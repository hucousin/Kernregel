/**
 * File: interpreter.cpp
 * Compile: C++ 17
 */

#include "method.cpp"

// ---------- 编译期 FNV-1a 64位 ----------
constexpr uint64_t fnv1a(const char* s, size_t n) noexcept {
    uint64_t h = 14695981039346656037ULL;   // offset basis
    for (size_t i = 0; i < n; ++i) {
        h ^= (uint64_t)(unsigned char)s[i];
        h *= 1099511628211ULL;              // FNV prime
    }
    return h;
}

// 字面量后缀： "KRFehl"_h 会在编译期算出常量
constexpr uint64_t operator""_h(const char* s, size_t n) noexcept {
    return fnv1a(s, n);
}

Value eval_expr(ASTNode* node) {
    // if (std::this_thread::get_id() != main_thread_id) {
    //     return make_null();
    // }
     g_last_error_line = node->line;
     g_last_error_col = node->col;
     g_last_error_filename = nullptr;
     if (g_trace_ast) {
         std::string indent(eval_depth * 2, ' ');
         fprintf(stderr, "%s[VERF] eval_expr: %s at %d:%d\n",
                 indent.c_str(),
                 node_type_to_string(node->type),
                 node->line, node->col);
     }
     // 递归深度检查
     if (++eval_depth > MAX_RECURSION_DEPTH) {
         kr_error("Fehler: 表达式递归深度超过限制 (%d)\n", MAX_RECURSION_DEPTH);
         
     }
     EvalNodeGuard node_guard(node);
     Value result;
     switch (node->type) {
        case NODE_NUMBER: {
            const char* str = node->data.number_str;
            // 快速路径：十进制小整数
            errno = 0;
            char* end = nullptr;
            long long v = strtoll(str, &end, 10);
            if (end && *end == '\0' && end != str && errno == 0) {
                result = make_int64(v);
                break;
            }
            // 回退到通用 GMP 路径（十六进制、二进制、大整数等）
            mpz_t tmp;
            mpz_init(tmp);
            int base = 10;
            const char* num_start = str;
            if (strncmp(str, "0x", 2) == 0 || strncmp(str, "0X", 2) == 0) {
                base = 16;
                num_start = str + 2;          // 去掉前缀
            } else if (strncmp(str, "0b", 2) == 0 || strncmp(str, "0B", 2) == 0) {
                base = 2;
                num_start = str + 2;
            } else if (strncmp(str, "0o", 2) == 0 || strncmp(str, "0O", 2) == 0) {
                base = 8;
                num_start = str + 2;
            }
            if (mpz_set_str(tmp, num_start, base) != 0) {
                kr_error("无效的整数常量");
            }
            result = make_int_auto(tmp);
            mpz_clear(tmp);
            break;
        }
        case NODE_FLOAT: {
            mpf_t tmp;
            mpf_init(tmp);
            const char* str = node->data.float_str;
            bool parsed = false;
        
            // 1. 尝试默认十进制
            if (mpf_set_str(tmp, str, 10) == 0) {
                parsed = true;
            }
            // 2. 如果是十六进制格式
            else if (strncmp(str, "0x", 2) == 0 || strncmp(str, "0X", 2) == 0) {
                // 2a. 尝试 base=0（自动识别十六进制）
                if (!parsed && mpf_set_str(tmp, str, 0) == 0) {
                    parsed = true;
                }
                // 2b. 去掉前缀，用 base=16
                if (!parsed) {
                    std::string no_prefix = str + 2;
                    // 确保指数符号（如果缺省则补 +）
                    size_t ppos = no_prefix.find_first_of("pP");
                    if (ppos != std::string::npos && ppos + 1 < no_prefix.size()) {
                        char next = no_prefix[ppos + 1];
                        if (next != '+' && next != '-') {
                            no_prefix.insert(ppos + 1, "+");
                        }
                    }
                    if (mpf_set_str(tmp, no_prefix.c_str(), 16) == 0) {
                        parsed = true;
                    }
                }
                // 2c. 将 'P' 统一转为 'p' 再试一次
                if (!parsed) {
                    std::string modified = str + 2;
                    for (char& c : modified) if (c == 'P') c = 'p';
                    // 补符号（同上）
                    size_t ppos = modified.find('p');
                    if (ppos != std::string::npos && ppos + 1 < modified.size()) {
                        char next = modified[ppos + 1];
                        if (next != '+' && next != '-') {
                            modified.insert(ppos + 1, "+");
                        }
                    }
                    if (mpf_set_str(tmp, modified.c_str(), 16) == 0) {
                        parsed = true;
                    }
                }
                // 2d. 最后尝试用 strtod（虽然标准不支持十六进制，但某些实现扩展）
                if (!parsed) {
                    char* end;
                    double d = strtod(str, &end);
                    if (end != str && *end == '\0') {
                        mpf_set_d(tmp, d);
                        parsed = true;
                    }
                }
            }
        
            if (!parsed) {
                mpf_clear(tmp);
                kr_error("无效的浮点数常量");
            }
        
            result = make_float(tmp);
            mpf_clear(tmp);
            break;
        }
        case NODE_STRING: {
            size_t len = node->string_len;
            if (len == 0 && node->data.string) len = strlen(node->data.string);
            result = make_string_len(node->data.string, len);
            break;
        }
        case NODE_BINARY: {
            Value left = eval_expr(node->data.binary.left);
            Value right = eval_expr(node->data.binary.right);
            char op = node->data.binary.op;

            if (op == '+') {
                if (left.type == VAL_STRING || right.type == VAL_STRING ||
                    left.type == VAL_NULL || right.type == VAL_NULL) {
                    if (left.type == VAL_STRING && right.type == VAL_STRING) {
                        std::string combined;
                        combined.reserve(left.str_len + right.str_len);
                        combined.append(left.str_val, left.str_len);
                        combined.append(right.str_val, right.str_len);
                        result = make_string_len(combined.data(), combined.size());
                    } else {
                        std::string lstr = value_to_stdstring(left);
                        std::string rstr = value_to_stdstring(right);
                        std::string combined = lstr + rstr;
                        result = make_string_len(combined.data(), combined.size());
                    }
                    free_value(&left);
                    free_value(&right);
                    break;
                }
            }
        
            // ------------------------------------------------------------
            // 1. 特殊运算符：字符串拼接 (##)
            // ------------------------------------------------------------
            if (op == 'H') {
                std::string lstr = value_to_stdstring(left);
                std::string rstr = value_to_stdstring(right);
                std::string combined = lstr + rstr;
                result = make_string_len(combined.data(), combined.size());
                free_value(&left); free_value(&right);
                break;
            }
        
            // ------------------------------------------------------------
            // 2. 快速路径：双方都是原生 int64（仅算术/比较）
            // ------------------------------------------------------------
            if (left.type == VAL_INT64 && right.type == VAL_INT64 &&
                op != '^' && op != 'X' && op != '|' && op != '&') {
                int64_t a = left.int64_val;
                int64_t b = right.int64_val;
                int64_t res;
                bool overflow = false;
        
                switch (op) {
                    case '+':
                        if (__builtin_add_overflow(a, b, &res)) overflow = true;
                        break;
                    case '-':
                        if (__builtin_sub_overflow(a, b, &res)) overflow = true;
                        break;
                    case '*':
                        if (__builtin_mul_overflow(a, b, &res)) overflow = true;
                        break;
                    case '/':
                        if (b == 0) kr_error("除零错误");
                        if (a == INT64_MIN && b == -1) { overflow = true; } else { res = a / b; }
                        break;
                    case '%':
                        if (b == 0) kr_error("取模零");
                        res = a % b;
                        break;
                    case '>':  res = (a > b); break;
                    case '<':  res = (a < b); break;
                    case 'E':  res = (a == b); break;
                    case 'N':  res = (a != b); break;
                    case 'G':  res = (a >= b); break;
                    case 'L':  res = (a <= b); break;
                    case 'C':  res = (a > b) ? 1 : (a < b) ? -1 : 0; break;
                    default:
                        kr_error("不支持的二元运算符 '%c'", op);
                }
        
                free_value(&left);
                free_value(&right);
        
                if (overflow) {
                    // 回退到 GMP
                    mpz_t la, lb, lr;
                    mpz_init_set_si(la, a);
                    mpz_init_set_si(lb, b);
                    mpz_init(lr);
                    switch (op) {
                        case '+': mpz_add(lr, la, lb); break;
                        case '-': mpz_sub(lr, la, lb); break;
                        case '*': mpz_mul(lr, la, lb); break;
                        case '/': if (mpz_sgn(lb) == 0) kr_error("除零错误"); mpz_tdiv_q(lr, la, lb); break;
                        case '%': if (mpz_sgn(lb) == 0) kr_error("取模零"); mpz_mod(lr, la, lb); break;
                        case '^': if (!mpz_fits_ulong_p(lb)) kr_error("指数过大"); mpz_pow_ui(lr, la, mpz_get_ui(lb)); break;
                        default: kr_error("不支持溢出的运算符");
                    }
                    result = make_int_auto(lr);
                    mpz_clear(la); mpz_clear(lb); mpz_clear(lr);
                } else {
                    result = make_int64(res);
                }
                break;
            }
        
            // ------------------------------------------------------------
            // 3. 完整逻辑（支持 null、字符串、浮点、大整数等）
            //    注意：此处所有 VAL_INT64 都会先被转换为 GMP 或浮点
            // ------------------------------------------------------------
            // 注意：此 lambda 会修改 v 的类型，但不会影响后续 free_value（因为复制了）
        
            // ---- 对 null 的处理 ----
            if (left.type == VAL_NULL || right.type == VAL_NULL) {
                if (op == 'E') {
                    result = make_int((left.type == VAL_NULL && right.type == VAL_NULL) ? 1 : 0);
                } else if (op == 'N') {
                    result = make_int(!(left.type == VAL_NULL && right.type == VAL_NULL));
                } else {
                    kr_warn("null 与非 '=='/'!=' 运算符比较，结果强制为 false");
                    result = make_int(0LL);
                }
                free_value(&left); free_value(&right);
                break;
            }
        
            // ---- 判断类型 ----
            bool left_num = (left.type == VAL_INT || left.type == VAL_FLOAT || left.type == VAL_INT64);
            bool right_num = (right.type == VAL_INT || right.type == VAL_FLOAT || right.type == VAL_INT64);
            bool left_str = (left.type == VAL_STRING);
            bool right_str = (right.type == VAL_STRING);
            bool is_comparison = (op == '>' || op == '<' || op == 'G' || op == 'L' ||
                                    op == 'E' || op == 'N' || op == 'C');
        
            // ---- 4. 比较运算（包含字符串、单字符数字比较等） ----
            if (is_comparison) {
                // 如果双方都是数值类型（包括 INT64、GMP、浮点）
                if (left_num && right_num) {
                    // 只要有浮点就浮点比较
                    if (left.type == VAL_FLOAT || right.type == VAL_FLOAT ||
                        (left.type == VAL_INT64 && right.type == VAL_INT64)) {
                        // 但 int64 已在快速路径中处理，这里只处理含 GMP 或浮点的情况
                        mpf_t a, b;
                        mpf_init(a); mpf_init(b);
                        if (left.type == VAL_INT64) mpf_set_int64(a, left.int64_val);
                        else if (left.type == VAL_INT) mpf_set_z(a, *left.big_int);
                        else mpf_set(a, *left.mpf_val);
        
                        if (right.type == VAL_INT64) mpf_set_int64(b, right.int64_val);
                        else if (right.type == VAL_INT) mpf_set_z(b, *right.big_int);
                        else mpf_set(b, *right.mpf_val);
        
                        int cmp = mpf_cmp(a, b);
                        int res = 0;
                        switch (op) {
                            case '>': res = (cmp > 0); break;
                            case '<': res = (cmp < 0); break;
                            case 'E': res = (cmp == 0); break;
                            case 'N': res = (cmp != 0); break;
                            case 'G': res = (cmp >= 0); break;
                            case 'L': res = (cmp <= 0); break;
                            case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
                        }
                        result = make_int(res);
                        mpf_clear(a); mpf_clear(b);
                        free_value(&left); free_value(&right);
                        break;
                    } else {
                        // 纯 GMP 整数比较
                        mpz_t a, b;
                        mpz_init(a); mpz_init(b);
                        if (left.type == VAL_INT64) mpz_set_int64(a, left.int64_val);
                        else mpz_set(a, *left.big_int);
                        if (right.type == VAL_INT64) mpz_set_int64(b, right.int64_val);
                        else mpz_set(b, *right.big_int);
                        int cmp = mpz_cmp(a, b);
                        int res = 0;
                        switch (op) {
                            case '>': res = (cmp > 0); break;
                            case '<': res = (cmp < 0); break;
                            case 'E': res = (cmp == 0); break;
                            case 'N': res = (cmp != 0); break;
                            case 'G': res = (cmp >= 0); break;
                            case 'L': res = (cmp <= 0); break;
                            case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
                        }
                        result = make_int(res);
                        mpz_clear(a); mpz_clear(b);
                        free_value(&left); free_value(&right);
                        break;
                    }
                }
        
                // ---- 至少一边是字符串（包含单字符与数字比较） ----
                if (left_str || right_str) {
                    // 尝试将字符串转为数字
                    mpf_t left_mpf, right_mpf;
                    mpf_init(left_mpf); mpf_init(right_mpf);
                    bool left_parsed = false, right_parsed = false;
        
                    if (left_str) {
                        if (mpf_set_str(left_mpf, left.str_val, 10) == 0) left_parsed = true;
                    }
                    if (right_str) {
                        if (mpf_set_str(right_mpf, right.str_val, 10) == 0) right_parsed = true;
                    }
        
                    bool can_do_numeric = false;
                    mpf_t a, b;
                    mpf_init(a); mpf_init(b);
        
                    if (left_num && right_parsed) {
                        can_do_numeric = true;
                        if (left.type == VAL_INT64) mpf_set_int64(a, left.int64_val);
                        else if (left.type == VAL_INT) mpf_set_z(a, *left.big_int);
                        else mpf_set(a, *left.mpf_val);
                        mpf_set(b, right_mpf);
                    } else if (left_parsed && right_num) {
                        can_do_numeric = true;
                        mpf_set(a, left_mpf);
                        if (right.type == VAL_INT64) mpf_set_int64(b, right.int64_val);
                        else if (right.type == VAL_INT) mpf_set_z(b, *right.big_int);
                        else mpf_set(b, *right.mpf_val);
                    } else if (left_parsed && right_parsed) {
                        can_do_numeric = true;
                        mpf_set(a, left_mpf);
                        mpf_set(b, right_mpf);
                    }
        
                    if (can_do_numeric) {
                        int cmp = mpf_cmp(a, b);
                        int res = 0;
                        switch (op) {
                            case '>': res = (cmp > 0); break;
                            case '<': res = (cmp < 0); break;
                            case 'E': res = (cmp == 0); break;
                            case 'N': res = (cmp != 0); break;
                            case 'G': res = (cmp >= 0); break;
                            case 'L': res = (cmp <= 0); break;
                            case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
                        }
                        result = make_int(res);
                        mpf_clear(a); mpf_clear(b);
                        mpf_clear(left_mpf); mpf_clear(right_mpf);
                        free_value(&left); free_value(&right);
                        break;
                    }
        
                    // ---- 单字符与数字比较 ----
                    bool special_char_compare = false;
                    std::string left_s, right_s;
                    if (left_str && right_num && strlen(left.str_val) == 1) {
                        long long n = value_to_ll(right);
                        if (n >= 0 && n <= 255) {
                            left_s = left.str_val;
                            right_s = std::string(1, (char)n);
                            special_char_compare = true;
                        }
                    } else if (left_num && right_str && strlen(right.str_val) == 1) {
                        long long n = value_to_ll(left);
                        if (n >= 0 && n <= 255) {
                            left_s = std::string(1, (char)n);
                            right_s = right.str_val;
                            special_char_compare = true;
                        }
                    }
        
                    if (special_char_compare) {
                        int cmp = strcmp(left_s.c_str(), right_s.c_str());
                        int res = 0;
                        switch (op) {
                            case '>': res = (cmp > 0); break;
                            case '<': res = (cmp < 0); break;
                            case 'E': res = (cmp == 0); break;
                            case 'N': res = (cmp != 0); break;
                            case 'G': res = (cmp >= 0); break;
                            case 'L': res = (cmp <= 0); break;
                            case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
                        }
                        result = make_int(res);
                        mpf_clear(a); mpf_clear(b);
                        mpf_clear(left_mpf); mpf_clear(right_mpf);
                        free_value(&left); free_value(&right);
                        break;
                    }
        
                    // ---- 纯字符串比较 ----
                    char* ls = value_to_string(left);
                    char* rs = value_to_string(right);
                    int cmp = strcmp(ls, rs);
                    int res = 0;
                    switch (op) {
                        case '>': res = (cmp > 0); break;
                        case '<': res = (cmp < 0); break;
                        case 'E': res = (cmp == 0); break;
                        case 'N': res = (cmp != 0); break;
                        case 'G': res = (cmp >= 0); break;
                        case 'L': res = (cmp <= 0); break;
                        case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
                    }
                    free(ls); free(rs);
                    result = make_int(res);
                    mpf_clear(left_mpf); mpf_clear(right_mpf);
                    free_value(&left); free_value(&right);
                    break;
                }
        
                // 如果都不是数值或字符串，则根据类型返回 false
                kr_warn("未知类型比较，返回 false");
                result = make_int(0LL);
                free_value(&left); free_value(&right);
                break;
            }
        
            // ---- 5. 算术运算（+ - * / % ^） ----
            if (op == 'X' || op == '|' || op == '&') {
                const char* op_name = (op == 'X') ? "异或(~=)" :
                                      (op == '|') ? "按位或(|=)" : "按位与(&=)";
            
                mpz_t a, b, r;
                mpz_init(a); mpz_init(b); mpz_init(r);
            
                if (left.type == VAL_FLOAT || right.type == VAL_FLOAT) {
                    mpz_clear(a); mpz_clear(b); mpz_clear(r);
                    kr_error("%s 不支持浮点数操作数", op_name);
                }
            
                if (left.type == VAL_INT64) {
                    mpz_set_int64(a, left.int64_val);
                } else if (left.type == VAL_INT) {
                    mpz_set(a, *left.big_int);
                } else {
                    mpz_clear(a); mpz_clear(b); mpz_clear(r);
                    kr_error("%s 左操作数必须是整数，实际类型 '%s'",
                             op_name, value_type_to_string(left).c_str());
                }
            
                if (right.type == VAL_INT64) {
                    mpz_set_int64(b, right.int64_val);
                } else if (right.type == VAL_INT) {
                    mpz_set(b, *right.big_int);
                } else {
                    mpz_clear(a); mpz_clear(b); mpz_clear(r);
                    kr_error("%s 右操作数必须是整数，实际类型 '%s'",
                             op_name, value_type_to_string(right).c_str());
                }
            
                if (op == 'X')      mpz_xor(r, a, b);
                else if (op == '|') mpz_ior(r, a, b);
                else                mpz_and(r, a, b);
            
                free_value(&left);
                free_value(&right);
            
                if (mpz_fits_slong_p(r)) {
                    result = make_int64(mpz_get_si(r));
                } else {
                    result = make_int(r);
                }
            
                mpz_clear(a);
                mpz_clear(b);
                mpz_clear(r);
                break;
            }
            // 确保所有整数操作数都是 GMP（将 INT64 转为 GMP）
            if (left.type == VAL_INT64) {
                int64_t tmp = left.int64_val;
                left.big_int = (mpz_t*)malloc(sizeof(mpz_t));
                mpz_init(*left.big_int);
                mpz_set_int64(*left.big_int, tmp);
                left.type = VAL_INT;
            }
            if (right.type == VAL_INT64) {
                int64_t tmp = right.int64_val;
                right.big_int = (mpz_t*)malloc(sizeof(mpz_t));
                mpz_init(*right.big_int);
                mpz_set_int64(*right.big_int, tmp);
                right.type = VAL_INT;
            }
        
            // 检查是否为数值类型（整数或浮点）
            if (!(left.type == VAL_INT || left.type == VAL_FLOAT) ||
                !(right.type == VAL_INT || right.type == VAL_FLOAT)) {
                kr_error("算术运算符需要数值操作数");
            }
        
            // 浮点运算
            if (left.type == VAL_FLOAT || right.type == VAL_FLOAT) {
                // 对 FLOAT 操作数直接引用其 mpf 数据，避免无谓复制；
                // 只有 INT / INT64 操作数才需要临时 mpf。
                mpf_ptr lp, rp;
                mpf_t ltmp, rtmp;
                bool ltmp_used = false, rtmp_used = false;
            
                if (left.type == VAL_FLOAT) {
                    lp = *left.mpf_val;                  // 直接指向原数据
                } else {
                    mpf_init(ltmp);
                    if (left.type == VAL_INT64) mpf_set_int64(ltmp, left.int64_val);
                    else mpf_set_z(ltmp, *left.big_int);
                    lp = ltmp;
                    ltmp_used = true;
                }
                if (right.type == VAL_FLOAT) {
                    rp = *right.mpf_val;
                } else {
                    mpf_init(rtmp);
                    if (right.type == VAL_INT64) mpf_set_int64(rtmp, right.int64_val);
                    else mpf_set_z(rtmp, *right.big_int);
                    rp = rtmp;
                    rtmp_used = true;
                }
            
                mpf_t r;
                mpf_init(r);
                switch (op) {
                    case '+': mpf_add(r, lp, rp); break;
                    case '-': mpf_sub(r, lp, rp); break;
                    case '*': mpf_mul(r, lp, rp); break;
                    case '/':
                        if (mpf_sgn(rp) == 0) {
                            mpf_clear(r);
                            if (ltmp_used) mpf_clear(ltmp);
                            if (rtmp_used) mpf_clear(rtmp);
                            kr_error("除零错误");
                        }
                        mpf_div(r, lp, rp);
                        break;
                    case '^': {
                        bool exponent_is_int = false;
                        unsigned long exp = 0;
                        if (right.type == VAL_INT64) {
                            if (right.int64_val < 0) {
                                mpf_clear(r);
                                if (ltmp_used) mpf_clear(ltmp);
                                if (rtmp_used) mpf_clear(rtmp);
                                kr_error("指数不能为负");
                            }
                            exp = (unsigned long)right.int64_val;
                            exponent_is_int = true;
                        } else if (right.type == VAL_INT) {
                            if (!mpz_fits_ulong_p(*right.big_int)) {
                                mpf_clear(r);
                                if (ltmp_used) mpf_clear(ltmp);
                                if (rtmp_used) mpf_clear(rtmp);
                                kr_error("指数过大");
                            }
                            exp = mpz_get_ui(*right.big_int);
                            exponent_is_int = true;
                        }
                        if (exponent_is_int) {
                            mpf_set_ui(r, 1);
                            for (unsigned long i = 0; i < exp; ++i)
                                mpf_mul(r, r, lp);
                        } else if (right.type == VAL_FLOAT) {
                            double ad = mpf_get_d(lp);
                            double bd = mpf_get_d(rp);
                            mpf_set_d(r, pow(ad, bd));
                        } else {
                            mpf_clear(r);
                            if (ltmp_used) mpf_clear(ltmp);
                            if (rtmp_used) mpf_clear(rtmp);
                            kr_error("乘方右操作数非数值");
                        }
                        break;
                    }
                    default:
                        mpf_clear(r);
                        if (ltmp_used) mpf_clear(ltmp);
                        if (rtmp_used) mpf_clear(rtmp);
                        kr_error("未知浮点算术运算符");
                }
                result = make_float(r);
                mpf_clear(r);
                if (ltmp_used) mpf_clear(ltmp);
                if (rtmp_used) mpf_clear(rtmp);
            } else {
                // 纯整数 GMP 运算（此时 left/right 都是 VAL_INT，big_int 已有效）
                mpz_t r;
                mpz_init(r);
                switch (op) {
                    case '+': mpz_add   (r, *left.big_int, *right.big_int); break;
                    case '-': mpz_sub   (r, *left.big_int, *right.big_int); break;
                    case '*': mpz_mul   (r, *left.big_int, *right.big_int); break;
                    case '/':
                        if (mpz_sgn(*right.big_int) == 0) kr_error("除零错误");
                        mpz_tdiv_q(r, *left.big_int, *right.big_int);
                        break;
                    case '%':
                        if (mpz_sgn(*right.big_int) == 0) kr_error("取模零");
                        mpz_mod(r, *left.big_int, *right.big_int);
                        break;
                    case '^':
                        if (!mpz_fits_ulong_p(*right.big_int)) kr_error("指数过大");
                        mpz_pow_ui(r, *left.big_int, mpz_get_ui(*right.big_int));
                        break;
                    default: kr_error("未知整数算术运算符");
                }
                if (fits_int64(r)) {
                    result = make_int64(mpz_get_int64(r));
                } else {
                    result = make_int(r);
                }
                mpz_clear(r);
            }
        
            free_value(&left);
            free_value(&right);
            break;
        }
        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT: {
            Value left = eval_expr(node->data.binary.left);
            Value right = eval_expr(node->data.binary.right);
            // 确保操作数是整数
            if (!(left.type == VAL_INT64 || left.type == VAL_INT) ||
                !(right.type == VAL_INT64 || right.type == VAL_INT)) {
                kr_error("位运算符要求整数操作数");
            }
            // 转换为 mpz_t
            mpz_t a, b, r;
            mpz_init(a); mpz_init(b); mpz_init(r);
            if (left.type == VAL_INT64) mpz_set_int64(a, left.int64_val);
            else mpz_set(a, *left.big_int);
            if (right.type == VAL_INT64) mpz_set_int64(b, right.int64_val);
            else mpz_set(b, *right.big_int);

            switch (node->type) {
                case NODE_BITWISE_OR:  mpz_ior(r, a, b); break;
                case NODE_BITWISE_AND: mpz_and(r, a, b); break;
                case NODE_SHIFT_LEFT: {
                    if (!mpz_fits_ulong_p(b)) kr_error("左移位数过大");
                    unsigned long shift = mpz_get_ui(b);
                    mpz_mul_2exp(r, a, shift);
                    break;
                }
                case NODE_SHIFT_RIGHT: {
                    if (!mpz_fits_ulong_p(b)) kr_error("右移位数过大");
                    unsigned long shift = mpz_get_ui(b);
                    mpz_tdiv_q_2exp(r, a, shift);   // 向零取整（算术右移）
                    break;
                }
                default: break;
            }

            free_value(&left);
            free_value(&right);
            // 结果可能为 int64
            if (mpz_fits_slong_p(r)) {
                result = make_int64(mpz_get_si(r));
            } else {
                result = make_int(r);
            }
            mpz_clear(a); mpz_clear(b); mpz_clear(r);
            break;
        }
        case NODE_FUNC_CALL: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);

            std::vector<Value> arg_store;              // 仅当 arg_count > 0 时才使用
            Value* args    = nullptr;
            int    arg_count = node->data.func_call.arg_count;

            if (arg_count > 0) {
                arg_store.reserve(arg_count);
                for (int i = 0; i < arg_count; ++i) {
                    ASTNode* param = node->data.func_call.args[i];
                    if (param->type == NODE_SPREAD_ARG) {
                        Value spread_val = eval_expr(param->data.spread.expr);
                        if (spread_val.type != VAL_ARRAY)
                            kr_error("函数调用展开只能用于数组");
                        for (int j = 0; j < spread_val.arr_val.length; ++j)
                            arg_store.push_back(copy_value(spread_val.arr_val.elements[j]));
                        free_value(&spread_val);
                    } else {
                        arg_store.push_back(eval_expr(param));
                    }
                }
                args = arg_store.data();
                arg_count = (int)arg_store.size();
            }

            if (node->data.func_call.func_expr != nullptr) {
                Value func_val = eval_expr(node->data.func_call.func_expr);
                if (func_val.type != VAL_FUNCTION) kr_error("表达式不是函数");
                result = call_function_value(func_val, args, arg_count, node);
                free_value(&func_val);
                for (auto& v : arg_store) free_value(&v);
                return_caught = break_caught = continue_caught = exception_raised = false;
                break;
            }

            char* fname = node->data.func_call.name;

            if (node->data.func_call.name && strcmp(node->data.func_call.name, "ast") == 0) {
                if (node->data.func_call.arg_count != 1) {
                    kr_error("ast 需要恰好 1 个参数");
                }
                ASTNode* arg_node = node->data.func_call.args[0];
                std::string ast_str = ast_to_string(arg_node);
                result = make_string(ast_str.c_str());
                break;
            }
    
            uint64_t fh = fnv1a(fname, std::strlen(fname));
            if (fh == "KRFehl"_h) {
                if (arg_count < 1) kr_error("KRFehl 需要至少 1 个参数（错误消息或对象）");

                std::string msg;
                int line = 0, col = 0;
                std::string filename;
                std::string custom_source;
                std::string hint;
                int level = 0;   // 回退层级
                bool found_valid = false;

                // ---------- 1. 判断参数模式 ----------
                if (arg_count >= 1 && args[0].type == VAL_OBJECT) {
                    // 对象模式
                    for (int i = 0; i < args[0].obj_val.count; ++i) {
                        const char* key = args[0].obj_val.entries[i].key;
                        Value val = args[0].obj_val.entries[i].value;

                        if (strcmp(key, "msg") == 0 || strcmp(key, "info") == 0 || strcmp(key, "text") == 0) {
                            char* s = value_to_string(val);
                            msg = s;
                            free(s);
                        }
                        else if (strcmp(key, "line") == 0 || strcmp(key, "zel") == 0) {
                            if (val.type == VAL_INT || val.type == VAL_INT64)
                                line = (int)value_to_ll(val);
                        }
                        else if (strcmp(key, "col") == 0 || strcmp(key, "spl") == 0) {
                            if (val.type == VAL_INT || val.type == VAL_INT64)
                                col = (int)value_to_ll(val);
                        }
                        else if (strcmp(key, "file") == 0 || strcmp(key, "datei") == 0 || strcmp(key, "name") == 0) {
                            if (val.type == VAL_STRING)
                                filename = val.str_val;
                        }
                        else if (strcmp(key, "kont") == 0) {
                            if (val.type == VAL_STRING)
                                custom_source = val.str_val;
                        }
                        else if (strcmp(key, "hint") == 0) {
                            if (val.type == VAL_STRING)
                                hint = val.str_val;
                        }
                        else if (strcmp(key, "rueck") == 0 || strcmp(key, "level") == 0) {
                            if (val.type == VAL_INT || val.type == VAL_INT64) {
                                level = (int)value_to_ll(val);
                                if (level < 0) level = 0;
                            }
                        }
                    }
                    if (msg.empty() && msg != "") {
                        kr_error("KRFehl 对象参数缺少 'info' 字段");
                    }
                } else {
                    // 顺序模式
                    char* msg_cstr = value_to_string(args[0]);
                    msg = msg_cstr;
                    free(msg_cstr);

                    if (arg_count >= 2) {
                        if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                            kr_error("KRFehl 第 2 个参数必须是整数（行号）");
                        line = (int)value_to_ll(args[1]);
                        if (arg_count >= 3) {
                            if (args[2].type != VAL_INT && args[2].type != VAL_INT64)
                                kr_error("KRFehl 第 3 个参数必须是整数（列号）");
                            col = (int)value_to_ll(args[2]);
                            if (arg_count >= 4) {
                                if (args[3].type != VAL_STRING)
                                    kr_error("KRFehl 第 4 个参数必须是字符串（文件名）");
                                filename = args[3].str_val;
                            }
                        }
                    }
                    if (arg_count >= 5) {
                        if (args[4].type != VAL_STRING)
                            kr_error("KRFehl 第 5 个参数必须是字符串（自定义源码）");
                        custom_source = args[4].str_val;
                    }
                    if (arg_count >= 6) {
                        if (args[5].type != VAL_STRING)
                            kr_error("KRFehl 第 6 个参数必须是字符串（提示）");
                        hint = args[5].str_val;
                    }
                }

                // ---------- 2. 确定最终位置 ----------
                if (level > 0) {
                    std::vector<size_t> valid_indices;
                    for (size_t i = 0; i < g_call_stack.size(); ++i) {
                        const CallFrame& frame = g_call_stack[i];
                        if (frame.line > 0 && frame.col > 0 &&
                            frame.filename && frame.filename[0] != '\0' &&
                            strcmp(frame.filename, "-") != 0) {
                            valid_indices.push_back(i);
                        }
                    }
                    if (!valid_indices.empty()) {
                        int idx = (int)valid_indices.size() - 1 - level;
                        if (idx < 0) idx = 0;
                        size_t real_idx = valid_indices[idx];
                        const CallFrame& frame = g_call_stack[real_idx];
                        line = frame.line;
                        col = frame.col;
                        // 优先通过行列从映射获取文件名
                        const char* fname = find_filename_by_line_col(line, col);
                        if (fname) {
                            filename = fname;
                        } else {
                            filename = frame.filename; // 后备：使用帧中存储的文件名
                        }
                        found_valid = true;
                    }
                }
                
                // 如果未找到有效帧或 level==0，则使用当前节点（KRFehl 调用点）
                if (!found_valid) {
                    line = node->line;
                    col = node->col;
                    // 通过节点位置查找文件名
                    const char* fname = find_filename_by_line_col(line, col);
                    if (fname) {
                        filename = fname;   // 用 std::string 存储
                    }
                    if (filename.empty()) {
                        filename = current_filename ? current_filename : "-";
                    }
                }

                if (filename.empty())
                    filename = (current_filename && current_filename[0] != '\0') ? current_filename : "-";

                // ---------- 3. 设置线程局部变量 ----------
                g_last_error_line = line;
                g_last_error_col = col;

                static thread_local std::string filename_storage;
                if (!filename.empty()) {
                    filename_storage = filename;
                } else if (current_filename) {
                    filename_storage = current_filename;
                } else {
                    filename_storage = "-";
                }
                g_last_error_filename = filename_storage.c_str();

                // 如果还设置了 custom_source，继续：
                g_custom_source_context = custom_source;

                // 然后抛出错误
                if (!hint.empty())
                    kr_error_hint(hint.c_str(), "%s", msg.c_str());
                else
                    kr_error("%s", msg.c_str());
            }            

            // ==================== 内置函数处理 ====================

            else if (fh == "vw"_h) {
                if (arg_count < 1 || arg_count > 4) {
                    kr_error("vw benötigt 1 bis 4 Parameter: Code, [Startzeile, Startspalte, Dateiname]");
                }
                if (args[0].type != VAL_STRING) {
                    kr_error("erster Parameter muss ein String (Verwirrt-Code) sein");
                }
                std::string vw_code(args[0].str_val, args[0].str_len);
                int start_line = node->line;
                int start_col = node->col;
                const char* filename = current_filename ? current_filename : "-";
                if (arg_count >= 2) {
                    if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                        kr_error("zweiter Parameter muss eine ganze Zahl (Startzeile) sein");
                    start_line = (int)value_to_ll(args[1]);
                }
                if (arg_count >= 3) {
                    if (args[2].type != VAL_INT && args[2].type != VAL_INT64)
                        kr_error("dritter Parameter muss eine ganze Zahl (Startspalte) sein");
                    start_col = (int)value_to_ll(args[2]);
                }
                if (arg_count >= 4) {
                    if (args[3].type != VAL_STRING)
                        kr_error("vierter Parameter muss ein String (Dateiname) sein");
                    filename = args[3].str_val;
                }

                // ----- 构造外部回调函数 -----
                auto external_call = [&](const std::string& func_name, const std::string& args_json) -> std::string {
                    // 解析参数 JSON
                    JSONParser parser(args_json);
                    Value args_val = parser.parse();

                    // 提取参数数组
                    std::vector<Value> call_args;
                    if (args_val.type == VAL_ARRAY) {
                        for (int i = 0; i < args_val.arr_val.length; ++i)
                            call_args.push_back(copy_value(args_val.arr_val.elements[i]));
                    } else {
                        // 如果传入的是单个值，则作为唯一参数
                        call_args.push_back(copy_value(args_val));
                    }
                    free_value(&args_val);

                    // 查找 Kernregel 函数
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    Function* func = get_function(func_name.c_str());
                    if (!func) {
                        kr_error("Kernregel-Funktion '%s' nicht gefunden", func_name.c_str());
                    }

                    // 构造函数值（用于调用）
                    Value func_val = make_function(
                        func->name,
                        func->params,
                        func->param_count,
                        func->body,
                        func->closure_scope,
                        func->is_memoized,
                        func->is_async,
                        func->global_scope,
                        false, // is_rule
                        func->return_type,
                        func->vararg_name,
                        func->param_is_const,
                        func->param_defaults,
                        func->param_types,
                        func->vararg_type
                    );
                    // 调用函数
                    Value result = call_function_value(func_val, call_args.data(), (int)call_args.size(), nullptr);
                    free_value(&func_val);
                    for (auto& v : call_args) free_value(&v);

                    // 将结果序列化为 JSON
                    std::string result_json = json_stringify_value(result, false, 0);
                    free_value(&result);
                    return result_json;
                };

                // 获取当前上下文 JSON
                std::string context_json = export_global_values();
                std::string result_json = execute_vw(vw_code, context_json, start_line, start_col, filename, external_call);

                // ---- 导入所有变量（包括对象、数组） ----
                JSONParser parser(result_json);
                Value result_obj = parser.parse();
                if (result_obj.type == VAL_OBJECT) {
                    Scope* gs = get_global_scope();   // 使用全局作用域
                    for (int i = 0; i < result_obj.obj_val.count; ++i) {
                        const char* key = result_obj.obj_val.entries[i].key;
                        Value val = copy_value(result_obj.obj_val.entries[i].value);
                        // 在全局作用域查找或声明变量
                        int idx = get_var_index_in_scope(gs, key);
                        if (idx >= 0) {
                            Variable* var = &gs->vars[idx];
                            if (var->is_const) {
                                // 常量变量不允许通过 vw 重新赋值，跳过此更新
                                free_value(&val);
                                continue;
                            }
                            free_value(&var->value);
                            var->value = val;
                        } else {
                            declare_var_in_scope(gs, key, false, val);
                        }
                    }
                }
                free_value(&result_obj);
                result = make_null();
                break;
            }

            // 1. 数学函数：sqrt, abs, sin, cos, rand, srand
            else if (fh == "sqrt"_h || fh == "wurz"_h) {
                if (arg_count != 1) kr_error("sqrt/wurz 需要 1 个参数");
                Value x = args[0];
                if (x.type != VAL_INT && x.type != VAL_INT64 && x.type != VAL_FLOAT)
                    kr_error("参数必须是数值");
                mpf_t x_mpf; mpf_init(x_mpf);
                if (x.type == VAL_INT64) {
                    mpf_set_int64(x_mpf, x.int64_val);
                } else if (x.type == VAL_INT) {
                    mpf_set_z(x_mpf, *x.big_int);
                } else { // VAL_FLOAT
                    mpf_set(x_mpf, *x.mpf_val);
                }
                if (mpf_sgn(x_mpf) < 0) kr_error("负数不能开方");
                mpf_t res; mpf_init(res); mpf_sqrt(res, x_mpf);
                result = make_float(res);
                mpf_clear(x_mpf); mpf_clear(res);
                break;
            }
            else if (fh == "cbrt"_h || fh == "kub"_h) {
                if (arg_count != 1) kr_error("cbrt/kub 需要 1 个参数");
                double x = value_to_double(args[0]);
                double r = std::cbrt(x);
                result = make_float(r);
                break;
            }
            else if (fh == "abs"_h || fh == "btr"_h) {
                if (arg_count != 1) kr_error("abs/btr 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(fabs(x));
                break;
            }
            else if (fh == "sin"_h) {
                if (arg_count != 1) kr_error("sin 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(sin(x));
                break;
            }
            else if (fh == "cos"_h) {
                if (arg_count != 1) kr_error("cos 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(cos(x));
                break;
            }
            else if (fh == "tan"_h || fh == "tg"_h) {
                if (arg_count != 1) kr_error("tan/tg 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(tan(x));
                break;
            }
            else if (fh == "cot"_h || fh == "ctg"_h) {
                if (arg_count != 1) kr_error("cot/ctg 需要 1 个参数");
                double x = value_to_double(args[0]);
                double res = 1.0 / tan(x);
                result = make_float(res);
                break;
            }
            else if (fh == "sec"_h) {
                if (arg_count != 1) kr_error("sec 需要 1 个参数");
                double x = value_to_double(args[0]);
                double res = 1.0 / cos(x);
                result = make_float(res);
                break;
            }
            else if (fh == "csc"_h) {
                if (arg_count != 1) kr_error("csc 需要 1 个参数");
                double x = value_to_double(args[0]);
                double res = 1.0 / sin(x);
                result = make_float(res);
                break;
            }
            else if (fh == "asin"_h) {
                if (arg_count != 1) kr_error("asin 需要 1 个参数");
                double x = value_to_double(args[0]);
                if (x < -1 || x > 1) kr_error("asin 的定义域为 [-1,1]");
                result = make_float(asin(x));
                break;
            }
            else if (fh == "acos"_h) {
                if (arg_count != 1) kr_error("acos 需要 1 个参数");
                double x = value_to_double(args[0]);
                if (x < -1 || x > 1) kr_error("acos 的定义域为 [-1,1]");
                result = make_float(acos(x));
                break;
            }
            else if (fh == "atan"_h) {
                if (arg_count != 1) kr_error("atan 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(atan(x));
                break;
            }
            else if (fh == "atan2"_h) {
                if (arg_count != 2) kr_error("atan2 需要 2 个参数 (y, x)");
                double y = value_to_double(args[0]);
                double x = value_to_double(args[1]);
                result = make_float(atan2(y, x));
                break;
            }
            // ----- 双曲函数 -----
            else if (fh == "sinh"_h) {
                if (arg_count != 1) kr_error("sinh 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(sinh(x));
                break;
            }
            else if (fh == "cosh"_h) {
                if (arg_count != 1) kr_error("cosh 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(cosh(x));
                break;
            }
            else if (fh == "tanh"_h) {
                if (arg_count != 1) kr_error("tanh 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(tanh(x));
                break;
            }
            else if (fh == "asinh"_h) {
                if (arg_count != 1) kr_error("asinh 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(asinh(x));
                break;
            }
            else if (fh == "acosh"_h) {
                if (arg_count != 1) kr_error("acosh 需要 1 个参数");
                double x = value_to_double(args[0]);
                if (x < 1) kr_error("acosh 的定义域为 x ≥ 1");
                result = make_float(acosh(x));
                break;
            }
            else if (fh == "atanh"_h) {
                if (arg_count != 1) kr_error("atanh 需要 1 个参数");
                double x = value_to_double(args[0]);
                if (x <= -1 || x >= 1) kr_error("atanh 的定义域为 (-1,1)");
                result = make_float(atanh(x));
                break;
            }
            else if (fh == "rand"_h || fh == "zuf"_h) {
                if (arg_count != 0) kr_error("rand/zuf 不需要参数");
                result = make_int(rand());
                break;
            }
            else if (fh == "srand"_h || fh == "setze"_h) {
                if (arg_count != 1) kr_error("srand/setze 需要 1 个参数");
                int seed = value_to_int(args[0]);
                srand(seed);
                result = make_null();
                break;
            }

            // 2. 文件读取：leseDatei, lese, leseBin
            else if (fh == "leseDatei"_h || fh == "lese"_h) {
                if (arg_count != 1) kr_error("leseDatei/lese 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("文件名必须是字符串");
                FILE* fp = fopen(args[0].str_val, "rb");
                if (!fp) kr_error("无法打开文件 '%s'", args[0].str_val);
                fseek(fp, 0, SEEK_END);
                long len = ftell(fp);
                fseek(fp, 0, SEEK_SET);
                if (len < 0) len = 0;
                char* content = (char*)malloc((size_t)len + 1);
                fread(content, 1, (size_t)len, fp);
                content[len] = '\0';
                fclose(fp);
                result = make_string_len(content, (size_t)len);   // ← 不再走 strdup
                free(content);
                break;
            }
            else if (fh == "leseBin"_h) {
                if (arg_count != 1) kr_error("leseBin 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("文件名必须是字符串");
                std::ifstream file(args[0].str_val, std::ios::binary | std::ios::ate);
                if (!file) kr_error("无法打开文件 '%s'", args[0].str_val);
                std::streamsize len = file.tellg();
                if (len <= 0) kr_error("文件为空或大小无效");
                file.seekg(0, std::ios::beg);
                unsigned char* buffer = (unsigned char*)malloc((size_t)len);
                if (!buffer) kr_error("内存分配失败");
                file.read(reinterpret_cast<char*>(buffer), len);
                if (!file) { free(buffer); kr_error("读取文件失败"); }
                file.close();
                Value* elems = (Value*)malloc((size_t)len * sizeof(Value));
                for (std::streamsize i = 0; i < len; ++i) elems[i] = make_int((int)buffer[i]);
                result = make_array(elems, (int)len);
                free(elems); free(buffer);
                break;
            }

            // 3. 微积分函数：abl, inte, ab2, simp, grad, nullst, euler
            else if (fh == "abl"_h) {
                if (arg_count < 2 || arg_count > 3) kr_error("abl 需要 2 或 3 个参数");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double x = value_to_double(args[1]);
                double h = (arg_count == 3) ? value_to_double(args[2]) : 1e-5;
                if (h == 0.0) kr_error("步长不能为零");
                Value arg_plus = make_float(x + h);
                Value arg_minus = make_float(x - h);
                Value f_plus = call_function_value(args[0], &arg_plus, 1, node);
                Value f_minus = call_function_value(args[0], &arg_minus, 1, node);
                free_value(&arg_plus); free_value(&arg_minus);
                double fp = value_to_double(f_plus);
                double fm = value_to_double(f_minus);
                free_value(&f_plus); free_value(&f_minus);
                result = make_float((fp - fm) / (2 * h));
                break;
            }
            else if (fh == "inte"_h) {
                if (arg_count < 3 || arg_count > 4) kr_error("inte 需要 3 或 4 个参数");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double a = value_to_double(args[1]);
                double b = value_to_double(args[2]);
                int n = (arg_count == 4) ? value_to_int(args[3]) : 100;
                if (n < 1) n = 1;
                double h = (b - a) / n;
                double sum = 0.0;
                for (int i = 0; i <= n; i++) {
                    double x = a + i * h;
                    Value arg = make_float(x);
                    Value fv = call_function_value(args[0], &arg, 1, node);
                    free_value(&arg);
                    double fx = value_to_double(fv);
                    free_value(&fv);
                    if (i == 0 || i == n) sum += fx / 2.0;
                    else sum += fx;
                }
                result = make_float(sum * h);
                break;
            }
            else if (fh == "ab2"_h) {
                if (arg_count < 2 || arg_count > 3) kr_error("ab2 需要 2 或 3 个参数");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double x = value_to_double(args[1]);
                double h = (arg_count == 3) ? value_to_double(args[2]) : 1e-5;
                if (h == 0.0) kr_error("步长不能为零");
                Value arg_plus = make_float(x + h);
                Value arg_minus = make_float(x - h);
                Value arg_center = make_float(x);
                Value f_plus = call_function_value(args[0], &arg_plus, 1, node);
                Value f_center = call_function_value(args[0], &arg_center, 1, node);
                Value f_minus = call_function_value(args[0], &arg_minus, 1, node);
                free_value(&arg_plus); free_value(&arg_minus); free_value(&arg_center);
                double fp = value_to_double(f_plus);
                double fc = value_to_double(f_center);
                double fm = value_to_double(f_minus);
                free_value(&f_plus); free_value(&f_center); free_value(&f_minus);
                result = make_float((fp - 2*fc + fm) / (h * h));
                break;
            }
            else if (fh == "simp"_h) {
                if (arg_count < 3 || arg_count > 4) kr_error("simp 需要 3 或 4 个参数");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double a = value_to_double(args[1]);
                double b = value_to_double(args[2]);
                int n = (arg_count == 4) ? value_to_int(args[3]) : 100;
                if (n % 2) n++;
                if (n < 2) n = 2;
                double h = (b - a) / n;
                double sum = 0.0;
                for (int i = 0; i <= n; i++) {
                    double x = a + i * h;
                    Value arg = make_float(x);
                    Value fv = call_function_value(args[0], &arg, 1, node);
                    free_value(&arg);
                    double fx = value_to_double(fv);
                    free_value(&fv);
                    if (i == 0 || i == n) sum += fx;
                    else if (i % 2 == 1) sum += 4 * fx;
                    else sum += 2 * fx;
                }
                result = make_float(sum * h / 3.0);
                break;
            }
            else if (fh == "grad"_h) {
                if (arg_count < 2) kr_error("grad 需要至少 2 个参数：函数, 点坐标...");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");

                int dim;
                double h = 1e-5;
                // 判断最后一个参数是否为浮点数（步长）
                if (arg_count > 2 && args[arg_count - 1].type == VAL_FLOAT) {
                    h = value_to_double(args[arg_count - 1]);
                    dim = arg_count - 2;
                } else {
                    dim = arg_count - 1;
                }

                if (dim < 1) kr_error("grad 需要至少一个坐标");

                int target_n = args[0].func_val.param_count;
                if (target_n != 1 && target_n != dim)
                    kr_error("目标函数参数个数 (%d) 与点维度 (%d) 不匹配", target_n, dim);

                // 构造点数组（用于旧风格）
                Value point_arr;
                if (target_n == 1) {
                    Value* elems = (Value*)malloc(dim * sizeof(Value));
                    for (int i = 0; i < dim; ++i)
                        elems[i] = copy_value(args[i+1]);
                    point_arr = make_array(elems, dim);
                    free(elems);
                }

                Value* grad_vals = (Value*)malloc(dim * sizeof(Value));
                for (int i = 0; i < dim; ++i) {
                    Value* perturb_plus = (Value*)malloc(dim * sizeof(Value));
                    Value* perturb_minus = (Value*)malloc(dim * sizeof(Value));
                    for (int j = 0; j < dim; ++j) {
                        if (j == i) {
                            double base = value_to_double(args[j+1]);
                            perturb_plus[j] = make_float(base + h);
                            perturb_minus[j] = make_float(base - h);
                        } else {
                            perturb_plus[j] = copy_value(args[j+1]);
                            perturb_minus[j] = copy_value(args[j+1]);
                        }
                    }
                    double fp, fm;
                    if (target_n == 1) {
                        Value plus_arr = make_array(perturb_plus, dim);
                        Value minus_arr = make_array(perturb_minus, dim);
                        Value fplus = call_function_value(args[0], &plus_arr, 1, node);
                        Value fminus = call_function_value(args[0], &minus_arr, 1, node);
                        fp = value_to_double(fplus);
                        fm = value_to_double(fminus);
                        free_value(&plus_arr);
                        free_value(&minus_arr);
                        free_value(&fplus);
                        free_value(&fminus);
                    } else {
                        Value fplus = call_function_value(args[0], perturb_plus, dim, node);
                        Value fminus = call_function_value(args[0], perturb_minus, dim, node);
                        fp = value_to_double(fplus);
                        fm = value_to_double(fminus);
                        free_value(&fplus);
                        free_value(&fminus);
                    }
                    for (int j = 0; j < dim; ++j) {
                        free_value(&perturb_plus[j]);
                        free_value(&perturb_minus[j]);
                    }
                    free(perturb_plus);
                    free(perturb_minus);
                    grad_vals[i] = make_float((fp - fm) / (2 * h));
                }

                result = make_array(grad_vals, dim);
                free(grad_vals);
                if (target_n == 1) free_value(&point_arr);
                break;
            }
            else if (fh == "nullst"_h) {
                if (arg_count < 3 || arg_count > 4) kr_error("nullst 需要 3 或 4 个参数");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double a = value_to_double(args[1]);
                double b = value_to_double(args[2]);
                double tol = (arg_count == 4) ? value_to_double(args[3]) : 1e-7;
                if (tol <= 0) tol = 1e-7;
                auto eval_f = [&](double x) {
                    Value arg = make_float(x);
                    Value fv = call_function_value(args[0], &arg, 1, node);
                    free_value(&arg);
                    double res = value_to_double(fv);
                    free_value(&fv);
                    return res;
                };
                double fa = eval_f(a), fb = eval_f(b);
                if (fa * fb > 0) kr_error("区间端点函数值同号");
                double c;
                int iter = 0;
                while (b - a > tol && iter < 1000) {
                    c = (a + b) / 2.0;
                    double fc = eval_f(c);
                    if (fc == 0.0) break;
                    if (fa * fc < 0) { b = c; fb = fc; }
                    else { a = c; fa = fc; }
                    iter++;
                }
                result = make_float((a + b) / 2.0);
                break;
            }
            else if (fh == "euler"_h) {
                if (arg_count != 5) kr_error("euler 需要 5 个参数：函数, x0, y0, 步长, 步数");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double x0 = value_to_double(args[1]);
                double y0 = value_to_double(args[2]);
                double h  = value_to_double(args[3]);
                int steps = value_to_int(args[4]);
                if (steps < 0) steps = 0;

                int target_n = args[0].func_val.param_count;
                if (target_n != 1 && target_n != 2)
                    kr_error("目标函数必须接受 1 个数组或 2 个独立参数 (x, y)");

                Value* y_values = (Value*)malloc((steps + 1) * sizeof(Value));
                y_values[0] = make_float(y0);
                double x = x0, y = y0;

                for (int i = 0; i < steps; i++) {
                    double slope;
                    if (target_n == 1) {
                        // 传递数组 [x, y]
                        Value elems[2] = {make_float(x), make_float(y)};
                        Value point = make_array(elems, 2);
                        Value fv = call_function_value(args[0], &point, 1, node);
                        free_value(&point);
                        slope = value_to_double(fv);
                        free_value(&fv);
                    } else {
                        // 传递两个参数 (x, y)
                        Value f_args[2] = { make_float(x), make_float(y) };
                        Value fv = call_function_value(args[0], f_args, 2, node);
                        free_value(&f_args[0]);
                        free_value(&f_args[1]);
                        slope = value_to_double(fv);
                        free_value(&fv);
                    }
                    y += h * slope;
                    x += h;
                    y_values[i+1] = make_float(y);
                }

                result = make_array(y_values, steps + 1);
                free(y_values);
                break;
            }
            else if (fh == "pabl"_h) {
                if (arg_count < 3 || arg_count > 4)
                    kr_error("pabl 需要 3 或 4 个参数：函数, 点数组, 变量索引, [步长]");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                if (args[1].type != VAL_ARRAY) kr_error("第二个参数必须是点数组");
                int idx = (int)value_to_ll(args[2]);
                double h = (arg_count == 4) ? value_to_double(args[3]) : 1e-5;
                if (idx < 0 || idx >= args[1].arr_val.length)
                    kr_error("变量索引越界");

                int target_n = args[0].func_val.param_count;
                int dim = args[1].arr_val.length;

                Value point_base = copy_value(args[1]);
                Value point_plus = copy_value(point_base);
                Value point_minus = copy_value(point_base);

                double orig = value_to_double(point_plus.arr_val.elements[idx]);
                point_plus.arr_val.elements[idx] = make_float(orig + h);
                point_minus.arr_val.elements[idx] = make_float(orig - h);

                auto call_target = [&](Value& point) -> double {
                    if (target_n == 1) {
                        Value res = call_function_value(args[0], &point, 1, node);
                        double val = value_to_double(res);
                        free_value(&res);
                        return val;
                    } else if (target_n == dim) {
                        Value* unpacked = (Value*)malloc(dim * sizeof(Value));
                        for (int i = 0; i < dim; ++i)
                            unpacked[i] = copy_value(point.arr_val.elements[i]);
                        Value res = call_function_value(args[0], unpacked, dim, node);
                        for (int i = 0; i < dim; ++i) free_value(&unpacked[i]);
                        free(unpacked);
                        double val = value_to_double(res);
                        free_value(&res);
                        return val;
                    } else {
                        kr_error("目标函数参数个数 (%d) 与点维度 (%d) 不匹配", target_n, dim);
                        return 0.0;
                    }
                };

                double fp = call_target(point_plus);
                double fm = call_target(point_minus);
                result = make_float((fp - fm) / (2 * h));

                free_value(&point_base);
                free_value(&point_plus);
                free_value(&point_minus);
                break;
            }
            else if (fh == "ab3"_h) {   // 三阶导数（中心差分）
                if (arg_count < 2 || arg_count > 3)
                    kr_error("ab3 需要 2 或 3 个参数：函数, x, [步长]");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double x0 = value_to_double(args[1]);
                double h = (arg_count == 3) ? value_to_double(args[2]) : 1e-4;

                Value arg_x2h = make_float(x0 + 2*h);
                Value arg_xh  = make_float(x0 + h);
                Value arg_xmh = make_float(x0 - h);
                Value arg_x2mh= make_float(x0 - 2*h);

                Value f_x2h = call_function_value(args[0], &arg_x2h, 1, node);
                Value f_xh  = call_function_value(args[0], &arg_xh, 1, node);
                Value f_xmh = call_function_value(args[0], &arg_xmh, 1, node);
                Value f_x2mh= call_function_value(args[0], &arg_x2mh, 1, node);

                double val = (value_to_double(f_x2h) - 2*value_to_double(f_xh) + 2*value_to_double(f_xmh) - value_to_double(f_x2mh)) / (2 * h * h * h);
                result = make_float(val);

                free_value(&arg_x2h); free_value(&arg_xh); free_value(&arg_xmh); free_value(&arg_x2mh);
                free_value(&f_x2h); free_value(&f_xh); free_value(&f_xmh); free_value(&f_x2mh);
                break;
            }
            else if (fh == "ab4"_h) {   // 四阶导数（五点公式）
                if (arg_count < 2 || arg_count > 3)
                    kr_error("ab4 需要 2 或 3 个参数：函数, x, [步长]");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");

                // 1. 获取 x0 和 h 的高精度值
                mpf_t x0_mpf, h_mpf;
                mpf_init(x0_mpf);
                mpf_init(h_mpf);
                // 将 x0 转为 mpf_t
                if (args[1].type == VAL_FLOAT) {
                    mpf_set(x0_mpf, *args[1].mpf_val);
                } else if (args[1].type == VAL_INT64) {
                    mpf_set_int64(x0_mpf, args[1].int64_val);
                } else if (args[1].type == VAL_INT) {
                    mpf_set_z(x0_mpf, *args[1].big_int);
                } else {
                    kr_error("x0 必须是数值");
                }
                // 处理步长 h（默认 1e-2）
                if (arg_count == 3) {
                    if (args[2].type == VAL_FLOAT) {
                        mpf_set(h_mpf, *args[2].mpf_val);
                    } else if (args[2].type == VAL_INT64 || args[2].type == VAL_INT) {
                        long long hv = value_to_ll(args[2]);
                        mpf_set_int64(h_mpf, hv);
                    } else {
                        kr_error("步长必须是数值");
                    }
                } else {
                    mpf_set_d(h_mpf, 1e-2);
                }

                // 2. 构造五个求值点：x±h, x±2h
                mpf_t x2h_mpf, xh_mpf, x_mpf, xmh_mpf, x2mh_mpf;
                mpf_init(x2h_mpf); mpf_init(xh_mpf); mpf_init(x_mpf);
                mpf_init(xmh_mpf); mpf_init(x2mh_mpf);

                mpf_set(x_mpf, x0_mpf);
                mpf_add(xh_mpf, x0_mpf, h_mpf);
                mpf_sub(xmh_mpf, x0_mpf, h_mpf);
                mpf_add(x2h_mpf, x0_mpf, h_mpf);
                mpf_add(x2h_mpf, x2h_mpf, h_mpf);          // x0 + 2h
                mpf_sub(x2mh_mpf, x0_mpf, h_mpf);
                mpf_sub(x2mh_mpf, x2mh_mpf, h_mpf);        // x0 - 2h

                // 辅助函数：将 Value 转为 mpf_t（通过输出参数避免返回数组类型）
                auto value_to_mpf = [](const Value& v, mpf_t& out) {
                    mpf_init(out);
                    if (v.type == VAL_FLOAT) {
                        mpf_set(out, *v.mpf_val);
                    } else if (v.type == VAL_INT64) {
                        mpf_set_int64(out, v.int64_val);
                    } else if (v.type == VAL_INT) {
                        mpf_set_z(out, *v.big_int);
                    } else {
                        // 如果返回非数值，尝试字符串转换（极少见）
                        char* s = value_to_string(v);
                        if (mpf_set_str(out, s, 10) != 0) {
                            free(s);
                            mpf_clear(out);
                            kr_error("函数返回值无法转为数值");
                        }
                        free(s);
                    }
                };

                // 3. 计算各点函数值（先构造 Value 参数，再调用）
                Value arg_x2h = make_float(x2h_mpf);
                Value arg_xh  = make_float(xh_mpf);
                Value arg_x   = make_float(x_mpf);
                Value arg_xmh = make_float(xmh_mpf);
                Value arg_x2mh= make_float(x2mh_mpf);

                Value f_x2h_v = call_function_value(args[0], &arg_x2h, 1, node);
                Value f_xh_v  = call_function_value(args[0], &arg_xh, 1, node);
                Value f_x_v   = call_function_value(args[0], &arg_x, 1, node);
                Value f_xmh_v = call_function_value(args[0], &arg_xmh, 1, node);
                Value f_x2mh_v= call_function_value(args[0], &arg_x2mh, 1, node);

                // 释放临时参数
                free_value(&arg_x2h); free_value(&arg_xh); free_value(&arg_x);
                free_value(&arg_xmh); free_value(&arg_x2mh);

                // 将函数返回值转为 mpf_t
                mpf_t f_x2h, f_xh, f_x, f_xmh, f_x2mh;
                value_to_mpf(f_x2h_v, f_x2h);
                value_to_mpf(f_xh_v, f_xh);
                value_to_mpf(f_x_v, f_x);
                value_to_mpf(f_xmh_v, f_xmh);
                value_to_mpf(f_x2mh_v, f_x2mh);

                // 释放函数返回的 Value（call_function_value 返回的是副本）
                free_value(&f_x2h_v); free_value(&f_xh_v); free_value(&f_x_v);
                free_value(&f_xmh_v); free_value(&f_x2mh_v);

                // 4. 高精度计算分子：f(x+2h) - 4f(x+h) + 6f(x) - 4f(x-h) + f(x-2h)
                mpf_t numerator, tmp;
                mpf_init(numerator);
                mpf_init(tmp);
                mpf_set_ui(numerator, 0);

                mpf_add(numerator, numerator, f_x2h);
                mpf_mul_ui(tmp, f_xh, 4);
                mpf_sub(numerator, numerator, tmp);
                mpf_mul_ui(tmp, f_x, 6);
                mpf_add(numerator, numerator, tmp);
                mpf_mul_ui(tmp, f_xmh, 4);
                mpf_sub(numerator, numerator, tmp);
                mpf_add(numerator, numerator, f_x2mh);

                // 5. 计算分母 h^4
                mpf_t h4;
                mpf_init(h4);
                mpf_pow_ui(h4, h_mpf, 4);

                // 6. 相除得结果
                mpf_t result_mpf;
                mpf_init(result_mpf);
                mpf_div(result_mpf, numerator, h4);

                // 7. 构造返回值并清理
                result = make_float(result_mpf);

                // 清理所有 mpf_t
                mpf_clear(x0_mpf); mpf_clear(h_mpf);
                mpf_clear(x2h_mpf); mpf_clear(xh_mpf); mpf_clear(x_mpf);
                mpf_clear(xmh_mpf); mpf_clear(x2mh_mpf);
                mpf_clear(f_x2h); mpf_clear(f_xh); mpf_clear(f_x);
                mpf_clear(f_xmh); mpf_clear(f_x2mh);
                mpf_clear(numerator); mpf_clear(tmp);
                mpf_clear(h4); mpf_clear(result_mpf);

                break;
            }
            else if (fh == "rk"_h) {
                if (arg_count < 5 || arg_count > 6)
                    kr_error("rk 需要 5 或 6 个参数：函数, x0, y0, 步长, 步数, [容差]");
                if (args[0].type != VAL_FUNCTION)
                    kr_error("第一个参数必须是函数");
                double x0 = value_to_double(args[1]);
                double h  = value_to_double(args[3]);
                int n     = (int)value_to_ll(args[4]);
                if (n < 0) kr_error("步数不能为负数");
                double tol = (arg_count == 6) ? value_to_double(args[5]) : 1e-6;
                if (tol <= 0) tol = 1e-6;

                int target_n = args[0].func_val.param_count;
                bool is_vector = (args[2].type == VAL_ARRAY);

                // ---- 导数函数（统一返回 Value，标量也返回数值 Value） ----
                std::function<Value(double, Value&)> deriv_func;
                if (is_vector) {
                    if (target_n != 2)
                        kr_error("向量模式要求函数接受两个参数 (t, y)，其中 y 为数组");
                    deriv_func = [&](double xv, Value& yv) -> Value {
                        Value x_arg = make_float(xv);
                        Value y_arg = copy_value(yv);
                        Value args_arr[2] = { x_arg, y_arg };
                        Value res = call_function_value(args[0], args_arr, 2, node);
                        free_value(&x_arg); free_value(&y_arg);
                        return res;
                    };
                } else {
                    // 标量模式：函数可接受 1 个数组 [t, y] 或 2 个参数 (t, y)
                    deriv_func = [&](double xv, Value& yv) -> Value {
                        double y = value_to_double(yv);
                        if (target_n == 1) {
                            Value elems[2] = { make_float(xv), make_float(y) };
                            Value point = make_array(elems, 2);
                            Value fv = call_function_value(args[0], &point, 1, node);
                            free_value(&point);
                            double res = value_to_double(fv);
                            free_value(&fv);
                            return make_float(res);
                        } else if (target_n == 2) {
                            Value f_args[2] = { make_float(xv), make_float(y) };
                            Value fv = call_function_value(args[0], f_args, 2, node);
                            free_value(&f_args[0]); free_value(&f_args[1]);
                            double res = value_to_double(fv);
                            free_value(&fv);
                            return make_float(res);
                        } else {
                            kr_error("目标函数必须接受 1 个数组或 2 个独立参数 (x, y)");
                            return make_null();
                        }
                    };
                }

                // ---- RKF45 Butcher tableau ----
                const double c2 = 1.0/4.0, c3 = 3.0/8.0, c4 = 12.0/13.0, c5 = 1.0, c6 = 1.0/2.0;
                const double a21 = 1.0/4.0;
                const double a31 = 3.0/32.0, a32 = 9.0/32.0;
                const double a41 = 1932.0/2197.0, a42 = -7200.0/2197.0, a43 = 7296.0/2197.0;
                const double a51 = 439.0/216.0, a52 = -8.0, a53 = 3680.0/513.0, a54 = -845.0/4104.0;
                const double a61 = -8.0/27.0, a62 = 2.0, a63 = -3544.0/2565.0, a64 = 1859.0/4104.0, a65 = -11.0/40.0;
                const double b41 = 25.0/216.0, b43 = 1408.0/2565.0, b44 = 2197.0/4104.0, b45 = -1.0/5.0;
                const double b51 = 16.0/135.0, b53 = 6656.0/12825.0, b54 = 28561.0/56430.0, b55 = -9.0/50.0, b56 = 2.0/55.0;

                // ---- 向量单步函数 ----
                auto rkf45_step_vec = [&](double x, Value& y, double h, Value& y_next, double& error) -> void {
                    int dim = y.arr_val.length;
                    Value k1 = deriv_func(x, y);
                    if (k1.type != VAL_ARRAY || k1.arr_val.length != dim)
                        kr_error("导数必须为数组，长度与状态相同");

                    Value y2 = copy_value(y);
                    for (int i = 0; i < dim; ++i) {
                        double val = value_to_double(y.arr_val.elements[i]) + h * a21 * value_to_double(k1.arr_val.elements[i]);
                        free_value(&y2.arr_val.elements[i]);
                        y2.arr_val.elements[i] = make_float(val);
                    }
                    Value k2 = deriv_func(x + c2 * h, y2);

                    Value y3 = copy_value(y);
                    for (int i = 0; i < dim; ++i) {
                        double val = value_to_double(y.arr_val.elements[i]) +
                                    h * (a31 * value_to_double(k1.arr_val.elements[i]) +
                                        a32 * value_to_double(k2.arr_val.elements[i]));
                        free_value(&y3.arr_val.elements[i]);
                        y3.arr_val.elements[i] = make_float(val);
                    }
                    Value k3 = deriv_func(x + c3 * h, y3);

                    Value y4 = copy_value(y);
                    for (int i = 0; i < dim; ++i) {
                        double val = value_to_double(y.arr_val.elements[i]) +
                                    h * (a41 * value_to_double(k1.arr_val.elements[i]) +
                                        a42 * value_to_double(k2.arr_val.elements[i]) +
                                        a43 * value_to_double(k3.arr_val.elements[i]));
                        free_value(&y4.arr_val.elements[i]);
                        y4.arr_val.elements[i] = make_float(val);
                    }
                    Value k4 = deriv_func(x + c4 * h, y4);

                    Value y5 = copy_value(y);
                    for (int i = 0; i < dim; ++i) {
                        double val = value_to_double(y.arr_val.elements[i]) +
                                    h * (a51 * value_to_double(k1.arr_val.elements[i]) +
                                        a52 * value_to_double(k2.arr_val.elements[i]) +
                                        a53 * value_to_double(k3.arr_val.elements[i]) +
                                        a54 * value_to_double(k4.arr_val.elements[i]));
                        free_value(&y5.arr_val.elements[i]);
                        y5.arr_val.elements[i] = make_float(val);
                    }
                    Value k5 = deriv_func(x + c5 * h, y5);

                    Value y6 = copy_value(y);
                    for (int i = 0; i < dim; ++i) {
                        double val = value_to_double(y.arr_val.elements[i]) +
                                    h * (a61 * value_to_double(k1.arr_val.elements[i]) +
                                        a62 * value_to_double(k2.arr_val.elements[i]) +
                                        a63 * value_to_double(k3.arr_val.elements[i]) +
                                        a64 * value_to_double(k4.arr_val.elements[i]) +
                                        a65 * value_to_double(k5.arr_val.elements[i]));
                        free_value(&y6.arr_val.elements[i]);
                        y6.arr_val.elements[i] = make_float(val);
                    }
                    Value k6 = deriv_func(x + c6 * h, y6);

                    // RK5 结果
                    y_next = copy_value(y);
                    for (int i = 0; i < dim; ++i) {
                        double sum = b51 * value_to_double(k1.arr_val.elements[i]) +
                                    b53 * value_to_double(k3.arr_val.elements[i]) +
                                    b54 * value_to_double(k4.arr_val.elements[i]) +
                                    b55 * value_to_double(k5.arr_val.elements[i]) +
                                    b56 * value_to_double(k6.arr_val.elements[i]);
                        double new_val = value_to_double(y.arr_val.elements[i]) + h * sum;
                        free_value(&y_next.arr_val.elements[i]);
                        y_next.arr_val.elements[i] = make_float(new_val);
                    }

                    // 误差估计 (RK4 - RK5)
                    double max_err = 0.0;
                    for (int i = 0; i < dim; ++i) {
                        double rk4 = value_to_double(y.arr_val.elements[i]) + h * (
                            b41 * value_to_double(k1.arr_val.elements[i]) +
                            b43 * value_to_double(k3.arr_val.elements[i]) +
                            b44 * value_to_double(k4.arr_val.elements[i]) +
                            b45 * value_to_double(k5.arr_val.elements[i])
                        );
                        double rk5 = value_to_double(y_next.arr_val.elements[i]);
                        double err = fabs(rk4 - rk5);
                        if (err > max_err) max_err = err;
                    }
                    error = max_err;

                    // 释放临时
                    free_value(&k1); free_value(&k2); free_value(&k3); free_value(&k4); free_value(&k5); free_value(&k6);
                    free_value(&y2); free_value(&y3); free_value(&y4); free_value(&y5); free_value(&y6);
                };

                // ---- 标量单步函数 ----
                auto rkf45_step_scalar = [&](double x, double y, double h, double& y_next, double& error) -> void {
                    // 将标量包装为 Value 以便调用 deriv_func
                    Value yv = make_float(y);
                    Value k1 = deriv_func(x, yv);
                    free_value(&yv);
                    double k1v = value_to_double(k1);
                    free_value(&k1);

                    Value y2v = make_float(y + h * a21 * k1v);
                    Value k2 = deriv_func(x + c2 * h, y2v);
                    free_value(&y2v);
                    double k2v = value_to_double(k2);
                    free_value(&k2);

                    Value y3v = make_float(y + h * (a31 * k1v + a32 * k2v));
                    Value k3 = deriv_func(x + c3 * h, y3v);
                    free_value(&y3v);
                    double k3v = value_to_double(k3);
                    free_value(&k3);

                    Value y4v = make_float(y + h * (a41 * k1v + a42 * k2v + a43 * k3v));
                    Value k4 = deriv_func(x + c4 * h, y4v);
                    free_value(&y4v);
                    double k4v = value_to_double(k4);
                    free_value(&k4);

                    Value y5v = make_float(y + h * (a51 * k1v + a52 * k2v + a53 * k3v + a54 * k4v));
                    Value k5 = deriv_func(x + c5 * h, y5v);
                    free_value(&y5v);
                    double k5v = value_to_double(k5);
                    free_value(&k5);

                    Value y6v = make_float(y + h * (a61 * k1v + a62 * k2v + a63 * k3v + a64 * k4v + a65 * k5v));
                    Value k6 = deriv_func(x + c6 * h, y6v);
                    free_value(&y6v);
                    double k6v = value_to_double(k6);
                    free_value(&k6);

                    y_next = y + h * (b51 * k1v + b53 * k3v + b54 * k4v + b55 * k5v + b56 * k6v);
                    double y_rk4 = y + h * (b41 * k1v + b43 * k3v + b44 * k4v + b45 * k5v);
                    error = fabs(y_next - y_rk4);
                };

                // ---- 自适应步进（封装向量和标量） ----
                auto adaptive_step = [&](double x_start, Value& y_start, double h_step, double tol) -> Value {
                    double x = x_start;
                    Value y = copy_value(y_start);
                    double h = h_step;
                    double x_end = x_start + h_step;

                    while (fabs(x - x_end) > 1e-15) {
                        if (fabs(h) > fabs(x_end - x)) h = x_end - x;
                        double err;
                        Value y_next;
                        if (is_vector) {
                            rkf45_step_vec(x, y, h, y_next, err);
                        } else {
                            double y_scalar = value_to_double(y);
                            double y_next_scalar;
                            rkf45_step_scalar(x, y_scalar, h, y_next_scalar, err);
                            free_value(&y);
                            y = make_float(y_next_scalar);
                            y_next = make_float(y_next_scalar); // 仅用于保持流程一致，实际 unused
                        }

                        if (err <= tol) {
                            x += h;
                            if (is_vector) {
                                free_value(&y);
                                y = y_next;
                            } else {
                                // y 已更新，释放临时 y_next
                                free_value(&y_next);
                            }
                            // 动态调整步长
                            if (err > 0) {
                                double factor = 0.9 * pow(tol / err, 0.2);
                                if (factor > 4.0) factor = 4.0;
                                h *= factor;
                            } else {
                                h *= 2.0;
                            }
                            if (fabs(h) > fabs(x_end - x)) h = x_end - x;
                        } else {
                            double factor = 0.9 * pow(tol / err, 0.25);
                            if (factor < 0.1) factor = 0.1;
                            h *= factor;
                            if (is_vector) free_value(&y_next);
                            else free_value(&y_next);
                        }
                    }
                    return y;
                };

                // ---- 主循环 ----
                Value y_cur;
                if (is_vector) {
                    y_cur = copy_value(args[2]);
                } else {
                    double y0 = value_to_double(args[2]);
                    y_cur = make_float(y0);
                }
                Value* y_steps = (Value*)malloc((n + 1) * sizeof(Value));
                y_steps[0] = copy_value(y_cur);
                double x = x0;

                for (int step = 0; step < n; ++step) {
                    Value y_next = adaptive_step(x, y_cur, h, tol);
                    x += h;
                    free_value(&y_cur);
                    y_cur = y_next;
                    y_steps[step + 1] = copy_value(y_cur);
                }
                free_value(&y_cur);

                Value result_arr = make_array(y_steps, n + 1);
                for (int i = 0; i <= n; ++i) free_value(&y_steps[i]);
                free(y_steps);
                result = result_arr;
                break;
            }
            else if (fh == "newton"_h) {   // 牛顿法求根（中心差分，步长自适应）
                if (arg_count < 2 || arg_count > 4)
                    kr_error("newton 需要 2~4 个参数：函数, 初始值, [容差], [最大迭代]");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double x = value_to_double(args[1]);
                double tol = (arg_count >= 3) ? value_to_double(args[2]) : 1e-7;
                int max_iter = (arg_count >= 4) ? (int)value_to_ll(args[3]) : 100;
                double h = 1e-5;   // 中心差分步长，较之前增大一个数量级
                for (int iter = 0; iter < max_iter; ++iter) {
                    Value arg_x = make_float(x);
                    Value f_x = call_function_value(args[0], &arg_x, 1, node);
                    free_value(&arg_x);
                    double fx = value_to_double(f_x);
                    free_value(&f_x);
                    if (fabs(fx) < tol) break;

                    // 中心差分求导数
                    Value arg_xp = make_float(x + h);
                    Value arg_xm = make_float(x - h);
                    Value f_xp = call_function_value(args[0], &arg_xp, 1, node);
                    Value f_xm = call_function_value(args[0], &arg_xm, 1, node);
                    free_value(&arg_xp); free_value(&arg_xm);
                    double fp = value_to_double(f_xp);
                    double fm = value_to_double(f_xm);
                    free_value(&f_xp); free_value(&f_xm);
                    double df = (fp - fm) / (2 * h);
                    if (fabs(df) < 1e-10) kr_error("导数接近零，牛顿法无法收敛");
                    x = x - fx / df;
                }
                result = make_float(x);
                break;
            }
            else if (fh == "gradab"_h) {
                if (arg_count != 4) kr_error("gradab 需要 4 个参数：函数, 起始点数组, 学习率, 迭代次数");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                if (args[1].type != VAL_ARRAY) kr_error("第二个参数必须是点数组");
                int dim = args[1].arr_val.length;
                if (dim == 0) kr_error("起始点不能为空");
                double lr = value_to_double(args[2]);
                int iter = (int)value_to_ll(args[3]);
                if (iter < 0) kr_error("迭代次数不能为负数");

                int target_n = args[0].func_val.param_count;
                if (target_n != 1 && target_n != dim)
                    kr_error("目标函数参数个数 (%d) 与点维度 (%d) 不匹配", target_n, dim);

                Value point = copy_value(args[1]);   // 深拷贝
                double h = 1e-5;

                for (int it = 0; it < iter; ++it) {
                    // 计算梯度
                    Value* grad_vals = (Value*)malloc(dim * sizeof(Value));
                    for (int i = 0; i < dim; ++i) {
                        // 扰动点
                        Value point_plus = copy_value(point);
                        Value point_minus = copy_value(point);
                        double orig = value_to_double(point.arr_val.elements[i]);
                        point_plus.arr_val.elements[i] = make_float(orig + h);
                        point_minus.arr_val.elements[i] = make_float(orig - h);

                        auto eval = [&](Value& pt) -> double {
                            if (target_n == 1) {
                                Value res = call_function_value(args[0], &pt, 1, node);
                                double v = value_to_double(res);
                                free_value(&res);
                                return v;
                            } else {
                                // 解包
                                Value* unpacked = (Value*)malloc(dim * sizeof(Value));
                                for (int j = 0; j < dim; ++j)
                                    unpacked[j] = copy_value(pt.arr_val.elements[j]);
                                Value res = call_function_value(args[0], unpacked, dim, node);
                                for (int j = 0; j < dim; ++j) free_value(&unpacked[j]);
                                free(unpacked);
                                double v = value_to_double(res);
                                free_value(&res);
                                return v;
                            }
                        };

                        double fp = eval(point_plus);
                        double fm = eval(point_minus);
                        grad_vals[i] = make_float((fp - fm) / (2 * h));

                        free_value(&point_plus);
                        free_value(&point_minus);
                    }

                    // 更新点
                    for (int i = 0; i < dim; ++i) {
                        double new_val = value_to_double(point.arr_val.elements[i]) - lr * value_to_double(grad_vals[i]);
                        free_value(&point.arr_val.elements[i]);
                        point.arr_val.elements[i] = make_float(new_val);
                        free_value(&grad_vals[i]);
                    }
                    free(grad_vals);
                }

                result = point;
                break;
            }
            else if (fh == "kquad"_h) {
                if (arg_count != 2) kr_error("kquad 需要 2 个参数：数据点数组, 多项式次数");
                if (args[0].type != VAL_ARRAY) kr_error("第一个参数必须是数据点数组");
                if (args[1].type != VAL_INT && args[1].type != VAL_INT64) kr_error("第二个参数必须是整数（多项式次数）");
                int grado = (int)value_to_ll(args[1]);
                if (grado < 0) kr_error("多项式次数不能为负数");
                int n = args[0].arr_val.length;
                if (n < grado + 1) kr_error("数据点数量必须大于多项式次数");
                
                std::vector<double> xs, ys;
                xs.reserve(n); ys.reserve(n);
                for (int i = 0; i < n; ++i) {
                    Value pt = args[0].arr_val.elements[i];
                    if (pt.type != VAL_OBJECT) kr_error("每个数据点必须是对象");
                    double x = 0, y = 0;
                    bool found_x = false, found_y = false;
                    for (int j = 0; j < pt.obj_val.count; ++j) {
                        if (strcmp(pt.obj_val.entries[j].key, "x") == 0) {
                            x = value_to_double(pt.obj_val.entries[j].value);
                            found_x = true;
                        } else if (strcmp(pt.obj_val.entries[j].key, "y") == 0) {
                            y = value_to_double(pt.obj_val.entries[j].value);
                            found_y = true;
                        }
                    }
                    if (!found_x || !found_y) kr_error("每个数据点必须包含 'x' 和 'y' 字段");
                    xs.push_back(x);
                    ys.push_back(y);
                }

                int m = grado + 1;
                std::vector<std::vector<double>> A(m, std::vector<double>(m, 0.0));
                std::vector<double> b(m, 0.0);

                for (int i = 0; i < n; ++i) {
                    double xi = xs[i], yi = ys[i];
                    // 预计算所有幂次 xi^0 .. xi^(2*m-1)
                    std::vector<double> pow(2 * m);
                    pow[0] = 1.0;
                    for (int p = 1; p < 2 * m; ++p) pow[p] = pow[p - 1] * xi;
                    for (int j = 0; j < m; ++j) {
                        b[j] += yi * pow[j];
                        for (int k = 0; k < m; ++k) {
                            A[j][k] += pow[j + k];   // 正确：xi^(j+k)
                        }
                    }
                }

                // 高斯消元（保持不变）
                for (int col = 0; col < m; ++col) {
                    int pivot = col;
                    while (pivot < m && fabs(A[pivot][col]) < 1e-12) pivot++;
                    if (pivot == m) kr_error("法矩阵奇异，无法拟合");
                    if (pivot != col) {
                        std::swap(A[col], A[pivot]);
                        std::swap(b[col], b[pivot]);
                    }
                    double piv = A[col][col];
                    for (int j = col; j < m; ++j) A[col][j] /= piv;
                    b[col] /= piv;
                    for (int row = 0; row < m; ++row) {
                        if (row == col) continue;
                        double factor = A[row][col];
                        for (int j = col; j < m; ++j) A[row][j] -= factor * A[col][j];
                        b[row] -= factor * b[col];
                    }
                }

                Value* coeffs = (Value*)malloc(m * sizeof(Value));
                for (int i = 0; i < m; ++i) coeffs[i] = make_float(b[i]);
                result = make_array(coeffs, m);
                free(coeffs);
                break;
            }
            else if (fh == "gauss"_h) {   // 高斯-勒让德数值积分
                if (arg_count != 4)
                    kr_error("gauss 需要 4 个参数：函数, a, b, 节点数 (2,4,8,16)");
                if (args[0].type != VAL_FUNCTION) kr_error("第一个参数必须是函数");
                double a = value_to_double(args[1]);
                double b = value_to_double(args[2]);
                int n = (int)value_to_ll(args[3]);
                // 预定义勒让德节点和权重 (仅支持 n=2,4,8,16)
                std::vector<std::pair<double,double>> nodes;
                if (n == 2) {
                    nodes = { {-0.5773502691896257, 1.0}, {0.5773502691896257, 1.0} };
                } else if (n == 4) {
                    nodes = { {-0.8611363115940526, 0.3478548451374538}, {-0.3399810435848563, 0.6521451548625461},
                            {0.3399810435848563, 0.6521451548625461}, {0.8611363115940526, 0.3478548451374538} };
                } else if (n == 8) {
                    nodes = { {-0.9602898564975363, 0.1012285362903763}, {-0.7966664774136267, 0.2223810344533745},
                            {-0.5255324099163290, 0.3137066458778873}, {-0.1834346424956498, 0.3626837833783620},
                            {0.1834346424956498, 0.3626837833783620}, {0.5255324099163290, 0.3137066458778873},
                            {0.7966664774136267, 0.2223810344533745}, {0.9602898564975363, 0.1012285362903763} };
                } else if (n == 16) {
                    // 16点节点和权重（省略完整列表，可临时定义）
                    // 为简化，此处仅作示意，实际可查表
                    kr_error("gauss 暂不支持 16 点，请使用 2,4,8");
                    // 若需支持，可在此添加完整16点表
                } else {
                    kr_error("gauss 节点数仅支持 2, 4, 8");
                }
                double half = (b - a) / 2.0;
                double mid  = (a + b) / 2.0;
                double sum = 0.0;
                for (auto &p : nodes) {
                    double t = p.first;
                    double w = p.second;
                    double x = mid + half * t;
                    Value arg = make_float(x);
                    Value fv = call_function_value(args[0], &arg, 1, node);
                    free_value(&arg);
                    sum += w * value_to_double(fv);
                    free_value(&fv);
                }
                result = make_float(sum * half);
                break;
            }
            else if (fh == "exp"_h) {
                if (arg_count != 1) kr_error("exp 需要 1 个参数");
                double x = value_to_double(args[0]);
                result = make_float(exp(x));
                break;
            }
            else if (fh == "ln"_h) {
                if (arg_count != 1) kr_error("ln 需要 1 个参数");
                double x = value_to_double(args[0]);
                if (x <= 0) kr_error("ln 的定义域为 x > 0");
                result = make_float(log(x));
                break;
            }
            else if (fh == "log"_h || fh == "lg"_h) {
                if (arg_count != 1) kr_error("log/lg 需要 1 个参数");
                double x = value_to_double(args[0]);
                if (x <= 0) kr_error("log/lg 的定义域为 x > 0");
                result = make_float(log10(x));
                break;
            }
            else if (fh == "ld"_h) {
                if (arg_count != 1) kr_error("ld 需要 1 个参数");
                double x = value_to_double(args[0]);
                if (x <= 0) kr_error("ld 的定义域为 x > 0");
                result = make_float(log2(x));
                break;
            }

            // ---- umf: 获取命名作用域的所有变量 ----
            else if (fh == "umf"_h) {
                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                if (arg_count != 1) kr_error("umf 需要 1 个参数（作用域名称字符串）");
                if (args[0].type != VAL_STRING) kr_error("umf 参数必须是字符串");
                std::string scope_name = args[0].str_val;
                auto it = named_scopes.find(scope_name);
                if (it == named_scopes.end()) kr_error("未找到命名作用域 '%s'", scope_name.c_str());
                Scope* ns = it->second;

                // 收集作用域链上所有变量（从 ns 向上直到全局作用域），子作用域覆盖父作用域同名变量
                std::unordered_map<std::string, Variable*> var_map;
                Scope* cur = ns;
                while (cur && cur != original_global_scope) {
                    for (int i = 0; i < cur->var_count; i++) {
                        var_map[cur->vars[i].name] = &cur->vars[i];
                    }
                    cur = cur->parent;
                }

                // 构建对象条目
                ObjectEntry* entries = (ObjectEntry*)malloc(var_map.size() * sizeof(ObjectEntry));
                int idx = 0;
                for (auto& pair : var_map) {
                    Variable* var = pair.second;
                    // 解析别名
                    if (var->is_alias) var = resolve_alias(var);
                    // 处理惰性变量
                    Value val;
                    if (var->is_lazy) {
                        if (!var->evaluated) {
                            Value v = eval_expr(var->init_expr);
                            var->cached_value = copy_value(v);
                            var->evaluated = true;
                            free_value(&v);
                        }
                        val = copy_value(var->cached_value);
                    } else {
                        val = copy_value(var->value);
                    }
                    entries[idx].key = strdup(pair.first.c_str());
                    entries[idx].value = val;
                    idx++;
                }
                Value obj = make_object(entries, idx);
                // 释放临时 entries（make_object 已深拷贝）
                for (int i = 0; i < idx; i++) {
                    free(entries[i].key);
                    free_value(&entries[i].value);
                }
                free(entries);
                result = obj;
                break;
            }

            // 4. 字符串函数（作为全局函数）
            else if (fh == "trim"_h) {
                if (arg_count != 1) kr_error("trim 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
                result = method_trim(args[0], NULL, 0);
                break;
            }
            else if (fh == "ersetze"_h || fh == "ers"_h) {
                if (arg_count != 3) kr_error("ersetze/ers 需要 3 个参数");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                ASTNode** method_args = node->data.func_call.args + 1;
                int method_arg_count = 2;
                result = method_ersetze(args[0], method_args, method_arg_count);
                break;
            }
            else if (fh == "teil"_h) {
                if (arg_count != 2) kr_error("teil 需要 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                ASTNode** method_args = node->data.func_call.args + 1;
                int method_arg_count = 1;
                result = method_teile(args[0], method_args, method_arg_count);
                break;
            }
            else if (fh == "enthält"_h || fh == "hat"_h) {
                if (arg_count != 2) kr_error("enthält/hat 需要 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                ASTNode** method_args = node->data.func_call.args + 1;
                int method_arg_count = 1;
                result = method_enthaelt(args[0], method_args, method_arg_count);
                break;
            }
            else if (fh == "fängtAnMit"_h || fh == "beg"_h) {
                if (arg_count != 2) kr_error("fängtAnMit/beg 需要 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                ASTNode** method_args = node->data.func_call.args + 1;
                int method_arg_count = 1;
                result = method_faengtAnMit(args[0], method_args, method_arg_count);
                break;
            }
            else if (fh == "abschnitt"_h || fh == "ab"_h) {
                if (arg_count < 2 || arg_count > 3)
                    kr_error("abschnitt/ab 需要 2 或 3 个参数（字符串, 起始, [结束]）");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                ASTNode** method_args = node->data.func_call.args + 1;
                int method_arg_count = arg_count - 1;   // 2 个参数时传给方法 1 个参数，相当于 [x:]
                result = method_abschnitt(args[0], method_args, method_arg_count);
                break;
            }
            else if (fh == "stelleVon"_h || fh == "wo"_h) {
                if (arg_count != 2) kr_error("stelleVon/wo 需要 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                ASTNode** method_args = node->data.func_call.args + 1;
                int method_arg_count = 1;
                result = method_stelleVon(args[0], method_args, method_arg_count);
                break;
            }
            else if (fh == "letzteStelleVon"_h || fh == "letzt"_h) {
                if (arg_count != 2) kr_error("letzteStelleVon/letzt 需要 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                ASTNode** method_args = node->data.func_call.args + 1;
                int method_arg_count = 1;
                result = method_letzteStelleVon(args[0], method_args, method_arg_count);
                break;
            }
            else if (fh == "alsZahl"_h || fh == "alz"_h) {
                if (arg_count < 1) kr_error("alsZahl/alz 至少需要 1 个参数");
                result = method_alsZahl(args[0], node->data.func_call.args + 1, arg_count - 1);
            }
            else if (fh == "alsText"_h || fh == "alt"_h) {
                if (arg_count != 1) kr_error("alsText/alt 需要 1 个参数");
                // 支持数字或字符串
                result = method_alsText(args[0], NULL, 0);
                break;
            }
            else if (fh == "groß"_h) {
                if (arg_count != 1) {
                    kr_error("groß 需要 1 个参数");
                }
                if (args[0].type != VAL_STRING) {
                    kr_error("参数必须是字符串");
                }
                result = method_toUpper(args[0], NULL, 0);
            }
            else if (fh == "format"_h) {
                if (arg_count < 1) kr_error("format 至少需要一个格式字符串");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是格式字符串");

                // 检查是否包含未转义的 '%'
                bool has_old_percent = false;
                const char* fmt = args[0].str_val;
                for (const char* p = fmt; *p; ++p) {
                    if (*p == '\\' && *(p+1) == '%') { ++p; continue; }
                    if (*p == '%') { has_old_percent = true; break; }
                }

                if (!has_old_percent) {
                    // 新格式：直接调用 format_value_new
                    if (arg_count < 2) kr_error("format: 新语法需要至少一个值参数");
                    Value val = copy_value(args[1]);
                    Value formatted = format_value_new(val, std::string(fmt));
                    free_value(&val);
                    result = formatted;
                    break;
                }

                // ---- 旧格式处理（含 %） ----
                std::string output;
                const char* fmt_str = args[0].str_val;
                int arg_idx = 0;
                int total_args = arg_count - 1;

                while (*fmt_str) {
                    if (*fmt_str == '%') {
                        fmt_str++;
                        if (*fmt_str == '%') { output += '%'; fmt_str++; continue; }

                        // ---- 解析格式说明符 ----
                        int base = 10;
                        bool zero_pad = false;
                        int width = 0;
                        char sep_char = '\0';
                        int precision = -1;
                        RoundingMode mode = ROUND_HALF_UP;

                        // 1) 检查 '0' 填充标记
                        if (*fmt_str == '0') {
                            zero_pad = true;
                            fmt_str++;
                        }

                        // 2) 读取宽度数字（如果存在）
                        if (isdigit(*fmt_str)) {
                            width = 0;
                            while (isdigit(*fmt_str)) {
                                width = width * 10 + (*fmt_str - '0');
                                fmt_str++;
                            }
                        }

                        // 3) 读取分隔符（可选）
                        if (*fmt_str && !isdigit(*fmt_str) && !isalpha(*fmt_str) && *fmt_str != '.') {
                            sep_char = *fmt_str;
                            fmt_str++;
                        }

                        // 4) 读取精度（. 后数字）
                        if (*fmt_str == '.') {
                            fmt_str++;
                            precision = 0;
                            while (isdigit(*fmt_str)) {
                                precision = precision * 10 + (*fmt_str - '0');
                                fmt_str++;
                            }
                            // 如果点后无数字，精度视为0
                        }

                        // 5) 读取类型字符
                        char type = *fmt_str;
                        fmt_str++; // 跳过类型

                        // 6) 对于整数类型，之前读取的数字应作为进制，而不是宽度
                        if (type == 'z' || type == 'd' || type == 'x' || type == 'X') {
                            // 整数类型：宽度应忽略（由新格式处理），这里将 width 作为进制
                            if (width > 0) {
                                base = width;
                                width = 0;  // 宽度置0，不应用宽度填充
                            }
                            // 零填充对整数类型无效（新格式才支持）
                            zero_pad = false;
                        }

                        // 7) 检查舍入模式（仅对 k/w 有效）
                        if (type == 'k' || type == 'w') {
                            if (*fmt_str == '^') { mode = ROUND_CEIL; fmt_str++; }
                            else if (*fmt_str == '_') { mode = ROUND_FLOOR; fmt_str++; }
                        }

                        // ---- 获取参数值 ----
                        if (arg_idx >= total_args) kr_error("format: 缺少对应参数");
                        Value v = copy_value(args[arg_idx + 1]);
                        arg_idx++;

                        std::string part;

                        // ---- 根据类型格式化 ----
                        if (type == 'z' || type == 'd' || type == 'x' || type == 'X') {
                            mpz_t num;
                            mpz_init(num);
                            if (v.type == VAL_FLOAT) {
                                mpf_t tmp;
                                mpf_init(tmp);
                                mpf_set(tmp, *v.mpf_val);
                                mpz_set_f(num, tmp);
                                mpf_clear(tmp);
                            } else if (v.type == VAL_INT || v.type == VAL_INT64) {
                                mpz_set(num, *v.big_int);
                            } else {
                                kr_error("format: 整数格式需要整数或浮点数参数");
                            }
                            int radix = (type == 'z') ? base : (type == 'x' || type == 'X') ? 16 : 10;
                            char* s = mpz_get_str(NULL, radix, num);
                            std::string num_str = s;
                            free(s);
                            mpz_clear(num);
                            free_value(&v);
                            if (type == 'X') {
                                for (char& c : num_str) if (c >= 'a' && c <= 'f') c = c - 'a' + 'A';
                            }
                            // 整数格式不应用宽度（宽度已被当作进制）
                            part = num_str;
                        }
                        else if (type == 'k' || type == 'w') {
                            if (v.type != VAL_INT && v.type != VAL_FLOAT) kr_error("format: %%k/%%w 需要整数或浮点数参数");
                            mpf_t tmp;
                            mpf_init(tmp);
                            if (v.type == VAL_INT || v.type == VAL_INT64) mpf_set_z(tmp, *v.big_int);
                            else mpf_set(tmp, *v.mpf_val);
                            part = ::format_mpf_decimal(tmp, precision, sep_char, mode);
                            mpf_clear(tmp);
                            free_value(&v);
                            // 应用宽度填充
                            part = apply_width(part, width, zero_pad);
                        }
                        else if (type == 'e') {
                            if (v.type != VAL_INT && v.type != VAL_FLOAT) kr_error("format: %%e 需要整数或浮点数参数");
                            mpf_t tmp;
                            mpf_init(tmp);
                            if (v.type == VAL_INT || v.type == VAL_INT64) mpf_set_z(tmp, *v.big_int);
                            else mpf_set(tmp, *v.mpf_val);
                            // 使用 format_mpf_decimal 生成科学计数法？
                            // 但 format_mpf_decimal 目前只支持小数，我们需要单独处理科学计数法
                            // 这里沿用原始代码的科学计数法生成方式，但应用宽度
                            int digits = (precision >= 0) ? precision + 1 : 7;
                            if (digits < 1) digits = 1;
                            mp_exp_t exp;
                            char* mant = mpf_get_str(NULL, &exp, 10, digits, tmp);
                            mpf_clear(tmp);
                            bool neg = false;
                            if (mant[0] == '-') { neg = true; ++mant; }
                            int len = strlen(mant);
                            int real_exp = exp - 1;
                            std::string part_str = (neg ? "-" : "") + std::string(1, mant[0]);
                            if (len > 1) {
                                part_str += ".";
                                part_str.append(mant + 1, len - 1);
                                if (precision >= 0 && (len - 1) < precision) {
                                    part_str.append(precision - (len - 1), '0');
                                }
                            } else if (precision > 0) {
                                part_str += ".";
                                part_str.append(precision, '0');
                            }
                            std::ostringstream oss;
                            oss << (real_exp >= 0 ? "+" : "-") << std::setw(2) << std::setfill('0') << abs(real_exp);
                            part_str += 'e' + oss.str();
                            free(mant - (neg ? 1 : 0));
                            free_value(&v);
                            part = apply_width(part_str, width, zero_pad);
                        }
                        else if (type == 't') {
                            char* s = value_to_string(v);
                            part = s;
                            free(s);
                            free_value(&v);
                            part = apply_width(part, width, zero_pad);
                        }
                        else if (type == '%') {
                            if (v.type != VAL_INT && v.type != VAL_FLOAT)
                                kr_error("format: %% 需要整数或浮点数参数");
                            mpf_t tmp;
                            mpf_init(tmp);
                            if (v.type == VAL_INT || v.type == VAL_INT64) mpf_set_z(tmp, *v.big_int);
                            else mpf_set(tmp, *v.mpf_val);
                            mpf_mul_ui(tmp, tmp, 100);
                            part = ::format_mpf_decimal(tmp, (precision >= 0) ? precision : 0, sep_char, mode);
                            mpf_clear(tmp);
                            free_value(&v);
                            part += '%';
                            part = apply_width(part, width, zero_pad);
                        }
                        else {
                            kr_error("format: 不支持的格式类型 '%c'", type);
                        }
                        output += part;
                    } else if (*fmt_str == '\\' && *(fmt_str+1) == '%') {
                        output += '%';
                        fmt_str += 2;
                    } else {
                        output += *fmt_str;
                        fmt_str++;
                    }
                }

                if (arg_idx < total_args) {
                    kr_warn("format: 存在未使用的参数");
                }

                result = make_string(output.c_str());
                break;
            }
            else if (fh == "schrd"_h) {
                if (arg_count != 2) kr_error("schrd 需要 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("文件名必须是字符串");

                FILE* fp = fopen(args[0].str_val, "wb");
                if (!fp) kr_error("无法写入文件 '%s'", args[0].str_val);

                if (args[1].type == VAL_ARRAY) {
                    Value& arr = args[1];
                    std::string buf;
                    buf.reserve((size_t)arr.arr_val.length);
                    for (long long i = 0; i < arr.arr_val.length; ++i) {
                        Value& elem = arr.arr_val.elements[i];
                        if (elem.type != VAL_INT && elem.type != VAL_INT64) {
                            fclose(fp);
                            kr_error("schrd: 数组元素 %lld 不是整数（字节值 0-255）", i);
                        }
                        long long byte = value_to_ll(elem);
                        if (byte < 0 || byte > 255) {
                            fclose(fp);
                            kr_error("schrd: 数组元素 %lld 的字节值 %lld 超出 0-255", i, byte);
                        }
                        buf.push_back((char)(unsigned char)byte);
                    }
                    if (!buf.empty())
                        fwrite(buf.data(), 1, buf.size(), fp);
                } else {
                    std::string content = value_to_stdstring(args[1]);
                    if (!content.empty())
                        fwrite(content.data(), 1, content.size(), fp);
                }

                fclose(fp);
                result = make_null();
                break;
            }

            else if (fh == "zeigIn"_h || fh == "schrIn"_h) {
                bool add_newline = (fh == "zeigIn"_h);
                if (arg_count < 1) {
                    kr_error("%s 需要至少 1 个参数（流选择符 stderg 或 stdfehl）", fname);
                }
                // 解析第一个参数：流选择符
                Value& stream_val = args[0];
                long long stream_id = -1;
                if (stream_val.type == VAL_INT64) {
                    stream_id = stream_val.int64_val;
                } else if (stream_val.type == VAL_INT) {
                    if (mpz_fits_slong_p(*stream_val.big_int))
                        stream_id = mpz_get_si(*stream_val.big_int);
                } else if (stream_val.type == VAL_STRING) {
                    // 允许直接传字符串 "stdout" / "stderr" 作为兼容
                    if (strcmp(stream_val.str_val, "stdout") == 0) stream_id = 0;
                    else if (strcmp(stream_val.str_val, "stderr") == 0) stream_id = 1;
                }
                if (stream_id != 0 && stream_id != 1) {
                    kr_error("%s: 第一个参数必须是 stderg (stdout) 或 stdfehl (stderr)", fname);
                }
                std::ostream& os = (stream_id == 1) ? std::cerr : std::cout;
                for (int i = 1; i < arg_count; ++i) {
                    Value& v = args[i];
                    switch (v.type) {
                        case VAL_INT64:
                            os << v.int64_val;
                            break;
                        case VAL_STRING:
                            os.write(v.str_val, v.str_len);
                            break;
                        case VAL_INT: {
                            char* s = mpz_get_str(nullptr, 10, *v.big_int);
                            os << s;
                            free(s);
                            break;
                        }
                        case VAL_FLOAT:
                            os << mpf_get_d(*v.mpf_val);
                            break;
                        case VAL_NULL:
                            os << "null";
                            break;
                        default: {
                            char* s = value_to_string(v);
                            os << s;
                            free(s);
                            break;
                        }
                    }
                }
                if (add_newline) os << '\n';
                os.flush();   // stderr 通常是行缓冲/无缓冲，此调用确保立即可被外部捕获
                result = make_null();
                break;
            }

            // 5. 系统函数：sleep, zeit, datum, loesch, aktu, zeigAlle
            else if (fh == "sleep"_h) {
                if (arg_count != 1) kr_error("sleep 需要 1 个参数");
                int ms = value_to_int(args[0]);
                std::this_thread::sleep_for(std::chrono::milliseconds(ms));
                result = make_null();
                break;
            }
            else if (fh == "zeit"_h) {
                if (arg_count != 0) kr_error("zeit 不需要参数");
                result = make_int((long long)time(NULL));
                break;
            }
            else if (fh == "zeit_us"_h) {
                if (arg_count != 0) kr_error("zeit_us 不需要参数");
                auto now = std::chrono::system_clock::now().time_since_epoch();
                auto us = std::chrono::duration_cast<std::chrono::microseconds>(now).count();
                result = make_int(us);
                break;
            }
            else if (fh == "zeit_ms"_h) {
                if (arg_count != 0) kr_error("zeit_ms 不需要参数");
                auto now = std::chrono::system_clock::now().time_since_epoch();
                auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
                result = make_int(ms);
                break;
            }
            else if (fh == "zeit_ns"_h) {
                if (arg_count != 0) kr_error("zeit_ns 不需要参数");
                auto now = std::chrono::system_clock::now().time_since_epoch();
                auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();
                result = make_int(ns);
                break;
            }
            else if (fh == "tick"_h) {
                if (arg_count != 0) kr_error("tick 不需要参数");
                g_tick_time = std::chrono::steady_clock::now();
                g_tick_set = true;
                result = make_null();
                break;
            }
            else if (fh == "tock"_h) {
                if (arg_count != 0) kr_error("tock 不需要参数");
                if (!g_tick_set) kr_error("请先调用 tick");
                auto now = std::chrono::steady_clock::now();
                auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(now - g_tick_time).count();
                result = make_int(elapsed);
                break;
            }
            else if (fh == "tock_ms"_h) {
                if (arg_count != 0) kr_error("tock_ms 不需要参数");
                if (!g_tick_set) kr_error("请先调用 tick");
                auto now = std::chrono::steady_clock::now();
                auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - g_tick_time).count();
                result = make_int(elapsed);
                break;
            }
            else if (fh == "tock_s"_h) {
                if (arg_count != 0) kr_error("tock_s 不需要参数");
                if (!g_tick_set) kr_error("请先调用 tick");
                auto now = std::chrono::steady_clock::now();
                std::chrono::duration<double> elapsed = now - g_tick_time;
                result = make_float(elapsed.count());
                break;
            }
            else if (fh == "datum"_h) {
                if (arg_count != 0) kr_error("datum 不需要参数");
                time_t t = time(NULL);
                struct tm* tm_info = localtime(&t);
                char buffer[64];
                strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_info);
                result = make_string(buffer);
                break;
            }
            else if (fh == "loesch"_h) {
                if (arg_count == 0) {
                    auto it = print_lines.find(current_scope->id);
                    if (it != print_lines.end()) it->second.clear();
                    result = make_null();
                } else if (arg_count == 1) {
                    int line = value_to_int(args[0]);
                    auto it = print_lines.find(current_scope->id);
                    if (it != print_lines.end()) it->second.erase(line);
                    result = make_null();
                } else kr_error("loesch 接受 0 或 1 个参数");
                break;
            }
            else if (fh == "aktu"_h) {
                if (arg_count < 1 || arg_count > 3) kr_error("aktu 需要 1 到 3 个参数");
                char* str = value_to_string(args[0]);
                bool has_line = false;
                int line = -1;
                std::string option;
                bool auto_hide = false;
                if (arg_count >= 2) {
                    if (args[1].type == VAL_INT || args[1].type == VAL_INT64) {
                        has_line = true;
                        line = value_to_int(args[1]);
                        if (arg_count == 3) {
                            if (args[2].type != VAL_STRING) kr_error("第三个参数必须是字符串");
                            option = args[2].str_val;
                        }
                    } else if (args[1].type == VAL_STRING) {
                        if (arg_count != 2) kr_error("如果第二个参数是选项，则只能有两个参数");
                        option = args[1].str_val;
                    } else kr_error("第二个参数必须是整数或字符串");
                }
                if (!option.empty()) {
                    if (option == "verstecken" || option == "v") { printf("\033[?25l"); fflush(stdout); }
                    else if (option == "anzeigen" || option == "a") { printf("\033[?25h"); fflush(stdout); }
                    else if (option == "auto" || option == "t" || option == "temporaer") auto_hide = true;
                    else kr_error("未知选项: %s", option.c_str());
                }
                if (auto_hide) { printf("\033[?25l"); fflush(stdout); }
                if (has_line) {
                    int ansi_line = line + 1;   // 终端从 1 开始
                    printf("\033[%d;0H", ansi_line);
                    printf("\033[K%s\033[K", str);
                    fflush(stdout);
                    print_lines[current_scope->id][line] = std::string(str);  // 存储仍用 line（0-based）
                } else {
                    printf("\r%s", str);
                    fflush(stdout);
                }
                if (auto_hide) { printf("\033[?25h"); fflush(stdout); }
                free(str);
                result = make_null();
                break;
            }
            else if (fh == "zeigAlle"_h) {
                if (arg_count > 3) kr_error("zeigAlle 最多接受 3 个参数");
                bool show_line_num = false, clear_first = false;
                for (int i = 0; i < arg_count; i++) {
                    if (args[i].type != VAL_STRING) kr_error("参数必须为字符串");
                    std::string opt = args[i].str_val;
                    if (opt == "klar" || opt == "k") clear_first = true;
                    else if (opt == "z") show_line_num = true;
                    else if (opt == "global") { /* ignore */ }
                    else kr_error("未知参数: %s", opt.c_str());
                }
                if (clear_first) { printf("\033[2J\033[H"); fflush(stdout); }
                auto it = print_lines.find(current_scope->id);
                if (it != print_lines.end()) {
                    std::vector<int> keys;
                    for (auto& p : it->second) keys.push_back(p.first);
                    std::sort(keys.begin(), keys.end());
                    for (int key : keys) {
                        if (show_line_num) 
                            printf("%d: %s\n", key + 1, it->second[key].c_str());   // 打印时 +1
                        else
                            printf("%s\n", it->second[key].c_str());
                    }
                }
                result = make_null();
                break;
            }

            // 6. 按键相关：drücke, taste, ac_taste, taste_gedrueckt
            else if (fh == "drücke"_h) {
                if (arg_count != 1) kr_error("drücke 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
                std::string key = normalize_key_string(args[0].str_val);
                auto it = key_bind_map.find(key);
                if (it == key_bind_map.end()) { result = make_null(); break; }
                ASTNode* body = it->second.first;
                Scope* captured = it->second.second;
                bool old_return = return_caught;
                Value old_return_val = return_value;
                bool old_break = break_caught, old_continue = continue_caught;
                bool old_exception = exception_raised;
                Value old_exception_val = exception_value;
                return_caught = false; break_caught = false; continue_caught = false; exception_raised = false;
                Scope* old_scope = current_scope;
                push_scope();
                current_scope->parent = captured;
                exec_statement(body);
                pop_scope();
                current_scope = old_scope;
                return_caught = old_return; return_value = old_return_val;
                break_caught = old_break; continue_caught = old_continue;
                exception_raised = old_exception; exception_value = old_exception_val;
                result = make_null();
                break;
            }
            else if (fh == "taste"_h) {
                if (arg_count != 0) kr_error("taste 不需要参数");
                std::string key_str;
            #ifdef _WIN32
                int ch = _getch();
                if (ch == 0xE0 || ch == 0x00) {
                    int ch2 = _getch();
                    switch (ch2) {
                        case 0x3B: key_str = "F1"; break; case 0x3C: key_str = "F2"; break;
                        case 0x3D: key_str = "F3"; break; case 0x3E: key_str = "F4"; break;
                        case 0x3F: key_str = "F5"; break; case 0x40: key_str = "F6"; break;
                        case 0x41: key_str = "F7"; break; case 0x42: key_str = "F8"; break;
                        case 0x43: key_str = "F9"; break; case 0x44: key_str = "F10"; break;
                        case 0x85: key_str = "F11"; break; case 0x86: key_str = "F12"; break;
                        default: key_str = std::string(1, (char)ch) + (char)ch2; break;
                    }
                } else { key_str = (char)ch; }
            #else
                struct termios oldt, newt;
                tcgetattr(STDIN_FILENO, &oldt);
                newt = oldt; newt.c_lflag &= ~(ICANON | ECHO);
                tcsetattr(STDIN_FILENO, TCSANOW, &newt);
                int ch = getchar();
                if (ch == 0x1B) {
                    int ch2 = getchar();
                    std::string seq = "\x1b";
                    if (ch2 != EOF) seq += (char)ch2;
                    // 简化处理，仅处理常见序列
                    std::string norm = ansi_to_key_name(seq);
                    key_str = norm.empty() ? seq : norm;
                } else if (ch != EOF) key_str = (char)ch;
                tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
            #endif
                result = make_string(key_str.c_str());
                break;
            }
            else if (fh == "ac_taste"_h) {
                if (arg_count < 1 || arg_count > 2) kr_error("ac_taste 需要 1 或 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("第一个参数必须是字符串");
                std::string key = normalize_key_string(args[0].str_val);
                bool stop = false;
                if (arg_count == 2) {
                    if (args[1].type != VAL_STRING || strcmp(args[1].str_val, "stop") != 0)
                        kr_error("第二个参数若存在必须为 \"stop\"");
                    stop = true;
                }
                {
                    std::lock_guard<std::mutex> lock(g_key_listener_mutex);
                    auto it = g_key_listeners.find(key);
                    if (it != g_key_listeners.end()) {
                        g_key_pressed[key] = true;
                        if (it->second.joinable()) it->second.join();
                        g_key_listeners.erase(it);
                    }
                    if (!stop) {
                        g_key_pressed[key] = false;
                        std::thread t(key_listener_thread_func, key);
                        t.detach();
                        g_key_listeners[key] = std::move(t);
                    }
                }
                result = make_null();
                break;
            }
            else if (fh == "taste_g"_h) {
                if (arg_count != 1) kr_error("taste_g 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
                std::string key = normalize_key_string(args[0].str_val);
                bool pressed = g_key_pressed[key].load();
                if (pressed) g_key_pressed[key] = false;
                result = make_int(pressed ? 1 : 0);
                break;
            }

            // 7. 进程执行：ausf, ausführen, ac_ausf
            else if (fh == "ausf"_h || fh == "ausführen"_h) {
                if (arg_count != 1) kr_error("ausf/ausführen 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
                result = run_command_and_capture(args[0].str_val);
                break;
            }
            else if (fh == "ac_ausf"_h) {
                if (arg_count != 1) kr_error("ac_ausf 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
                std::string cmd = args[0].str_val;
                int id = ++next_future_id;
                auto future = std::async(std::launch::async, [cmd]() -> std::shared_ptr<Value> {
                    Value result = run_command_and_capture(cmd);
                    Value* heap_val = new Value(copy_value(result));
                    free_value(&result);
                    return std::shared_ptr<Value>(heap_val, [](Value* p) { if (p) { free_value(p); delete p; } });
                });
                {
                    std::lock_guard<std::mutex> lock(future_map_mutex);
                    future_map[id] = future.share();
                }
                Value fut_val;
                fut_val.type = VAL_FUTURE;
                fut_val.future_state.future_id = id;
                result = fut_val;
                break;
            }
            else if (fh == "BC"_h) {
                if (arg_count != 1) {
                    kr_error("BC benötigt genau 1 Argument (Byte-Array)");
                }
                if (args[0].type != VAL_ARRAY) {
                    kr_error("Argument muss ein Array von Bytes sein (0-255)");
                }

                size_t size = args[0].arr_val.length;
                if (size == 0) {
                    result = make_int(0LL);
                    break;
                }

                // 1. 拷贝字节码到普通堆内存
                unsigned char* code = (unsigned char*)malloc(size);
                if (!code) kr_error("Speicherzuweisung fehlgeschlagen");

                for (size_t i = 0; i < size; ++i) {
                    Value& elem = args[0].arr_val.elements[(long long)i];
                    if (elem.type != VAL_INT && elem.type != VAL_INT64) {
                        free(code);
                        kr_error("Byte-Array-Element muss eine Zahl sein");
                    }
                    long long byte = value_to_ll(elem);
                    if (byte < 0 || byte > 255) {
                        free(code);
                        kr_error("Byte-Wert außerhalb 0-255");
                    }
                    code[i] = (unsigned char)byte;
                }

                // 2. 分配可执行内存
                void* exec_mem = nullptr;
            #ifdef _WIN32
                exec_mem = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
                if (!exec_mem) {
                    free(code);
                    kr_error("VirtualAlloc fehlgeschlagen");
                }
            #else
                exec_mem = mmap(NULL, size, PROT_READ | PROT_WRITE | PROT_EXEC,
                                MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
                if (exec_mem == MAP_FAILED) {
                    free(code);
                    kr_error("mmap fehlgeschlagen");
                }
            #endif

                // 3. 写入机器码
                memcpy(exec_mem, code, size);
                free(code);  // 普通堆内存已无用

                // 4. 刷新指令缓存（确保 CPU 读取新写入的指令）
            #ifdef __GNUC__
                __builtin___clear_cache((char*)exec_mem, (char*)exec_mem + size);
            #endif

                // 5. 执行并获取返回值（假设机器码返回 int，兼容 x86/ARM 调用约定）
                typedef int (*func_t)(void);
                func_t f = (func_t)exec_mem;
                int ret_val = f();

                // 6. 释放可执行内存
            #ifdef _WIN32
                VirtualFree(exec_mem, 0, MEM_RELEASE);
            #else
                munmap(exec_mem, size);
            #endif

                // 7. 将返回值传回 Kernregel 环境
                result = make_int((long long)ret_val);
                break;
            }

            // 8. 调试函数：tokens, worte, bytes, kodierBase64
            else if (fh == "tokens"_h) {
                long long startLine = 1, endLine = 0;
                long long startCol = 1, endCol = LLONG_MAX;
                bool hasColRange = false;

                // 参数解析
                if (arg_count == 0) {
                    // 全部文件
                    for (int i = 0; i < token_count; ++i)
                        if (tokens[i].line > endLine) endLine = tokens[i].line;
                    if (endLine == 0) endLine = 1;
                } else if (arg_count == 1) {
                    Value arg = args[0];
                    if (arg.type == VAL_INT || arg.type == VAL_INT64) {
                        long long line = value_to_ll(arg);
                        startLine = endLine = line;
                    } else if (arg.type == VAL_ARRAY && arg.arr_val.length == 2) {
                        startLine = value_to_ll(arg.arr_val.elements[0]);
                        endLine   = value_to_ll(arg.arr_val.elements[1]);
                        if (startLine > endLine) std::swap(startLine, endLine);
                    } else {
                        kr_error("tokens 参数应为整数或 [行,行] 数组");
                    }
                } else if (arg_count == 2) {
                    Value arg1 = args[0], arg2 = args[1];
                    if (arg1.type == VAL_ARRAY && arg1.arr_val.length == 2 &&
                        arg2.type == VAL_ARRAY && arg2.arr_val.length == 2) {
                        startLine = value_to_ll(arg1.arr_val.elements[0]);
                        startCol  = value_to_ll(arg1.arr_val.elements[1]);
                        endLine   = value_to_ll(arg2.arr_val.elements[0]);
                        endCol    = value_to_ll(arg2.arr_val.elements[1]);
                        hasColRange = true;
                        if (startLine > endLine) { std::swap(startLine, endLine); std::swap(startCol, endCol); }
                    } else {
                        kr_error("tokens 两个参数必须都是 [行,列] 数组");
                    }
                } else {
                    kr_error("tokens 接受 0, 1 或 2 个参数");
                }

                if (endLine == 0) { // 未设置最大行
                    for (int i = 0; i < token_count; ++i)
                        if (tokens[i].line > endLine) endLine = tokens[i].line;
                    if (endLine == 0) endLine = 1;
                }
                if (!hasColRange) {
                    startCol = 1;
                    endCol = LLONG_MAX;
                }

                std::string output;
                for (int i = 0; i < token_count; ++i) {
                    Token* tok = &tokens[i];
                    if (tok->line < startLine || tok->line > endLine) continue;
                    if (tok->line == startLine && tok->col < startCol) continue;
                    if (tok->line == endLine   && tok->col > endCol)   continue;

                    const char* type_str;
                    const char* color_code = "\033[0m";  // 默认重置
                    switch (tok->type) {
                        case TOK_IDENT:   type_str = "<IDENT>";   color_code = "\033[32m"; break;
                        case TOK_NUMBER:  type_str = "<ZAHL>";    color_code = "\033[33m"; break;
                        case TOK_REGEX:   type_str = "<REGUL>\n";   color_code = "\033[35m"; break;
                        case TOK_KEYWORD: type_str = "<KEYWORT>\n"; color_code = "\033[36m"; break;
                        case TOK_OP:      type_str = "<OP>";      color_code = "\033[31m"; break;
                        case TOK_SYMBOL:  type_str = "<SYMBOL>";  color_code = "\033[34m"; break;
                        case TOK_EOF:     type_str = "<EOF>";     color_code = "\033[90m"; break;
                        default:          type_str = "<UNBEKAN>"; color_code = "\033[37m"; break;
                    }
                    char part[256];
                    snprintf(part, sizeof(part), "%s%s%s%s",
                            tok->value, color_code, type_str, "\033[0m");
                    output += part;
                }
                if (!output.empty() && output.back() == ' ') output.pop_back();
                result = make_string(output.c_str());
                break;
            }
            else if (fh == "worte"_h) {
                long long startLine = 1, endLine = 0;
                long long startCol = 1, endCol = LLONG_MAX;
                bool hasColRange = false;

                // 参数解析（与 tokens 相同）
                if (arg_count == 0) {
                    for (int i = 0; i < token_count; ++i)
                        if (tokens[i].line > endLine) endLine = tokens[i].line;
                    if (endLine == 0) endLine = 1;
                } else if (arg_count == 1) {
                    Value arg = args[0];
                    if (arg.type == VAL_INT || arg.type == VAL_INT64) {
                        long long line = value_to_ll(arg);
                        startLine = endLine = line;
                    } else if (arg.type == VAL_ARRAY && arg.arr_val.length == 2) {
                        startLine = value_to_ll(arg.arr_val.elements[0]);
                        endLine   = value_to_ll(arg.arr_val.elements[1]);
                        if (startLine > endLine) std::swap(startLine, endLine);
                    } else {
                        kr_error("worte 参数应为整数或 [行,行] 数组");
                    }
                } else if (arg_count == 2) {
                    Value arg1 = args[0], arg2 = args[1];
                    if (arg1.type == VAL_ARRAY && arg1.arr_val.length == 2 &&
                        arg2.type == VAL_ARRAY && arg2.arr_val.length == 2) {
                        startLine = value_to_ll(arg1.arr_val.elements[0]);
                        startCol  = value_to_ll(arg1.arr_val.elements[1]);
                        endLine   = value_to_ll(arg2.arr_val.elements[0]);
                        endCol    = value_to_ll(arg2.arr_val.elements[1]);
                        hasColRange = true;
                        if (startLine > endLine) { std::swap(startLine, endLine); std::swap(startCol, endCol); }
                    } else {
                        kr_error("worte 两个参数必须都是 [行,列] 数组");
                    }
                } else {
                    kr_error("worte 接受 0, 1 或 2 个参数");
                }

                if (endLine == 0) {
                    for (int i = 0; i < token_count; ++i)
                        if (tokens[i].line > endLine) endLine = tokens[i].line;
                    if (endLine == 0) endLine = 1;
                }
                if (!hasColRange) {
                    startCol = 1;
                    endCol = LLONG_MAX;
                }

                std::string output;
                for (int i = 0; i < token_count; ++i) {
                    Token* tok = &tokens[i];
                    if (tok->line < startLine || tok->line > endLine) continue;
                    if (tok->line == startLine && tok->col < startCol) continue;
                    if (tok->line == endLine   && tok->col > endCol)   continue;

                    // 仅收集非运算符、非符号、非 EOF
                    if (tok->type == TOK_OP || tok->type == TOK_SYMBOL || tok->type == TOK_EOF)
                        continue;

                    output += tok->value;
                    output += ' ';
                }
                if (!output.empty() && output.back() == ' ') output.pop_back();
                result = make_string(output.c_str());
                break;
            }
            // ---- 获取当前行号 ----
            else if (fh == "zeile"_h || fh == "line"_h) {
                if (arg_count == 0) {
                    result = make_int(node->line);
                } else if (arg_count == 1) {
                    Value arg = args[0];
                    if (arg.type != VAL_STRING) kr_error("zeile 参数必须是字符串");
                    const char* opt = arg.str_val;
                    if (strcmp(opt, "s") == 0 || strcmp(opt, "spalte") == 0) {
                        result = make_int(node->col);
                    } else if (strcmp(opt, "a") == 0 || strcmp(opt, "alle") == 0) {
                        char buf[64];
                        snprintf(buf, sizeof(buf), "%d:%d", node->line, node->col);
                        result = make_string(buf);
                    } else {
                        kr_error("未知选项 '%s'，支持 's' (列), 'a' (行列)", opt);
                    }
                } else {
                    kr_error("zeile 接受 0 或 1 个参数");
                }
                break;
            }
            else if (fh == "fname"_h) {
                if (arg_count != 0) kr_error("fname 不需要参数");
                const char* fname_val = nullptr;
                // 1. 优先从当前节点位置查找
                if (node->line > 0) {
                    fname_val = find_filename_by_line_col(node->line, node->col);
                }
                // 2. 若未找到，尝试从调用栈获取
                if (!fname_val && !g_call_stack.empty()) {
                    const CallFrame& frame = g_call_stack.back();
                    if (frame.filename && strcmp(frame.filename, "-") != 0) {
                        fname_val = frame.filename;
                    }
                }
                // 3. 最后回退到 current_filename（作为后备）
                if (!fname_val) {
                    fname_val = current_filename ? current_filename : "";
                }
                result = make_string(fname_val);
                break;
            }
            else if (fh == "ende"_h || fh == "exit"_h) {
                if (arg_count > 1) {
                    kr_error("ende/exit 预期 0 或 1 个参数（退出码）");
                }
                int exit_code = 0;
                if (arg_count == 1) {
                    Value code = args[0];
                    if (code.type != VAL_INT && args[0].type != VAL_INT64) {
                        kr_error("退出码必须是一个整数");
                    }
                    exit_code = (int)value_to_ll(code);
                }
                std::exit(exit_code);
            }
            else if (fh == "bytes"_h) {
                if (arg_count != 1) kr_error("bytes 需要 1 个字符串参数");
                if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
                size_t len = 0;
                char* unescaped = unescape_string(args[0].str_val, &len);
                Value* elems = (Value*)malloc(len * sizeof(Value));
                for (size_t i = 0; i < len; ++i) elems[i] = make_int((unsigned char)unescaped[i]);
                free(unescaped);
                result = make_array(elems, len);
                free(elems);
                break;
            }
            else if (fh == "umbytes"_h) {
                if (arg_count != 1) {
                    kr_error("umbytes benötigt genau 1 Argument (Byte-Array)");
                }
                if (args[0].type != VAL_ARRAY) {
                    kr_error("umbytes Argument muss ein Array von Bytes sein");
                }
                Value& arr = args[0];
                std::string str;
                str.reserve(arr.arr_val.length);
                for (long long i = 0; i < arr.arr_val.length; ++i) {
                    Value& elem = arr.arr_val.elements[i];
                    if (elem.type != VAL_INT && elem.type != VAL_INT64) {
                        kr_error("umbytes Array-Element %lld ist keine Zahl", i);
                    }
                    long long byte = value_to_ll(elem);
                    if (byte < 0 || byte > 255) {
                        kr_error("umbytes Byte-Wert %lld außerhalb 0-255", byte);
                    }
                    str.push_back((char)byte);
                }
                result = make_string_len(str.data(), str.size());
                break;
            }
            else if (fh == "kodierBase64"_h) {
                if (arg_count != 1) kr_error("kodierBase64 需要 1 个参数");
                std::string raw_data;
                if (args[0].type == VAL_STRING) {
                    raw_data.assign(args[0].str_val, args[0].str_len);
                } else if (args[0].type == VAL_ARRAY) {
                    raw_data.reserve(args[0].arr_val.length);
                    for (long long i = 0; i < args[0].arr_val.length; i++) {
                        Value& elem = args[0].arr_val.elements[i];
                        if (elem.type != VAL_INT && elem.type != VAL_INT64) kr_error("数组元素必须是整数");
                        int byte = value_to_int(elem);
                        if (byte < 0 || byte > 255) kr_error("字节值超出 0-255");
                        raw_data.push_back((unsigned char)byte);
                    }
                } else kr_error("参数必须是字符串或字节数组");
                std::string encoded = base64_encode((const unsigned char*)raw_data.data(), raw_data.size());
                result = make_string(encoded.c_str());
                break;
            }

            // ==================== 通用 HTTP 辅助 ====================

            // ---------- esc(s) ----------
            else if (fh == "esc"_h) {
                if (arg_count != 1) kr_error("esc 需要 1 个参数");
                char* s = value_to_string(args[0]);
                std::string out;
                for (char c : std::string(s)) {
                    switch (c) {
                        case '&':  out += "&amp;";  break;
                        case '<':  out += "&lt;";   break;
                        case '>':  out += "&gt;";   break;
                        case '"':  out += "&quot;"; break;
                        case '\'': out += "&#39;";  break;
                        default:   out += c;
                    }
                }
                free(s);
                result = make_string(out.c_str());
                break;
            }

            // ---------- text(s [, status]) ----------
            else if (fh == "text"_h) {
                if (arg_count < 1 || arg_count > 2) kr_error("text 需要 1 或 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("text 第一个参数必须是字符串");
                int status = 200;
                if (arg_count == 2) {
                    if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                        kr_error("text 状态码必须是整数");
                    status = (int)value_to_ll(args[1]);
                }

                ObjectEntry head[1];
                head[0].key = strdup("Content-Type");
                head[0].value = make_string("text/plain; charset=utf-8");

                ObjectEntry entries[3];
                entries[0].key = strdup("zustand"); entries[0].value = make_int((long long)status);
                entries[1].key = strdup("kopf");    entries[1].value = make_object(head, 1);
                entries[2].key = strdup("inhalt");  entries[2].value =
                    make_string_len(args[0].str_val, args[0].str_len);

                result = make_object(entries, 3);

                free(head[0].key); free_value(&head[0].value);
                for (int i = 0; i < 3; i++) { free(entries[i].key); free_value(&entries[i].value); }
                break;
            }

            // ---------- json(v [, status]) ----------
            else if (fh == "json"_h) {
                if (arg_count < 1 || arg_count > 2) kr_error("json 需要 1 或 2 个参数");
                int status = 200;
                if (arg_count == 2) {
                    if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                        kr_error("json 状态码必须是整数");
                    status = (int)value_to_ll(args[1]);
                }

                std::string body = json_stringify_value(args[0], false, 0);

                ObjectEntry head[1];
                head[0].key = strdup("Content-Type");
                head[0].value = make_string("application/json; charset=utf-8");

                ObjectEntry entries[3];
                entries[0].key = strdup("zustand"); entries[0].value = make_int((long long)status);
                entries[1].key = strdup("kopf");    entries[1].value = make_object(head, 1);
                entries[2].key = strdup("inhalt");  entries[2].value =
                    make_string_len(body.data(), body.size());

                result = make_object(entries, 3);

                free(head[0].key); free_value(&head[0].value);
                for (int i = 0; i < 3; i++) { free(entries[i].key); free_value(&entries[i].value); }
                break;
            }

            // ---------- html(s [, status]) ----------
            else if (fh == "html"_h) {
                if (arg_count < 1 || arg_count > 2) kr_error("html 需要 1 或 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("html 第一个参数必须是字符串");
                int status = 200;
                if (arg_count == 2) {
                    if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                        kr_error("html 状态码必须是整数");
                    status = (int)value_to_ll(args[1]);
                }

                ObjectEntry head[1];
                head[0].key = strdup("Content-Type");
                head[0].value = make_string("text/html; charset=utf-8");

                ObjectEntry entries[3];
                entries[0].key = strdup("zustand"); entries[0].value = make_int((long long)status);
                entries[1].key = strdup("kopf");    entries[1].value = make_object(head, 1);
                entries[2].key = strdup("inhalt");  entries[2].value =
                    make_string_len(args[0].str_val, args[0].str_len);

                result = make_object(entries, 3);

                free(head[0].key); free_value(&head[0].value);
                for (int i = 0; i < 3; i++) { free(entries[i].key); free_value(&entries[i].value); }
                break;
            }

            // ---------- umleiten(url [, status]) ----------
            else if (fh == "umleiten"_h) {
                if (arg_count < 1 || arg_count > 2) kr_error("umleiten 需要 1 或 2 个参数");
                if (args[0].type != VAL_STRING) kr_error("umleiten 第一个参数必须是 URL");
                int status = 302;
                if (arg_count == 2) {
                    if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                        kr_error("umleiten 状态码必须是整数");
                    status = (int)value_to_ll(args[1]);
                }

                ObjectEntry head[1];
                head[0].key = strdup("Location");
                head[0].value = make_string_len(args[0].str_val, args[0].str_len);

                ObjectEntry entries[3];
                entries[0].key = strdup("zustand"); entries[0].value = make_int((long long)status);
                entries[1].key = strdup("kopf");    entries[1].value = make_object(head, 1);
                entries[2].key = strdup("inhalt");  entries[2].value = make_string("");

                result = make_object(entries, 3);

                free(head[0].key); free_value(&head[0].value);
                for (int i = 0; i < 3; i++) { free(entries[i].key); free_value(&entries[i].value); }
                break;
            }

            // ---------- abfrage(url) ----------
            else if (fh == "abfrage"_h) {
                if (arg_count != 1) kr_error("abfrage 需要 1 个 URL 字符串");
                if (args[0].type != VAL_STRING) kr_error("abfrage 参数必须是字符串");

                std::string url(args[0].str_val, args[0].str_len);
                size_t qm = url.find('?');
                std::string query = (qm == std::string::npos) ? "" : url.substr(qm + 1);

                // 去掉 #fragment
                size_t hash = query.find('#');
                if (hash != std::string::npos) query = query.substr(0, hash);

                result = parse_urlencoded(query);
                break;
            }

            // ---------- formular(body) ----------
            else if (fh == "formular"_h) {
                if (arg_count != 1) kr_error("formular 需要 1 个 body 字符串");
                if (args[0].type != VAL_STRING) kr_error("formular 参数必须是字符串");
                result = parse_urlencoded(std::string(args[0].str_val, args[0].str_len));
                break;
            }

            // ---------- kodierURL(s) ----------
            else if (fh == "kodierURL"_h) {
                if (arg_count != 1) kr_error("kodierURL 需要 1 个参数");
                char* s = value_to_string(args[0]);
                static const char* hex = "0123456789ABCDEF";
                std::string out;
                for (unsigned char c : std::string(s)) {
                    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
                        out += (char)c;
                    } else {
                        out += '%';
                        out += hex[c >> 4];
                        out += hex[c & 0xF];
                    }
                }
                free(s);
                result = make_string(out.c_str());
                break;
            }

            // ---------- dekodierURL(s) ----------
            else if (fh == "dekodierURL"_h) {
                if (arg_count != 1) kr_error("dekodierURL 需要 1 个参数");
                char* s = value_to_string(args[0]);
                std::string in(s);
                std::string out;
                for (size_t i = 0; i < in.size(); i++) {
                    if (in[i] == '+') {
                        out += ' ';
                    } else if (in[i] == '%' && i + 2 < in.size() &&
                            isxdigit((unsigned char)in[i+1]) &&
                            isxdigit((unsigned char)in[i+2])) {
                        char hex[3] = { in[i+1], in[i+2], 0 };
                        out += (char)strtol(hex, nullptr, 16);
                        i += 2;
                    } else {
                        out += in[i];
                    }
                }
                free(s);
                result = make_string(out.c_str());
                break;
            }

            // 9. HTTP 请求：ANFR, ac_ANFR
            else if (fh == "ANFR"_h) {
                if (arg_count < 2 || arg_count > 3) kr_error("ANFR 需要 2 或 3 个参数");
                if (args[0].type != VAL_STRING) kr_error("方法必须是字符串");
                if (args[1].type != VAL_STRING) kr_error("URL 必须是字符串");
                Value optionen = (arg_count == 3) ? copy_value(args[2]) : make_null();
                result = http_anfrage(args[0].str_val, args[1].str_val, optionen);
                free_value(&optionen);
                break;
            }
            else if (fh == "ac_ANFR"_h) {
                if (arg_count < 2 || arg_count > 3) kr_error("ac_ANFR 需要 2 或 3 个参数");
                if (args[0].type != VAL_STRING) kr_error("方法必须是字符串");
                if (args[1].type != VAL_STRING) kr_error("URL 必须是字符串");
                Value optionen = (arg_count == 3) ? copy_value(args[2]) : make_null();
                result = ac_http_anfrage(args[0].str_val, args[1].str_val, optionen);
                free_value(&optionen);
                break;
            }

            else if (fh == "holeIP"_h) {
                if (arg_count == 0) {
                    // ---- 无参：返回本机（服务器主机）IP 信息 ----
                    result = make_host_ip_object();
                } else if (arg_count == 1) {
                    // ---- 单参：从 HTTP 请求对象读取客户端 IP ----
                    if (args[0].type != VAL_OBJECT) {
                        kr_error("holeIP(req): 参数必须是 HTTP 请求对象");
                    }
                    std::string client_ip;
                    bool found = false;
                    for (int i = 0; i < args[0].obj_val.count; ++i) {
                        if (strcmp(args[0].obj_val.entries[i].key, "ip") == 0 &&
                            args[0].obj_val.entries[i].value.type == VAL_STRING) {
                            client_ip.assign(args[0].obj_val.entries[i].value.str_val,
                                            args[0].obj_val.entries[i].value.str_len);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        kr_warn("holeIP(req): 请求对象没有 'ip' 字段（可能不是标准 HTTP 请求对象）");
                        client_ip = "";
                    }

                    // 同时返回客户端与主机信息，方便一起用
                    Value host_obj = make_host_ip_object();

                    ObjectEntry entries[5];
                    entries[0].key = strdup("client");
                    entries[0].value = make_string(client_ip.c_str());
                    entries[1].key = strdup("client_lokal");
                    entries[1].value = make_int(is_loopback_ip(client_ip) ? 1LL : 0LL);
                    entries[2].key = strdup("host");
                    entries[2].value = make_string(host_obj.obj_val.entries[0].value.str_val);
                    entries[3].key = strdup("lokal");
                    entries[3].value = make_string("127.0.0.1");
                    entries[4].key = strdup("ipv4");
                    entries[4].value = copy_value(host_obj.obj_val.entries[2].value);

                    Value obj = make_object(entries, 5);
                    for (int i = 0; i < 5; ++i) {
                        free(entries[i].key);
                        free_value(&entries[i].value);
                    }
                    free_value(&host_obj);
                    result = obj;
                } else {
                    kr_error("holeIP 需要 0 或 1 个参数");
                }
                break;
            }

            // ---------- SSE() ----------
            else if (fh == "SSE"_h) {
                if (arg_count != 0) kr_error("SSE 不需要参数");
                auto state = std::make_shared<StreamState>();
                state->sse = true;
                StreamHandle* user_handle = new StreamHandle{ state };

                ObjectEntry head[1];
                head[0].key = strdup("Content-Type");
                head[0].value = make_string("text/event-stream; charset=utf-8");

                ObjectEntry entries[4];
                entries[0].key = strdup("__stream");
                entries[0].value = make_int(1LL);
                entries[1].key = strdup("__stream_handle");
                entries[1].value = make_int64((int64_t)user_handle);
                entries[2].key = strdup("zustand");
                entries[2].value = make_int(200LL);
                entries[3].key = strdup("kopf");
                entries[3].value = make_object(head, 1);

                result = make_object(entries, 4);

                free(head[0].key); free_value(&head[0].value);
                for (int i = 0; i < 4; i++) { free(entries[i].key); free_value(&entries[i].value); }
                break;
            }

            // ---------- sende(stream, data) ----------
            else if (fh == "sende"_h) {
                if (arg_count != 2) kr_error("sende 需要 2 个参数：stream, data");
                if (args[0].type != VAL_OBJECT) kr_error("第一个参数必须是 stream");

                StreamHandle* h = nullptr;
                bool sse_mode = false;
                for (int i = 0; i < args[0].obj_val.count; i++) {
                    if (strcmp(args[0].obj_val.entries[i].key, "__stream_handle") == 0 &&
                        args[0].obj_val.entries[i].value.type == VAL_INT64) {
                        h = (StreamHandle*)args[0].obj_val.entries[i].value.int64_val;
                    } else if (strcmp(args[0].obj_val.entries[i].key, "__stream") == 0) {
                        sse_mode = true;
                    }
                }
                if (!h || !h->state) kr_error("无效的 stream 对象");

                std::string data = value_to_stdstring(args[1]);
                std::string payload;
                if (sse_mode) {
                    std::istringstream iss(data);
                    std::string line;
                    while (std::getline(iss, line)) {
                        payload += "data: " + line + "\n";
                    }
                    payload += "\n";
                } else {
                    payload = data;
                }
                h->state->push(std::move(payload));
                result = make_null();
                break;
            }

            // ---------- sendeSSE(stream, [event,] data) ----------
            else if (fh == "sendeSSE"_h) {
                if (arg_count < 2 || arg_count > 3) kr_error("sendeSSE 需要 2 或 3 个参数");
                if (args[0].type != VAL_OBJECT) kr_error("第一个参数必须是 stream");

                StreamHandle* h = nullptr;
                for (int i = 0; i < args[0].obj_val.count; i++) {
                    if (strcmp(args[0].obj_val.entries[i].key, "__stream_handle") == 0 &&
                        args[0].obj_val.entries[i].value.type == VAL_INT64) {
                        h = (StreamHandle*)args[0].obj_val.entries[i].value.int64_val;
                        break;
                    }
                }
                if (!h || !h->state) kr_error("无效的 stream 对象");

                std::string event, data;
                if (arg_count == 2) data = value_to_stdstring(args[1]);
                else { event = value_to_stdstring(args[1]); data = value_to_stdstring(args[2]); }

                std::string payload;
                if (!event.empty()) payload += "event: " + event + "\n";
                std::istringstream iss(data);
                std::string line;
                while (std::getline(iss, line)) payload += "data: " + line + "\n";
                payload += "\n";

                h->state->push(std::move(payload));
                result = make_null();
                break;
            }

            // ---------- schliesse(stream) ----------
            else if (fh == "schliesse"_h) {
                if (arg_count != 1) kr_error("schliesse 需要 1 个参数");
                if (args[0].type != VAL_OBJECT) kr_error("参数必须是 stream");

                StreamHandle* h = nullptr;
                for (int i = 0; i < args[0].obj_val.count; i++) {
                    if (strcmp(args[0].obj_val.entries[i].key, "__stream_handle") == 0 &&
                        args[0].obj_val.entries[i].value.type == VAL_INT64) {
                        h = (StreamHandle*)args[0].obj_val.entries[i].value.int64_val;
                        break;
                    }
                }
                if (!h || !h->state) kr_error("无效的 stream 对象");

                h->state->close();
                result = make_null();
                break;
            }

            // 10. HTTP 服务器：starteServer, ac_starteServer
            else if (fh == "starteServer"_h || fh == "ac_starteServer"_h) {
                if (arg_count != 2) kr_error("starteServer/ac_starteServer 需要 2 个参数");
                if (args[0].type != VAL_INT && args[0].type != VAL_INT64) kr_error("端口必须是整数");
                if (args[1].type != VAL_FUNCTION) kr_error("Handler 必须是函数");
                uint16_t port = (uint16_t)value_to_int(args[0]);
                Value handler_copy = copy_value(args[1]);
                int line = node->line, col = node->col;
                auto server = std::make_shared<HttpServer>(port,
                    [handler_copy, line, col](Value req) -> Value {
                        return call_function_value(handler_copy, &req, 1);
                    });
                if (!server->start()) kr_error("无法在端口 %d 启动服务器", port);
                if (fh == "starteServer"_h) {
                    // 让出全局锁，否则 HTTP 回调线程拿不到锁会死锁
                    ScopedLockRelease releaser(g_global_mutex);
                    releaser.release();
                    server->wait();
                    releaser.relock();          // wait 返回后再恢复持锁状态
                    result = make_null();
                } else {
                    int id = ++next_future_id;
                    auto future = std::async(std::launch::async, [server]() -> std::shared_ptr<Value> {
                        server->wait();
                        Value null_val = make_null();
                        return std::make_shared<Value>(copy_value(null_val));
                    });
                    { std::lock_guard<std::mutex> lock(future_map_mutex); future_map[id] = future.share(); }
                    Value fut_val; fut_val.type = VAL_FUTURE; fut_val.future_state.future_id = id;
                    result = fut_val;
                }
                break;
            }

            else if (fh == "html"_h) {
                // html(html_string)            → 状态码 200
                // html(html_string, status)    → 自定义状态码
                if (arg_count < 1 || arg_count > 2)
                    kr_error("html 需要 1 或 2 个参数：HTML 字符串, [状态码]");
                if (args[0].type != VAL_STRING)
                    kr_error("html 第一个参数必须是字符串");

                int status = 200;
                if (arg_count == 2) {
                    if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                        kr_error("html 第二个参数必须是整数状态码");
                    status = (int)value_to_ll(args[1]);
                }

                // ---- 构造 kopf 对象 { "Content-Type": "text/html; charset=utf-8" } ----
                ObjectEntry head_entries[1];
                head_entries[0].key   = strdup("Content-Type");
                head_entries[0].value = make_string("text/html; charset=utf-8");
                Value head_obj = make_object(head_entries, 1);
                free(head_entries[0].key);
                free_value(&head_entries[0].value);

                // ---- 构造响应对象 { zustand, kopf, inhalt } ----
                ObjectEntry entries[3];
                entries[0].key = strdup("zustand");
                entries[0].value = make_int((long long)status);
                entries[1].key = strdup("kopf");
                entries[1].value = head_obj;                                  // 转移所有权给 make_object 的复制
                entries[2].key = strdup("inhalt");
                entries[2].value = make_string_len(args[0].str_val, args[0].str_len);

                result = make_object(entries, 3);

                // make_object 内部已深拷贝，这里释放临时内存
                for (int i = 0; i < 3; ++i) {
                    free(entries[i].key);
                    free_value(&entries[i].value);
                }
                break;
            }

            // 11. KD 数据集操作
            else if (fh == "ladeKD"_h) {
                if (arg_count != 1) kr_error("ladeKD 需要 1 个参数");
                if (args[0].type != VAL_STRING) kr_error("文件名必须是字符串");
                auto ds = std::make_shared<KDDataSet>();
                bool loaded = ds->load(args[0].str_val);
                if (!loaded) {
                    FILE* test = fopen(args[0].str_val, "rb");
                    if (test) {
                        fclose(test);
                        kr_error("文件 '%s' 存在但无法加载", args[0].str_val);
                    } else {
                        FILE* fp = fopen(args[0].str_val, "wb");
                        if (!fp) kr_error("无法创建文件 '%s'", args[0].str_val);
                        char magic[5] = "KDB"; uint32_t version = 1; uint64_t count = 0;
                        fwrite(magic, 4, 1, fp); fwrite(&version, 4, 1, fp); fwrite(&count, 8, 1, fp);
                        fclose(fp);
                        if (!ds->load(args[0].str_val)) kr_error("无法加载新建文件");
                    }
                }
                Value obj; obj.type = VAL_OBJECT;
                obj.obj_val.count = 1;
                obj.obj_val.entries = (ObjectEntry*)malloc(sizeof(ObjectEntry));
                obj.obj_val.entries[0].key = strdup("__kd_daten");
                std::shared_ptr<KDDataSet>* ptr_holder = new std::shared_ptr<KDDataSet>(ds);
                obj.obj_val.entries[0].value.type = VAL_OBJECT;
                obj.obj_val.entries[0].value.obj_val.count = 1;
                obj.obj_val.entries[0].value.obj_val.entries = (ObjectEntry*)malloc(sizeof(ObjectEntry));
                obj.obj_val.entries[0].value.obj_val.entries[0].key = strdup("__zgr");
                obj.obj_val.entries[0].value.obj_val.entries[0].value.type = VAL_INT;
                Value &v = obj.obj_val.entries[0].value.obj_val.entries[0].value;
                free_value(&v);
                v = make_int64((int64_t)ptr_holder);
                result = obj;
                break;
            }
            else if (fh == "schrKD"_h) {
                if (arg_count != 2) kr_error("schrKD 需要 2 个参数");
                auto datenmenge = _hole_dataset(args[0]);
                if (!datenmenge) kr_error("无效的数据集对象");
                Record eintrag = _wert_zu_eintrag(args[1]);
                if (eintrag.id == 0) eintrag.id = datenmenge->naechste_id();
                if (!datenmenge->insert_record(eintrag)) kr_error("写入失败");
                result = make_null();
                break;
            }
            else if (fh == "erneuKD"_h) {
                if (arg_count != 2) kr_error("erneuKD 需要 2 个参数");
                auto datenmenge = _hole_dataset(args[0]);
                if (!datenmenge) kr_error("无效的数据集对象");
                Record eintrag = _wert_zu_eintrag(args[1]);
                if (eintrag.id == 0) kr_error("缺少 ID");
                if (!datenmenge->delete_record(eintrag.id)) kr_error("ID 不存在");
                if (!datenmenge->insert_record(eintrag)) kr_error("更新失败");
                result = make_null();
                break;
            }
            else if (fh == "loesKD"_h) {
                if (arg_count != 2) kr_error("loesKD 需要 2 个参数");
                auto datenmenge = _hole_dataset(args[0]);
                if (!datenmenge) kr_error("无效的数据集对象");
                uint64_t id = value_to_int(args[1]);
                if (!datenmenge->delete_record(id)) kr_error("ID 不存在");
                result = make_null();
                break;
            }
            else if (fh == "suchKD"_h) {
                if (arg_count != 2) kr_error("suchKD 需要 2 个参数");
                if (args[1].type != VAL_STRING) kr_error("模式必须是字符串");
                auto datenmenge = _hole_dataset(args[0]);
                if (!datenmenge) kr_error("无效的数据集对象");
                auto treffer = datenmenge->find_by_text(args[1].str_val);
                Value* id_werte = (Value*)malloc(treffer.size() * sizeof(Value));
                for (size_t i = 0; i < treffer.size(); i++) id_werte[i] = make_int(treffer[i]);
                result = make_array(id_werte, treffer.size());
                free(id_werte);
                break;
            }
            else if (fh == "siebeKD"_h) {
                if (arg_count != 2) kr_error("siebeKD 需要 2 个参数");
                if (args[1].type != VAL_FUNCTION) kr_error("第二个参数必须是函数");
                auto datenmenge = _hole_dataset(args[0]);
                if (!datenmenge) kr_error("无效的数据集对象");
                auto pred = [&](const Record& rec) -> bool {
                    Value rec_obj = _eintrag_zu_wert(rec);
                    Value erg = call_function_value(args[1], &rec_obj, 1, node);
                    bool ok = value_to_bool(erg);
                    free_value(&rec_obj); free_value(&erg);
                    return ok;
                };
                auto gefiltert = datenmenge->filter_records(pred);
                Value* id_werte = (Value*)malloc(gefiltert.size() * sizeof(Value));
                for (size_t i = 0; i < gefiltert.size(); i++) id_werte[i] = make_int(gefiltert[i]);
                result = make_array(id_werte, gefiltert.size());
                free(id_werte);
                break;
            }
            else if (fh == "alleKD"_h) {
                if (arg_count != 1) kr_error("alleKD 需要 1 个参数");
                auto datenmenge = _hole_dataset(args[0]);
                if (!datenmenge) kr_error("无效的数据集对象");
                auto ids = datenmenge->all_ids();
                Value* id_werte = (Value*)malloc(ids.size() * sizeof(Value));
                for (size_t i = 0; i < ids.size(); i++) id_werte[i] = make_int(ids[i]);
                result = make_array(id_werte, ids.size());
                free(id_werte);
                break;
            }
            else if (fh == "zaehleKD"_h) {
                if (arg_count != 1) kr_error("zaehleKD 需要 1 个参数");
                auto datenmenge = _hole_dataset(args[0]);
                if (!datenmenge) kr_error("无效的数据集对象");
                size_t anzahl = datenmenge->all_ids().size();
                result = make_int((long long)anzahl);
                break;
            }
            else if (fh == "verschlKD"_h) {
                if (arg_count != 2) kr_error("verschlKD 需要 2 个参数");
                if (args[1].type != VAL_STRING) kr_error("密码必须是字符串");
                auto ds = _hole_dataset(args[0]);
                if (!ds) kr_error("无效的数据集对象");
                if (!ds->encrypt(args[1].str_val)) kr_error("加密失败");
                result = make_null();
                break;
            }
            else if (fh == "entschlKD"_h) {
                if (arg_count != 2) kr_error("entschlKD 需要 2 个参数");
                if (args[1].type != VAL_STRING) kr_error("密码必须是字符串");
                auto ds = _hole_dataset(args[0]);
                if (!ds) kr_error("无效的数据集对象");
                if (!ds->decrypt(args[1].str_val)) kr_error("解密失败");
                result = make_null();
                break;
            }
            else if (fh == "jsonzu"_h) {
                if (arg_count != 1) kr_error("jsonzu 需要 1 个字符串参数");
                if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
                result = json_parse(args[0]);
                break;
            }
            else if (fh == "zujson"_h) {
                if (arg_count != 1) kr_error("zujson 需要 1 个参数");
                result = json_to_string(args[0]);
                break;
            }

            // ==================== 指针操作 ====================

            // ---- 裸指针 ----
            else if (fh == "zgr"_h) {
                if (arg_count != 1) kr_error("zeiger 需要 1 个参数");
                result = make_pointer_raw(args[0]);
                break;
            }
            // ---- 智能指针 ----
            else if (fh == "schlau"_h) {
                if (arg_count != 1) kr_error("schlauZeiger 需要 1 个参数");
                result = make_pointer_smart(args[0]);
                break;
            }
            // ---- 解引用（读写通用） ----
            else if (fh == "zgrw"_h) {
                if (arg_count != 1) kr_error("zeigerWert 需要 1 个参数");
                if (args[0].type != VAL_POINTER) kr_error("参数不是指针");
                if (args[0].ptr_val.freed) kr_error("访问已释放的指针");
                Value* target = args[0].ptr_val.smart_target
                                ? args[0].ptr_val.smart_target->get()
                                : args[0].ptr_val.raw_target;
                if (!target) kr_error("空指针解引用");
                result = copy_value(*target);
                break;
            }
            // ---- 写指针 ----
            else if (fh == "zgrs"_h) {
                if (arg_count != 2) kr_error("zeigerSetze 需要 2 个参数");
                if (args[0].type != VAL_POINTER) kr_error("第一个参数不是指针");
                if (args[0].ptr_val.freed) kr_error("访问已释放的指针");
                Value* target = args[0].ptr_val.smart_target
                                ? args[0].ptr_val.smart_target->get()
                                : args[0].ptr_val.raw_target;
                if (!target) kr_error("空指针写入");
                free_value(target);
                *target = copy_value(args[1]);
                result = make_null();
                break;
            }
            // ---- 释放裸指针 ----
            else if (fh == "frei"_h) {
                if (arg_count != 1) kr_error("zeigerFrei 需要 1 个参数");
                if (args[0].type != VAL_POINTER) kr_error("参数不是指针");

                // 尝试拿到原左值指针；若参数是表达式，则退回参数副本
                Value* p = &args[0];
                ASTNode* arg_node = node->data.func_call.args[0];
                if (arg_node && is_lvalue_node(arg_node)) {
                    Value* lv = get_mutable_ptr(arg_node);
                    if (lv && lv->type == VAL_POINTER) p = lv;
                }

                if (p->ptr_val.smart_target) {
                    kr_warn("zeigerFrei 对智能指针无效果；引用计数自动管理生命周期");
                } else if (p->ptr_val.raw_target) {
                    if (p->ptr_val.freed) {
                        kr_error("指针已经被释放，不能重复释放");
                    }
                    free_value(p->ptr_val.raw_target);
                    delete p->ptr_val.raw_target;
                    p->ptr_val.raw_target = nullptr;
                    p->ptr_val.freed = true;
                }
                result = make_null();
                break;
            }
            // ---- 是否空指针 ----
            else if (fh == "zgrNull"_h) {
                if (arg_count != 1) kr_error("zeigerIstNull 需要 1 个参数");
                if (args[0].type != VAL_POINTER) kr_error("参数不是指针");
                if (args[0].ptr_val.freed) kr_error("访问已释放的指针");
                bool is_null = (args[0].ptr_val.smart_target == nullptr) &&
                            (args[0].ptr_val.raw_target  == nullptr);
                result = make_int(is_null ? 1 : 0);
                break;
            }

            else if (fh == "regGen"_h) {
                // ---------- 1. 参数解析 ----------
                if (arg_count < 1 || arg_count > 4)
                    kr_error("regGen 需要 1 到 4 个参数：正则, [排除], [起始码点], [结束码点]");

                // ---------- 主正则 ----------
                std::string pattern_str;
                int pcre2_options = PCRE2_UTF | PCRE2_UCP;
                if (args[0].type == VAL_STRING) {
                    pattern_str.assign(args[0].str_val, args[0].str_len);
                } else if (args[0].type == VAL_OBJECT) {
                    std::string pat;
                    std::string flg;
                    bool has_pat = false;
                    for (int i = 0; i < args[0].obj_val.count; ++i) {
                        if (strcmp(args[0].obj_val.entries[i].key, "muster") == 0 &&
                            args[0].obj_val.entries[i].value.type == VAL_STRING) {
                            pat.assign(args[0].obj_val.entries[i].value.str_val,
                                    args[0].obj_val.entries[i].value.str_len);
                            has_pat = true;
                        }
                        if (strcmp(args[0].obj_val.entries[i].key, "flags") == 0 &&
                            args[0].obj_val.entries[i].value.type == VAL_STRING) {
                            flg.assign(args[0].obj_val.entries[i].value.str_val,
                                    args[0].obj_val.entries[i].value.str_len);
                        }
                    }
                    if (!has_pat) kr_error("正则对象缺少 'muster' 字段");
                    pattern_str = pat;
                    if (strchr(flg.c_str(), 'i')) pcre2_options |= PCRE2_CASELESS;
                    if (strchr(flg.c_str(), 'm')) pcre2_options |= PCRE2_MULTILINE;
                    if (strchr(flg.c_str(), 's')) pcre2_options |= PCRE2_DOTALL;
                    if (strchr(flg.c_str(), 'x')) pcre2_options |= PCRE2_EXTENDED;
                } else {
                    kr_error("第一个参数必须是字符串或正则对象");
                }

                // ---------- 排除处理：支持字符串、数组、正则对象 ----------
                std::unordered_set<std::string> exclude_set;
                pcre2_code* exclude_re = nullptr;
                pcre2_match_data* exclude_match_data = nullptr;
                int arg_idx = 1;
                if (arg_count > arg_idx) {
                    Value ex = args[arg_idx];
                    if (ex.type == VAL_STRING) {
                        // 字符串：每个字符排除
                        std::string s = ex.str_val;
                        size_t pos = 0;
                        while (pos < s.size()) {
                            size_t len;
                            utf8_char_width(&s[pos], &len);
                            exclude_set.insert(s.substr(pos, len));
                            pos += len;
                        }
                        arg_idx++;
                    } else if (ex.type == VAL_ARRAY) {
                        // 数组：每个元素（单字符字符串）排除
                        for (long long i = 0; i < ex.arr_val.length; ++i) {
                            if (ex.arr_val.elements[i].type == VAL_STRING) {
                                std::string elem = ex.arr_val.elements[i].str_val;
                                if (utf8_length(elem) == 1)
                                    exclude_set.insert(elem);
                            }
                        }
                        arg_idx++;
                    } else if (ex.type == VAL_OBJECT) {
                        // 正则对象：排除匹配该正则的字符
                        const char* pat = nullptr;
                        const char* flg = "";
                        for (int i = 0; i < ex.obj_val.count; ++i) {
                            if (strcmp(ex.obj_val.entries[i].key, "muster") == 0 &&
                                ex.obj_val.entries[i].value.type == VAL_STRING) {
                                pat = ex.obj_val.entries[i].value.str_val;
                            }
                            if (strcmp(ex.obj_val.entries[i].key, "flags") == 0 &&
                                ex.obj_val.entries[i].value.type == VAL_STRING) {
                                flg = ex.obj_val.entries[i].value.str_val;
                            }
                        }
                        if (!pat) kr_error("排除正则对象缺少 'muster' 字段");
                        std::string exclude_pattern = pat;
                        exclude_pattern = convert_ampersand_to_dollar(exclude_pattern);
                        int opt = PCRE2_UTF | PCRE2_UCP;
                        if (strchr(flg, 'i')) opt |= PCRE2_CASELESS;
                        if (strchr(flg, 'm')) opt |= PCRE2_MULTILINE;
                        if (strchr(flg, 's')) opt |= PCRE2_DOTALL;
                        if (strchr(flg, 'x')) opt |= PCRE2_EXTENDED;

                        int errcode;
                        PCRE2_SIZE erroffset;
                        exclude_re = pcre2_compile(
                            (PCRE2_SPTR)exclude_pattern.c_str(),
                            exclude_pattern.size(),
                            opt,
                            &errcode,
                            &erroffset,
                            NULL
                        );
                        if (!exclude_re) {
                            PCRE2_UCHAR errbuf[256];
                            pcre2_get_error_message(errcode, errbuf, sizeof(errbuf));
                            kr_error("排除正则编译错误: %s (偏移 %zu)", errbuf, erroffset);
                        }
                        exclude_match_data = pcre2_match_data_create_from_pattern(exclude_re, NULL);
                        if (!exclude_match_data) {
                            pcre2_code_free(exclude_re);
                            kr_error("无法创建排除正则匹配数据");
                        }
                        arg_idx++;
                    } else {
                        // 其他类型忽略（或可警告）
                        kr_warn("regGen: 排除参数类型不支持，已忽略");
                    }
                }

                // ---------- 范围 ----------
                int start = 0, end = 0xFFFF;   // 原为 127
                if (arg_count > arg_idx && (args[arg_idx].type == VAL_INT || args[arg_idx].type == VAL_INT64)) {
                    start = (int)value_to_ll(args[arg_idx]);
                    arg_idx++;
                    if (arg_count > arg_idx && (args[arg_idx].type == VAL_INT || args[arg_idx].type == VAL_INT64)) {
                        end = (int)value_to_ll(args[arg_idx]);
                        arg_idx++;
                    } else {
                        end = 0xFFFF;          // 若只提供了起始，结束仍为 BMP 上限
                    }
                }
                if (start > end) std::swap(start, end);
                if (start < 0) start = 0;
                if (end > 0x10FFFF) end = 0x10FFFF;

                // ---------- 编译主正则 ----------
                pattern_str = convert_ampersand_to_dollar(pattern_str);
                int errorcode;
                PCRE2_SIZE erroroffset;
                pcre2_code* re = pcre2_compile(
                    (PCRE2_SPTR)pattern_str.c_str(),
                    pattern_str.size(),
                    pcre2_options,
                    &errorcode,
                    &erroroffset,
                    NULL
                );
                if (!re) {
                    PCRE2_UCHAR errbuf[256];
                    pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
                    kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
                }
                pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
                if (!match_data) {
                    pcre2_code_free(re);
                    if (exclude_re) { pcre2_code_free(exclude_re); pcre2_match_data_free(exclude_match_data); }
                    kr_error("无法创建匹配数据");
                }

                // ---------- 遍历码点 ----------
                std::vector<Value> results;
                for (int cp = start; cp <= end; ++cp) {
                    char utf8[5];
                    int len = 0;
                    if (cp < 0x80) {
                        utf8[0] = (char)cp; len = 1;
                    } else if (cp < 0x800) {
                        utf8[0] = (char)(0xC0 | (cp >> 6));
                        utf8[1] = (char)(0x80 | (cp & 0x3F));
                        len = 2;
                    } else if (cp < 0x10000) {
                        utf8[0] = (char)(0xE0 | (cp >> 12));
                        utf8[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
                        utf8[2] = (char)(0x80 | (cp & 0x3F));
                        len = 3;
                    } else if (cp <= 0x10FFFF) {
                        utf8[0] = (char)(0xF0 | (cp >> 18));
                        utf8[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
                        utf8[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
                        utf8[3] = (char)(0x80 | (cp & 0x3F));
                        len = 4;
                    } else {
                        continue;
                    }
                    utf8[len] = '\0';
                    std::string ch(utf8, len);

                    // 排除检查：先检查集合，再检查排除正则
                    if (exclude_set.find(ch) != exclude_set.end())
                        continue;
                    if (exclude_re) {
                        int rc = pcre2_match(exclude_re, (PCRE2_SPTR)ch.c_str(), ch.size(), 0, 0, exclude_match_data, NULL);
                        if (rc >= 0) continue;   // 匹配排除模式，跳过
                    }

                    // 测试主正则
                    int rc = pcre2_match(re, (PCRE2_SPTR)ch.c_str(), ch.size(), 0, 0, match_data, NULL);
                    if (rc >= 0) {
                        results.push_back(make_string(ch.c_str()));
                    }
                }

                // ---------- 清理 ----------
                pcre2_match_data_free(match_data);
                pcre2_code_free(re);
                if (exclude_re) {
                    pcre2_match_data_free(exclude_match_data);
                    pcre2_code_free(exclude_re);
                }

                Value* elems = (Value*)malloc(results.size() * sizeof(Value));
                for (size_t i = 0; i < results.size(); ++i)
                    elems[i] = results[i];   // 移动
                result = make_array(elems, (int)results.size());
                free(elems);
                break;
            }

            else if (fh == "KRWarn"_h) {
                if (arg_count < 1) kr_error("KRWarn 需要至少 1 个参数（错误消息或对象）");

                // ---- 解析参数 ----
                std::string msg;
                int line = 0, col = 0;
                std::string filename;
                std::string custom_source;
                std::string hint;
                int level = 0;
                bool has_level = false;

                if (arg_count >= 1 && args[0].type == VAL_OBJECT) {
                    // ---------- 对象模式 ----------
                    Value& obj = args[0];
                    for (int i = 0; i < obj.obj_val.count; ++i) {
                        const char* key = obj.obj_val.entries[i].key;
                        Value val = obj.obj_val.entries[i].value;

                        if (strcmp(key, "msg") == 0 || strcmp(key, "info") == 0 || strcmp(key, "text") == 0) {
                            char* s = value_to_string(val);
                            msg = s;
                            free(s);
                        }
                        else if (strcmp(key, "line") == 0 || strcmp(key, "zel") == 0) {
                            if (val.type == VAL_INT || val.type == VAL_INT64)
                                line = (int)value_to_ll(val);
                        }
                        else if (strcmp(key, "col") == 0 || strcmp(key, "spl") == 0) {
                            if (val.type == VAL_INT || val.type == VAL_INT64)
                                col = (int)value_to_ll(val);
                        }
                        else if (strcmp(key, "file") == 0 || strcmp(key, "datei") == 0 || strcmp(key, "name") == 0) {
                            if (val.type == VAL_STRING)
                                filename = val.str_val;
                        }
                        else if (strcmp(key, "kont") == 0) {
                            if (val.type == VAL_STRING)
                                custom_source = val.str_val;
                        }
                        else if (strcmp(key, "hint") == 0) {
                            if (val.type == VAL_STRING)
                                hint = val.str_val;  // 暂未使用，但保留
                        }
                        else if (strcmp(key, "rueck") == 0 || strcmp(key, "level") == 0) {
                            if (val.type == VAL_INT || val.type == VAL_INT64) {
                                level = (int)value_to_ll(val);
                                has_level = true;
                                if (level < 0) level = 0;
                            }
                        }
                    }
                    if (msg.empty()) {
                        kr_error("KRWarn 对象参数缺少 'msg' 字段");
                    }
                } else {
                    // ---------- 顺序模式 ----------
                    char* msg_cstr = value_to_string(args[0]);
                    msg = msg_cstr;
                    free(msg_cstr);

                    if (arg_count >= 2) {
                        if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                            kr_error("KRWarn 第 2 个参数必须是整数（行号）");
                        line = (int)value_to_ll(args[1]);

                        if (arg_count >= 3) {
                            if (args[2].type != VAL_INT && args[2].type != VAL_INT64)
                                kr_error("KRWarn 第 3 个参数必须是整数（列号）");
                            col = (int)value_to_ll(args[2]);

                            if (arg_count >= 4) {
                                if (args[3].type != VAL_STRING)
                                    kr_error("KRWarn 第 4 个参数必须是字符串（文件名）");
                                filename = args[3].str_val;
                            }
                        }
                    }
                    // 顺序模式不支持 hint 和 kont
                }

                // ---- 处理回退层级（覆盖位置信息） ----
                if (has_level && level > 0) {
                    std::vector<size_t> valid_indices;
                    for (size_t i = 0; i < g_call_stack.size(); ++i) {
                        const CallFrame& frame = g_call_stack[i];
                        if (frame.line > 0 && frame.col > 0 &&
                            frame.filename && frame.filename[0] != '\0' &&
                            strcmp(frame.filename, "-") != 0) {
                            valid_indices.push_back(i);
                        }
                    }
                    if (!valid_indices.empty()) {
                        int idx = (int)valid_indices.size() - 1 - level;
                        if (idx < 0) idx = 0;
                        size_t real_idx = valid_indices[idx];
                        const CallFrame& frame = g_call_stack[real_idx];
                        line = frame.line;
                        col = frame.col;
                        // 通过行列查找文件名（优先从映射获取）
                        const char* fname = find_filename_by_line_col(line, col);
                        if (fname) {
                            filename = fname;
                        } else {
                            filename = frame.filename;
                        }
                    }
                }

                // ---- 设置线程局部变量（用于 kr_warn） ----
                if (line > 0) g_last_error_line = line;
                if (col > 0) g_last_error_col = col;
                if (!filename.empty()) {
                    static thread_local std::string filename_storage;
                    filename_storage = filename;
                    current_filename = filename_storage.c_str();
                    g_last_error_filename = filename_storage.c_str();
                }
                if (!custom_source.empty()) {
                    g_custom_source_context = custom_source;
                }

                // ---- 强制启用警告并调用 kr_warn ----
                bool old_warn = g_warnings_enabled;
                g_warnings_enabled = true;
                kr_warn("%s", msg.c_str());
                g_warnings_enabled = old_warn;

                // ---- 清理自定义上下文（避免影响后续） ----
                if (!custom_source.empty()) {
                    g_custom_source_context.clear();
                }

                result = make_null();
                break;
            }
            else if (fh == "typist"_h) {
                if (arg_count != 1) kr_error("typist 需要且仅需要 1 个参数");
                Value& v = args[0];

                if (v.type == VAL_OBJECT) {
                    // ---- 检测枚举变体（存在 __tag） ----
                    bool is_enum = false;
                    std::string tag;
                    for (int i = 0; i < v.obj_val.count; ++i) {
                        if (strcmp(v.obj_val.entries[i].key, "__tag") == 0 &&
                            v.obj_val.entries[i].value.type == VAL_STRING) {
                            tag = v.obj_val.entries[i].value.str_val;
                            is_enum = true;
                            break;
                        }
                    }
                    if (is_enum) {
                        ObjectEntry entries[2];
                        entries[0].key = strdup("typ");
                        entries[0].value = make_string("aufz");
                        entries[1].key = strdup("aufz");
                        entries[1].value = make_string(tag.c_str());
                        Value obj = make_object(entries, 2);
                        // 释放临时条目（make_object 已深拷贝）
                        free(entries[0].key); free_value(&entries[0].value);
                        free(entries[1].key); free_value(&entries[1].value);
                        result = obj;
                        break;
                    }

                    // ---- 检测类实例（存在 __klass） ----
                    bool is_class = false;
                    for (int i = 0; i < v.obj_val.count; ++i) {
                        if (strcmp(v.obj_val.entries[i].key, "__klass") == 0) {
                            is_class = true;
                            break;
                        }
                    }
                    if (is_class) {
                        std::string klass_name;
                        for (int i = 0; i < v.obj_val.count; ++i) {
                            if (strcmp(v.obj_val.entries[i].key, "__klass") == 0 &&
                                v.obj_val.entries[i].value.type == VAL_STRING) {
                                klass_name = v.obj_val.entries[i].value.str_val;
                                break;
                            }
                        }
                        ObjectEntry entries[2];
                        entries[0].key = strdup("typ");
                        entries[0].value = make_string("objekt");
                        entries[1].key = strdup("klass");
                        entries[1].value = make_string(klass_name.c_str());
                        Value obj = make_object(entries, 2);
                        free(entries[0].key); free_value(&entries[0].value);
                        free(entries[1].key); free_value(&entries[1].value);
                        result = obj;
                        break;
                    }
                }

                // 其他类型仍返回字符串（保持向后兼容）
                std::string type_name = value_type_to_string(v);
                result = make_string(type_name.c_str());
                break;
            }
            else if (fh == "gtyp"_h) {
                if (arg_count != 1) kr_error("gtyp 需要且仅需要 1 个参数");
                Value& v = args[0];
                std::string type_name = basic_value_type_to_string(v);
                result = make_string(type_name.c_str());
                break;
            }
            else if (fh == "KRKom"_h) {
                // 参数校验
                if (arg_count != 3)
                    kr_error("KRKom 需要 3 个参数: 文件名, 共享作用域(布尔), 代码字符串");
                if (args[0].type != VAL_STRING)
                    kr_error("KRKom 第一个参数必须是文件名(字符串)");
                if (args[1].type != VAL_INT && args[1].type != VAL_INT64)
                    kr_error("KRKom 第二个参数必须是布尔值(0 或 1)");
                if (args[2].type != VAL_STRING)
                    kr_error("KRKom 第三个参数必须是代码字符串");

                bool share = value_to_bool(args[1]) != 0;
                const char* filename = args[0].str_val;
                const char* code = args[2].str_val;

                struct ContextGuard {
                    // 保存的旧状态
                    const char* old_filename;
                    char* old_source;
                    int old_line, old_col;
                    Token* saved_tokens;
                    int saved_token_count;
                    int saved_tok_pos;
                    int saved_last_token_line, saved_last_token_col;
                    int saved_stmt_start_line, saved_stmt_start_col;
                    Scope* old_scope;
                    bool old_return, old_break, old_continue, old_exception;
                    Value old_return_val, old_exception_val;
                    std::map<int, std::string> old_line_to_file;
                    Value* old_return_slot;
                    bool shared;                     // 存储共享模式标志
                
                    // 构造：保存所有上下文并建立新环境
                    ContextGuard(const char* new_filename, const char* new_code, bool share)
                        : old_filename(current_filename),
                        old_source(source_code),
                        old_line(g_last_error_line),
                        old_col(g_last_error_col),
                        saved_tokens(tokens),
                        saved_token_count(token_count),
                        saved_tok_pos(tok_pos),
                        saved_last_token_line(g_last_token_line),
                        saved_last_token_col(g_last_token_col),
                        saved_stmt_start_line(g_stmt_start_line),
                        saved_stmt_start_col(g_stmt_start_col),
                        old_scope(current_scope),
                        old_return(return_caught),
                        old_break(break_caught),
                        old_continue(continue_caught),
                        old_exception(exception_raised),
                        old_return_val(copy_value(return_value)),
                        old_exception_val(copy_value(exception_value)),
                        old_line_to_file(g_line_to_file),
                        old_return_slot(g_current_return_slot),
                        shared(share)
                    {
                        static std::string filename_storage;
                        filename_storage = new_filename;
                        current_filename = filename_storage.c_str();
                        g_custom_source_context = new_code;
                
                        g_last_error_line = 1;
                        g_last_error_col = 1;
                
                        return_caught = false;
                        break_caught = false;
                        continue_caught = false;
                        exception_raised = false;
                
                        source_code = strdup(new_code);
                
                        if (!shared) {
                            push_scope();       // 非共享模式创建新作用域
                        }
                    }
                
                    // 析构：恢复所有上下文
                    ~ContextGuard() {
                        // 恢复源码
                        if (source_code && source_code != old_source) {
                            free(source_code);
                        }
                        source_code = old_source;
                
                        current_filename = old_filename;
                        g_custom_source_context.clear();
                
                        g_last_error_line = old_line;
                        g_last_error_col = old_col;
                
                        // 释放当前 tokens（如果与新 tokens 不同）
                        if (tokens != saved_tokens) {
                            free_tokens();
                        }
                        tokens = saved_tokens;
                        token_count = saved_token_count;
                        tok_pos = saved_tok_pos;
                        g_last_token_line = saved_last_token_line;
                        g_last_token_col = saved_last_token_col;
                        g_stmt_start_line = saved_stmt_start_line;
                        g_stmt_start_col = saved_stmt_start_col;
                
                        g_line_to_file = old_line_to_file;
                
                        // 恢复作用域：非共享模式下弹出新建的作用域
                        if (!shared) {
                            if (current_scope != old_scope) {
                                pop_scope();
                            }
                        }
                        current_scope = old_scope;
                
                        // 恢复控制标志
                        return_caught = old_return;
                        break_caught = old_break;
                        continue_caught = old_continue;
                        exception_raised = old_exception;
                
                        free_value(&return_value);
                        return_value = copy_value(old_return_val);
                        free_value(&exception_value);
                        exception_value = copy_value(old_exception_val);
                
                        g_current_return_slot = old_return_slot;
                
                        free_value(&old_return_val);
                        free_value(&old_exception_val);
                    }
                };

                Value result_val = make_null();

                // ---- 使用作用域（RAII）自动管理上下文 ----
                {
                    ContextGuard guard(filename, code, share);

                    tokenize_impl(code);
                    ASTNode* ast = parse_program();

                    exec_statement(ast);

                    // 提取返回值（若 return_caught 被设置）
                    if (return_caught) {
                        result_val = copy_value(return_value);
                        return_caught = false;
                        free_value(&return_value);
                        return_value = make_null();
                    } else {
                        ASTNode* last = get_last_expr_from_block(ast);
                        if (last) {
                            result_val = eval_expr(last);
                        } else {
                            result_val = make_null();
                        }
                    }

                    // 清除可能残留的异常标志
                    if (exception_raised) {
                        free_value(&exception_value);
                        exception_raised = false;
                    }

                    free_ast(ast);
                    // tokens 会在 guard 析构时释放
                } // 此处 guard 析构，自动恢复所有上下文

                result = result_val;
                break;
            }
            else if (fh == "cpp"_h) {
                if (arg_count < 1) kr_error("cpp 需要至少 1 个参数（源码字符串）");
                if (args[0].type != VAL_STRING) kr_error("cpp 的第一个参数必须是字符串（C++ 源码）");

                bool run = true;
                long long timeout_ms = 5000;
                std::string compiler = "g++";
                std::string flags = "-std=c++17 -O2";
                bool json_mode = false;
                Value bind_obj = make_null();
                bool has_bind = false;

                // 解析选项对象
                if (arg_count >= 2) {
                    Value opts = args[1];
                    if (opts.type == VAL_OBJECT) {
                        for (int i = 0; i < opts.obj_val.count; ++i) {
                            const char* key = opts.obj_val.entries[i].key;
                            Value val = opts.obj_val.entries[i].value;
                            if (strcmp(key, "compiler") == 0 && val.type == VAL_STRING)
                                compiler = val.str_val;
                            else if (strcmp(key, "flags") == 0 && val.type == VAL_STRING)
                                flags = val.str_val;
                            else if (strcmp(key, "timeout") == 0)
                                timeout_ms = (long long)value_to_double(val);
                            else if (strcmp(key, "run") == 0)
                                run = value_to_bool(val) != 0;
                            else if (strcmp(key, "mode") == 0 && val.type == VAL_STRING) {
                                if (strcmp(val.str_val, "json") == 0) json_mode = true;
                            }
                            else if (strcmp(key, "bind") == 0) {
                                bind_obj = copy_value(val);
                                has_bind = true;
                            }
                        }
                    } else {
                        kr_warn("cpp 第二个参数应为对象，忽略");
                    }
                }

                // ----- 构建 JSON 辅助库源码（C++ 内嵌） -----
                const char* json_helper = R"(
                    #include <iostream>
                    #include <fstream>
                    #include <sstream>
                    #include <map>
                    #include <vector>
                    #include <variant>
                    #include <string>
                    #include <stdexcept>
                    #include <cctype>
                    
                    class JSON {
                    public:
                        using Object = std::map<std::string, JSON>;
                        using Array = std::vector<JSON>;
                        using Value = std::variant<std::nullptr_t, bool, long long, double, std::string, Object, Array>;
                    
                        JSON() : val_(nullptr) {}
                        JSON(std::nullptr_t) : val_(nullptr) {}
                        JSON(bool b) : val_(b) {}
                        JSON(long long i) : val_(i) {}
                        explicit JSON(double d) : val_(d) {}  // explicit to avoid int ambiguity
                        JSON(const std::string& s) : val_(s) {}
                        JSON(const char* s) : val_(std::string(s)) {}
                        JSON(const Object& o) : val_(o) {}
                        JSON(const Array& a) : val_(a) {}
                    
                        static JSON parse(const std::string& str) {
                            size_t pos = 0;
                            return parse_value(str, pos);
                        }
                    
                        static JSON parse_from_file(const std::string& path) {
                            std::ifstream ifs(path);
                            if (!ifs) throw std::runtime_error("Cannot open " + path);
                            std::stringstream ss; ss << ifs.rdbuf();
                            return parse(ss.str());
                        }
                    
                        std::string serialize() const {
                            return serialize_value(*this, 0);
                        }
                    
                        bool is_null() const { return std::holds_alternative<std::nullptr_t>(val_); }
                        bool is_bool() const { return std::holds_alternative<bool>(val_); }
                        bool is_int() const { return std::holds_alternative<long long>(val_); }
                        bool is_double() const { return std::holds_alternative<double>(val_); }
                        bool is_string() const { return std::holds_alternative<std::string>(val_); }
                        bool is_object() const { return std::holds_alternative<Object>(val_); }
                        bool is_array() const { return std::holds_alternative<Array>(val_); }
                    
                        bool as_bool() const { return std::get<bool>(val_); }
                        long long as_int() const { return std::get<long long>(val_); }
                        double as_double() const { return std::get<double>(val_); }
                        std::string as_string() const { return std::get<std::string>(val_); }
                        Object as_object() const { return std::get<Object>(val_); }
                        Array as_array() const { return std::get<Array>(val_); }
                    
                        JSON& operator[](const std::string& key) {
                            if (!is_object()) val_ = Object{};
                            return std::get<Object>(val_)[key];
                        }
                    
                        JSON& operator[](size_t idx) {
                            if (!is_array()) val_ = Array{};
                            auto& arr = std::get<Array>(val_);
                            if (idx >= arr.size()) arr.resize(idx + 1);
                            return arr[idx];
                        }
                    
                    private:
                        Value val_;
                    
                        static void skip_ws(const std::string& s, size_t& pos) {
                            while (pos < s.size() && std::isspace(s[pos])) ++pos;
                        }
                    
                        static JSON parse_value(const std::string& s, size_t& pos) {
                            skip_ws(s, pos);
                            if (pos >= s.size()) throw std::runtime_error("Unexpected EOF");
                            char c = s[pos];
                            if (c == 'n') {
                                if (s.compare(pos, 4, "null") == 0) { pos += 4; return JSON(nullptr); }
                                throw std::runtime_error("Expected null");
                            } else if (c == 't') {
                                if (s.compare(pos, 4, "true") == 0) { pos += 4; return JSON(true); }
                                throw std::runtime_error("Expected true");
                            } else if (c == 'f') {
                                if (s.compare(pos, 5, "false") == 0) { pos += 5; return JSON(false); }
                                throw std::runtime_error("Expected false");
                            } else if (c == '"') {
                                ++pos;
                                std::string str;
                                while (pos < s.size() && s[pos] != '"') {
                                    if (s[pos] == '\\') {
                                        ++pos;
                                        if (pos >= s.size()) throw std::runtime_error("Invalid escape");
                                        char esc = s[pos++];
                                        switch (esc) {
                                            case '"':  str += '"'; break;
                                            case '\\': str += '\\'; break;
                                            case '/':  str += '/'; break;
                                            case 'b':  str += '\b'; break;
                                            case 'f':  str += '\f'; break;
                                            case 'n':  str += '\n'; break;
                                            case 'r':  str += '\r'; break;
                                            case 't':  str += '\t'; break;
                                            case 'u': {
                                                if (pos + 4 > s.size()) throw std::runtime_error("Invalid unicode");
                                                std::string hex = s.substr(pos, 4);
                                                pos += 4;
                                                unsigned int code = std::stoul(hex, nullptr, 16);
                                                if (code < 0x80) str += char(code);
                                                else if (code < 0x800) {
                                                    str += char(0xC0 | (code >> 6));
                                                    str += char(0x80 | (code & 0x3F));
                                                } else {
                                                    str += char(0xE0 | (code >> 12));
                                                    str += char(0x80 | ((code >> 6) & 0x3F));
                                                    str += char(0x80 | (code & 0x3F));
                                                }
                                                break;
                                            }
                                            default: throw std::runtime_error("Unknown escape");
                                        }
                                    } else {
                                        str += s[pos++];
                                    }
                                }
                                if (pos >= s.size() || s[pos] != '"') throw std::runtime_error("Unterminated string");
                                ++pos;
                                return JSON(str);
                            } else if (c == '{') {
                                ++pos;
                                Object obj;
                                skip_ws(s, pos);
                                if (pos < s.size() && s[pos] == '}') { ++pos; return JSON(obj); }
                                while (true) {
                                    if (pos >= s.size()) throw std::runtime_error("Unterminated object");
                                    JSON key = parse_value(s, pos);
                                    if (!key.is_string()) throw std::runtime_error("Object key must be string");
                                    skip_ws(s, pos);
                                    if (pos >= s.size() || s[pos] != ':') throw std::runtime_error("Expected ':'");
                                    ++pos;
                                    JSON val = parse_value(s, pos);
                                    obj[key.as_string()] = val;
                                    skip_ws(s, pos);
                                    if (pos >= s.size()) throw std::runtime_error("Unterminated object");
                                    if (s[pos] == ',') { ++pos; continue; }
                                    else if (s[pos] == '}') { ++pos; break; }
                                    else throw std::runtime_error("Expected ',' or '}'");
                                }
                                return JSON(obj);
                            } else if (c == '[') {
                                ++pos;
                                Array arr;
                                skip_ws(s, pos);
                                if (pos < s.size() && s[pos] == ']') { ++pos; return JSON(arr); }
                                while (true) {
                                    JSON val = parse_value(s, pos);
                                    arr.push_back(val);
                                    skip_ws(s, pos);
                                    if (pos >= s.size()) throw std::runtime_error("Unterminated array");
                                    if (s[pos] == ',') { ++pos; continue; }
                                    else if (s[pos] == ']') { ++pos; break; }
                                    else throw std::runtime_error("Expected ',' or ']'");
                                }
                                return JSON(arr);
                            } else if (c == '-' || std::isdigit(c)) {
                                size_t start = pos;
                                if (c == '-') ++pos;
                                while (pos < s.size() && std::isdigit(s[pos])) ++pos;
                                bool is_float = false;
                                if (pos < s.size() && s[pos] == '.') { ++pos; while (pos < s.size() && std::isdigit(s[pos])) ++pos; is_float = true; }
                                if (pos < s.size() && (s[pos] == 'e' || s[pos] == 'E')) {
                                    ++pos;
                                    if (pos < s.size() && (s[pos] == '+' || s[pos] == '-')) ++pos;
                                    while (pos < s.size() && std::isdigit(s[pos])) ++pos;
                                    is_float = true;
                                }
                                std::string num = s.substr(start, pos - start);
                                if (is_float) return JSON(std::stod(num)); // explicit double constructor called
                                else return JSON(std::stoll(num));
                            } else {
                                throw std::runtime_error("Unexpected character");
                            }
                        }
                    
                        static std::string serialize_value(const JSON& val, int indent) {
                            std::string indent_str(indent, ' ');
                            std::string result;
                            if (val.is_null()) result = "null";
                            else if (val.is_bool()) result = val.as_bool() ? "true" : "false";
                            else if (val.is_int()) result = std::to_string(val.as_int());
                            else if (val.is_double()) {
                                std::string s = std::to_string(val.as_double());
                                // 移除多余的零
                                if (s.find('.') != std::string::npos) {
                                    while (s.size() > 1 && s.back() == '0') s.pop_back();
                                    if (s.back() == '.') s.pop_back();
                                }
                                result = s;
                            } else if (val.is_string()) {
                                result = "\"" + escape_string(val.as_string()) + "\"";
                            } else if (val.is_object()) {
                                result = "{";
                                const auto& obj = std::get<Object>(val.val_);
                                bool first = true;
                                for (const auto& pair : obj) {
                                    if (!first) result += ",";
                                    if (indent >= 0) result += "\n" + indent_str + "  ";
                                    else result += " ";
                                    result += "\"" + escape_string(pair.first) + "\":" + (indent >= 0 ? " " : "");
                                    result += serialize_value(pair.second, indent >= 0 ? indent + 2 : -1);
                                    first = false;
                                }
                                if (indent >= 0 && !obj.empty()) result += "\n" + indent_str;
                                result += "}";
                            } else if (val.is_array()) {
                                result = "[";
                                const auto& arr = std::get<Array>(val.val_);
                                for (size_t i = 0; i < arr.size(); ++i) {
                                    if (i > 0) result += ",";
                                    if (indent >= 0) result += "\n" + indent_str + "  ";
                                    else result += " ";
                                    result += serialize_value(arr[i], indent >= 0 ? indent + 2 : -1);
                                }
                                if (indent >= 0 && !arr.empty()) result += "\n" + indent_str;
                                result += "]";
                            }
                            return result;
                        }
                    
                        static std::string escape_string(const std::string& s) {
                            std::string out;
                            for (char c : s) {
                                switch (c) {
                                    case '"':  out += "\\\""; break;
                                    case '\\': out += "\\\\"; break;
                                    case '\b': out += "\\b"; break;
                                    case '\f': out += "\\f"; break;
                                    case '\n': out += "\\n"; break;
                                    case '\r': out += "\\r"; break;
                                    case '\t': out += "\\t"; break;
                                    default:
                                        if (static_cast<unsigned char>(c) < 0x20) {
                                            char buf[7];
                                            snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                                            out += buf;
                                        } else out += c;
                                }
                            }
                            return out;
                        }
                    };
                )";

                const char* kr_helper = R"(
                    namespace KR {
                        inline JSON get(const JSON& input, const std::string& name) {
                            if (input.is_object()) {
                                auto obj = input.as_object();
                                auto it = obj.find(name);
                                if (it != obj.end()) return it->second;
                            }
                            return JSON(nullptr);
                        }

                        inline void set(JSON& output, const std::string& name, long long value) {
                            output["__kr_set"][name] = JSON(value);
                        }
                        inline void set(JSON& output, const std::string& name, double value) {
                            output["__kr_set"][name] = JSON(value);
                        }
                        inline void set(JSON& output, const std::string& name, const char* value) {
                            output["__kr_set"][name] = JSON(value);
                        }
                        inline void set(JSON& output, const std::string& name, const std::string& value) {
                            output["__kr_set"][name] = JSON(value);
                        }
                        inline void set(JSON& output, const std::string& name, const JSON& value) {
                            output["__kr_set"][name] = value;
                        }
                        inline void set(JSON& output, const std::string& name, int value) {
                            set(output, name, static_cast<long long>(value));
                        }
                    }
                )";

                // 生成临时文件名
                static std::atomic<int> counter{0};
                auto now = std::chrono::steady_clock::now().time_since_epoch().count();
                std::string base_name = "kr_cpp_" + std::to_string(now) + "_" + std::to_string(counter++);

            #ifdef _WIN32
                std::string exe_suffix = ".exe";
            #else
                std::string exe_suffix = "";
            #endif

                fs::path temp_dir = fs::temp_directory_path();
                fs::path src_path = temp_dir / (base_name + ".cpp");
                fs::path exe_path = temp_dir / (base_name + exe_suffix);
                fs::path out_path = temp_dir / (base_name + ".out");
                fs::path err_path = temp_dir / (base_name + ".err");
                fs::path input_path = temp_dir / (base_name + ".json");

                // 如果启用 JSON 模式且提供了 bind，则将 bind 对象序列化为 JSON 写入临时文件
                if (json_mode && has_bind) {
                    std::string json_str = json_stringify_value(bind_obj, false, 0);
                    std::ofstream ifs(input_path.string());
                    if (!ifs) kr_error("无法创建临时 JSON 输入文件");
                    ifs << json_str;
                    ifs.close();
                }

                std::string user_code(args[0].str_val, args[0].str_len);
                std::string source_code = std::string(json_helper) + "\n" + kr_helper + "\n\n" + user_code;

                // 写入源码文件
                std::ofstream src_file(src_path.string(), std::ios::binary);
                if (!src_file) kr_error("无法创建临时源码文件");
                src_file << source_code;
                src_file.close();

                // 编译命令（添加 -I 路径指向我们提供的 JSON 头文件，或直接嵌入源码）
                std::string compile_cmd = compiler + " " + flags + " " + src_path.string() + " -o " + exe_path.string() + " 2>" + err_path.string();
                int compile_ret = std::system(compile_cmd.c_str());

                // 读取编译错误
                std::string stderr_content;
                std::ifstream err_file(err_path.string());
                if (err_file) {
                    std::stringstream ss;
                    ss << err_file.rdbuf();
                    stderr_content = ss.str();
                    err_file.close();
                }

                if (compile_ret != 0) {
                    // 编译失败，返回错误对象
                    ObjectEntry entries[3];
                    entries[0].key = strdup("ok");
                    entries[0].value = make_int(0LL);
                    entries[1].key = strdup("code");
                    entries[1].value = make_int(compile_ret);
                    entries[2].key = strdup("fehl");
                    entries[2].value = make_string(stderr_content.c_str());
                    result = make_object(entries, 3);
                    // 清理
                    std::remove(src_path.string().c_str());
                    std::remove(exe_path.string().c_str());
                    std::remove(out_path.string().c_str());
                    std::remove(err_path.string().c_str());
                    std::remove(input_path.string().c_str());
                    break;
                }

                // 如果 run 为 false，仅编译成功
                if (!run) {
                    ObjectEntry entries[3];
                    entries[0].key = strdup("ok");
                    entries[0].value = make_int(1LL);
                    entries[1].key = strdup("code");
                    entries[1].value = make_int(0LL);
                    entries[2].key = strdup("fehl");
                    entries[2].value = make_string(stderr_content.c_str());
                    result = make_object(entries, 3);
                    // 清理
                    std::remove(src_path.string().c_str());
                    std::remove(exe_path.string().c_str());
                    std::remove(out_path.string().c_str());
                    std::remove(err_path.string().c_str());
                    std::remove(input_path.string().c_str());
                    break;
                }

                // 运行程序
                std::string run_cmd = exe_path.string();
                if (json_mode && has_bind) {
                    // 将输入文件路径作为参数
                    run_cmd += " " + input_path.string();
                }
                run_cmd += " > " + out_path.string() + " 2> " + err_path.string();

                auto future = std::async(std::launch::async, [&]() -> int {
                    return std::system(run_cmd.c_str());
                });

                int exit_code = -1;
                bool timeout = false;
                if (timeout_ms > 0) {
                    auto status = future.wait_for(std::chrono::milliseconds(timeout_ms));
                    if (status == std::future_status::timeout) {
                        timeout = true;
                        exit_code = -1;
                    } else {
                        exit_code = future.get();
                    }
                } else {
                    exit_code = future.get();
                }

                // 读取输出和错误
                std::string stdout_content, stderr_content2;
                std::ifstream out_file(out_path.string());
                if (out_file) {
                    std::stringstream ss;
                    ss << out_file.rdbuf();
                    stdout_content = ss.str();
                    out_file.close();
                }
                std::ifstream err_file2(err_path.string());
                if (err_file2) {
                    std::stringstream ss;
                    ss << err_file2.rdbuf();
                    stderr_content2 = ss.str();
                    err_file2.close();
                }

                // 清理临时文件
                std::remove(src_path.string().c_str());
                std::remove(exe_path.string().c_str());
                std::remove(out_path.string().c_str());
                std::remove(err_path.string().c_str());
                std::remove(input_path.string().c_str());

                // 构造返回值
                if (json_mode && exit_code == 0 && !timeout) {
                    // 尝试将 stdout 解析为 JSON
                    try {
                        JSONParser parser(stdout_content);
                        Value json_val = parser.parse();
                        // 检查是否有 __kr_set
                        if (json_val.type == VAL_OBJECT) {
                            for (int i = 0; i < json_val.obj_val.count; ++i) {
                                if (strcmp(json_val.obj_val.entries[i].key, "__kr_set") == 0) {
                                    Value set_obj = json_val.obj_val.entries[i].value;
                                    if (set_obj.type == VAL_OBJECT) {
                                        for (int j = 0; j < set_obj.obj_val.count; ++j) {
                                            const char* varname = set_obj.obj_val.entries[j].key;
                                            Value varval = copy_value(set_obj.obj_val.entries[j].value);
                                            // 在当前作用域设置变量（如果存在则赋值，否则声明）
                                            Variable* var = get_var(varname, false);
                                            if (var) {
                                                if (var->is_const) kr_error("常量 '%s' 不能通过 cpp 修改", varname);
                                                free_value(&var->value);
                                                var->value = varval;
                                            } else {
                                                declare_var(varname, false, varval);
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                            // 移除 __kr_set 键（为了干净返回）
                            ObjectEntry* new_entries = nullptr;
                            int new_count = 0;
                            for (int i = 0; i < json_val.obj_val.count; ++i) {
                                if (strcmp(json_val.obj_val.entries[i].key, "__kr_set") != 0) {
                                    new_entries = (ObjectEntry*)realloc(new_entries, (new_count + 1) * sizeof(ObjectEntry));
                                    new_entries[new_count].key = strdup(json_val.obj_val.entries[i].key);
                                    new_entries[new_count].value = copy_value(json_val.obj_val.entries[i].value);
                                    new_count++;
                                }
                            }
                            // 释放原对象（注意：释放时不会释放 new_entries，因为那是新的）
                            free_value(&json_val);
                            Value clean_obj = make_object(new_entries, new_count);
                            // 释放临时 new_entries（make_object 已复制）
                            for (int i = 0; i < new_count; ++i) {
                                free(new_entries[i].key);
                                free_value(&new_entries[i].value);
                            }
                            free(new_entries);
                            result = clean_obj;
                        } else {
                            result = json_val;
                        }
                    } catch (const KRError& e) {
                        // JSON 解析失败，返回包含错误信息的对象
                        ObjectEntry entries[4];
                        entries[0].key = strdup("ok");
                        entries[0].value = make_int(0LL);
                        entries[1].key = strdup("code");
                        entries[1].value = make_int(exit_code);
                        entries[2].key = strdup("fehl");
                        entries[2].value = make_string(("JSON 解析失败: " + std::string(e.what())).c_str());
                        entries[3].key = strdup("out");
                        entries[3].value = make_string(stdout_content.c_str());
                        result = make_object(entries, 4);
                        free(entries[0].key); free_value(&entries[0].value);
                        free(entries[1].key); free_value(&entries[1].value);
                        free(entries[2].key); free_value(&entries[2].value);
                        free(entries[3].key); free_value(&entries[3].value);
                    }
                } else {
                    // 普通模式或运行失败
                    ObjectEntry entries[4];
                    entries[0].key = strdup("ok");
                    entries[0].value = make_int((exit_code == 0 && !timeout) ? 1LL : 0LL);
                    entries[1].key = strdup("code");
                    entries[1].value = make_int(exit_code);
                    entries[2].key = strdup("fehl");
                    entries[2].value = make_string((timeout ? "超时" : stderr_content2).c_str());
                    entries[3].key = strdup("erg");
                    entries[3].value = make_string(stdout_content.c_str());
                    result = make_object(entries, 4);
                    for (int i = 0; i < 4; ++i) {
                        free(entries[i].key);
                        free_value(&entries[i].value);
                    }
                }
                break;
            }
            else if (strcmp(fname, "asm") == 0) {
                // 1. 参数检查
                if (arg_count < 1) kr_error("asm benötigt mindestens 1 Argument (Assembler-Code)");
                if (args[0].type != VAL_STRING) kr_error("asm erster Parameter muss ein String sein");

                std::string asm_code = args[0].str_val;

                // 2. 生成临时文件名（使用原子计数器避免冲突）
                static std::atomic<int> counter{0};
                auto now = std::chrono::steady_clock::now().time_since_epoch().count();
                std::string base_name = "kr_asm_" + std::to_string(now) + "_" + std::to_string(counter++);
                fs::path temp_dir = fs::temp_directory_path();
                fs::path src_path = temp_dir / (base_name + ".asm");
                fs::path bin_path = temp_dir / (base_name + ".bin");

                // 3. 写入汇编源文件
                std::ofstream src_file(src_path.string());
                if (!src_file) kr_error("无法创建临时汇编文件");
                src_file << asm_code;
                src_file.close();

                // 4. 调用 nasm 编译为纯二进制（-f bin）
                std::string compile_cmd = "nasm -f bin -o " + bin_path.string() + " " + src_path.string() + " 2>&1";
                int ret = std::system(compile_cmd.c_str());
                if (ret != 0) {
                    std::remove(src_path.string().c_str());
                    kr_error("nasm 编译失败 (返回码 %d)，请确保 nasm 已安装并在 PATH 中", ret);
                }

                // 5. 读取生成的二进制机器码
                std::ifstream bin_file(bin_path.string(), std::ios::binary | std::ios::ate);
                if (!bin_file) {
                    std::remove(src_path.string().c_str());
                    std::remove(bin_path.string().c_str());
                    kr_error("无法读取生成的二进制文件");
                }
                std::streamsize size = bin_file.tellg();
                if (size <= 0) {
                    bin_file.close();
                    std::remove(src_path.string().c_str());
                    std::remove(bin_path.string().c_str());
                    kr_error("生成的二进制文件为空");
                }
                bin_file.seekg(0, std::ios::beg);
                std::vector<unsigned char> code((size_t)size);
                bin_file.read(reinterpret_cast<char*>(code.data()), size);
                bin_file.close();

                // 6. 清理临时文件
                std::remove(src_path.string().c_str());
                std::remove(bin_path.string().c_str());

                // 7. 分配可执行内存并运行（与 BC 相同逻辑）
                void* exec_mem = nullptr;
            #ifdef _WIN32
                exec_mem = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
                if (!exec_mem) kr_error("VirtualAlloc fehlgeschlagen");
            #else
                exec_mem = mmap(NULL, size, PROT_READ | PROT_WRITE | PROT_EXEC,
                                MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
                if (exec_mem == MAP_FAILED) kr_error("mmap fehlgeschlagen");
            #endif
                memcpy(exec_mem, code.data(), size);
            #ifdef __GNUC__
                __builtin___clear_cache((char*)exec_mem, (char*)exec_mem + size);
            #endif

                typedef int (*func_t)(void);
                func_t f = (func_t)exec_mem;
                int result_val = f();   // 执行汇编代码，返回值在 eax/rax 中

            #ifdef _WIN32
                VirtualFree(exec_mem, 0, MEM_RELEASE);
            #else
                munmap(exec_mem, size);
            #endif

                // 8. 返回结果
                result = make_int((long long)result_val);
                break;
            }

            auto variant_it = variant_table.find(fname);
            if (variant_it != variant_table.end()) {
                int expected_param_count = variant_it->second.second;  // 参数个数
                if (arg_count != expected_param_count) {
                    kr_error("枚举变体 %s 需要 %d 个参数，实际 %d", fname, expected_param_count, arg_count);
                }

                // 构造 __tag 和 __felder
                ObjectEntry entries[2];
                entries[0].key = strdup("__tag");
                entries[0].value = make_string(fname);

                entries[1].key = strdup("__felder");
                Value* field_vals = (Value*)malloc(arg_count * sizeof(Value));
                for (int i = 0; i < arg_count; i++) {
                    field_vals[i] = copy_value(args[i]);  // args 是已求值参数
                }
                entries[1].value = make_array(field_vals, arg_count);
                free(field_vals);

                result = make_object(entries, 2);

                // 释放临时 entries（make_object 已复制内容）
                for (int i = 0; i < 2; i++) {
                    free(entries[i].key);
                    free_value(&entries[i].value);
                }
                break;  // 跳出 case NODE_FUNC_CALL
            }
            else if (strcmp(fname, "va") == 0) {
                if (arg_count != 1)
                    kr_error("va 需要 1 个参数（代码字符串）");
                if (args[0].type != VAL_STRING || args[0].str_val == nullptr)
                    kr_error("va 参数必须是字符串");

                // 空字符串：直接跳过，不做任何事
                if (args[0].str_len == 0) {
                    break;
                }

                std::string arg_str(args[0].str_val, args[0].str_len);

                // 生成临时文件名
                static std::atomic<int> counter{0};
                auto now = std::chrono::steady_clock::now().time_since_epoch().count();
                std::string base_name = "kr_va_" + std::to_string(now) + "_" + std::to_string(counter++);
                fs::path temp_dir = fs::temp_directory_path();
                fs::path va_file = temp_dir / (base_name + ".va");

                // 写入代码文件
                std::ofstream ofs(va_file.string(), std::ios::binary);
                if (!ofs) kr_error("无法创建临时 VA 文件");
                ofs << arg_str;
                ofs.close();

                // 构建命令
                std::string cmd = "va \"" + va_file.string() + "\"";
                Value result_val = run_command_and_capture(cmd);

                long long exit_code = value_to_ll(result_val.obj_val.entries[0].value);
                bool use_fallback = false;
                if (exit_code != 0 && result_val.obj_val.count > 2) {
                    Value err_val = result_val.obj_val.entries[2].value;
                    if (err_val.type == VAL_STRING) {
                        std::string err_msg = err_val.str_val;
                        if (err_msg.find("not found") != std::string::npos ||
                            err_msg.find("not recognized") != std::string::npos ||
                            err_msg.find("No such file") != std::string::npos) {
                            use_fallback = true;
                        }
                    }
                }

                if (use_fallback) {
                    fs::path va_path = exe_dir / "va" / "va";
            #ifdef _WIN32
                    va_path.replace_extension(".exe");
            #endif
                    if (fs::exists(va_path)) {
                        std::string fallback_cmd = "\"" + va_path.string() + "\" \"" + va_file.string() + "\"";
                        free_value(&result_val);
                        result_val = run_command_and_capture(fallback_cmd);
                    } else {
                        free_value(&result_val);
                        std::remove(va_file.string().c_str());
                        kr_error("找不到 va 程序，请确保 va 在 PATH 中或位于 %s", exe_dir.string().c_str());
                    }
                }

                // ---- 检查 va 是否异常终止 ----
                // 仅当进程系统级崩溃（段错误、访问冲突等）时才报错。
                // 其他非零退出码视为用户自定义返回值，正常返回给 Kernregel。
                {
                    long long final_exit = 0;
                    bool has_exit = false;
                    bool is_abnormal = false;
                    if (result_val.type == VAL_OBJECT && result_val.obj_val.count > 0) {
                        Value& code_val = result_val.obj_val.entries[0].value;
                        if (code_val.type == VAL_INT || code_val.type == VAL_INT64) {
                            final_exit = value_to_ll(code_val);
                            has_exit = true;
                        }
                        // 读取 run_command_and_capture 设置的 abnorm 标志
                        for (int i = 0; i < result_val.obj_val.count; i++) {
                            if (strcmp(result_val.obj_val.entries[i].key, "abnorm") == 0) {
                                Value& abn = result_val.obj_val.entries[i].value;
                                if (abn.type == VAL_INT || abn.type == VAL_INT64) {
                                    is_abnormal = value_to_ll(abn) != 0;
                                }
                                break;
                            }
                        }
                    }
                    // 只有系统级异常终止才抛错
                    if (has_exit && is_abnormal) {
                        std::string err_msg;
                        if (result_val.obj_val.count > 2 &&
                            result_val.obj_val.entries[2].value.type == VAL_STRING) {
                            err_msg.assign(result_val.obj_val.entries[2].value.str_val,
                                        result_val.obj_val.entries[2].value.str_len);
                        }
                        std::remove(va_file.string().c_str());
                        free_value(&result_val);
                        kr_error("va 异常终止（可能发生段错误或崩溃，退出码 %lld）%s%s",
                                final_exit,
                                err_msg.empty() ? "" : ": ", err_msg.c_str());
                    }
                }

                // 删除临时文件
                std::remove(va_file.string().c_str());

                result = result_val;
                break;
            }
        
            // ==================== 普通函数调用 ====================
            else {
                // ---- 0. 检查是否为未解析的类实例化（解析时类未加载） ----
                {
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    auto class_it = class_table.find(fname);
                    if (class_it != class_table.end()) {
                        ClassDef& cls = class_it->second;
                
                        // 获取期望参数个数
                        int expected = (int)cls.ctor_params.size();
                        int argc = node->data.func_call.arg_count;   // 原始参数个数（已求值）
                        if (argc > expected)
                            kr_error("构造函数参数过多: 期望 %d, 实际 %d", expected, argc);
                
                        // 检查缺失参数是否有默认值
                        for (int i = argc; i < expected; ++i) {
                            if (!cls.ctor_defaults[i])
                                kr_error("构造函数缺少参数 '%s' 且无默认值", cls.ctor_params[i].c_str());
                        }
                
                        // 构建完整参数值（实际参数 + 默认值）
                        Value* full_args = (Value*)malloc(expected * sizeof(Value));
                        for (int i = 0; i < expected; ++i) {
                            if (i < argc)
                                full_args[i] = copy_value(args[i]);   // args 已在 NODE_FUNC_CALL 中求值
                            else
                                full_args[i] = eval_expr(cls.ctor_defaults[i]);
                        }
                
                        // 参数类型检查（使用完整参数）
                        for (int i = 0; i < expected; ++i) {
                            TypeNode* expected_type = cls.ctor_param_types[i];
                            if (expected_type && !check_type(expected_type, full_args[i])) {
                                std::string expected_str = type_to_string(expected_type);
                                char* got = value_to_string(full_args[i]);
                                kr_error("构造函数参数 '%s' 类型错误: 期望 '%s', 实际 '%s'",
                                         cls.ctor_params[i].c_str(), expected_str.c_str(), got);
                            }
                        }
                
                        // ---- 创建对象并设置 __klass ----
                        Value obj;
                        obj.type = VAL_OBJECT;
                        obj.obj_val.count = 1;
                        obj.obj_val.entries = (ObjectEntry*)malloc(sizeof(ObjectEntry));
                        obj.obj_val.entries[0].key = strdup("__klass");
                        obj.obj_val.entries[0].value = make_string(class_it->first.c_str());
                
                        // ---- 初始化非静态属性（沿继承链，子类优先） ----
                        {
                            std::unordered_set<std::string> added;
                            std::vector<ClassDef*> chain;
                            std::string cur = fname;           // 注意这里用 fname
                            while (!cur.empty()) {
                                auto it2 = class_table.find(cur);
                                if (it2 == class_table.end()) break;
                                chain.push_back(&it2->second);
                                if (it2->second.parent.empty()) break;
                                cur = it2->second.parent;
                            }
                            for (ClassDef* c : chain) {
                                for (auto& prop : c->properties) {
                                    if (prop.is_static) continue;
                                    if (prop.is_lazy)   continue;
                                    if (added.count(prop.name)) continue;
                                    added.insert(prop.name);

                                    Value init_val;
                                    if (prop.default_expr) {
                                        init_val = eval_expr(prop.default_expr);
                                        if (prop.type && !check_type(prop.type, init_val)) {
                                            char* got = value_to_string(init_val);
                                            kr_error("属性 '%s' 初始化类型错误: 期望 '%s', 实际 '%s'",
                                                    prop.name.c_str(), type_to_string(prop.type).c_str(), got);
                                        }
                                    } else {
                                        init_val = prop.type
                                            ? eval_expr(make_default_value_for_type(prop.type))
                                            : make_null();
                                    }
                                    obj.obj_val.count++;
                                    obj.obj_val.entries = (ObjectEntry*)realloc(
                                        obj.obj_val.entries,
                                        obj.obj_val.count * sizeof(ObjectEntry));
                                    obj.obj_val.entries[obj.obj_val.count - 1].key
                                        = strdup(prop.name.c_str());
                                    obj.obj_val.entries[obj.obj_val.count - 1].value
                                        = copy_value(init_val);
                                    free_value(&init_val);
                                }
                            }
                        }
                
                        // ---- 执行构造函数（若存在） ----
                        if (cls.ctor_body) {
                            Value* old_constructed = current_constructed_obj;
                            current_constructed_obj = &obj;
                        
                            save_flags();
                            push_scope();
                            return_caught = false;
                            break_caught = false;
                            continue_caught = false;
                            exception_raised = false;
                        
                            // 设置类上下文
                            std::string old_class_str;
                            if (g_current_class_name) old_class_str = g_current_class_name;
                            g_current_class_name_str = fname;
                            g_current_class_name = g_current_class_name_str.c_str();
                        
                            for (int i = 0; i < expected; ++i) {
                                declare_var(cls.ctor_params[i].c_str(), false, copy_value(full_args[i]));
                            }
                        
                            CallStackGuard guard(g_call_stack, node->line, node->col, cls.defining_file.c_str());
                            exec_statement(cls.ctor_body);
                        
                            // 恢复旧类上下文
                            if (old_class_str.empty()) {
                                g_current_class_name_str.clear();
                                g_current_class_name = nullptr;
                            } else {
                                g_current_class_name_str = old_class_str;
                                g_current_class_name = g_current_class_name_str.c_str();
                            }
                        
                            bool had_exception = exception_raised;
                            Value ex_val = exception_value;
                        
                            pop_scope();
                            restore_flags();
                            current_constructed_obj = old_constructed;
                        
                            if (had_exception) {
                                char* msg = value_to_string(ex_val);
                                kr_warn("构造函数 '%s' 抛出异常: %s", fname, msg);
                            }
                        }
                
                        // ---- 释放临时参数 ----
                        for (int i = 0; i < expected; ++i)
                            free_value(&full_args[i]);
                        free(full_args);
                
                        result = obj;   // 直接移动
                        break;          // 跳出 NODE_FUNC_CALL
                    }
                }
                // ---- 1. 构造 func_val（变量函数或全局函数，或静态方法） ----
                Value func_val;
                memset(&func_val, 0, sizeof(func_val));
                bool is_var_func = false;
                bool is_static_method = false;
                std::string static_class_name;

                Variable* var = get_var(fname);
                if (var) {
                    var = resolve_alias(var);
                    if (var->value.type == VAL_FUNCTION) {
                        // 浅拷贝（别名）。调用期间变量 var 始终存活，函数值只读，
                        // 因此共享底层指针完全安全。
                        // 后续所有释放路径都要用 is_var_func 保护
                        func_val = var->value;
                        is_var_func = true;
                    } else {
                        char* got = value_to_string(var->value);
                        std::string ty = value_type_to_string(var->value);
                        kr_error("'%s' 不是函数，而是 %s 类型的变量（当前值: %s）",
                                 fname, ty.c_str(), got);
                        free(got);                     // 不会执行到，但保持完整
                    }
                } else {
                    Function* global_func = get_function(fname);
                    if (global_func) {
                        func_val.type = VAL_FUNCTION;
                        func_val.func_val.name = global_func->name ? strdup(global_func->name) : NULL;
                        func_val.func_val.param_count = global_func->param_count;
                        func_val.func_val.params = (char**)malloc(func_val.func_val.param_count * sizeof(char*));
                        for (int i = 0; i < func_val.func_val.param_count; i++) {
                            func_val.func_val.params[i] = strdup(global_func->params[i]);
                        }
                        func_val.func_val.body = copy_ast(global_func->body);
                        func_val.func_val.closure_scope = copy_scope_chain(global_func->closure_scope);
                        func_val.func_val.is_memoized = global_func->is_memoized;
                        func_val.func_val.is_async = global_func->is_async;
                        func_val.func_val.global_scope = global_func->global_scope;
                        func_val.func_val.is_rule = false;
                        func_val.func_val.return_type = copy_type_node(global_func->return_type);
                        func_val.func_val.vararg_name = global_func->vararg_name ? strdup(global_func->vararg_name) : NULL;
                    
                        // --- 复制 param_is_const 和 param_defaults（总是需要） ---
                        func_val.func_val.param_is_const = (bool*)malloc(func_val.func_val.param_count * sizeof(bool));
                        func_val.func_val.param_defaults = (ASTNode**)malloc(func_val.func_val.param_count * sizeof(ASTNode*));
                        for (int i = 0; i < func_val.func_val.param_count; i++) {
                            func_val.func_val.param_is_const[i] = global_func->param_is_const[i];
                            func_val.func_val.param_defaults[i] = global_func->param_defaults[i]
                                                                    ? copy_ast(global_func->param_defaults[i])
                                                                    : NULL;
                        }
                    
                        // --- 只有在 global_func->param_types 非空时才复制类型 ---
                        if (global_func->param_types) {
                            func_val.func_val.param_types = (TypeNode**)malloc(func_val.func_val.param_count * sizeof(TypeNode*));
                            for (int i = 0; i < func_val.func_val.param_count; i++) {
                                func_val.func_val.param_types[i] = copy_type_node(global_func->param_types[i]);
                            }
                        } else {
                            func_val.func_val.param_types = nullptr;
                        }
                    
                        // --- 复制可变参数类型（可能为空） ---
                        func_val.func_val.vararg_type = global_func->vararg_type ? copy_type_node(global_func->vararg_type) : nullptr;
                    
                        func_val.func_val.is_async = global_func->is_async;
                        func_val.func_val.filename = global_func->filename ? strdup(global_func->filename) : strdup("-");
                    } else {
                        // ---- 尝试静态方法 ----
                        if (g_current_class_name) {
                            std::string found_class;
                            MethodDef* md = find_static_method(g_current_class_name, fname, &found_class);
                            if (md) {
                                // 构造 func_val 作为静态方法
                                // 先用 0 初始化整个 Value，避免任何字段残留垃圾
                                memset(&func_val, 0, sizeof(func_val));
                                func_val.type = VAL_FUNCTION;
                                func_val.func_val.name = strdup(fname);
                                func_val.func_val.param_count = (int)md->params.size();
                            
                                // params：仅当参数数量 > 0 时分配
                                if (func_val.func_val.param_count > 0) {
                                    func_val.func_val.params = (char**)malloc(func_val.func_val.param_count * sizeof(char*));
                                    for (int i = 0; i < func_val.func_val.param_count; i++) {
                                        func_val.func_val.params[i] = strdup(md->params[i].c_str());
                                    }
                                } else {
                                    func_val.func_val.params = nullptr;
                                }
                            
                                func_val.func_val.body = copy_ast(md->body);
                                func_val.func_val.closure_scope = nullptr;
                                func_val.func_val.global_scope = true;
                                func_val.func_val.is_memoized = false;
                                func_val.func_val.is_async = false;
                                func_val.func_val.is_rule = false;
                                func_val.func_val.is_stmt_func = false;           //  关键：必须显式初始化
                                func_val.func_val.return_type = copy_type_node(md->return_type);
                                func_val.func_val.vararg_name = md->vararg_name.empty()
                                                                    ? nullptr
                                                                    : strdup(md->vararg_name.c_str());
                            
                                // param_is_const / param_defaults：仅当有参数时分配
                                if (func_val.func_val.param_count > 0) {
                                    func_val.func_val.param_is_const =
                                        (bool*)malloc(func_val.func_val.param_count * sizeof(bool));
                                    func_val.func_val.param_defaults =
                                        (ASTNode**)malloc(func_val.func_val.param_count * sizeof(ASTNode*));
                                    for (int i = 0; i < func_val.func_val.param_count; i++) {
                                        func_val.func_val.param_is_const[i] = false;
                                        func_val.func_val.param_defaults[i] = nullptr;
                                    }
                                } else {
                                    func_val.func_val.param_is_const = nullptr;
                                    func_val.func_val.param_defaults = nullptr;
                                }
                            
                                // 参数类型
                                if (!md->param_types.empty() && func_val.func_val.param_count > 0) {
                                    func_val.func_val.param_types =
                                        (TypeNode**)malloc(func_val.func_val.param_count * sizeof(TypeNode*));
                                    for (int i = 0; i < func_val.func_val.param_count; i++) {
                                        func_val.func_val.param_types[i] =
                                            md->param_types[i] ? copy_type_node(md->param_types[i]) : nullptr;
                                    }
                                } else {
                                    func_val.func_val.param_types = nullptr;
                                }
                            
                                func_val.func_val.vararg_type = md->vararg_type
                                                                    ? copy_type_node(md->vararg_type)
                                                                    : nullptr;
                                func_val.func_val.filename = strdup(current_filename ? current_filename : "-");
                                is_static_method = true;
                                static_class_name = found_class;
                            }
                        }
                        if (!is_static_method) {
                            std::string hint = suggest_correction(fname);
                            kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "未定义函数 '%s'", fname);
                        }
                    }
                }
            
                // ---- 2. 判断是否为异步函数 ----
                bool is_async = func_val.func_val.is_async;
            
                if (is_async) {
                    // 复制参数和函数值（深拷贝）
                    auto async_args = std::make_shared<std::vector<Value>>();
                    async_args->reserve(arg_count);
                    for (int i = 0; i < arg_count; ++i)
                        async_args->push_back(copy_value(args[i]));
                    
                    auto func_ptr = std::make_shared<Value>(copy_value(func_val));
                    int saved_line = node->line;
                    int saved_col = node->col;
                    int id = ++next_future_id;
                
                    // 启动异步任务
                    auto future = std::async(std::launch::async,
                        [func_ptr, async_args, saved_line, saved_col]() -> std::shared_ptr<Value> {
                            g_in_async_context = true;
                            std::lock_guard<std::recursive_mutex> lock(g_global_mutex); 
                            // 设置错误位置（thread_local，安全）
                            g_last_error_line = saved_line;
                            g_last_error_col = saved_col;
                
                            // 复制闭包（若包含全局作用域则返回原指针，后续访问需加锁）
                            auto closure_copy = copy_scope_chain(func_ptr->func_val.closure_scope);
                
                            // 保存当前线程的本地作用域（新线程中为 nullptr）
                            Scope* old_scope = current_scope;
                
                            // 创建局部作用域（父为闭包）
                            push_scope();
                            current_scope->parent = closure_copy;
                
                            // 重置控制标志（thread_local）
                            return_caught = false;
                            break_caught = false;
                            continue_caught = false;
                            exception_raised = false;
                
                            // ---------- 加锁执行函数体 ----------
                            Value result;
                            {
                                // 使用共享锁保护读操作，但可能涉及写操作（如全局变量赋值），故用独占锁更安全
                                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                                result = call_function_value(*func_ptr, async_args->data(), async_args->size());
                            }
                
                            // 清理当前作用域（释放局部变量）
                            pop_scope();
                            current_scope = old_scope;   // 恢复为 nullptr
                
                            // 释放闭包副本（若包含全局作用域，原指针未被复制，不会重复释放）
                            free_scope_chain(closure_copy);
                
                            // 返回值包装为 shared_ptr
                            g_in_async_context = false;
                            return std::make_shared<Value>(result);
                        }
                    );
                
                    // 存储 Future 到全局 map
                    {
                        std::lock_guard<std::mutex> lock(future_map_mutex);
                        future_map[id] = future.share();
                    }
                
                    // 构造 Future 值返回
                    Value fut_val;
                    fut_val.type = VAL_FUTURE;
                    fut_val.future_state.future_id = id;
                    result = fut_val;
                
                    // 释放原函数值（已复制到 func_ptr）
                    if (!is_var_func) free_value(&func_val);
                    // 清除控制标志（异步调用不阻塞）
                    return_caught = false;
                    break_caught = false;
                    continue_caught = false;
                    exception_raised = false;
                    break; // 跳出 NODE_FUNC_CALL
                }
            
                // ========== 同步调用 ==========
                bool is_memoized = func_val.func_val.is_memoized;
                std::string cache_key;
                if (is_memoized) {
                    Value* temp_args = (Value*)malloc(arg_count * sizeof(Value));
                    for (int i = 0; i < arg_count; i++) temp_args[i] = args[i];
                    cache_key = make_key(temp_args, arg_count);
                    free(temp_args);
                    {
                        std::lock_guard<std::mutex> lock(memo_cache_mutex);
                        auto& func_cache = memo_cache[fname];
                        auto it = func_cache.find(cache_key);
                        if (it != func_cache.end()) {
                            result = copy_value(it->second);
                            // 仅当 func_val 是本地构建的深拷贝时才释放
                            if (!is_var_func) {
                                free(func_val.func_val.name);
                                // 释放全局构造的 func_val
                                free(func_val.func_val.name);
                                for (int i = 0; i < func_val.func_val.param_count; i++) free(func_val.func_val.params[i]);
                                free(func_val.func_val.params);
                                free_ast(func_val.func_val.body);
                                free_scope_chain(func_val.func_val.closure_scope);
                                free(func_val.func_val.vararg_name);
                                free(func_val.func_val.param_is_const);
                                for (int i = 0; i < func_val.func_val.param_count; i++)
                                    free_ast(func_val.func_val.param_defaults[i]);
                                free(func_val.func_val.param_defaults);
                            }
                            break;
                        }
                    }
                }
                std::string old_class_str;
                if (g_current_class_name) old_class_str = g_current_class_name;

                if (is_static_method) {
                    g_current_class_name_str = static_class_name;
                    g_current_class_name = g_current_class_name_str.c_str();
                }

                // 调用函数
                Value return_val = call_function_value(func_val, args, arg_count, node, true);

                // ---- 恢复旧的类上下文 ----
                if (old_class_str.empty()) {
                    g_current_class_name_str.clear();
                    g_current_class_name = nullptr;
                } else {
                    g_current_class_name_str = old_class_str;
                    g_current_class_name = g_current_class_name_str.c_str();
                }
            
                // 记忆化存储
                if (is_memoized) {
                    std::lock_guard<std::mutex> lock(memo_cache_mutex);
                    memo_cache[fname][cache_key] = copy_value(return_val);
                }
            
                // 返回类型检查
                if (func_val.func_val.return_type && !check_type(func_val.func_val.return_type, return_val)) {
                    std::string expected = type_to_string(func_val.func_val.return_type);
                    char* got = value_to_string(return_val);
                    std::string actual_type = value_type_to_string(return_val);
                    bool old_warn = g_warnings_enabled;
                    g_warnings_enabled = true;
                    kr_warn("返回值类型不匹配: 期望 '%s', 实际 '%s' (类型: '%s')", expected.c_str(), got, actual_type.c_str());
                    g_warnings_enabled = old_warn;
                    free(got);
                    free_value(&return_val);
                    return_val = make_null();
                }
            
                result = return_val;
            
                // 释放 func_val 资源
                if (!is_var_func) {
                    free(func_val.func_val.name);
                    for (int i = 0; i < func_val.func_val.param_count; i++) free(func_val.func_val.params[i]);
                    free(func_val.func_val.params);
                    free_ast(func_val.func_val.body);
                    free_scope_chain(func_val.func_val.closure_scope);
                    free(func_val.func_val.vararg_name);
                    free(func_val.func_val.param_is_const);
                    for (int i = 0; i < func_val.func_val.param_count; i++)
                        free_ast(func_val.func_val.param_defaults[i]);
                    free(func_val.func_val.param_defaults);
                }
            
                return_caught = false;
                exception_raised = false;
                for (auto& v : arg_store) free_value(&v);
                break;
            }

            return_caught = false;
            break_caught = false;
            continue_caught = false;
            exception_raised = false;
            break;
        }
        case NODE_ARRAY_LITERAL: {
            std::vector<Value> result_elems;
            for (int i = 0; i < node->data.array_lit.count; i++) {
                ASTNode* elem = node->data.array_lit.elems[i];
                if (elem->type == NODE_SPREAD_ARRAY) {
                    Value spread_val = eval_expr(elem->data.spread.expr);
                    if (spread_val.type != VAL_ARRAY)
                        kr_error("展开运算符只能用于数组");
                    for (int j = 0; j < spread_val.arr_val.length; j++)
                        result_elems.push_back(copy_value(spread_val.arr_val.elements[j]));
                    free_value(&spread_val);
                } else {
                    Value v = eval_expr(elem);
                    result_elems.push_back(copy_value(v));  // 深拷贝
                    free_value(&v);
                }
            }
            // 构建数组（make_array 会复制元素）
            Value arr = make_array(result_elems.data(), (int)result_elems.size());
            // 释放临时元素
            for (auto& v : result_elems) free_value(&v);
            result = arr;
            break;
        }
         case NODE_ARRAY_ACCESS: {
            Value arr = eval_expr(node->data.array_access.array);
            Value idx_val = eval_expr(node->data.array_access.index);
            char* key_str = value_to_string(idx_val);
            free_value(&idx_val);
        
            if (arr.type == VAL_ARRAY) {
                long long idx = atoll(key_str);
                if (idx < 0 || idx >= arr.arr_val.length) {
                    kr_warn("数组索引 %lld 越界（长度 %lld），返回 null", idx, arr.arr_val.length);
                    free(key_str);
                    free_value(&arr);
                    result = make_null();
                    break;
                }
                result = copy_value(arr.arr_val.elements[idx]);
            }
            else if (arr.type == VAL_STRING) {
                long long idx = atoll(key_str);
                int len = utf8_length(arr.str_val);
                if (len == 0) {
                    // 空字符串直接返回空字符串
                    result = make_string("");
                    free(key_str);
                    free_value(&arr);
                    break;
                }
                if (idx < 0) {
                    kr_warn("字符串索引不能为负数，返回 null");
                    free(key_str);
                    free_value(&arr);
                    result = make_null();
                    break;
                }
                if (idx >= len) {
                    kr_warn("字符串索引越界，返回 null");
                    free(key_str);
                    free_value(&arr);
                    result = make_null();
                    break;
                }
                std::string ch = utf8_char_at(arr.str_val, idx);
                result = make_string(ch.c_str());
            }
            else if (arr.type == VAL_OBJECT) {
                bool found = false;
                for (int i = 0; i < arr.obj_val.count; i++) {
                    if (strcmp(arr.obj_val.entries[i].key, key_str) == 0) {
                        result = copy_value(arr.obj_val.entries[i].value);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    // 未找到键返回 null（可改为报错）
                    result = make_null();
                }
            }
            else {
                kr_error("索引访问非数组、字符串或对象\n");
                free(key_str);
                free_value(&arr);
                
            }
            free(key_str);
            free_value(&arr);
            break;
        }
         case NODE_ARRAY_LEN: {
             Value arr = eval_expr(node->data.array_len.array);
             int len = 0;
             if (arr.type == VAL_ARRAY) len = arr.arr_val.length;
             else if (arr.type == VAL_STRING) len = (int)utf8_length(std::string(arr.str_val, arr.str_len));
             else {
                 kr_error(".län 只能用于数组或字符串\n");
                 
             }
             free_value(&arr);
             result = make_int(len);
             break;
         }
         case NODE_LOGICAL_AND: {
             Value left = eval_expr(node->data.logical_and.left);
             int l = value_to_bool(left);
             free_value(&left);
             if (!l) { result = make_int(0LL); break; }
             Value right = eval_expr(node->data.logical_and.right);
             int r = value_to_bool(right);
             free_value(&right);
             result = make_int(r ? 1 : 0);
             break;
         }
         case NODE_LOGICAL_OR: {
             Value left = eval_expr(node->data.logical_or.left);
             int l = value_to_bool(left);
             free_value(&left);
             if (l) { result = make_int(1LL); break; }
             Value right = eval_expr(node->data.logical_or.right);
             int r = value_to_bool(right);
             free_value(&right);
             result = make_int(r ? 1 : 0);
             break;
         }
         case NODE_NOT: {
             Value v = eval_expr(node->data.not_expr.expr);
             int val = value_to_bool(v);
             free_value(&v);
             result = make_int(!val);
             break;
         }
         case NODE_METHOD_CALL: {
            std::string current_class_name;
            // ---- 静态方法调用检测 ----
            if (node->data.method_call.obj->type == NODE_VARIABLE) {
                std::string var_name = node->data.method_call.obj->data.var_name;
                    // ---- 命名空间成员调用 ----
                {
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    auto ns_it = named_scopes.find(var_name);
                    if (ns_it != named_scopes.end()) {
                        Scope* ns = ns_it->second;
                        std::string method_name = node->data.method_call.method;
                        int idx = get_var_index_in_scope(ns, method_name.c_str());
                        if (idx >= 0) {
                            Variable* fn_var = &ns->vars[idx];
                            if (fn_var->value.type != VAL_FUNCTION)
                                kr_error("命名空间 '%s' 的成员 '%s' 不是函数",
                                        var_name.c_str(), method_name.c_str());

                            int arg_count = node->data.method_call.arg_count;
                            Value* call_args = (Value*)malloc(arg_count * sizeof(Value));
                            for (int i = 0; i < arg_count; i++)
                                call_args[i] = eval_expr(node->data.method_call.args[i]);

                            Value ret = call_function_value(fn_var->value, call_args, arg_count, node);

                            for (int i = 0; i < arg_count; i++)
                                free_value(&call_args[i]);
                            free(call_args);

                            result = ret;
                            break; // 跳出 switch
                        } else {
                            kr_error("命名空间 '%s' 中没有成员 '%s'",
                                    var_name.c_str(), method_name.c_str());
                        }
                    }
                }
                Variable* var = get_var(var_name.c_str());
                if (!var) {
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    auto class_it = class_table.find(var_name);
                    if (class_it != class_table.end()) {
                        current_class_name = class_it->first;
                        ClassDef& cls = class_it->second;
                        std::string method_name = node->data.method_call.method;
                        auto method_it = cls.methods.find(method_name);
                        if (method_it == cls.methods.end()) {
                            kr_error("类 '%s' 没有方法 '%s'", var_name.c_str(), method_name.c_str());
                        }
                        MethodDef& md = method_it->second;
                        if (!md.is_static) {
                            kr_error("不能静态调用实例方法 '%s'", method_name.c_str());
                        }
                        std::string caller_class = var_name;
                        check_access(md.access, cls.defining_file, cls.name, method_name, caller_class, node);

                        std::string old_class_str;
                        if (g_current_class_name) old_class_str = g_current_class_name;
                        g_current_class_name_str = var_name;
                        g_current_class_name = g_current_class_name_str.c_str();
            
                        int arg_count = node->data.method_call.arg_count;
                        int fixed_param_count = (int)md.params.size();
                        bool has_vararg = !md.vararg_name.empty();
                        int vararg_count = 0;
                        if (has_vararg) {
                            if (arg_count < fixed_param_count)
                                kr_error("静态方法 '%s::%s' 参数不足：至少需要 %d 个，实际 %d", var_name.c_str(), method_name.c_str(), fixed_param_count, arg_count);
                            vararg_count = arg_count - fixed_param_count;
                        } else {
                            if (arg_count != fixed_param_count)
                                kr_error("静态方法 '%s::%s' 参数数量不匹配：期望 %d，实际 %d", var_name.c_str(), method_name.c_str(), fixed_param_count, arg_count);
                        }
            
                        // 求值所有参数
                        Value* call_args = (Value*)malloc(arg_count * sizeof(Value));
                        for (int i = 0; i < arg_count; i++) {
                            call_args[i] = eval_expr(node->data.method_call.args[i]);
                        }
            
                        save_flags();
                        push_scope();
            
                        // 声明固定参数
                        for (size_t i = 0; i < md.params.size(); i++) {
                            declare_var(md.params[i].c_str(), false, copy_value(call_args[i]));
                        }
            
                        // 声明可变参数（如果有）
                        if (has_vararg) {
                            Value* vararr_elems = (Value*)malloc(vararg_count * sizeof(Value));
                            for (int i = 0; i < vararg_count; i++) {
                                vararr_elems[i] = copy_value(call_args[fixed_param_count + i]);
                            }
                            Value vararr = make_array(vararr_elems, vararg_count);
                            free(vararr_elems);
                            declare_var(md.vararg_name.c_str(), false, vararr);
                        }
            
                        // 重置控制标志
                        return_caught = false;
                        break_caught = false;
                        continue_caught = false;
                        exception_raised = false;
            
                        // 执行方法体
                        Value method_body_slot = make_null();
                        Value* old_return_slot = g_current_return_slot;
                        g_current_return_slot = &method_body_slot;

                        {
                            CallStackGuard guard(g_call_stack, node->line, node->col, current_filename);
                            exec_statement(md.body);
                        }

                        g_current_return_slot = old_return_slot;
                        if (old_class_str.empty()) {
                            g_current_class_name_str.clear();
                            g_current_class_name = nullptr;
                        } else {
                            g_current_class_name_str = old_class_str;
                            g_current_class_name = g_current_class_name_str.c_str();
                        }

                        Value method_result;
                        if (return_caught) {
                            method_result = copy_value(return_value);
                            return_caught = false;
                            free_value(&method_body_slot);
                        } else {
                            if (md.return_type && md.return_type->kind == TYPE_ANY) {
                                method_result = make_null();
                                free_value(&method_body_slot);
                            } else {
                                method_result = copy_value(method_body_slot);
                                free_value(&method_body_slot);
                            }
                        }
                        bool had_exception = exception_raised;
                        Value ex_val = exception_value;
                        pop_scope();
                        restore_flags();
            
                        // 释放参数
                        for (int i = 0; i < arg_count; i++) free_value(&call_args[i]);
                        free(call_args);
            
                        if (had_exception) {
                            char* msg = value_to_string(ex_val);
                            kr_warn("静态方法 '%s' 抛出异常: %s", method_name.c_str(), msg);
                        }
                        result = method_result;
                        break; // 跳出 NODE_METHOD_CALL
                    }
                }
            }
            Value obj = eval_expr(node->data.method_call.obj);
            if (obj.type == VAL_NULL && node->data.method_call.is_optional) {
                free_value(&obj);
                result = make_null();
                break;
            }
            char* method = node->data.method_call.method;
            ASTNode** args = node->data.method_call.args;
            int arg_count = node->data.method_call.arg_count;
            Value res;

            if (is_lazy_range(obj) && strcmp(method, "län") != 0) {
                Value expanded = expand_lazy_range(obj);
                free_value(&obj);
                obj = expanded;
            }
            else if (strcmp(method, "keine") == 0) {
                if (arg_count != 0) {
                    kr_error("keine benötigt keine Argumente");
                }
                bool is_null = (obj.type == VAL_NULL);
                free_value(&obj);
                result = make_int(is_null ? 1 : 0);
                break;
            }
            else if (strcmp(method, "zgr") == 0) {
                if (arg_count != 0) kr_error("zeiger 不需要参数");
                res = make_pointer_raw(obj);
                free_value(&obj);
                result = res;
                break;   // 跳出 switch
            }
            else if (strcmp(method, "schlau") == 0) {
                if (arg_count != 0) kr_error("schlauerZeiger 不需要参数");
                res = make_pointer_smart(obj);
                free_value(&obj);
                result = res;
                break;
            }
            else if (strcmp(method, "typ") == 0) {
                if (arg_count != 0) kr_error("typ 不需要参数");
                bool handled = false;
                if (obj.type == VAL_OBJECT) {
                    // ---- 检测枚举变体（存在 __tag） ----
                    bool is_enum = false;
                    std::string tag;
                    for (int i = 0; i < obj.obj_val.count; ++i) {
                        if (strcmp(obj.obj_val.entries[i].key, "__tag") == 0 &&
                            obj.obj_val.entries[i].value.type == VAL_STRING) {
                            tag = obj.obj_val.entries[i].value.str_val;
                            is_enum = true;
                            break;
                        }
                    }
                    if (is_enum) {
                        ObjectEntry entries[2];
                        entries[0].key = strdup("typ");
                        entries[0].value = make_string("aufz");
                        entries[1].key = strdup("aufz");
                        entries[1].value = make_string(tag.c_str());
                        result = make_object(entries, 2);
                        free(entries[0].key); free_value(&entries[0].value);
                        free(entries[1].key); free_value(&entries[1].value);
                        handled = true;
                    } else {
                        // ---- 检测类实例（存在 __klass） ----
                        std::string klass_name;
                        for (int i = 0; i < obj.obj_val.count; ++i) {
                            if (strcmp(obj.obj_val.entries[i].key, "__klass") == 0 &&
                                obj.obj_val.entries[i].value.type == VAL_STRING) {
                                klass_name = obj.obj_val.entries[i].value.str_val;
                                break;
                            }
                        }
                        if (!klass_name.empty()) {
                            ObjectEntry entries[2];
                            entries[0].key = strdup("typ");
                            entries[0].value = make_string("objekt");
                            entries[1].key = strdup("klass");
                            entries[1].value = make_string(klass_name.c_str());
                            result = make_object(entries, 2);
                            free(entries[0].key); free_value(&entries[0].value);
                            free(entries[1].key); free_value(&entries[1].value);
                            handled = true;
                        }
                    }
                }
                if (!handled) {
                    std::string type_name = value_type_to_string(obj);
                    result = make_string(type_name.c_str());
                }
                free_value(&obj);
                break;
            }
            else if (strcmp(method, "gtyp") == 0) {
                if (arg_count != 0) kr_error("gtyp 不需要参数");
                std::string type_name = basic_value_type_to_string(obj);
                result = make_string(type_name.c_str());
                free_value(&obj);
                break;
            }
            else if (strcmp(method, "leer") == 0) {
                if (arg_count != 0) {
                    kr_error("leer benötigt keine Argumente");
                }
                bool empty = false;
                switch (obj.type) {
                    case VAL_NULL:
                        empty = true;
                        break;
                    case VAL_STRING:
                        empty = (strlen(obj.str_val) == 0);
                        break;
                    case VAL_ARRAY:
                        empty = (obj.arr_val.length == 0);
                        break;
                    case VAL_OBJECT:
                        empty = (obj.obj_val.count == 0);
                        break;
                    default:
                        empty = false;
                        break;
                }
                free_value(&obj);
                result = make_int(empty ? 1 : 0);
                break;
            }

            else if (strcmp(method, "leeren") == 0) {
                if (arg_count != 0) {
                    free_value(&obj);
                    kr_error("leeren 不需要参数");
                }
            
                // 尽量作用于原始左值；如果不是左值，就作用于临时副本
                Value* target = is_lvalue_node(node->data.method_call.obj)
                                ? get_mutable_ptr(node->data.method_call.obj)
                                : &obj;
            
                if (target->type == VAL_ARRAY) {
                    // 清空数组
                    for (long long i = 0; i < target->arr_val.length; ++i) {
                        free_value(&target->arr_val.elements[i]);
                    }
                    free(target->arr_val.elements);
                    target->arr_val.elements = nullptr;
                    target->arr_val.length = 0;
                }
                else if (target->type == VAL_OBJECT) {
                    // 清空对象：保留 __ 开头的内部元数据，例如 __klass、__range、__kd_daten 等
                    int w = 0;
                    for (int i = 0; i < target->obj_val.count; ++i) {
                        const char* k = target->obj_val.entries[i].key;
                        bool internal = (k && k[0] == '_' && k[1] == '_');
            
                        if (internal) {
                            if (w != i) {
                                target->obj_val.entries[w] = target->obj_val.entries[i];
                            }
                            ++w;
                        } else {
                            free(target->obj_val.entries[i].key);
                            free_value(&target->obj_val.entries[i].value);
                        }
                    }
            
                    target->obj_val.count = w;
                    if (w == 0) {
                        free(target->obj_val.entries);
                        target->obj_val.entries = nullptr;
                    } else {
                        target->obj_val.entries = (ObjectEntry*)realloc(
                            target->obj_val.entries,
                            w * sizeof(ObjectEntry)
                        );
                    }
                }
                else if (target->type == VAL_STRING) {
                    // 字符串清空为空串
                    free_value(target);
                    *target = make_string("");
                }
                else {
                    std::string ty = value_type_to_string(*target);
                    free_value(&obj);
                    kr_error("leeren/clear 不支持类型: %s", ty.c_str());
                }
            
                free_value(&obj);
                result = make_null();
                break;
            }
        
            if (obj.type == VAL_NULL) {
                // 对 alt 和 alsText 方法返回字符串 "null"
                if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
                    free_value(&obj);
                    result = make_string("null");
                    break;
                }
                kr_warn("在 null 上调用方法 '%s'，返回 null", method);
                free_value(&obj);
                result = make_null();
                break;
            }
        
            if (obj.type == VAL_OBJECT) {
                bool object_method_called = false;
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, method) == 0) {
                        Value& fn_val = obj.obj_val.entries[i].value;
                        if (fn_val.type == VAL_FUNCTION) {
                            Value* call_args = (Value*)malloc(arg_count * sizeof(Value));
                            for (int j = 0; j < arg_count; j++)
                                call_args[j] = eval_expr(args[j]);
                            result = call_function_value(fn_val, call_args, arg_count, node);
                            for (int j = 0; j < arg_count; j++)
                                free_value(&call_args[j]);
                            free(call_args);
                            free_value(&obj);
                            return_caught = false;
                            exception_raised = false;
                            object_method_called = true;
                            break;   // 跳出 switch(node->type)
                        }
                    }
                }
                if (object_method_called) {
                    break;   // 跳出 switch(node->type)，结束 NODE_METHOD_CALL
                }
                // 检查是否为 KDDataSet 对象
                bool is_dataset = false;
                std::shared_ptr<KDDataSet> ds_ptr;
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, "__kd_daten") == 0) {
                        is_dataset = true;
                        // 提取指针
                        Value& inner = obj.obj_val.entries[i].value;
                        if (inner.type == VAL_OBJECT && inner.obj_val.count >= 1 &&
                            strcmp(inner.obj_val.entries[0].key, "__zgr") == 0 &&
                            (inner.obj_val.entries[0].value.type == VAL_INT || inner.obj_val.entries[0].value.type == VAL_INT64)) {
                            ds_ptr = *(std::shared_ptr<KDDataSet>*)value_to_ll(inner.obj_val.entries[0].value);
                        }
                        break;
                    }
                }
                if (is_dataset && ds_ptr) {
                    if (strcmp(method, "hole") == 0) {
                        if (arg_count != 1) kr_error("hole benötigt 1 Argument (ID)");
                        Value id_val = eval_expr(args[0]);
                        uint64_t id = (id_val.type == VAL_INT || id_val.type == VAL_INT64) ? value_to_ll(id_val) : 0;
                        free_value(&id_val);
                        Record rec = ds_ptr->get_record(id);
                        // 构建记录对象
                        Value rec_obj; rec_obj.type = VAL_OBJECT;
                        int base_count = 4; // id,parent,typ,tags
                        rec_obj.obj_val.count = base_count + 2; // + dataset pointer + id for lazy fields
                        rec_obj.obj_val.entries = (ObjectEntry*)malloc(rec_obj.obj_val.count * sizeof(ObjectEntry));
                        int idx = 0;
                        rec_obj.obj_val.entries[idx].key = strdup("id"); rec_obj.obj_val.entries[idx].value = make_int(rec.id); idx++;
                        rec_obj.obj_val.entries[idx].key = strdup("vater"); rec_obj.obj_val.entries[idx].value = make_int(rec.vater); idx++;
                        rec_obj.obj_val.entries[idx].key = strdup("art"); rec_obj.obj_val.entries[idx].value = make_int(rec.type); idx++;
                        // tags -> array
                        Value* tag_vals = (Value*)malloc(rec.tags.size() * sizeof(Value));
                        for (size_t i=0; i<rec.tags.size(); ++i) tag_vals[i] = make_string(rec.tags[i].c_str());
                        rec_obj.obj_val.entries[idx].key = strdup("tags"); rec_obj.obj_val.entries[idx].value = make_array(tag_vals, rec.tags.size()); free(tag_vals); idx++;
                        // 存储 dataset 和 id 用于延迟加载
                        rec_obj.obj_val.entries[idx].key = strdup("__kd_daten"); 
                        // 复制指针（共享所有权）
                        std::shared_ptr<KDDataSet>* ds_copy = new std::shared_ptr<KDDataSet>(ds_ptr);
                        rec_obj.obj_val.entries[idx].value.type = VAL_OBJECT; // 嵌套
                        rec_obj.obj_val.entries[idx].value.obj_val.count = 1;
                        rec_obj.obj_val.entries[idx].value.obj_val.entries = (ObjectEntry*)malloc(sizeof(ObjectEntry));
                        rec_obj.obj_val.entries[idx].value.obj_val.entries[0].key = strdup("__zgr");
                        rec_obj.obj_val.entries[idx].value.obj_val.entries[0].value.type = VAL_INT;
                        Value &v = rec_obj.obj_val.entries[idx].value.obj_val.entries[0].value;
                        free_value(&v);
                        v = make_int((int64_t)ds_copy);
                        idx++;
                        rec_obj.obj_val.entries[idx].key = strdup("__kd_id"); rec_obj.obj_val.entries[idx].value = make_int(rec.id); idx++;
                        free_value(&obj); // 释放原obj
                        result = rec_obj;
                        break;
                    }
                    else if (strcmp(method, "sucheTag") == 0) {
                        if (arg_count != 1) kr_error("sucheTag benötigt 1 Argument (Tag)");
                        Value tag_val = eval_expr(args[0]);
                        if (tag_val.type != VAL_STRING) kr_error("Tag muss String sein");
                        auto ids = ds_ptr->find_by_tag(tag_val.str_val);
                        free_value(&tag_val);
                        // 返回记录ID数组
                        Value* id_vals = (Value*)malloc(ids.size() * sizeof(Value));
                        for (size_t i=0; i<ids.size(); ++i) id_vals[i] = make_int(ids[i]);
                        Value arr = make_array(id_vals, ids.size());
                        free(id_vals);
                        free_value(&obj);
                        result = arr;
                        break;
                    }
                    else if (strcmp(method, "sucheTyp") == 0) {
                        if (arg_count != 1) kr_error("sucheTyp benötigt 1 Argument (Typ)");
                        Value typ_val = eval_expr(args[0]);
                        uint32_t typ = (typ_val.type == VAL_INT || typ_val.type == VAL_INT64) ? value_to_ll(typ_val) : 0;
                        free_value(&typ_val);
                        auto ids = ds_ptr->find_by_type(typ);
                        Value* id_vals = (Value*)malloc(ids.size() * sizeof(Value));
                        for (size_t i=0; i<ids.size(); ++i) id_vals[i] = make_int(ids[i]);
                        Value arr = make_array(id_vals, ids.size());
                        free(id_vals);
                        free_value(&obj);
                        result = arr;
                        break;
                    }
                    else if (strcmp(method, "kinder") == 0) {
                        if (arg_count != 1) kr_error("kinder benötigt 1 Argument (Eltern-ID)");
                        Value parent_val = eval_expr(args[0]);
                        uint64_t vater_id = (parent_val.type == VAL_INT || parent_val.type == VAL_INT64) ? value_to_ll(parent_val) : 0;
                        free_value(&parent_val);
                        auto ids = ds_ptr->find_children(vater_id);
                        Value* id_vals = (Value*)malloc(ids.size() * sizeof(Value));
                        for (size_t i=0; i<ids.size(); ++i) id_vals[i] = make_int(ids[i]);
                        Value arr = make_array(id_vals, ids.size());
                        free(id_vals);
                        free_value(&obj);
                        result = arr;
                        break;
                    }
                    else if (strcmp(method, "komprim") == 0) {
                        if (arg_count != 0) kr_error("komprimiere benötigt keine Argumente");
                        if (!ds_ptr->compact()) kr_error("Komprimierung fehlgeschlagen");
                        res = make_null();
                        break;
                    }
                    else {
                        kr_error("Unbekan Methode für KDDataSet: '%s'", method);
                    }
                    break; // 跳出方法调用处理
                }
                // ---- 规则句柄处理 ----
                int rule_id = -1;
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, "__reg_id") == 0 && (obj.obj_val.entries[i].value.type == VAL_INT || obj.obj_val.entries[i].value.type == VAL_INT64)) {
                        rule_id = (int)value_to_ll(obj.obj_val.entries[i].value);
                        break;
                    }
                }
                if (rule_id != -1) {
                    auto it = rule_states.find(rule_id);
                    if (it != rule_states.end()) {
                        auto state = it->second;
                        if (strcmp(method, "wert") == 0) {
                            if (arg_count != 0) { kr_error("wert 不需要参数"); }
                            std::lock_guard<std::mutex> lock(state->mtx);
                            Value res = copy_value(state->cached_value);
                            free_value(&obj);
                            return res;
                        } else if (strcmp(method, "setZweck") == 0) {
                            if (arg_count != 1) { kr_error("setZweck 需要 1 个字符串参数"); }
                            Value usage_arg = eval_expr(args[0]);
                            if (usage_arg.type != VAL_STRING) { kr_error("zweck 必须是字符串"); }
                            std::lock_guard<std::mutex> lock(state->mtx);
                            state->usage = usage_arg.str_val;
                            free_value(&usage_arg);
                            free_value(&obj);
                            return make_null();
                        } else if (strcmp(method, "stop") == 0) {
                            if (arg_count != 0) { kr_error("stop 不需要参数"); }
                            state->running = false;
                            free_value(&obj);
                            return make_null();
                        }
                    }
                }
                if (strcmp(method, "län") == 0) {
                    if (is_lazy_range(obj)) {
                        int64_t rs, re, rstep;
                        extract_range_params(obj, rs, re, rstep);
                        result = make_int64(lazy_range_count(rs, re, rstep));
                        free_value(&obj);
                        break;
                    }
                    // 1. 检查对象是否属于某个类，并且该类是否定义了名为 "län" 的方法
                    char* cls_name = NULL;
                    for (int i = 0; i < obj.obj_val.count; i++) {
                        if (strcmp(obj.obj_val.entries[i].key, "__klass") == 0 &&
                            obj.obj_val.entries[i].value.type == VAL_STRING) {
                            cls_name = obj.obj_val.entries[i].value.str_val;
                            break;
                        }
                    }
                    bool method_called = false;
                    if (cls_name) {
                        current_class_name = cls_name;
                        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                        auto it_cls = class_table.find(cls_name);
                        if (it_cls != class_table.end()) {
                            auto it_meth = it_cls->second.methods.find("län");
                            if (it_meth != it_cls->second.methods.end()) {
                                MethodDef& md = it_meth->second;

                                std::string caller_class = cls_name;
                                check_access(md.access, it_cls->second.defining_file,
                                            it_cls->second.name, "län", caller_class, node);

                                // ---- 保存旧的类上下文（字符串副本，避免裸指针悬空）----
                                std::string old_class_str;
                                if (g_current_class_name) old_class_str = g_current_class_name;
                                g_current_class_name_str = cls_name;
                                g_current_class_name = g_current_class_name_str.c_str();

                                // 检查是否为静态方法（静态方法不接收 this）
                                int total_args = md.is_static ? 0 : 1;
                                Value* call_args = (Value*)malloc(total_args * sizeof(Value));
                                int idx = 0;
                                if (!md.is_static)
                                    call_args[idx++] = copy_value(obj);
                                // 无普通参数
                                save_flags();
                                push_scope();
                                if (!md.is_static)
                                    declare_var("dies", false, copy_value(obj));
                                // 声明参数（此处无）
                                return_caught = false;
                                break_caught = false;
                                continue_caught = false;
                                exception_raised = false;

                                Value method_body_slot = make_null();
                                Value* old_return_slot = g_current_return_slot;
                                g_current_return_slot = &method_body_slot;

                                {
                                    // 原代码引用未定义的 def_class_it，此处应使用 it_cls
                                    CallStackGuard guard(g_call_stack, node->line, node->col,
                                                        it_cls->second.defining_file.c_str());
                                    exec_statement(md.body);
                                }

                                g_current_return_slot = old_return_slot;

                                // ---- 恢复旧的类上下文 ----
                                if (old_class_str.empty()) {
                                    g_current_class_name_str.clear();
                                    g_current_class_name = nullptr;
                                } else {
                                    g_current_class_name_str = old_class_str;
                                    g_current_class_name = g_current_class_name_str.c_str();
                                }

                                Value method_result;
                                if (return_caught) {
                                    method_result = copy_value(return_value);
                                    return_caught = false;
                                    free_value(&method_body_slot);
                                } else {
                                    method_result = copy_value(method_body_slot);
                                    free_value(&method_body_slot);
                                }
                                bool had_exception = exception_raised;
                                Value ex_val = exception_value;
                                pop_scope();
                                restore_flags();
                                if (had_exception) {
                                    char* msg = value_to_string(ex_val);
                                    kr_error("Methode 'län' warf Fehler: %s", msg);
                                }
                                for (int i = 0; i < total_args; i++) free_value(&call_args[i]);
                                free(call_args);
                                result = method_result;
                                free_value(&obj);
                                method_called = true;
                                break; // 跳出方法调用处理
                            }
                        }
                    }
                    if (!method_called) {
                        // 无类方法：将对象序列化为字符串并返回字节长度
                        char* str = value_to_string(obj);
                        int byte_len = (int)strlen(str);
                        free(str);
                        result = make_int(byte_len);
                        free_value(&obj);
                        break;
                    }
                    // 如果已调用方法，上面已经 break，这里不会执行
                }
                else if (strcmp(method, "zufall") == 0 || strcmp(method, "random") == 0) {
                    if (arg_count > 1) {
                        kr_error("zufall/random benötigt höchstens 1 Argument (String oder Array)");
                    }
                    if (obj.obj_val.count == 0) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                    
                    // 收集候选键
                    std::vector<std::string> candidates;
                    if (arg_count == 0) {
                        // 所有属性
                        for (int i = 0; i < obj.obj_val.count; i++) {
                            candidates.push_back(obj.obj_val.entries[i].key);
                        }
                    } else {
                        Value arg = eval_expr(args[0]);   // 关键修正：求值参数
                        if (arg.type == VAL_STRING) {
                            candidates.push_back(arg.str_val);
                        } else if (arg.type == VAL_ARRAY) {
                            for (long long i = 0; i < arg.arr_val.length; i++) {
                                Value& elem = arg.arr_val.elements[i];
                                if (elem.type == VAL_STRING) {
                                    candidates.push_back(elem.str_val);
                                } else {
                                    kr_warn("zufall: Array-Element ist kein String, wird ignoriert");
                                }
                            }
                        } else {
                            free_value(&arg);
                            kr_error("zufall: Argument muss String oder Array sein");
                        }
                        free_value(&arg);   // 释放参数值
                    }
                    
                    // 过滤出实际存在的键
                    std::vector<std::string> valid_keys;
                    for (const auto& k : candidates) {
                        for (int i = 0; i < obj.obj_val.count; i++) {
                            if (k == obj.obj_val.entries[i].key) {
                                valid_keys.push_back(k);
                                break;
                            }
                        }
                    }
                    
                    if (valid_keys.empty()) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                    
                    // 随机选择一个键
                    int idx = rand() % valid_keys.size();
                    const std::string& chosen = valid_keys[idx];
                    // 查找对应的值
                    Value chosen_val = make_null();
                    for (int i = 0; i < obj.obj_val.count; i++) {
                        if (chosen == obj.obj_val.entries[i].key) {
                            chosen_val = copy_value(obj.obj_val.entries[i].value);
                            break;
                        }
                    }
                    
                    // 构造返回对象 { key, value }
                    ObjectEntry entries[2];
                    entries[0].key = strdup("key");
                    entries[0].value = make_string(chosen.c_str());
                    entries[1].key = strdup("wert");
                    entries[1].value = chosen_val;
                    
                    Value ret = make_object(entries, 2);
                    
                    // 释放临时 entries（make_object 内部已复制，但我们需要释放原始的键和值）
                    free(entries[0].key);
                    free_value(&entries[0].value);
                    free(entries[1].key);
                    free_value(&entries[1].value);
                    
                    free_value(&obj);
                    result = ret;
                    break;
                }
                else if (strcmp(method, "zufWert") == 0 || strcmp(method, "randomValue") == 0) {
                    if (arg_count > 1) {
                        kr_error("zufallWert/randomValue benötigt höchstens 1 Argument (String oder Array)");
                    }
                    if (obj.obj_val.count == 0) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                    
                    std::vector<std::string> candidates;
                    if (arg_count == 0) {
                        for (int i = 0; i < obj.obj_val.count; i++) {
                            candidates.push_back(obj.obj_val.entries[i].key);
                        }
                    } else {
                        Value arg = eval_expr(args[0]);   // 关键修正
                        if (arg.type == VAL_STRING) {
                            candidates.push_back(arg.str_val);
                        } else if (arg.type == VAL_ARRAY) {
                            for (long long i = 0; i < arg.arr_val.length; i++) {
                                Value& elem = arg.arr_val.elements[i];
                                if (elem.type == VAL_STRING) {
                                    candidates.push_back(elem.str_val);
                                } else {
                                    kr_warn("zufallWert: Array-Element ist kein String, wird ignoriert");
                                }
                            }
                        } else {
                            free_value(&arg);
                            kr_error("zufallWert: Argument muss String oder Array sein");
                        }
                        free_value(&arg);
                    }
                    
                    std::vector<std::string> valid_keys;
                    for (const auto& k : candidates) {
                        for (int i = 0; i < obj.obj_val.count; i++) {
                            if (k == obj.obj_val.entries[i].key) {
                                valid_keys.push_back(k);
                                break;
                            }
                        }
                    }
                    
                    if (valid_keys.empty()) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                    
                    int idx = rand() % valid_keys.size();
                    const std::string& chosen = valid_keys[idx];
                    for (int i = 0; i < obj.obj_val.count; i++) {
                        if (chosen == obj.obj_val.entries[i].key) {
                            result = copy_value(obj.obj_val.entries[i].value);
                            break;
                        }
                    }
                    free_value(&obj);
                    break;
                }
                else if (strcmp(method, "schl") == 0 || strcmp(method, "keys") == 0) {
                    if (arg_count != 0) kr_error("schl/keys benötigt keine Argumente");
                    std::vector<Value> key_vals;
                    for (int i = 0; i < obj.obj_val.count; i++) {
                        const char* key = obj.obj_val.entries[i].key;
                        // 跳过内部属性（以 __ 开头）
                        if (key[0] == '_' && key[1] == '_') continue;
                        key_vals.push_back(make_string(key));
                    }
                    Value result_arr = make_array(key_vals.data(), (int)key_vals.size());
                    for (auto& v : key_vals) free_value(&v);
                    free_value(&obj);
                    result = result_arr;
                    break;
                }
                if (strcmp(method, "werts") == 0 || strcmp(method, "values") == 0) {
                    if (arg_count != 0) kr_error("werts/values benötigt keine Argumente");
                    std::vector<Value> val_vals;
                    for (int i = 0; i < obj.obj_val.count; i++) {
                        const char* key = obj.obj_val.entries[i].key;
                        if (key[0] == '_' && key[1] == '_') continue;
                        val_vals.push_back(copy_value(obj.obj_val.entries[i].value));
                    }
                    Value result_arr = make_array(val_vals.data(), (int)val_vals.size());
                    for (auto& v : val_vals) free_value(&v);
                    free_value(&obj);
                    result = result_arr;
                    break;
                }
                else if (strcmp(method, "eintr") == 0 || strcmp(method, "entries") == 0) {
                    if (arg_count != 0) kr_error("eintr/entries benötigt keine Argumente");
                    std::vector<Value> entry_objs;
                    for (int i = 0; i < obj.obj_val.count; i++) {
                        const char* key = obj.obj_val.entries[i].key;
                        if (key[0] == '_' && key[1] == '_') continue;
                        ObjectEntry entries[2];
                        entries[0].key = strdup("key");
                        entries[0].value = make_string(key);
                        entries[1].key = strdup("wert");
                        entries[1].value = copy_value(obj.obj_val.entries[i].value);
                        Value entry_obj = make_object(entries, 2);
                        // 释放临时 entries（make_object 已复制）
                        free(entries[0].key);
                        free_value(&entries[0].value);
                        free(entries[1].key);
                        free_value(&entries[1].value);
                        entry_objs.push_back(entry_obj);
                    }
                    Value result_arr = make_array(entry_objs.data(), (int)entry_objs.size());
                    for (auto& v : entry_objs) free_value(&v);
                    free_value(&obj);
                    result = result_arr;
                    break;
                }
                else if (strcmp(method, "umk") == 0 || strcmp(method, "umkehren") == 0) {
                    Value* obj_ptr;
                    if (is_lvalue_node(node->data.method_call.obj)) {
                        obj_ptr = get_mutable_ptr(node->data.method_call.obj);
                    } else {
                        obj_ptr = &obj;
                    }
                    if (obj_ptr->type != VAL_OBJECT)
                        kr_error("umk: 类型错误(当前用于对象)");
                    int count = obj_ptr->obj_val.count;
                    for (int i = 0; i < count / 2; ++i) {
                        ObjectEntry tmp = obj_ptr->obj_val.entries[i];
                        obj_ptr->obj_val.entries[i] = obj_ptr->obj_val.entries[count - 1 - i];
                        obj_ptr->obj_val.entries[count - 1 - i] = tmp;
                    }
                    res = copy_value(*obj_ptr);
                    free_value(&obj);
                    result = res;
                    break;
                }
                else if (strcmp(method, "hat") == 0) {
                    if (arg_count != 1) {
                        kr_error("hat benötigt genau 1 Argument (Schlüssel)");
                    }
                    Value key_val = eval_expr(args[0]);
                    if (key_val.type != VAL_STRING) {
                        kr_error("Schlüssel muss ein String sein");
                    }
                    bool found = false;
                    for (int i = 0; i < obj.obj_val.count; i++) {
                        if (strcmp(obj.obj_val.entries[i].key, key_val.str_val) == 0) {
                            found = true;
                            break;
                        }
                    }
                    free_value(&key_val);
                    result = make_int(found ? 1 : 0);
                    free_value(&obj);
                    break;
                }
                else if (strcmp(method, "anf") == 0 || strcmp(method, "hinzufügen") == 0) {
                    result = method_hinzufuegen(obj, args, arg_count, node->data.method_call.obj);
                    break;
                }
                else if (strcmp(method, "lösch") == 0) {
                    result = method_loeschen(obj, args, arg_count, node->data.method_call.obj);
                    break;
                }
                else if (strcmp(method, "vereinige") == 0) {
                    result = method_vereinige_obj(obj, args, arg_count);
                    break;
                }
                else if (strcmp(method, "kopiere") == 0) {
                    result = method_kopiere(obj, args, arg_count);
                    break;
                }
        
                // ---- 类方法调用 ----
                char* cls_name = NULL;
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, "__klass") == 0 &&
                        obj.obj_val.entries[i].value.type == VAL_STRING) {
                        cls_name = obj.obj_val.entries[i].value.str_val;
                        break;
                    }
                }
                if (!cls_name) {
                    // 通用回退：alt / alsText 对任意对象有效
                    if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
                        if (arg_count != 0) {
                            free_value(&obj);
                            kr_error("alt 不需要参数");
                        }
                        char* s = value_to_string(obj);
                        result = make_string(s);
                        free(s);
                        free_value(&obj);
                        break;
                    }
                    kr_error("未知对象方法 '%s'", method);
                }
                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                auto it_cls = class_table.find(cls_name);
                if (it_cls == class_table.end()) {
                    kr_error("类 '%s' 未定义", cls_name);
                }

                // 在继承链中查找方法
                MethodDef* method_def = NULL;
                std::string current_class = cls_name;
                auto def_class_it = class_table.end();
                while (true) {
                    auto it_class = class_table.find(current_class);
                    if (it_class == class_table.end()) break;
                    auto it_method = it_class->second.methods.find(method);
                    if (it_method != it_class->second.methods.end()) {
                        method_def = &it_method->second;
                        def_class_it = it_class;
                        break;
                    }
                    if (it_class->second.parent.empty()) break;
                    current_class = it_class->second.parent;
                }
                if (!method_def) {
                    // 通用回退：alt / alsText 对任意对象有效
                    if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
                        if (arg_count != 0) {
                            free_value(&obj);
                            kr_error("alt 不需要参数");
                        }
                        char* s = value_to_string(obj);
                        result = make_string(s);
                        free(s);
                        free_value(&obj);
                        break;
                    }
                    kr_error("方法 '%s' 未找到", method);
                }

                std::string caller_class = cls_name;          // 对象所属类
                std::string target_class = current_class;     // 方法实际定义的类
                auto target_it = class_table.find(target_class);
                if (target_it != class_table.end()) {
                    check_access(method_def->access, target_it->second.defining_file,
                                 target_class, method, caller_class, node);
                }

                // 构造参数列表：静态方法不含 this，实例方法含 this
                bool has_vararg = !method_def->vararg_name.empty();
                int fixed_param_count = method_def->params.size();
                int vararg_count = 0;
                if (has_vararg) {
                    if (arg_count < fixed_param_count)
                        kr_error("方法 '%s::%s' 参数不足：至少需要 %d 个，实际 %d", cls_name, method, fixed_param_count, arg_count);
                    vararg_count = arg_count - fixed_param_count;
                } else {
                    if (arg_count != fixed_param_count)
                        kr_error("方法 '%s::%s' 参数数量不匹配：期望 %d，实际 %d", cls_name, method, fixed_param_count, arg_count);
                }

                int total_argc = fixed_param_count + (method_def->is_static ? 0 : 1) + (has_vararg ? 1 : 0);
                Value* call_args = (Value*)malloc(total_argc * sizeof(Value));
                int idx = 0;
                if (!method_def->is_static)
                    call_args[idx++] = copy_value(obj);
                // 固定参数
                for (int i = 0; i < fixed_param_count; ++i)
                    call_args[idx++] = eval_expr(args[i]);
                // 可变参数打包为数组
                if (has_vararg) {
                    Value* vararr_elems = (Value*)malloc(vararg_count * sizeof(Value));
                    for (int i = 0; i < vararg_count; ++i)
                        vararr_elems[i] = eval_expr(args[fixed_param_count + i]);
                    Value vararr = make_array(vararr_elems, vararg_count);
                    free(vararr_elems);
                    call_args[idx++] = vararr;   // 此值将在声明时使用
                }

                int param_start_idx = method_def->is_static ? 0 : 1;
                for (size_t p = 0; p < method_def->params.size(); p++) {
                    TypeNode* expected_type = method_def->param_types[p];
                    if (expected_type) {
                        Value* arg_val = &call_args[param_start_idx + p];
                        if (!check_type(expected_type, *arg_val)) {
                            std::string expected = type_to_string(expected_type);
                            char* got = value_to_string(*arg_val);
                            kr_error("方法 '%s' 参数 '%s' 类型错误: 期望 '%s', 实际 '%s'",
                                    method, method_def->params[p].c_str(), expected.c_str(), got);
                        }
                    }
                }

                save_flags();

                push_scope();

                std::string old_class_str;
                if (g_current_class_name) old_class_str = g_current_class_name;
                g_current_class_name_str = cls_name;
                g_current_class_name = g_current_class_name_str.c_str();

                if (!method_def->is_static) {
                    declare_var("dies", false, copy_value(obj));
                }

                // 声明参数
                for (size_t i = 0; i < method_def->params.size(); i++) {
                    int arg_index = method_def->is_static ? i : i + 1;
                    declare_var(method_def->params[i].c_str(), false, copy_value(call_args[arg_index]));
                }

                if (has_vararg) {
                    // 可变参数数组在 call_args 中的索引为 param_start_idx + fixed_param_count
                    int vararg_index = (method_def->is_static ? 0 : 1) + fixed_param_count;
                    declare_var(method_def->vararg_name.c_str(), false, copy_value(call_args[vararg_index]));
                }

                // 重置内部标志，避免污染
                return_caught = false;
                break_caught = false;
                continue_caught = false;
                exception_raised = false;

                {
                    CallStackGuard guard(g_call_stack, node->line, node->col,
                                         def_class_it->second.defining_file.c_str());
                    exec_statement(method_def->body);
                }

                // 提取返回值
                Value method_result;
                if (return_caught) {
                    method_result = copy_value(return_value);
                    return_caught = false;
                } else {
                    ASTNode* last = get_last_expr_from_block(method_def->body);
                    method_result = last ? eval_expr(last) : make_int(0LL);
                }
                if (method_def->return_type) {
                    if (!check_type(method_def->return_type, method_result)) {
                        std::string expected = type_to_string(method_def->return_type);
                        char* got = value_to_string(method_result);
                        kr_error("方法 '%s' 返回值类型错误: 期望 '%s', 实际 '%s'",
                                 method, expected.c_str(), got);
                    }
                }
                if (old_class_str.empty()) {
                    g_current_class_name_str.clear();
                    g_current_class_name = nullptr;
                } else {
                    g_current_class_name_str = old_class_str;
                    g_current_class_name = g_current_class_name_str.c_str();
                }

                // 检查异常
                bool had_exception = exception_raised;
                Value ex_val = exception_value;

                pop_scope();

                restore_flags();

                if (had_exception) {
                    char* msg = value_to_string(ex_val);
                    kr_error("Methode '%s' warf Fehler: %s", method, msg);
                }

                // 释放临时资源
                for (int i = 0; i < total_argc; i++) free_value(&call_args[i]);
                free(call_args);
                free_value(&obj);

                res = method_result;
            }
            else if (obj.type == VAL_STRING) {
                if (strcmp(method, "passende") == 0 || strcmp(method, "pass") == 0) res = method_passende(obj, args, arg_count);
                else if (strcmp(method, "ersetze") == 0 || strcmp(method, "ers") == 0) res = method_ersetze(obj, args, arg_count);
                else if (strcmp(method, "teil") == 0) res = method_teile(obj, args, arg_count);
                else if (strcmp(method, "entfal") == 0) {
                    res = method_entfal(obj, args, arg_count);
                }
                else if (strcmp(method, "enthält") == 0 || strcmp(method, "hat") == 0) res = method_enthaelt(obj, args, arg_count);
                else if (strcmp(method, "fängtAnMit") == 0 || strcmp(method, "beg") == 0) res = method_faengtAnMit(obj, args, arg_count);
                else if (strcmp(method, "abschnitt") == 0 || strcmp(method, "ab") == 0) res = method_abschnitt(obj, args, arg_count);
                else if (strcmp(method, "stelleVon") == 0 || strcmp(method, "wo") == 0) res = method_stelleVon(obj, args, arg_count);
                else if (strcmp(method, "letzteStelleVon") == 0 || strcmp(method, "letzt") == 0) res = method_letzteStelleVon(obj, args, arg_count);
                else if (strcmp(method, "trim") == 0) res = method_trim(obj, args, arg_count);
                else if (strcmp(method, "alsZahl") == 0 || strcmp(method, "alz") == 0) res = method_alsZahl(obj, args, arg_count);
                else if (strcmp(method, "alsText") == 0 || strcmp(method, "alt") == 0) res = method_alsText(obj, args, arg_count);
                else if (strcmp(method, "län") == 0) {
                    res = make_int((long long)obj.str_len);
                }
                else if (strcmp(method, "groß") == 0) res = method_toUpper(obj, args, arg_count);
                else if (strcmp(method, "klein") == 0)
                    res = method_toLower(obj, args, arg_count);
                else if (strcmp(method, "umkehren") == 0 || strcmp(method, "umk") == 0)
                    res = method_reverse(obj, args, arg_count);
                else if (strcmp(method, "zähle") == 0)
                    res = method_count(obj, args, arg_count);
                else if (strcmp(method, "ohneAnfang") == 0)
                    res = method_remove_prefix(obj, args, arg_count);
                else if (strcmp(method, "ohneEnde") == 0)
                    res = method_remove_suffix(obj, args, arg_count);
                else if (strcmp(method, "füll") == 0)
                    res = method_pad(obj, args, arg_count);
                else if (strcmp(method, "endetMit") == 0)
                    res = method_ends_with(obj, args, arg_count);
                else if (strcmp(method, "wieder") == 0)
                    res = method_repeat(obj, args, arg_count);
                else if (strcmp(method, "zeich") == 0)
                    res = method_char_at(obj, args, arg_count);
                else if (strcmp(method, "istZiffer") == 0)
                    res = method_istZiffer(obj, args, arg_count);
                else if (strcmp(method, "istBuchstabe") == 0)
                    res = method_istBuchstabe(obj, args, arg_count);
                else if (strcmp(method, "istAlnum") == 0)
                    res = method_istAlnum(obj, args, arg_count);
                else if (strcmp(method, "istRaum") == 0)
                    res = method_istRaum(obj, args, arg_count);
                else if (strcmp(method, "istGroß") == 0)
                    res = method_istGroß(obj, args, arg_count);
                else if (strcmp(method, "istKlein") == 0)
                    res = method_istKlein(obj, args, arg_count);
                else if (strcmp(method, "istZahl") == 0)
                    res = method_istZahl(obj, args, arg_count);
                else if (strcmp(method, "entferne") == 0)
                    res = method_entferne(obj, args, arg_count);
                else if (strcmp(method, "anfang") == 0)
                    res = method_anfang(obj, args, arg_count);
                else if (strcmp(method, "rechts") == 0)
                    res = method_rechts(obj, args, arg_count);
                else {
                    kr_error("未知字符串方法 '%s'", method);
                }
                free_value(&obj);
            }
            else if (obj.type == VAL_ARRAY) {
                // 数组方法
                if (strcmp(method, "hinzufügen") == 0 || strcmp(method, "anf") == 0)
                    res = method_hinzufuegen(obj, args, arg_count, node->data.method_call.obj);
                else if (strcmp(method, "finde") == 0)
                    res = method_finde(obj, args, arg_count);
                else if (strcmp(method, "findeIndex") == 0 || strcmp(method, "idx") == 0)
                    res = method_findeIndex(obj, args, arg_count);
                else if (strcmp(method, "letzt") == 0 || strcmp(method, "letzteStelleVon") == 0) {
                    res = method_array_last(obj, args, arg_count);
                }
                else if (strcmp(method, "ab") == 0 || strcmp(method, "abschnitt") == 0) {
                    res = method_slice(obj, args, arg_count);
                }
                else if (strcmp(method, "lösch") == 0) {
                    if (arg_count != 1) kr_error("删除需要 1 个参数（索引）");
                    Value idx_val = eval_expr(args[0]);
                    if (idx_val.type != VAL_INT && idx_val.type != VAL_INT64) kr_error("索引必须是一个整数");
                    long long idx = value_to_ll(idx_val);
                    free_value(&idx_val);
                
                    Value* arr_ptr;
                    if (is_lvalue_node(node->data.method_call.obj)) {
                        arr_ptr = get_mutable_ptr(node->data.method_call.obj);
                    } else {
                        arr_ptr = &obj;
                    }
                    if (arr_ptr->type != VAL_ARRAY) kr_error("对象不是数组");
                    if (idx < 0 || idx >= arr_ptr->arr_val.length) {
                        kr_error("索引超出范围 (Länge %lld, Index %lld)", arr_ptr->arr_val.length, idx);
                    }
                
                    Value removed = copy_value(arr_ptr->arr_val.elements[idx]);
                    for (long long i = idx; i < arr_ptr->arr_val.length - 1; ++i) {
                        free_value(&arr_ptr->arr_val.elements[i]);
                        arr_ptr->arr_val.elements[i] = copy_value(arr_ptr->arr_val.elements[i+1]);
                    }
                    free_value(&arr_ptr->arr_val.elements[arr_ptr->arr_val.length - 1]);
                    arr_ptr->arr_val.length--;
                    if (arr_ptr->arr_val.length > 0) {
                        arr_ptr->arr_val.elements = (Value*)realloc(arr_ptr->arr_val.elements,
                                                                    arr_ptr->arr_val.length * sizeof(Value));
                    } else {
                        free(arr_ptr->arr_val.elements);
                        arr_ptr->arr_val.elements = NULL;
                    }
                
                    res = removed;
                }
                else if (strcmp(method, "map") == 0) {
                    if (arg_count != 1) { kr_error("map 需要 1 个参数（函数）"); }
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) { kr_error("map 参数必须是函数"); }
                    Value* new_elems = (Value*)malloc(obj.arr_val.length * sizeof(Value));
                    for (int i = 0; i < obj.arr_val.length; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        new_elems[i] = call_function_value(func, &arg, 1, node);
                        free_value(&arg);
                    }
                    res = make_array(new_elems, obj.arr_val.length);
                    free(new_elems);
                    free_value(&func);
                }
                else if (strcmp(method, "filter") == 0) {
                    if (arg_count != 1) { kr_error("filter 需要 1 个参数（函数）"); }
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) { kr_error("filter 参数必须是函数"); }
                    Value* filtered = NULL;
                    int count = 0;
                    for (int i = 0; i < obj.arr_val.length; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        Value pred = call_function_value(func, &arg, 1, node);
                        int keep = value_to_bool(pred);
                        free_value(&pred);
                        free_value(&arg);
                        if (keep) {
                            filtered = (Value*)realloc(filtered, (count + 1) * sizeof(Value));
                            filtered[count++] = copy_value(obj.arr_val.elements[i]);
                        }
                    }
                    res = make_array(filtered, count);
                    free(filtered);
                    free_value(&func);
                }
                else if (strcmp(method, "reduz") == 0) {
                    if (arg_count != 2) { kr_error("reduz 需要 2 个参数（函数, 初始值）"); }
                    Value func = eval_expr(args[0]);
                    Value init = eval_expr(args[1]);
                    if (func.type != VAL_FUNCTION) { kr_error("reduz 第一个参数必须是函数"); }
                    Value acc = copy_value(init);
                    free_value(&init);
                    for (int i = 0; i < obj.arr_val.length; i++) {
                        Value args_arr[2] = { copy_value(acc), copy_value(obj.arr_val.elements[i]) };
                        Value new_acc = call_function_value(func, args_arr, 2, node);
                        free_value(&acc);
                        free_value(&args_arr[0]);
                        free_value(&args_arr[1]);
                        acc = new_acc;
                    }
                    res = acc;
                    free_value(&func);
                }
                else if (strcmp(method, "län") == 0) {
                    res = make_int(obj.arr_val.length);
                }
                else if (strcmp(method, "beit") == 0) {
                    if (arg_count != 1) kr_error("beit 需要1个参数（分隔符）");
                    Value sep_val = eval_expr(args[0]);
                    if (sep_val.type != VAL_STRING) kr_error("分隔符必须是一个字符串");
                    std::string sep(sep_val.str_val, sep_val.str_len);
                    free_value(&sep_val);
                
                    std::string result_str;
                    for (int i = 0; i < obj.arr_val.length; ++i) {
                        if (i > 0) result_str += sep;
                        Value& elem = obj.arr_val.elements[i];
                        if (elem.type == VAL_STRING) {
                            result_str.append(elem.str_val, elem.str_len);
                        } else {
                            char* s = value_to_string(elem);
                            result_str += s;
                            free(s);
                        }
                    }
                    res = make_string_len(result_str.data(), result_str.size());
                }
                else if (strcmp(method, "zufall") == 0 || strcmp(method, "random") == 0) {
                    if (arg_count > 1) {
                        kr_error("zufall/random benötigt höchstens 1 Argument (Integer oder Integer-Array)");
                    }
                    if (obj.arr_val.length == 0) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                
                    std::vector<long long> candidates;
                    if (arg_count == 0) {
                        for (long long i = 0; i < obj.arr_val.length; i++) {
                            candidates.push_back(i);
                        }
                    } else {
                        Value arg = eval_expr(args[0]);
                        if (arg.type == VAL_INT || arg.type == VAL_INT64) {
                            long long idx = value_to_ll(arg);
                            if (idx >= 0 && idx < obj.arr_val.length) {
                                candidates.push_back(idx);
                            }
                        } else if (arg.type == VAL_ARRAY) {
                            for (long long i = 0; i < arg.arr_val.length; i++) {
                                Value& elem = arg.arr_val.elements[i];
                                if (elem.type == VAL_INT || elem.type == VAL_INT64) {
                                    long long idx = value_to_ll(elem);
                                    if (idx >= 0 && idx < obj.arr_val.length) {
                                        candidates.push_back(idx);
                                    }
                                } else {
                                    kr_warn("zufall: Array-Element ist kein gültiger Index, wird ignoriert");
                                }
                            }
                        } else {
                            free_value(&arg);
                            kr_error("zufall: Argument muss Integer oder Integer-Array sein");
                        }
                        free_value(&arg);
                    }
                
                    if (candidates.empty()) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                
                    long long chosen = candidates[rand() % candidates.size()];
                    Value val = copy_value(obj.arr_val.elements[chosen]);
                
                    // 返回 { index, value } 对象
                    ObjectEntry entries[2];
                    entries[0].key = strdup("index");
                    entries[0].value = make_int(chosen);
                    entries[1].key = strdup("wert");
                    entries[1].value = val;
                
                    Value ret = make_object(entries, 2);
                    free(entries[0].key);
                    free_value(&entries[0].value);
                    free(entries[1].key);
                    free_value(&entries[1].value);
                
                    free_value(&obj);
                    result = ret;
                    break;
                }
                
                else if (strcmp(method, "zufWert") == 0 || strcmp(method, "randomValue") == 0) {
                    if (arg_count > 1) {
                        kr_error("zufallWert/randomValue benötigt höchstens 1 Argument (Integer oder Integer-Array)");
                    }
                    if (obj.arr_val.length == 0) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                
                    std::vector<long long> candidates;
                    if (arg_count == 0) {
                        for (long long i = 0; i < obj.arr_val.length; i++) {
                            candidates.push_back(i);
                        }
                    } else {
                        Value arg = eval_expr(args[0]);
                        if (arg.type == VAL_INT || arg.type == VAL_INT64) {
                            long long idx = value_to_ll(arg);
                            if (idx >= 0 && idx < obj.arr_val.length) {
                                candidates.push_back(idx);
                            }
                        } else if (arg.type == VAL_ARRAY) {
                            for (long long i = 0; i < arg.arr_val.length; i++) {
                                Value& elem = arg.arr_val.elements[i];
                                if (elem.type == VAL_INT || elem.type == VAL_INT64) {
                                    long long idx = value_to_ll(elem);
                                    if (idx >= 0 && idx < obj.arr_val.length) {
                                        candidates.push_back(idx);
                                    }
                                } else {
                                    kr_warn("zufallWert: Array-Element ist kein gültiger Index, wird ignoriert");
                                }
                            }
                        } else {
                            free_value(&arg);
                            kr_error("zufallWert: Argument muss Integer oder Integer-Array sein");
                        }
                        free_value(&arg);
                    }
                
                    if (candidates.empty()) {
                        free_value(&obj);
                        result = make_null();
                        break;
                    }
                
                    long long chosen = candidates[rand() % candidates.size()];
                    result = copy_value(obj.arr_val.elements[chosen]);
                    free_value(&obj);
                    break;
                }
                else if (strcmp(method, "sort") == 0)
                    res = method_sort(obj, args, arg_count, node->data.method_call.obj);
                else if (strcmp(method, "unique") == 0)
                    res = method_unique(obj, args, arg_count);
                else if (strcmp(method, "teil") == 0)
                    res = method_slice(obj, args, arg_count);
                else if (strcmp(method, "hat") == 0)
                    res = method_contains_array(obj, args, arg_count);
                else if (strcmp(method, "alle") == 0)
                    res = method_all_indices(obj, args, arg_count);
                else if (strcmp(method, "max") == 0)
                    res = method_max(obj, args, arg_count);
                else if (strcmp(method, "min") == 0)
                    res = method_min(obj, args, arg_count);
                else if (strcmp(method, "sum") == 0)
                    res = method_sum(obj, args, arg_count);
                else if (strcmp(method, "umk") == 0 || strcmp(method, "umkehren") == 0) {
                    Value* arr_ptr;
                    if (is_lvalue_node(node->data.method_call.obj)) {
                        arr_ptr = get_mutable_ptr(node->data.method_call.obj);
                    } else {
                        arr_ptr = &obj;
                    }
                    if (arr_ptr->type != VAL_ARRAY)
                        kr_error("umk: 类型错误(当前用于数组)");
                
                    int len = arr_ptr->arr_val.length;
                    for (int i = 0; i < len / 2; ++i) {
                        Value tmp = arr_ptr->arr_val.elements[i];
                        arr_ptr->arr_val.elements[i] = arr_ptr->arr_val.elements[len - 1 - i];
                        arr_ptr->arr_val.elements[len - 1 - i] = tmp;
                    }
                    res = copy_value(*arr_ptr);
                }
                else if (strcmp(method, "jeden") == 0) {
                    // jeden(fn) —— forEach：对每个元素调用函数
                    if (arg_count != 1) kr_error("jeden 需要 1 个参数（函数）");
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) kr_error("jeden 参数必须是函数");
                    for (int i = 0; i < obj.arr_val.length; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        Value r = call_function_value(func, &arg, 1, node);
                        free_value(&r);
                        free_value(&arg);
                    }
                    free_value(&func);
                    res = make_null();
                }
                else if (strcmp(method, "manche") == 0) {
                    // manche(fn) —— some：任意一个元素满足谓词
                    if (arg_count != 1) kr_error("manche 需要 1 个参数（函数）");
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) kr_error("manche 参数必须是函数");
                    int found = 0;
                    for (int i = 0; i < obj.arr_val.length && !found; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        Value r = call_function_value(func, &arg, 1, node);
                        found = value_to_bool(r);
                        free_value(&r);
                        free_value(&arg);
                    }
                    free_value(&func);
                    res = make_int(found ? 1 : 0);
                }
                else if (strcmp(method, "keiner") == 0) {
                    // keiner(fn) —— none：没有任何元素满足谓词
                    if (arg_count != 1) kr_error("keiner 需要 1 个参数（函数）");
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) kr_error("keiner 参数必须是函数");
                    int found = 0;
                    for (int i = 0; i < obj.arr_val.length && !found; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        Value r = call_function_value(func, &arg, 1, node);
                        found = value_to_bool(r);
                        free_value(&r);
                        free_value(&arg);
                    }
                    free_value(&func);
                    res = make_int(found ? 0 : 1);
                }
                else if (strcmp(method, "zähl") == 0) {
                    // zähl() —— 元素个数；zähl(fn) —— 满足谓词的元素个数
                    if (arg_count > 1) kr_error("zähl 需要 0 或 1 个参数");
                    if (arg_count == 0) {
                        res = make_int(obj.arr_val.length);
                    } else {
                        Value func = eval_expr(args[0]);
                        if (func.type != VAL_FUNCTION) kr_error("zähl 参数必须是函数");
                        int cnt = 0;
                        for (int i = 0; i < obj.arr_val.length; i++) {
                            Value arg = copy_value(obj.arr_val.elements[i]);
                            Value r = call_function_value(func, &arg, 1, node);
                            if (value_to_bool(r)) cnt++;
                            free_value(&r);
                            free_value(&arg);
                        }
                        free_value(&func);
                        res = make_int(cnt);
                    }
                }
                else if (strcmp(method, "grupp") == 0) {
                    // grupp(fn) —— 按函数返回的键分组，返回 { key: [元素...] }
                    if (arg_count != 1) kr_error("grupp 需要 1 个参数（函数）");
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) kr_error("grupp 参数必须是函数");
                    ObjectEntry* entries = nullptr;
                    int count = 0;
                    for (int i = 0; i < obj.arr_val.length; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        Value k = call_function_value(func, &arg, 1, node);
                        char* ks = value_to_string(k);
                        // 找到已有的 key 则追加，否则新建
                        int found_idx = -1;
                        for (int j = 0; j < count; j++) {
                            if (strcmp(entries[j].key, ks) == 0) { found_idx = j; break; }
                        }
                        if (found_idx >= 0) {
                            Value& arr = entries[found_idx].value;
                            arr.arr_val.elements = (Value*)realloc(
                                arr.arr_val.elements,
                                (arr.arr_val.length + 1) * sizeof(Value));
                            arr.arr_val.elements[arr.arr_val.length] = copy_value(arg);
                            arr.arr_val.length++;
                        } else {
                            entries = (ObjectEntry*)realloc(entries, (count + 1) * sizeof(ObjectEntry));
                            entries[count].key = strdup(ks);
                            Value one = copy_value(arg);
                            entries[count].value = make_array(&one, 1);
                            free_value(&one);
                            count++;
                        }
                        free(ks);
                        free_value(&k);
                        free_value(&arg);
                    }
                    res = make_object(entries, count);
                    for (int j = 0; j < count; j++) {
                        free(entries[j].key);
                        free_value(&entries[j].value);
                    }
                    free(entries);
                    free_value(&func);
                }
                else if (strcmp(method, "partit") == 0) {
                    // partit(fn) —— 按谓词分成两个数组，返回 [满足, 不满足]
                    if (arg_count != 1) kr_error("partit 需要 1 个参数（函数）");
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) kr_error("partit 参数必须是函数");
                    std::vector<Value> ja, nein;
                    for (int i = 0; i < obj.arr_val.length; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        Value r = call_function_value(func, &arg, 1, node);
                        if (value_to_bool(r)) ja.push_back(arg);
                        else nein.push_back(arg);
                    }
                    free_value(&func);
                    Value two[2] = {
                        make_array(ja.data(), (int)ja.size()),
                        make_array(nein.data(), (int)nein.size())
                    };
                    for (auto& v : ja)   free_value(&v);
                    for (auto& v : nein) free_value(&v);
                    res = make_array(two, 2);
                    free_value(&two[0]);
                    free_value(&two[1]);
                }
                else if (strcmp(method, "erste") == 0) {
                    // erste(fn) —— 返回第一个满足谓词的元素（无则 null）
                    if (arg_count != 1) kr_error("erste 需要 1 个参数（函数）");
                    Value func = eval_expr(args[0]);
                    if (func.type != VAL_FUNCTION) kr_error("erste 参数必须是函数");
                    Value found = make_null();
                    for (int i = 0; i < obj.arr_val.length; i++) {
                        Value arg = copy_value(obj.arr_val.elements[i]);
                        Value r = call_function_value(func, &arg, 1, node);
                        int ok = value_to_bool(r);
                        free_value(&r);
                        if (ok) { found = arg; break; }
                        free_value(&arg);
                    }
                    free_value(&func);
                    res = found;
                }
                else if (strcmp(method, "flach") == 0) {
                    // flach() / flach(n) —— 展平嵌套数组（默认深度 1）
                    if (arg_count > 1) kr_error("flach 需要 0 或 1 个参数（深度）");
                    int depth = 1;
                    if (arg_count == 1) {
                        Value d = eval_expr(args[0]);
                        depth = (int)value_to_ll(d);
                        free_value(&d);
                    }
                    std::vector<Value> out;
                    std::function<void(Value&, int)> rec = [&](Value& v, int d) {
                        if (v.type == VAL_ARRAY && d > 0) {
                            for (int i = 0; i < v.arr_val.length; i++)
                                rec(v.arr_val.elements[i], d - 1);
                        } else {
                            out.push_back(copy_value(v));
                        }
                    };
                    rec(obj, depth);
                    res = make_array(out.data(), (int)out.size());
                    for (auto& v : out) free_value(&v);
                }
                else if (strcmp(method, "nehmen") == 0) {
                    // nehmen(n) —— 取前 n 个
                    if (arg_count != 1) kr_error("nehmen 需要 1 个参数（个数）");
                    Value nv = eval_expr(args[0]);
                    long long k = value_to_ll(nv);
                    free_value(&nv);
                    if (k < 0) k = 0;
                    if (k > obj.arr_val.length) k = obj.arr_val.length;
                    Value* elems = (Value*)malloc((size_t)k * sizeof(Value));
                    for (long long i = 0; i < k; i++)
                        elems[i] = copy_value(obj.arr_val.elements[i]);
                    res = make_array(elems, (int)k);
                    free(elems);
                }
                else if (strcmp(method, "fallen") == 0) {
                    // fallen(n) —— 丢弃前 n 个
                    if (arg_count != 1) kr_error("fallen 需要 1 个参数（个数）");
                    Value nv = eval_expr(args[0]);
                    long long k = value_to_ll(nv);
                    free_value(&nv);
                    if (k < 0) k = 0;
                    if (k > obj.arr_val.length) k = obj.arr_val.length;
                    long long cnt = obj.arr_val.length - k;
                    Value* elems = (Value*)malloc((size_t)cnt * sizeof(Value));
                    for (long long i = 0; i < cnt; i++)
                        elems[i] = copy_value(obj.arr_val.elements[k + i]);
                    res = make_array(elems, (int)cnt);
                    free(elems);
                }
                else if (strcmp(method, "zip") == 0) {
                    // zip(other) —— 与另一个数组逐元素配对成 [a, b] 数组
                    if (arg_count != 1) kr_error("zip 需要 1 个参数（数组）");
                    Value other = eval_expr(args[0]);
                    if (other.type != VAL_ARRAY) kr_error("zip 参数必须是数组");
                    long long n = std::min((long long)obj.arr_val.length,
                                           (long long)other.arr_val.length);
                    Value* pairs = (Value*)malloc((size_t)n * sizeof(Value));
                    for (long long i = 0; i < n; i++) {
                        Value two[2] = {
                            copy_value(obj.arr_val.elements[i]),
                            copy_value(other.arr_val.elements[i])
                        };
                        pairs[i] = make_array(two, 2);
                        free_value(&two[0]);
                        free_value(&two[1]);
                    }
                    res = make_array(pairs, (int)n);
                    free(pairs);
                    free_value(&other);
                }
                else if (strcmp(method, "mittel") == 0)
                    res = method_mittel(obj, args, arg_count);
                else if (strcmp(method, "produkt") == 0)
                    res = method_produkt(obj, args, arg_count);
                else if (strcmp(method, "erstes") == 0)
                    res = method_erstes(obj, args, arg_count);
                else if (strcmp(method, "einfuegen") == 0)
                    res = method_einfuegen(obj, args, arg_count, node->data.method_call.obj);
                else if (strcmp(method, "vereinige") == 0)
                    res = method_vereinige_array(obj, args, arg_count);
                else if (strcmp(method, "schnitt") == 0)
                    res = method_schnitt(obj, args, arg_count);
                else if (strcmp(method, "differenz") == 0)
                    res = method_differenz(obj, args, arg_count);
                else if (strcmp(method, "entferne") == 0)
                    res = method_entferne_array(obj, args, arg_count, node->data.method_call.obj);
                else if (strcmp(method, "mische") == 0)
                    res = method_mische(obj, args, arg_count, node->data.method_call.obj);
                else if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
                    if (arg_count != 0) kr_error("alt 对数组不需要参数");
                    char* s = value_to_string(obj);
                    res = make_string(s);
                    free(s);
                }
                else {
                    kr_error("未知数组方法 '%s'", method);
                }
                free_value(&obj);
            }
            else if (obj.type == VAL_INT || obj.type == VAL_INT64 || obj.type == VAL_FLOAT) {
                // 数字方法
                if (strcmp(method, "alsText") == 0 || strcmp(method, "alt") == 0) {
                    res = method_alsText(obj, args, arg_count);
                } else if (strcmp(method, "runden") == 0) {
                    if (arg_count != 1) { kr_error("runden 需要 1 个参数（小数位数）"); }
                    Value digits_val = eval_expr(args[0]);
                    if (digits_val.type != VAL_INT && digits_val.type != VAL_INT64) { kr_error("runden 参数必须为整数"); }
                    int digits = (int)value_to_ll(digits_val);
                    if (digits < 0) { kr_error("小数位数不能为负数"); }
                    double val = (obj.type == VAL_INT || obj.type == VAL_INT64) ? mpz_get_d(*obj.big_int) : mpf_get_d(*obj.mpf_val);
                    double factor = pow(10.0, digits);
                    double rounded = round(val * factor) / factor;
                    free_value(&digits_val);
                    res = make_float(rounded);
                }
                else if (strcmp(method, "alsZahl") == 0 || strcmp(method, "alz") == 0) {
                    // 将参数节点列表传递给 method_alsZahl（第一个参数为格式串）
                    res = method_alsZahl(obj, args, arg_count);
                }
                else {
                    kr_error("数字不支持方法 '%s'", method);
                }
                free_value(&obj);
            }
            else if (obj.type == VAL_POINTER) {
                if (strcmp(method, "alt") == 0 ||
                    strcmp(method, "alsText") == 0 ) {
                    res = method_alsText(obj, args, arg_count);
                }
                // 解引用（读）：同全局函数 zgrw
                else if (strcmp(method, "zgrw") == 0) {
                    if (arg_count != 0) kr_error("zgrw 不需要参数");
                    Value* target = obj.ptr_val.smart_target
                                    ? obj.ptr_val.smart_target->get()
                                    : obj.ptr_val.raw_target;
                    if (!target) kr_error("空指针解引用");
                    if (obj.ptr_val.freed) kr_error("访问已释放的指针");
                    res = copy_value(*target);
                }
                // 解引用（写）：同全局函数 zgrs
                else if (strcmp(method, "setz") == 0 ||
                         strcmp(method, "zgrs") == 0) {
                    if (arg_count != 1) kr_error("setz/zgrs 需要 1 个参数");
                    Value* target = obj.ptr_val.smart_target
                                    ? obj.ptr_val.smart_target->get()
                                    : obj.ptr_val.raw_target;
                    if (!target) kr_error("空指针写入");
                    if (obj.ptr_val.freed) kr_error("访问已释放的指针");
                    Value v = eval_expr(args[0]);
                    free_value(target);
                    *target = copy_value(v);
                    free_value(&v);
                    res = make_null();
                }
                // 释放裸指针：同全局函数 frei
                else if (strcmp(method, "frei") == 0) {
                    if (arg_count != 0) kr_error("frei 不需要参数");
                
                    Value* p = &obj;
                    ASTNode* obj_node = node->data.method_call.obj;
                    if (obj_node && is_lvalue_node(obj_node)) {
                        Value* lv = get_mutable_ptr(obj_node);
                        if (lv && lv->type == VAL_POINTER) p = lv;
                    }
                    if (p->ptr_val.smart_target) {
                        kr_warn("frei 对智能指针无效果；引用计数自动管理生命周期");
                    } else if (p->ptr_val.raw_target) {
                        if (p->ptr_val.freed) kr_error("指针已经被释放，不能重复释放");
                        free_value(p->ptr_val.raw_target);
                        delete p->ptr_val.raw_target;
                        p->ptr_val.raw_target = nullptr;
                        p->ptr_val.freed = true;
                    }
                    res = make_null();
                }
                // 是否空指针：同全局函数 zgrNull
                else if (strcmp(method, "zgrNull") == 0) {
                    if (arg_count != 0) kr_error("zgrNull 不需要参数");
                    if (obj.ptr_val.freed) kr_error("访问已释放的指针");
                    bool is_null = (obj.ptr_val.smart_target == nullptr) &&
                                   (obj.ptr_val.raw_target  == nullptr);
                    res = make_int(is_null ? 1 : 0);
                }
                else {
                    kr_error("未知指针方法 '%s'", method);
                }
                free_value(&obj);
            }
            else if (obj.type == VAL_FUNCTION) {
                // 函数值上的方法调用
                if (strcmp(method, "aufruf") == 0 || strcmp(method, "call") == 0) {
                    // 动态调用：fn.aufruf(a, b, ...)
                    Value* call_args = (Value*)malloc(arg_count * sizeof(Value));
                    for (int i = 0; i < arg_count; i++)
                        call_args[i] = eval_expr(args[i]);
                    result = call_function_value(obj, call_args, arg_count, node);
                    for (int i = 0; i < arg_count; i++)
                        free_value(&call_args[i]);
                    free(call_args);
                }
                else if (strcmp(method, "name") == 0) {
                    if (arg_count != 0) kr_error("name 不需要参数");
                    result = make_string(obj.func_val.name ? obj.func_val.name : "anonym");
                }
                else if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
                    if (arg_count != 0) kr_error("alt 不需要参数");
                    char* s = value_to_string(obj);
                    result = make_string(s);
                    free(s);
                }
                else {
                    kr_error("函数不支持方法 '%s'", method);
                }
                free_value(&obj);
            }
            else {
                kr_error("不支持的方法调用类型 (类型 %d)", obj.type);
            }
            result = res;
            return_caught = false;
            exception_raised = false;
            break;
         }
         case NODE_TERNARY: {
             Value cond = eval_expr(node->data.ternary.cond);
             int c = value_to_bool(cond);
             free_value(&cond);
             if (c) result = eval_expr(node->data.ternary.true_expr);
             else result = eval_expr(node->data.ternary.false_expr);
             break;
         }
        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC: {
            ASTNode* operand = node->data.inc_dec.operand;
            const bool is_inc  = (node->type == NODE_PRE_INC || node->type == NODE_POST_INC);
            const bool is_post = (node->type == NODE_POST_INC || node->type == NODE_POST_DEC);

            // ============================================================
            // 快速路径：current_scope 内的普通 int64 局部变量
            // 所有条件都是"必须满足才走快线"，任何一条不满足立即回退
            // ============================================================
            if (operand->type == NODE_VARIABLE
                && current_scope
                && current_scope != original_global_scope) {

                const char* name = operand->data.var_name;
                Variable* var = nullptr;
                const char c0 = name[0];

                // 只扫 current_scope 自己这一层（thread_local，无需锁）
                for (int i = 0; i < current_scope->var_count; ++i) {
                    Variable* v = &current_scope->vars[i];
                    if (v->name[0] == c0 && strcmp(v->name, name) == 0) {
                        var = v;
                        break;
                    }
                }

                if (var
                    && !var->is_const
                    && !var->is_lazy
                    && !var->is_alias
                    && var->value.type == VAL_INT64) {

                    const int64_t old = var->value.int64_val;
                    const bool overflow = is_inc ? (old == INT64_MAX)
                                                : (old == INT64_MIN);

                    if (!overflow) {
                        var->value.int64_val = is_inc ? (old + 1) : (old - 1);
                        var->is_read = true;
                        result = make_int64(is_post ? old : var->value.int64_val);
                        break;   // 快线完成
                    }
                    // 溢出 → 落到慢线，让 inc_value/dec_value 走 GMP 提升逻辑
                }
            }

            // ============================================================
            // 常规路径
            // ============================================================
            Value* ptr = get_mutable_ptr(operand);
            if (is_post) {
                Value old = copy_value(*ptr);
                if (is_inc) inc_value(ptr);
                else        dec_value(ptr);
                result = old;
            } else {
                if (is_inc) inc_value(ptr);
                else        dec_value(ptr);
                result = copy_value(*ptr);
            }
            break;
        }
         
         case NODE_OBJECT_LITERAL: {
            ObjectEntry* entries = (ObjectEntry*)malloc(node->data.object_lit.count * sizeof(ObjectEntry));
            for (int i = 0; i < node->data.object_lit.count; i++) {
                Value key_val = eval_expr(node->data.object_lit.key_exprs[i]);
                char* key_str = value_to_string(key_val);
                free_value(&key_val);
                entries[i].key = key_str;                // 后面会被 strdup，但需先存储
                entries[i].value = eval_expr(node->data.object_lit.vals[i]);
            }
            result = make_object(entries, node->data.object_lit.count);
            // 释放临时 entries（make_object 已深拷贝）
            for (int i = 0; i < node->data.object_lit.count; i++) {
                free(entries[i].key);
                free_value(&entries[i].value);
            }
            free(entries);
            break;
        }
        case NODE_OBJECT_ACCESS: {
            // ===== 0. 命名空间成员访问=====
            if (node->data.object_access.obj->type == NODE_VARIABLE) {
                std::string var_name = node->data.object_access.obj->data.var_name;
                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                auto ns_it = named_scopes.find(var_name);
                if (ns_it != named_scopes.end()) {
                    std::string key = node->data.object_access.key;
                    Scope* ns = ns_it->second;
        
                    // (a) 命名空间里直接定义了同名变量 → 返回它
                    int idx = get_var_index_in_scope(ns, key.c_str());
                    if (idx >= 0) {
                        result = copy_value(ns->vars[idx].value);
                        break;
                    }
        
                    // (b) 否则当作"类引用"返回，让外层的 .x 去查静态属性
                    //     先试带命名空间前缀，再试裸名（兼容 type_key 改造前后的两种注册方式）
                    std::string qualified = var_name + "::" + key;
                    auto cls_it = class_table.find(qualified);
                    if (cls_it == class_table.end()) cls_it = class_table.find(key);
                    if (cls_it != class_table.end()) {
                        ObjectEntry e[1];
                        e[0].key = strdup("__umf_klass");
                        e[0].value = make_string(cls_it->first.c_str());  // 存真实注册名
                        result = make_object(e, 1);
                        free(e[0].key);
                        free_value(&e[0].value);
                        break;
                    }

                    // (c) 类型别名（art int = gzl 之类）
                    //     同样先试限定名（A::int），再回退裸名
                    auto ta_it = type_aliases.find(qualified);
                    if (ta_it == type_aliases.end()) ta_it = type_aliases.find(key);
                    if (ta_it != type_aliases.end()) {
                        // 返回类型名字符串，供 typist / 打印等场景使用
                        std::string type_name = type_to_string(ta_it->second);
                        result = make_string(type_name.c_str());
                        break;
                    }

                    // (d) 枚举类型名（aufz E { ... } 里的 E）
                    auto enum_it = enum_table.find(qualified);
                    if (enum_it == enum_table.end()) enum_it = enum_table.find(key);
                    if (enum_it != enum_table.end()) {
                        ObjectEntry e[1];
                        e[0].key = strdup("__umf_enum");
                        e[0].value = make_string(enum_it->first.c_str());
                        result = make_object(e, 1);
                        free(e[0].key);
                        free_value(&e[0].value);
                        break;
                    }
        
                    kr_error("命名空间 '%s' 中没有成员 '%s'",
                             var_name.c_str(), key.c_str());
                }
            }
        
            // ===== 0b. 类引用对象的成员访问=====
            if (node->data.object_access.obj->type == NODE_OBJECT_ACCESS) {
                Value obj_val = eval_expr(node->data.object_access.obj);
                bool is_klass_ref = false;
                std::string klass_name;
                if (obj_val.type == VAL_OBJECT) {
                    for (int i = 0; i < obj_val.obj_val.count; i++) {
                        if (strcmp(obj_val.obj_val.entries[i].key, "__umf_klass") == 0 &&
                            obj_val.obj_val.entries[i].value.type == VAL_STRING) {
                            klass_name = obj_val.obj_val.entries[i].value.str_val;
                            is_klass_ref = true;
                            break;
                        }
                    }
                }
                free_value(&obj_val);
                if (is_klass_ref) {
                    std::string key = node->data.object_access.key;
                    std::string prop_key = klass_name + "::" + key;
                    Value v;
                    if (try_get_static_property(prop_key, v)) {
                        result = v;
                        break;
                    }
                    kr_error("类 '%s' 没有静态属性 '%s'",
                             klass_name.c_str(), key.c_str());
                }
            }
            // ---- 1. 判断是否为静态属性访问 ----
            if (node->data.object_access.obj->type == NODE_VARIABLE) {
                std::string var_name = node->data.object_access.obj->data.var_name;
                Variable* var = get_var(var_name.c_str());
                if (!var) {
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    auto class_it = class_table.find(var_name);
                    if (class_it != class_table.end()) {
                        ClassDef& cls = class_it->second;
                        std::string prop_key = class_it->first + "::" + node->data.object_access.key;
        
                        // ---- 访问权限检查（只需一次） ----
                        bool prop_defined = false;
                        for (const auto& prop : cls.properties) {
                            if (prop.name == node->data.object_access.key && prop.is_static) {
                                check_access(prop.access, cls.defining_file,
                                             cls.name, node->data.object_access.key,
                                             var_name, node);
                                prop_defined = true;
                                break;
                            }
                        }
        
                        if (!prop_defined) {
                            // 检查是否有同名的非静态属性
                            bool has_instance_prop = false;
                            for (const auto& prop : cls.properties) {
                                if (prop.name == node->data.object_access.key && !prop.is_static) {
                                    has_instance_prop = true;
                                    break;
                                }
                            }
                            if (has_instance_prop) {
                                kr_error("属性 '%s' 是类 '%s' 的实例属性，不能通过类名访问。"
                                         "请先实例化：'x = %s()'，再使用 'x.%s'",
                                         node->data.object_access.key, var_name.c_str(),
                                         var_name.c_str(), node->data.object_access.key);
                            }
                            kr_error("静态属性 '%s' 未在类 '%s' 中定义",
                                     node->data.object_access.key, var_name.c_str());
                        }
        
                        // ---- 读取：优先缓存，其次惰性求值 ----
                        Value v;
                        if (try_get_static_property(prop_key, v)) {
                            result = v;
                            break;
                        }
        
                        // ---- 回退：登记了属性但两个表都没有（例如有类型但无默认值）----
                        for (const auto& prop : cls.properties) {
                            if (prop.name == node->data.object_access.key && prop.is_static) {
                                if (prop.type) {
                                    ASTNode* default_ast = make_default_value_for_type(prop.type);
                                    Value init_val = eval_expr(default_ast);
                                    free_ast(default_ast);
                                    static_props[prop_key] = copy_value(init_val);
                                    result = init_val;
                                } else {
                                    result = make_null();
                                }
                                break;
                            }
                        }
                        break;   // 静态分支处理完毕
                    }
                }
            }
        
            // ---- 2. 普通对象属性访问 ----
            Value obj = eval_expr(node->data.object_access.obj);
            char* key = node->data.object_access.key;
            bool is_optional = node->data.object_access.is_optional;
            bool found = false;
        
            // ---- 2a. 可选链 null 短路 ----
            if (obj.type == VAL_NULL && is_optional) {
                result = make_null();
                free_value(&obj);
                break;
            }
        
            // ---- 2b. KD 数据集特殊处理 ----
            if (obj.type == VAL_OBJECT) {
                std::shared_ptr<KDDataSet> ds_ptr;
                uint64_t rec_id = 0;
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, "__kd_daten") == 0) {
                        Value& inner = obj.obj_val.entries[i].value;
                        if (inner.type == VAL_OBJECT && inner.obj_val.count >= 1 &&
                            strcmp(inner.obj_val.entries[0].key, "__zgr") == 0 &&
                            (inner.obj_val.entries[0].value.type == VAL_INT ||
                             inner.obj_val.entries[0].value.type == VAL_INT64)) {
                            ds_ptr = *(std::shared_ptr<KDDataSet>*)value_to_ll(inner.obj_val.entries[0].value);
                        }
                    }
                    if (strcmp(obj.obj_val.entries[i].key, "__kd_id") == 0 &&
                        (obj.obj_val.entries[i].value.type == VAL_INT ||
                         obj.obj_val.entries[i].value.type == VAL_INT64)) {
                        rec_id = value_to_ll(obj.obj_val.entries[i].value);
                    }
                }
                if (ds_ptr) {
                    if (strcmp(key, "text") == 0) {
                        Record rec = ds_ptr->get_record(rec_id);
                        result = make_string(rec.text.c_str());
                        found = true;
                    } else if (strcmp(key, "daten") == 0) {
                        Record rec = ds_ptr->get_record(rec_id);
                        Value* elems = (Value*)malloc(rec.data.size() * sizeof(Value));
                        for (size_t i = 0; i < rec.data.size(); ++i) elems[i] = make_int(rec.data[i]);
                        result = make_array(elems, (int)rec.data.size());
                        free(elems);
                        found = true;
                    }
                    if (found) { free_value(&obj); break; }
                }
            }
        
            // ---- 2c. 规则句柄处理 ----
            int rule_id = -1;
            if (obj.type == VAL_OBJECT) {
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, "__reg_id") == 0 &&
                        (obj.obj_val.entries[i].value.type == VAL_INT ||
                         obj.obj_val.entries[i].value.type == VAL_INT64)) {
                        rule_id = (int)value_to_ll(obj.obj_val.entries[i].value);
                        break;
                    }
                }
            }
            if (rule_id != -1 && !found) {
                auto it = rule_states.find(rule_id);
                if (it != rule_states.end()) {
                    std::lock_guard<std::mutex> lock(it->second->mtx);
                    Value cached = copy_value(it->second->cached_value);
                    if (cached.type == VAL_OBJECT) {
                        for (int i = 0; i < cached.obj_val.count; i++) {
                            if (strcmp(cached.obj_val.entries[i].key, key) == 0) {
                                result = copy_value(cached.obj_val.entries[i].value);
                                found = true;
                                break;
                            }
                        }
                        if (!found && is_optional) { result = make_null(); found = true; }
                    } else if (cached.type == VAL_NULL) {
                        if (is_optional) { result = make_null(); found = true; }
                        else kr_error("规则尚未产生结果");
                    } else {
                        if (is_optional) { result = make_null(); found = true; }
                        else kr_error("规则结果不是对象，无法访问属性 '%s'", key);
                    }
                    free_value(&cached);
                    if (found) { free_value(&obj); break; }
                }
            }
        
            // ---- 2d. 对象 .län（惰性 Range 或对象属性数） ----
            if (!found && obj.type == VAL_OBJECT && strcmp(key, "län") == 0) {
                if (is_lazy_range(obj)) {
                    int64_t rs, re, rstep;
                    extract_range_params(obj, rs, re, rstep);
                    result = make_int64(lazy_range_count(rs, re, rstep));
                    free_value(&obj);
                    break;
                }
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, "län") == 0) {
                        result = copy_value(obj.obj_val.entries[i].value);
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    result = make_int(obj.obj_val.count);
                    found = true;
                }
                free_value(&obj);
                break;
            }
        
            // ---- 2e. 普通对象属性访问 + 实例惰性回退 ----
            if (!found && obj.type == VAL_OBJECT) {
                // ---- 先查自有属性 ----
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, key) == 0) {
                        result = copy_value(obj.obj_val.entries[i].value);
                        found = true;
                        break;
                    }
                }
                if (found) { free_value(&obj); break; }
            
                // ---- 取对象所属类 ----
                std::string obj_class;
                for (int i = 0; i < obj.obj_val.count; i++) {
                    if (strcmp(obj.obj_val.entries[i].key, "__klass") == 0 &&
                        obj.obj_val.entries[i].value.type == VAL_STRING) {
                        obj_class = obj.obj_val.entries[i].value.str_val;
                        break;
                    }
                }
            
                // ---- 沿继承链查找属性定义 ----
                if (!obj_class.empty()) {
                    std::string cur = obj_class;
                    while (!cur.empty()) {
                        auto it = class_table.find(cur);
                        if (it == class_table.end()) break;
            
                        bool is_defined  = false;
                        int  access_level = 0;
                        const PropertyDef* lazy_prop = nullptr;
                        for (const auto& prop : it->second.properties) {
                            if (prop.name == key && !prop.is_static) {
                                is_defined   = true;
                                access_level = prop.access;
                                if (prop.is_lazy) lazy_prop = &prop;
                                break;
                            }
                        }
            
                        if (is_defined) {
                            //  权限检查（原代码里有，别丢）
                            check_access(access_level, it->second.defining_file,
                                         cur, key, obj_class, node);
            
                            if (lazy_prop) {
                                // ---- 惰性属性：首次访问求值 + 回写 ----
                                Value v;
                                if (lazy_prop->default_expr) {
                                    v = eval_expr(lazy_prop->default_expr);
                                } else if (lazy_prop->type) {
                                    ASTNode* dflt = make_default_value_for_type(lazy_prop->type);
                                    v = eval_expr(dflt);
                                    free_ast(dflt);            //  释放临时 AST
                                } else {
                                    v = make_null();
                                }
                                if (lazy_prop->type && !check_type(lazy_prop->type, v)) {
                                    char* got = value_to_string(v);
                                    std::string expected = type_to_string(lazy_prop->type);
                                    std::string msg = "惰性属性 '" + std::string(key) +
                                                      "' 初始化类型错误: 期望 '" + expected +
                                                      "', 实际 '" + std::string(got) + "'";
                                    free(got);
                                    free_value(&v);
                                    kr_error("%s", msg.c_str());
                                }
            
                                result = copy_value(v);
            
                                // ---- 回写到原始对象（仅可寻址左值） ----
                                ASTNode* obj_node = node->data.object_access.obj;
                                if (obj_node->type == NODE_VARIABLE) {
                                    Variable* var = get_var(obj_node->data.var_name);
                                    if (var && !var->is_const && !var->is_lazy) {
                                        var = resolve_alias(var);
                                        if (var->value.type == VAL_OBJECT) {
                                            Value* target = &var->value;
                                            // 防重复：检查是否已被其他路径回写
                                            bool already = false;
                                            for (int i = 0; i < target->obj_val.count; i++) {
                                                if (strcmp(target->obj_val.entries[i].key, key) == 0) {
                                                    already = true; break;
                                                }
                                            }
                                            if (!already) {
                                                target->obj_val.count++;
                                                target->obj_val.entries = (ObjectEntry*)realloc(
                                                    target->obj_val.entries,
                                                    target->obj_val.count * sizeof(ObjectEntry));
                                                target->obj_val.entries[target->obj_val.count - 1].key
                                                    = strdup(key);
                                                target->obj_val.entries[target->obj_val.count - 1].value
                                                    = copy_value(v);
                                            }
                                        }
                                    }
                                }
                                free_value(&v);
                            } else {
                                //  非惰性属性：构造时已初始化到对象里；对象里却没有 → 视为 null
                                result = make_null();
                            }
                            found = true;
                            break;  // 命中即停，不再往父类找
                        }
            
                        if (it->second.parent.empty()) break;
                        cur = it->second.parent;
                    }
                }
            
                if (!found) {
                    if (is_optional) result = make_null();
                    else {
                        kr_warn("在对象中未找到键 '%s'，返回 null", key);
                        result = make_null();
                    }
                }
                free_value(&obj);
                break;
            }
        
            // ---- 2f. 数组/字符串 .län ----
            if (!found && obj.type == VAL_ARRAY && strcmp(key, "län") == 0) {
                result = make_int(obj.arr_val.length);
                free_value(&obj);
                break;
            }
            if (!found && obj.type == VAL_STRING && strcmp(key, "län") == 0) {
                result = make_int((long long)utf8_length(std::string(obj.str_val, obj.str_len)));
                free_value(&obj);
                break;
            }
        
            // ---- 2g. 兜底 ----
            if (!found) {
                if (is_optional) result = make_null();
                else kr_error("无法访问属性 '%s' 在类型 %d 上", key, obj.type);
                free_value(&obj);
                break;
            }
            break;
        }
        case NODE_OBJECT_ASSIGN:
            kr_error("对象赋值不能作为表达式使用");
            break;
        case NODE_NULL_COALESCE: {
            Value left = eval_expr(node->data.null_coalesce.left);
            if (left.type != VAL_NULL) {
                result = copy_value(left);   // 显式深拷贝
                free_value(&left);           // 释放原值
            } else {
                free_value(&left);
                result = eval_expr(node->data.null_coalesce.right);
            }
            break;
        }
        case NODE_RANGE: {
            Value start = eval_expr(node->data.range.start);
            Value end = eval_expr(node->data.range.end);
            if (!(start.type == VAL_INT || start.type == VAL_INT64)) {
                free_value(&start); free_value(&end);
                kr_error("范围边界必须是整数\n");
            }
            if (!(end.type == VAL_INT || end.type == VAL_INT64)) {
                free_value(&start); free_value(&end);
                kr_error("范围边界必须是整数\n");
            }
            long long s = value_to_ll(start);
            long long e = value_to_ll(end);
            free_value(&start); free_value(&end);
        
            long long step = 1;
            if (node->data.range.step) {
                Value step_val = eval_expr(node->data.range.step);
                Value int_step_val = to_integer_value(step_val);
                free_value(&step_val);
                step = value_to_ll(int_step_val);
                free_value(&int_step_val);
                if (step == 0) {
                    kr_error("步长不能为0");
                }
            } else {
                step = (s <= e) ? 1 : -1;
            }
        
            // 惰性 Range 对象：不展开为数组，按需使用
            ObjectEntry entries[4];
            entries[0].key = strdup("__range");
            entries[0].value = make_int(1LL);
            entries[1].key = strdup("start");
            entries[1].value = make_int64(s);
            entries[2].key = strdup("end");
            entries[2].value = make_int64(e);
            entries[3].key = strdup("step");
            entries[3].value = make_int64(step);
            result = make_object(entries, 4);
            for (int i = 0; i < 4; i++) {
                free(entries[i].key);
                free_value(&entries[i].value);
            }
            break;
        }
        case NODE_LIST_COMPREHENSION: {
            Value coll = eval_expr(node->data.list_comp.collection);
            if (coll.type != VAL_ARRAY && coll.type != VAL_OBJECT) {
                kr_error("推导式集合必须是数组或对象\n");
                
            }
            Value* result_elems = NULL;
            int result_count = 0;
            // 保存旧作用域，创建新作用域用于循环变量
            push_scope();
            declare_var(node->data.list_comp.var_name, false, make_int(0LL));
            if (coll.type == VAL_ARRAY) {
                for (long long i = 0; i < coll.arr_val.length; i++) {
                    // 声明变量 var_name
                    declare_var(node->data.list_comp.var_name, false,
                                copy_value(coll.arr_val.elements[i]));
                    // 条件检查
                    if (node->data.list_comp.cond) {
                        Value cond_val = eval_expr(node->data.list_comp.cond);
                        int c = value_to_bool(cond_val);
                        free_value(&cond_val);
                        if (!c) continue;   // 跳过当前迭代
                    }
                    // 求值表达式
                    Value elem_val = eval_expr(node->data.list_comp.expr);
                    result_elems = (Value*)realloc(result_elems, (result_count+1)*sizeof(Value));
                    result_elems[result_count++] = elem_val;
                }
            } else { // VAL_OBJECT
                for (int i = 0; i < coll.obj_val.count; i++) {
                    // 声明循环变量（值为对象属性的值）
                    declare_var(node->data.list_comp.var_name, false,
                                copy_value(coll.obj_val.entries[i].value));
                    // 条件检查
                    if (node->data.list_comp.cond) {
                        Value cond_val = eval_expr(node->data.list_comp.cond);
                        int c = value_to_bool(cond_val);
                        free_value(&cond_val);
                        if (!c) continue;   // 跳过当前迭代
                    }
                    // 求值表达式
                    Value elem_val = eval_expr(node->data.list_comp.expr);
                    result_elems = (Value*)realloc(result_elems, (result_count + 1) * sizeof(Value));
                    result_elems[result_count++] = elem_val;
                }
            }
            pop_scope();
            free_value(&coll);
            result = make_array(result_elems, result_count);
            free(result_elems);
            break;
        }
        case NODE_OBJECT_COMPREHENSION: {
            Value coll = eval_expr(node->data.object_comp.collection);
            if (coll.type != VAL_ARRAY && coll.type != VAL_OBJECT)
                kr_error("对象推导式的集合必须是数组或对象");
            ObjectEntry* entries = nullptr;
            int count = 0;
            push_scope();
            // 声明第一个变量（必需）
            declare_var(node->data.object_comp.var_name, false, make_null());
            // 如果有第二个变量，也声明
            if (node->data.object_comp.value_var)
                declare_var(node->data.object_comp.value_var, false, make_null());
        
            auto process = [&](Value elem, const char* key_str = nullptr) {
                // 绑定变量
                if (node->data.object_comp.value_var && key_str) {
                    // 双变量模式：var_name 绑定键，value_var 绑定值
                    set_var(node->data.object_comp.var_name, make_string(key_str));
                    set_var(node->data.object_comp.value_var, copy_value(elem));
                } else {
                    // 单变量模式：var_name 绑定值（或数组元素）
                    set_var(node->data.object_comp.var_name, copy_value(elem));
                }
                // 条件过滤
                if (node->data.object_comp.cond) {
                    Value cond_val = eval_expr(node->data.object_comp.cond);
                    int ok = value_to_bool(cond_val);
                    free_value(&cond_val);
                    if (!ok) return;
                }
                // 计算键和值
                Value key_val = eval_expr(node->data.object_comp.key_expr);
                char* key_str2 = value_to_string(key_val);
                free_value(&key_val);
                Value val = eval_expr(node->data.object_comp.value_expr);
                entries = (ObjectEntry*)realloc(entries, (count + 1) * sizeof(ObjectEntry));
                entries[count].key = strdup(key_str2);
                entries[count].value = val;
                count++;
                free(key_str2);
            };
        
            if (coll.type == VAL_ARRAY) {
                for (long long i = 0; i < coll.arr_val.length; ++i) {
                    process(coll.arr_val.elements[i]);
                }
            } else { // VAL_OBJECT
                for (int i = 0; i < coll.obj_val.count; ++i) {
                    process(coll.obj_val.entries[i].value, coll.obj_val.entries[i].key);
                }
            }
        
            pop_scope();
            free_value(&coll);
            Value obj = make_object(entries, count);
            for (int i = 0; i < count; ++i) {
                free(entries[i].key);
                free_value(&entries[i].value);
            }
            free(entries);
            result = obj;
            break;
        }
        case NODE_FUNC_DEF: {
            Scope* captured = copy_scope_chain(current_scope);
            Value func_val = make_function(
                NULL,                                 // name
                node->data.func_def.params,           // params
                node->data.func_def.param_count,      // param_count
                node->data.func_def.body,             // body
                captured,                             // closure
                node->data.func_def.is_memoized,      // is_memoized
                false,                                // is_async
                false,                                // global_scope
                false,                                // is_rule
                node->data.func_def.return_type,      // ret_type
                nullptr,                              // vararg_name
                node->data.func_def.param_is_const,   // param_is_const
                node->data.func_def.param_defaults,   // param_defaults
                node->data.func_def.param_types,
                node->data.func_def.vararg_type
            );
            return func_val;
        }
        case NODE_VARIABLE: {
            Variable* var = get_var(node->data.var_name);
            if (!var) {
                // ---- 尝试从当前类的静态属性中读取 ----
                if (g_current_class_name) {
                    std::string key = std::string(g_current_class_name) + "::" + node->data.var_name;
                    Value v;
                    if (try_get_static_property(key, v)) {
                        result = v;
                        break;
                    }
                }
                // ---- 错误处理 ----
                char buf[256];
                std::string hint = suggest_correction(node->data.var_name);
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "变量 '%s' 未在当前作用域声明", node->data.var_name);
                if (!hint.empty())
                    throw KRError(buf, hint.c_str());
                else
                    throw KRError(buf);
            }
            var = resolve_alias(var); 
            bool handled = false;

            // ---- 惰性变量：首次读取时求值 ----
            if (var->is_lazy) {
                if (!var->evaluated) {
                    Scope* saved = current_scope;
                    current_scope = var->lazy_scope ? var->lazy_scope : saved;   //  切回声明点
                    Value v = eval_expr(var->init_expr);
                    current_scope = saved;
                    var->cached_value = copy_value(v);
                    var->evaluated = true;
                    free_value(&v);
                }
                result = copy_value(var->cached_value);
                handled = true;
            }

            // 检查是否为无参枚举变体
            if (!handled && var->value.type == VAL_FUNCTION && var->value.func_val.name) {
                auto it = variant_table.find(var->value.func_val.name);
                if (it != variant_table.end() && it->second.second == 0) {
                    // 构造无参枚举对象
                    const std::string& variant_name = var->value.func_val.name;
                    ObjectEntry entries[2];
                    entries[0].key = strdup("__tag");
                    entries[0].value = make_string(variant_name.c_str());
                    entries[1].key = strdup("__felder");
                    entries[1].value = make_array(nullptr, 0);
                    result = make_object(entries, 2);
                    // 释放临时 entries
                    free(entries[0].key); free_value(&entries[0].value);
                    free(entries[1].key); free_value(&entries[1].value);
                    handled = true;
                }
            }
            if (!handled) {
                bool is_parent_data_structure = false;
                // 检查当前节点的父节点是否为对象字面量或数组字面量
                if (g_eval_node_stack.size() >= 2) {
                    ASTNode* parent = g_eval_node_stack[g_eval_node_stack.size() - 2];
                    if (parent && (parent->type == NODE_OBJECT_LITERAL || parent->type == NODE_ARRAY_LITERAL)) {
                        is_parent_data_structure = true;
                    }
                }
                if (is_parent_data_structure && var->value.type == VAL_OBJECT) {
                    result = copy_value(var->value);
                } else {
                    // 检查父节点是否为属性访问或方法调用
                    bool is_parent_access = false;
                    if (g_eval_node_stack.size() >= 2) {
                        ASTNode* parent = g_eval_node_stack[g_eval_node_stack.size() - 2];
                        if (parent && (parent->type == NODE_OBJECT_ACCESS || parent->type == NODE_METHOD_CALL)) {
                            is_parent_access = true;
                        }
                    }
                    if (!is_parent_access && var->value.type == VAL_OBJECT) {
                        bool found_default = false;
                        for (int i = 0; i < var->value.obj_val.count; i++) {
                            if (strcmp(var->value.obj_val.entries[i].key, "__stdwert") == 0) {
                                result = copy_value(var->value.obj_val.entries[i].value);
                                found_default = true;
                                break;
                            }
                        }
                        if (!found_default) {
                            result = copy_value(var->value);
                        }
                    } else {
                        result = copy_value(var->value);
                    }
                }
            }
            break;
        }
        case NODE_NULL:
            result = make_null();
            break;
        case NODE_ASSIGN: {
            Value rhs = eval_expr(node->data.assign.expr);
            result = copy_value(rhs);        // 表达式需要返回值 → 一份独立副本
            assign_to_target(node, rhs);     // rhs 移动进目标
            break;
        }
        case NODE_AWAIT: {
            // 求值基础表达式
            Value base_val = eval_expr(node->data.await.expr);
            
            // 超时处理（若有）
            long long timeout_ms = -1;
            if (node->data.await.timeout) {
                Value t = eval_expr(node->data.await.timeout);
                if (t.type != VAL_INT && t.type != VAL_FLOAT) {
                    kr_warn("超时时间必须是数字，忽略");
                } else {
                    timeout_ms = (long long)value_to_double(t);
                    if (timeout_ms < 0) timeout_ms = 0;
                }
                free_value(&t);
            }
            
            // 提取 Future ID
            std::vector<int> future_ids;
            if (base_val.type == VAL_ARRAY) {
                for (int i = 0; i < base_val.arr_val.length; ++i) {
                    if (base_val.arr_val.elements[i].type != VAL_FUTURE) {
                        kr_warn("warte 数组元素不是 Future，跳过");
                        continue;
                    }
                    future_ids.push_back(base_val.arr_val.elements[i].future_state.future_id);
                }
                free_value(&base_val);
            } else if (base_val.type == VAL_FUTURE) {
                future_ids.push_back(base_val.future_state.future_id);
                free_value(&base_val);
            } else {
                kr_warn("warte 需要 Future 或 Future 数组，返回 null");
                free_value(&base_val);
                result = make_null();
                break;
            }
            
            if (future_ids.empty()) {
                result = make_null();
                break;
            }
            
            // 从 map 中取出所有 shared_future
            std::vector<std::shared_future<std::shared_ptr<Value>>> shared_futures;
            {
                std::lock_guard<std::mutex> lock(future_map_mutex);
                for (int id : future_ids) {
                    auto it = future_map.find(id);
                    if (it == future_map.end()) {
                        kr_warn("无效的 Future ID: %d，跳过", id);
                        continue;
                    }
                    shared_futures.push_back(it->second);
                    future_map.erase(it);
                }
            }
            
            if (shared_futures.empty()) {
                kr_warn("没有有效的 Future 可等待，返回 null");
                result = make_null();
                break;
            }
            
            // 只有在异步上下文中才需要释放锁（主线程调用 warte 时无需释放）
            ScopedLockRelease lock_releaser(g_global_mutex);
            if (g_in_async_context) {
                lock_releaser.release();   // 释放全局锁，允许其他线程访问共享状态
            }
            
            // ---------- 等待所有 Future（异常安全） ----------
            std::vector<Value> results;
            results.reserve(shared_futures.size());
            bool timeout_occurred = false;
            bool waiting_exception = false;   // 标记等待过程中是否抛出异常
            
            try {
                if (timeout_ms >= 0) {
                    auto start = std::chrono::steady_clock::now();
                    for (auto& sf : shared_futures) {
                        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                            std::chrono::steady_clock::now() - start).count();
                        long long remaining = timeout_ms - elapsed;
                        if (remaining <= 0) {
                            timeout_occurred = true;
                            break;
                        }
                        try {
                            auto status = sf.wait_for(std::chrono::milliseconds(remaining));
                            if (status == std::future_status::timeout) {
                                timeout_occurred = true;
                                break;
                            }
                            results.push_back(copy_value(*sf.get()));
                        } catch (const std::exception& e) {
                            kr_warn("等待 Future 时异常: %s，忽略该 Future", e.what());
                            // 不加入结果
                        }
                    }
                } else {
                    for (auto& sf : shared_futures) {
                        try {
                            results.push_back(copy_value(*sf.get()));
                        } catch (const std::exception& e) {
                            kr_warn("等待 Future 时异常: %s，忽略该 Future", e.what());
                        }
                    }
                }
            } catch (...) {
                // 如果等待过程中发生了未预期的异常，确保重新加锁
                waiting_exception = true;
            }
            
            lock_releaser.relock();
            
            // ---------- 处理超时/异常 ----------
            if (waiting_exception) {
                // 如果等待过程中抛出异常，我们已重新加锁，现在重新抛出
                throw;
            }
            
            if (timeout_occurred) {
                if (node->data.await.fallback) {
                    // 此时已持有锁，可以安全求值 fallback
                    Value fallback_val = eval_expr(node->data.await.fallback);
                    for (auto& v : results) free_value(&v);
                    result = fallback_val;
                } else {
                    for (auto& v : results) free_value(&v);
                    kr_warn("warte 超时，返回 null");
                    result = make_null();
                }
                break;
            }
            
            // 正常返回结果
            if (results.size() == 1) {
                result = results[0];
            } else {
                result = make_array(results.data(), (int)results.size());
                for (auto& v : results) free_value(&v);
            }
            break;
        }
        case NODE_STRING_INTERP: {
            std::string output;
            for (int i = 0; i < node->data.string_interp.count; i++) {
                ASTNode* frag = node->data.string_interp.fragments[i];
                if (frag->type == NODE_STRING) {
                    output.append(frag->data.string, frag->string_len);
                } else {
                    Value v = eval_expr(frag);
                    if (v.type == VAL_STRING) {
                        output.append(v.str_val, v.str_len);
                    } else {
                        char* s = value_to_string(v);
                        output += s;
                        free(s);
                    }
                    free_value(&v);
                }
            }
            result = make_string_len(output.data(), output.size());
            break;
        }
        case NODE_NEW: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            char* cls_name = node->data.new_expr.class_name;
            auto it = class_table.find(cls_name);
            if (it == class_table.end()) {
                std::string hint = suggest_correction(cls_name);
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "未定义类 '%s'", cls_name);
            }
            ClassDef& cls = it->second;
        
            // 静态类检查
            if (cls.is_static_class) {
                kr_error("静态类 '%s' 不能实例化", cls_name);
            }
        
            // 访问权限检查（私有/保护）
            if (cls.access_modifier == 1) {
                const char* caller_file = current_filename ? current_filename : "";
                if (strcmp(caller_file, cls.defining_file.c_str()) != 0) {
                    kr_error("无法在文件 '%s' 中实例化私有类 '%s'（定义于 '%s'）",
                             caller_file, cls_name, cls.defining_file.c_str());
                }
            } else if (cls.access_modifier == 2) {
                const char* caller_file = current_filename ? current_filename : "";
                if (strcmp(caller_file, cls.defining_file.c_str()) != 0) {
                    kr_error("无法在文件 '%s' 中实例化保护类 '%s'（定义于 '%s'）",
                             caller_file, cls_name, cls.defining_file.c_str());
                }
            }
        
            int expected = (int)cls.ctor_params.size();
            int argc = node->data.new_expr.arg_count;
            if (argc > expected)
                kr_error("构造函数参数过多: 期望 %d, 实际 %d", expected, argc);
        
            for (int i = argc; i < expected; ++i) {
                if (!cls.ctor_defaults[i])
                    kr_error("构造函数缺少参数 '%s' 且无默认值", cls.ctor_params[i].c_str());
            }
        
            // 构建完整参数数组
            Value* full_args = (Value*)malloc(expected * sizeof(Value));
            for (int i = 0; i < expected; ++i) {
                if (i < argc)
                    full_args[i] = eval_expr(node->data.new_expr.args[i]);
                else
                    full_args[i] = eval_expr(cls.ctor_defaults[i]);
            }
        
            // 类型检查
            for (int i = 0; i < expected; ++i) {
                TypeNode* expected_type = cls.ctor_param_types[i];
                if (expected_type && !check_type(expected_type, full_args[i])) {
                    std::string expected_str = type_to_string(expected_type);
                    char* got = value_to_string(full_args[i]);
                    kr_error("构造函数参数 '%s' 类型错误: 期望 '%s', 实际 '%s'",
                             cls.ctor_params[i].c_str(), expected_str.c_str(), got);
                }
            }
        
            // 创建对象并设置 __klass
            Value obj;
            obj.type = VAL_OBJECT;
            obj.obj_val.count = 1;
            obj.obj_val.entries = (ObjectEntry*)malloc(sizeof(ObjectEntry));
            obj.obj_val.entries[0].key = strdup("__klass");
            obj.obj_val.entries[0].value = make_string(it->first.c_str());
        
            {
                std::unordered_set<std::string> added;
                // 收集继承链：[子, 父, 祖父, ...]
                std::vector<ClassDef*> chain;
                std::string cur = cls_name;
                while (!cur.empty()) {
                    auto it2 = class_table.find(cur);
                    if (it2 == class_table.end()) break;
                    chain.push_back(&it2->second);
                    if (it2->second.parent.empty()) break;
                    cur = it2->second.parent;
                }
                // 从子到父遍历：子类先声明，父类同名属性跳过（子类覆盖）
                for (ClassDef* c : chain) {
                    for (auto& prop : c->properties) {
                        if (prop.is_static) continue;
                        if (prop.is_lazy)   continue;   // 惰性属性：构造时不求值
                        if (added.count(prop.name)) continue;   // 子类已定义 → 跳过父类同名
                        added.insert(prop.name);
            
                        Value init_val;
                        if (prop.default_expr) {
                            init_val = eval_expr(prop.default_expr);
                            if (prop.type && !check_type(prop.type, init_val)) {
                                char* got = value_to_string(init_val);
                                kr_error("属性 '%s' 初始化类型错误: 期望 '%s', 实际 '%s'",
                                         prop.name.c_str(), type_to_string(prop.type).c_str(), got);
                            }
                        } else {
                            init_val = prop.type
                                ? eval_expr(make_default_value_for_type(prop.type))
                                : make_null();
                        }
                        obj.obj_val.count++;
                        obj.obj_val.entries = (ObjectEntry*)realloc(
                            obj.obj_val.entries,
                            obj.obj_val.count * sizeof(ObjectEntry));
                        obj.obj_val.entries[obj.obj_val.count - 1].key
                            = strdup(prop.name.c_str());
                        obj.obj_val.entries[obj.obj_val.count - 1].value
                            = copy_value(init_val);
                        free_value(&init_val);
                    }
                }
            }
        
            // 执行构造函数
            if (cls.ctor_body) {
                Value* old_constructed = current_constructed_obj;
                current_constructed_obj = &obj;
            
                save_flags();
                push_scope();
                return_caught = false;
                break_caught = false;
                continue_caught = false;
                exception_raised = false;
            
                // 设置类上下文，使构造函数体内可以访问静态属性（如 zaehler++）
                std::string old_class_str;
                if (g_current_class_name) old_class_str = g_current_class_name;
                g_current_class_name_str = cls_name;
                g_current_class_name = g_current_class_name_str.c_str();
            
                for (int i = 0; i < expected; ++i) {
                    declare_var(cls.ctor_params[i].c_str(), false, copy_value(full_args[i]));
                }
            
                CallStackGuard guard(g_call_stack, node->line, node->col, cls.defining_file.c_str());
                exec_statement(cls.ctor_body);
            
                // 恢复旧类上下文
                if (old_class_str.empty()) {
                    g_current_class_name_str.clear();
                    g_current_class_name = nullptr;
                } else {
                    g_current_class_name_str = old_class_str;
                    g_current_class_name = g_current_class_name_str.c_str();
                }
            
                bool had_exception = exception_raised;
                Value ex_val = exception_value;
            
                pop_scope();
                restore_flags();
                current_constructed_obj = old_constructed;
            
                if (had_exception) {
                    char* msg = value_to_string(ex_val);
                    kr_warn("构造函数 '%s' 抛出异常: %s", cls_name, msg);
                }
            }
        
            // 释放完整参数
            for (int i = 0; i < expected; ++i)
                free_value(&full_args[i]);
            free(full_args);
        
            result = obj;
            break;
        }
        case NODE_SUPER_CALL: {
            if (!current_constructed_obj) {
                g_last_error_line = node->line;
                g_last_error_col  = node->col;
                std::string hint = make_keyword_alias_hint("ober", "ober");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "ober 只能在构造函数内使用");
            }
            char* cls_name = NULL;
            for (int i = 0; i < current_constructed_obj->obj_val.count; i++) {
                if (strcmp(current_constructed_obj->obj_val.entries[i].key, "__klass") == 0 &&
                    current_constructed_obj->obj_val.entries[i].value.type == VAL_STRING) {
                    cls_name = current_constructed_obj->obj_val.entries[i].value.str_val;
                    break;
                }
            }
            if (!cls_name) kr_error("对象缺少 __klass");
            auto it = class_table.find(cls_name);
            if (it == class_table.end()) kr_error("类定义丢失");
            ClassDef& cls = it->second;
            if (cls.parent.empty()) kr_error("当前类没有父类");
            auto it_parent = class_table.find(cls.parent);
            if (it_parent == class_table.end()) kr_error("父类未定义");
            ClassDef& parent = it_parent->second;
        
            int arg_count = node->data.super_call.arg_count;
            Value* args = (Value*)malloc(arg_count * sizeof(Value));
            for (int i = 0; i < arg_count; i++) args[i] = eval_expr(node->data.super_call.args[i]);
        
            save_flags();
            push_scope();
            return_caught = break_caught = continue_caught = exception_raised = false;
        
            // 关键修复：设置类上下文为父类，使父类构造函数中可访问父类静态属性
            std::string old_class_str;
            if (g_current_class_name) old_class_str = g_current_class_name;
            g_current_class_name_str = parent.name;
            g_current_class_name = g_current_class_name_str.c_str();
        
            for (size_t i = 0; i < parent.ctor_params.size() && i < (size_t)arg_count; i++) {
                declare_var(parent.ctor_params[i].c_str(), false, copy_value(args[i]));
            }
        
            CallStackGuard guard(g_call_stack, node->line, node->col, parent.defining_file.c_str());
        
            exec_statement(parent.ctor_body);
            bool had_exception = exception_raised;
            Value ex_val = exception_value;
            pop_scope();
            restore_flags();
        
            // 恢复旧的类上下文
            if (old_class_str.empty()) {
                g_current_class_name_str.clear();
                g_current_class_name = nullptr;
            } else {
                g_current_class_name_str = old_class_str;
                g_current_class_name = g_current_class_name_str.c_str();
            }
        
            if (had_exception) {
                char* msg = value_to_string(ex_val);
                kr_error("Super-Konstruktor von '%s' warf Fehler: %s", cls.parent.c_str(), msg);
            }
        
            free(args);
            result = make_null();
            break;
        }
        case NODE_THIS: {
            if (current_constructed_obj) {
                result = copy_value(*current_constructed_obj);
            } else {
                Variable* dies = get_var("dies");
                if (!dies) {
                    g_last_error_line = node->line;
                    g_last_error_col  = node->col;
                    std::string hint = make_keyword_alias_hint("dies", "dies");
                    kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                                  "dies 只能在构造函数或实例方法内使用");
                }
                result = copy_value(dies->value);
            }
            break;
        }
        case NODE_DEGREE: {
            Value v = eval_expr(node->data.inc_dec.operand);
            // 使用高精度 mpf_t 计算弧度
            mpf_t num_mpf, rad_mpf, pi_mpf;
            mpf_init(num_mpf);
            mpf_init(rad_mpf);
            mpf_init(pi_mpf);
            // π/180 ≈ 0.017453292519943295769236907684886
            mpf_set_d(pi_mpf, 0.017453292519943295769236907684886);
        
            if (v.type == VAL_INT || v.type == VAL_INT64) {
                mpf_set_int64(num_mpf, value_to_ll(v));
            } else if (v.type == VAL_FLOAT) {
                mpf_set_d(num_mpf, value_to_double(v));
            } else {
                mpf_clear(num_mpf);
                mpf_clear(rad_mpf);
                mpf_clear(pi_mpf);
                kr_error("度数操作数必须为数值类型");
            }
        
            mpf_mul(rad_mpf, num_mpf, pi_mpf);
            free_value(&v);
            result = make_float(rad_mpf);
        
            mpf_clear(num_mpf);
            mpf_clear(rad_mpf);
            mpf_clear(pi_mpf);
            break;
        }
        case NODE_FACTORIAL: {
            Value v = eval_expr(node->data.inc_dec.operand);
            if (v.type != VAL_INT && v.type != VAL_INT64) {
                kr_error("阶乘只支持整数");
            }
            // 获取 n 的 mpz_t
            mpz_t n_mpz;
            mpz_init(n_mpz);
            if (v.type == VAL_INT || v.type == VAL_INT64) {
                mpz_set_int64(n_mpz, value_to_ll(v));
            } else {
                mpz_set(n_mpz, *v.big_int);
            }
            if (mpz_sgn(n_mpz) < 0) {
                mpz_clear(n_mpz);
                kr_error("阶乘只支持非负整数");
            }
            // 使用 GMP 的阶乘函数（需要 n 适合 unsigned long）
            if (!mpz_fits_ulong_p(n_mpz)) {
                mpz_clear(n_mpz);
                kr_error("阶乘参数过大（超出 unsigned long）");
            }
            unsigned long n = mpz_get_ui(n_mpz);
            mpz_clear(n_mpz);
        
            mpz_t result_mpz;
            mpz_init(result_mpz);
            mpz_fac_ui(result_mpz, n);   // 计算 n!
            result = make_int(result_mpz);
            mpz_clear(result_mpz);
            free_value(&v);
            break;
        }
        case NODE_DOUBLE_FACTORIAL: {
            Value v = eval_expr(node->data.inc_dec.operand);
            if (v.type != VAL_INT && v.type != VAL_INT64) {
                kr_error("双阶乘只支持整数");
            }
            mpz_t n_mpz;
            mpz_init(n_mpz);
            if (v.type == VAL_INT || v.type == VAL_INT64) {
                mpz_set_int64(n_mpz, value_to_ll(v));
            } else {
                mpz_set(n_mpz, *v.big_int);
            }
            if (mpz_sgn(n_mpz) < 0) {
                mpz_clear(n_mpz);
                kr_error("双阶乘只支持非负整数");
            }
            if (!mpz_fits_ulong_p(n_mpz)) {
                mpz_clear(n_mpz);
                kr_error("双阶乘参数过大（超出 unsigned long）");
            }
            unsigned long n = mpz_get_ui(n_mpz);
            mpz_clear(n_mpz);

            mpz_t result_mpz;
            mpz_init_set_ui(result_mpz, 1);
            // Beginnen bei n, jedes Mal 2 subtrahieren, bis i < 2 ist (also stoppen, wenn i 0 oder 1 ist)
            for (unsigned long i = n; i >= 2; i -= 2) {
                mpz_mul_ui(result_mpz, result_mpz, i);
            }
            result = make_int(result_mpz);
            mpz_clear(result_mpz);
            free_value(&v);
            break;
        }
        case NODE_STRING_LEN: {
            Value arr = eval_expr(node->data.string_len.str);
            if (arr.type != VAL_STRING) kr_error(".län 只能用于字符串");
            result = make_int(utf8_length(std::string(arr.str_val, arr.str_len)));
            free_value(&arr);
            break;
        }
        case NODE_REGEX_LITERAL: {
            ObjectEntry entries[2];
            entries[0].key = strdup("muster");
            entries[0].value = make_string(node->data.regex_lit.pattern);
            entries[1].key = strdup("flags");
            entries[1].value = make_string(node->data.regex_lit.flags);
            result = make_object(entries, 2);
            free(entries[0].key); free_value(&entries[0].value);
            free(entries[1].key); free_value(&entries[1].value);
            break;
        }
        case NODE_MATCH: {
            Value val = eval_expr(node->data.match.expr);
            push_scope();
        
            for (int i = 0; i < node->data.match.branch_count; ++i) {
                int saved_count  = current_scope->var_count;
                ASTNode* pattern = node->data.match.branches[i].pattern;
                ASTNode* guard   = node->data.match.branches[i].guard;
                ASTNode* body    = node->data.match.branches[i].body;
        
                bool branch_matched = false;
                try {
                    branch_matched = try_match_pattern(pattern, val);
                } catch (...) {
                    // 清理已声明的变量
                    while (current_scope->var_count > saved_count) {
                        Variable* var = &current_scope->vars[--current_scope->var_count];
                        free(var->name);
                        free_value(&var->value);
                    }
                    throw;
                }
        
                if (!branch_matched) {
                    // 匹配失败，清理该分支声明的变量
                    while (current_scope->var_count > saved_count) {
                        Variable* var = &current_scope->vars[--current_scope->var_count];
                        free(var->name);
                        free_value(&var->value);
                    }
                    continue;
                }
        
                // 匹配成功，检查守卫
                if (guard) {
                    Value gv = eval_expr(guard);
                    int ok = value_to_bool(gv);
                    free_value(&gv);
                    if (!ok) {
                        // 不满足守卫，清理变量并继续下一个分支
                        while (current_scope->var_count > saved_count) {
                            Variable* var = &current_scope->vars[--current_scope->var_count];
                            free(var->name);
                            free_value(&var->value);
                        }
                        continue;
                    }
                }
        
                // 求值分支体，并直接返回（异常安全）
                try {
                    Value ret = eval_expr(body);
                    // 清理本分支声明的变量
                    while (current_scope->var_count > saved_count) {
                        Variable* var = &current_scope->vars[--current_scope->var_count];
                        free(var->name);
                        free_value(&var->value);
                    }
                    pop_scope();
                    free_value(&val);
                    return ret;  // 利用 NRVO，无拷贝
                } catch (...) {
                    // 分支体求值抛异常：清理本分支变量，弹出作用域，释放 val，然后重新抛出
                    while (current_scope->var_count > saved_count) {
                        Variable* var = &current_scope->vars[--current_scope->var_count];
                        free(var->name);
                        free_value(&var->value);
                    }
                    pop_scope();
                    free_value(&val);
                    throw;
                }
            }
        
            // 所有分支未匹配
            pop_scope();
            free_value(&val);
            return make_null();
        }
        case NODE_BLOCK: {
            Value slot = make_null();
            Value* old_slot = g_current_return_slot;
            g_current_return_slot = &slot;
            exec_statement(node);
            g_current_return_slot = old_slot;
        
            if (return_caught) {
                result = copy_value(return_value);
                return_caught = false;
            } else {
                result = copy_value(slot);  // 深拷贝
            }
            free_value(&slot);
            break;
        }
        case NODE_BITWISE_NOT: {
            Value v = eval_expr(node->data.inc_dec.operand);
            mpz_t z, r;
            mpz_init(z); mpz_init(r);
            value_to_mpz(v, z);
            mpz_com(r, z);   // 按位取反
            free_value(&v);
            if (mpz_fits_slong_p(r)) {
                result = make_int64(mpz_get_si(r));
            } else {
                result = make_int(r);
            }
            mpz_clear(z); mpz_clear(r);
            break;
        }
         default:
             kr_error("不是表达式节点 %d\n", node->type);
             
    }
    eval_depth--;
    return result;
}

// 判断节点是否为常量整数
static bool is_constant_int(ASTNode* node, long long& val) {
    if (!node) return false;

    // 1. 字面量
    if (node->type == NODE_NUMBER) {
        mpz_t tmp;
        mpz_init(tmp);
        if (mpz_set_str(tmp, node->data.number_str, 10) == 0) {
            if (mpz_fits_slong_p(tmp)) {
                val = mpz_get_si(tmp);
                mpz_clear(tmp);
                return true;
            }
            mpz_clear(tmp);
        }
        return false;
    }

    // 2. 常量二元表达式：1+2, 1_000_000-2, 3*5, 10/2, 7%3 等
    if (node->type == NODE_BINARY) {
        long long L, R;
        if (!is_constant_int(node->data.binary.left,  L)) return false;
        if (!is_constant_int(node->data.binary.right, R)) return false;
        switch (node->data.binary.op) {
            case '+': val = L + R; return true;
            case '-': val = L - R; return true;
            case '*': val = L * R; return true;
            case '/': if (R == 0) return false; val = L / R; return true;
            case '%': if (R == 0) return false; val = L % R; return true;
            case '^': {
                // 只支持整数非负指数、且结果不溢出 int64
                if (R < 0 || R > 62) return false;
                long long r = 1;
                bool ok = true;
                for (long long k = 0; k < R; ++k) {
                    if (__builtin_mul_overflow(r, L, &r)) { ok = false; break; }
                }
                if (!ok) return false;
                val = r;
                return true;
            }
            default:  return false;   // 幂 ^、位运算等保守放弃
        }
    }

    // 3. 常量变量引用（const 变量 + 常量初始值）
    //     支持 count = 100_000_000; for(i=0; i<count; i++) 中的 count 折叠
    if (node->type == NODE_VARIABLE) {
        const char* name = node->data.var_name;
        Variable* var = get_var(name, false);
        if (!var || var->is_lazy || var->is_alias) return false;
        if (var->is_const) {
            if (var->value.type == VAL_INT64) {
                val = var->value.int64_val;
                return true;
            }
            if (var->value.type == VAL_INT && mpz_fits_slong_p(*var->value.big_int)) {
                val = mpz_get_si(*var->value.big_int);
                return true;
            }
            return false;
        }
        // 支持 int64 和 GMP big int
        if (var->value.type == VAL_INT64) {
            val = var->value.int64_val;
            return true;
        }
        if (var->value.type == VAL_INT && mpz_fits_slong_p(*var->value.big_int)) {
            val = mpz_get_si(*var->value.big_int);
            return true;
        }
        return false;
    }

    return false;
}

// 提取变量名（若节点为变量）
static bool is_var_node(ASTNode* node, std::string& name) {
    if (node->type == NODE_VARIABLE) {
        name = node->data.var_name;
        return true;
    }
    return false;
}

// ============================================================
// 激进 -O：符号化 for 循环求值
// 支持项：coeff * i^power 和 coeff * (i % mod_base)
// ============================================================
struct SummableTerm {
    double      coeff   = 0.0;
    int         power   = 0;    // i^power；0 表示常量项
    long long   mod_base = 0;   // > 0 表示该项为 (i % mod_base)
};

// 把表达式分解成可求和项。成功返回 true。
static bool decompose_to_summable(ASTNode* expr, const std::string& loop_var,
                                  std::vector<SummableTerm>& out) {
    if (!expr) return false;

    switch (expr->type) {
        case NODE_NUMBER: {
            SummableTerm t;
            t.coeff = std::strtod(expr->data.number_str, nullptr);
            out.push_back(t);
            return true;
        }
        case NODE_FLOAT: {
            SummableTerm t;
            t.coeff = std::strtod(expr->data.float_str, nullptr);
            out.push_back(t);
            return true;
        }
        case NODE_VARIABLE: {
            if (strcmp(expr->data.var_name, loop_var.c_str()) != 0) return false;
            SummableTerm t;
            t.coeff = 1.0;
            t.power = 1;
            out.push_back(t);
            return true;
        }
        case NODE_BINARY: {
            char op = expr->data.binary.op;
            ASTNode* L = expr->data.binary.left;
            ASTNode* R = expr->data.binary.right;

            // 加减：展开成项列表
            if (op == '+' || op == '-') {
                if (!decompose_to_summable(L, loop_var, out)) return false;
                std::vector<SummableTerm> rt;
                if (!decompose_to_summable(R, loop_var, rt)) return false;
                double sign = (op == '+') ? 1.0 : -1.0;
                for (auto& t : rt) { t.coeff *= sign; out.push_back(t); }
                return true;
            }

            // 乘法：一侧必须是常量
            if (op == '*') {
                std::vector<SummableTerm> lt, rt;
                if (decompose_to_summable(L, loop_var, lt) &&
                    lt.size() == 1 && lt[0].power == 0 && lt[0].mod_base == 0) {
                    if (!decompose_to_summable(R, loop_var, rt)) return false;
                    for (auto& t : rt) { t.coeff *= lt[0].coeff; out.push_back(t); }
                    return true;
                }
                if (decompose_to_summable(R, loop_var, rt) &&
                    rt.size() == 1 && rt[0].power == 0 && rt[0].mod_base == 0) {
                    if (!decompose_to_summable(L, loop_var, lt)) return false;
                    for (auto& t : lt) { t.coeff *= rt[0].coeff; out.push_back(t); }
                    return true;
                }
                return false;
            }

            // 取模：左为循环变量，右为常量
            if (op == '%') {
                if (L->type != NODE_VARIABLE) return false;
                if (strcmp(L->data.var_name, loop_var.c_str()) != 0) return false;
                if (R->type != NODE_NUMBER) return false;
                long long base = std::strtoll(R->data.number_str, nullptr, 10);
                if (base <= 0) return false;
                SummableTerm t;
                t.coeff = 1.0;
                t.mod_base = base;
                out.push_back(t);
                return true;
            }
            return false;
        }
        default:
            return false;
    }
}

// 在 [start, end] 上以 step 步长对项列表求和
static bool sum_summable_terms(const std::vector<SummableTerm>& terms,
                               long long start, long long end, long long step,
                               double& total) {
    total = 0.0;
    long long n = (end - start) / step + 1;
    if (n <= 0) return true;

    for (const auto& t : terms) {
        if (t.mod_base > 0) {
            double sum = 0.0;
            if (step == 1) {
                // 完整周期 + 余项（利用 (i % k) 的周期性）
                long long full = n / t.mod_base;
                long long rem  = n % t.mod_base;
                double period_sum = (double)t.mod_base * (t.mod_base - 1) / 2.0;
                sum = full * period_sum;
                long long rem_start = start + full * t.mod_base;
                for (long long k = 0; k < rem; ++k)
                    sum += (double)((rem_start + k) % t.mod_base);
            } else {
                // 非常规步长：直接遍历（范围通常很小）
                for (long long i = start; i <= end; i += step)
                    sum += (double)(i % t.mod_base);
            }
            total += t.coeff * sum;
        }
        else if (t.power == 0) {
            total += t.coeff * (double)n;
        }
        else if (t.power == 1) {
            // sum (start + step*j) for j=0..n-1
            double sum_i = (double)n * (double)start
                         + (double)step * (double)n * (double)(n - 1) / 2.0;
            total += t.coeff * sum_i;
        }
        else if (t.power == 2) {
            // sum (start + step*j)^2
            double ss = (double)start * (double)start;
            double st = (double)start * (double)step;
            double tt = (double)step * (double)step;
            double sj  = (double)n * (double)(n - 1) / 2.0;
            double sj2 = (double)n * (double)(n - 1) * (2.0 * (double)n - 1.0) / 6.0;
            double sum_i2 = (double)n * ss + 2.0 * st * sj + tt * sj2;
            total += t.coeff * sum_i2;
        }
        else {
            return false;   // 更高次幂暂不支持
        }
    }
    return true;
}

// 把 double 格式化成十进制字符串
static std::string format_double_as_string(double d) {
    if (std::isfinite(d) && d == std::floor(d) &&
        d >= -(double)LLONG_MAX && d <= (double)LLONG_MAX) {
        char buf[64];
        snprintf(buf, sizeof(buf), "%lld", (long long)d);
        return buf;
    }
    char buf[64];
    snprintf(buf, sizeof(buf), "%.17g", d);
    return buf;
}

// 判断字符串看起来是否为整数
static bool is_int_string(const std::string& s) {
    for (char c : s) if (c == '.' || c == 'e' || c == 'E') return false;
    return true;
}

// 若变量是已知的整数数组（VAL_ARRAY 且所有元素均为整数），
// 把元素取到 out 中并返回 true；否则返回 false。
static bool try_extract_array_ints(const char* var_name, std::vector<long long>& out) {
    Variable* var = get_var(var_name);
    if (!var || var->is_lazy || var->is_alias) return false;
    Value& v = var->value;
    if (v.type != VAL_ARRAY) return false;
    out.clear();
    out.reserve((size_t)v.arr_val.length);
    for (int i = 0; i < v.arr_val.length; ++i) {
        const Value& e = v.arr_val.elements[i];
        if (e.type == VAL_INT64) {
            out.push_back(e.int64_val);
        } else if (e.type == VAL_INT) {
            if (!mpz_fits_slong_p(*e.big_int)) return false;
            out.push_back((long long)mpz_get_si(*e.big_int));
        } else {
            return false;    // 出现浮点/字符串/对象/指针等，放弃优化
        }
    }
    return true;
}

// 尝试优化范围 for 循环
// 返回 true 表示优化成功，并将优化后的语句插入到 block 中（或直接执行）
static bool try_optimize_range_for(ASTNode* node, std::vector<ASTNode*>& opt_stmts) {
    ASTNode* init   = node->data.for_stmt.init;
    ASTNode* cond   = node->data.for_stmt.cond;
    ASTNode* update = node->data.for_stmt.update;
    ASTNode* body   = node->data.for_stmt.body;

    // ---------- 0. 必须三个部分都非空，否则放弃优化 ----------
    if (!init || !cond || !update || !body) return false;

    // ---------- 1. 解包可能的 NODE_EXPR_STMT ----------
    if (init->type == NODE_EXPR_STMT) init = init->data.expr_stmt.expr;
    if (cond->type == NODE_EXPR_STMT) cond = cond->data.expr_stmt.expr;
    if (update->type == NODE_EXPR_STMT) update = update->data.expr_stmt.expr;
    if (body->type == NODE_EXPR_STMT) body = body->data.expr_stmt.expr;

    if (!init || !cond || !update || !body) return false;

    // ---------- 2. 解析 init ----------
    std::string loop_var;
    long long start_val;
    if (init->type == NODE_VAR_DECL) {
        if (!is_constant_int(init->data.var_decl.expr, start_val)) return false;
        loop_var = init->data.var_decl.name;
    } else if (init->type == NODE_ASSIGN) {
        if (!is_constant_int(init->data.assign.expr, start_val)) return false;
        loop_var = init->data.assign.name;
    } else {
        return false;
    }

    // ---------- 3. 解析 cond ----------
    long long end_val;
    bool cond_le = false;
    if (cond->type == NODE_BINARY) {
        char op = cond->data.binary.op;
        if (op == 'L') cond_le = true;
        else if (op == '<') cond_le = false;
        else return false;
        std::string left_name;
        if (!is_var_node(cond->data.binary.left, left_name) || left_name != loop_var) return false;
        if (!is_constant_int(cond->data.binary.right, end_val)) return false;
    } else {
        return false;
    }

    // ---------- 4. 解析 update ----------
    long long step_val = 1;
    if (update->type == NODE_EXPR_STMT) update = update->data.expr_stmt.expr;
    if (!update) return false;

    if (update->type == NODE_ASSIGN) {
        if (update->data.assign.name != loop_var) return false;
        ASTNode* rhs = update->data.assign.expr;
        if (rhs->type == NODE_BINARY && rhs->data.binary.op == '+') {
            std::string left_name;
            if (!is_var_node(rhs->data.binary.left, left_name) || left_name != loop_var) return false;
            if (!is_constant_int(rhs->data.binary.right, step_val)) return false;
        } else {
            return false;
        }
    } else if (update->type == NODE_PRE_INC || update->type == NODE_POST_INC) {
        std::string var_name;
        if (!is_var_node(update->data.inc_dec.operand, var_name) || var_name != loop_var) return false;
        step_val = 1;
    } else if (update->type == NODE_PRE_DEC || update->type == NODE_POST_DEC) {
        std::string var_name;
        if (!is_var_node(update->data.inc_dec.operand, var_name) || var_name != loop_var) return false;
        step_val = -1;
    } else {
        return false;
    }

    if (step_val <= 0) return false; // 只支持正步长

    // ---------- 5. 计算迭代次数 n 及循环变量的最后值 ----------
    long long n;
    if (cond_le) {
        if (start_val > end_val) return false;
        n = (end_val - start_val) / step_val + 1;
    } else {
        if (start_val >= end_val) return false;
        n = (end_val - start_val - 1) / step_val + 1;
    }
    if (n <= 0) return false;
    long long last_i = start_val + (n - 1) * step_val;

    // ---------- 6. 辅助数据结构 ----------
    struct LinearExpr { bool ok; long long a; long long b; };
    std::function<LinearExpr(ASTNode*, const std::string&)> parse_linear =
        [&](ASTNode* node, const std::string& var) -> LinearExpr {
            if (!node) return {false, 0, 0};
            if (node->type == NODE_NUMBER) {
                long long c;
                if (is_constant_int(node, c)) return {true, 0, c};
                return {false, 0, 0};
            }
            if (node->type == NODE_VARIABLE && strcmp(node->data.var_name, var.c_str()) == 0) {
                return {true, 1, 0};
            }
            if (node->type == NODE_BINARY) {
                char op = node->data.binary.op;
                if (op == '+') {
                    auto L = parse_linear(node->data.binary.left, var);
                    auto R = parse_linear(node->data.binary.right, var);
                    if (L.ok && R.ok) return {true, L.a + R.a, L.b + R.b};
                } else if (op == '-') {
                    auto L = parse_linear(node->data.binary.left, var);
                    auto R = parse_linear(node->data.binary.right, var);
                    if (L.ok && R.ok) return {true, L.a - R.a, L.b - R.b};
                } else if (op == '*') {
                    long long c;
                    if (is_constant_int(node->data.binary.left, c)) {
                        auto R = parse_linear(node->data.binary.right, var);
                        if (R.ok) return {true, c * R.a, c * R.b};
                    }
                    if (is_constant_int(node->data.binary.right, c)) {
                        auto L = parse_linear(node->data.binary.left, var);
                        if (L.ok) return {true, c * L.a, c * L.b};
                    }
                }
            }
            return {false, 0, 0};
        };

    // ---------- 7. 分析循环体语句 ----------
    std::vector<ASTNode*> body_stmts;
    if (body->type == NODE_BLOCK) {
        for (int i = 0; i < body->data.block.count; ++i)
            body_stmts.push_back(body->data.block.stmts[i]);
    } else {
        body_stmts.push_back(body);
    }

    // 存储每个优化语句的结果（顺序保留）
    struct OptimizedStmt {
        std::string target_var;
        bool is_accum;          // true: 累加 (x += total), false: 赋值 (x = final)
        bool is_mul;            // true: 累积乘法 (x *= factor)
        std::string total_str;  // 存储计算出的总增量/因子/最终值（十进制字符串）
        bool ok;
    };

    std::vector<OptimizedStmt> opt_infos;
    std::unordered_set<std::string> assigned_targets;

    for (ASTNode* stmt : body_stmts) {
        if (!stmt) continue;
        if (stmt->type == NODE_EXPR_STMT) {
            stmt = stmt->data.expr_stmt.expr;
            if (!stmt) continue;
        }

        OptimizedStmt info{ "", false, false, "", false };

        // ---- 情形 A：自增/自减（累加 ±1） ----
        if (stmt->type == NODE_PRE_INC || stmt->type == NODE_POST_INC ||
            stmt->type == NODE_PRE_DEC || stmt->type == NODE_POST_DEC) {
            std::string var_name;
            if (!is_var_node(stmt->data.inc_dec.operand, var_name)) { info.ok = false; break; }
            long long delta = (stmt->type == NODE_PRE_INC || stmt->type == NODE_POST_INC) ? 1 : -1;
            info.target_var = var_name;
            info.is_accum = true;
            info.is_mul = false;
            mpz_t total_mpz;
            mpz_init(total_mpz);
            mpz_set_int64(total_mpz, delta);
            mpz_mul_si(total_mpz, total_mpz, n);
            char* total_str = mpz_get_str(nullptr, 10, total_mpz);
            info.total_str = total_str ? total_str : "";
            free(total_str);
            mpz_clear(total_mpz);
            info.ok = true;
        }

        // ---- 情形 B：普通赋值（可能为累加或乘法） ----
        else if (stmt->type == NODE_ASSIGN) {
            std::string target = stmt->data.assign.name;
            ASTNode* rhs = stmt->data.assign.expr;

            // --- B1: 检查是否为累加形式: x = x + f(i) ---
            if (rhs && rhs->type == NODE_BINARY && rhs->data.binary.op == '+') {
                std::string left_name;
                if (is_var_node(rhs->data.binary.left, left_name) && left_name == target) {
                    auto expr_lin = parse_linear(rhs->data.binary.right, loop_var);
                    if (expr_lin.ok) {
                        mpz_t total_mpz, tmp1, tmp2, tmp3;
                        mpz_init(total_mpz);
                        mpz_init(tmp1);
                        mpz_init(tmp2);
                        mpz_init(tmp3);

                        // a * n * start
                        mpz_set_int64(tmp1, expr_lin.a);
                        mpz_mul_si(tmp1, tmp1, n);
                        mpz_mul_si(tmp1, tmp1, start_val);

                        // a * step * (n-1) * n / 2
                        mpz_set_int64(tmp2, expr_lin.a);
                        mpz_mul_si(tmp2, tmp2, step_val);
                        mpz_mul_si(tmp2, tmp2, n - 1);
                        mpz_mul_si(tmp2, tmp2, n);
                        mpz_fdiv_q_ui(tmp2, tmp2, 2);

                        // b * n
                        mpz_set_int64(tmp3, expr_lin.b);
                        mpz_mul_si(tmp3, tmp3, n);

                        mpz_add(total_mpz, tmp1, tmp2);
                        mpz_add(total_mpz, total_mpz, tmp3);

                        char* total_str = mpz_get_str(nullptr, 10, total_mpz);
                        info.total_str = total_str ? total_str : "";
                        free(total_str);
                        mpz_clear(total_mpz);
                        mpz_clear(tmp1);
                        mpz_clear(tmp2);
                        mpz_clear(tmp3);

                        info.target_var = target;
                        info.is_accum = true;
                        info.is_mul = false;
                        info.ok = true;
                    } 
                    else {
                        std::vector<SummableTerm> terms;
                        if (decompose_to_summable(rhs->data.binary.right, loop_var, terms)) {
                            double total_sum = 0.0;
                            if (sum_summable_terms(terms, start_val, last_i, step_val,
                                                   total_sum)) {
                                info.total_str = format_double_as_string(total_sum);
                                info.target_var = target;
                                info.is_accum = true;
                                info.is_mul = false;
                                info.ok = true;
                            }
                        }
                        
                        if (!info.ok) {
                            ASTNode* rhs_inner = rhs->data.binary.right;   // 形如 arr[索引表达式]
                            if (rhs_inner && rhs_inner->type == NODE_ARRAY_ACCESS) {
                                ASTNode* arr_ref = rhs_inner->data.array_access.array;
                                ASTNode* idx_expr = rhs_inner->data.array_access.index;
                        
                                if (arr_ref->type == NODE_VARIABLE) {
                                    std::string arr_name = arr_ref->data.var_name;
                        
                                    // ---- 识别形如 (a*i + b) % mod 的索引 ----
                                    bool has_period = false;
                                    long long A = 0, B = 0, mod_base = 0;
                        
                                    if (idx_expr && idx_expr->type == NODE_BINARY &&
                                        idx_expr->data.binary.op == '%') {
                                        ASTNode* inner    = idx_expr->data.binary.left;
                                        ASTNode* mod_node = idx_expr->data.binary.right;
                                        long long mod_val;
                                        if (is_constant_int(mod_node, mod_val) && mod_val > 0) {
                                            auto inner_lin = parse_linear(inner, loop_var);
                                            if (inner_lin.ok) {
                                                A = inner_lin.a;
                                                B = inner_lin.b;
                                                mod_base = mod_val;
                                                has_period = true;
                                            }
                                        }
                                    }
                        
                                    if (has_period && step_val > 0) {
                                        std::vector<long long> arr_ints;
                                        if (try_extract_array_ints(arr_name.c_str(), arr_ints) &&
                                            !arr_ints.empty() &&
                                            mod_base <= (long long)arr_ints.size())
                                        {
                                            const long long L = (long long)arr_ints.size();
                        
                                            // ---- 规约到迭代计数 j ----
                                            // i = start_val + j * step_val
                                            // idx(j) = (a*i + b) % mod
                                            //        = (B_start + A_step * j) % mod
                                            long long A_mod = ((A % mod_base) + mod_base) % mod_base;
                                            long long B_mod = ((B % mod_base) + mod_base) % mod_base;
                        
                                            long long A_step = (A_mod * (step_val % mod_base)) % mod_base;
                                            if (A_step < 0) A_step += mod_base;
                        
                                            long long B_start = (A_mod * (start_val % mod_base) + B_mod) % mod_base;
                                            if (B_start < 0) B_start += mod_base;
                        
                                            // ---- 求周期 ----
                                            long long g = std::gcd(A_step, mod_base);
                                            long long P = (g == 0) ? 1 : (mod_base / g);
                                            if (P <= 0) P = 1;
                        
                                            // ---- 一个周期内的和 ----
                                            long long period_sum = 0;
                                            for (long long j = 0; j < P; ++j) {
                                                long long idx = (B_start + A_step * j) % mod_base;
                                                if (idx < 0) idx += mod_base;
                                                period_sum += arr_ints[idx % L];
                                            }
                        
                                            // ---- 完整周期 + 余项 ----
                                            long long full = n / P;
                                            long long rem  = n % P;
                                            long long total = full * period_sum;
                        
                                            for (long long j = 0; j < rem; ++j) {
                                                long long idx = (B_start + A_step * j) % mod_base;
                                                if (idx < 0) idx += mod_base;
                                                total += arr_ints[idx % L];
                                            }
                        
                                            char buf[64];
                                            snprintf(buf, sizeof(buf), "%lld", total);
                                            info.total_str = buf;
                                            info.target_var = target;
                                            info.is_accum = true;
                                            info.is_mul = false;
                                            info.ok = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // --- B2: 检查是否为乘法形式: x = x * expr 或 x = expr * x ---
            if (!info.ok && rhs && rhs->type == NODE_BINARY && rhs->data.binary.op == '*') {
                std::string left_name, right_name;
                ASTNode* factor_node = nullptr;
                if (is_var_node(rhs->data.binary.left, left_name) && left_name == target) {
                    factor_node = rhs->data.binary.right;
                } else if (is_var_node(rhs->data.binary.right, right_name) && right_name == target) {
                    factor_node = rhs->data.binary.left;
                }

                if (factor_node) {
                    long long const_val;
                    // 常量因子
                    if (is_constant_int(factor_node, const_val)) {
                        mpz_t factor_mpz;
                        mpz_init(factor_mpz);
                        mpz_set_int64(factor_mpz, const_val);
                        mpz_pow_ui(factor_mpz, factor_mpz, n);
                        char* factor_str = mpz_get_str(nullptr, 10, factor_mpz);
                        info.total_str = factor_str ? factor_str : "";
                        free(factor_str);
                        mpz_clear(factor_mpz);
                        info.target_var = target;
                        info.is_accum = false;
                        info.is_mul = true;
                        info.ok = true;
                    }
                    // 循环变量因子（仅当步长为1且 start>=1）
                    else if (factor_node->type == NODE_VARIABLE &&
                             std::string(factor_node->data.var_name) == loop_var &&
                             step_val == 1 && start_val >= 1) {
                        mpz_t numerator, denominator, factor_mpz;
                        mpz_init(numerator);
                        mpz_init(denominator);
                        mpz_init(factor_mpz);
                        mpz_fac_ui(numerator, end_val);
                        mpz_fac_ui(denominator, start_val - 1);
                        mpz_divexact(factor_mpz, numerator, denominator);
                        char* factor_str = mpz_get_str(nullptr, 10, factor_mpz);
                        info.total_str = factor_str ? factor_str : "";
                        free(factor_str);
                        mpz_clear(numerator);
                        mpz_clear(denominator);
                        mpz_clear(factor_mpz);
                        info.target_var = target;
                        info.is_accum = false;
                        info.is_mul = true;
                        info.ok = true;
                    }
                }
            }

            // --- B3: 普通赋值: x = f(i)（线性表达式）---
            if (!info.ok && rhs) {
                auto expr_lin = parse_linear(rhs, loop_var);
                if (expr_lin.ok) {
                    long long final_val = expr_lin.a * last_i + expr_lin.b;
                    info.target_var = target;
                    info.is_accum = false;
                    info.is_mul = false;
                    mpz_t total_mpz;
                    mpz_init(total_mpz);
                    mpz_set_int64(total_mpz, final_val);
                    char* total_str = mpz_get_str(nullptr, 10, total_mpz);
                    info.total_str = total_str ? total_str : "";
                    free(total_str);
                    mpz_clear(total_mpz);
                    info.ok = true;
                }
            }
        }

        // ---- 情形 C：数组复合赋值（暂不支持） ----
        else if (stmt->type == NODE_ARRAY_COMPOUND_ASSIGN) {
            info.ok = false;
        }
        // ---- 其他语句视为不可优化 ----
        else {
            info.ok = false;
        }

        if (!info.ok) {
            return false;
        }
        opt_infos.push_back(info);

        // 检查目标变量是否已被赋值过
        if (info.ok && !info.target_var.empty()) {
            if (assigned_targets.count(info.target_var)) {
                return false;   // 重复赋值，放弃优化
            }
            assigned_targets.insert(info.target_var);
        }
    }

    // ---------- 8. 所有语句均可优化，生成最终优化语句 ----------
    // 8a. 构造循环变量最终值设置语句
    ASTNode* final_val_node = new_node(NODE_NUMBER);
    char buf[64];
    snprintf(buf, sizeof(buf), "%lld", last_i);
    final_val_node->data.number_str = strdup(buf);

    ASTNode* final_init = nullptr;
    if (init->type == NODE_VAR_DECL) {
        final_init = new_node(NODE_VAR_DECL);
        final_init->data.var_decl.name = strdup(init->data.var_decl.name);
        final_init->data.var_decl.is_const = init->data.var_decl.is_const;
        final_init->data.var_decl.global = init->data.var_decl.global;
        final_init->data.var_decl.type_annotation = init->data.var_decl.type_annotation ?
                                                     copy_type_node(init->data.var_decl.type_annotation) : nullptr;
        final_init->data.var_decl.expr = final_val_node;
    } else if (init->type == NODE_ASSIGN) {
        final_init = new_node(NODE_ASSIGN);
        final_init->data.assign.name = strdup(init->data.assign.name);
        final_init->data.assign.global = init->data.assign.global;
        final_init->data.assign.expr = final_val_node;
    } else {
        free_ast(final_val_node);
        return false;
    }
    opt_stmts.push_back(final_init);

    // 8b. 为每个目标变量生成优化语句
    for (const auto& info : opt_infos) {
        ASTNode* node_expr;
        if (is_int_string(info.total_str)) {
            node_expr = new_node(NODE_NUMBER);
            node_expr->data.number_str = strdup(info.total_str.c_str());
        } else {
            node_expr = new_node(NODE_FLOAT);
            node_expr->data.float_str = strdup(info.total_str.c_str());
        }

        if (info.is_mul) {
            // 生成 x = x * factor
            ASTNode* var_node = new_node(NODE_VARIABLE);
            var_node->data.var_name = strdup(info.target_var.c_str());
            ASTNode* mul_node = new_node(NODE_BINARY);
            mul_node->data.binary.left = var_node;
            mul_node->data.binary.right = node_expr;
            mul_node->data.binary.op = '*';
            ASTNode* assign = new_node(NODE_ASSIGN);
            assign->data.assign.name = strdup(info.target_var.c_str());
            assign->data.assign.expr = mul_node;
            opt_stmts.push_back(assign);
        } else if (info.is_accum) {
            // 生成 x += total
            ASTNode* binary = new_node(NODE_BINARY);
            binary->data.binary.left = new_node(NODE_VARIABLE);
            binary->data.binary.left->data.var_name = strdup(info.target_var.c_str());
            binary->data.binary.right = node_expr;
            binary->data.binary.op = '+';
            ASTNode* assign = new_node(NODE_ASSIGN);
            assign->data.assign.name = strdup(info.target_var.c_str());
            assign->data.assign.expr = binary;
            opt_stmts.push_back(assign);
        } else {
            // 生成 x = total
            ASTNode* assign = new_node(NODE_ASSIGN);
            assign->data.assign.name = strdup(info.target_var.c_str());
            assign->data.assign.expr = node_expr;
            opt_stmts.push_back(assign);
        }
    }

    return true;
}

// ============================================================
// 简单数值 for 循环提升
// ============================================================
struct SimpleNumericFor {
    std::string var_name;
    int64_t start_val = 0;
    int64_t end_val   = 0;
    char    cmp_op    = 0;   // '<' / 'L' / '>' / 'G'
    int64_t step      = 0;
};

// walk_ast 在文件后部定义，这里先前向声明
static void walk_ast(ASTNode* node, std::function<void(ASTNode*)> visit);

// 循环体是否会写循环变量（赋值、自增、同名重声明）
static bool body_writes_var(ASTNode* body, const std::string& name) {
    bool found = false;
    if (!body) return false;
    walk_ast(body, [&](ASTNode* n) {
        if (found) return;
        switch (n->type) {
            case NODE_ASSIGN:
                if (n->data.assign.name && name == n->data.assign.name)
                    found = true;
                break;
            case NODE_PRE_INC: case NODE_PRE_DEC:
            case NODE_POST_INC: case NODE_POST_DEC:
                if (n->data.inc_dec.operand &&
                    n->data.inc_dec.operand->type == NODE_VARIABLE &&
                    n->data.inc_dec.operand->data.var_name &&
                    name == n->data.inc_dec.operand->data.var_name)
                    found = true;
                break;
            case NODE_VAR_DECL:
                if (n->data.var_decl.name && name == n->data.var_decl.name)
                    found = true;
                break;
            case NODE_MULTI_ASSIGN:
                for (int i = 0; i < n->data.multi_assign.left_count; ++i)
                    if (n->data.multi_assign.left_names[i] &&
                        name == n->data.multi_assign.left_names[i])
                        found = true;
                break;
            case NODE_DESTRUCTURE:
            case NODE_DESTRUCTURE_ASSIGN:
                for (int i = 0; i < n->data.destructure.count; ++i)
                    if (n->data.destructure.names[i] &&
                        name == n->data.destructure.names[i])
                        found = true;
                if (n->data.destructure.rest_name &&
                    name == n->data.destructure.rest_name)
                    found = true;
                break;
            default: break;
        }
    });
    return found;
}

// 识别：für i = C1; i <OP> C2; i += K
static bool detect_simple_numeric_for(ASTNode* node, SimpleNumericFor& out) {
    if (!node || node->type != NODE_FOR) return false;
    ASTNode* init   = node->data.for_stmt.init;
    ASTNode* cond   = node->data.for_stmt.cond;
    ASTNode* update = node->data.for_stmt.update;
    if (!init || !cond || !update) return false;

    auto unwrap = [](ASTNode* n) -> ASTNode* {
        if (n && n->type == NODE_EXPR_STMT) return n->data.expr_stmt.expr;
        return n;
    };
    init = unwrap(init); cond = unwrap(cond); update = unwrap(update);
    if (!init || !cond || !update) return false;

    // -------- init --------
    std::string var_name;
    int64_t start_val;
    if (init->type == NODE_VAR_DECL) {
        if (!init->data.var_decl.name || init->data.var_decl.is_const) return false;
        var_name = init->data.var_decl.name;
        if (!is_constant_int(init->data.var_decl.expr, start_val)) return false;
        TypeNode* ta = init->data.var_decl.type_annotation;
        if (ta && ta->kind != TYPE_INT && ta->kind != TYPE_ANY && ta->kind != TYPE_NUM)
            return false;
    } else if (init->type == NODE_ASSIGN) {
        if (!init->data.assign.name) return false;
        var_name = init->data.assign.name;
        if (!is_constant_int(init->data.assign.expr, start_val)) return false;
    } else {
        return false;
    }

    // -------- cond --------
    if (cond->type != NODE_BINARY) return false;
    char cmp_op = cond->data.binary.op;
    if (cmp_op != '<' && cmp_op != 'L' && cmp_op != '>' && cmp_op != 'G') return false;
    std::string left_name;
    int64_t end_val;
    if (!is_var_node(cond->data.binary.left, left_name) || left_name != var_name) return false;
    if (!is_constant_int(cond->data.binary.right, end_val)) return false;

    // -------- update --------
    int64_t step = 0;
    if (update->type == NODE_PRE_INC || update->type == NODE_POST_INC) {
        std::string n2;
        if (!is_var_node(update->data.inc_dec.operand, n2) || n2 != var_name) return false;
        step = 1;
    } else if (update->type == NODE_PRE_DEC || update->type == NODE_POST_DEC) {
        std::string n2;
        if (!is_var_node(update->data.inc_dec.operand, n2) || n2 != var_name) return false;
        step = -1;
    } else if (update->type == NODE_ASSIGN &&
               update->data.assign.name && var_name == update->data.assign.name) {
        ASTNode* rhs = update->data.assign.expr;
        if (!rhs || rhs->type != NODE_BINARY) return false;
        std::string lname; int64_t k;
        if (!is_var_node(rhs->data.binary.left, lname) || lname != var_name) return false;
        if (!is_constant_int(rhs->data.binary.right, k)) return false;
        if (rhs->data.binary.op == '+')      step =  k;
        else if (rhs->data.binary.op == '-') step = -k;
        else return false;
    } else {
        return false;
    }
    if (step == 0) return false;

    // 循环体不能写循环变量
    if (body_writes_var(node->data.for_stmt.body, var_name)) return false;

    // 防溢出：四个量全部限制在安全范围内
    const int64_t SAFE = INT64_MAX / 4;
    if (start_val > SAFE || start_val < -SAFE ||
        end_val   > SAFE || end_val   < -SAFE ||
        step      > SAFE || step      < -SAFE)
        return false;

    out.var_name  = var_name;
    out.start_val = start_val;
    out.end_val   = end_val;
    out.cmp_op    = cmp_op;
    out.step      = step;
    return true;
}

// 循环体是否引用了循环变量（会遍历嵌套函数体等所有子节点）
static bool body_references_var(ASTNode* body, const std::string& name) {
    if (!body) return false;
    bool found = false;
    walk_ast(body, [&](ASTNode* n) {
        if (found) return;
        if (n->type == NODE_VARIABLE &&
            n->data.var_name && name == n->data.var_name) {
            found = true;
        }
    });
    return found;
}

static bool try_native_numeric_for(ASTNode* node, const SimpleNumericFor& snf) {
    Variable* var = get_var(snf.var_name.c_str(), false);
    if (!var) {
        if (!current_scope) return false;
        declare_var_in_scope(current_scope, snf.var_name.c_str(), false,
                             make_int64(snf.start_val));
        var = get_var(snf.var_name.c_str(), false);
        if (!var) return false;
    }
    if (var->is_const || var->is_lazy) return false;
    if (var->type_annotation) {
        TypeKind k = var->type_annotation->kind;
        if (k != TYPE_INT && k != TYPE_ANY && k != TYPE_NUM) return false;
    }

    // 若循环体完全没用到 i，迭代期间无需更新 var->value，
    // 只在循环结束后同步一次最终值即可。
    const bool body_reads_i =
        body_references_var(node->data.for_stmt.body, snf.var_name);

    in_loop++;
    int64_t i = snf.start_val;
    bool interrupted = false;

    // 初始化循环变量的 Value（一次即可）
    free_value(&var->value);
    var->value = make_int64(i);

    while (true) {
        bool keep_going;
        switch (snf.cmp_op) {
            case '<': keep_going = (i <  snf.end_val); break;
            case 'L': keep_going = (i <= snf.end_val); break;
            case '>': keep_going = (i >  snf.end_val); break;
            case 'G': keep_going = (i >= snf.end_val); break;
            default:  keep_going = false; break;
        }
        if (!keep_going) break;

        // ---- 仅当循环体确实会读取循环变量时，才同步其 Value ----
        // 且改为原地更新 int64_val，避免 free_value / make_int64 的函数调用开销。
        if (body_reads_i) {
            var->value.int64_val = i;
        }

        break_caught = false;
        continue_caught = false;
        exec_statement(node->data.for_stmt.body);

        if (return_caught || exception_raised) { interrupted = true; break; }
        if (break_caught) {
            if (break_levels > 1) { break_levels--; interrupted = true; break; }
            break_caught = false; break_levels = 1; break;
        }
        if (continue_caught) {
            if (continue_levels > 1) { continue_levels--; interrupted = true; break; }
            continue_caught = false; continue_levels = 1;
        }

        i += snf.step;   // 前面已限制过范围，不会溢出
    }

    // ---- 循环结束后，把最终值写回变量 ----
    // 情况 A：循环体读过 i → 最后一次同步的 i 可能不是退出后的值（因为退出时 i 已增加），
    //         仍需同步一次最终 i。
    // 情况 B：循环体从未读过 i → var->value 可能仍为初始值，
    //         直接重建为最终 i（一次性 free/alloc）。
    if (body_reads_i) {
        var->value.int64_val = i;
    } else {
        free_value(&var->value);
        var->value = make_int64(i);
    }

    in_loop--;
    return !interrupted;
}

// 分析一条语句对 var_name 的净更新（i++/i--/i+=k/i-=k/i=i+k/i=i-k），累加到 step
static bool analyze_update_stmt(ASTNode* stmt, const std::string& var_name, long long& step) {
    if (!stmt) return false;
    if (stmt->type == NODE_EXPR_STMT) {
        if (!stmt->data.expr_stmt.expr) return false;
        stmt = stmt->data.expr_stmt.expr;
    }
    if (stmt->type == NODE_ASSIGN) {
        if (!stmt->data.assign.name) return false;
        if (strcmp(stmt->data.assign.name, var_name.c_str()) != 0) return false;
        ASTNode* rhs = stmt->data.assign.expr;
        if (rhs && rhs->type == NODE_BINARY) {
            char op = rhs->data.binary.op;
            if (op == '+' || op == '-') {
                ASTNode* l = rhs->data.binary.left;
                ASTNode* r = rhs->data.binary.right;
                long long k;
                if (l && l->type == NODE_VARIABLE &&
                    strcmp(l->data.var_name, var_name.c_str()) == 0 &&
                    is_constant_int(r, k)) {
                    step += (op == '+') ? k : -k;
                    return true;
                }
                if (r && r->type == NODE_VARIABLE &&
                    strcmp(r->data.var_name, var_name.c_str()) == 0 &&
                    is_constant_int(l, k) && op == '+') {
                    step += k;
                    return true;
                }
            }
        }
        return false;
    }
    if (stmt->type == NODE_PRE_INC || stmt->type == NODE_POST_INC) {
        ASTNode* opd = stmt->data.inc_dec.operand;
        if (opd && opd->type == NODE_VARIABLE &&
            strcmp(opd->data.var_name, var_name.c_str()) == 0) {
            step += 1;
            return true;
        }
        return false;
    }
    if (stmt->type == NODE_PRE_DEC || stmt->type == NODE_POST_DEC) {
        ASTNode* opd = stmt->data.inc_dec.operand;
        if (opd && opd->type == NODE_VARIABLE &&
            strcmp(opd->data.var_name, var_name.c_str()) == 0) {
            step -= 1;
            return true;
        }
        return false;
    }
    return false;
}

// 把 while 循环提升为原生 C++ 循环：展平常量条件的 IF、合并末尾的循环变量更新、用 int64_t 原生跑循环
static bool try_native_while_loop(ASTNode* node, bool& ret) {
    if (!node || node->type != NODE_WHILE) return false;
    ASTNode* cond = node->data.while_stmt.cond;
    ASTNode* body = node->data.while_stmt.body;

    // ---- 1. 条件必须是 i < N / i <= N / i > N / i >= N ----
    if (!cond || cond->type != NODE_BINARY) return false;
    char cmp_op = cond->data.binary.op;
    if (cmp_op != '<' && cmp_op != 'L' && cmp_op != '>' && cmp_op != 'G') return false;
    ASTNode* left = cond->data.binary.left;
    ASTNode* right = cond->data.binary.right;
    if (!left || left->type != NODE_VARIABLE || !right) return false;
    std::string var_name = left->data.var_name;

    // ---- 2. 循环变量必须是可写的 int64 ----
    Variable* var = get_var(var_name.c_str(), false);
    if (!var || var->is_const || var->is_lazy || var->is_alias) return false;
    if (var->type_annotation) {
        TypeKind k = var->type_annotation->kind;
        if (k != TYPE_INT && k != TYPE_ANY && k != TYPE_NUM) return false;
    }
    long long start_i;
    if (var->value.type == VAL_INT64) {
        start_i = var->value.int64_val;
    } else if (var->value.type == VAL_INT && mpz_fits_slong_p(*var->value.big_int)) {
        start_i = mpz_get_si(*var->value.big_int);
    } else {
        return false;
    }

    // ---- 3. limit ----
    long long limit_val = 0;
    bool limit_is_var = false;
    std::string limit_var_name;
    if (is_constant_int(right, limit_val)) {
        // 常量
    } else if (right->type == NODE_VARIABLE) {
        limit_is_var = true;
        limit_var_name = right->data.var_name;
        Variable* lv = get_var(limit_var_name.c_str(), false);
        if (!lv || lv->is_const || lv->is_lazy || lv->is_alias) return false;
        if (lv->value.type == VAL_INT64) limit_val = lv->value.int64_val;
        else if (lv->value.type == VAL_INT && mpz_fits_slong_p(*lv->value.big_int))
            limit_val = mpz_get_si(*lv->value.big_int);
        else return false;
    } else {
        return false;
    }

    // ---- 4. 展平常量条件的 IF，得到扁平的语句序列 ----
    std::vector<ASTNode*> flat;
    std::function<void(ASTNode*)> add_flat = [&](ASTNode* n) {
        if (!n) return;
        if (n->type == NODE_IF) {
            long long cv;
            if (is_constant_int(n->data.if_stmt.cond, cv)) {
                ASTNode* chosen = nullptr;
                if (cv) {
                    chosen = n->data.if_stmt.then_block;
                } else {
                    for (int i = 0; i < n->data.if_stmt.else_if_count; ++i) {
                        ASTNode* ei = n->data.if_stmt.else_ifs[i];
                        long long ec;
                        if (is_constant_int(ei->data.if_stmt.cond, ec) /*&& ec*/) {
                            chosen = ei->data.if_stmt.then_block;
                            break;
                        }
                    }
                    if (!chosen) chosen = n->data.if_stmt.else_block;
                }
                if (chosen) {
                    if (chosen->type == NODE_BLOCK) {
                        for (int i = 0; i < chosen->data.block.count; ++i)
                            add_flat(chosen->data.block.stmts[i]);
                    } else {
                        add_flat(chosen);
                    }
                    return;
                }
            }
        }
        flat.push_back(n);
    };

    if (body->type == NODE_BLOCK) {
        for (int i = 0; i < body->data.block.count; ++i)
            add_flat(body->data.block.stmts[i]);
    } else {
        add_flat(body);
    }

    // ---- 5. 从末尾提取循环变量更新 ----
    long long step = 0;
    int keep = (int)flat.size();
    for (int i = (int)flat.size() - 1; i >= 0; --i) {
        long long s = 0;
        if (analyze_update_stmt(flat[i], var_name, s)) {
            step += s;
            keep = i;
        } else break;
    }
    if (step == 0) return false;

    // ---- 6. 安全检查：保留部分不能修改循环变量或 limit 变量 ----
    for (int i = 0; i < keep; ++i) {
        bool bad = false;
        walk_ast(flat[i], [&](ASTNode* n) {
            if (bad) return;
            if (n->type == NODE_ASSIGN && n->data.assign.name) {
                if (strcmp(n->data.assign.name, var_name.c_str()) == 0) bad = true;
                if (limit_is_var && strcmp(n->data.assign.name, limit_var_name.c_str()) == 0) bad = true;
            }
            if ((n->type == NODE_PRE_INC || n->type == NODE_POST_INC ||
                 n->type == NODE_PRE_DEC || n->type == NODE_POST_DEC) &&
                n->data.inc_dec.operand && n->data.inc_dec.operand->type == NODE_VARIABLE) {
                if (strcmp(n->data.inc_dec.operand->data.var_name, var_name.c_str()) == 0) bad = true;
                if (limit_is_var &&
                    strcmp(n->data.inc_dec.operand->data.var_name, limit_var_name.c_str()) == 0) bad = true;
            }
        });
        if (bad) return false;
    }
    // 有 continue 就放弃（语义会变）
    bool has_continue = false;
    walk_ast(body, [&](ASTNode* n) { if (n->type == NODE_CONTINUE) has_continue = true; });
    if (has_continue) return false;

    // ---- 7. 防溢出 ----
    const long long SAFE = INT64_MAX / 4;
    if (start_i > SAFE || start_i < -SAFE || limit_val > SAFE || limit_val < -SAFE ||
        step > SAFE || step < -SAFE) return false;

    // ---- 8. 构造保留部分作为临时块（仅借用指针，不释放原 AST） ----
    ASTNode* reduced_body = nullptr;
    if (keep > 0) {
        reduced_body = new_node(NODE_BLOCK);
        reduced_body->data.block.count = keep;
        reduced_body->data.block.stmts = (ASTNode**)malloc(keep * sizeof(ASTNode*));
        for (int i = 0; i < keep; ++i)
            reduced_body->data.block.stmts[i] = flat[i];
    }

    // ---- 9. 用原生 C++ 循环执行 ----
    in_loop++;
    int64_t i = start_i;
    bool interrupted = false;

    free_value(&var->value);
    var->value = make_int64(i);

    while (true) {
        bool keep_going;
        switch (cmp_op) {
            case '<': keep_going = (i <  limit_val); break;
            case 'L': keep_going = (i <= limit_val); break;
            case '>': keep_going = (i >  limit_val); break;
            case 'G': keep_going = (i >= limit_val); break;
            default:  keep_going = false;
        }
        if (!keep_going) break;

        if (reduced_body) {
            var->value.int64_val = i;
            break_caught = false;
            continue_caught = false;
            exec_statement(reduced_body);

            if (return_caught || exception_raised) { interrupted = true; break; }
            if (break_caught) {
                if (break_levels > 1) { break_levels--; interrupted = true; break; }
                break_caught = false; break_levels = 1;
                var->value.int64_val = i;   // 保留当前 i（break 前未自增）
                i = var->value.int64_val;
                break;
            }
            if (continue_caught) {
                if (continue_levels > 1) { continue_levels--; interrupted = true; break; }
                continue_caught = false; continue_levels = 1;
            }
        }
        i += step;
    }
    in_loop--;

    // ---- 10. 写回最终值并清理 ----
    free_value(&var->value);
    var->value = make_int64(i);

    if (reduced_body) {
        free(reduced_body->data.block.stmts);
        free(reduced_body);
    }

    ret = !interrupted;
    return true;
}

// 复合赋值（+=、-=、...）的公共运算逻辑。
// current 是被赋值的当前值，rhs 是右值，op 为二元运算符字符。
// 返回运算结果（新构造的 Value，调用方负责 free_value）。
static Value compute_compound(const Value& current, Value& rhs, char op) {
    bool left_num  = (current.type == VAL_INT || current.type == VAL_INT64 || current.type == VAL_FLOAT);
    bool right_num = (rhs.type     == VAL_INT || rhs.type     == VAL_INT64 || rhs.type     == VAL_FLOAT);
    if (!left_num || !right_num) {
        kr_error("复合赋值只支持数值类型（整数或浮点数）");
    }

    bool any_float = (current.type == VAL_FLOAT) || (rhs.type == VAL_FLOAT);

    if (any_float) {
        if (op == '%') kr_error("取模(%=) 不支持浮点数");
        if (op == '|' || op == '&' || op == 'X') {
            const char* op_name = (op == 'X') ? "异或(~=)" :
                                  (op == '|') ? "按位或(|=)" : "按位与(&=)";
            kr_error("%s 不支持浮点数操作数", op_name);
        }
        mpf_t a_mpf, b_mpf, res_mpf;
        mpf_init(a_mpf); mpf_init(b_mpf); mpf_init(res_mpf);
        if (current.type == VAL_FLOAT) mpf_set(a_mpf, *current.mpf_val);
        else                           mpf_set_int64(a_mpf, value_to_ll(current));
        if (rhs.type == VAL_FLOAT)     mpf_set(b_mpf, *rhs.mpf_val);
        else                           mpf_set_int64(b_mpf, value_to_ll(rhs));

        switch (op) {
            case '+': mpf_add(res_mpf, a_mpf, b_mpf); break;
            case '-': mpf_sub(res_mpf, a_mpf, b_mpf); break;
            case '*': mpf_mul(res_mpf, a_mpf, b_mpf); break;
            case '/':
                if (mpf_sgn(b_mpf) == 0) {
                    mpf_clear(a_mpf); mpf_clear(b_mpf); mpf_clear(res_mpf);
                    kr_error("除零错误");
                }
                mpf_div(res_mpf, a_mpf, b_mpf);
                break;
            default:
                mpf_clear(a_mpf); mpf_clear(b_mpf); mpf_clear(res_mpf);
                kr_error("复合赋值: 不支持的操作符 '%c'", op);
        }
        Value res = make_float(res_mpf);
        mpf_clear(a_mpf); mpf_clear(b_mpf); mpf_clear(res_mpf);
        return res;
    }

    // 整数路径
    mpz_t a_mpz, b_mpz, r_mpz;
    mpz_init(a_mpz); mpz_init(b_mpz); mpz_init(r_mpz);
    if (current.type == VAL_INT64) mpz_set_int64(a_mpz, current.int64_val);
    else                           mpz_set(a_mpz, *current.big_int);
    if (rhs.type == VAL_INT64)     mpz_set_int64(b_mpz, rhs.int64_val);
    else                           mpz_set(b_mpz, *rhs.big_int);

    Value res = make_null();
    switch (op) {
        case '+': mpz_add(r_mpz, a_mpz, b_mpz); res = make_int(r_mpz); break;
        case '-': mpz_sub(r_mpz, a_mpz, b_mpz); res = make_int(r_mpz); break;
        case '*': mpz_mul(r_mpz, a_mpz, b_mpz); res = make_int(r_mpz); break;
        case '/':
            if (mpz_sgn(b_mpz) == 0) {
                mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz);
                kr_error("除零");
            }
            mpz_tdiv_q(r_mpz, a_mpz, b_mpz);
            res = make_int(r_mpz);
            break;
        case '%':
            if (mpz_sgn(b_mpz) == 0) {
                mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz);
                kr_error("取模零");
            }
            mpz_mod(r_mpz, a_mpz, b_mpz);
            res = make_int(r_mpz);
            break;
        case '^': {
            if (mpz_sgn(b_mpz) < 0) {
                mpf_t a_f, b_f, r_f;
                mpf_init(a_f); mpf_init(b_f); mpf_init(r_f);
                mpf_set_z(a_f, a_mpz);
                mpf_set_z(b_f, b_mpz);
                mpf_set_d(r_f, pow(mpf_get_d(a_f), mpf_get_d(b_f)));
                res = make_float(r_f);
                mpf_clear(a_f); mpf_clear(b_f); mpf_clear(r_f);
            } else if (!mpz_fits_ulong_p(b_mpz)) {
                mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz);
                kr_error("指数过大");
            } else {
                unsigned long exp = mpz_get_ui(b_mpz);
                mpz_pow_ui(r_mpz, a_mpz, exp);
                res = make_int(r_mpz);
            }
            break;
        }
        case '|': mpz_ior(r_mpz, a_mpz, b_mpz); res = make_int(r_mpz); break;
        case '&': mpz_and(r_mpz, a_mpz, b_mpz); res = make_int(r_mpz); break;
        case 'X': mpz_xor(r_mpz, a_mpz, b_mpz); res = make_int(r_mpz); break;
        default:
            mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz);
            kr_error("复合赋值: 不支持的操作符 '%c'", op);
    }

    mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz);
    return res;
}

// 快速路径：形如 `x = x <op> <整数字面量>` 的复合赋值（x 为当前作用域内的 int64 局部变量）。
// 命中则就地更新 var->value.int64_val 并返回 true；不适用或溢出时返回 false，由调用方走通用路径。
static bool try_fast_compound_int64(ASTNode* node) {
    if (!node || node->type != NODE_ASSIGN) return false;
    if (node->data.assign.global) return false;

    ASTNode* rhs_node = node->data.assign.expr;
    if (!rhs_node || rhs_node->type != NODE_BINARY) return false;

    ASTNode* bin_left = rhs_node->data.binary.left;
    if (!bin_left || bin_left->type != NODE_VARIABLE) return false;
    if (strcmp(bin_left->data.var_name, node->data.assign.name) != 0) return false;

    const char op = rhs_node->data.binary.op;
    if (op != '+' && op != '-' && op != '*' && op != '/' && op != '%')
        return false;

    ASTNode* right = rhs_node->data.binary.right;
    if (!right || right->type != NODE_NUMBER) return false;

    // 只接受纯十进制整数字面量（快速失败，避免误判十六进制/浮点字面量）
    const char* num = right->data.number_str;
    errno = 0;
    char* end = nullptr;
    long long parsed = strtoll(num, &end, 10);
    if (!end || end == num || *end != '\0' || errno != 0) return false;
    const int64_t operand = (int64_t)parsed;

    // 只在 current_scope 一层查找：与 x++ 快线策略一致
    if (!current_scope) return false;
    const char* name = node->data.assign.name;
    const char c0 = name[0];
    Variable* var = nullptr;
    for (int i = 0; i < current_scope->var_count; ++i) {
        Variable* v = &current_scope->vars[i];
        if (v->name[0] == c0 && strcmp(v->name, name) == 0) {
            var = v;
            break;
        }
    }
    if (!var) return false;
    if (var->is_const || var->is_lazy || var->is_alias) return false;
    if (var->value.type != VAL_INT64) return false;
    if (var->type_annotation) {
        const TypeKind k = var->type_annotation->kind;
        if (k != TYPE_INT && k != TYPE_ANY && k != TYPE_NUM) return false;
    }

    const int64_t a = var->value.int64_val;
    int64_t res = 0;
    bool overflow = false;

    switch (op) {
        case '+':
            if (__builtin_add_overflow(a, operand, &res)) overflow = true;
            break;
        case '-':
            if (__builtin_sub_overflow(a, operand, &res)) overflow = true;
            break;
        case '*':
            if (__builtin_mul_overflow(a, operand, &res)) overflow = true;
            break;
        case '/':
            if (operand == 0) kr_error("除零错误");
            if (a == INT64_MIN && operand == -1) overflow = true; // 提升到 GMP
            else res = a / operand;
            break;
        case '%':
            if (operand == 0) kr_error("取模零");
            res = a % operand;
            break;
        default:
            return false;
    }
    if (overflow) return false;   // 溢出：交给通用路径走 GMP

    var->value.int64_val = res;
    var->is_read = true;
    return true;
}
 
bool exec_statement(ASTNode* node) {
    // if (std::this_thread::get_id() != main_thread_id) {
    //     return true;
    // }
     g_last_error_line = node->line;
     g_last_error_col = node->col;
     g_last_error_filename = nullptr;
     if (!node) return true;
     if (g_trace_ast) {
         std::string indent(exec_depth * 2, ' ');
         fprintf(stderr, "%s[VERF] exec_statement: %s at %d:%d\n",
                 indent.c_str(),
                 node_type_to_string(node->type),
                 node->line, node->col);
     }
     // 执行深度检查
     if (++exec_depth > MAX_RECURSION_DEPTH) {
         kr_error("Fehler: 语句递归深度超过限制 (%d)\n", MAX_RECURSION_DEPTH);
         
     }
     bool ret = true;
     switch (node->type) {
         case NODE_PROGRAM:
         case NODE_BLOCK: {
             for (int i = 0; i < node->data.block.count; i++) {
                if (!exec_statement(node->data.block.stmts[i])) {
                    if (return_caught || break_caught || continue_caught || exception_raised) {
                        ret = false;
                        goto cleanup;
                    }
                }
             }
             break;
         }
         case NODE_VAR_DECL: {
            Value val = eval_expr(node->data.var_decl.expr);
            if (node->data.var_decl.type_annotation) {
                if (!check_type(node->data.var_decl.type_annotation, val)) {
                    std::string expected = type_to_string(node->data.var_decl.type_annotation);
                    char* got = value_to_string(val);
                    kr_error("类型错误: 变量 '%s' 期望类型 '%s', 实际值 '%s' (类型: '%s')",
                             node->data.var_decl.name, expected.c_str(), got, value_type_to_string(val).c_str());
                }
            }
            if (node->data.var_decl.global) {
                declare_var_in_scope(get_global_scope(), node->data.var_decl.name,
                                     node->data.var_decl.is_const, val,
                                     node->data.var_decl.type_annotation);
            } else {
                declare_var(node->data.var_decl.name, node->data.var_decl.is_const, val,
                            node->data.var_decl.type_annotation);
            }
            // 存储位置，仅当当前作用域是全局作用域
            if (current_scope == original_global_scope) {
                g_var_decl_pos[node->data.var_decl.name] = {node->line, node->col};
            }
            Scope* target_scope = node->data.var_decl.global ? get_global_scope() : current_scope;
            int idx = get_var_index_in_scope(target_scope, node->data.var_decl.name);
            if (idx >= 0) {
                target_scope->vars[idx].is_read = false;
            }
            break;
         }
         case NODE_MARK_USED: {
            // 标记指定的变量和函数为已使用
            for (int i = 0; i < node->data.mark_used.count; ++i) {
                const char* name = node->data.mark_used.names[i];
                // 标记变量
                Scope* s = current_scope;
                while (s) {
                    int idx = get_var_index_in_scope(s, name);
                    if (idx >= 0) {
                        s->vars[idx].is_read = true;
                        break;
                    }
                    s = s->parent;
                }
                // 标记函数
                Function* func = get_function(name);
                if (func) func->called = true;
            }
            break;
         }
         case NODE_MARK_ALL_USED: {
            // 标记所有全局变量为已读
            if (original_global_scope) {
                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                for (int i = 0; i < original_global_scope->var_count; ++i) {
                    original_global_scope->vars[i].is_read = true;
                }
                // 标记所有全局函数为已调用
                std::lock_guard<std::mutex> lock_f(functions_mutex);
                for (int i = 0; i < func_count; ++i) {
                    functions[i].called = true;
                }
            }
            break;
         }
         case NODE_ASSIGN: {
            if (try_fast_compound_int64(node)) break;
            Value rhs = eval_expr(node->data.assign.expr);
            assign_to_target(node, rhs);     // 无返回值 → 直接移动，零 copy
            break;
         }
         case NODE_ARRAY_ASSIGN: {
            // 新的 left 字段是 NODE_ARRAY_ACCESS 节点
            ASTNode* left_expr = node->data.array_assign.left;
            if (left_expr->type != NODE_ARRAY_ACCESS) {
                kr_error("内部错误: 数组赋值左侧不是 NODE_ARRAY_ACCESS\n");
            }
            ASTNode* base_expr = left_expr->data.array_access.array;
            ASTNode* idx_expr = node->data.array_assign.index;
        
            // 获取容器指针
            Value* container = get_container_ptr(base_expr);
            if (!container) break;
        
            // 求索引和右值
            Value idx_val = eval_expr(idx_expr);
            char* key_str = value_to_string(idx_val);
            free_value(&idx_val);
        
            Value rhs = eval_expr(node->data.array_assign.expr);
        
            if (container->type == VAL_ARRAY) {
                long long idx = atoll(key_str);
                if (idx < 0 || idx >= container->arr_val.length) {
                    // 提取变量名用于警告（如果 base 是变量）
                    char* base_name = (base_expr->type == NODE_VARIABLE) ? base_expr->data.var_name : (char*)"(unbekannt)";
                    kr_warn("数组 '%s' 索引 %lld 越界，赋值被忽略", base_name, idx);
                    free(key_str);
                    free_value(&rhs);
                    break;
                }
                // 类型检查（仅当 base 是变量且有类型注解时有效）
                if (base_expr->type == NODE_VARIABLE) {
                    Variable* var = get_var(base_expr->data.var_name);
                    if (var && var->type_annotation && var->type_annotation->kind == TYPE_ARRAY) {
                        TypeNode* elem_type = var->type_annotation->array_type.elem_type;
                        if (!check_type(elem_type, rhs)) {
                            std::string expected = type_to_string(elem_type);
                            char* got = value_to_string(rhs);
                            kr_error("数组元素类型错误: 索引 %lld 期望 '%s', 实际 '%s'",
                                    idx, expected.c_str(), got);
                        }
                    }
                }
                free_value(&container->arr_val.elements[idx]);
                container->arr_val.elements[idx] = rhs;
            }
            else if (container->type == VAL_OBJECT) {
                int found = -1;
                for (int i = 0; i < container->obj_val.count; i++) {
                    if (strcmp(container->obj_val.entries[i].key, key_str) == 0) {
                        found = i;
                        break;
                    }
                }
                if (found >= 0) {
                    free_value(&container->obj_val.entries[found].value);
                    container->obj_val.entries[found].value = rhs;
                } else {
                    container->obj_val.count++;
                    container->obj_val.entries = (ObjectEntry*)realloc(
                        container->obj_val.entries,
                        container->obj_val.count * sizeof(ObjectEntry)
                    );
                    container->obj_val.entries[container->obj_val.count - 1].key = strdup(key_str);
                    container->obj_val.entries[container->obj_val.count - 1].value = rhs;
                }
            }
            else {
                char* base_name = (base_expr->type == NODE_VARIABLE) ? base_expr->data.var_name : (char*)"(unbekannt)";
                kr_error("'%s' 既不是数组也不是对象\n", base_name);
                free(key_str);
                free_value(&rhs);
            }
            free(key_str);
            break;
        }
        case NODE_ARRAY_COMPOUND_ASSIGN: {
            ASTNode* left_expr = node->data.array_compound_assign.left;
            if (left_expr->type != NODE_ARRAY_ACCESS) {
                kr_error("内部错误: 数组复合赋值左侧不是 NODE_ARRAY_ACCESS\n");
            }
            ASTNode* base_expr = left_expr->data.array_access.array;
            ASTNode* idx_expr = node->data.array_compound_assign.index;
        
            Value* container = get_container_ptr(base_expr);
            if (!container) break;
        
            Value idx_val = eval_expr(idx_expr);
            char* key_str = value_to_string(idx_val);
            free_value(&idx_val);
        
            Value rhs = eval_expr(node->data.array_compound_assign.rhs);
            char op = node->data.array_compound_assign.op;
        
            // 获取目标指针（数组元素或对象属性）
            Value* target = nullptr;
            if (container->type == VAL_ARRAY) {
                long long idx = atoll(key_str);
                if (idx < 0 || idx >= container->arr_val.length) {
                    char* base_name = (base_expr->type == NODE_VARIABLE) ? base_expr->data.var_name : (char*)"(unbekannt)";
                    kr_warn("数组 '%s' 索引 %lld 越界，复合赋值被忽略", base_name, idx);
                    free(key_str);
                    free_value(&rhs);
                    break;
                }
                target = &container->arr_val.elements[idx];
            }
            else if (container->type == VAL_OBJECT) {
                int found = -1;
                for (int i = 0; i < container->obj_val.count; i++) {
                    if (strcmp(container->obj_val.entries[i].key, key_str) == 0) {
                        found = i;
                        break;
                    }
                }
                if (found < 0) {
                    // 不存在则创建（值为 null）
                    container->obj_val.count++;
                    container->obj_val.entries = (ObjectEntry*)realloc(
                        container->obj_val.entries,
                        container->obj_val.count * sizeof(ObjectEntry)
                    );
                    container->obj_val.entries[container->obj_val.count - 1].key = strdup(key_str);
                    container->obj_val.entries[container->obj_val.count - 1].value = make_null();
                    found = container->obj_val.count - 1;
                }
                target = &container->obj_val.entries[found].value;
            }
            else {
                char* base_name = (base_expr->type == NODE_VARIABLE) ? base_expr->data.var_name : (char*)"(unbekannt)";
                kr_error("'%s' 既不是数组也不是对象\n", base_name);
                free(key_str);
                free_value(&rhs);
                break;
            }
        
            // ---------- 执行复合运算 ----------
            Value current = copy_value(*target);
            bool left_num = (current.type == VAL_INT || current.type == VAL_INT64 || current.type == VAL_FLOAT);
            bool right_num = (rhs.type == VAL_INT || rhs.type == VAL_INT64 || rhs.type == VAL_FLOAT);
            if (!left_num || !right_num) {
                kr_error("复合赋值只支持数值类型（整数或浮点数）\n");
            }
            bool left_float = (current.type == VAL_FLOAT);
            bool right_float = (rhs.type == VAL_FLOAT);
            bool any_float = left_float || right_float;
            Value res;
            if (any_float) {
                if (op == '%') kr_error("取模(%=) 不支持浮点数");
                if (op == '|' || op == '&' || op == 'X') {
                    const char* op_name = (op == 'X') ? "异或(~=)" :
                                          (op == '|') ? "按位或(|=)" : "按位与(&=)";
                    kr_error("%s 不支持浮点数操作数", op_name);
                }
                mpf_t a_mpf, b_mpf, res_mpf;
                mpf_init(a_mpf); mpf_init(b_mpf); mpf_init(res_mpf);
                if (current.type == VAL_FLOAT) mpf_set_d(a_mpf, value_to_double(current));
                else if (current.type == VAL_INT || current.type == VAL_INT64) mpf_set_int64(a_mpf, value_to_ll(current));
                else kr_error("无法转换当前值为 mpf_t");
                if (rhs.type == VAL_FLOAT) mpf_set_d(b_mpf, value_to_double(rhs));
                else if (rhs.type == VAL_INT || rhs.type == VAL_INT64) mpf_set_int64(b_mpf, value_to_ll(rhs));
                else kr_error("无法转换右值为 mpf_t");
                switch (op) {
                    case '+': mpf_add(res_mpf, a_mpf, b_mpf); break;
                    case '-': mpf_sub(res_mpf, a_mpf, b_mpf); break;
                    case '*': mpf_mul(res_mpf, a_mpf, b_mpf); break;
                    case '/':
                        if (mpf_sgn(b_mpf) == 0) kr_error("除零错误");
                        mpf_div(res_mpf, a_mpf, b_mpf);
                        break;
                    default: kr_error("数组复合赋值: 不支持的操作符 '%c'", op);
                }
                res = make_float(res_mpf);
                mpf_clear(a_mpf); mpf_clear(b_mpf); mpf_clear(res_mpf);
                free_value(&current); free_value(&rhs);
            } else {
                mpz_t a_mpz, b_mpz, r_mpz;
                mpz_init(a_mpz); mpz_init(b_mpz); mpz_init(r_mpz);
                if (current.type == VAL_INT || current.type == VAL_INT64) mpz_set_int64(a_mpz, value_to_ll(current));
                else mpz_set(a_mpz, *current.big_int);
                if (rhs.type == VAL_INT || rhs.type == VAL_INT64) mpz_set_int64(b_mpz, value_to_ll(rhs));
                else mpz_set(b_mpz, *rhs.big_int);
                switch (op) {
                    case '+': mpz_add(r_mpz, a_mpz, b_mpz); break;
                    case '-': mpz_sub(r_mpz, a_mpz, b_mpz); break;
                    case '*': mpz_mul(r_mpz, a_mpz, b_mpz); break;
                    case '/':
                        if (mpz_sgn(b_mpz) == 0) { mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz); kr_error("除零\n"); }
                        mpz_tdiv_q(r_mpz, a_mpz, b_mpz);
                        break;
                    case '%':
                        if (mpz_sgn(b_mpz) == 0) { mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz); kr_error("取模零\n"); }
                        mpz_mod(r_mpz, a_mpz, b_mpz);
                        break;
                    case '^': {
                        if (mpz_sgn(b_mpz) < 0) {
                            mpf_t a_f, b_f, r_f;
                            mpf_init(a_f); mpf_init(b_f); mpf_init(r_f);
                            mpf_set_z(a_f, a_mpz);
                            mpf_set_z(b_f, b_mpz);
                            mpf_set_d(r_f, pow(mpf_get_d(a_f), mpf_get_d(b_f)));
                            res = make_float(r_f);
                            mpf_clear(a_f); mpf_clear(b_f); mpf_clear(r_f);
                        } else if (!mpz_fits_ulong_p(b_mpz)) {
                            kr_error("指数过大");
                        } else {
                            unsigned long exp = mpz_get_ui(b_mpz);
                            mpz_pow_ui(r_mpz, a_mpz, exp);
                            res = make_int(r_mpz);
                        }
                        break;
                    }
                    case '|': mpz_ior(r_mpz, a_mpz, b_mpz); break;
                    case '&': mpz_and(r_mpz, a_mpz, b_mpz); break;
                    case 'X': mpz_xor(r_mpz, a_mpz, b_mpz); break;
                    default:
                        mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz);
                        kr_error("不支持的操作符 '%c'\n", op);
                }
                if (op != '^' || mpz_sgn(b_mpz) >= 0) {
                    if (op != '^' || mpz_sgn(b_mpz) >= 0) {
                        res = make_int(r_mpz);
                    }
                }
                mpz_clear(a_mpz); mpz_clear(b_mpz); mpz_clear(r_mpz);
                free_value(&current);
                free_value(&rhs);
            }
            free_value(target);
            *target = res;
            free(key_str);
            break;
        }
        case NODE_PRINT: {
            Value v = eval_expr(node->data.print.expr);
            switch (v.type) {
                case VAL_INT64:
                    std::cout << v.int64_val;
                    break;
                case VAL_STRING:
                    std::cout.write(v.str_val, v.str_len);
                    break;
                case VAL_INT: {
                    char* s = mpz_get_str(nullptr, 10, *v.big_int);
                    std::cout << s;
                    free(s);
                    break;
                }
                case VAL_FLOAT:
                    std::cout << mpf_get_d(*v.mpf_val);
                    break;
                case VAL_NULL:
                    std::cout << "null";
                    break;
                default:
                    // 数组、对象、函数等走通用转换
                    char* s = value_to_string(v);
                    std::cout << s;
                    free(s);
                    break;
            }
            std::cout << '\n' << std::flush;
            free_value(&v);
            break;
         }
         case NODE_PRINT_NO_NEWLINE: {
            Value v = eval_expr(node->data.print.expr);
            switch (v.type) {
                case VAL_INT64:
                    std::cout << v.int64_val;
                    break;
                case VAL_STRING:
                    std::cout.write(v.str_val, v.str_len);
                    break;
                case VAL_INT: {
                    char* s = mpz_get_str(nullptr, 10, *v.big_int);
                    std::cout << s;
                    free(s);
                    break;
                }
                case VAL_FLOAT:
                    std::cout << mpf_get_d(*v.mpf_val);
                    break;
                case VAL_NULL:
                    std::cout << "null";
                    break;
                default:
                    char* s = value_to_string(v);
                    std::cout << s;
                    free(s);
                    break;
            }
            std::cout << std::flush;
            free_value(&v);
            break;
         }
         
        case NODE_PRINT_WITH_LINE: {
            Value val = eval_expr(node->data.print_with_line.expr);
            Value line_val = eval_expr(node->data.print_with_line.line);
            int line = (int)value_to_int(line_val);
        
            // ---------- 快速输出表达式 ----------
            switch (val.type) {
                case VAL_INT64:
                    std::cout << val.int64_val;
                    break;
                case VAL_STRING:
                    std::cout.write(val.str_val, val.str_len);
                    break;
                case VAL_INT: {
                    char* s = mpz_get_str(nullptr, 10, *val.big_int);
                    std::cout << s;
                    free(s);
                    break;
                }
                case VAL_FLOAT:
                    std::cout << mpf_get_d(*val.mpf_val);
                    break;
                case VAL_NULL:
                    std::cout << "null";
                    break;
                default:
                    char* s = value_to_string(val);
                    std::cout << s;
                    free(s);
                    break;
            }
            std::cout << '\n' << std::flush;
        
            // ---------- 存储行号（仍使用 value_to_string 获得字符串表示） ----------
            if (val.type == VAL_STRING)
                print_lines[current_scope->id][line] = std::string(val.str_val, val.str_len);
            else {
                char* s = value_to_string(val);
                print_lines[current_scope->id][line] = std::string(s);
                free(s);
            }
        
            free_value(&val);
            free_value(&line_val);
            break;
        }
        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI: {
            for (int i = 0; i < node->data.print_multi.count; ++i) {
                Value v = eval_expr(node->data.print_multi.exprs[i]);
                // --- 快速输出（绕过 value_to_string）---
                switch (v.type) {
                    case VAL_INT64:
                        std::cout << v.int64_val;
                        break;
                    case VAL_STRING:
                        std::cout.write(v.str_val, v.str_len);
                        break;
                    case VAL_INT: {
                        char* s = mpz_get_str(nullptr, 10, *v.big_int);
                        std::cout << s;
                        free(s);
                        break;
                    }
                    case VAL_FLOAT: {
                        // 简单转换为 double 输出（可保留几位小数）
                        std::cout << mpf_get_d(*v.mpf_val);
                        break;
                    }
                    case VAL_NULL:
                        std::cout << "null";
                        break;
                    case VAL_ARRAY:   // 如需打印数组，可以保留原有 value_to_string 或简化
                    case VAL_OBJECT:
                    case VAL_FUNCTION:
                    case VAL_FUTURE:
                    default:
                        char* s = value_to_string(v);
                        std::cout << s;
                        free(s);
                        break;
                }
                free_value(&v);
            }
            if (node->type == NODE_PRINT_MULTI) std::cout << '\n';
            std::cout.flush();
            break;
        }
        case NODE_INPUT: {
            char buffer[256];
            if (!fgets(buffer, sizeof(buffer), stdin)) {
                kr_error("lies: 输入错误\n");
            }
            size_t len = strlen(buffer);
            while (len > 0 && (buffer[len-1] == '\n' || buffer[len-1] == '\r' || isspace((unsigned char)buffer[len-1])))
                buffer[--len] = '\0';
        
            int flags = node->data.input.flags;
        
            // ---------- PCRE2 正则相关 ----------
            pcre2_code* re = nullptr;
            pcre2_match_data* match_data = nullptr;
            bool has_regex = false;
        
            // ---------- 参数解析（支持对象 / 字符串） ----------
            for (int i = 0; i < node->data.input.arg_count; i++) {
                Value v = eval_expr(node->data.input.args[i]);
        
                if (v.type == VAL_OBJECT) {
                    // 尝试解析为 { muster: "...", flags: "..." } 对象
                    const char* pattern_str = nullptr;
                    const char* flags_str = "";
                    for (int j = 0; j < v.obj_val.count; ++j) {
                        if (strcmp(v.obj_val.entries[j].key, "muster") == 0 &&
                            v.obj_val.entries[j].value.type == VAL_STRING) {
                            pattern_str = v.obj_val.entries[j].value.str_val;
                        }
                        if (strcmp(v.obj_val.entries[j].key, "flags") == 0 &&
                            v.obj_val.entries[j].value.type == VAL_STRING) {
                            flags_str = v.obj_val.entries[j].value.str_val;
                        }
                    }
                    if (pattern_str) {
                        if (has_regex) { kr_error("只能指定一个正则表达式\n"); }
                        int opts = PCRE2_UTF | PCRE2_UCP;
                        if (strchr(flags_str, 'i')) opts |= PCRE2_CASELESS;
                        if (strchr(flags_str, 'm')) opts |= PCRE2_MULTILINE;
                        if (strchr(flags_str, 's')) opts |= PCRE2_DOTALL;
                        if (strchr(flags_str, 'x')) opts |= PCRE2_EXTENDED;
                        // 可扩展其他 flag，如 'U' (UNGREEDY) 等
        
                        int errcode;
                        PCRE2_SIZE erroffset;
                        re = pcre2_compile((PCRE2_SPTR)pattern_str, strlen(pattern_str),
                                           opts, &errcode, &erroffset, NULL);
                        if (!re) {
                            PCRE2_UCHAR errbuf[256];
                            pcre2_get_error_message(errcode, errbuf, sizeof(errbuf));
                            kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroffset);
                        }
                        match_data = pcre2_match_data_create_from_pattern(re, NULL);
                        if (!match_data) {
                            pcre2_code_free(re);
                            kr_error("无法创建匹配数据");
                        }
                        has_regex = true;
                        free_value(&v);
                        break;
                    }
                    // 没有 pattern 字段，当作普通对象转为字符串（兼容旧行为）
                    // 但我们会将其编译为正则，就像字符串一样
                    char* str = value_to_string(v);
                    int errcode;
                    PCRE2_SIZE erroffset;
                    re = pcre2_compile((PCRE2_SPTR)str, strlen(str),
                                       PCRE2_UTF | PCRE2_UCP, &errcode, &erroffset, NULL);
                    free(str);
                    if (!re) {
                        PCRE2_UCHAR errbuf[256];
                        pcre2_get_error_message(errcode, errbuf, sizeof(errbuf));
                        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroffset);
                    }
                    match_data = pcre2_match_data_create_from_pattern(re, NULL);
                    if (!match_data) {
                        pcre2_code_free(re);
                        kr_error("无法创建匹配数据");
                    }
                    has_regex = true;
                    free_value(&v);
                    break;
                }
                else if (v.type == VAL_STRING) {
                    if (has_regex) { kr_error("只能指定一个正则表达式\n"); }
                    const char* pattern_str = v.str_val;
                    int errcode;
                    PCRE2_SIZE erroffset;
                    re = pcre2_compile((PCRE2_SPTR)pattern_str, strlen(pattern_str),
                                       PCRE2_UTF | PCRE2_UCP, &errcode, &erroffset, NULL);
                    if (!re) {
                        PCRE2_UCHAR errbuf[256];
                        pcre2_get_error_message(errcode, errbuf, sizeof(errbuf));
                        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroffset);
                    }
                    match_data = pcre2_match_data_create_from_pattern(re, NULL);
                    if (!match_data) {
                        pcre2_code_free(re);
                        kr_error("无法创建匹配数据");
                    }
                    has_regex = true;
                    free_value(&v);
                    break;
                }
                else {
                    // 其他类型转为字符串（数字、null 等）
                    char* str = value_to_string(v);
                    int errcode;
                    PCRE2_SIZE erroffset;
                    re = pcre2_compile((PCRE2_SPTR)str, strlen(str),
                                       PCRE2_UTF | PCRE2_UCP, &errcode, &erroffset, NULL);
                    free(str);
                    if (!re) {
                        PCRE2_UCHAR errbuf[256];
                        pcre2_get_error_message(errcode, errbuf, sizeof(errbuf));
                        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroffset);
                    }
                    match_data = pcre2_match_data_create_from_pattern(re, NULL);
                    if (!match_data) {
                        pcre2_code_free(re);
                        kr_error("无法创建匹配数据");
                    }
                    has_regex = true;
                    free_value(&v);
                    break;
                }
            }
        
            bool do_clear = (flags & FLAG_NO_STORE) != 0;
            Value result_value = make_null();
        
            // ========== 多行模式 ==========
            if (node->data.input.multiline_expr != NULL) {
                std::string full_input;
                int line_count = 0;
                if (do_clear) {
                    printf("\033[s");
                    fflush(stdout);
                }
        
                push_scope();
                declare_var("_", false, make_string(""));
        
                bool should_stop = false;
                if (strlen(buffer) > 0) {
                    set_var_in_scope(current_scope, "_", make_string(buffer));
                    Value cond = eval_expr(node->data.input.multiline_expr);
                    should_stop = value_to_bool(cond);
                    free_value(&cond);
                }
                if (!should_stop && strlen(buffer) > 0) {
                    full_input += buffer;
                    full_input += '\n';
                    line_count++;
                }
        
                while (!should_stop) {
                    char line_buf[4096];
                    if (!fgets(line_buf, sizeof(line_buf), stdin)) break;
                    size_t line_len = strlen(line_buf);
                    while (line_len > 0 && (line_buf[line_len-1] == '\n' || line_buf[line_len-1] == '\r'))
                        line_buf[--line_len] = '\0';
                    if (line_len == 0) continue;
        
                    set_var_in_scope(current_scope, "_", make_string(line_buf));
                    Value cond = eval_expr(node->data.input.multiline_expr);
                    should_stop = value_to_bool(cond);
                    free_value(&cond);
                    if (should_stop) break;
        
                    full_input += line_buf;
                    full_input += '\n';
                    line_count++;
                }
                pop_scope();
        
                if (do_clear) {
        #ifdef _WIN32
                    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
                    CONSOLE_SCREEN_BUFFER_INFO csbi;
                    if (GetConsoleScreenBufferInfo(hOut, &csbi)) {
                        COORD cursor = csbi.dwCursorPosition;
                        int total_lines = line_count + 1;
                        int startY = cursor.Y - total_lines;
                        if (startY < 0) startY = 0;
                        for (int y = startY; y <= cursor.Y; y++) {
                            COORD pos = { 0, (SHORT)y };
                            SetConsoleCursorPosition(hOut, pos);
                            DWORD written;
                            FillConsoleOutputCharacter(hOut, ' ', csbi.dwSize.X, pos, &written);
                            FillConsoleOutputAttribute(hOut, csbi.wAttributes, csbi.dwSize.X, pos, &written);
                        }
                        COORD newPos = { 0, (SHORT)startY };
                        SetConsoleCursorPosition(hOut, newPos);
                    }
        #else
                    printf("\033[2J\033[H");
        #endif
                    fflush(stdout);
                }
        
                std::string processed = full_input;
                if (flags & (FLAG_NUM | FLAG_FLOAT)) {
                    processed.erase(std::remove_if(processed.begin(), processed.end(),
                                                  [](char c) { return std::isspace((unsigned char)c); }),
                                   processed.end());
                } else {
                    while (!processed.empty() && std::isspace((unsigned char)processed.back()))
                        processed.pop_back();
                    while (!processed.empty() && std::isspace((unsigned char)processed.front()))
                        processed.erase(0, 1);
                }
        
                bool is_empty = (flags & (FLAG_NUM | FLAG_FLOAT)) && processed.empty();
        
                // ------ 应用正则验证（PCRE2）------
                if (has_regex) {
                    int rc = pcre2_match(re, (PCRE2_SPTR)processed.c_str(), processed.size(),
                                         0, 0, match_data, NULL);
                    if (rc < 0) {
                        // 不匹配 -> 返回 null
                        result_value = make_null();
                    } else {
                        // 匹配成功，按 flags 转换
                        if (is_empty) {
                            result_value = make_null();
                        } else if (flags & FLAG_FLOAT) {
                            char* end;
                            double d = strtod(processed.c_str(), &end);
                            if (*end == '\0') result_value = make_float(d);
                            else result_value = make_null();
                        } else if (flags & FLAG_NUM) {
                            char* end;
                            long long n = strtoll(processed.c_str(), &end, 10);
                            if (*end == '\0') result_value = make_int(n);
                            else {
                                double d = strtod(processed.c_str(), &end);
                                if (*end == '\0') result_value = make_float(d);
                                else result_value = make_null();
                            }
                        } else {
                            result_value = make_string(processed.c_str());
                        }
                    }
                } else {
                    // 无正则，直接按 flags 转换
                    if (is_empty) {
                        result_value = make_null();
                    } else if (flags & FLAG_FLOAT) {
                        char* end;
                        double d = strtod(processed.c_str(), &end);
                        if (*end == '\0') result_value = make_float(d);
                        else result_value = make_null();
                    } else if (flags & FLAG_NUM) {
                        char* end;
                        long long n = strtoll(processed.c_str(), &end, 10);
                        if (*end == '\0') result_value = make_int(n);
                        else {
                            double d = strtod(processed.c_str(), &end);
                            if (*end == '\0') result_value = make_float(d);
                            else result_value = make_null();
                        }
                    } else {
                        result_value = make_string(processed.c_str());
                    }
                }
        
                assign_or_declare(node->data.input.name, result_value);
                // 释放 PCRE2 资源
                if (match_data) { pcre2_match_data_free(match_data); match_data = nullptr; }
                if (re) { pcre2_code_free(re); re = nullptr; }
                break;
            }
        
            // ========== 单行模式 ==========
            {
                std::string input_str(buffer);
                if (has_regex) {
                    // 如果提供了正则，去除首尾空白（便于匹配）
                    auto trim = [](std::string& s) {
                        s.erase(0, s.find_first_not_of(" \t\n\r\f\v"));
                        s.erase(s.find_last_not_of(" \t\n\r\f\v") + 1);
                    };
                    trim(input_str);
                }
        
                bool is_empty = (flags & (FLAG_NUM | FLAG_FLOAT)) &&
                                input_str.find_first_not_of(" \t\n\r") == std::string::npos;
        
                // ------ 应用正则验证（PCRE2）------
                if (has_regex) {
                    int rc = pcre2_match(re, (PCRE2_SPTR)input_str.c_str(), input_str.size(),
                                         0, 0, match_data, NULL);
                    if (rc < 0) {
                        result_value = make_null();
                    } else {
                        // 匹配成功，按 flags 转换
                        if (is_empty) {
                            result_value = make_null();
                        } else if (flags & FLAG_FLOAT) {
                            char* end;
                            double d = strtod(input_str.c_str(), &end);
                            if (*end == '\0') result_value = make_float(d);
                            else result_value = make_null();
                        } else if (flags & FLAG_NUM) {
                            char* end;
                            long long n = strtoll(input_str.c_str(), &end, 10);
                            if (*end == '\0') result_value = make_int(n);
                            else {
                                double d = strtod(input_str.c_str(), &end);
                                if (*end == '\0') result_value = make_float(d);
                                else result_value = make_null();
                            }
                        } else {
                            result_value = make_string(input_str.c_str());
                        }
                    }
                } else {
                    // 无正则，直接按 flags 转换
                    if (is_empty) {
                        result_value = make_null();
                    } else if (flags & FLAG_FLOAT) {
                        char* end;
                        double d = strtod(buffer, &end);
                        if (*end == '\0') result_value = make_float(d);
                        else result_value = make_null();
                    } else if (flags & FLAG_NUM) {
                        mpz_t tmp;
                        mpz_init(tmp);
                        if (mpz_set_str(tmp, buffer, 10) == 0) {
                            result_value = make_int(tmp);
                        } else {
                            char* end;
                            double d = strtod(buffer, &end);
                            if (*end == '\0') result_value = make_float(d);
                            else result_value = make_null();
                        }
                        mpz_clear(tmp);
                    } else {
                        result_value = make_string(buffer);
                    }
                }
        
                assign_or_declare(node->data.input.name, result_value);
                if (do_clear) {
                    printf("\r\033[K\033[A\033[K");
                    fflush(stdout);
                }
                // 释放 PCRE2 资源
                if (match_data) { pcre2_match_data_free(match_data); match_data = nullptr; }
                if (re) { pcre2_code_free(re); re = nullptr; }
            }
            break;
        }
        case NODE_IF: {
            if (node->data.if_stmt.cond->type == NODE_NUMBER) {
                int val = atoi(node->data.if_stmt.cond->data.number_str);
                kr_warn("条件结果是常量 %s，可能为逻辑错误", val ? "wahr (1)" : "fals (0)");
            }
             Value cond = eval_expr(node->data.if_stmt.cond);
             int cond_val = value_to_bool(cond);
             free_value(&cond);
             if (cond_val) {
                 ret = exec_statement(node->data.if_stmt.then_block);
                 if (return_caught || break_caught || continue_caught || exception_raised) {
                     goto cleanup;
                 }
             } else {
                 for (int i = 0; i < node->data.if_stmt.else_if_count; i++) {
                     ASTNode* elif = node->data.if_stmt.else_ifs[i];
                     Value elif_cond = eval_expr(elif->data.if_stmt.cond);
                     int ec = value_to_bool(elif_cond);
                     free_value(&elif_cond);
                     if (ec) {
                         ret = exec_statement(elif->data.if_stmt.then_block);
                         goto cleanup;
                     }
                 }
                 if (node->data.if_stmt.else_block) {
                     ret = exec_statement(node->data.if_stmt.else_block);
                 }
             }
             break;
         }
         
         case NODE_WHILE: {
            if (g_optimize_for_loops) {
                bool opt_ret = true;
                if (try_native_while_loop(node, opt_ret)) {
                    ret = opt_ret;
                    break;
                }
            }
            int iterations = 0;
            in_loop++;
        
            // ---- 常量条件优化 ----
            bool cond_const = false;
            int const_bool = 0;          // 0 = false, 1 = true
            ASTNode* cond_node = node->data.while_stmt.cond;
            if (cond_node->type == NODE_NUMBER) {
                Value const_val = eval_expr(cond_node);
                const_bool = value_to_bool(const_val);
                free_value(&const_val);
                cond_const = true;
            }
        
            while (1) {
                if (++iterations > MAX_LOOP_ITERATIONS) {
                    kr_error("Fehler: indes 循环超过最大迭代次数 (%d)\n", MAX_LOOP_ITERATIONS);
                }
        
                int c;
                if (cond_const) {
                    c = const_bool;
                } else {
                    Value cond = eval_expr(cond_node);
                    c = value_to_bool(cond);
                    free_value(&cond);
                }
                if (!c) break;
        
                // 执行循环体（原有逻辑）
                break_caught = false;
                continue_caught = false;
                exec_statement(node->data.while_stmt.body);
        
                if (return_caught) {
                    ret = false;
                    goto loop_cleanup;
                }
                if (exception_raised) {
                    ret = false;
                    goto loop_cleanup;
                }
                if (break_caught) {
                    if (break_levels > 1) {
                        break_levels--;             // 保留 break_caught = true 向上传播
                        ret = false;
                        goto loop_cleanup;
                    }
                    break_caught = false;
                    break_levels = 1;
                    break;
                }
                if (continue_caught) {
                    if (continue_levels > 1) {
                        continue_levels--;
                        ret = false;
                        goto loop_cleanup;
                    }
                    continue_caught = false;
                    continue_levels = 1;
                    continue;
                }
            }
            ret = true;
        loop_cleanup:
            in_loop--;
            break;
        }
        case NODE_FOR: {
            if (g_optimize_for_loops) {  // 仅当显式开启优化时尝试
                std::vector<ASTNode*> opt_stmts;
                if (try_optimize_range_for(node, opt_stmts)) {
                    push_scope();
                    ret = true;
                    for (ASTNode* stmt : opt_stmts) {
                        if (!exec_statement(stmt)) {
                            ret = false;
                            if (return_caught || break_caught || continue_caught || exception_raised)
                                break;
                        }
                    }
                    pop_scope();
                    for (ASTNode* stmt : opt_stmts) free_ast(stmt);
                    break;  // 优化执行完毕，跳过普通循环
                }
            }
            {
                SimpleNumericFor snf;
                if (detect_simple_numeric_for(node, snf)) {
                    if (try_native_numeric_for(node, snf)) {
                        ret = true;
                        break;
                    }
                    if (return_caught || break_caught || continue_caught || exception_raised) {
                        ret = false;
                        break;
                    }
                }
            }
            in_loop++;
            if (node->data.for_stmt.init) {
                exec_statement(node->data.for_stmt.init);
                if (return_caught || break_caught || continue_caught) {
                    if (break_caught || continue_caught) {
                        kr_error("break/continue 不能出现在 for 初始化部分\n");
                        
                    }
                    ret = false;
                    goto for_cleanup;
                }
            }
            while (1) {
                if (node->data.for_stmt.cond) {
                    Value cond = eval_expr(node->data.for_stmt.cond);
                    int c = value_to_bool(cond);
                    free_value(&cond);
                    if (!c) break;
                }
                break_caught = false;
                continue_caught = false;
                exec_statement(node->data.for_stmt.body);

                if (return_caught) {
                    ret = false;
                    goto for_cleanup;
                }
                if (exception_raised) {
                    ret = false;
                    goto for_cleanup;
                }
                if (break_caught) {
                    if (break_levels > 1) {
                        break_levels--;
                        ret = false;
                        goto for_cleanup;
                    }
                    break_caught = false;
                    break_levels = 1;
                    break;
                }
                if (continue_caught) {
                    if (continue_levels > 1) {
                        // 向外层循环 continue，跳过当前层的 update
                        continue_levels--;
                        ret = false;
                        goto for_cleanup;
                    }
                    continue_caught = false;
                    continue_levels = 1;
                    // 落到下面执行 update（默认 continue 语义）
                }
                if (node->data.for_stmt.update) {
                    exec_statement(node->data.for_stmt.update);
                
                    if (return_caught) {
                        ret = false;
                        goto for_cleanup;
                    }
                    if (exception_raised) {
                        ret = false;
                        goto for_cleanup;
                    }
                    if (break_caught) {
                        if (break_levels > 1) {
                            break_levels--;
                            ret = false;
                            goto for_cleanup;
                        }
                        break_caught = false;
                        break_levels = 1;
                        break;
                    }
                    if (continue_caught) {
                        if (continue_levels > 1) {
                            continue_levels--;
                            ret = false;
                            goto for_cleanup;
                        }
                        continue_caught = false;
                        continue_levels = 1;
                    }
                }
            }
            ret = true;
        for_cleanup:
            in_loop--;
            break;
         }
         
        case NODE_FOREACH: {

            Value coll = eval_expr(node->data.foreach.collection);
        
            if (coll.type != VAL_ARRAY && coll.type != VAL_OBJECT && coll.type != VAL_STRING && !is_lazy_range(coll)) {
                kr_error("Fehler: für jedes 只能遍历数组或对象\n");
            }
            in_loop++;
            auto mark_var_used = [&](const char* name) {
                Variable* v = get_var(name, false);
                if (v) v->is_read = true;
            };
        
            if (is_lazy_range(coll)) {
                int64_t rs, re, rstep;
                extract_range_params(coll, rs, re, rstep);
                int64_t count = lazy_range_count(rs, re, rstep);
                if (count > MAX_LOOP_ITERATIONS) {
                    kr_error("Fehler: Range 迭代次数超过限制 (%d)\n", MAX_LOOP_ITERATIONS);
                }
                bool has_value_var_r = (node->data.foreach.value_var != NULL);
                for (int64_t idx = 0; idx < count; idx++) {
                    int64_t val = rs + idx * rstep;
                    if (has_value_var_r) {
                        set_var(node->data.foreach.key_var, make_int64(idx));
                        mark_var_used(node->data.foreach.key_var);
                        set_var(node->data.foreach.value_var, make_int64(val));
                        mark_var_used(node->data.foreach.value_var);
                    } else {
                        set_var(node->data.foreach.key_var, make_int64(val));
                        mark_var_used(node->data.foreach.key_var);
                    }
                    break_caught = false;
                    continue_caught = false;
                    exec_statement(node->data.foreach.body);
                    if (return_caught) { ret = false; goto foreach_cleanup; }
                    if (exception_raised) { ret = false; goto foreach_cleanup; }
                    if (break_caught) {
                        if (break_levels > 1) {
                            break_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        break_caught = false;
                        break_levels = 1;
                        break;
                    }
                    if (continue_caught) {
                        if (continue_levels > 1) {
                            continue_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        continue_caught = false;
                        continue_levels = 1;
                        continue;
                    }
                }
                ret = true;
                goto foreach_cleanup;
            }
            
            if (coll.type == VAL_STRING) {
                const std::string& s = coll.str_val;
                std::vector<std::string> utf8_chars;
        
                // 一次性预处理，分割全部utf8字符
                for (size_t i = 0; i < s.size(); ) {
                    unsigned char c = static_cast<unsigned char>(s[i]);
                    size_t len;
                    if (c < 0x80) len = 1;
                    else if ((c & 0xE0) == 0xC0) len = 2;
                    else if ((c & 0xF0) == 0xE0) len = 3;
                    else if ((c & 0xF8) == 0xF0) len = 4;
                    else len = 1; // 无效字节，单字节
        
                    // 防止越界（比如截断的utf8）
                    if (i + len > s.size()) {
                        len = s.size() - i;
                    }
                    utf8_chars.push_back(s.substr(i, len));
                    i += len;
                }
        
                size_t char_count = utf8_chars.size();
                for (size_t i = 0; i < char_count; i++) {
                    const std::string& ch = utf8_chars[i];
                    if (node->data.foreach.value_var == NULL) {
                        // 单变量：直接存UTF8字符
                        set_var(node->data.foreach.key_var, make_string(ch.c_str()));
                        mark_var_used(node->data.foreach.key_var);
                    } else {
                        // 双变量：索引 + UTF8字符
                        set_var(node->data.foreach.key_var, make_int(static_cast<long long>(i)));
                        mark_var_used(node->data.foreach.key_var);
                        set_var(node->data.foreach.value_var, make_string(ch.c_str()));
                        mark_var_used(node->data.foreach.value_var);
                    }
        
                    break_caught = false;
                    continue_caught = false;
                    exec_statement(node->data.foreach.body);
        
                    if (return_caught) {
                        ret = false;
                        goto foreach_cleanup;
                    }
                    if (exception_raised) {
                        ret = false;
                        goto foreach_cleanup;
                    }
                    if (break_caught) {
                        if (break_levels > 1) {
                            break_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        break_caught = false;
                        break_levels = 1;
                        break;
                    }
                    if (continue_caught) {
                        if (continue_levels > 1) {
                            continue_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        continue_caught = false;
                        continue_levels = 1;
                        continue;
                    }
                }
            }

            else if (coll.type == VAL_ARRAY) {
                for (long long i = 0; i < coll.arr_val.length; i++) {
                    if (node->data.foreach.value_var == NULL) {
                        set_var(node->data.foreach.key_var, copy_value(coll.arr_val.elements[i]));
                        mark_var_used(node->data.foreach.key_var);
                    } else {
                        set_var(node->data.foreach.key_var, make_int(i));
                        mark_var_used(node->data.foreach.key_var);
                        set_var(node->data.foreach.value_var, copy_value(coll.arr_val.elements[i]));
                        mark_var_used(node->data.foreach.value_var);
                    }
        
                    break_caught = false;
                    continue_caught = false;
                    exec_statement(node->data.foreach.body);
        
                    if (return_caught) {
                        ret = false;
                        goto foreach_cleanup;
                    }
                    if (exception_raised) {
                        ret = false;
                        goto foreach_cleanup;
                    }
                    if (break_caught) {
                        if (break_levels > 1) {
                            break_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        break_caught = false;
                        break_levels = 1;
                        break;
                    }
                    if (continue_caught) {
                        if (continue_levels > 1) {
                            continue_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        continue_caught = false;
                        continue_levels = 1;
                        continue;
                    }
                }
            } else { // VAL_OBJECT
                for (int i = 0; i < coll.obj_val.count; i++) {
                    if (node->data.foreach.value_var == NULL) {
                        // 仅遍历值（键被忽略，但这里变量名为 key_var 实际存储值）
                        set_var(node->data.foreach.key_var, copy_value(coll.obj_val.entries[i].value));
                        mark_var_used(node->data.foreach.key_var);
                    } else {
                        // 键-值对遍历
                        set_var(node->data.foreach.key_var, make_string(coll.obj_val.entries[i].key));
                        mark_var_used(node->data.foreach.key_var);
                        set_var(node->data.foreach.value_var, copy_value(coll.obj_val.entries[i].value));
                        mark_var_used(node->data.foreach.value_var);
                    }
        
                    break_caught = false;
                    continue_caught = false;
                    exec_statement(node->data.foreach.body);
        
                    if (return_caught) {
                        ret = false;
                        goto foreach_cleanup;
                    }
                    if (exception_raised) {
                        ret = false;
                        goto foreach_cleanup;
                    }
                    if (break_caught) {
                        if (break_levels > 1) {
                            break_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        break_caught = false;
                        break_levels = 1;
                        break;
                    }
                    if (continue_caught) {
                        if (continue_levels > 1) {
                            continue_levels--;
                            ret = false;
                            goto foreach_cleanup;
                        }
                        continue_caught = false;
                        continue_levels = 1;
                        continue;
                    }
                }
            }
        
            ret = true;
        
        foreach_cleanup:
            in_loop--;
            free_value(&coll);
            break;
        }
         
         case NODE_DO_WHILE: {
            int iterations = 0;
            in_loop++;
        
            // ---- 常量条件优化 ----
            bool cond_const = false;
            int const_bool = 0;
            ASTNode* cond_node = node->data.do_while.cond;
            if (cond_node->type == NODE_NUMBER) {
                Value const_val = eval_expr(cond_node);
                const_bool = value_to_bool(const_val);
                free_value(&const_val);
                cond_const = true;
            }
        
            do {
                if (++iterations > MAX_LOOP_ITERATIONS) {
                    kr_error("Fehler: tu-indes 循环超过最大迭代次数 (%d)\n", MAX_LOOP_ITERATIONS);
                }
        
                break_caught = false;
                continue_caught = false;
                exec_statement(node->data.do_while.body);
        
                if (return_caught) { ret = false; goto do_while_cleanup; }
                if (exception_raised) { ret = false; goto do_while_cleanup; }
                if (break_caught) {
                    if (break_levels > 1) {
                        break_levels--;
                        ret = false;
                        goto do_while_cleanup;
                    }
                    break_caught = false;
                    break_levels = 1;
                    break;
                }
                if (continue_caught) {
                    if (continue_levels > 1) {
                        continue_levels--;
                        ret = false;
                        goto do_while_cleanup;
                    }
                    continue_caught = false;
                    continue_levels = 1;
                }
        
                // 条件检查
                int c;
                if (cond_const) {
                    c = const_bool;
                } else {
                    Value cond = eval_expr(cond_node);
                    c = value_to_bool(cond);
                    free_value(&cond);
                }
                if (!c) break;
        
            } while (true);
        
        do_while_cleanup:
            in_loop--;
            break;
        }
        case NODE_RULE_DEF: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex); 
            declare_var(node->data.func_def.name, false, make_null());
            if (node->data.func_def.name) {
                if (class_table.find(node->data.func_def.name) != class_table.end()) {
                    kr_warn("函数名 '%s' 与类名相同。注意：'%s(...)' 会被解释为类实例化，而 '%s' 没有括号时则引用函数。这可能会导致混淆。",
                        node->data.func_def.name,
                        node->data.func_def.name,
                        node->data.func_def.name);
                }
            }
            Value func_val = make_function(
                node->data.func_def.name,
                node->data.func_def.params,
                node->data.func_def.param_count,
                node->data.func_def.body,
                copy_scope_chain(current_scope),
                false,          // is_memoized
                false,          // is_async
                node->data.func_def.global_scope,
                true,           // is_rule
                node->data.func_def.return_type,
                node->data.func_def.vararg_name,
                node->data.func_def.param_is_const,
                node->data.func_def.param_defaults,
                node->data.func_def.param_types,
                node->data.func_def.vararg_type
            );

            Variable* var = get_var(node->data.func_def.name);
            if (var) { free_value(&var->value); var->value = func_val; }
            else declare_var(node->data.func_def.name, false, func_val);
            break;
         }
         case NODE_FUNC_DEF: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            
            // ---- 确定目标作用域（根据 global_scope 标志） ----
            Scope* target_scope = node->data.func_def.global_scope ? get_global_scope() : current_scope;
            
            // ---- 在目标作用域中占位声明（允许递归） ----
            int idx = get_var_index_in_scope(target_scope, node->data.func_def.name);
            if (idx < 0) {
                declare_var_in_scope(target_scope, node->data.func_def.name, false, make_null());
                idx = get_var_index_in_scope(target_scope, node->data.func_def.name);
                // idx 现在必定有效
            }
            if (node->data.func_def.name) {
                if (class_table.find(node->data.func_def.name) != class_table.end()) {
                    kr_warn("函数名 '%s' 与类名相同。注意：'%s(...)' 会被解释为类实例化，而 '%s' 没有括号时则引用函数。这可能会导致混淆。",
                        node->data.func_def.name,
                        node->data.func_def.name,
                        node->data.func_def.name);
                }
            }
            
            // ---- 复制当前作用域作为闭包（使用带 visited 的版本） ----
            std::unordered_map<Scope*, Scope*> visited;
            Scope* captured = copy_scope_chain(current_scope, visited);
            
            // ---- 构造函数值 ----
            Value func_val;
            func_val.type = VAL_FUNCTION;
            func_val.func_val.name = node->data.func_def.name ? strdup(node->data.func_def.name) : NULL;
            func_val.func_val.param_count = node->data.func_def.param_count;
            func_val.func_val.params = (char**)malloc(func_val.func_val.param_count * sizeof(char*));
            for (int i = 0; i < func_val.func_val.param_count; i++)
                func_val.func_val.params[i] = strdup(node->data.func_def.params[i]);
            func_val.func_val.body = copy_ast(node->data.func_def.body);
            func_val.func_val.closure_scope = captured;   // 使用已复制好的闭包
            func_val.func_val.is_memoized = node->data.func_def.is_memoized;
            func_val.func_val.is_async = false;
            func_val.func_val.global_scope = node->data.func_def.global_scope;
            func_val.func_val.is_rule = false;
            func_val.func_val.return_type = copy_type_node(node->data.func_def.return_type);
            func_val.func_val.vararg_name = node->data.func_def.vararg_name ? strdup(node->data.func_def.vararg_name) : NULL;
            func_val.func_val.param_is_const = (bool*)malloc(node->data.func_def.param_count * sizeof(bool));
            func_val.func_val.param_defaults = (ASTNode**)malloc(node->data.func_def.param_count * sizeof(ASTNode*));
            for (int i = 0; i < node->data.func_def.param_count; i++) {
                func_val.func_val.param_is_const[i] = node->data.func_def.param_is_const[i];
                func_val.func_val.param_defaults[i] = node->data.func_def.param_defaults[i] ? copy_ast(node->data.func_def.param_defaults[i]) : NULL;
            }
        
            if (node->data.func_def.param_types) {
                func_val.func_val.param_types = (TypeNode**)malloc(node->data.func_def.param_count * sizeof(TypeNode*));
                for (int i = 0; i < node->data.func_def.param_count; i++)
                    func_val.func_val.param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
            } else {
                func_val.func_val.param_types = nullptr;
            }
            func_val.func_val.vararg_type = copy_type_node(node->data.func_def.vararg_type);
            func_val.func_val.filename = strdup(current_filename ? current_filename : "-");
            
            // ---- 赋值给目标作用域中的变量（替换原 get_var/declare_var 逻辑） ----
            // 此时 idx 已存在，直接获取指针
            Variable* var = &target_scope->vars[idx];
            free_value(&var->value);
            var->value = func_val;   // 直接移动，func_val 不再单独释放
            
            // ---- 如果定义在全局作用域，同时注册到全局函数表（保持原逻辑） ----
            if (node->data.func_def.name && current_scope == original_global_scope) {
                std::lock_guard<std::mutex> lock(functions_mutex);
                functions = (Function*)realloc(functions, (func_count + 1) * sizeof(Function));
                Function* f = &functions[func_count++];
                f->name = strdup(node->data.func_def.name);
                f->param_count = node->data.func_def.param_count;
                f->params = (char**)malloc(f->param_count * sizeof(char*));
                for (int i = 0; i < f->param_count; i++) f->params[i] = strdup(node->data.func_def.params[i]);
                f->body = copy_ast(node->data.func_def.body);
                f->closure_scope = copy_scope_chain(current_scope);
                f->is_memoized = node->data.func_def.is_memoized;
                f->is_async = false;
                f->global_scope = node->data.func_def.global_scope;
                f->cache = nullptr;
                f->vararg_name = node->data.func_def.vararg_name ? strdup(node->data.func_def.vararg_name) : NULL;
                f->return_type = copy_type_node(node->data.func_def.return_type);
                f->param_is_const = (bool*)malloc(f->param_count * sizeof(bool));
                f->param_defaults = (ASTNode**)malloc(f->param_count * sizeof(ASTNode*));
                if (node->data.func_def.param_types) {
                    f->param_types = (TypeNode**)malloc(f->param_count * sizeof(TypeNode*));
                    for (int i = 0; i < f->param_count; i++) {
                        f->param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
                    }
                } else {
                    f->param_types = nullptr;
                }
                f->vararg_type = copy_type_node(node->data.func_def.vararg_type);
                f->called = false;
                f->is_stmt_func = node->data.func_def.is_stmt_func;
                f->filename = strdup(current_filename ? current_filename : "-");
                g_func_decl_pos[node->data.func_def.name] = {node->line, node->col};
            }
            break_caught = false;
            continue_caught = false;
            break;
         }
         case NODE_ASYNC_FUNC_DEF: {
             std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
             
             // ---- 确定目标作用域（根据 global_scope 标志） ----
             Scope* target_scope = node->data.func_def.global_scope ? get_global_scope() : current_scope;
             
             // ---- 在目标作用域中占位声明（允许递归） ----
             int idx = get_var_index_in_scope(target_scope, node->data.func_def.name);
             if (idx < 0) {
                 declare_var_in_scope(target_scope, node->data.func_def.name, false, make_null());
                 idx = get_var_index_in_scope(target_scope, node->data.func_def.name);
             }
             if (node->data.func_def.name) {
                 if (class_table.find(node->data.func_def.name) != class_table.end()) {
                     kr_warn("函数名 '%s' 与类名相同。注意：'%s(...)' 会被解释为类实例化，而 '%s' 没有括号时则引用函数。这可能会导致混淆。",
                         node->data.func_def.name,
                         node->data.func_def.name,
                         node->data.func_def.name);
                 }
             }
             
             // ---- 复制当前作用域作为闭包 ----
             Scope* captured = copy_scope_chain(current_scope);
             
             // ---- 构造函数值（异步函数） ----
             Value func_val = make_function(
                 node->data.func_def.name,
                 node->data.func_def.params,
                 node->data.func_def.param_count,
                 node->data.func_def.body,
                 captured,
                 node->data.func_def.is_memoized,
                 true,   // is_async
                 node->data.func_def.global_scope,
                 false,  // is_rule
                 node->data.func_def.return_type,
                 node->data.func_def.vararg_name,
                 node->data.func_def.param_is_const,
                 node->data.func_def.param_defaults
             );
             // 补充参数类型和可变参数类型（make_function 未复制这些）
             func_val.func_val.param_types = (TypeNode**)malloc(node->data.func_def.param_count * sizeof(TypeNode*));
             for (int i = 0; i < node->data.func_def.param_count; i++)
                 func_val.func_val.param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
             func_val.func_val.vararg_type = copy_type_node(node->data.func_def.vararg_type);
             func_val.func_val.filename = strdup(current_filename ? current_filename : "-");
             
             // ---- 赋值给目标作用域中的变量 ----
             Variable* var = &target_scope->vars[idx];
             free_value(&var->value);
             var->value = func_val;
             
             // ---- 如果定义在全局作用域，同时注册到全局函数表 ----
             if (node->data.func_def.name && current_scope == original_global_scope) {
                 std::lock_guard<std::mutex> lock(functions_mutex);
                 functions = (Function*)realloc(functions, (func_count + 1) * sizeof(Function));
                 Function* f = &functions[func_count++];
                 f->name = strdup(node->data.func_def.name);
                 f->param_count = node->data.func_def.param_count;
                 f->params = (char**)malloc(f->param_count * sizeof(char*));
                 for (int i = 0; i < f->param_count; i++) f->params[i] = strdup(node->data.func_def.params[i]);
                 f->body = copy_ast(node->data.func_def.body);
                 f->closure_scope = copy_scope_chain(current_scope);
                 f->is_memoized = node->data.func_def.is_memoized;
                 f->is_async = true;
                 f->global_scope = node->data.func_def.global_scope;
                 f->cache = nullptr;
                 f->vararg_name = node->data.func_def.vararg_name ? strdup(node->data.func_def.vararg_name) : NULL;
                 f->return_type = copy_type_node(node->data.func_def.return_type);
                 f->param_is_const = (bool*)malloc(f->param_count * sizeof(bool));
                 f->param_defaults = (ASTNode**)malloc(f->param_count * sizeof(ASTNode*));
                 if (node->data.func_def.param_types) {
                     f->param_types = (TypeNode**)malloc(f->param_count * sizeof(TypeNode*));
                     for (int i = 0; i < f->param_count; i++) {
                         f->param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
                     }
                 } else {
                     f->param_types = nullptr;
                 }
                 f->vararg_type = copy_type_node(node->data.func_def.vararg_type);
                 f->called = false;
                 f->is_stmt_func = node->data.func_def.is_stmt_func;
                 f->filename = strdup(current_filename ? current_filename : "-");
                 g_func_decl_pos[node->data.func_def.name] = {node->line, node->col};
             }
             break;
         }
         case NODE_FUNC_CALL: {
            Value v = eval_expr(node);
            free_value(&v);
            // ---- 函数调用结束后，必须清除所有控制标志，避免污染外层 ----
            return_caught = false;
            break_caught = false;
            continue_caught = false;
            exception_raised = false;
            break;
         }
         case NODE_RETURN: {
            if (node->data.ret.expr) {
                return_value = eval_expr(node->data.ret.expr);
            } else {
                return_value = make_null();
            }
            return_caught = true;
            ret = false;
            goto cleanup;
         }
         case NODE_EXPR_STMT: {
            ASTNode* expr = node->data.expr_stmt.expr;

            // ---- 快速路径 0：独立递增/递减语句（不构造结果 Value） ----
            if (!g_current_return_slot &&
                (expr->type == NODE_PRE_INC || expr->type == NODE_PRE_DEC ||
                 expr->type == NODE_POST_INC || expr->type == NODE_POST_DEC)) {
                Value* ptr = get_mutable_ptr(expr->data.inc_dec.operand);
                bool is_inc = (expr->type == NODE_PRE_INC || expr->type == NODE_POST_INC);
                // int64 快线：绝大多数循环变量都是 64 位整数
                if (ptr->type == VAL_INT64) {
                    if (is_inc) {
                        if (ptr->int64_val != INT64_MAX) ptr->int64_val++;
                        else inc_value(ptr);          // 溢出回退到 GMP
                    } else {
                        if (ptr->int64_val != INT64_MIN) ptr->int64_val--;
                        else dec_value(ptr);
                    }
                } else if (is_inc) {
                    inc_value(ptr);
                } else {
                    dec_value(ptr);
                }
                return_caught = false;
                break_caught = false;
                continue_caught = false;
                break;
            }
        
            // ---- 快速路径 1：顶层赋值 + 不需要块返回值 → 完全零复制 ----
            if (expr->type == NODE_ASSIGN && !g_current_return_slot) {
                if (try_fast_compound_int64(expr)) {
                    return_caught = false;
                    break_caught = false;
                    continue_caught = false;
                    break;
                }
                Value rhs = eval_expr(expr->data.assign.expr);
                assign_to_target(expr, rhs);   // rhs 直接移入目标变量
                return_caught = false;
                break_caught = false;
                continue_caught = false;
                break;
            }
        
            // ---- 保留原语句函数无参调用 ----
            if (expr->type == NODE_VARIABLE) {
                const char* name = expr->data.var_name;
                Variable* var = get_var(name);
                if (var) {
                    var = resolve_alias(var);
                    if (var->value.type == VAL_FUNCTION && var->value.func_val.is_stmt_func) {
                        Value result = call_function_value(var->value, nullptr, 0, node);
                        free_value(&result);
                        return_caught = false;
                        break_caught = false;
                        continue_caught = false;
                        break;
                    }
                }
            }
        
            // ---- 通用路径 ----
            Value v = eval_expr(expr);
            if (g_current_return_slot) {
                free_value(g_current_return_slot);
                *g_current_return_slot = v;   // 移动
            } else {
                free_value(&v);
            }
            return_caught = false;
            break_caught = false;
            continue_caught = false;
            break;
        }
        case NODE_BREAK: {
            if (in_loop == 0) {
                g_last_error_line = node->line;
                g_last_error_col  = node->col;
                std::string hint = make_keyword_alias_hint("bruch", "bruch");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "Fehler: bruch 只能在循环中使用");
            }
            int levels = node->data.break_stmt.levels;
            if (levels > in_loop) {
                error_at(node->line, node->col,
                         "bruch 层级 %d 超过当前循环嵌套深度 %d",
                         levels, in_loop);
            }
            break_caught = true;
            break_levels = levels;
            ret = false;
            goto cleanup;
        }
        case NODE_CONTINUE: {
            if (in_loop == 0) {
                g_last_error_line = node->line;
                g_last_error_col  = node->col;
                std::string hint = make_keyword_alias_hint("weiter", "weiter");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "Fehler: weiter 只能在循环中使用");
            }
            int levels = node->data.break_stmt.levels;
            if (levels > in_loop) {
                error_at(node->line, node->col,
                         "weiter 层级 %d 超过当前循环嵌套深度 %d",
                         levels, in_loop);
            }
            continue_caught = true;
            continue_levels = levels;
            ret = false;
            goto cleanup;
        }
         case NODE_TRY: {
            // 重置控制标志
            return_caught = false;
            break_caught = false;
            continue_caught = false;
            exception_raised = false;
        
            // ----- 执行 try 体，并捕获致命异常 -----
            try {
                exec_statement(node->data.try_stmt.try_body);
            } catch (const KRError& e) {
                // 将异常转为可捕获的错误值
                exception_value = make_string(e.what());
                exception_raised = true;
                // 其他控制标志保持 false
            }
            // 注意：其他 C++ 异常（如 std::bad_alloc）不捕获，保持原始崩溃行为
        
            bool try_return = return_caught;
            bool try_break = break_caught;
            bool try_continue = continue_caught;
            bool try_exception = exception_raised;
            Value try_exception_val = exception_value;
        
            // 清除 try 产生的标志，准备 catch/finally
            return_caught = false;
            break_caught = false;
            continue_caught = false;
            exception_raised = false;
        
            // ---------- 处理 catch ----------
            if (try_exception && node->data.try_stmt.catch_body) {
                if (node->data.try_stmt.catch_var && strcmp(node->data.try_stmt.catch_var, "_") != 0) {
                    declare_var(node->data.try_stmt.catch_var, false, copy_value(try_exception_val));
                    Variable* var = get_var(node->data.try_stmt.catch_var);
                    if (var) var->is_read = true;
                }
                in_catch_depth++;
                exec_statement(node->data.try_stmt.catch_body);
                in_catch_depth--;
                if (exception_raised) {
                    try_exception = true;
                    try_exception_val = exception_value;
                    exception_raised = false;
                } else {
                    try_exception = false;
                }
            }
        
            // ---------- 处理 finally ----------
            bool finally_ok = true;
            if (node->data.try_stmt.finally_body) {
                finally_ok = exec_statement(node->data.try_stmt.finally_body);
            }
        
            if (finally_ok && !return_caught && !break_caught && !continue_caught && !exception_raised) {
                return_caught = try_return;
                break_caught = try_break;
                continue_caught = try_continue;
                exception_raised = try_exception;
                if (try_exception) {
                    exception_value = try_exception_val;
                }
            }
        
            ret = !(return_caught || break_caught || continue_caught || exception_raised);
            break;
        }
        case NODE_THROW: {
            exception_value = eval_expr(node->data.throw_expr.expr);
            char* msg = value_to_string(exception_value);
            // 强制输出异常消息（即使全局警告未开启）
            bool old_warn = g_warnings_enabled;
            g_warnings_enabled = true;
            kr_warn("%s", msg);
            g_warnings_enabled = old_warn;
            free(msg);
            exception_raised = true;
            ret = false;
            goto cleanup;
         }
         case NODE_OBJECT_ASSIGN: {
            // ---- 1. 判断是否为静态属性赋值 ----
            bool is_static = false;
            std::string class_name;
            if (node->data.object_assign.obj->type == NODE_VARIABLE) {
                std::string var_name = node->data.object_assign.obj->data.var_name;
                bool var_exists = (get_var(var_name.c_str()) != nullptr);
                if (!var_exists) {
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    if (class_table.find(var_name) != class_table.end()) {
                        is_static = true;
                        class_name = var_name;
                    }
                }
            }

            if (is_static) {
                Value rhs = eval_expr(node->data.object_assign.value);
                const char* key = node->data.object_assign.key;
            
                auto cls_it = class_table.find(class_name);
                if (cls_it == class_table.end()) {
                    free_value(&rhs);
                    kr_error("类 '%s' 未定义", class_name.c_str());
                }
                std::string prop_key = cls_it->first + "::" + key; 

                // ---- 一次遍历同时完成：查找属性、权限检查、惰性只读、类型检查 ----
                bool found_static = false;
                const PropertyDef* matched = nullptr;
                for (const auto& prop : cls_it->second.properties) {
                    if (prop.name == key && prop.is_static) {
                        matched = &prop;
                        found_static = true;
                        break;
                    }
                }
                if (!found_static) {
                    free_value(&rhs);
                    kr_error("类 '%s' 没有静态属性 '%s'",
                            class_name.c_str(), key);
                }

                // 权限检查
                check_access(matched->access,
                            cls_it->second.defining_file,
                            cls_it->second.name,
                            key, class_name, node);

                // 惰性属性只读
                if (matched->is_lazy) {
                    free_value(&rhs);
                    kr_error("惰性静态属性 '%s' 不能赋值", key);
                }

                // 类型检查
                if (matched->type && !check_type(matched->type, rhs)) {
                    char* got = value_to_string(rhs);
                    std::string expected = type_to_string(matched->type);
                    free_value(&rhs);
                    kr_error("静态属性 '%s' 赋值类型错误: 期望 '%s', 实际 '%s'",
                            key, expected.c_str(), got);
                }

                // ---- 写入缓存 ----
                {
                    std::lock_guard<std::mutex> lock(static_props_mutex);
                    auto it = static_props.find(prop_key);
                    if (it != static_props.end()) {
                        free_value(&it->second);
                        it->second = copy_value(rhs);
                    } else {
                        static_props[prop_key] = copy_value(rhs);
                    }
                    // 如果这个属性同时登记在 lazy 表中（理论上不会，因为已拦），清掉以防万一
                    static_lazy_init.erase(prop_key);
                }
                free_value(&rhs);
                break;
            }
        
            // ---- 2. 普通对象属性赋值 ----
            Value* parent_ptr = get_mutable_ptr(node->data.object_assign.obj);
            if (parent_ptr->type != VAL_OBJECT) {
                kr_error("尝试为非对象设置属性");
            }
            char* key = node->data.object_assign.key;
            Value rhs = eval_expr(node->data.object_assign.value);

            // 提取对象所属类（调用者类）
            std::string obj_class;
            for (int i = 0; i < parent_ptr->obj_val.count; i++) {
                if (strcmp(parent_ptr->obj_val.entries[i].key, "__klass") == 0 &&
                    parent_ptr->obj_val.entries[i].value.type == VAL_STRING) {
                    obj_class = parent_ptr->obj_val.entries[i].value.str_val;
                    break;
                }
            }

            // 查找属性定义类（包括继承链）
            if (!obj_class.empty() && (key[0] != '_' || key[1] != '_')) {
                std::string prop_owner = obj_class;
                while (!prop_owner.empty()) {
                    auto it = class_table.find(prop_owner);
                    if (it == class_table.end()) break;
            
                    // ---- 查找属性定义：一次性取出 is_defined / access_level / is_lazy ----
                    bool is_defined   = false;
                    int  access_level = 0;
                    bool prop_is_lazy = false;
                    std::string defining_file = it->second.defining_file;
            
                    for (const auto& prop : it->second.properties) {
                        if (prop.name == key && !prop.is_static) {
                            is_defined    = true;
                            access_level  = prop.access;
                            prop_is_lazy  = prop.is_lazy;
                            break;
                        }
                    }
            
                    if (is_defined) {
                        check_access(access_level, defining_file, prop_owner, key, obj_class, node);
            
                        if (prop_is_lazy) {
                            free_value(&rhs);
                            kr_error("惰性属性 '%s' 不能赋值", key);
                        }
                        break; // 找到定义后退出循环
                    }
            
                    if (it->second.parent.empty()) break;
                    prop_owner = it->second.parent;
                }
            }
        
            // 类型检查（仅当对象是变量时，且变量有类型注解）
            if (node->data.object_assign.obj->type == NODE_VARIABLE) {
                Variable* var = get_var(node->data.object_assign.obj->data.var_name);
                if (var && var->type_annotation && var->type_annotation->kind == TYPE_OBJECT) {
                    TypeNode* obj_type = var->type_annotation;
                    TypeNode* prop_type = nullptr;
                    for (int i = 0; i < obj_type->object_type.count; i++) {
                        if (strcmp(obj_type->object_type.keys[i], key) == 0) {
                            prop_type = obj_type->object_type.types[i];
                            break;
                        }
                    }
                    if (prop_type) {
                        if (!check_type(prop_type, rhs)) {
                            std::string expected = type_to_string(prop_type);
                            char* got = value_to_string(rhs);
                            kr_error("对象属性 '%s' 赋值类型错误: 期望 '%s', 实际 '%s'",
                                     key, expected.c_str(), got);
                        }
                    }
                }
            }
        
            // 查找或创建属性并赋值
            Value* target_ptr = NULL;
            for (int i = 0; i < parent_ptr->obj_val.count; i++) {
                if (strcmp(parent_ptr->obj_val.entries[i].key, key) == 0) {
                    target_ptr = &parent_ptr->obj_val.entries[i].value;
                    break;
                }
            }
            if (!target_ptr) {
                parent_ptr->obj_val.count++;
                parent_ptr->obj_val.entries = (ObjectEntry*)realloc(parent_ptr->obj_val.entries,
                                            parent_ptr->obj_val.count * sizeof(ObjectEntry));
                parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].key = strdup(key);
                parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].value = make_null();
                target_ptr = &parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].value;
            }
            free_value(target_ptr);
            *target_ptr = rhs;   // 直接移动
            break;
        }
        case NODE_OBJECT_COMPOUND_ASSIGN: {
            // 拿可修改的对象指针
            Value* parent_ptr = get_mutable_ptr(node->data.object_compound_assign.obj);
            if (parent_ptr->type != VAL_OBJECT) {
                kr_error("复合赋值的对象不是对象类型");
            }
            char* key = node->data.object_compound_assign.key;

            // 查找属性，如果不存在则在末尾创建（值为 null，方便后续进行算术）
            Value* target = nullptr;
            for (int i = 0; i < parent_ptr->obj_val.count; i++) {
                if (strcmp(parent_ptr->obj_val.entries[i].key, key) == 0) {
                    target = &parent_ptr->obj_val.entries[i].value;
                    break;
                }
            }
            if (!target) {
                parent_ptr->obj_val.count++;
                parent_ptr->obj_val.entries = (ObjectEntry*)realloc(
                    parent_ptr->obj_val.entries,
                    parent_ptr->obj_val.count * sizeof(ObjectEntry));
                parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].key = strdup(key);
                parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].value = make_null();
                target = &parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].value;
            }

            // 计算 current OP rhs
            Value current = copy_value(*target);
            Value rhs     = eval_expr(node->data.object_compound_assign.rhs);
            char  op      = node->data.object_compound_assign.op;

            Value res = compute_compound(current, rhs, op);

            free_value(&current);
            free_value(&rhs);
            free_value(target);
            *target = res;    // 直接移动
            break;
        }
        case NODE_LAZY_VAR_DECL: {
            // 声明惰性变量
            declare_lazy_var(node->data.lazy_var_decl.name, node->data.lazy_var_decl.expr);
            
            // 若当前作用域为全局，记录声明位置
            if (current_scope == original_global_scope) {
                g_var_decl_pos[node->data.lazy_var_decl.name] = {node->line, node->col};
                int idx = get_var_index_in_scope(current_scope, node->data.lazy_var_decl.name);
                if (idx >= 0) {
                    current_scope->vars[idx].is_read = false;   // 确保标记为未读
                }
            }
            break;
        }
        case NODE_SICHER: {
            Value cond = eval_expr(node->data.sicher.expr);
            int ok = value_to_bool(cond);
            free_value(&cond);
            if (!ok) {
                // 直接退出，不产生后续错误，也不打印上下文
                if (node->data.sicher.msg_expr) {
                    Value msg_val = eval_expr(node->data.sicher.msg_expr);
                    char* msg_str = value_to_string(msg_val);
                    fprintf(stderr, "%s\n", msg_str);
                    free(msg_str);
                    free_value(&msg_val);
                } else {
                    fprintf(stderr, "\033[31mFehler: sicher ist NICH\033[0m\n");
                }
                std::exit(1);
            }
            break;
        }
        case NODE_SWAP_ASSIGN: {
            Scope* old_scope = NULL;
            if (node->data.swap.global) {
                old_scope = current_scope;
                current_scope = get_global_scope();   // 切换到全局作用域
            }
        
            Value* left_ptr = get_mutable_ptr(node->data.swap.left);
            Value* right_ptr = get_mutable_ptr(node->data.swap.right);
            if (left_ptr != right_ptr) {
                Value temp = copy_value(*left_ptr);
                free_value(left_ptr);
                *left_ptr = copy_value(*right_ptr);
                free_value(right_ptr);
                *right_ptr = temp;
            }
        
            if (old_scope) current_scope = old_scope; // 恢复原作用域
            break;
        }
        case NODE_IMPORT: {
            char* filename = node->data.import.filename;
            char* alias = node->data.import.alias;
            bool has_quote = node->data.import.has_quote;
        
            std::string base_dir = ".";
            if (current_filename && current_filename[0] != '\0') {
                fs::path file_path = fs::u8path(current_filename);
                base_dir = file_path.parent_path().string();
            }
        
            std::vector<std::string> added_funcs;
            Scope* mod_scope = load_module(filename, has_quote, base_dir, &added_funcs);
        
            if (alias) {
                // 创建模块对象
                ObjectEntry* entries = (ObjectEntry*)malloc(mod_scope->var_count * sizeof(ObjectEntry));
                for (int i = 0; i < mod_scope->var_count; ++i) {
                    entries[i].key = strdup(mod_scope->vars[i].name);
                    entries[i].value = copy_value(mod_scope->vars[i].value);
                }
                Value mod_obj = make_object(entries, mod_scope->var_count);
                for (int i = 0; i < mod_scope->var_count; ++i) {
                    free(entries[i].key);
                    free_value(&entries[i].value);
                }
                free(entries);
                declare_var(alias, false, mod_obj);
                // 标记别名变量为已使用
                int idx = get_var_index_in_scope(current_scope, alias);
                if (idx >= 0) current_scope->vars[idx].is_read = true;
            } else {
                // 直接导入所有变量
                for (int i = 0; i < mod_scope->var_count; ++i) {
                    const char* var_name = mod_scope->vars[i].name;
                    declare_var(var_name, false, copy_value(mod_scope->vars[i].value));
                    // 直接标记最新声明的变量为已读（位于当前作用域末尾）
                    if (current_scope->var_count > 0) {
                        current_scope->vars[current_scope->var_count - 1].is_read = true;
                    }
                }
        
                // 标记所有新增函数为已调用
                for (const std::string& fname : added_funcs) {
                    for (int j = 0; j < func_count; ++j) {
                        if (functions[j].name && fname == functions[j].name) {
                            functions[j].called = true;
                            break;
                        }
                    }
                }
            }
            break;
        }
        case NODE_ENUM_DEF: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            std::string enum_qual = type_key(node->data.enum_def.name);
        
            // (A) 兜底 enum_table 注册（当前代码根本没注册 enum_table）
            // 通常 parse_enum_definition() 已用 type_key_parse 注册过，
            // 若已存在则跳过。
            if (enum_table.find(enum_qual) == enum_table.end()) {
                EnumInfo info;
                info.variants.reserve(node->data.enum_def.variant_count);
                info.param_counts.reserve(node->data.enum_def.variant_count);
                for (int i = 0; i < node->data.enum_def.variant_count; i++) {
                    info.variants.push_back(node->data.enum_def.variants[i]);
                    info.param_counts.push_back(node->data.enum_def.variant_param_counts[i]);
                }
                enum_table[enum_qual] = std::move(info);
            }
        
            // (B) variant_table 用 type_key
            for (int i = 0; i < node->data.enum_def.variant_count; i++) {
                char* var_name = node->data.enum_def.variants[i];
                int param_count = node->data.enum_def.variant_param_counts[i];
                variant_table[type_key(var_name)] = { enum_qual, param_count };
        
                // declare_var 保持原样（变量本身仍然注册到当前 Scope，
                // 作用域隔离由 current_scope 负责，不需要额外前缀）
                Value func_val;
                func_val.type = VAL_FUNCTION;
                func_val.func_val.name = strdup(var_name);
                func_val.func_val.param_count = param_count;
                func_val.func_val.params = NULL;
                func_val.func_val.body = NULL;
                func_val.func_val.closure_scope = NULL;
                func_val.func_val.is_memoized = false;
                func_val.func_val.filename = strdup(current_filename ? current_filename : "-");
                declare_var(var_name, false, func_val);
            }
            break;
        }
        case NODE_AWAIT: {
            // 当 warte 单独作为语句时（虽然罕见），求值并释放结果
            Value v = eval_expr(node);
            free_value(&v);
            break;
        }
        case NODE_NULL:
            break;   // 什么也不做
        case NODE_KEY_BIND: {
            char* key = node->data.key_bind.key;
            ASTNode* body = node->data.key_bind.body;
            // 复制绑定体和作用域（避免节点释放时丢失）
            ASTNode* body_copy = copy_ast(body);
            Scope* captured = copy_scope_chain(current_scope);
            std::string key_str(key);
            auto it = key_bind_map.find(key_str);
            if (it != key_bind_map.end()) {
                free_ast(it->second.first);
                free_scope_chain(it->second.second);
            }
            key_bind_map[key_str] = std::make_pair(body_copy, captured);
            break;
        }
        case NODE_SCOPE_BLOCK: {
            push_scope();
            bool ok = true;
            for (int i = 0; i < node->data.block.count; i++) {
                if (!exec_statement(node->data.block.stmts[i])) {
                    if (return_caught || break_caught || continue_caught || exception_raised) {
                        ok = false;
                        break;
                    }
                }
            }
            pop_scope();
            ret = ok;
            break;
        }
        case NODE_ALIAS_DECL: {
            char* alias_name = node->data.alias_decl.name;
            char* target_name = node->data.alias_decl.target;
            Variable* target_var = get_var(target_name);
            if (!target_var) {
                kr_error("别名目标 '%s' 未定义\n", target_name);
                
            }
            Scope* target_scope = node->data.alias_decl.global ? get_global_scope() : current_scope;
            // 检查别名是否已存在
            if (get_var_index_in_scope(target_scope, alias_name) >= 0) {
                kr_error("变量 '%s' 已声明\n", alias_name);
                
            }
            // 分配新的 Variable
            target_scope->vars = (Variable*)realloc(target_scope->vars,
                                          (target_scope->var_count + 1) * sizeof(Variable));
            Variable* var = &target_scope->vars[target_scope->var_count++];
            var->name = strdup(alias_name);
            var->value = make_null();          // 不使用
            var->is_const = false;
            var->is_lazy = false;
            var->evaluated = false;
            var->init_expr = NULL;
            var->cached_value = make_null();
            var->is_alias = true;
            var->alias_target = strdup(target_name);
            break;
        }
        case NODE_GLOBAL_BLOCK: {
            Scope* old_scope = current_scope;
            current_scope = get_global_scope();   // 切换到全局作用域
            bool ok = true;
            for (int i = 0; i < node->data.block.count; i++) {
                if (!exec_statement(node->data.block.stmts[i])) {
                    if (return_caught || break_caught || continue_caught || exception_raised) {
                        ok = false;
                        break;
                    }
                }
            }
            current_scope = old_scope;            // 恢复原作用域
            ret = ok;
            break;
        }
        case NODE_DESTRUCTURE: {
            Value val = eval_expr(node->data.destructure.expr);
            int var_count = node->data.destructure.count;
        
            // 辅助 lambda：声明变量并记录位置
            auto declare_with_pos = [&](const char* name, Value elem) {
                int before = current_scope->var_count;
                declare_var(name, node->data.destructure.is_const, elem);
                if (current_scope->var_count > before) {
                    Variable* new_var = &current_scope->vars[current_scope->var_count - 1];
                    new_var->is_read = false;                     // 确保未读
                    if (current_scope == original_global_scope) {
                        g_var_decl_pos[name] = {node->line, node->col}; // 记录声明位置
                    }
                }
            };
        
            if (val.type == VAL_ARRAY) {
                if (val.arr_val.length != var_count) {
                    kr_error("解构赋值：数组长度 %lld 与变量数 %d 不匹配\n",
                            val.arr_val.length, var_count);
                }
                for (int i = 0; i < var_count; i++) {
                    Value elem = copy_value(val.arr_val.elements[i]);
                    declare_with_pos(node->data.destructure.names[i], elem);
                }
            }
            else if (val.type == VAL_OBJECT) {
                for (int i = 0; i < var_count; i++) {
                    char* name = node->data.destructure.names[i];
                    bool found = false;
                    for (int j = 0; j < val.obj_val.count; j++) {
                        if (strcmp(val.obj_val.entries[j].key, name) == 0) {
                            Value elem = copy_value(val.obj_val.entries[j].value);
                            declare_with_pos(name, elem);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        kr_error("解构赋值：对象中未找到键 '%s'\n", name);
                    }
                }
            }
            else {
                kr_error("解构赋值要求右侧为数组或对象，实际类型 %d\n", val.type);
            }
        
            free_value(&val);
            break;
        }
        case NODE_CLASS_DEF: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            ClassDef cls;
            cls.name = type_key(node->data.class_def.name);
            cls.parent = node->data.class_def.parent ? node->data.class_def.parent : "";
            if (!cls.parent.empty()) cls.parent = type_key(cls.parent);
        
            // ---- 复制构造函数参数名 ----
            cls.ctor_params.clear();
            for (int i = 0; i < node->data.class_def.ctor_param_count; i++)
                cls.ctor_params.push_back(node->data.class_def.ctor_params[i]);
        
            // ---- 复制构造函数参数类型 ----
            cls.ctor_param_types.clear();
            for (int i = 0; i < node->data.class_def.ctor_param_type_count; i++) {
                cls.ctor_param_types.push_back(copy_type_node(node->data.class_def.ctor_param_types[i]));
            }
        
            // ---- 复制构造函数体 ----
            cls.ctor_body = copy_ast(node->data.class_def.ctor_body);
        
            // ---- 复制方法 ----
            cls.methods.clear();
            for (int i = 0; i < node->data.class_def.methods.count; i++) {
                MethodDef md;
                md.body = nullptr;
                md.is_static = false;
                md.access = 0;
                md.return_type = nullptr;
                md.vararg_type = nullptr;
                md.is_stmt_func = false;
                // 参数名
                for (int j = 0; j < node->data.class_def.methods.param_counts[i]; j++)
                    md.params.push_back(node->data.class_def.methods.param_lists[i][j]);
                // 参数类型
                if (node->data.class_def.methods.param_types && node->data.class_def.methods.param_types[i]) {
                    for (int j = 0; j < node->data.class_def.methods.param_counts[i]; j++)
                        md.param_types.push_back(copy_type_node(node->data.class_def.methods.param_types[i][j]));
                }
                md.body = copy_ast(node->data.class_def.methods.bodies[i]);
                md.is_static = node->data.class_def.methods.is_static[i];
                md.access = node->data.class_def.methods.access[i];
                md.return_type = node->data.class_def.methods.return_types[i]
                                 ? copy_type_node(node->data.class_def.methods.return_types[i])
                                 : nullptr;

                if (node->data.class_def.methods.vararg_names && node->data.class_def.methods.vararg_names[i]) {
                    md.vararg_name = node->data.class_def.methods.vararg_names[i];
                }
                if (node->data.class_def.methods.vararg_types && node->data.class_def.methods.vararg_types[i]) {
                    md.vararg_type = copy_type_node(node->data.class_def.methods.vararg_types[i]);
                }
                cls.methods[node->data.class_def.methods.names[i]] = md;
            }
        
            // ---- 复制属性 ----
            cls.properties.clear();
            for (int i = 0; i < node->data.class_def.properties.count; i++) {
                PropertyDef pd;
                pd.name = node->data.class_def.properties.names[i];
                pd.type = node->data.class_def.properties.types[i]
                          ? copy_type_node(node->data.class_def.properties.types[i])
                          : nullptr;
                ASTNode* def_expr = node->data.class_def.properties.default_exprs[i];
                if (def_expr && def_expr->type == NODE_NULL) {
                    def_expr = nullptr;   // 避免在实例化时误认为有默认值
                }
                pd.default_expr = copy_ast(def_expr);
                pd.is_const = node->data.class_def.properties.is_const[i];
                pd.is_static = node->data.class_def.properties.is_static[i];
                pd.is_lazy = node->data.class_def.properties.is_lazy[i];
                pd.access = node->data.class_def.properties.access[i];
                cls.properties.push_back(pd);
            }

            if (!cls.parent.empty()) {
                auto parent_it = class_table.find(cls.parent);
                if (parent_it == class_table.end()) {
                    kr_error("父类 '%s' 未定义", cls.parent.c_str());
                }
                if (parent_it->second.access_modifier == 1) {
                    kr_error("无法从私有类 '%s' 继承", cls.parent.c_str());
                }
                // protected 父类允许继承，但实例化时受限
            }
        
            // ---- 父类存在性检查 ----
            if (!cls.parent.empty() && class_table.find(cls.parent) == class_table.end()) {
                std::string hint = suggest_correction(cls.parent);
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "父类 '%s' 未定义", cls.parent.c_str());
            }
        
            // ---- 存入全局类表 ----
            cls.access_modifier = node->data.class_def.access_modifier;
            const char* def_file = find_filename_by_line_col(node->line, node->col);
            cls.defining_file = def_file ? def_file : (current_filename ? current_filename : "");
        
            // ---- 为静态属性分配存储空间（使用外部 static_props） ----
            for (auto& prop : cls.properties) {
                if (prop.is_static) {
                    std::string key = cls.name + "::" + prop.name;
                    if (prop.is_lazy) {
                        static_lazy_init[key] = prop.default_expr;   // 可为 nullptr
                    } else if (prop.default_expr) {
                        Value init_val = eval_expr(prop.default_expr);
                        if (prop.type && !check_type(prop.type, init_val)) {
                            char* got = value_to_string(init_val);
                            kr_error("静态属性 '%s' 初始化类型错误: 期望 '%s', 实际 '%s'",
                                     prop.name.c_str(), type_to_string(prop.type).c_str(), got);
                        }
                        static_props[key] = copy_value(init_val);
                        free_value(&init_val);
                    } else {
                        Value init_val = prop.type
                            ? eval_expr(make_default_value_for_type(prop.type))
                            : make_null();
                        static_props[key] = copy_value(init_val);
                        free_value(&init_val);
                    }
                }
            }
            cls.is_static_class = node->data.class_def.is_static_class;
            cls.ctor_defaults.clear();
            for (int i = 0; i < node->data.class_def.ctor_default_count; ++i) {
                cls.ctor_defaults.push_back(copy_ast(node->data.class_def.ctor_defaults[i]));
            }
            if (cls.ctor_defaults.size() != cls.ctor_params.size()) {
                cls.ctor_defaults.resize(cls.ctor_params.size(), nullptr);
            }
            class_table.emplace(type_key(node->data.class_def.name), std::move(cls));
            break;
        }
        case NODE_SUPER_CALL: {
            Value v = eval_expr(node);
            free_value(&v);
            break;
        }
        case NODE_NEW: {
            Value v = eval_expr(node);
            free_value(&v);
            break;
        }
        case NODE_UMF_DEF: {
            // ---- 保存当前控制标志 ----
            bool old_return = return_caught;
            bool old_break = break_caught;
            bool old_continue = continue_caught;
            bool old_exception = exception_raised;
            Value old_return_val = copy_value(return_value);
            Value old_exception_val = copy_value(exception_value);
        
            // ---- 重置标志，防止内部污染 ----
            return_caught = false;
            break_caught = false;
            continue_caught = false;
            exception_raised = false;
        
            char* name = node->data.umf_def.name;
            char* parent_name = node->data.umf_def.parent_name;
        
            Scope* ns = nullptr;
            auto it = named_scopes.find(name);
            if (it == named_scopes.end()) {
                ns = (Scope*)calloc(1, sizeof(Scope));
                ns->id = next_scope_id++;
                ns->var_count = 0;
                ns->vars = NULL;
                if (parent_name) {
                    auto parent_it = named_scopes.find(parent_name);
                    if (parent_it == named_scopes.end())
                        kr_error("父作用域 '%s' 未定义", parent_name);
                    ns->parent = parent_it->second;
                } else {
                    ns->parent = original_global_scope;
                }
                named_scopes[name] = ns;
            } else {
                ns = it->second;
                // 可选的父作用域检查（忽略）
            }
        
            Scope* old_scope = current_scope;
            current_scope = ns;
            g_umf_stack.push_back(name);
            exec_statement(node->data.umf_def.body);
            g_umf_stack.pop_back();
            current_scope = old_scope;
        
            // ---- 丢弃 umf 内部产生的控制标志（并释放相关值） ----
            if (return_caught) {
                free_value(&return_value);
            }
            if (exception_raised) {
                free_value(&exception_value);
            }
            // 这些标志在 umf 内部没有意义，忽略它们
        
            // ---- 恢复旧标志和值 ----
            return_caught = old_return;
            break_caught = old_break;
            continue_caught = old_continue;
            exception_raised = old_exception;
            // 替换当前全局值为保存的旧值（移动语义，无需再 copy）
            free_value(&return_value);
            return_value = old_return_val;
            free_value(&exception_value);
            exception_value = old_exception_val;
        
            ret = true;
            break;
        }
        case NODE_DESTRUCTURE_ASSIGN: {
            Value val = eval_expr(node->data.destructure.expr);
            int var_count = node->data.destructure.count;
            char** names = node->data.destructure.names;
            char* rest_name = node->data.destructure.rest_name;   // 仅对象解构可用

            auto declare_or_assign_with_pos = [&](const char* name, Value elem, int line, int col) {
                // 仅在当前作用域查找（不向上追溯）
                int idx = get_var_index_in_scope(current_scope, name);
                if (idx >= 0) {
                    // 变量已存在 → 赋值（检查 const/lazy）
                    Variable* var = &current_scope->vars[idx];
                    if (var->is_const) kr_error("常量 '%s' 不能重新赋值", name);
                    if (var->is_lazy) kr_error("惰性变量 '%s' 不能赋值", name);
                    free_value(&var->value);
                    var->value = elem;
                    return;
                }
                // 变量不存在 → 声明（非 const）
                declare_var_in_scope(current_scope, name, false, elem);
                // 记录声明位置（仅全局作用域）
                if (current_scope == original_global_scope) {
                    g_var_decl_pos[name] = {line, col};
                    int new_idx = get_var_index_in_scope(current_scope, name);
                    if (new_idx >= 0) {
                        current_scope->vars[new_idx].is_read = false;
                    }
                }
            };
        
            if (val.type == VAL_ARRAY) {
                // ---------- 数组解构 ----------
                if (val.arr_val.length != var_count) {
                    kr_error("解构赋值：数组长度 %lld 与变量数 %d 不匹配", val.arr_val.length, var_count);
                }
                for (int i = 0; i < var_count; i++) {
                    Value elem = copy_value(val.arr_val.elements[i]);
                    declare_or_assign_with_pos(names[i], elem, node->line, node->col);
                }
            }
            else if (val.type == VAL_OBJECT) {
                // ---------- 对象解构 ----------
                // 1. 处理普通属性
                for (int i = 0; i < var_count; i++) {
                    char* name = names[i];
                    bool found = false;
                    for (int j = 0; j < val.obj_val.count; j++) {
                        if (strcmp(val.obj_val.entries[j].key, name) == 0) {
                            Value elem = copy_value(val.obj_val.entries[j].value);
                            declare_or_assign_with_pos(name, elem, node->line, node->col);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        kr_error("解构赋值：对象中未找到键 '%s'", name);
                    }
                }
        
                // 2. 处理剩余属性（rest）
                if (rest_name) {
                    ObjectEntry* rest_entries = nullptr;
                    int rest_count = 0;
                    for (int j = 0; j < val.obj_val.count; j++) {
                        char* key = val.obj_val.entries[j].key;
                        // 检查该键是否已被匹配过
                        bool matched = false;
                        for (int i = 0; i < var_count; i++) {
                            if (strcmp(names[i], key) == 0) {
                                matched = true;
                                break;
                            }
                        }
                        if (!matched) {
                            rest_entries = (ObjectEntry*)realloc(rest_entries, (rest_count + 1) * sizeof(ObjectEntry));
                            rest_entries[rest_count].key = strdup(key);
                            rest_entries[rest_count].value = copy_value(val.obj_val.entries[j].value);
                            rest_count++;
                        }
                    }
                    Value rest_obj = make_object(rest_entries, rest_count);
                    // 释放临时条目（make_object 已复制）
                    for (int i = 0; i < rest_count; i++) {
                        free(rest_entries[i].key);
                        free_value(&rest_entries[i].value);
                    }
                    free(rest_entries);
                    declare_or_assign_with_pos(rest_name, rest_obj, node->line, node->col);
                }
            }
            else {
                kr_error("解构赋值要求右侧为数组或对象，实际类型 %d", val.type);
            }
        
            free_value(&val);
            break;
        }
        case NODE_MULTI_ASSIGN: {
            // 先求所有右侧表达式的值
            Value* right_vals = (Value*)malloc(node->data.multi_assign.right_count * sizeof(Value));
            for (int i = 0; i < node->data.multi_assign.right_count; i++) {
                right_vals[i] = eval_expr(node->data.multi_assign.right_exprs[i]);
            }
        
            // 对每个左侧变量进行处理
            for (int i = 0; i < node->data.multi_assign.left_count; i++) {
                const char* name = node->data.multi_assign.left_names[i];
                Value val = (i < node->data.multi_assign.right_count) 
                            ? copy_value(right_vals[i]) 
                            : make_null();
        
                // 在当前作用域查找变量（不向上追溯）
                int idx = get_var_index_in_scope(current_scope, name);
                Variable* var = (idx >= 0) ? &current_scope->vars[idx] : nullptr;
        
                if (!var) {
                    // 隐式声明
                    declare_var_in_scope(current_scope, name, false, val);
                    idx = get_var_index_in_scope(current_scope, name);
                    if (idx >= 0) {
                        var = &current_scope->vars[idx];
                        if (current_scope == original_global_scope) {
                            g_var_decl_pos[name] = {node->line, node->col};
                            var->is_read = false;
                        }
                    }
                } else {
                    // 赋值
                    if (var->is_const) {
                        kr_error("Fehler: 常量 '%s' 不能重新赋值\n", name);
                    }
                    if (var->is_lazy) {
                        kr_error("Fehler: 惰性变量 '%s' 不能赋值\n", name);
                    }
                    free_value(&var->value);
                    var->value = val;   // 直接移动（val 已复制）
                }
            }
        
            // 释放右侧值
            for (int i = 0; i < node->data.multi_assign.right_count; i++)
                free_value(&right_vals[i]);
            free(right_vals);
            break;
        }
        case NODE_TYPE_DEF: {
            std::vector<std::string> values;
            for (int i = 0; i < node->data.type_def.member_count; ++i) {
                ASTNode* member = node->data.type_def.members[i];
                if (member->type == NODE_VARIABLE) {
                    Variable* var = get_var(member->data.var_name);
                    if (!var)
                        kr_error("未定义变量 '%s'", member->data.var_name);
                    var = resolve_alias(var);
                    if (var->value.type != VAL_STRING)
                        kr_error("变量 '%s' 的值不是字符串", member->data.var_name);
                    values.push_back(var->value.str_val);
                } else if (member->type == NODE_STRING) {
                    values.push_back(member->data.string);
                } else {
                    kr_error("类型成员必须是变量引用或字符串常量");
                }
            }
            TypeNode* union_type = new TypeNode;
            union_type->kind = TYPE_STRING_UNION;
            union_type->union_type.string_union = new std::unordered_set<std::string>(values.begin(), values.end());
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            auto it = type_aliases.find(node->data.type_def.name);
            if (it != type_aliases.end()) {
                free_type_node(it->second);
                type_aliases.erase(it);
            }
            type_aliases[type_key(node->data.type_def.name)] = union_type;
            break;
        }
        case NODE_STRUCT_DEF: {
            // ----- 1. 注册结构体类型（原有逻辑） -----
            TypeNode* type = new TypeNode;
            type->kind = TYPE_STRUCT;
            type->struct_type.field_count = node->data.struct_def.field_count;
            type->struct_type.fields = (StructField*)malloc(type->struct_type.field_count * sizeof(StructField));
            for (int i = 0; i < type->struct_type.field_count; i++) {
                type->struct_type.fields[i].name = strdup(node->data.struct_def.fields[i].name);
                type->struct_type.fields[i].type = copy_type_node(node->data.struct_def.fields[i].type);
            }
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            type_aliases[node->data.struct_def.name] = type;
        
            // ----- 2. 生成构造函数（保留并修正） -----
            char* struct_name = node->data.struct_def.name;          // 声明缺失的变量
            int field_count = node->data.struct_def.field_count;
        
            // 2.1 构造参数列表（参数名 = 字段名）
            char** params = (char**)malloc(field_count * sizeof(char*));
            for (int i = 0; i < field_count; i++) {
                params[i] = strdup(node->data.struct_def.fields[i].name);
            }
        
            // 2.2 构造对象字面量：{ field1: param1, field2: param2, ... }
            ASTNode** key_exprs = (ASTNode**)malloc(field_count * sizeof(ASTNode*));
            ASTNode** vals = (ASTNode**)malloc(field_count * sizeof(ASTNode*));
            for (int i = 0; i < field_count; i++) {
                ASTNode* key_node = new_node(NODE_STRING);
                key_node->data.string = strdup(node->data.struct_def.fields[i].name);
                key_exprs[i] = key_node;
                ASTNode* var_node = new_node(NODE_VARIABLE);
                var_node->data.var_name = strdup(node->data.struct_def.fields[i].name);
                vals[i] = var_node;
            }
        
            ASTNode* obj_lit = new_node(NODE_OBJECT_LITERAL);
            obj_lit->data.object_lit.key_exprs = key_exprs;
            obj_lit->data.object_lit.vals = vals;
            obj_lit->data.object_lit.count = field_count;
            obj_lit->data.object_lit.spreads = NULL;
            obj_lit->data.object_lit.spread_count = 0;
        
            // 2.3 构造 return { ... };
            ASTNode* return_node = new_node(NODE_RETURN);
            return_node->data.ret.expr = obj_lit;
        
            // 2.4 构造函数体（块）
            ASTNode* body = new_node(NODE_BLOCK);
            body->data.block.count = 1;
            body->data.block.stmts = (ASTNode**)malloc(sizeof(ASTNode*));
            body->data.block.stmts[0] = return_node;
        
            // 2.5 构造完整的函数定义节点
            ASTNode* func_def = new_node(NODE_FUNC_DEF);              // 声明 func_def
            func_def->data.func_def.name = strdup(struct_name);
            func_def->data.func_def.params = params;
            func_def->data.func_def.param_count = field_count;
            func_def->data.func_def.body = body;
            func_def->data.func_def.is_memoized = false;
            func_def->data.func_def.global_scope = false;   // 跟随当前作用域
            func_def->data.func_def.is_static = false;
            func_def->data.func_def.return_type = copy_type_node(type);
            func_def->data.func_def.vararg_name = NULL;
            func_def->data.func_def.param_is_const = (bool*)malloc(field_count * sizeof(bool));
            for (int i = 0; i < field_count; i++) func_def->data.func_def.param_is_const[i] = false;
            func_def->data.func_def.param_defaults = (ASTNode**)calloc(field_count, sizeof(ASTNode*));
            func_def->data.func_def.param_types = (TypeNode**)malloc(field_count * sizeof(TypeNode*));
            for (int i = 0; i < field_count; i++) {
                func_def->data.func_def.param_types[i] = copy_type_node(node->data.struct_def.fields[i].type);
            }
            func_def->data.func_def.vararg_type = NULL;
            func_def->data.func_def.is_stmt_func = false;
        
            // 2.6 注册函数到作用域（执行函数定义）
            exec_statement(func_def);
            
            // 2.7 标记该函数为“已调用”，避免未调用警告
            //      因为我们知道它是构造器，并非用户显式定义的可执行函数
            std::lock_guard<std::mutex> lock_f(functions_mutex);
            for (int i = 0; i < func_count; ++i) {
                if (functions[i].name && strcmp(functions[i].name, struct_name) == 0) {
                    functions[i].called = true;
                }
            }
        
            // 2.8 释放临时 AST（exec_statement 已复制所需数据，但 func_def 本身的某些数据被复制，释放它不会影响注册的函数）
            free_ast(func_def);
            break;
        }
        case NODE_UNION_DEF: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        
            // ---- (A) 兜底注册 type_aliases ----
            // 通常 parse_complex_type() 已经用 type_key_parse() 注册过；
            // 这里只在缺失时补一份，避免重复注册导致 TypeNode* 泄漏。
            std::string union_qual = type_key(node->data.union_def.name);
            if (type_aliases.find(union_qual) == type_aliases.end()) {
                TypeNode* type = new TypeNode;
                type->kind = TYPE_UNION;
                type->variant_type.variant_count = node->data.union_def.variant_count;
                type->variant_type.variants = (UnionVariant*)malloc(
                    type->variant_type.variant_count * sizeof(UnionVariant));
                for (int i = 0; i < type->variant_type.variant_count; i++) {
                    UnionVariant* sv = &node->data.union_def.variants[i];
                    UnionVariant* dv = &type->variant_type.variants[i];
                    dv->name = strdup(sv->name);
                    dv->param_count = sv->param_count;
                    if (sv->param_count > 0) {
                        dv->param_types = (TypeNode**)malloc(
                            dv->param_count * sizeof(TypeNode*));
                        for (int j = 0; j < dv->param_count; j++)
                            dv->param_types[j] = copy_type_node(sv->param_types[j]);
                        dv->named_fields = NULL;
                        dv->field_count  = 0;
                    } else {
                        dv->param_types  = NULL;
                        dv->field_count  = sv->field_count;
                        if (dv->field_count > 0) {
                            dv->named_fields = (StructField*)malloc(
                                dv->field_count * sizeof(StructField));
                            for (int j = 0; j < dv->field_count; j++) {
                                dv->named_fields[j].name = strdup(sv->named_fields[j].name);
                                dv->named_fields[j].type = copy_type_node(sv->named_fields[j].type);
                            }
                        } else {
                            dv->named_fields = NULL;
                        }
                    }
                }
                type_aliases[union_qual] = type;
            }
        
            // ---- (B) 变体注册：加 umf 前缀 ----
            for (int i = 0; i < node->data.union_def.variant_count; i++) {
                UnionVariant* v = &node->data.union_def.variants[i];
                int count = (v->param_count > 0) ? v->param_count : v->field_count;
                // key:   变体名加前缀，例如 "A::Red"
                // value: 所属 union 的限定名 + 参数个数
                variant_table[type_key(v->name)] = { union_qual, count };
            }
            break;
        }
        case NODE_UMF_IMPORT: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            const char* ns_name = node->data.umf_import.name;
            auto it = named_scopes.find(ns_name);
            if (it == named_scopes.end())
                kr_error("命名空间 '%s' 未定义", ns_name);

            Scope* ns = it->second;
            std::string prefix = std::string(ns_name) + "::";
        
            for (int i = 0; i < ns->var_count; i++) {
                Variable* var = &ns->vars[i];
                // 导入到当前作用域（会覆盖同名变量）
                declare_var(var->name, false, copy_value(var->value));
                int idx = get_var_index_in_scope(current_scope, var->name);
                if (idx >= 0) current_scope->vars[idx].is_read = true;
            }
            auto alias_one = [&](auto& table, const char* kind) {
                // ---- 阶段 1：只读遍历，收集所有 A::X 中的短名 X ----
                std::vector<std::string> short_names;
                for (auto& kv : table) {
                    if (kv.first.size() > prefix.size() &&
                        kv.first.compare(0, prefix.size(), prefix) == 0) {
                        short_names.push_back(kv.first.substr(prefix.size()));
                    }
                }
                // 同一批内去重（例如 A::X 出现在两次循环里）
                std::sort(short_names.begin(), short_names.end());
                short_names.erase(std::unique(short_names.begin(), short_names.end()),
                                  short_names.end());
            
                // ---- 阶段 2：逐个写入（此时遍历已结束，修改 map 是安全的） ----
                for (const auto& sn : short_names) {
                    if (table.count(sn)) {
                        kr_warn("umf %s; 的 %s '%s' 与已有同名项冲突，跳过短名导入",
                                ns_name, kind, sn.c_str());
                        continue;
                    }
                    // 用 at() 拿到 A::X 的值并拷贝进裸名 X 的槽位
                    table.emplace(sn, table.at(prefix + sn));
                }
            };

            alias_one(type_aliases,  "Typalias");
            alias_one(class_table,   "Klasse");
            alias_one(enum_table,    "Enum");
            alias_one(variant_table, "Variante");
            break;
        }
        default:
            kr_error("未知语句类型 %d, 节点地址 %p\n", node->type, (void*)node);
            
     }
 cleanup:
     exec_depth--;
     return ret;
 }