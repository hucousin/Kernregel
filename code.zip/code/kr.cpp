#include "compiler.cpp"

static int utf8_char_width(const char* str, size_t* char_len) {
    unsigned char c = str[0];
    if (c < 0x80) {          // ASCII
        *char_len = 1;
        return 1;
    } else if ((c & 0xE0) == 0xC0) {  // 2字节（多数为拉丁扩展等，宽度1）
        *char_len = 2;
        return 1;
    } else if ((c & 0xF0) == 0xE0) {  // 3字节（包括中日韩、全角符号等）
        *char_len = 3;
        uint32_t code = ((c & 0x0F) << 12) | ((str[1] & 0x3F) << 6) | (str[2] & 0x3F);
        // CJK统一表意文字（常用汉字）
        if ((code >= 0x4E00 && code <= 0x9FFF) ||
            (code >= 0x3400 && code <= 0x4DBF) ||   // 扩展A
            (code >= 0x20000 && code <= 0x2A6DF) || // 扩展B（实际4字节，但此处不处理）
            (code >= 0xFF00 && code <= 0xFFEF) ||   // 全角ASCII
            (code >= 0x3000 && code <= 0x303F) ||   // 中日韩符号
            (code >= 0x3040 && code <= 0x30FF) ||   // 平假名/片假名
            (code >= 0xAC00 && code <= 0xD7AF)) {   // 韩文音节
            return 2;
        }
        // 其他3字节字符（如部分符号、特殊字母）宽度1
        return 1;
    } else if ((c & 0xF8) == 0xF0) {  // 4字节（如Emoji、扩展B汉字等）
        *char_len = 4;
        return 2;
    }
    // fallback
    *char_len = 1;
    return 1;
}

// 计算字符串 s 中 [start_byte, end_byte) 区间的显示宽度（终端列数）
static int display_width(const std::string& s, size_t start_byte, size_t end_byte) {
    int width = 0;
    size_t pos = start_byte;
    while (pos < end_byte && pos < s.size()) {
        size_t char_len;
        width += utf8_char_width(&s[pos], &char_len);
        pos += char_len;
    }
    return width;
}

// 获取某个字节索引在行中的显示列位置（从0开始）
static int byte_to_display_col(const std::string& line, size_t byte_idx) {
    return display_width(line, 0, byte_idx);
}

// 判断是否为分隔符（用于扩展标记范围）
static bool is_delimiter(char c) {
    return isspace(c) ||
           strchr("()[]{},;+-*/%=!<>&|?:#^", c) != nullptr;
}

static std::pair<std::string, size_t> strip_zeile_directive(const std::string& line) {
    size_t pos = line.find("#zeile");
    if (pos == std::string::npos) return {line, 0};
    size_t semicolon = line.find(';', pos);
    size_t end;
    if (semicolon != std::string::npos) {
        end = semicolon + 1;   // 包括分号
    } else {
        end = line.size();     // 到行尾
    }
    size_t removed = end - pos;
    std::string result = line.substr(0, pos) + line.substr(end);
    return {result, removed};
}

// ---------- 显示错误上下文 ----------
static void print_source_context(int line, int col, const char* filename) {
    std::string content;

    std::string safe_filename;
    if (g_last_error_filename && g_last_error_filename[0] != '\0'
        && strcmp(g_last_error_filename, "-") != 0
        && strcmp(g_last_error_filename, "<cmdline>") != 0) {
        safe_filename = g_last_error_filename;
    } else if (filename && filename[0] != '\0'
        && strcmp(filename, "-") != 0
        && strcmp(filename, "<cmdline>") != 0) {
        safe_filename = filename;
    }
    if (safe_filename.empty()) {
        const char* f2 = find_filename_by_line_col(line, col);
        if (f2 && f2[0] != '\0') safe_filename = f2;
    }
    if (safe_filename.empty()) safe_filename = current_filename ? current_filename : "";
    if (safe_filename.empty() || safe_filename == "-" || safe_filename == "<cmdline>") {
        return;
    }

    // 从 safe_filename 读取（此时是安全的 std::string）
    if (!g_custom_source_context.empty()) {
        content = g_custom_source_context;
    } else {
        std::ifstream ifs(safe_filename);
        if (!ifs) return;
        ifs.seekg(0, std::ios::end);
        size_t len = ifs.tellg();
        ifs.seekg(0);
        content.resize(len);
        ifs.read(&content[0], len);
        ifs.close();
        if (content.empty()) return;
    }

    // 分割行
    std::vector<std::string> lines;
    const char* p = content.c_str();
    while (*p) {
        const char* start = p;
        while (*p && *p != '\n') p++;
        lines.emplace_back(start, p - start);
        if (*p == '\n') p++;
    }
    int total_lines = (int)lines.size();
    if (total_lines == 0) return;

    // 若行号超出，则修正为文件末尾
    if (line > total_lines) {
        line = total_lines;
        // 可输出警告，但可选
    }
    if (line <= 0) line = 1;

    // 显示上下文
    int start_line = std::max(1, line - g_context_before);
    int end_line   = std::min(total_lines, line + g_context_after);

    fprintf(stderr, "\n\033[93m----------------------\nKernregel v%d.%d.%d\n----------------------\033[0m", MAJOR, MINOR, PATCH);
    fprintf(stderr, "\n\033[33m--- Fehler (In der Nähe von Zeile %d) ---\033[0m\n", line);

    for (int i = start_line; i <= end_line; i++) {
        std::string original_line = lines[i-1];
        auto [clean_line, removed] = strip_zeile_directive(original_line);
        std::string display_line = clean_line;

        if (i == line) {
            int token_start_byte = -1, token_end_byte = -1;
            int adjusted_col = col;
            if (col > 0 && removed > 0) {
                if (col > (int)removed)
                    adjusted_col = col - removed;
                else
                    adjusted_col = col;
            }
            if (adjusted_col > 0 && adjusted_col <= (int)clean_line.length()) {
                int idx = adjusted_col - 1;
                int start = idx, end = idx;
                while (start > 0 && !is_delimiter(clean_line[start-1])) start--;
                while (end < (int)clean_line.length() && !is_delimiter(clean_line[end])) end++;
                if (start == end) {
                    start = idx;
                    end = (int)clean_line.length();
                    if (end - start > 30) end = start + 30;
                }
                token_start_byte = start;
                token_end_byte = end;
                if (token_start_byte < token_end_byte) {
                    std::string before = display_line.substr(0, token_start_byte);
                    std::string token = display_line.substr(token_start_byte, token_end_byte - token_start_byte);
                    std::string after = display_line.substr(token_end_byte);
                    display_line = before + "\033[31m" + token + "\033[0m" + after;
                }
            }

            fprintf(stderr, ">>> %4d: %s\n", i, display_line.c_str());
            if (token_start_byte != -1 && token_end_byte != -1 && token_start_byte < token_end_byte) {
                int display_start = byte_to_display_col(display_line, token_start_byte);
                int display_end   = byte_to_display_col(display_line, token_end_byte);
                int token_width   = display_end - display_start;
                std::string tilde_line;
                tilde_line.reserve(display_start + token_width);
                tilde_line.append(display_start, ' ');
                tilde_line.append(token_width, '~');
                fprintf(stderr, "          \033[31m%s\033[0m\n", tilde_line.c_str());
            }
        } else {
            fprintf(stderr, "    %4d: %s\n", i, display_line.c_str());
        }
    }
    fprintf(stderr, "\033[33m--- Ende der Kontext ---\033[0m\n");
}

// 全局清理函数（幂等，可多次调用）
void kr_cleanup() {
    for (auto& pair : rule_states) {
        if (pair.second) {
            pair.second->running = false;   // 让线程自己退出循环
        }
    }
    {
        std::lock_guard<std::mutex> lock(g_key_listener_mutex);
        for (auto& pair : g_key_listeners) {
            if (pair.second.joinable()) {
                pair.second.detach();       // 分离后线程不再阻塞进程退出
            }
        }
    }
    fflush(stdout);
    fflush(stderr);
    {
        std::lock_guard<std::mutex> lock(future_map_mutex);
        future_map.clear();
    }
}

// 计算 Levenshtein 距离（编辑距离）
static int levenshtein(const std::string& s1, const std::string& s2) {
    const size_t m = s1.size(), n = s2.size();
    std::vector<size_t> prev(n + 1), curr(n + 1);
    for (size_t i = 0; i <= n; ++i) prev[i] = i;
    for (size_t i = 1; i <= m; ++i) {
        curr[0] = i;
        for (size_t j = 1; j <= n; ++j) {
            int cost = (s1[i-1] == s2[j-1]) ? 0 : 1;
            curr[j] = std::min({ prev[j] + 1, curr[j-1] + 1, prev[j-1] + cost });
        }
        prev.swap(curr);
    }
    return (int)prev[n];
}

// 沿继承链查找静态方法（返回 MethodDef 指针，若找到则同时传出所属类名）
static MethodDef* find_static_method(const std::string& class_name,
                                     const std::string& method_name,
                                     std::string* found_class) {
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    std::string cur = class_name;
    while (!cur.empty()) {
        auto it = class_table.find(cur);
        if (it == class_table.end()) break;
        auto meth_it = it->second.methods.find(method_name);
        if (meth_it != it->second.methods.end()) {
            if (meth_it->second.is_static) {
                if (found_class) *found_class = cur;
                return &meth_it->second;
            }
        }
        cur = it->second.parent;
    }
    return nullptr;
}

// 生成修正建议
static std::string suggest_correction(const std::string& name) {
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        for (const auto& pair : named_scopes) {
            Scope* ns = pair.second;
            if (!ns) continue;
            int idx = get_var_index_in_scope(ns, name.c_str());
            if (idx >= 0) {
                Variable* var = &ns->vars[idx];
                const char* kind = (var->value.type == VAL_FUNCTION) ? "函数" : "变量";
                return std::string(kind) + " '" + name + "' 已在命名作用域 '" +
                       pair.first + "' 中定义。\n"
                       "  请先导入:  umf " + pair.first + ";\n"
                       "  或限定调用: " + pair.first + "." + name + "(...)";
            }
        }
    }
    // ---------- 精确映射（常见错误 -> 正确 Kernregel 关键字） ----------
    static const std::unordered_map<std::string, std::string> exact_map = {
        {"and", "und"},
        {"or", "od"},
        {"not", "nich"},
        {"nicht", "nich"},
        {"oder", "od"},
        // 控制流
        {"if", "fa"},
        {"falls", "fa"},
        {"wenn", "fa"},
        {"else", "sonst"},
        {"elif", "snfa"},
        {"while", "indes"},
        {"solange", "indes"},
        {"do", "tu"},
        {"for", "für"},
        {"foreach", "für jedes"},
        {"break", "bruch"},
        {"continue", "weiter"},
        {"return", "gib"},
        {"try", "ver"},
        {"catch", "den"},
        {"finally", "die"},
        {"throw", "dem"},
        // 变量与类型
        {"var", "der"},
        {"let", "das"},
        {"const", "das"},
        {"alias", "des"},
        {"type", "art"},
        {"enum", "aufz"},
        {"class", "klass"},
        {"new", "neu"},
        {"this", "dies"},
        {"super", "ober"},
        // 函数定义
        {"function", "fkt"},
        {"async", "ac"},
        // 布尔与空
        {"true", "wahr"},
        {"false", "fals"},
        {"NULL", "null"},
        {"None", "null"},
        // 输入输出
        {"print", "zeig"},
        {"println", "zeig"},
        {"input", "lies"},
        {"read", "lese"},
        // 其他
        {"import", "imp"},
        {"lazy", "faul"},
        {"static", "stati"},
        {"await", "warte"},
        {"match", "als"},
    };
    auto it_exact = exact_map.find(name);
    if (it_exact != exact_map.end()) {
        return "Meinten Sie '" + it_exact->second + "'? (Kernregel-Schlüsselwort)";
    }

    // 长度 < 3 不进行模糊匹配
    if (name.length() < 3) return "";

    // ---- 收集所有用户定义的变量（当前可见作用域） ----
    std::unordered_set<std::string> user_vars;
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        Scope* s = current_scope;
        while (s) {
            for (int i = 0; i < s->var_count; ++i) {
                user_vars.insert(s->vars[i].name);
            }
            if (s == original_global_scope) break;
            s = s->parent;
        }
        if (!current_scope && original_global_scope) {
            for (int i = 0; i < original_global_scope->var_count; ++i) {
                user_vars.insert(original_global_scope->vars[i].name);
            }
        }
    }

    // ---- 收集用户定义的函数名 ----
    std::unordered_set<std::string> user_funcs;
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        for (int i = 0; i < func_count; ++i) {
            if (functions[i].name) user_funcs.insert(functions[i].name);
        }
    }

    // 合并用户定义
    std::unordered_set<std::string> user_defs = user_vars;
    user_defs.insert(user_funcs.begin(), user_funcs.end());
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        for (const auto& pair : class_table) user_defs.insert(strip_umf_prefix(pair.first));
        for (const auto& pair : enum_table)  user_defs.insert(strip_umf_prefix(pair.first));
        for (const auto& pair : type_aliases) user_defs.insert(strip_umf_prefix(pair.first));
        for (const auto& pair : variant_table) user_defs.insert(strip_umf_prefix(pair.first));
    }

    // ---- 构建候选集 ----
    std::unordered_set<std::string> candidates;
    for (const auto& pair : type_aliases) candidates.insert(strip_umf_prefix(pair.first));
    for (const auto& pair : variant_table) candidates.insert(strip_umf_prefix(pair.first));
    for (const auto& pair : class_table)   candidates.insert(strip_umf_prefix(pair.first));
    for (const auto& pair : enum_table)    candidates.insert(strip_umf_prefix(pair.first));

    // 1. 关键字
    const char* keywords[] = {
        "der", "das", "ist", "zeig", "schr", "fa", "snfa", "sonst", "indes", "tu",
        "fkt", "lies", "gib", "art", "null", "wahr", "fals", "für", "bruch",
        "ver", "den", "die", "dem", "jedes", "in", "faul", "dies", "imp", "as",
        "weiter", "aufz", "als", "warte", "kernregel", "global", "des",
        "bind", "klass", "erbt", "konstr", "methode", "privat", "öffent", "schutz", "neu", "ober", "bei", "sch",
        "stati", "sicher", "NICH", "nich"
    };
    for (const auto& kw : keywords) candidates.insert(kw);

    // 2. 内置函数
    const char* builtins[] = {
        // ===== 全局函数 =====
        // 数学
        "sqrt", "wurz", "cbrt", "kub", "abs", "btr",
        "sin", "cos", "tan", "tg", "cot", "ctg", "sec", "csc",
        "asin", "acos", "atan", "atan2",
        "sinh", "cosh", "tanh", "asinh", "acosh", "atanh",
        "rand", "zuf", "srand", "setze",
        "exp", "ln", "log", "lg", "ld",
        // 微积分
        "abl", "inte", "ab2", "simp", "grad", "nullst", "euler",
        "pabl", "ab3", "ab4", "rk", "newton", "gradab", "kquad", "gauss",
        // 文件与字符串
        "leseDatei", "lese", "leseBin", "schrd",
        "trim", "ersetze", "ers", "teil", "entfal",
        "enthält", "hat", "fängtAnMit", "beg",
        "abschnitt", "ab", "stelleVon", "wo",
        "letzteStelleVon", "letzt",
        "alsZahl", "alz", "alsText", "alt", "alsArray", "ala",
        "format", "groß",
        // 时间系统
        "sleep", "zeit", "zeit_us", "zeit_ms", "zeit_ns",
        "tick", "tock", "tock_ms", "tock_s",
        "datum", "loesch", "aktu", "zeigAlle",
        // 按键
        "drücke", "taste", "ac_taste", "taste_gedrueckt", "taste_g",
        // 进程网络
        "ausf", "ausführen", "BC", "ac_ausf","lauf","ac_lauf","aufgT","aufgTöten","aufgAnf",
        "ANFR", "ac_ANFR", "starteServer", "ac_starteServer", "text","json","html","umleiten","abfrage","formular","esc",
        "holeIP",
        "kodierURL","dekodierURL",
        // KD数据集
        "ladeKD", "schrKD", "erneuKD", "loesKD",
        "suchKD", "siebeKD", "alleKD", "zaehleKD",
        "verschlKD", "entschlKD",
        // JSON
        "jsonzu", "zujson",
        // 调试元编程
        "KRFehl", "KRWarn", "KRKom",
        "typist", "tokens", "worte", "zeile", "line",
        "ende", "exit", "bytes", "umbytes", "kodierBase64",
        // 命名作用域
        "umf",
    
        "keine", "typ", "leer", "gtyp", "leeren",
        "istZahl", "entferne", "anfang", "rechts",
        "mittel", "produkt", "erstes", "einfuegen",
        "vereinige", "schnitt", "differenz", "mische",
        "kopiere",
    
        // 字符串方法
        "passende", "pass",
        "ersetze", "ers",      // 已在全局，但保留无妨
        "teil",                // 已在全局
        "enthält", "hat",
        "fängtAnMit", "beg",
        "abschnitt", "ab",
        "stelleVon", "wo",
        "letzteStelleVon", "letzt",
        "trim",
        "alsZahl", "alz",
        "alsText", "alt",
        "län",
        "groß", "klein",
        "umkehren", "umk",
        "zähle",
        "ohneAnfang",
        "ohneEnde",
        "füll",
        "endetMit",
        "wieder",
        "zeich",
        "istZiffer", "istBuchstabe",
        "istAlnum", "istRaum",
        "istGroß","istKlein",
    
        // 数组方法
        "hinzufügen", "anf",
        "finde",
        "findeIndex", "idx",
        "lösch",
        "map",
        "filter",
        "reduz",
        "beit",
        "zufall", "random",
        "zufWert", "randomValue",
        "sort",
        "unique",
        "hat",          // 已在字符串，但数组也有
        "alle",
        "max", "min", "sum",
        
        "jeden", "manche", "keiner", "zähl", "grupp",
        "partit", "erste", "flach", "nehmen", "fallen", "zip",
    
        // 数字方法（含重复）
        "runden",
    
        // 对象方法
        "schl", "keys",
        "werts", "values",
        "eintr", "entries",
    
        // KD数据集方法
        "hole",
        "sucheTag",
        "sucheTyp",
        "kinder",
        "komprim",
    
        // 规则句柄方法
        "wert",
        "setZweck",
        "stop",

        // 其他
        "cpp",
        "asm",
        
        // 指针
        "zgr", "schlau", "zgrw", "zgrs",
        "frei", "zgrNull",
        "zeigIn","schrIn"
    };
    for (const auto& fn : builtins) candidates.insert(fn);

    // 3. 用户函数和变量（已包含在 user_defs）
    candidates.insert(user_funcs.begin(), user_funcs.end());
    candidates.insert(user_vars.begin(), user_vars.end());

    // 4. 类型别名
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        for (const auto& pair : type_aliases) {
            candidates.insert(pair.first);
        }
    }

    // 5. 枚举变体
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        for (const auto& pair : variant_table) {
            candidates.insert(pair.first);
        }
    }

    // 6. 类名
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        for (const auto& pair : class_table) {
            candidates.insert(pair.first);
        }
    }

    if (candidates.empty()) return "";

    // ---- 相似度阈值 60% ----
    const double SIMILARITY_THRESHOLD = 0.6;
    double best_sim = -1.0;
    std::string best_match;
    bool best_is_user = false;

    for (const auto& cand : candidates) {
        int dist = levenshtein(name, cand);
        int max_len = std::max(name.length(), cand.length());
        if (max_len == 0) continue;
        double sim = 1.0 - static_cast<double>(dist) / max_len;
        if (sim < SIMILARITY_THRESHOLD) continue;

        bool is_user = (user_defs.find(cand) != user_defs.end());
        // 选择相似度最高的，若相同则优先用户定义
        if (sim > best_sim || (sim == best_sim && is_user && !best_is_user)) {
            best_sim = sim;
            best_match = cand;
            best_is_user = is_user;
        }
    }

    if (!best_match.empty()) {
        std::string label;
        // 1. 检查关键字
        for (const auto& kw : keywords) {
            if (best_match == kw) {
                label = "Kernregel-Schlüsselwort";
                break;
            }
        }
        // 2. 检查内置函数
        if (label.empty()) {
            for (const auto& fn : builtins) {
                if (best_match == fn) {
                    label = "eingebaute Funktion";
                    break;
                }
            }
        }
        // 3. 检查用户定义的类型（类、枚举、类型别名、枚举变体）
        if (label.empty()) {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            if (type_aliases.find(best_match) != type_aliases.end()) {
                label = "Typalias";
            } else if (variant_table.find(best_match) != variant_table.end()) {
                label = "Enum-Variante";
            } else if (class_table.find(best_match) != class_table.end()) {
                label = "Klasse";
            } else if (enum_table.find(best_match) != enum_table.end()) {
                label = "Enum";
            }
        }
    
        if (!label.empty()) {
            return "Meinten Sie '" + best_match + "'? (" + label + ")";
        } else {
            return "Meinten Sie '" + best_match + "'?";
        }
    }
    return "";
}

// 只读遍历 AST 所有节点（不修改结构）
static void walk_ast(ASTNode* node, std::function<void(ASTNode*)> visit) {
    if (!node) return;
    visit(node);
    switch (node->type) {
        case NODE_PROGRAM:
        case NODE_BLOCK:
        case NODE_SCOPE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            for (int i = 0; i < node->data.block.count; i++) {
                walk_ast(node->data.block.stmts[i], visit);
            }
            break;

        case NODE_VAR_DECL:
            walk_ast(node->data.var_decl.expr, visit);
            break;

        case NODE_ASSIGN:
            walk_ast(node->data.assign.expr, visit);
            break;

        case NODE_PRINT:
        case NODE_PRINT_NO_NEWLINE:
            walk_ast(node->data.print.expr, visit);
            break;

        case NODE_PRINT_WITH_LINE:
            walk_ast(node->data.print_with_line.expr, visit);
            walk_ast(node->data.print_with_line.line, visit);
            break;

        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI:
            for (int i = 0; i < node->data.print_multi.count; i++) {
                walk_ast(node->data.print_multi.exprs[i], visit);
            }
            break;

        case NODE_INPUT:
            for (int i = 0; i < node->data.input.arg_count; i++) {
                walk_ast(node->data.input.args[i], visit);
            }
            walk_ast(node->data.input.multiline_expr, visit);
            break;

        case NODE_IF:
            walk_ast(node->data.if_stmt.cond, visit);
            walk_ast(node->data.if_stmt.then_block, visit);
            for (int i = 0; i < node->data.if_stmt.else_if_count; i++) {
                walk_ast(node->data.if_stmt.else_ifs[i], visit);
            }
            walk_ast(node->data.if_stmt.else_block, visit);
            break;

        case NODE_WHILE:
            walk_ast(node->data.while_stmt.cond, visit);
            walk_ast(node->data.while_stmt.body, visit);
            break;

        case NODE_DO_WHILE:
            walk_ast(node->data.do_while.body, visit);
            walk_ast(node->data.do_while.cond, visit);
            break;

        case NODE_FOR:
            walk_ast(node->data.for_stmt.init, visit);
            walk_ast(node->data.for_stmt.cond, visit);
            walk_ast(node->data.for_stmt.update, visit);
            walk_ast(node->data.for_stmt.body, visit);
            break;

        case NODE_FOREACH:
            walk_ast(node->data.foreach.collection, visit);
            walk_ast(node->data.foreach.body, visit);
            break;

        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF:
            for (int i = 0; i < node->data.func_def.param_count; i++) {
                walk_ast(node->data.func_def.param_defaults[i], visit);
            }
            walk_ast(node->data.func_def.body, visit);
            break;

        case NODE_FUNC_CALL:
            walk_ast(node->data.func_call.func_expr, visit);
            for (int i = 0; i < node->data.func_call.arg_count; i++) {
                walk_ast(node->data.func_call.args[i], visit);
            }
            break;

        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT:
        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT:
            walk_ast(node->data.binary.left, visit);
            walk_ast(node->data.binary.right, visit);
            break;

        case NODE_RETURN:
            walk_ast(node->data.ret.expr, visit);
            break;

        case NODE_ARRAY_LITERAL:
            for (int i = 0; i < node->data.array_lit.count; i++) {
                walk_ast(node->data.array_lit.elems[i], visit);
            }
            break;

        case NODE_ARRAY_ACCESS:
            walk_ast(node->data.array_access.array, visit);
            walk_ast(node->data.array_access.index, visit);
            break;

        case NODE_ARRAY_LEN:
            walk_ast(node->data.array_len.array, visit);
            break;

        case NODE_STRING_ACCESS:
            walk_ast(node->data.string_access.str, visit);
            walk_ast(node->data.string_access.index, visit);
            break;

        case NODE_STRING_LEN:
            walk_ast(node->data.string_len.str, visit);
            break;

        case NODE_NOT:
            walk_ast(node->data.not_expr.expr, visit);
            break;

        case NODE_LOGICAL_AND:
            walk_ast(node->data.logical_and.left, visit);
            walk_ast(node->data.logical_and.right, visit);
            break;

        case NODE_LOGICAL_OR:
            walk_ast(node->data.logical_or.left, visit);
            walk_ast(node->data.logical_or.right, visit);
            break;

        case NODE_ARRAY_ASSIGN:
            walk_ast(node->data.array_assign.left, visit);
            walk_ast(node->data.array_assign.index, visit);
            walk_ast(node->data.array_assign.expr, visit);
            break;

        case NODE_METHOD_CALL:
            walk_ast(node->data.method_call.obj, visit);
            for (int i = 0; i < node->data.method_call.arg_count; i++) {
                walk_ast(node->data.method_call.args[i], visit);
            }
            break;

        case NODE_EXPR_STMT:
            walk_ast(node->data.expr_stmt.expr, visit);
            break;

        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
        case NODE_DOUBLE_FACTORIAL:
        case NODE_BITWISE_NOT:
            walk_ast(node->data.inc_dec.operand, visit);
            break;

        case NODE_TERNARY:
            walk_ast(node->data.ternary.cond, visit);
            walk_ast(node->data.ternary.true_expr, visit);
            walk_ast(node->data.ternary.false_expr, visit);
            break;

        case NODE_ARRAY_COMPOUND_ASSIGN:
            walk_ast(node->data.array_compound_assign.left, visit);
            walk_ast(node->data.array_compound_assign.index, visit);
            walk_ast(node->data.array_compound_assign.rhs, visit);
            break;

        case NODE_TRY:
            walk_ast(node->data.try_stmt.try_body, visit);
            walk_ast(node->data.try_stmt.catch_body, visit);
            walk_ast(node->data.try_stmt.finally_body, visit);
            break;

        case NODE_THROW:
            walk_ast(node->data.throw_expr.expr, visit);
            break;

        case NODE_OBJECT_LITERAL:
            for (int i = 0; i < node->data.object_lit.count; i++) {
                walk_ast(node->data.object_lit.key_exprs[i], visit);
                walk_ast(node->data.object_lit.vals[i], visit);
            }
            for (int i = 0; i < node->data.object_lit.spread_count; i++) {
                walk_ast(node->data.object_lit.spreads[i], visit);
            }
            break;

        case NODE_OBJECT_ACCESS:
            walk_ast(node->data.object_access.obj, visit);
            break;

        case NODE_OBJECT_ASSIGN:
            walk_ast(node->data.object_assign.obj, visit);
            walk_ast(node->data.object_assign.value, visit);
            break;

        case NODE_OBJECT_COMPOUND_ASSIGN:
            walk_ast(node->data.object_compound_assign.obj, visit);
            walk_ast(node->data.object_compound_assign.rhs, visit);
            break;

        case NODE_NULL_COALESCE:
            walk_ast(node->data.null_coalesce.left, visit);
            walk_ast(node->data.null_coalesce.right, visit);
            break;

        case NODE_PIPE:
            walk_ast(node->data.pipe.left, visit);
            walk_ast(node->data.pipe.right, visit);
            break;

        case NODE_RANGE:
            walk_ast(node->data.range.start, visit);
            walk_ast(node->data.range.end, visit);
            walk_ast(node->data.range.step, visit);
            break;

        case NODE_LIST_COMPREHENSION:
            walk_ast(node->data.list_comp.expr, visit);
            walk_ast(node->data.list_comp.collection, visit);
            walk_ast(node->data.list_comp.cond, visit);
            break;

        case NODE_OBJECT_COMPREHENSION:
            walk_ast(node->data.object_comp.key_expr, visit);
            walk_ast(node->data.object_comp.value_expr, visit);
            walk_ast(node->data.object_comp.collection, visit);
            walk_ast(node->data.object_comp.cond, visit);
            break;

        case NODE_LAZY_VAR_DECL:
            walk_ast(node->data.lazy_var_decl.expr, visit);
            break;

        case NODE_SICHER:
            walk_ast(node->data.sicher.expr, visit);
            walk_ast(node->data.sicher.msg_expr, visit);
            break;

        case NODE_SWAP_ASSIGN:
            walk_ast(node->data.swap.left, visit);
            walk_ast(node->data.swap.right, visit);
            break;

        case NODE_MATCH:
            walk_ast(node->data.match.expr, visit);
            for (int i = 0; i < node->data.match.branch_count; i++) {
                walk_ast(node->data.match.branches[i].pattern, visit);
                walk_ast(node->data.match.branches[i].guard, visit);
                walk_ast(node->data.match.branches[i].body, visit);
            }
            break;

        case NODE_PATTERN_OR:
            for (int i = 0; i < node->data.pattern_or.count; i++) {
                walk_ast(node->data.pattern_or.patterns[i], visit);
            }
            break;

        case NODE_AWAIT:
            walk_ast(node->data.await.expr, visit);
            walk_ast(node->data.await.timeout, visit);
            walk_ast(node->data.await.fallback, visit);
            break;

        case NODE_KEY_BIND:
            walk_ast(node->data.key_bind.body, visit);
            break;

        case NODE_DESTRUCTURE:
        case NODE_DESTRUCTURE_ASSIGN:
            walk_ast(node->data.destructure.expr, visit);
            break;

        case NODE_CLASS_DEF:
            walk_ast(node->data.class_def.ctor_body, visit);
            for (int i = 0; i < node->data.class_def.methods.count; i++) {
                walk_ast(node->data.class_def.methods.bodies[i], visit);
            }
            for (int i = 0; i < node->data.class_def.properties.count; i++) {
                walk_ast(node->data.class_def.properties.default_exprs[i], visit);
            }
            break;

        case NODE_NEW:
            for (int i = 0; i < node->data.new_expr.arg_count; i++) {
                walk_ast(node->data.new_expr.args[i], visit);
            }
            break;

        case NODE_SUPER_CALL:
            for (int i = 0; i < node->data.super_call.arg_count; i++) {
                walk_ast(node->data.super_call.args[i], visit);
            }
            break;

        case NODE_UMF_DEF:
            walk_ast(node->data.umf_def.body, visit);
            break;

        case NODE_MULTI_ASSIGN:
            for (int i = 0; i < node->data.multi_assign.right_count; i++) {
                walk_ast(node->data.multi_assign.right_exprs[i], visit);
            }
            break;

        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            walk_ast(node->data.spread.expr, visit);
            break;

        case NODE_STRING_INTERP:
            for (int i = 0; i < node->data.string_interp.count; i++) {
                walk_ast(node->data.string_interp.fragments[i], visit);
            }
            break;

        case NODE_TYPE_DEF:
            for (int i = 0; i < node->data.type_def.member_count; i++) {
                walk_ast(node->data.type_def.members[i], visit);
            }
            break;

        default:
            break;
    }
}

static void check_type_refs(TypeNode* t, int line, int col,
                            const std::unordered_set<std::string>& known_types) {
    if (!t) return;
    switch (t->kind) {
        case TYPE_ALIAS: {
            const char* name = t->alias_type.name;
            if (!name || !*name) return;
            // 内建类型 (zahl/gzl/kzl/zkt/bool/einz/leer) 在 parse_type_expr 阶段
            // 就被识别为对应 kind，永远不会进入 TYPE_ALIAS。
            // 所以此处一定是用户定义的类型别名 / 类 / 枚举 / 结构体 / 联合。
            if (!known_types.count(name)) {
                g_last_error_line = line;
                g_last_error_col  = col;
                std::string hint = suggest_correction(name);
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "未定义的类型 '%s'", name);
            }
            break;
        }
        case TYPE_ARRAY:
            check_type_refs(t->array_type.elem_type, line, col, known_types);
            break;
        case TYPE_OBJECT:
            for (int i = 0; i < t->object_type.count; i++)
                check_type_refs(t->object_type.types[i], line, col, known_types);
            break;
        case TYPE_FUNCTION:
            for (int i = 0; i < t->func_type.param_count; i++)
                check_type_refs(t->func_type.param_types[i], line, col, known_types);
            check_type_refs(t->func_type.ret_type, line, col, known_types);
            break;
        case TYPE_OPTIONAL:
            check_type_refs(t->optional_type.inner_type, line, col, known_types);
            break;
        case TYPE_STRUCT:
            for (int i = 0; i < t->struct_type.field_count; i++)
                check_type_refs(t->struct_type.fields[i].type, line, col, known_types);
            break;
        case TYPE_UNION:
            for (int i = 0; i < t->variant_type.variant_count; i++) {
                UnionVariant* v = &t->variant_type.variants[i];
                for (int j = 0; j < v->param_count; j++)
                    check_type_refs(v->param_types[j], line, col, known_types);
                for (int j = 0; j < v->field_count; j++)
                    check_type_refs(v->named_fields[j].type, line, col, known_types);
            }
            break;
        default:
            break;
    }
}

// 沿继承链收集类成员：实例成员、静态成员
static void collect_class_members_recursive(
    const std::string& cls_name,
    const std::unordered_map<std::string, ASTNode*>& class_ast_map,
    std::unordered_set<std::string>& instance_out,
    std::unordered_set<std::string>& static_out,
    std::unordered_set<std::string>& visited)
{
if (cls_name.empty() || visited.count(cls_name)) return;
visited.insert(cls_name);

auto it = class_ast_map.find(cls_name);
if (it == class_ast_map.end()) return;
ASTNode* cls = it->second;

// 属性
for (int i = 0; i < cls->data.class_def.properties.count; ++i) {
    const char* nm = cls->data.class_def.properties.names[i];
    if (!nm) continue;
    if (cls->data.class_def.properties.is_static[i])
        static_out.insert(nm);
    else
        instance_out.insert(nm);
}
// 方法
for (int i = 0; i < cls->data.class_def.methods.count; ++i) {
    const char* nm = cls->data.class_def.methods.names[i];
    if (!nm) continue;
    if (cls->data.class_def.methods.is_static[i])
        static_out.insert(nm);
    else
        instance_out.insert(nm);
}

// 父类
if (cls->data.class_def.parent)
    collect_class_members_recursive(cls->data.class_def.parent,
                                     class_ast_map,
                                     instance_out, static_out, visited);
}

// 深度优先遍历，但跳过嵌套类定义（它们有独立成员上下文）
static void walk_body_skip_nested_classes(ASTNode* n,
                                      std::function<void(ASTNode*)> visit)
{
if (!n) return;
if (n->type == NODE_CLASS_DEF) return;   // 不进入嵌套类
visit(n);

// 递归子节点（与 walk_ast 的结构保持一致，但类定义已在上面 return）
switch (n->type) {
    case NODE_PROGRAM:
    case NODE_BLOCK:
    case NODE_SCOPE_BLOCK:
    case NODE_GLOBAL_BLOCK:
        for (int i = 0; i < n->data.block.count; ++i)
            walk_body_skip_nested_classes(n->data.block.stmts[i], visit);
        return;
    case NODE_VAR_DECL:
        walk_body_skip_nested_classes(n->data.var_decl.expr, visit); return;
    case NODE_ASSIGN:
        walk_body_skip_nested_classes(n->data.assign.expr, visit); return;
    case NODE_PRINT:
    case NODE_PRINT_NO_NEWLINE:
        walk_body_skip_nested_classes(n->data.print.expr, visit); return;
    case NODE_PRINT_WITH_LINE:
        walk_body_skip_nested_classes(n->data.print_with_line.expr, visit);
        walk_body_skip_nested_classes(n->data.print_with_line.line, visit); return;
    case NODE_PRINT_MULTI:
    case NODE_PRINT_NO_NEWLINE_MULTI:
        for (int i = 0; i < n->data.print_multi.count; ++i)
            walk_body_skip_nested_classes(n->data.print_multi.exprs[i], visit);
        return;
    case NODE_INPUT:
        for (int i = 0; i < n->data.input.arg_count; ++i)
            walk_body_skip_nested_classes(n->data.input.args[i], visit);
        walk_body_skip_nested_classes(n->data.input.multiline_expr, visit); return;
    case NODE_IF:
        walk_body_skip_nested_classes(n->data.if_stmt.cond, visit);
        walk_body_skip_nested_classes(n->data.if_stmt.then_block, visit);
        for (int i = 0; i < n->data.if_stmt.else_if_count; ++i)
            walk_body_skip_nested_classes(n->data.if_stmt.else_ifs[i], visit);
        walk_body_skip_nested_classes(n->data.if_stmt.else_block, visit); return;
    case NODE_WHILE:
        walk_body_skip_nested_classes(n->data.while_stmt.cond, visit);
        walk_body_skip_nested_classes(n->data.while_stmt.body, visit); return;
    case NODE_DO_WHILE:
        walk_body_skip_nested_classes(n->data.do_while.body, visit);
        walk_body_skip_nested_classes(n->data.do_while.cond, visit); return;
    case NODE_FOR:
        walk_body_skip_nested_classes(n->data.for_stmt.init, visit);
        walk_body_skip_nested_classes(n->data.for_stmt.cond, visit);
        walk_body_skip_nested_classes(n->data.for_stmt.update, visit);
        walk_body_skip_nested_classes(n->data.for_stmt.body, visit); return;
    case NODE_FOREACH:
        walk_body_skip_nested_classes(n->data.foreach.collection, visit);
        walk_body_skip_nested_classes(n->data.foreach.body, visit); return;
    case NODE_RETURN:
        walk_body_skip_nested_classes(n->data.ret.expr, visit); return;
    case NODE_EXPR_STMT:
        walk_body_skip_nested_classes(n->data.expr_stmt.expr, visit); return;
    case NODE_TRY:
        walk_body_skip_nested_classes(n->data.try_stmt.try_body, visit);
        walk_body_skip_nested_classes(n->data.try_stmt.catch_body, visit);
        walk_body_skip_nested_classes(n->data.try_stmt.finally_body, visit); return;
    case NODE_THROW:
        walk_body_skip_nested_classes(n->data.throw_expr.expr, visit); return;
    case NODE_ARRAY_LITERAL:
        for (int i = 0; i < n->data.array_lit.count; ++i)
            walk_body_skip_nested_classes(n->data.array_lit.elems[i], visit);
        return;
    case NODE_ARRAY_ACCESS:
        walk_body_skip_nested_classes(n->data.array_access.array, visit);
        walk_body_skip_nested_classes(n->data.array_access.index, visit); return;
    case NODE_ARRAY_LEN:
        walk_body_skip_nested_classes(n->data.array_len.array, visit); return;
    case NODE_STRING_ACCESS:
        walk_body_skip_nested_classes(n->data.string_access.str, visit);
        walk_body_skip_nested_classes(n->data.string_access.index, visit); return;
    case NODE_STRING_LEN:
        walk_body_skip_nested_classes(n->data.string_len.str, visit); return;
    case NODE_NOT:
        walk_body_skip_nested_classes(n->data.not_expr.expr, visit); return;
    case NODE_LOGICAL_AND:
        walk_body_skip_nested_classes(n->data.logical_and.left, visit);
        walk_body_skip_nested_classes(n->data.logical_and.right, visit); return;
    case NODE_LOGICAL_OR:
        walk_body_skip_nested_classes(n->data.logical_or.left, visit);
        walk_body_skip_nested_classes(n->data.logical_or.right, visit); return;
    case NODE_ARRAY_ASSIGN:
        walk_body_skip_nested_classes(n->data.array_assign.left, visit);
        walk_body_skip_nested_classes(n->data.array_assign.index, visit);
        walk_body_skip_nested_classes(n->data.array_assign.expr, visit); return;
    case NODE_ARRAY_COMPOUND_ASSIGN:
        walk_body_skip_nested_classes(n->data.array_compound_assign.left, visit);
        walk_body_skip_nested_classes(n->data.array_compound_assign.index, visit);
        walk_body_skip_nested_classes(n->data.array_compound_assign.rhs, visit); return;
    case NODE_BINARY:
    case NODE_CMP_THREE_WAY:
    case NODE_CONCAT:
    case NODE_BITWISE_OR:
    case NODE_BITWISE_AND:
    case NODE_SHIFT_LEFT:
    case NODE_SHIFT_RIGHT:
        walk_body_skip_nested_classes(n->data.binary.left, visit);
        walk_body_skip_nested_classes(n->data.binary.right, visit); return;
    case NODE_TERNARY:
        walk_body_skip_nested_classes(n->data.ternary.cond, visit);
        walk_body_skip_nested_classes(n->data.ternary.true_expr, visit);
        walk_body_skip_nested_classes(n->data.ternary.false_expr, visit); return;
    case NODE_PRE_INC:
    case NODE_PRE_DEC:
    case NODE_POST_INC:
    case NODE_POST_DEC:
    case NODE_DEGREE:
    case NODE_FACTORIAL:
    case NODE_DOUBLE_FACTORIAL:
    case NODE_BITWISE_NOT:
        walk_body_skip_nested_classes(n->data.inc_dec.operand, visit); return;
    case NODE_METHOD_CALL:
        walk_body_skip_nested_classes(n->data.method_call.obj, visit);
        for (int i = 0; i < n->data.method_call.arg_count; ++i)
            walk_body_skip_nested_classes(n->data.method_call.args[i], visit);
        return;
    case NODE_OBJECT_LITERAL:
        for (int i = 0; i < n->data.object_lit.count; ++i) {
            walk_body_skip_nested_classes(n->data.object_lit.key_exprs[i], visit);
            walk_body_skip_nested_classes(n->data.object_lit.vals[i], visit);
        }
        for (int i = 0; i < n->data.object_lit.spread_count; ++i)
            walk_body_skip_nested_classes(n->data.object_lit.spreads[i], visit);
        return;
    case NODE_OBJECT_ACCESS:
        walk_body_skip_nested_classes(n->data.object_access.obj, visit); return;
    case NODE_OBJECT_ASSIGN:
        walk_body_skip_nested_classes(n->data.object_assign.obj, visit);
        walk_body_skip_nested_classes(n->data.object_assign.value, visit); return;
    case NODE_OBJECT_COMPOUND_ASSIGN:
        walk_body_skip_nested_classes(n->data.object_compound_assign.obj, visit);
        walk_body_skip_nested_classes(n->data.object_compound_assign.rhs, visit); return;
    case NODE_NULL_COALESCE:
        walk_body_skip_nested_classes(n->data.null_coalesce.left, visit);
        walk_body_skip_nested_classes(n->data.null_coalesce.right, visit); return;
    case NODE_PIPE:
        walk_body_skip_nested_classes(n->data.pipe.left, visit);
        walk_body_skip_nested_classes(n->data.pipe.right, visit); return;
    case NODE_RANGE:
        walk_body_skip_nested_classes(n->data.range.start, visit);
        walk_body_skip_nested_classes(n->data.range.end, visit);
        walk_body_skip_nested_classes(n->data.range.step, visit); return;
    case NODE_LIST_COMPREHENSION:
        walk_body_skip_nested_classes(n->data.list_comp.expr, visit);
        walk_body_skip_nested_classes(n->data.list_comp.collection, visit);
        walk_body_skip_nested_classes(n->data.list_comp.cond, visit); return;
    case NODE_OBJECT_COMPREHENSION:
        walk_body_skip_nested_classes(n->data.object_comp.key_expr, visit);
        walk_body_skip_nested_classes(n->data.object_comp.value_expr, visit);
        walk_body_skip_nested_classes(n->data.object_comp.collection, visit);
        walk_body_skip_nested_classes(n->data.object_comp.cond, visit); return;
    case NODE_LAZY_VAR_DECL:
        walk_body_skip_nested_classes(n->data.lazy_var_decl.expr, visit); return;
    case NODE_SICHER:
        walk_body_skip_nested_classes(n->data.sicher.expr, visit);
        walk_body_skip_nested_classes(n->data.sicher.msg_expr, visit); return;
    case NODE_SWAP_ASSIGN:
        walk_body_skip_nested_classes(n->data.swap.left, visit);
        walk_body_skip_nested_classes(n->data.swap.right, visit); return;
    case NODE_MATCH:
        walk_body_skip_nested_classes(n->data.match.expr, visit);
        for (int i = 0; i < n->data.match.branch_count; ++i) {
            walk_body_skip_nested_classes(n->data.match.branches[i].pattern, visit);
            walk_body_skip_nested_classes(n->data.match.branches[i].guard, visit);
            walk_body_skip_nested_classes(n->data.match.branches[i].body, visit);
        }
        return;
    case NODE_AWAIT:
        walk_body_skip_nested_classes(n->data.await.expr, visit);
        walk_body_skip_nested_classes(n->data.await.timeout, visit);
        walk_body_skip_nested_classes(n->data.await.fallback, visit); return;
    case NODE_KEY_BIND:
        walk_body_skip_nested_classes(n->data.key_bind.body, visit); return;
    case NODE_DESTRUCTURE:
    case NODE_DESTRUCTURE_ASSIGN:
        walk_body_skip_nested_classes(n->data.destructure.expr, visit); return;
    case NODE_NEW:
        for (int i = 0; i < n->data.new_expr.arg_count; ++i)
            walk_body_skip_nested_classes(n->data.new_expr.args[i], visit);
        return;
    case NODE_SUPER_CALL:
        for (int i = 0; i < n->data.super_call.arg_count; ++i)
            walk_body_skip_nested_classes(n->data.super_call.args[i], visit);
        return;
    case NODE_STRING_INTERP:
        for (int i = 0; i < n->data.string_interp.count; ++i)
            walk_body_skip_nested_classes(n->data.string_interp.fragments[i], visit);
        return;
    case NODE_MULTI_ASSIGN:
        for (int i = 0; i < n->data.multi_assign.right_count; ++i)
            walk_body_skip_nested_classes(n->data.multi_assign.right_exprs[i], visit);
        return;
    case NODE_SPREAD_ARRAY:
    case NODE_SPREAD_OBJECT:
    case NODE_SPREAD_ARG:
        walk_body_skip_nested_classes(n->data.spread.expr, visit); return;
    case NODE_FUNC_DEF:
    case NODE_ASYNC_FUNC_DEF:
    case NODE_RULE_DEF:
        // 函数定义在自己的方法体内（很少见），进入其体
        walk_body_skip_nested_classes(n->data.func_def.body, visit);
        for (int i = 0; i < n->data.func_def.param_count; ++i)
            walk_body_skip_nested_classes(n->data.func_def.param_defaults[i], visit);
        return;
    // 其它叶子节点无需递归
    default:
        return;
}
}

// 增强检查入口：在 check_undefined_symbols 之后调用
static void check_class_member_access(ASTNode* prog) {
if (!prog) return;

// ---- 收集所有类定义到 name -> ASTNode* 映射 ----
std::unordered_map<std::string, ASTNode*> class_ast_map;
walk_ast(prog, [&](ASTNode* n) {
    if (n->type == NODE_CLASS_DEF && n->data.class_def.name)
        class_ast_map[n->data.class_def.name] = n;
});
if (class_ast_map.empty()) return;

// ---- 1. 类体内 dies.X / dies.X(...) 检查 ----
for (auto& kv : class_ast_map) {
    const std::string& cls_name = kv.first;
    ASTNode* cls = kv.second;

    std::unordered_set<std::string> inst_members, stat_members, visited;
    collect_class_members_recursive(cls_name, class_ast_map,
                                     inst_members, stat_members, visited);

    auto check_body = [&](ASTNode* body) {
        if (!body) return;
        walk_body_skip_nested_classes(body, [&](ASTNode* n) {
            if (n->type == NODE_OBJECT_ACCESS) {
                ASTNode* obj = n->data.object_access.obj;
                const char* key = n->data.object_access.key;
                if (obj && obj->type == NODE_THIS && key && *key) {
                    if (!inst_members.count(key)) {
                        g_last_error_line = n->line;
                        g_last_error_col  = n->col;
                        kr_error("类 '%s' 没有实例成员 '%s'",
                                 cls_name.c_str(), key);
                    }
                }
            }
            else if (n->type == NODE_METHOD_CALL) {
                ASTNode* obj = n->data.method_call.obj;
                const char* method = n->data.method_call.method;
                if (obj && obj->type == NODE_THIS && method && *method) {
                    if (!inst_members.count(method)) {
                        g_last_error_line = n->line;
                        g_last_error_col  = n->col;
                        kr_error("类 '%s' 没有实例方法 '%s'",
                                 cls_name.c_str(), method);
                    }
                }
            }
        });
    };

    check_body(cls->data.class_def.ctor_body);
    for (int i = 0; i < cls->data.class_def.methods.count; ++i)
        check_body(cls->data.class_def.methods.bodies[i]);
    // 属性默认值也可能引用 dies.X（罕见）
    for (int i = 0; i < cls->data.class_def.properties.count; ++i)
        check_body(cls->data.class_def.properties.default_exprs[i]);
}

// ---- 2. 类外 ClassName.static_member / ClassName.static_method 检查 ----
// 遍历整个程序；在访问者里区分 dies（NODE_THIS）和 ClassName（NODE_VARIABLE）
walk_ast(prog, [&](ASTNode* n) {
    if (n->type == NODE_OBJECT_ACCESS) {
        ASTNode* obj = n->data.object_access.obj;
        const char* key = n->data.object_access.key;
        if (obj && obj->type == NODE_VARIABLE && key && *key) {
            const char* obj_name = obj->data.var_name;
            auto it = class_ast_map.find(obj_name);
            if (it != class_ast_map.end()) {
                std::unordered_set<std::string> inst, stat, visited;
                collect_class_members_recursive(obj_name, class_ast_map,
                                                 inst, stat, visited);
                if (!stat.count(key)) {
                    g_last_error_line = n->line;
                    g_last_error_col  = n->col;
                    kr_error("类 '%s' 没有静态成员 '%s'",
                             obj_name, key);
                }
            }
        }
    }
    else if (n->type == NODE_METHOD_CALL) {
        ASTNode* obj = n->data.method_call.obj;
        const char* method = n->data.method_call.method;
        if (obj && obj->type == NODE_VARIABLE && method && *method) {
            const char* obj_name = obj->data.var_name;
            auto it = class_ast_map.find(obj_name);
            if (it != class_ast_map.end()) {
                std::unordered_set<std::string> inst, stat, visited;
                collect_class_members_recursive(obj_name, class_ast_map,
                                                 inst, stat, visited);
                if (!stat.count(method)) {
                    g_last_error_line = n->line;
                    g_last_error_col  = n->col;
                    kr_error("类 '%s' 没有静态方法 '%s'",
                             obj_name, method);
                }
            }
        }
    }
});
}

// 轻量作用域链（仅用于静态检查，不影响运行时）
struct LexScope {
    std::unordered_set<std::string> decls;
    LexScope* parent = nullptr;

    LexScope() = default;
    explicit LexScope(LexScope* p) : parent(p) {}

    bool visible(const std::string& name) const {
        if (decls.count(name)) return true;
        return parent ? parent->visible(name) : false;
    }
};

// 作用域感知的声明收集 + 引用检查
static void scoped_check_undefined(
        ASTNode* n,
        LexScope* scope,
        const std::unordered_set<std::string>& builtins,
        const std::unordered_map<std::string, std::unordered_set<std::string>>& umf_symbols,
        const std::unordered_map<std::string, std::unordered_set<std::string>>& umf_visible,
        std::vector<std::pair<ASTNode*, std::string>>& undefined_refs)
{
    if (!n) return;

    switch (n->type) {

        // ========================================================
        //  一、创建新作用域的节点
        // ========================================================
        case NODE_SCOPE_BLOCK: {
            LexScope inner(scope);
            for (int i = 0; i < n->data.block.count; ++i)
                scoped_check_undefined(n->data.block.stmts[i], &inner,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;
        }

        case NODE_UMF_DEF: {
            // umf A von B: A 的内部作用域应能看到 B 的符号（含 B 的父链）
            LexScope inner(scope);
            if (n->data.umf_def.name) {
                auto it = umf_visible.find(n->data.umf_def.name);
                if (it != umf_visible.end()) {
                    for (const auto& s : it->second)
                        inner.decls.insert(s);
                }
            }
            scoped_check_undefined(n->data.umf_def.body, &inner,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;
        }

        case NODE_UMF_IMPORT: {
            // umf A; 只把 A 的直系符号引入当前作用域，不追溯 parent
            if (n->data.umf_import.name) {
                auto it = umf_symbols.find(n->data.umf_import.name);
                if (it != umf_symbols.end()) {
                    for (const auto& s : it->second)
                        scope->decls.insert(s);
                }
            }
            return;
        }

        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF: {
            if (n->data.func_def.name)
                scope->decls.insert(n->data.func_def.name);

            LexScope inner(scope);
            for (int i = 0; i < n->data.func_def.param_count; ++i)
                if (n->data.func_def.params[i])
                    inner.decls.insert(n->data.func_def.params[i]);
            if (n->data.func_def.vararg_name)
                inner.decls.insert(n->data.func_def.vararg_name);

            if (n->data.func_def.param_defaults) {
                for (int i = 0; i < n->data.func_def.param_count; ++i)
                    if (n->data.func_def.param_defaults[i])
                        scoped_check_undefined(n->data.func_def.param_defaults[i],
                                                &inner,
                                                builtins, umf_symbols, umf_visible,
                                                undefined_refs);
            }
            scoped_check_undefined(n->data.func_def.body, &inner,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;
        }

        case NODE_CLASS_DEF: {
            if (n->data.class_def.name)
                scope->decls.insert(n->data.class_def.name);

            // ---- 类成员作用域：包含所有属性名与方法名 ----
            LexScope class_member_scope(scope);
            for (int i = 0; i < n->data.class_def.properties.count; ++i)
                if (n->data.class_def.properties.names[i])
                    class_member_scope.decls.insert(n->data.class_def.properties.names[i]);
            for (int i = 0; i < n->data.class_def.methods.count; ++i)
                if (n->data.class_def.methods.names[i])
                    class_member_scope.decls.insert(n->data.class_def.methods.names[i]);

            // ---- 构造函数 ----
            if (n->data.class_def.ctor_body) {
                LexScope inner(&class_member_scope);
                for (int i = 0; i < n->data.class_def.ctor_param_count; ++i)
                    if (n->data.class_def.ctor_params[i])
                        inner.decls.insert(n->data.class_def.ctor_params[i]);
                scoped_check_undefined(n->data.class_def.ctor_body, &inner,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            }

            // ---- 每个方法：类成员 + 自身参数 ----
            for (int i = 0; i < n->data.class_def.methods.count; ++i) {
                LexScope inner(&class_member_scope);
                for (int j = 0; j < n->data.class_def.methods.param_counts[i]; ++j)
                    if (n->data.class_def.methods.param_lists[i][j])
                        inner.decls.insert(n->data.class_def.methods.param_lists[i][j]);
                if (n->data.class_def.methods.vararg_names &&
                    n->data.class_def.methods.vararg_names[i])
                    inner.decls.insert(n->data.class_def.methods.vararg_names[i]);
                scoped_check_undefined(n->data.class_def.methods.bodies[i], &inner,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            }

            // ---- 属性默认值：可以引用其他成员（如 stati das x = 1） ----
            for (int i = 0; i < n->data.class_def.properties.count; ++i)
                if (n->data.class_def.properties.default_exprs[i])
                    scoped_check_undefined(n->data.class_def.properties.default_exprs[i],
                                            &class_member_scope,
                                            builtins, umf_symbols, umf_visible,
                                            undefined_refs);
            return;
        }

        case NODE_LIST_COMPREHENSION: {
            scoped_check_undefined(n->data.list_comp.collection, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            LexScope inner(scope);
            if (n->data.list_comp.var_name)
                inner.decls.insert(n->data.list_comp.var_name);
            scoped_check_undefined(n->data.list_comp.expr, &inner,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            if (n->data.list_comp.cond)
                scoped_check_undefined(n->data.list_comp.cond, &inner,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;
        }

        case NODE_OBJECT_COMPREHENSION: {
            scoped_check_undefined(n->data.object_comp.collection, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            LexScope inner(scope);
            if (n->data.object_comp.var_name)
                inner.decls.insert(n->data.object_comp.var_name);
            if (n->data.object_comp.value_var)
                inner.decls.insert(n->data.object_comp.value_var);
            scoped_check_undefined(n->data.object_comp.key_expr, &inner,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.object_comp.value_expr, &inner,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            if (n->data.object_comp.cond)
                scoped_check_undefined(n->data.object_comp.cond, &inner,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;
        }

        // ========================================================
        //  二、声明类节点：加入当前作用域，然后继续遍历子节点
        // ========================================================
        case NODE_VAR_DECL:
            if (n->data.var_decl.name)
                scope->decls.insert(n->data.var_decl.name);
            scoped_check_undefined(n->data.var_decl.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_ASSIGN:
            if (n->data.assign.name)
                scope->decls.insert(n->data.assign.name);
            scoped_check_undefined(n->data.assign.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_INPUT:
            if (n->data.input.name)
                scope->decls.insert(n->data.input.name);
            for (int i = 0; i < n->data.input.arg_count; ++i)
                scoped_check_undefined(n->data.input.args[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            if (n->data.input.multiline_expr)
                scoped_check_undefined(n->data.input.multiline_expr, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_LAZY_VAR_DECL:
            if (n->data.lazy_var_decl.name)
                scope->decls.insert(n->data.lazy_var_decl.name);
            scoped_check_undefined(n->data.lazy_var_decl.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_ALIAS_DECL:
            if (n->data.alias_decl.name)
                scope->decls.insert(n->data.alias_decl.name);
            return;

        case NODE_IMPORT:
            if (n->data.import.alias)
                scope->decls.insert(n->data.import.alias);
            return;

        case NODE_ENUM_DEF:
            if (n->data.enum_def.name)
                scope->decls.insert(n->data.enum_def.name);
            for (int i = 0; i < n->data.enum_def.variant_count; ++i)
                if (n->data.enum_def.variants[i])
                    scope->decls.insert(n->data.enum_def.variants[i]);
            return;

        case NODE_STRUCT_DEF:
            if (n->data.struct_def.name)
                scope->decls.insert(n->data.struct_def.name);
            return;

        case NODE_UNION_DEF:
            if (n->data.union_def.name)
                scope->decls.insert(n->data.union_def.name);
            for (int i = 0; i < n->data.union_def.variant_count; ++i)
                if (n->data.union_def.variants[i].name)
                    scope->decls.insert(n->data.union_def.variants[i].name);
            return;

        case NODE_MARK_USED:
        case NODE_MARK_ALL_USED:
            return;

        // ========================================================
        //  三、引用类节点：检查可见性
        // ========================================================
        case NODE_VARIABLE:
            if (n->data.var_name &&
                !scope->visible(n->data.var_name) &&
                !builtins.count(n->data.var_name) &&
                !umf_symbols.count(n->data.var_name)) {
                undefined_refs.push_back({n, n->data.var_name});
            }
            return;

        case NODE_FUNC_CALL:
            if (n->data.func_call.name &&
                !scope->visible(n->data.func_call.name) &&
                !builtins.count(n->data.func_call.name)) {
                undefined_refs.push_back({n, n->data.func_call.name});
            }
            if (n->data.func_call.func_expr)
                scoped_check_undefined(n->data.func_call.func_expr, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            for (int i = 0; i < n->data.func_call.arg_count; ++i)
                scoped_check_undefined(n->data.func_call.args[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;
        
        case NODE_METHOD_CALL: {
            // 命名空间成员调用 Namespace.fn()：
            // obj 是命名空间名而非变量，不做可见性检查（与运行时 named_scopes 查找一致）
            bool obj_is_namespace = false;
            if (n->data.method_call.obj &&
                n->data.method_call.obj->type == NODE_VARIABLE) {
                const char* obj_name = n->data.method_call.obj->data.var_name;
                if (obj_name && umf_symbols.count(obj_name)) {
                    obj_is_namespace = true;
                }
            }
            if (!obj_is_namespace) {
                scoped_check_undefined(n->data.method_call.obj, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            }
            for (int i = 0; i < n->data.method_call.arg_count; ++i)
                scoped_check_undefined(n->data.method_call.args[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;
        }

        // ========================================================
        //  四、递归遍历（不改变作用域）
        // ========================================================
        case NODE_PROGRAM:
        case NODE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            for (int i = 0; i < n->data.block.count; ++i)
                scoped_check_undefined(n->data.block.stmts[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_IF:
            scoped_check_undefined(n->data.if_stmt.cond, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.if_stmt.then_block, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            for (int i = 0; i < n->data.if_stmt.else_if_count; ++i)
                scoped_check_undefined(n->data.if_stmt.else_ifs[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            if (n->data.if_stmt.else_block)
                scoped_check_undefined(n->data.if_stmt.else_block, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_WHILE:
            scoped_check_undefined(n->data.while_stmt.cond, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.while_stmt.body, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_DO_WHILE:
            scoped_check_undefined(n->data.do_while.body, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.do_while.cond, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_FOR:
            if (n->data.for_stmt.init)
                scoped_check_undefined(n->data.for_stmt.init, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            if (n->data.for_stmt.cond)
                scoped_check_undefined(n->data.for_stmt.cond, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            if (n->data.for_stmt.update)
                scoped_check_undefined(n->data.for_stmt.update, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            scoped_check_undefined(n->data.for_stmt.body, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_FOREACH:
            if (n->data.foreach.key_var)
                scope->decls.insert(n->data.foreach.key_var);
            if (n->data.foreach.value_var)
                scope->decls.insert(n->data.foreach.value_var);
            scoped_check_undefined(n->data.foreach.collection, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.foreach.body, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_RETURN:
            if (n->data.ret.expr)
                scoped_check_undefined(n->data.ret.expr, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_EXPR_STMT:
            scoped_check_undefined(n->data.expr_stmt.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_TRY:
            scoped_check_undefined(n->data.try_stmt.try_body, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            if (n->data.try_stmt.catch_body) {
                if (n->data.try_stmt.catch_var)
                    scope->decls.insert(n->data.try_stmt.catch_var);
                scoped_check_undefined(n->data.try_stmt.catch_body, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            }
            if (n->data.try_stmt.finally_body)
                scoped_check_undefined(n->data.try_stmt.finally_body, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_THROW:
            scoped_check_undefined(n->data.throw_expr.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_DESTRUCTURE:
        case NODE_DESTRUCTURE_ASSIGN:
            for (int i = 0; i < n->data.destructure.count; ++i)
                if (n->data.destructure.names[i])
                    scope->decls.insert(n->data.destructure.names[i]);
            if (n->data.destructure.rest_name)
                scope->decls.insert(n->data.destructure.rest_name);
            scoped_check_undefined(n->data.destructure.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_MULTI_ASSIGN:
            for (int i = 0; i < n->data.multi_assign.left_count; ++i)
                if (n->data.multi_assign.left_names[i])
                    scope->decls.insert(n->data.multi_assign.left_names[i]);
            for (int i = 0; i < n->data.multi_assign.right_count; ++i)
                scoped_check_undefined(n->data.multi_assign.right_exprs[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_KEY_BIND:
            scoped_check_undefined(n->data.key_bind.body, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_SWAP_ASSIGN:
            scoped_check_undefined(n->data.swap.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.swap.right, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_SICHER:
            scoped_check_undefined(n->data.sicher.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            if (n->data.sicher.msg_expr)
                scoped_check_undefined(n->data.sicher.msg_expr, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_AWAIT:
            scoped_check_undefined(n->data.await.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            if (n->data.await.timeout)
                scoped_check_undefined(n->data.await.timeout, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            if (n->data.await.fallback)
                scoped_check_undefined(n->data.await.fallback, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_ARRAY_LITERAL:
            for (int i = 0; i < n->data.array_lit.count; ++i)
                scoped_check_undefined(n->data.array_lit.elems[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_ARRAY_ACCESS:
            scoped_check_undefined(n->data.array_access.array, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.array_access.index, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_ARRAY_LEN:
            scoped_check_undefined(n->data.array_len.array, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_STRING_ACCESS:
            scoped_check_undefined(n->data.string_access.str, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.string_access.index, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_STRING_LEN:
            scoped_check_undefined(n->data.string_len.str, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_NOT:
            scoped_check_undefined(n->data.not_expr.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_LOGICAL_AND:
            scoped_check_undefined(n->data.logical_and.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.logical_and.right, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_LOGICAL_OR:
            scoped_check_undefined(n->data.logical_or.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.logical_or.right, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_ARRAY_ASSIGN:
            scoped_check_undefined(n->data.array_assign.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.array_assign.index, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.array_assign.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_ARRAY_COMPOUND_ASSIGN:
            scoped_check_undefined(n->data.array_compound_assign.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.array_compound_assign.index, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.array_compound_assign.rhs, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT:
        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT:
            scoped_check_undefined(n->data.binary.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.binary.right, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_TERNARY:
            scoped_check_undefined(n->data.ternary.cond, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.ternary.true_expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.ternary.false_expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
        case NODE_DOUBLE_FACTORIAL:
        case NODE_BITWISE_NOT:
            scoped_check_undefined(n->data.inc_dec.operand, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_OBJECT_LITERAL:
            for (int i = 0; i < n->data.object_lit.count; ++i) {
                scoped_check_undefined(n->data.object_lit.key_exprs[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
                scoped_check_undefined(n->data.object_lit.vals[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            }
            for (int i = 0; i < n->data.object_lit.spread_count; ++i)
                scoped_check_undefined(n->data.object_lit.spreads[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_OBJECT_ACCESS: {
            // 若 obj 是命名空间名，跳过对 obj 的变量可见性检查
            bool obj_is_namespace = false;
            if (n->data.object_access.obj &&
                n->data.object_access.obj->type == NODE_VARIABLE) {
                const char* obj_name = n->data.object_access.obj->data.var_name;
                if (obj_name && umf_symbols.count(obj_name))
                    obj_is_namespace = true;
            }
            if (!obj_is_namespace) {
                scoped_check_undefined(n->data.object_access.obj, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            }
            return;
        }

        case NODE_OBJECT_ASSIGN:
            scoped_check_undefined(n->data.object_assign.obj, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.object_assign.value, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_OBJECT_COMPOUND_ASSIGN:
            scoped_check_undefined(n->data.object_compound_assign.obj, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.object_compound_assign.rhs, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_NULL_COALESCE:
            scoped_check_undefined(n->data.null_coalesce.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.null_coalesce.right, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_PIPE:
            scoped_check_undefined(n->data.pipe.left, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.pipe.right, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_RANGE:
            scoped_check_undefined(n->data.range.start, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.range.end, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            if (n->data.range.step)
                scoped_check_undefined(n->data.range.step, scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_NEW:
            for (int i = 0; i < n->data.new_expr.arg_count; ++i)
                scoped_check_undefined(n->data.new_expr.args[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_SUPER_CALL:
            for (int i = 0; i < n->data.super_call.arg_count; ++i)
                scoped_check_undefined(n->data.super_call.args[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_STRING_INTERP:
            for (int i = 0; i < n->data.string_interp.count; ++i)
                scoped_check_undefined(n->data.string_interp.fragments[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_MATCH:
            scoped_check_undefined(n->data.match.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            for (int i = 0; i < n->data.match.branch_count; ++i) {
                LexScope branch_scope(scope);
                scoped_check_undefined(n->data.match.branches[i].pattern,
                                        &branch_scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
                if (n->data.match.branches[i].guard)
                    scoped_check_undefined(n->data.match.branches[i].guard,
                                            &branch_scope,
                                            builtins, umf_symbols, umf_visible,
                                            undefined_refs);
                scoped_check_undefined(n->data.match.branches[i].body,
                                        &branch_scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            }
            return;

        case NODE_PATTERN_OR:
            for (int i = 0; i < n->data.pattern_or.count; ++i)
                scoped_check_undefined(n->data.pattern_or.patterns[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            scoped_check_undefined(n->data.spread.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        // ---------- 打印类节点 ----------
        case NODE_PRINT:
        case NODE_PRINT_NO_NEWLINE:
            scoped_check_undefined(n->data.print.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_PRINT_WITH_LINE:
            scoped_check_undefined(n->data.print_with_line.expr, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            scoped_check_undefined(n->data.print_with_line.line, scope,
                                    builtins, umf_symbols, umf_visible,
                                    undefined_refs);
            return;

        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI:
            for (int i = 0; i < n->data.print_multi.count; ++i)
                scoped_check_undefined(n->data.print_multi.exprs[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        // ---------- 类型定义：成员可能引用变量 ----------
        case NODE_TYPE_DEF:
            if (n->data.type_def.name)
                scope->decls.insert(n->data.type_def.name);
            for (int i = 0; i < n->data.type_def.member_count; ++i)
                scoped_check_undefined(n->data.type_def.members[i], scope,
                                        builtins, umf_symbols, umf_visible,
                                        undefined_refs);
            return;

        // ========================================================
        //  五、叶子节点
        // ========================================================
        case NODE_NUMBER:
        case NODE_FLOAT:
        case NODE_STRING:
        case NODE_NULL:
        case NODE_THIS:
        case NODE_BREAK:
        case NODE_CONTINUE:
        case NODE_REGEX_LITERAL:
        case NODE_ENUM_VARIANT:
        case NODE_PATTERN_BIND:
        case NODE_PATTERN_OBJECT:
        case NODE_PATTERN_VARIANT:
        case NODE_PATTERN_CONSTANT:
            return;

        default:
            return;
    }
}

// ============ 静态未定义检查（入口） ============
static void check_undefined_symbols(ASTNode* prog) {
    if (!prog) return;

    bool has_unaliased_import = false;
    walk_ast(prog, [&](ASTNode* n) {
        if (n->type == NODE_IMPORT && !n->data.import.alias)
            has_unaliased_import = true;
    });
    if (has_unaliased_import) return;

    // ------------------------------------------------------------
    // 第零遍：收集所有命名作用域（umf）的直系符号及其父作用域
    // ------------------------------------------------------------
    std::unordered_map<std::string, std::unordered_set<std::string>> umf_symbols;
    std::unordered_map<std::string, std::string> umf_parents;

    walk_ast(prog, [&](ASTNode* n) {
        if (n->type == NODE_UMF_DEF && n->data.umf_def.name) {
            // 记录 von 父作用域（若存在）
            if (n->data.umf_def.parent_name)
                umf_parents[n->data.umf_def.name] = n->data.umf_def.parent_name;
    
            std::unordered_set<std::string>& syms =
                umf_symbols[n->data.umf_def.name];

            {
                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                std::string prefix = std::string(n->data.umf_def.name) + "::";
                for (const auto& p : type_aliases) {
                    if (p.first.size() > prefix.size() &&
                        p.first.compare(0, prefix.size(), prefix) == 0) {
                        syms.insert(p.first.substr(prefix.size()));
                    }
                }
            }

            walk_ast(n->data.umf_def.body, [&](ASTNode* inner) {
                switch (inner->type) {
                    case NODE_FUNC_DEF:
                    case NODE_ASYNC_FUNC_DEF:
                    case NODE_RULE_DEF:
                        if (inner->data.func_def.name)
                            syms.insert(inner->data.func_def.name);
                        break;
                    case NODE_VAR_DECL:
                        if (inner->data.var_decl.name)
                            syms.insert(inner->data.var_decl.name);
                        break;
                    case NODE_ASSIGN:
                        if (inner->data.assign.name)
                            syms.insert(inner->data.assign.name);
                        break;
                    case NODE_LAZY_VAR_DECL:
                        if (inner->data.lazy_var_decl.name)
                            syms.insert(inner->data.lazy_var_decl.name);
                        break;
                    case NODE_ALIAS_DECL:
                        if (inner->data.alias_decl.name)
                            syms.insert(inner->data.alias_decl.name);
                        break;
                    case NODE_CLASS_DEF:
                        if (inner->data.class_def.name)
                            syms.insert(inner->data.class_def.name);
                        break;
                    case NODE_ENUM_DEF:
                        if (inner->data.enum_def.name)
                            syms.insert(inner->data.enum_def.name);
                        for (int i = 0; i < inner->data.enum_def.variant_count; i++)
                            if (inner->data.enum_def.variants[i])
                                syms.insert(inner->data.enum_def.variants[i]);
                        break;
                    case NODE_STRUCT_DEF:
                        if (inner->data.struct_def.name)
                            syms.insert(inner->data.struct_def.name);
                        break;
                    case NODE_UNION_DEF:
                        if (inner->data.union_def.name)
                            syms.insert(inner->data.union_def.name);
                        for (int i = 0; i < inner->data.union_def.variant_count; i++)
                            if (inner->data.union_def.variants[i].name)
                                syms.insert(inner->data.union_def.variants[i].name);
                        break;
                    case NODE_TYPE_DEF:
                        if (inner->data.type_def.name)
                            syms.insert(inner->data.type_def.name);
                        break;
                    default:
                        break;
                }
            });
        }
    });

    // ------------------------------------------------------------
    // 计算每个 umf 的传递可见符号集（含父链）
    // ------------------------------------------------------------
    std::unordered_map<std::string, std::unordered_set<std::string>> umf_visible;
    std::unordered_set<std::string> in_progress;

    std::function<void(const std::string&)> resolve_visible =
        [&](const std::string& name) {
            if (umf_visible.count(name)) return;
            if (in_progress.count(name)) return;   // 循环继承保护
            in_progress.insert(name);

            std::unordered_set<std::string> result;
            auto sit = umf_symbols.find(name);
            if (sit != umf_symbols.end())
                result.insert(sit->second.begin(), sit->second.end());

            auto pit = umf_parents.find(name);
            if (pit != umf_parents.end()) {
                resolve_visible(pit->second);
                auto vit = umf_visible.find(pit->second);
                if (vit != umf_visible.end())
                    result.insert(vit->second.begin(), vit->second.end());
            }

            umf_visible[name] = std::move(result);
            in_progress.erase(name);
        };

    for (auto& kv : umf_symbols) resolve_visible(kv.first);
    for (auto& kv : umf_parents) resolve_visible(kv.first);

    // ------------------------------------------------------------
    // 第一遍：收集用户定义的类型名
    // ------------------------------------------------------------
    std::unordered_set<std::string> known_types;
    {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        for (const auto& p : type_aliases) known_types.insert(p.first);
        for (const auto& p : enum_table)   known_types.insert(p.first);
    }
    walk_ast(prog, [&](ASTNode* n) {
        if (n->type == NODE_CLASS_DEF && n->data.class_def.name)
            known_types.insert(n->data.class_def.name);
        if (n->type == NODE_STRUCT_DEF && n->data.struct_def.name)
            known_types.insert(n->data.struct_def.name);
        if (n->type == NODE_UNION_DEF && n->data.union_def.name)
            known_types.insert(n->data.union_def.name);

        // ---- umf A; 导入的直系符号也视为已知类型名 ----
        if (n->type == NODE_UMF_IMPORT && n->data.umf_import.name) {
            auto it = umf_symbols.find(n->data.umf_import.name);
            if (it != umf_symbols.end()) {
                for (const auto& s : it->second)
                    known_types.insert(s);
            }
        }
    });

    // ------------------------------------------------------------
    // 第二遍：收集函数签名
    // ------------------------------------------------------------
    struct FuncSig { int min_args; int max_args; };
    std::unordered_map<std::string, std::vector<FuncSig>> func_sigs;
    walk_ast(prog, [&](ASTNode* n) {
        if (n->type == NODE_FUNC_DEF ||
            n->type == NODE_ASYNC_FUNC_DEF ||
            n->type == NODE_RULE_DEF) {
            const char* name = n->data.func_def.name;
            if (!name) return;
            int total = n->data.func_def.param_count;
            int min_required = total;
            for (int i = 0; i < total; i++) {
                if (n->data.func_def.param_defaults &&
                    n->data.func_def.param_defaults[i]) {
                    min_required = i;
                    break;
                }
            }
            bool has_vararg = (n->data.func_def.vararg_name != nullptr);
            func_sigs[name].push_back({ min_required, has_vararg ? -1 : total });
        }
    });

    // ------------------------------------------------------------
    // 作用域感知的未定义引用收集
    // ------------------------------------------------------------
    const auto& builtins = builtin_names();
    std::vector<std::pair<ASTNode*, std::string>> undefined_refs;

    LexScope root_scope;
    scoped_check_undefined(prog, &root_scope, builtins,
                            umf_symbols, umf_visible, undefined_refs);

    // ------------------------------------------------------------
    // 第三遍：类型注解检查 + 函数调用参数数量检查
    // （变量/函数引用的作用域检查已由 scoped_check_undefined 完成，
    //   这里不再收集 refs，避免与之重复。）
    // ------------------------------------------------------------
    walk_ast(prog, [&](ASTNode* n) {

        // ---------- 3a. 类型注解检查 ----------
        switch (n->type) {
            case NODE_VAR_DECL:
                if (n->data.var_decl.type_annotation)
                    check_type_refs(n->data.var_decl.type_annotation,
                                    n->line, n->col, known_types);
                break;

            case NODE_FUNC_DEF:
            case NODE_ASYNC_FUNC_DEF:
            case NODE_RULE_DEF:
                if (n->data.func_def.return_type)
                    check_type_refs(n->data.func_def.return_type,
                                    n->line, n->col, known_types);
                if (n->data.func_def.param_types) {
                    for (int i = 0; i < n->data.func_def.param_count; i++)
                        check_type_refs(n->data.func_def.param_types[i],
                                        n->line, n->col, known_types);
                }
                if (n->data.func_def.vararg_type)
                    check_type_refs(n->data.func_def.vararg_type,
                                    n->line, n->col, known_types);
                break;

            case NODE_CLASS_DEF:
                // 构造函数参数类型
                for (int i = 0; i < n->data.class_def.ctor_param_type_count; i++)
                    check_type_refs(n->data.class_def.ctor_param_types[i],
                                    n->line, n->col, known_types);
                // 方法返回类型 / 参数类型 / 可变参数类型
                for (int i = 0; i < n->data.class_def.methods.count; i++) {
                    if (n->data.class_def.methods.return_types[i])
                        check_type_refs(n->data.class_def.methods.return_types[i],
                                        n->line, n->col, known_types);
                    if (n->data.class_def.methods.param_types &&
                        n->data.class_def.methods.param_types[i]) {
                        for (int j = 0;
                             j < n->data.class_def.methods.param_counts[i];
                             j++) {
                            check_type_refs(
                                n->data.class_def.methods.param_types[i][j],
                                n->line, n->col, known_types);
                        }
                    }
                    if (n->data.class_def.methods.vararg_types &&
                        n->data.class_def.methods.vararg_types[i])
                        check_type_refs(n->data.class_def.methods.vararg_types[i],
                                        n->line, n->col, known_types);
                }
                // 属性类型
                for (int i = 0; i < n->data.class_def.properties.count; i++) {
                    if (n->data.class_def.properties.types[i])
                        check_type_refs(n->data.class_def.properties.types[i],
                                        n->line, n->col, known_types);
                }
                break;

            default:
                break;
        }

        // ---------- 3b. 函数调用参数数量检查 ----------
        if (n->type == NODE_FUNC_CALL) {
            const char* name = n->data.func_call.name;
            if (!name) return;                       // 形如 expr(...)，不是命名调用
            auto it = func_sigs.find(name);
            if (it == func_sigs.end()) return;       // 不是用户定义函数（可能是内置 / 变量函数 / 未定义）

            int argc = n->data.func_call.arg_count;

            // 含展开参数 ... 的调用，参数数量无法静态确定，跳过检查
            for (int i = 0; i < argc; i++) {
                if (n->data.func_call.args[i]->type == NODE_SPREAD_ARG)
                    return;
            }

            // 同名函数可能有多个重载签名（例如不同作用域），任一匹配即通过
            bool any_match = false;
            int min_required = INT_MAX;
            int max_allowed  = -1;
            for (const auto& sig : it->second) {
                if (argc >= sig.min_args &&
                    (sig.max_args < 0 || argc <= sig.max_args)) {
                    any_match = true;
                    break;
                }
                if (sig.min_args < min_required) min_required = sig.min_args;
                if (sig.max_args < 0) max_allowed = -1;
                else if (sig.max_args > max_allowed) max_allowed = sig.max_args;
            }
            if (!any_match) {
                g_last_error_line = n->line;
                g_last_error_col  = n->col;
                if (max_allowed >= 0 && argc > max_allowed) {
                    kr_error("函数 '%s' 参数过多: 期望至多 %d 个, 实际 %d 个",
                             name, max_allowed, argc);
                } else if (min_required != INT_MAX) {
                    kr_error("函数 '%s' 参数不足: 期望至少 %d 个, 实际 %d 个",
                             name, min_required, argc);
                }
            }
        }
    });
    check_class_member_access(prog);

    // ------------------------------------------------------------
    // 统一报告未定义引用
    // ------------------------------------------------------------
    for (const auto& r : undefined_refs) {
        g_last_error_line = r.first->line;
        g_last_error_col  = r.first->col;

        const std::string& name = r.second;

        // 提示：该标识符是否在某个命名作用域（umf）中定义？
        // 使用 umf_symbols（直系）检查，并列出所有候选 umf
        std::string scope_hint;
        for (const auto& kv : umf_symbols) {
            if (kv.second.find(name) != kv.second.end()) {
                scope_hint = "标识符 '" + name + "' 在命名作用域 '" +
                             kv.first + "' 中定义。\n"
                             "  请先导入:  umf " + kv.first + ";\n"
                             "  或限定调用: " + kv.first + "." + name;
                break;
            }
        }

        if (!scope_hint.empty()) {
            kr_error_hint(scope_hint.c_str(),
                          "标识符 '%s' 未在当前作用域声明", name.c_str());
        } else {
            std::string hint = suggest_correction(name);
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                          "标识符 '%s' 未在当前作用域声明", name.c_str());
        }
    }
}

// ---- 静态检查：bruch N / weiter N 是否超出循环嵌套深度 ----
static void check_loop_levels(ASTNode* n, int loop_depth) {
    if (!n) return;

    switch (n->type) {
        // ---------- 语句容器：原样递归 ----------
        case NODE_PROGRAM:
        case NODE_BLOCK:
        case NODE_SCOPE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            for (int i = 0; i < n->data.block.count; i++)
                check_loop_levels(n->data.block.stmts[i], loop_depth);
            return;

        // ---------- 循环：body 深度 +1 ----------
        case NODE_WHILE:
            check_loop_levels(n->data.while_stmt.body, loop_depth + 1);
            return;
        case NODE_DO_WHILE:
            check_loop_levels(n->data.do_while.body, loop_depth + 1);
            return;
        case NODE_FOR:
            check_loop_levels(n->data.for_stmt.body, loop_depth + 1);
            return;
        case NODE_FOREACH:
            check_loop_levels(n->data.foreach.body, loop_depth + 1);
            return;

        // ---------- 条件分支：深度不变 ----------
        case NODE_IF:
            check_loop_levels(n->data.if_stmt.then_block, loop_depth);
            for (int i = 0; i < n->data.if_stmt.else_if_count; i++)
                check_loop_levels(n->data.if_stmt.else_ifs[i], loop_depth);
            check_loop_levels(n->data.if_stmt.else_block, loop_depth);
            return;

        case NODE_TRY:
            check_loop_levels(n->data.try_stmt.try_body, loop_depth);
            check_loop_levels(n->data.try_stmt.catch_body, loop_depth);
            check_loop_levels(n->data.try_stmt.finally_body, loop_depth);
            return;

        case NODE_MATCH:
            // 分支体在运行时共享循环深度（break 可跳出外层循环）
            for (int i = 0; i < n->data.match.branch_count; i++)
                check_loop_levels(n->data.match.branches[i].body, loop_depth);
            return;

        case NODE_KEY_BIND:
            check_loop_levels(n->data.key_bind.body, loop_depth);
            return;

        // ---------- 函数 / 类 / umf：深度重置为 0 ----------
        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF:
            check_loop_levels(n->data.func_def.body, 0);
            return;

        case NODE_CLASS_DEF:
            check_loop_levels(n->data.class_def.ctor_body, 0);
            for (int i = 0; i < n->data.class_def.methods.count; i++)
                check_loop_levels(n->data.class_def.methods.bodies[i], 0);
            return;

        case NODE_UMF_DEF:
            check_loop_levels(n->data.umf_def.body, 0);
            return;

        // ---------- 关键：检查 break / continue ----------
        case NODE_BREAK:
        case NODE_CONTINUE: {
            const char* kw = (n->type == NODE_BREAK) ? "bruch" : "weiter";
            int levels = n->data.break_stmt.levels;
            if (levels < 1) levels = 1;   // 兼容旧 AST（calloc 默认 0）

            if (loop_depth == 0) {
                g_last_error_line = n->line;
                g_last_error_col  = n->col;
                kr_error("%s 只能在循环中使用", kw);
            }
            if (levels > loop_depth) {
                g_last_error_line = n->line;
                g_last_error_col  = n->col;
                kr_error("%s %d 超出当前循环嵌套深度 %d",
                         kw, levels, loop_depth);
            }
            return;
        }

        // ---------- 其余节点（表达式、声明等）不含语句级 break/continue ----------
        default:
            return;
    }
}

std::string ast_node_to_string(ASTNode* node, int indent) {
    if (!node) return "";
    std::string prefix(indent, ' ');
    std::string result = prefix + node_type_to_string(node->type) +
                         " (line:" + std::to_string(node->line) +
                         " col:" + std::to_string(node->col) + ")";

    switch (node->type) {
        case NODE_VAR_DECL:
            result += " name: " + std::string(node->data.var_decl.name) +
                      (node->data.var_decl.is_const ? " const" : "") +
                      (node->data.var_decl.global ? " global" : "");
            if (node->data.var_decl.type_annotation)
                result += " type: " + type_to_string(node->data.var_decl.type_annotation);
            break;
        case NODE_ASSIGN:
            result += " name: " + std::string(node->data.assign.name) +
                      (node->data.assign.global ? " global" : "");
            break;
        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT:
            result += " op: " + node->data.binary.op;
            break;
        case NODE_NUMBER:
            result += " value: " + std::string(node->data.number_str);
            break;
        case NODE_FLOAT:
            result += " value: " + std::string(node->data.float_str);
            break;
        case NODE_VARIABLE:
            result += " name: " + std::string(node->data.var_name);
            break;
        case NODE_STRING:
            result += " value: \"" + std::string(node->data.string) + "\"";
            break;
        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF:
            result += " name: " + std::string(node->data.func_def.name ? node->data.func_def.name : "<anon>") +
                      " params: " + std::to_string(node->data.func_def.param_count);
            break;
        case NODE_FUNC_CALL:
            if (node->data.func_call.name)
                result += " name: " + std::string(node->data.func_call.name);
            else
                result += " (func_expr)";
            result += " args: " + std::to_string(node->data.func_call.arg_count);
            break;
        case NODE_BLOCK:
        case NODE_PROGRAM:
        case NODE_SCOPE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            result += " stmts: " + std::to_string(node->data.block.count);
            break;
        case NODE_IF:
            result += " else_if_count: " + std::to_string(node->data.if_stmt.else_if_count) +
                      (node->data.if_stmt.else_block ? " has_else" : "");
            break;
        case NODE_WHILE:
        case NODE_DO_WHILE:
            break;
        case NODE_FOR:
            result += " has_init: " + std::to_string(node->data.for_stmt.init != nullptr) +
                      " has_cond: " + std::to_string(node->data.for_stmt.cond != nullptr) +
                      " has_update: " + std::to_string(node->data.for_stmt.update != nullptr);
            break;
        case NODE_FOREACH:
            result += " key: " + std::string(node->data.foreach.key_var) +
                      (node->data.foreach.value_var ? " value: " + std::string(node->data.foreach.value_var) : "");
            break;
        case NODE_RETURN:
            result += " has_expr: " + std::to_string(node->data.ret.expr != nullptr);
            break;
        case NODE_ARRAY_LITERAL:
            result += " count: " + std::to_string(node->data.array_lit.count);
            break;
        case NODE_ARRAY_ACCESS:
            break;
        case NODE_OBJECT_LITERAL:
            result += " count: " + std::to_string(node->data.object_lit.count) +
                      " spreads: " + std::to_string(node->data.object_lit.spread_count);
            break;
        case NODE_OBJECT_ACCESS:
            result += " key: " + std::string(node->data.object_access.key) +
                      (node->data.object_access.is_optional ? " optional" : "");
            break;
        case NODE_METHOD_CALL:
            result += " method: " + std::string(node->data.method_call.method) +
                      " args: " + std::to_string(node->data.method_call.arg_count) +
                      (node->data.method_call.is_optional ? " optional" : "");
            break;
        case NODE_MATCH:
            result += " branches: " + std::to_string(node->data.match.branch_count);
            break;
        case NODE_CLASS_DEF:
            result += " name: " + std::string(node->data.class_def.name) +
                      (node->data.class_def.parent ? " parent: " + std::string(node->data.class_def.parent) : "") +
                      " methods: " + std::to_string(node->data.class_def.methods.count) +
                      " props: " + std::to_string(node->data.class_def.properties.count);
            break;
        case NODE_NEW:
            result += " class: " + std::string(node->data.new_expr.class_name) +
                      " args: " + std::to_string(node->data.new_expr.arg_count);
            break;
        case NODE_SUPER_CALL:
            result += " args: " + std::to_string(node->data.super_call.arg_count);
            break;
        case NODE_THIS:
            break;
        case NODE_NULL:
            break;
        case NODE_PRINT_WITH_LINE:
        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI:
            result += " count: " + std::to_string(node->data.print_multi.count);
            break;
        case NODE_UMF_DEF:
            result += " name: " + std::string(node->data.umf_def.name) +
                      (node->data.umf_def.parent_name ? " parent: " + std::string(node->data.umf_def.parent_name) : "");
            break;
        case NODE_DESTRUCTURE:
        case NODE_DESTRUCTURE_ASSIGN:
            result += " vars: " + std::to_string(node->data.destructure.count) +
                      (node->data.destructure.rest_name ? " rest: " + std::string(node->data.destructure.rest_name) : "");
            break;
        case NODE_IMPORT:
            result += " file: " + std::string(node->data.import.filename) +
                      (node->data.import.alias ? " alias: " + std::string(node->data.import.alias) : "");
            break;
        case NODE_ENUM_DEF: {
            result += " name: " + std::string(node->data.enum_def.name) +
                        " variants: [";
            for (int i = 0; i < node->data.enum_def.variant_count; ++i) {
                if (i) result += ", ";
                result += node->data.enum_def.variants[i];
                if (node->data.enum_def.variant_param_counts &&
                    node->data.enum_def.variant_param_counts[i] > 0) {
                    result += "/" +
                                std::to_string(node->data.enum_def.variant_param_counts[i]);
                }
            }
            result += "]";
            break;
        }
        case NODE_ALIAS_DECL:
            result += " alias: " + std::string(node->data.alias_decl.name) +
                      " target: " + std::string(node->data.alias_decl.target) +
                      (node->data.alias_decl.global ? " global" : "");
            break;
        case NODE_KEY_BIND:
            result += " key: " + std::string(node->data.key_bind.key);
            break;
        case NODE_LAZY_VAR_DECL:
            result += " name: " + std::string(node->data.lazy_var_decl.name);
            break;
        case NODE_SICHER:
            result += " has_msg: " + std::to_string(node->data.sicher.msg_expr != nullptr);
            break;
        case NODE_SWAP_ASSIGN:
            result += " global: " + std::to_string(node->data.swap.global);
            break;
        case NODE_TRY:
            result += " has_catch: " + std::to_string(node->data.try_stmt.catch_body != nullptr) +
                      " has_finally: " + std::to_string(node->data.try_stmt.finally_body != nullptr);
            break;
        case NODE_THROW:
            break;
        case NODE_AWAIT:
            result += " has_timeout: " + std::to_string(node->data.await.timeout != nullptr) +
                      " has_fallback: " + std::to_string(node->data.await.fallback != nullptr);
            break;
        case NODE_STRING_INTERP:
            result += " fragments: " + std::to_string(node->data.string_interp.count);
            break;
        case NODE_REGEX_LITERAL:
            result += " pattern: " + std::string(node->data.regex_lit.pattern) +
                      " flags: " + std::string(node->data.regex_lit.flags);
            break;
        case NODE_MULTI_ASSIGN:
            result += " left: " + std::to_string(node->data.multi_assign.left_count) +
                      " right: " + std::to_string(node->data.multi_assign.right_count);
            break;
        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            break;
        case NODE_PATTERN_BIND:
            result += " name: " + std::string(node->data.pattern_bind.name);
            break;
        case NODE_PATTERN_OBJECT:
            result += " keys: " + std::to_string(node->data.pattern_object.count);
            break;
        case NODE_PATTERN_VARIANT:
            result += " tag: " + std::string(node->data.pattern_variant.tag) +
                      " params: " + std::to_string(node->data.pattern_variant.param_count);
            break;
        case NODE_PATTERN_CONSTANT:
            {
                char* s = value_to_string(node->data.pattern_constant.constant);
                result += " value: " + std::string(s);
                free(s);
            }
            break;
        case NODE_PATTERN_OR:
            result += " patterns: " + std::to_string(node->data.pattern_or.count);
            break;
        case NODE_MARK_USED:
            result += " names: " + std::to_string(node->data.mark_used.count);
            break;
        case NODE_MARK_ALL_USED:
            break;
        case NODE_TYPE_DEF:
            result += " name: " + std::string(node->data.type_def.name) +
                      " members: " + std::to_string(node->data.type_def.member_count);
            break;
        case NODE_STRUCT_DEF:
            result += " name: " + std::string(node->data.struct_def.name) +
                      " fields: " + std::to_string(node->data.struct_def.field_count);
            break;
        case NODE_UNION_DEF:
            result += " name: " + std::string(node->data.union_def.name) +
                      " common: " + std::to_string(node->data.union_def.common_count) +
                      " variants: " + std::to_string(node->data.union_def.variant_count);
            break;
        case NODE_EXPR_STMT:
            result += " (expr)";
            break;
        default:
            break;
    }
    return result + "\n";
}

static void print_ast_filtered(ASTNode* node, int indent, int start_line, int end_line) {
    if (!node) return;

    // 如果节点行号在范围内，打印当前节点摘要
    bool in_range = (start_line == 0 && end_line == 0) ||
                    (node->line >= start_line && node->line <= end_line);
    if (in_range) {
        std::string line = ast_node_to_string(node, indent);
        printf("%s", line.c_str());
    }

    // 递归处理所有子节点（无论当前节点是否在范围内）
    switch (node->type) {
        case NODE_PROGRAM:
        case NODE_BLOCK:
        case NODE_SCOPE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            for (int i = 0; i < node->data.block.count; ++i)
                print_ast_filtered(node->data.block.stmts[i], indent + 2, start_line, end_line);
            break;

        case NODE_VAR_DECL:
            print_ast_filtered(node->data.var_decl.expr, indent + 2, start_line, end_line);
            break;

        case NODE_ASSIGN:
            print_ast_filtered(node->data.assign.expr, indent + 2, start_line, end_line);
            break;

        case NODE_PRINT:
        case NODE_PRINT_NO_NEWLINE:
            print_ast_filtered(node->data.print.expr, indent + 2, start_line, end_line);
            break;

        case NODE_INPUT:
            for (int i = 0; i < node->data.input.arg_count; ++i)
                print_ast_filtered(node->data.input.args[i], indent + 2, start_line, end_line);
            if (node->data.input.multiline_expr)
                print_ast_filtered(node->data.input.multiline_expr, indent + 2, start_line, end_line);
            break;

        case NODE_IF:
            print_ast_filtered(node->data.if_stmt.cond, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.if_stmt.then_block, indent + 2, start_line, end_line);
            for (int i = 0; i < node->data.if_stmt.else_if_count; ++i)
                print_ast_filtered(node->data.if_stmt.else_ifs[i], indent + 2, start_line, end_line);
            if (node->data.if_stmt.else_block)
                print_ast_filtered(node->data.if_stmt.else_block, indent + 2, start_line, end_line);
            break;

        case NODE_WHILE:
            print_ast_filtered(node->data.while_stmt.cond, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.while_stmt.body, indent + 2, start_line, end_line);
            break;

        case NODE_DO_WHILE:
            print_ast_filtered(node->data.do_while.body, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.do_while.cond, indent + 2, start_line, end_line);
            break;

        case NODE_FOR:
            if (node->data.for_stmt.init)
                print_ast_filtered(node->data.for_stmt.init, indent + 2, start_line, end_line);
            if (node->data.for_stmt.cond)
                print_ast_filtered(node->data.for_stmt.cond, indent + 2, start_line, end_line);
            if (node->data.for_stmt.update)
                print_ast_filtered(node->data.for_stmt.update, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.for_stmt.body, indent + 2, start_line, end_line);
            break;

        case NODE_FOREACH:
            print_ast_filtered(node->data.foreach.collection, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.foreach.body, indent + 2, start_line, end_line);
            break;

        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF:
            for (int i = 0; i < node->data.func_def.param_count; ++i)
                if (node->data.func_def.param_defaults[i])
                    print_ast_filtered(node->data.func_def.param_defaults[i], indent + 2, start_line, end_line);
            print_ast_filtered(node->data.func_def.body, indent + 2, start_line, end_line);
            break;

        case NODE_FUNC_CALL:
            if (node->data.func_call.func_expr)
                print_ast_filtered(node->data.func_call.func_expr, indent + 2, start_line, end_line);
            for (int i = 0; i < node->data.func_call.arg_count; ++i)
                print_ast_filtered(node->data.func_call.args[i], indent + 2, start_line, end_line);
            break;

        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT:
            print_ast_filtered(node->data.binary.left, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.binary.right, indent + 2, start_line, end_line);
            break;

        case NODE_RETURN:
            if (node->data.ret.expr)
                print_ast_filtered(node->data.ret.expr, indent + 2, start_line, end_line);
            break;

        case NODE_ARRAY_LITERAL:
            for (int i = 0; i < node->data.array_lit.count; ++i)
                print_ast_filtered(node->data.array_lit.elems[i], indent + 2, start_line, end_line);
            break;

        case NODE_ARRAY_ACCESS:
            print_ast_filtered(node->data.array_access.array, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.array_access.index, indent + 2, start_line, end_line);
            break;

        case NODE_ARRAY_LEN:
            print_ast_filtered(node->data.array_len.array, indent + 2, start_line, end_line);
            break;

        case NODE_STRING_ACCESS:
            print_ast_filtered(node->data.string_access.str, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.string_access.index, indent + 2, start_line, end_line);
            break;

        case NODE_STRING_LEN:
            print_ast_filtered(node->data.string_len.str, indent + 2, start_line, end_line);
            break;

        case NODE_NOT:
            print_ast_filtered(node->data.not_expr.expr, indent + 2, start_line, end_line);
            break;

        case NODE_LOGICAL_AND:
        case NODE_LOGICAL_OR:
            print_ast_filtered(node->data.logical_and.left, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.logical_and.right, indent + 2, start_line, end_line);
            break;

        case NODE_ARRAY_ASSIGN:
            print_ast_filtered(node->data.array_assign.index, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.array_assign.expr, indent + 2, start_line, end_line);
            break;

        case NODE_METHOD_CALL:
            print_ast_filtered(node->data.method_call.obj, indent + 2, start_line, end_line);
            for (int i = 0; i < node->data.method_call.arg_count; ++i)
                print_ast_filtered(node->data.method_call.args[i], indent + 2, start_line, end_line);
            break;

        case NODE_EXPR_STMT:
            print_ast_filtered(node->data.expr_stmt.expr, indent + 2, start_line, end_line);
            break;

        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
        case NODE_DOUBLE_FACTORIAL:
        case NODE_BITWISE_NOT:
            print_ast_filtered(node->data.inc_dec.operand, indent + 2, start_line, end_line);
            break;

        case NODE_TERNARY:
            print_ast_filtered(node->data.ternary.cond, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.ternary.true_expr, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.ternary.false_expr, indent + 2, start_line, end_line);
            break;

        case NODE_ARRAY_COMPOUND_ASSIGN:
            print_ast_filtered(node->data.array_compound_assign.index, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.array_compound_assign.rhs, indent + 2, start_line, end_line);
            break;

        case NODE_TRY:
            print_ast_filtered(node->data.try_stmt.try_body, indent + 2, start_line, end_line);
            if (node->data.try_stmt.catch_body)
                print_ast_filtered(node->data.try_stmt.catch_body, indent + 2, start_line, end_line);
            if (node->data.try_stmt.finally_body)
                print_ast_filtered(node->data.try_stmt.finally_body, indent + 2, start_line, end_line);
            break;

        case NODE_THROW:
            print_ast_filtered(node->data.throw_expr.expr, indent + 2, start_line, end_line);
            break;

        case NODE_OBJECT_LITERAL:
            for (int i = 0; i < node->data.object_lit.count; ++i) {
                print_ast_filtered(node->data.object_lit.key_exprs[i], indent + 2, start_line, end_line);
                print_ast_filtered(node->data.object_lit.vals[i], indent + 2, start_line, end_line);
            }
            for (int i = 0; i < node->data.object_lit.spread_count; ++i)
                print_ast_filtered(node->data.object_lit.spreads[i], indent + 2, start_line, end_line);
            break;

        case NODE_OBJECT_ACCESS:
            print_ast_filtered(node->data.object_access.obj, indent + 2, start_line, end_line);
            break;

        case NODE_OBJECT_ASSIGN:
            print_ast_filtered(node->data.object_assign.obj, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.object_assign.value, indent + 2, start_line, end_line);
            break;
        
        case NODE_OBJECT_COMPOUND_ASSIGN:
            print_ast_filtered(node->data.object_compound_assign.obj, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.object_compound_assign.rhs, indent + 2, start_line, end_line);
            break;

        case NODE_NULL_COALESCE:
            print_ast_filtered(node->data.null_coalesce.left, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.null_coalesce.right, indent + 2, start_line, end_line);
            break;

        case NODE_PIPE:
            print_ast_filtered(node->data.pipe.left, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.pipe.right, indent + 2, start_line, end_line);
            break;

        case NODE_RANGE:
            print_ast_filtered(node->data.range.start, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.range.end, indent + 2, start_line, end_line);
            if (node->data.range.step)
                print_ast_filtered(node->data.range.step, indent + 2, start_line, end_line);
            break;

        case NODE_LIST_COMPREHENSION:
            print_ast_filtered(node->data.list_comp.expr, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.list_comp.collection, indent + 2, start_line, end_line);
            if (node->data.list_comp.cond)
                print_ast_filtered(node->data.list_comp.cond, indent + 2, start_line, end_line);
            break;

        case NODE_LAZY_VAR_DECL:
            print_ast_filtered(node->data.lazy_var_decl.expr, indent + 2, start_line, end_line);
            break;

        case NODE_SICHER:
            print_ast_filtered(node->data.sicher.expr, indent + 2, start_line, end_line);
            if (node->data.sicher.msg_expr)
                print_ast_filtered(node->data.sicher.msg_expr, indent + 2, start_line, end_line);
            break;

        case NODE_SWAP_ASSIGN:
            print_ast_filtered(node->data.swap.left, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.swap.right, indent + 2, start_line, end_line);
            break;

        case NODE_MATCH:
            print_ast_filtered(node->data.match.expr, indent + 2, start_line, end_line);
            for (int i = 0; i < node->data.match.branch_count; ++i) {
                print_ast_filtered(node->data.match.branches[i].pattern, indent + 2, start_line, end_line);
                if (node->data.match.branches[i].guard)
                    print_ast_filtered(node->data.match.branches[i].guard, indent + 2, start_line, end_line);
                print_ast_filtered(node->data.match.branches[i].body, indent + 2, start_line, end_line);
            }
            break;

        case NODE_AWAIT:
            print_ast_filtered(node->data.await.expr, indent + 2, start_line, end_line);
            if (node->data.await.timeout)
                print_ast_filtered(node->data.await.timeout, indent + 2, start_line, end_line);
            if (node->data.await.fallback)
                print_ast_filtered(node->data.await.fallback, indent + 2, start_line, end_line);
            break;

        case NODE_KEY_BIND:
            print_ast_filtered(node->data.key_bind.body, indent + 2, start_line, end_line);
            break;

        case NODE_DESTRUCTURE:
        case NODE_DESTRUCTURE_ASSIGN:
            print_ast_filtered(node->data.destructure.expr, indent + 2, start_line, end_line);
            break;

        case NODE_CLASS_DEF:
            if (node->data.class_def.ctor_body)
                print_ast_filtered(node->data.class_def.ctor_body, indent + 2, start_line, end_line);
            for (int i = 0; i < node->data.class_def.methods.count; ++i)
                print_ast_filtered(node->data.class_def.methods.bodies[i], indent + 2, start_line, end_line);
            for (int i = 0; i < node->data.class_def.properties.count; ++i)
                if (node->data.class_def.properties.default_exprs[i])
                    print_ast_filtered(node->data.class_def.properties.default_exprs[i], indent + 2, start_line, end_line);
            break;

        case NODE_NEW:
            for (int i = 0; i < node->data.new_expr.arg_count; ++i)
                print_ast_filtered(node->data.new_expr.args[i], indent + 2, start_line, end_line);
            break;

        case NODE_SUPER_CALL:
            for (int i = 0; i < node->data.super_call.arg_count; ++i)
                print_ast_filtered(node->data.super_call.args[i], indent + 2, start_line, end_line);
            break;

        case NODE_PRINT_WITH_LINE:
            print_ast_filtered(node->data.print_with_line.expr, indent + 2, start_line, end_line);
            print_ast_filtered(node->data.print_with_line.line, indent + 2, start_line, end_line);
            break;

        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI:
            for (int i = 0; i < node->data.print_multi.count; ++i)
                print_ast_filtered(node->data.print_multi.exprs[i], indent + 2, start_line, end_line);
            break;

        case NODE_UMF_DEF:
            print_ast_filtered(node->data.umf_def.body, indent + 2, start_line, end_line);
            break;

        case NODE_MULTI_ASSIGN:
            for (int i = 0; i < node->data.multi_assign.right_count; ++i)
                print_ast_filtered(node->data.multi_assign.right_exprs[i], indent + 2, start_line, end_line);
            break;

        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            print_ast_filtered(node->data.spread.expr, indent + 2, start_line, end_line);
            break;

        case NODE_STRING_INTERP:
            for (int i = 0; i < node->data.string_interp.count; ++i)
                print_ast_filtered(node->data.string_interp.fragments[i], indent + 2, start_line, end_line);
            break;

        case NODE_TYPE_DEF:
            for (int i = 0; i < node->data.type_def.member_count; ++i)
                print_ast_filtered(node->data.type_def.members[i], indent + 2, start_line, end_line);
            break;

        // 以下类型无子节点或已处理
        case NODE_NULL:
        case NODE_NUMBER:
        case NODE_FLOAT:
        case NODE_STRING:
        case NODE_VARIABLE:
        case NODE_BREAK:
        case NODE_CONTINUE:
        case NODE_THIS:
        case NODE_REGEX_LITERAL:
        case NODE_ENUM_DEF:     // 枚举定义无子节点（变体名等已存储）
        case NODE_ALIAS_DECL:
        case NODE_IMPORT:
        case NODE_PATTERN_BIND:
        case NODE_PATTERN_OBJECT:
        case NODE_PATTERN_VARIANT:
        case NODE_PATTERN_CONSTANT:
        case NODE_PATTERN_OR:
        case NODE_MARK_USED:
        case NODE_MARK_ALL_USED:
        case NODE_STRUCT_DEF:
        case NODE_UNION_DEF:
        default:
            break;
    }
}

static std::string serialize_value_for_export(const Value& v, std::unordered_map<const void*, int>& visited) {
    // 用地址作为标记（仅对对象/数组有效）
    const void* addr = nullptr;
    if (v.type == VAL_ARRAY) addr = (const void*)v.arr_val.elements;
    else if (v.type == VAL_OBJECT) addr = (const void*)v.obj_val.entries;
    if (addr && visited.find(addr) != visited.end()) {
        return "null"; // 循环引用，输出 null
    }
    if (addr) visited[addr] = 1;

    std::string result;
    switch (v.type) {
        case VAL_NULL: return "null";
        case VAL_INT64: return std::to_string(v.int64_val);
        case VAL_INT: {
            char* s = mpz_get_str(nullptr, 10, *v.big_int);
            std::string out(s);
            free(s);
            return out;
        }
        case VAL_FLOAT: {
            char* s = value_to_string(v);
            std::string out(s);
            free(s);
            return out;
        }
        case VAL_STRING: {
            std::string escaped;
            for (char c : std::string(v.str_val, v.str_len)) {
                if (c == '"') escaped += "\\\"";
                else if (c == '\\') escaped += "\\\\";
                else if (c == '\n') escaped += "\\n";
                else if (c == '\r') escaped += "\\r";
                else if (c == '\t') escaped += "\\t";
                else escaped += c;
            }
            return "\"" + escaped + "\"";
        }
        case VAL_ARRAY: {
            result = "[";
            for (int i = 0; i < v.arr_val.length; ++i) {
                if (i) result += ",";
                result += serialize_value_for_export(v.arr_val.elements[i], visited);
            }
            result += "]";
            break;
        }
        case VAL_OBJECT: {
            result = "{";
            bool first = true;
            for (int i = 0; i < v.obj_val.count; ++i) {
                const char* key = v.obj_val.entries[i].key;
                // 跳过内部标记（__开头）
                if (key[0] == '_' && key[1] == '_') continue;
                if (!first) result += ",";
                first = false;
                // 键转义
                std::string escaped_key;
                for (char c : std::string(key)) {
                    if (c == '"') escaped_key += "\\\"";
                    else if (c == '\\') escaped_key += "\\\\";
                    else if (c == '\n') escaped_key += "\\n";
                    else if (c == '\r') escaped_key += "\\r";
                    else if (c == '\t') escaped_key += "\\t";
                    else escaped_key += c;
                }
                result += "\"" + escaped_key + "\":";
                result += serialize_value_for_export(v.obj_val.entries[i].value, visited);
            }
            result += "}";
            break;
        }
        default:
            return "null";
    }
    if (addr) visited.erase(addr);
    return result;
}

std::string export_global_values() {
    Scope* gs = get_global_scope();
    if (!gs) return "{}";
    std::unordered_map<const void*, int> visited;
    std::string json = "{";
    bool first = true;
    for (int i = 0; i < gs->var_count; ++i) {
        Variable* var = &gs->vars[i];
        if (var->is_alias) continue;
        // 只导出可序列化的类型
        if (var->value.type != VAL_NULL && var->value.type != VAL_INT64 &&
            var->value.type != VAL_INT && var->value.type != VAL_FLOAT &&
            var->value.type != VAL_STRING && var->value.type != VAL_ARRAY &&
            var->value.type != VAL_OBJECT) continue;
        if (!first) json += ",";
        first = false;
        std::string key = var->name;
        std::string escaped_key;
        for (char c : key) {
            if (c == '"') escaped_key += "\\\"";
            else if (c == '\\') escaped_key += "\\\\";
            else if (c == '\n') escaped_key += "\\n";
            else if (c == '\r') escaped_key += "\\r";
            else if (c == '\t') escaped_key += "\\t";
            else escaped_key += c;
        }
        json += "\"" + escaped_key + "\":";
        json += serialize_value_for_export(var->value, visited);
    }
    json += "}";
    return json;
}

void import_global_values(const std::string& json) {
    if (json.empty() || json == "{}") return;
    Scope* gs = get_global_scope();
    if (!gs) return;
    JSONParser parser(json);
    Value obj = parser.parse();
    if (obj.type != VAL_OBJECT) return;
    for (int i = 0; i < obj.obj_val.count; ++i) {
        const char* key = obj.obj_val.entries[i].key;
        Value val = obj.obj_val.entries[i].value;
        // 忽略不可导入的类型（函数、future 等）
        if (val.type == VAL_FUNCTION || val.type == VAL_FUTURE) continue;
        int idx = get_var_index_in_scope(gs, key);
        if (idx >= 0) {
            Variable* var = &gs->vars[idx];
            free_value(&var->value);
            var->value = copy_value(val);
        } else {
            declare_var_in_scope(gs, key, false, copy_value(val));
        }
    }
    free_value(&obj);
}

std::string getCurrentDirectoryStr() {
    try {
        return fs::current_path().string();
    }
    catch (const std::exception& e) {
        std::cerr << "错误：获取当前目录失败：" << e.what() << '\n';
        return "";
    }
}

// 校验目录输入，错误直接cerr输出
bool checkDirectoryInput(const std::string& userInput, fs::path& outPath) {
    if (userInput.empty()) {
        std::cerr << "错误：输入不能为空！\n";
        return false;
    }

    outPath = fs::path(userInput);

    try {
        if (!fs::exists(outPath)) {
            std::cerr << "错误：路径不存在 -> " << userInput << '\n';
            return false;
        }

        if (!fs::is_directory(outPath)) {
            std::cerr << "错误：该路径不是目录 -> " << userInput << '\n';
            return false;
        }
    }
    catch (const std::exception& e) {
        std::cerr << "错误：访问路径异常：" << e.what() << '\n';
        return false;
    }

    return true;
}

// 辅助：分割一行输入为参数vector（代替argv）
std::vector<std::string> splitArgs(const std::string& line) {
    std::vector<std::string> args;
    std::istringstream iss(line);
    std::string token;
    while (iss >> token)
    {
        args.push_back(token);
    }
    return args;
}

// 把参数解析抽出来，复用；返回 true=解析成功；false=出错退出
bool parse_args(const std::vector<std::string>& args,
    bool& opt_zeit,
    bool& opt_set,
    bool& version_show,
    std::vector<Value>& opt_args,
    std::string& opt_haupt,
    std::string& opt_klass,
    bool& opt_print_ast,
    bool& lex_only,
    int& ast_start_line,
    int& ast_end_line,
    bool& interactive,
    std::string& filename,
    std::vector<std::string>& g_command_args,
    bool& debug_macro)
{
    // 重置所有状态，每次解析参数前清空
    opt_zeit = false;
    opt_set = false;
    version_show = false;
    opt_args.clear();
    opt_haupt.clear();
    opt_klass.clear();
    opt_print_ast = false;
    lex_only = false;
    ast_start_line = 0;
    ast_end_line = 0;
    interactive = false;
    filename.clear();
    g_command_args.clear();
    debug_macro = false;

    for (int i = 0; i < (int)args.size(); ++i) {
        const std::string& arg = args[i];
        if (arg == "--hilfe" || arg == "--h") {
            printf("\n\033[93m----------------------\n"
                "Kernregel v%d.%d.%d\n"
                "----------------------\033[0m\n"
                "\n"
                "\033[36mVerwendung:\033[0m\n"
                "  %s <Datei.kr>    – Führt die Kernregel-Quelldatei aus.\n"
                "  %s -k            – Startet den interaktiven Modus, liest mehrzeiliges Skript bis EOF (Strg+D / Strg+Z / Eingeben \"--ende\").\n"
                "\n"
                "\033[36mOptionen:\033[0m\n"
                "  --hilfe, --h     – Zeigt diese Hilfe an.\n"
                "  --opt \"...\"    - Benutzerdefinierte Ausführungsoptionen\n"
                "  --lex            – Nur lexikalische Analyse, gibt Fehler als JSON aus.\n"
                "  -k, --k          – Startet den interaktiven Modus.\n"
                "  -p, --p          – Zeigt den absoluten Pfad des ausführenden Programms an.\n"
                "  -w, --warn       – Warnungen aktivieren (standardmäßig aus; Warnungen auf bestimmten Ebenen können nicht ausgeblendet werden)\n"
                "  -v, --vor <N>    – Zeigt N Zeilen oberhalb der Fehlerzeile (Standard: 4).\n"
                "  -n, --nach <M>   – Zeigt M Zeilen unterhalb der Fehlerzeile (Standard: 4).\n"
                "\n"
                "\033[36m--- Schlüsselwörter (nach Kategorien) ---\033[0m\n"
                "\n"
                "\033[33m1. Anweisungen (Kontrollfluss, Deklarationen, etc.):\033[0m\n"
                "   Bedingungen: fa, snfa, sonst\n"
                "   Schleifen: indes, für, bruch/break, fortset/weiter\n"
                "   Funktionen: fkt, ac fkt, kernregel\n"
                "   Variablen: der, das, des, global, faul\n"
                "   Ein-/Ausgabe: lies, zeig, schr\n"
                "   Fehlerbehandlung: ver, den, die, dem, sicher\n"
                "   Rückgabe: gib\n"
                "   Module: imp\n"
                "   Aufzählung: aufz\n"
                "   Klassen: klass, konstr, methode, neu, ober, dies\n"
                "   Async: warte\n"
                "   Tasten: bind\n"
                "   Typalias: typ\n"
                "   Namensbereiche: umf\n"
                "\n"
                "\033[33m2. Eingebaute Funktionen (global):\033[0m\n"
                "   Mathematik: sqrt/wurz, cbrt/kub, abs/btr, sin, cos, rand/zuf, srand/setze\n"
                "   Analysis: abl, inte, ab2, simp, grad, nullst, euler\n"
                "   Zeichenketten: trim, ersetze/ers, teil, enthält/hat, fängtAnMit/beg, abschnitt/ab, stelleVon/wo, letzteStelleVon/letzt, alsZahl/alz, alsText/alt, format\n"
                "   Dateien: leseDatei/lese, leseBin, schrd\n"
                "   Zeit: sleep, zeit, datum\n"
                "   Bildschirm: loesch, aktu, zeigAlle\n"
                "   Tasten: drücke, taste, ac_taste, taste_gedrueckt/tg\n"
                "   Prozess: ausf/ausführen, ac_ausf\n"
                "   HTTP: ANFR, ac_ANFR, starteServer, ac_starteServer\n"
                "   KD-Datensätze: ladeKD, schrKD, erneuKD, loesKD, suchKD, siebeKD, alleKD, zaehleKD, verschlKD, entschlKD\n"
                "   Debug: tokens, worte, zeile, bytes, kodierBase64\n"
                "   Sonstiges: umf\n"
                "\n"
                "\033[33m3. Methoden (für Objekte):\033[0m\n"
                "   Zeichenketten: passende/pass, ersetze/ers, teil, enthält/hat, fängtAnMit/beg, abschnitt/ab, stelleVon/wo, letzteStelleVon/letzt, trim, alsZahl/alz, alsText/alt\n"
                "   Arrays: hinzufügen/anf, finde, findeIndex/idx, map, filter, reduz\n"
                "   Zahlen: alsText/alt, runden\n"
                "   KD-Datensätze: hole, sucheTag, sucheTyp, kinder, komprim\n"
                "   Regeln: wert, setZweck, stop\n"
                "\n"
                "\033[36mHinweis:\033[0m Ausführliche Syntaxbeispiele und Dokumentation findest du in der beiliegenden Dokumentation.\n"
                "\n", MAJOR, MINOR, PATCH, args[0].c_str(), args[0].c_str());
            return false;
        }
        else if (arg == "-p" || arg == "--p") {
            printf("%s\n", exe_dir.string().c_str());
            return false;
        }
        else if (arg == "-k" || arg == "--k") {
            interactive = true;
        }
        else if (arg == "-d" || arg == "--debug") {
            debug_macro = true;
        }
        else if (arg == "-w" || arg == "--warn") {
            g_warnings_enabled = true;
        }
        else if (arg == "-v" || arg == "--vor") {
            if (i + 1 < (int)args.size()) {
                int val = atoi(args[++i].c_str());
                g_context_before = (val >= 0) ? val : 0;
            } else {
                fprintf(stderr, "Fehler: -v benötigt eine Zahl.\n");
                return false;
            }
        }
        else if (arg == "-ver" || arg == "--version") {
            version_show = true;
        }
        else if (arg == "-n" || arg == "--nach") {
            if (i + 1 < (int)args.size()) {
                int val = atoi(args[++i].c_str());
                g_context_after = (val >= 0) ? val : 0;
            } else {
                fprintf(stderr, "Fehler: -n benötigt eine Zahl.\n");
                return false;
            }
        }
        else if (arg == "-t" || arg == "--zeit") {
            opt_zeit = true;
        }
        else if (arg == "-O") {
            g_optimize_for_loops = true;
        }
        else if (arg == "-i") {
            g_compile_mode = false;
        }
        else if (arg == "--verf") {
            g_trace_ast = true;
        }
        else if (arg == "--lex") {
            lex_only = true;
        }
        else if (arg == "--ast") {
            opt_print_ast = true;
        }
        else if (arg == "--opt") {
            if (i + 1 >= (int)args.size()) {
                fprintf(stderr, "Fehler: --opt benötigt ein Objekt-Argument.\n");
                return false;
            }
            std::string opt_arg = args[++i];
            auto trim = [](std::string& s) {
                s.erase(0, s.find_first_not_of(" \t\n\r"));
                s.erase(s.find_last_not_of(" \t\n\r") + 1);
            };
            trim(opt_arg);
            if (opt_arg.front() != '{' || opt_arg.back() != '}') {
                fprintf(stderr, "Fehler: --opt Argument muss {}-Objekt sein.\n");
                return false;
            }
            opt_arg = opt_arg.substr(1, opt_arg.size() - 2);
            std::stringstream ss(opt_arg);
            std::string pair;
            while (std::getline(ss, pair, ',')) {
                trim(pair);
                size_t colon = pair.find(':');
                if (colon == std::string::npos) {
                    fprintf(stderr, "Fehler: Ungültiges Schlüssel-Wert-Paar: %s\n", pair.c_str());
                    return false;
                }
                std::string key = pair.substr(0, colon);
                std::string val = pair.substr(colon + 1);
                trim(key); trim(val);
                if (key == "haupt") {
                    opt_haupt = val;
                    opt_set = true;
                } else if (key == "klass") {
                    opt_klass = val;
                } else if (key == "args") {
                    try {
                        JSONParser parser(val);
                        Value args_val = parser.parse();
                        if (args_val.type != VAL_ARRAY) {
                            fprintf(stderr, "Fehler: --opt args muss Array sein.\n");
                            return false;
                        }
                        opt_args.reserve(args_val.arr_val.length);
                        for (int j = 0; j < args_val.arr_val.length; ++j)
                            opt_args.push_back(copy_value(args_val.arr_val.elements[j]));
                        free_value(&args_val);
                    } catch (const KRError& e) {
                        fprintf(stderr, "Fehler beim Parsen von args: %s\n", e.what());
                        return false;
                    }
                } else if (key == "ast") {
                    if (val == "wahr") {
                        opt_print_ast = true;
                    } else if (val == "fals") {
                        opt_print_ast = false;
                    } else if (val.front() == '{') {
                        try {
                            JSONParser parser(val);
                            Value ast_obj = parser.parse();
                            if (ast_obj.type == VAL_OBJECT) {
                                for (int j = 0; j < ast_obj.obj_val.count; ++j) {
                                    const char* k = ast_obj.obj_val.entries[j].key;
                                    Value v = ast_obj.obj_val.entries[j].value;
                                    if (strcmp(k, "st") == 0 && (v.type == VAL_INT || v.type == VAL_INT64)) {
                                        ast_start_line = (int)value_to_ll(v);
                                    } else if (strcmp(k, "end") == 0 && (v.type == VAL_INT || v.type == VAL_INT64)) {
                                        ast_end_line = (int)value_to_ll(v);
                                    }
                                }
                                opt_print_ast = true;
                                free_value(&ast_obj);
                            }
                        } catch (const KRError& e) {
                            fprintf(stderr, "Fehler beim Parsen von ast: %s\n", e.what());
                            return false;
                        }
                    } else {
                        fprintf(stderr, "Warnung: Ungültiger Wert für 'ast', ignoriert.\n");
                    }
                } else if (key == "verf") {
                    if (val == "wahr" || val == "true") {
                        g_trace_ast = true;
                    } else if (val == "fals" || val == "false") {
                        g_trace_ast = false;
                    } else {
                        fprintf(stderr, "Fehler: --opt verf muss wahr/fals sein.\n");
                        return false;
                    }
                } else {
                    fprintf(stderr, "Warnung: Unbekannter Schlüssel '%s' ignoriert.\n", key.c_str());
                }
            }
        }
        else {
            // 非选项参数
            if (interactive) {
                g_command_args.push_back(arg);
            } else {
                if (filename.empty()) {
                    filename = arg;
                } else {
                    g_command_args.push_back(arg);
                }
            }
        }
    }
    return true;
}

// 辅助函数：把一行输入字符串切割成参数列表（简单空格分割）
std::vector<std::string> split_args(const std::string& line) {
    std::vector<std::string> res;
    std::stringstream ss(line);
    std::string tok;
    while (ss >> tok) {
        res.push_back(tok);
    }
    return res;
}

int main(int argc, char* argv[]) {
    #if defined(_WIN32) || defined(_WIN64)
        SetConsoleOutputCP(CP_UTF8);
        SetConsoleCP(CP_UTF8);
    #endif
    std::ios::sync_with_stdio(false);
    struct ScopedTimer {
        bool enabled;
        std::chrono::steady_clock::time_point start;
        ScopedTimer(bool enable) : enabled(enable),
            start(enable ? std::chrono::steady_clock::now() : std::chrono::steady_clock::time_point{}) {}
        ~ScopedTimer() {
            if (!enabled) return;
            auto end = std::chrono::steady_clock::now();
            auto elapsed_ms = std::chrono::duration<double, std::milli>(end - start).count();

            char tmp[96];
            int n = std::snprintf(tmp, sizeof(tmp),
                "\033[32m[Debug]\033[0m Ausführungszeit: %.3f ms\n",
                elapsed_ms);
            if (n > 0) fastout::write(tmp, static_cast<size_t>(n));
            fastout::flush();
        }
    };
    bool opt_zeit = false;
    bool opt_set = false;
    bool version_show = false;
    std::vector<Value> opt_args;
    std::string opt_haupt;
    std::string opt_klass;
    bool opt_print_ast = false;
    bool lex_only = false;
    int ast_start_line = 0;
    int ast_end_line = 0;
    bool interactive = false;
    bool debug_macro = false;
    std::string filename;
    std::vector<std::string> g_command_args;

    std::atexit(kr_cleanup);
#ifdef _WIN32
    wchar_t wpath[MAX_PATH];
    GetModuleFileNameW(NULL, wpath, MAX_PATH);
    exe_dir = fs::path(wpath).parent_path();
#else
    char path[PATH_MAX];
    ssize_t len = readlink("/proc/self/exe", path, sizeof(path)-1);
    if (len != -1) {
        path[len] = '\0';
        exe_dir = fs::u8path(path).parent_path();
    }
#endif
    main_thread_id = std::this_thread::get_id();

    std::vector<std::string> init_args;
    for (int i = 1; i < argc; ++i) init_args.push_back(argv[i]);
    bool parse_ok = parse_args(init_args, opt_zeit, opt_set, version_show, opt_args, opt_haupt, opt_klass, opt_print_ast, lex_only, ast_start_line, ast_end_line, interactive, filename, g_command_args, debug_macro);
    if (!parse_ok) {
        return 0;
    }

    bool run_loop = filename.empty() && !interactive && !version_show;
    if (run_loop) printf("[Kernregel v%d.%d.%d] Geben Sie Parameter ein (z.B. test.kr --zeit), eingabe 'ende' zum Beenden:", MAJOR, MINOR, PATCH);
    std::string realPath = fs::current_path().string();
    while (run_loop) {
        std::cout << "\n" << realPath << "> ";
        std::string line;
        if (!std::getline(std::cin, line)) {
            break;
        }
        std::vector<std::string> args = splitArgs(line);
        if (args.empty()) continue; // 空输入跳过
        if (line == "ende") {
            return 0;
        } else if (args[0] == "cd" || args[0] == "zu") {
            if (args.size() < 2) {
                std::cout << realPath << '\n';
            } else {
                fs::path targetDir;
                if (checkDirectoryInput(args[1], targetDir)) {
                    fs::current_path(targetDir);
                    // 更新提示符路径
                    realPath = getCurrentDirectoryStr();
                }
            }
            continue;
        }
        // 分割输入行为参数列表
        auto user_args = split_args(line);
        if (user_args.empty()) {
            continue;
        }
        // 解析用户输入的参数
        parse_ok = parse_args(user_args, opt_zeit, opt_set, version_show, opt_args, opt_haupt, opt_klass, opt_print_ast, lex_only, ast_start_line, ast_end_line, interactive, filename, g_command_args, debug_macro);
        if (!parse_ok) {
            continue;
        }
        if (version_show) {
            fprintf(stderr, "Kernregel (%s) v%d.%d.%d\n", argv[0], MAJOR, MINOR, PATCH);
            version_show = false;
            continue;
        }
    
        bool file_missing = false;
        if (!filename.empty() && !interactive) {
            std::filesystem::path p(filename);
            if (!std::filesystem::exists(p) || !std::filesystem::is_regular_file(p)) {
                fprintf(stderr, "Fehler: '%s' Weder ein Befehl noch eine Datei, die geöffnet werden kann.\nHinweis: Gib --h oder --hilfe ein, um Hilfe anzuzeigen.\n", filename.c_str());
                file_missing = true;
            }
        }
        if (file_missing) {
            // 文件不存在：不跳出run_loop，回到提示符
            continue;
        }
    
        run_loop = false;
    }
    
    if (filename.empty() && !interactive) {
        return 0;
    }

    char* script_content = nullptr;
    if (interactive) {
        if (!filename.empty()) {
            fprintf(stderr, "Fehler: -k darf nicht mit einer Datei kombiniert werden.\n");
            return 1;
        }
        printf("\033[93m----------------------\n"
            "Kernregel v%d.%d.%d\n"
            "----------------------\033[0m\n", MAJOR, MINOR, PATCH);
        fflush(stdout);
        std::string full_input;
        std::string line;
        while (std::getline(std::cin, line)) {
            if (line == "--ende") break;
            full_input += line;
            full_input += '\n';
        }
        if (full_input.empty()) {
            fprintf(stderr, "Fehler: Keine Eingabe.\n");
            return 1;
        }
        script_content = strdup(full_input.c_str());
    }
    else if (version_show) {
        fprintf(stderr, "Kernregel (%s) v%d.%d.%d\n", argv[0], MAJOR, MINOR, PATCH);
        return 0;
    }

    register_system_macros();

    if (debug_macro) {
        def_stream("DEBUG", "1");
    }

    curl_global_init(CURL_GLOBAL_DEFAULT);
    mpf_set_default_prec(1024);
    atexit(curl_global_cleanup);
    ASTNode* prog = nullptr;
    char* source = nullptr;
    ScopedTimer timer(opt_zeit);
    try {
        std::string source_str;
        std::string base_dir;
        if (interactive) {
            printf("\033[33m--- Ende der Kommando ---\033[0m\n");
            source_str = script_content;
            current_filename = "<cmdline>";
            base_dir = ".";
        } else {
            fs::path file_path(filename);
            std::ifstream ifs(file_path, std::ios::binary);
            if (!ifs) {
                kr_error("无法打开文件 '%s': %s", filename.c_str(), strerror(errno));
            }
            ifs.seekg(0, std::ios::end);
            std::streamsize len = ifs.tellg();
            ifs.seekg(0, std::ios::beg);
            char* buf = (char*)malloc((size_t)len + 1);
            ifs.read(buf, len);
            buf[len] = '\0';
            ifs.close();
            source_str = buf;
            free(buf);

            if (source_str.find_first_not_of(" \t\r\n") == std::string::npos) {
                if (interactive && script_content) free(script_content);
                return 0;
            }
            current_filename = filename.c_str();
            size_t pos = filename.find_last_of("/\\");
            base_dir = (pos != std::string::npos) ? filename.substr(0, pos) : ".";
        }

        std::unordered_map<std::string, std::vector<std::string>> alias_map;
        std::set<fs::path> visited;
        std::string expanded_source = expand_imports(source_str, base_dir, visited, alias_map,
            current_filename ? current_filename : "");

        std::string final_source = preprocess_source(expanded_source.c_str(), true, alias_map);
        source = strdup(final_source.c_str());
        source_code = source;
        tokenize_impl(final_source.c_str());
        srand((unsigned)time(nullptr));
        push_scope();
        original_global_scope = current_scope;
        prog = parse_program();
        if (lex_only) {
            check_undefined_symbols(prog);
            check_loop_levels(prog, 0);
            printf("{\"ok\":1,\"version\":\"%s\",\"makros\":%s}\n",
                lex_version_string().c_str(),
                macro_marks_to_json().c_str());
            return 0;
        }
        if (opt_print_ast) {
            if (ast_start_line == 0 && ast_end_line == 0) {
                printf("%s", ast_to_string(prog).c_str());
            } else {
                print_ast_filtered(prog, 0, ast_start_line, ast_end_line);
            }
            free_ast(prog);
            kr_cleanup();
            return 0;
        }

        if (original_global_scope) {
            Value argc_val = make_int((long long)g_command_args.size());
            declare_var_in_scope(original_global_scope, "arga", true, argc_val);

            Value* elems = (Value*)malloc((g_command_args.size() + 1) * sizeof(Value));
            elems[0] = make_string(argv[0] ? argv[0] : "");
            for (size_t i = 0; i < g_command_args.size(); ++i) {
                elems[i + 1] = make_string(g_command_args[i].c_str());
            }
            Value argw_val = make_array(elems, (int)(g_command_args.size() + 1));
            free(elems);
            declare_var_in_scope(original_global_scope, "argw", true, argw_val);

            get_var("arga");
            get_var("argw");
        }

        if (g_compile_mode) {
            Bytecode bytecode;
            prescan_func_defs(prog, bytecode);
            prescan_class_defs(prog, bytecode);
            prescan_namespace_defs(prog, bytecode);
            compile_statement(prog, bytecode);
            bytecode.code.push_back(OP_HALT);
            VM vm;
            Value result = vm.run(bytecode);
            free_value(&result);
            for (auto& c : bytecode.constants) {
                free_value(&c);
            }
        } else {
            exec_statement(prog);
        }

        if (opt_set) {
            bool old_return = return_caught;
            bool old_break = break_caught;
            bool old_continue = continue_caught;
            bool old_exception = exception_raised;
            Value old_return_val = copy_value(return_value);
            Value old_exception_val = copy_value(exception_value);

            return_caught = false;
            break_caught = false;
            continue_caught = false;
            exception_raised = false;

            Scope* old_scope = current_scope;
            current_scope = original_global_scope;

            try {
                Value result;
                if (!opt_klass.empty()) {
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    auto cls_it = class_table.find(opt_klass);
                    if (cls_it == class_table.end()) {
                        kr_error("Klasse '%s' nicht gefunden.", opt_klass.c_str());
                    }
                    ClassDef& cls = cls_it->second;
                    auto meth_it = cls.methods.find(opt_haupt);
                    if (meth_it == cls.methods.end()) {
                        kr_error("Methode '%s' nicht in Klasse '%s' gefunden.", opt_haupt.c_str(), opt_klass.c_str());
                    }
                    MethodDef& md = meth_it->second;
                    if (!md.is_static) {
                        kr_error("Methode '%s' in Klasse '%s' ist nicht statisch.", opt_haupt.c_str(), opt_klass.c_str());
                    }
                    Value func_val;
                    func_val.type = VAL_FUNCTION;
                    func_val.func_val.name = strdup(opt_haupt.c_str());
                    func_val.func_val.param_count = (int)md.params.size();
                    func_val.func_val.params = (char**)malloc(func_val.func_val.param_count * sizeof(char*));
                    for (int i = 0; i < func_val.func_val.param_count; ++i)
                        func_val.func_val.params[i] = strdup(md.params[i].c_str());
                    func_val.func_val.body = copy_ast(md.body);
                    func_val.func_val.closure_scope = current_scope;
                    func_val.func_val.is_memoized = false;
                    func_val.func_val.is_async = false;
                    func_val.func_val.global_scope = false;
                    func_val.func_val.is_rule = false;
                    func_val.func_val.return_type = copy_type_node(md.return_type);
                    func_val.func_val.vararg_name = md.vararg_name.empty() ? NULL : strdup(md.vararg_name.c_str());
                    func_val.func_val.param_is_const = (bool*)malloc(func_val.func_val.param_count * sizeof(bool));
                    func_val.func_val.param_defaults = (ASTNode**)malloc(func_val.func_val.param_count * sizeof(ASTNode*));
                    for (int i = 0; i < func_val.func_val.param_count; ++i) {
                        func_val.func_val.param_is_const[i] = false;
                        func_val.func_val.param_defaults[i] = NULL;
                    }
                    func_val.func_val.param_types = (TypeNode**)malloc(func_val.func_val.param_count * sizeof(TypeNode*));
                    for (int i = 0; i < func_val.func_val.param_count; ++i)
                        func_val.func_val.param_types[i] = md.param_types[i] ? copy_type_node(md.param_types[i]) : nullptr;
                    func_val.func_val.vararg_type = md.vararg_type ? copy_type_node(md.vararg_type) : nullptr;

                    result = call_function_value(func_val,
                        opt_args.empty() ? nullptr : opt_args.data(),
                        (int)opt_args.size(),
                        nullptr);
                    func_val.func_val.body = nullptr;
                    free(func_val.func_val.name);
                    for (int i = 0; i < func_val.func_val.param_count; ++i)
                        free(func_val.func_val.params[i]);
                    free(func_val.func_val.params);
                    free(func_val.func_val.param_is_const);
                    free(func_val.func_val.param_defaults);
                    free(func_val.func_val.vararg_name);
                    free_type_node(func_val.func_val.return_type);
                    for (int i = 0; i < func_val.func_val.param_count; ++i)
                        free_type_node(func_val.func_val.param_types[i]);
                    free(func_val.func_val.param_types);
                    free_type_node(func_val.func_val.vararg_type);
                } else {
                    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                    Function* func = get_function(opt_haupt.c_str());
                    if (!func) {
                        kr_error("Globale Funktion '%s' nicht gefunden.", opt_haupt.c_str());
                    }
                    Value func_val;
                    func_val.type = VAL_FUNCTION;
                    func_val.func_val.name = strdup(opt_haupt.c_str());
                    func_val.func_val.param_count = func->param_count;
                    func_val.func_val.params = (char**)malloc(func_val.func_val.param_count * sizeof(char*));
                    for (int i = 0; i < func_val.func_val.param_count; ++i)
                        func_val.func_val.params[i] = strdup(func->params[i]);
                    func_val.func_val.body = copy_ast(func->body);
                    func_val.func_val.closure_scope = copy_scope_chain(func->closure_scope);
                    func_val.func_val.is_memoized = func->is_memoized;
                    func_val.func_val.is_async = func->is_async;
                    func_val.func_val.global_scope = func->global_scope;
                    func_val.func_val.is_rule = false;
                    func_val.func_val.return_type = copy_type_node(func->return_type);
                    func_val.func_val.vararg_name = func->vararg_name ? strdup(func->vararg_name) : NULL;
                    func_val.func_val.param_is_const = (bool*)malloc(func_val.func_val.param_count * sizeof(bool));
                    func_val.func_val.param_defaults = (ASTNode**)malloc(func_val.func_val.param_count * sizeof(ASTNode*));
                    for (int i = 0; i < func_val.func_val.param_count; ++i) {
                        func_val.func_val.param_is_const[i] = func->param_is_const[i];
                        func_val.func_val.param_defaults[i] = func->param_defaults[i] ? copy_ast(func->param_defaults[i]) : NULL;
                    }
                    func_val.func_val.param_types = (TypeNode**)malloc(func_val.func_val.param_count * sizeof(TypeNode*));
                    for (int i = 0; i < func_val.func_val.param_count; ++i)
                        func_val.func_val.param_types[i] = func->param_types[i] ? copy_type_node(func->param_types[i]) : nullptr;
                    func_val.func_val.vararg_type = func->vararg_type ? copy_type_node(func->vararg_type) : nullptr;
                    func_val.func_val.filename = strdup(current_filename ? current_filename : "-");

                    result = call_function_value(func_val,
                        opt_args.empty() ? nullptr : opt_args.data(),
                        (int)opt_args.size(),
                        nullptr);
                    free_value(&func_val);
                }

                free_value(&result);
                for (auto& v : opt_args) free_value(&v);

            } catch (const KRError& e) {
                int line = g_last_error_line;
                int col = g_last_error_col;
                if (line == 0) { line = 1; col = 1; }

                const char* filename_err = find_filename_by_line_col(line, col);
                if (!filename_err) filename_err = current_filename;
                if (!filename_err) filename_err = "-";

                print_source_context(line, col, filename_err);
                fprintf(stderr, "%s\n", e.what());
                return 1;
            }

            current_scope = old_scope;
            return_caught = old_return;
            break_caught = old_break;
            continue_caught = old_continue;
            exception_raised = old_exception;
            free_value(&return_value);
            return_value = old_return_val;
            free_value(&exception_value);
            exception_value = old_exception_val;
        }
    }
    catch (const KRError& e) {
        if (lex_only) {
            int err_line = g_last_error_line > 0 ? g_last_error_line : 1;
            int err_col = g_last_error_col > 0 ? g_last_error_col : 1;

            std::string msg = e.what();
            std::string clean;
            clean.reserve(msg.size());
            size_t i = 0;
            while (i < msg.size()) {
                if (msg[i] == '\033' && i + 1 < msg.size() && msg[i+1] == '[') {
                    i += 2;
                    while (i < msg.size() && !isalpha((unsigned char)msg[i])) i++;
                    if (i < msg.size()) i++;
                } else {
                    clean += msg[i++];
                }
            }

            const std::string FEHL_TAG = "[Fehl] ";
            if (clean.compare(0, FEHL_TAG.size(), FEHL_TAG) == 0)
                clean = clean.substr(FEHL_TAG.size());

            std::string marker = ":" + std::to_string(err_line) + ":"
                + std::to_string(err_col) + ": ";
            size_t mp = clean.find(marker);
            if (mp != std::string::npos && mp < 512 && mp >= 1 && clean[mp - 1] == ':')
                clean = clean.substr(mp + marker.size());

            while (!clean.empty() && (unsigned char)clean.front() <= ' ')
                clean.erase(clean.begin());
            while (!clean.empty() && (unsigned char)clean.back() <= ' ')
                clean.pop_back();

            std::string escaped;
            escaped.reserve(clean.size() + 8);
            for (unsigned char c : clean) {
                switch (c) {
                    case '"': escaped += "\\\""; break;
                    case '\\': escaped += "\\\\"; break;
                    case '\b': escaped += "\\b"; break;
                    case '\f': escaped += "\\f"; break;
                    case '\n': escaped += "\\n"; break;
                    case '\r': escaped += "\\r"; break;
                    case '\t': escaped += "\\t"; break;
                    default:
                        if (c < 0x20) {
                            char buf[8];
                            snprintf(buf, sizeof(buf), "\\u%04x", c);
                            escaped += buf;
                        } else {
                            escaped += (char)c;
                        }
                }
            }

            printf("{\"ok\":0,\"version\":\"%s\",\"zeile\":%d,\"spal\":%d,\"fehl\":\"%s\",\"makros\":%s}\n",
                lex_version_string().c_str(),
                err_line, err_col, escaped.c_str(), macro_marks_to_json().c_str());
            return 1;
        }
        int line = g_last_error_line;
        int col = g_last_error_col;
        if (line == 0) { line = 1; col = 1; }

        const char* filename_err = find_filename_by_line_col(line, col);
        if (!filename_err) filename_err = current_filename;
        if (!filename_err) filename_err = "-";

        print_source_context(line, col, filename_err);

        fprintf(stderr, "%s\n", e.what());
        return 1;
    }
    catch (const std::exception& e) {
        fprintf(stderr, "未捕获的异常: %s\n", e.what());
        return 1;
    }
    if (g_warnings_enabled && original_global_scope) {
        for (int i = 0; i < original_global_scope->var_count; ++i) {
            Variable* var = &original_global_scope->vars[i];
            if (!var->is_read && var->value.type != VAL_FUNCTION) {
                auto it = g_var_decl_pos.find(var->name);
                if (it != g_var_decl_pos.end()) {
                    g_last_error_line = it->second.first;
                    g_last_error_col = it->second.second;
                } else {
                    g_last_error_line = 1;
                    g_last_error_col = 1;
                }
                const char* kind = var->is_const ? "Konstante" : "Variable";
                std::string type_str = value_type_to_string(var->value);
                kr_warn("%s '%s' 被声明但从未使用 (typ: %s)", kind, var->name, type_str.c_str());
            }
        }
    }
    if (g_warnings_enabled) {
        std::lock_guard<std::mutex> lock(functions_mutex);
        for (int i = 0; i < func_count; ++i) {
            if (!functions[i].called) {
                auto it = g_func_decl_pos.find(functions[i].name);
                if (it != g_func_decl_pos.end()) {
                    g_last_error_line = it->second.first;
                    g_last_error_col = it->second.second;
                } else {
                    g_last_error_line = 1;
                    g_last_error_col = 1;
                }
                kr_warn("Funktion '%s' 被定义但从未调用", functions[i].name);
            }
        }
    }
    if (interactive && script_content) {
        free(script_content);
    }
    return 0;
}