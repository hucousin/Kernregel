#include "interpreter.cpp"

// ============================================================================
// Kompilieren
// ============================================================================

bool g_compile_mode = true;

class VM;                              // 前向声明
static thread_local VM* g_active_vm = nullptr;
static Value vm_invoke(const Value& fn, Value* args, int argc);
static void vm_force_eval_lazy_var(Variable* var);

struct CompiledFunction {
    std::string              name;
    std::vector<std::string> params;
    size_t                   code_offset = 0;
    bool                     is_rule = false;
    bool                     is_async = false;
    bool                     is_memoized = false;
    bool                     global_scope = false;
    mutable bool             called = false;
    std::string              return_type;
    std::string              vararg_name;
    std::string              vararg_type;
    std::vector<int>         param_defaults_idx;
    std::vector<size_t>      param_default_code_off;   // 默认值代码块起始
    std::vector<size_t>      param_default_code_end;   // 默认值代码块结束
    std::vector<bool>        param_has_default;        // 是否有默认值（不论可否折叠）
    std::vector<std::string> param_types;
    std::vector<bool>        param_is_const;
    std::string              defining_file;
};

struct CompiledClass {
    std::string name;
    std::string parent;
    int ctor_func_idx = -1;
    std::vector<std::pair<std::string, int>> properties;
    std::vector<std::pair<std::string, int>> static_props;
    std::vector<std::pair<std::string, int>> methods;      // 方法名 → functions 索引
    std::vector<bool>                        method_is_static;
    std::vector<int>                         method_access;  // 访问修饰符
    std::string                              defining_file;
    std::vector<std::string> ctor_params;
    std::vector<int>         ctor_defaults_idx;
    std::vector<std::string> ctor_param_types;
    int  access_modifier = 0;
    bool is_static_class = false;
};

struct CompiledNamespace {
    std::string name;
    std::string parent;
    int         scope_id = -1;
    size_t      code_offset = 0;
    std::vector<std::string> var_names;
    std::vector<std::string> class_shortnames;   // 供 OP_IMPORT_NS 使用
};

struct CStrHash {
    size_t operator()(const char* s) const noexcept {
        // FNV-1a 64
        uint64_t h = 1469598103934665603ULL;
        for (; *s; ++s) { h ^= (uint8_t)*s; h *= 1099511628211ULL; }
        return (size_t)h;
    }
};
struct CStrEq {
    bool operator()(const char* a, const char* b) const noexcept {
        return std::strcmp(a, b) == 0;
    }
};

struct Bytecode {
    std::vector<uint8_t>       code;
    std::vector<Value>         constants;
    std::vector<CompiledFunction> functions;
    std::unordered_map<const char*, int, CStrHash, CStrEq> func_by_name;
    std::unordered_map<std::string, int> string_intern;
    std::vector<ASTNode*>      aux_ast_refs;

    std::unordered_map<std::string, const char*> name_pool;

    std::vector<CompiledClass> classes;
    mutable std::unordered_map<std::string, int> class_by_name;   // mutable：OP_IMPORT_NS 运行时会补登记短名

    std::vector<CompiledNamespace> namespaces;
    std::unordered_map<std::string, int> ns_by_name;
    std::unordered_map<std::string, std::vector<std::string>> string_unions;
};

// HTTP handler 入口：延迟到 VM 完全类型可见后再定义。
// 主线程调用时把 bc / root_scope 捕获进去，HTTP 线程里就地建 VM。
static Value vm_invoke_http_handler(const Value& handler,
                                    const Bytecode* bc,
                                    Scope*          root_scope,
                                    Value           req);

// ============ 类静态属性裸名解析支持 ============
static std::string g_compiling_class_name;

struct ClassContextGuard {
    std::string saved;
    explicit ClassContextGuard(const std::string& cn)
        : saved(g_compiling_class_name) { g_compiling_class_name = cn; }
    ~ClassContextGuard() { g_compiling_class_name = saved; }
};

// 当前类是否把 name 声明为静态属性
static bool is_current_static_property(const char* name, const Bytecode& bc) {
    if (g_compiling_class_name.empty() || !name) return false;
    auto it = bc.class_by_name.find(g_compiling_class_name);
    if (it == bc.class_by_name.end()) return false;
    const CompiledClass& cc = bc.classes[it->second];
    for (const auto& p : cc.static_props)
        if (p.first == name) return true;
    return false;
}

// 若 name 是当前类静态属性，返回 "Class::name"；否则返回空串
static std::string qualify_static_name(const char* name, const Bytecode& bc) {
    if (is_current_static_property(name, bc))
        return g_compiling_class_name + "::" + name;
    return {};
}

// 当 cls_name 是已注册类、attr 是它的静态属性时，返回 "ClassName::attr"；否则返回空串
static std::string resolve_static_property(const char* cls_name,
                                           const char* attr,
                                           const Bytecode& bc) {
    if (!cls_name || !attr) return {};
    auto it = bc.class_by_name.find(cls_name);
    if (it == bc.class_by_name.end()) return {};
    const CompiledClass& cc = bc.classes[it->second];
    for (const auto& p : cc.static_props)
        if (p.first == attr) return std::string(cls_name) + "::" + attr;
    return {};
}

enum BuiltinId : uint32_t {
    BI_NONE = 0,

    // ---- 数学 ----
    BI_SQRT, BI_CBRT, BI_ABS, BI_SIN, BI_COS, BI_TAN, BI_COT, BI_SEC, BI_CSC,
    BI_ASIN, BI_ACOS, BI_ATAN, BI_ATAN2,
    BI_SINH, BI_COSH, BI_TANH, BI_ASINH, BI_ACOSH, BI_ATANH,
    BI_EXP, BI_LN, BI_LOG, BI_LD,
    BI_RAND, BI_SRAND,
    BI_ABL,     // 一阶导数（中心差分）
    BI_INTE,    // 梯形法数值积分
    BI_AB2,     // 二阶导数
    BI_SIMP,    // 辛普森法数值积分
    BI_GRAD,    // 梯度（多变量）
    BI_NULLST,  // 二分法求根
    BI_EULER,   // 欧拉法求解 ODE
    BI_PABL,    // 偏导数（对数组某分量）
    BI_AB3,     // 三阶导数
    BI_AB4,     // 四阶导数（五点公式）
    BI_RK,      // Runge-Kutta-Fehlberg 45 自适应 ODE
    BI_NEWTON,  // 牛顿法求根
    BI_GRADAB,  // 梯度下降
    BI_KQUAD,   // 多项式最小二乘拟合
    BI_GAUSS,   // 高斯-勒让德数值积分

    // ---- 文件 ----
    BI_LESE_DATEI, BI_LESE_BIN, BI_SCHRD,

    // ---- 字符串 ----
    BI_TRIM, BI_ERSETZE, BI_TEIL, BI_ENTHAELT, BI_FAENGT_AN_MIT,
    BI_ABSCHNITT, BI_STELLE_VON, BI_LETZTE_STELLE_VON,
    BI_ALS_ZAHL, BI_ALS_TEXT, BI_ALS_ARRAY, BI_GROSS, BI_FORMAT, BI_LAN,

    // ---- 时间 ----
    BI_SLEEP, BI_ZEIT, BI_ZEIT_US, BI_ZEIT_MS, BI_ZEIT_NS,
    BI_DATUM, BI_TICK, BI_TOCK, BI_TOCK_MS, BI_TOCK_S,

    // ---- 系统 ----
    BI_ENDE, BI_ZEILE, BI_FNAME,

    // ---- 流输出（对应解释器的 zeigIn / schrIn）----
    BI_ZEIG_IN, BI_SCHR_IN,

    // ---- 字节 / 编码 ----
    BI_BYTES, BI_UMBYTES, BI_KODIER_BASE64, BI_KODIER_URL, BI_DEKODIER_URL,

    // ---- JSON ----
    BI_JSONZU, BI_ZUJSON,

    // ---- 类型 ----
    BI_TYPIST, BI_GTYP,

    // ---- 指针 ----
    BI_ZGR, BI_SCHLAU, BI_ZGRW, BI_ZGRS, BI_FREI, BI_ZGR_NULL,

    // ---- 错误 ----
    BI_KRFEHL, BI_KRWARN,

    // ---- 元编程 / 外部工具 ----
    BI_KRKOM, BI_CPP, BI_ASM, BI_VA,

    // ---- HTTP 辅助 ----
    BI_ESC, BI_TEXT, BI_JSON_RESP, BI_HTML, BI_UMLEITEN,
    BI_ABFRAGE, BI_FORMULAR, BI_ANFR,

    // ---- HTTP 服务器 / 流 ----
    BI_STARTE_SERVER, BI_AC_STARTE_SERVER,
    BI_SSE, BI_SENDE, BI_SENDE_SSE, BI_SCHLIESSE,
    BI_HOLE_IP,

    // ---- 元信息 / 调试 ----
    BI_TOKENS, BI_WORTE, BI_REGGEN, BI_VW, BI_UMF,

    // ---- 键盘 / 终端 ----
    BI_DRUECKE, BI_TASTE, BI_AC_TASTE, BI_TASTE_G,
    BI_AKTU, BI_ZEIG_ALLE, BI_LOESCH,

    // ---- 异步 / 底层 ----
    BI_AC_AUSF, BI_AUSF, BI_BC,
    BI_EXEC,
    BI_AC_EXEC,
    BI_PROC_KILL,
    BI_PROC_QUERY,

    // ---- KD 数据集 ----
    BI_LADE_KD, BI_SCHR_KD, BI_ERNEU_KD, BI_LOES_KD,
    BI_SUCH_KD, BI_SIEBE_KD, BI_ALLE_KD, BI_ZAEHLE_KD,
    BI_VERSCHL_KD, BI_ENTSCHL_KD,
};



struct BuiltinEntry { const char* name; BuiltinId id; };

static const BuiltinEntry g_builtin_table[] = {
    // 数学
    {"sqrt", BI_SQRT}, {"wurz", BI_SQRT},
    {"cbrt", BI_CBRT}, {"kub",  BI_CBRT},
    {"abs",  BI_ABS},  {"btr",  BI_ABS},
    {"sin",  BI_SIN},  {"cos",  BI_COS},  {"tan", BI_TAN}, {"tg", BI_TAN},
    {"cot",  BI_COT},  {"ctg",  BI_COT},
    {"sec",  BI_SEC},  {"csc",  BI_CSC},
    {"asin", BI_ASIN}, {"acos", BI_ACOS}, {"atan", BI_ATAN},
    {"atan2", BI_ATAN2},
    {"sinh", BI_SINH}, {"cosh", BI_COSH}, {"tanh", BI_TANH},
    {"asinh", BI_ASINH}, {"acosh", BI_ACOSH}, {"atanh", BI_ATANH},
    {"exp",  BI_EXP},  {"ln", BI_LN}, {"log", BI_LOG}, {"lg", BI_LOG},
    {"ld",   BI_LD},
    {"rand", BI_RAND}, {"zuf", BI_RAND},
    {"srand", BI_SRAND}, {"setze", BI_SRAND},
    // 微积分 / 数值方法
    {"abl",     BI_ABL},
    {"inte",    BI_INTE},
    {"ab2",     BI_AB2},
    {"simp",    BI_SIMP},
    {"grad",    BI_GRAD},
    {"nullst",  BI_NULLST},
    {"euler",   BI_EULER},
    {"pabl",    BI_PABL},
    {"ab3",     BI_AB3},
    {"ab4",     BI_AB4},
    {"rk",      BI_RK},
    {"newton",  BI_NEWTON},
    {"gradab",  BI_GRADAB},
    {"kquad",   BI_KQUAD},
    {"gauss",   BI_GAUSS},
    // 文件
    {"leseDatei", BI_LESE_DATEI}, {"lese", BI_LESE_DATEI},
    {"leseBin",  BI_LESE_BIN},
    {"schrd",    BI_SCHRD},
    // 字符串
    {"trim",     BI_TRIM},
    {"ersetze",  BI_ERSETZE}, {"ers", BI_ERSETZE},
    {"teil",     BI_TEIL},
    {"enthält",  BI_ENTHAELT}, {"hat", BI_ENTHAELT},
    {"fängtAnMit", BI_FAENGT_AN_MIT}, {"beg", BI_FAENGT_AN_MIT},
    {"abschnitt",  BI_ABSCHNITT}, {"ab", BI_ABSCHNITT},
    {"stelleVon",  BI_STELLE_VON}, {"wo", BI_STELLE_VON},
    {"letzteStelleVon", BI_LETZTE_STELLE_VON}, {"letzt", BI_LETZTE_STELLE_VON},
    {"alsZahl",  BI_ALS_ZAHL}, {"alz", BI_ALS_ZAHL},
    {"alsText",  BI_ALS_TEXT}, {"alt", BI_ALS_TEXT},
    {"groß",     BI_GROSS},
    {"format",   BI_FORMAT},
    {"län",      BI_LAN},
    // 时间
    {"sleep",   BI_SLEEP},
    {"zeit",    BI_ZEIT},   {"zeit_us", BI_ZEIT_US},
    {"zeit_ms", BI_ZEIT_MS},{"zeit_ns", BI_ZEIT_NS},
    {"datum",   BI_DATUM},
    {"tick",    BI_TICK},   {"tock", BI_TOCK},
    {"tock_ms", BI_TOCK_MS},{"tock_s", BI_TOCK_S},
    // 系统
    {"ende", BI_ENDE}, {"exit", BI_ENDE},
    {"zeile", BI_ZEILE}, {"line", BI_ZEILE},
    {"fname", BI_FNAME},
    // 流输出
    {"zeigIn", BI_ZEIG_IN}, {"schrIn", BI_SCHR_IN},
    // 字节/编码
    {"bytes",       BI_BYTES},
    {"umbytes",     BI_UMBYTES},
    {"kodierBase64",BI_KODIER_BASE64},
    {"kodierURL",   BI_KODIER_URL}, {"dekodierURL", BI_DEKODIER_URL},
    // JSON
    {"jsonzu", BI_JSONZU}, {"zujson", BI_ZUJSON},
    // 类型
    {"typist", BI_TYPIST}, {"gtyp", BI_GTYP},
    // 指针
    {"zgr", BI_ZGR}, {"schlau", BI_SCHLAU},
    {"zgrw", BI_ZGRW}, {"zgrs", BI_ZGRS},
    {"frei", BI_FREI}, {"zgrNull", BI_ZGR_NULL},
    // 错误
    {"KRFehl", BI_KRFEHL}, {"KRWarn", BI_KRWARN},
    {"KRKom", BI_KRKOM},
    {"cpp",   BI_CPP},
    {"asm",   BI_ASM},
    {"va",    BI_VA},
    // HTTP 辅助
    {"esc",     BI_ESC},
    {"text",    BI_TEXT},
    {"json",    BI_JSON_RESP},
    {"html",    BI_HTML},
    {"umleiten",BI_UMLEITEN},
    {"abfrage", BI_ABFRAGE},
    {"formular",BI_FORMULAR},
    {"ANFR",    BI_ANFR},
    // HTTP 服务器 / 流
    {"starteServer",    BI_STARTE_SERVER},
    {"ac_starteServer", BI_AC_STARTE_SERVER},
    {"SSE",             BI_SSE},
    {"sende",           BI_SENDE},
    {"sendeSSE",        BI_SENDE_SSE},
    {"schliesse",       BI_SCHLIESSE},
    {"holeIP",          BI_HOLE_IP},
    // 元信息 / 调试
    {"tokens",          BI_TOKENS},
    {"worte",           BI_WORTE},
    {"regGen",          BI_REGGEN},
    {"vw",              BI_VW},
    {"umf",             BI_UMF},
    // 键盘 / 终端
    {"drücke",          BI_DRUECKE},
    {"taste",           BI_TASTE},
    {"ac_taste",        BI_AC_TASTE},
    {"taste_g",         BI_TASTE_G},
    {"aktu",            BI_AKTU},
    {"zeigAlle",        BI_ZEIG_ALLE},
    {"loesch",          BI_LOESCH},
    // 异步 / 底层
    {"ausf",            BI_AUSF},
    {"ac_ausf",         BI_AC_AUSF},
    {"BC",              BI_BC},
    {"lauf",            BI_EXEC},
    {"ac_lauf",         BI_AC_EXEC},
    {"aufgT",           BI_PROC_KILL},
    {"aufgTöten",       BI_PROC_KILL},
    {"aufgAnf",         BI_PROC_QUERY},
    // KD 数据集
    {"ladeKD",    BI_LADE_KD},
    {"schrKD",    BI_SCHR_KD},
    {"erneuKD",   BI_ERNEU_KD},
    {"loesKD",    BI_LOES_KD},
    {"suchKD",    BI_SUCH_KD},
    {"siebeKD",   BI_SIEBE_KD},
    {"alleKD",    BI_ALLE_KD},
    {"zaehleKD",  BI_ZAEHLE_KD},
    {"verschlKD", BI_VERSCHL_KD},
    {"entschlKD", BI_ENTSCHL_KD},
};
static const size_t g_builtin_table_size = sizeof(g_builtin_table)/sizeof(g_builtin_table[0]);

// 编译期一次线性扫描（对每个 call site 只发生一次；通常程序里的内建名很少）
static BuiltinId lookup_builtin(const char* name) {
    if (!name) return BI_NONE;
    for (size_t i = 0; i < g_builtin_table_size; ++i) {
        const char* n = g_builtin_table[i].name;
        // 名字都以相同首字母开始？直接 strcmp。
        if (n[0] == name[0] && strcmp(n, name) == 0)
            return g_builtin_table[i].id;
    }
    return BI_NONE;
}

static const char* intern_name(Bytecode& bc, const char* name) {
    auto it = bc.name_pool.find(name);
    if (it != bc.name_pool.end()) return it->second;
    char* stable = strdup(name);
    bc.name_pool.emplace(name, stable);
    return stable;
}

enum Opcode : uint8_t {
    OP_PUSH_INT64,
    OP_PUSH_INT,
    OP_PUSH_FLOAT,
    OP_PUSH_STRING,
    OP_ADD,
    OP_SUB,
    OP_MUL,
    OP_DIV,
    OP_MOD,
    OP_POW,
    OP_CONCAT,      // ##
    OP_XOR,         // ~~
    OP_CMP_EQ,      // ==
    OP_CMP_NE,      // !=
    OP_CMP_GT,      // >
    OP_CMP_LT,      // <
    OP_CMP_GE,      // >=
    OP_CMP_LE,      // <=
    OP_CMP_3WAY,    // <=>
    OP_HALT,
    OP_PRINT,
    OP_PRINT_NO_NEWLINE,
    OP_PRINT_MULTI,
    OP_PRINT_NO_NEWLINE_MULTI,
    OP_PRINT_WITH_LINE,
    OP_POP,
    OP_SETLINE,
    OP_IF,
    OP_WHILE,
    OP_FOR,
    OP_FOREACH,
    OP_DO_WHILE,
    OP_BREAK,
    OP_CONTINUE,
    OP_JMP,
    OP_JMP_IF_FALSE,
    OP_JMP_IF_TRUE,
    OP_DUP,              // 复制栈顶（用于条件求值后保留）
    OP_ARRAY_LEN,      // 获取数组/字符串长度
    OP_ARRAY_GET,      // 按索引取元素
    OP_STORE,          // 将栈顶值存入变量（需变量名）
    OP_SWAP,           // 交换栈顶两元素
    OP_RANGE,            // 创建范围数组（start, end, step）
    OP_PUSH_NULL,          // push null value
    OP_DECLARE_VAR,        // declare a variable (with const/global flags)
    OP_DECLARE_LAZY_VAR,   // <name_idx:4> <global:1> <code_off:4> <code_end:4>
    OP_INC_VAR,        // 前置 ++x：x++，压入新值
    OP_DEC_VAR,        // 前置 --x：x--，压入新值
    OP_POST_INC_VAR,   // 后置 x++：x++，压入旧值
    OP_POST_DEC_VAR,   // 后置 x--：x--，压入旧值

    OP_ADD_TO_VAR,     // <name_idx:4> : var = var + <stack_top>，弹出栈顶
    OP_SUB_TO_VAR,     // <name_idx:4> : var = var - <stack_top>，弹出栈顶
    OP_MUL_TO_VAR,     // <name_idx:4> : var = var * <stack_top>，弹出栈顶
    OP_DIV_TO_VAR,     // <name_idx:4> : var = var / <stack_top>，弹出栈顶
    OP_MOD_TO_VAR,     // <name_idx:4> : var = var % <stack_top>，弹出栈顶

    OP_NATIVE_FOR,     // 原生 int64 计数循环

    OP_FUNC_DEF,   // <func_idx:4>    : 压入一个 VAL_FUNCTION 值
    OP_CALL,       // <name_idx:4> <argc:4> : 原生 VM 调用
    OP_RETURN,     // 栈顶为返回值；返回到调用者的 return_pc
    OP_CALL_DIRECT,

    OP_BIT_OR,          // 按位或 |
    OP_BIT_AND,         // 按位与 &
    OP_SHL,             // 左移 <<
    OP_SHR,             // 右移 >>

    OP_NOT,             // 逻辑非：弹出 v，压入 !value_to_bool(v)（0/1）
    OP_JMP_IF_NOT_NULL, // 弹出 v；若 v.type != VAL_NULL 则跳到 addr

    OP_BIT_NOT,         // 按位取反 (mpz_com)
    OP_TO_RAD,          // 度 → 弧度 (mpf * π/180)
    OP_FACT,            // 单阶乘 (mpz_fac_ui)
    OP_DFACT,           // 双阶乘
    OP_SWAP_ASSIGN,     // 交换两个左值：<l_ast_id:4> <r_ast_id:4> <global:1>
    //   l_ast_id/r_ast_id 是 Bytecode::aux_ast_refs 的下标

    OP_NEW_ARRAY,       // <n:4>  ：弹 n 个值（栈顶是最后一个元素），打包成数组
    OP_NEW_OBJECT,      // <n:4>  ：弹 2n 个值（k,v 交替），打包成对象

    OP_OBJ_GET,         // <key_idx:4> <optional:1> : 弹出 obj，压入 obj[key]
    OP_OBJ_SET,         // <key_idx:4>               : 弹出 [obj, value]，写入 obj[key]
    OP_ARRAY_SET,       // 弹出 [container, index, value]：写入 container[index]
    OP_DUP2,            // 复制栈顶两个值： a b -- a b a b

    OP_ALIAS_DECL,          // <name_idx:4> <target_idx:4> <global:1>
    OP_PUSH_SCOPE,          // 进入新作用域
    OP_POP_SCOPE,           // 退出作用域
    OP_ENTER_GLOBAL_SCOPE,  // 切换到全局作用域（入栈保存旧作用域）
    OP_EXIT_GLOBAL_SCOPE,   // 恢复之前的作用域
    OP_THROW,               // 抛出异常：弹出栈顶值并中止执行

    OP_MULTI_ASSIGN,        // <count:4> <name_idx_0:4> ... <name_idx_(count-1):4>
    OP_DESTRUCTURE_ASSIGN,  // <count:4> <rest_idx:4> <name_idx_0:4> ... <name_idx_(count-1):4>

    // ---- 异常处理 ----
    OP_TRY_BEGIN,     // <catch_addr:4> <finally_addr:4>
    OP_TRY_END,       // 弹出当前 try handler
    OP_GET_CAUGHT,    // 压入当前捕获的异常值
    OP_THROW_RE,      // 重新抛出当前捕获的异常（finally 里用）

    // ---- 断言 ----
    OP_SICHER_FAIL,   // 弹出 msg，写 stderr，exit(1)

    // ---- 集合迭代 ----
    OP_ITER_PREP,     // 弹出集合 → 压入一个整数 iter_state(0)
    OP_ITER_NEXT,     // <done_addr:4>：栈 [coll, idx] → 要么跳 done，要么 [coll, idx, key, value] 并 idx++
    OP_ITER_BIND,     // <var_idx:4> <valuevar_idx:4 or -1>：弹出 [key,value]，按需绑定

    // ---- 记忆化函数 ----
    OP_RULE_DEF,      // <func_idx:4>：与 OP_FUNC_DEF 相同，但置 is_rule 标记
    OP_RULE_CALL,     // <func_idx:4> <argc:4>：带缓存查表的直接调用

    OP_AWAIT_PREP,      // 弹出 base（Future 或数组），压入 [n, future_id_0, ..., future_id_{n-1}]
    OP_AWAIT_WAIT,      // <timeout_ms:8> <has_timeout:1> <has_fallback:1>
                        // 弹出上述栈内容 → 压入单个结果或结果数组

    OP_TO_INT64,        // 任意数值 → int64
    OP_MARK_VAR_READ,   // <name_idx:4>  标记变量为已读
    OP_OBJ_SET_DYN,     // [obj, key, value] → obj[key] = value
    OP_ARRAY_PUSH,
    OP_NEW_OBJ,         // <cls_idx:4> <argc:4>  类实例化
    OP_PUSH_NS,         // <ns_idx:4>  切换 current_scope 到该命名空间
    OP_POP_NS,          // 恢复 current_scope
    OP_IMPORT_NS,       // <ns_idx:4>  把命名空间里的变量/类短名拉进当前作用域
    OP_RETURN_NS,       // 命名空间 body 的返回占位

    OP_FINALLY_END,     // finally 体结束哨兵：兑现挂起的 return/rethrow

    OP_CALL_VALUE,

    OP_WRAP_ARRAY_1,       // 弹出 v，压入 [v]
    OP_FLATTEN_ARRAYS,     // <n:4>：弹出 n 个数组，拼接成一个数组
    OP_CALL_DIRECT_ARR,    // <func_idx:4>：栈顶是参数数组
    OP_CALL_ARR,           // <name_idx:4>：栈顶是参数数组，动态名字调用
    OP_CALL_VALUE_ARR,     // 栈：[func_val, args_arr] → 调用

    OP_METHOD_CALL,       // <method_idx:4> <argc:4> <flags:1>
                        // 栈：[obj, arg0, ..., argN-1] → 结果
                        // flags: bit0 = is_optional
    OP_METHOD_CALL_VAR,   // <var_idx:4> <method_idx:4> <argc:4> <flags:1>
                        // 栈：[arg0, ..., argN-1] → 结果
                        // 变量接收者：先解析命名空间/类静态，再回退变量

    OP_GET_VAR,          // 从当前作用域读取变量（带 __stdwert 展开）
    OP_GET_VAR_RAW,      // 从当前作用域读取变量（不做 __stdwert 展开）

    OP_CALL_BUILTIN,

    OP_INPUT,
    OP_MATCH_TRY,
    OP_SUPER_CALL,
    OP_INC_DEC_AST,
    OP_OBJ_SET_VAR,
    OP_MARK_USED,        // 标记一组名字为已使用
    OP_MARK_ALL_USED,
};

struct LoopInfo {
    std::vector<size_t> break_jumps;
    std::vector<size_t> continue_jumps;
    size_t loop_start;           // 循环开始地址（用于 continue）
    size_t continue_target;      // 实际 continue 目标（更新部分或循环开始）
    size_t cond_jump;            // 条件为假时的跳转位置（用于回填）
    bool has_cond;               // 是否有条件
    size_t cond_jump_pos;        // 条件跳转指令的位置（用于回填）
};

std::vector<LoopInfo> g_loop_stack;
static std::unordered_map<std::string, Value> g_rule_cache;
static std::function<Scope*(const std::string&)> g_vm_named_scopes_lookup;

// ---- --verf：编译期 AST 追踪 ----
static int g_compile_depth = 0;   // 当前编译递归深度，仅用于缩进

static inline void compile_trace(const char* phase, ASTNode* node) {
    if (!g_trace_ast || !node) return;
    std::string indent((size_t)(g_compile_depth * 2), ' ');
    fprintf(stderr, "%s[VERF] %s: %s at %d:%d\n",
            indent.c_str(),
            phase,
            node_type_to_string(node->type),
            node->line, node->col);
}

// RAII：离开作用域自动 --g_compile_depth，异常/早退也安全
struct CompileDepthGuard {
    CompileDepthGuard()  { ++g_compile_depth; }
    ~CompileDepthGuard() { --g_compile_depth; }
    CompileDepthGuard(const CompileDepthGuard&)            = delete;
    CompileDepthGuard& operator=(const CompileDepthGuard&) = delete;
};

static bool vm_check_type(const Value& v, const std::string& tname) {
    if (tname.empty() || tname == "any") return true;
    if (tname == "gzl" || tname == "zahl")
        return v.type == VAL_INT || v.type == VAL_INT64;
    if (tname == "kzl")
        return v.type == VAL_FLOAT;
    if (tname == "zkt")
        return v.type == VAL_STRING;
    if (tname == "bool")
        return v.type == VAL_INT64 || v.type == VAL_INT;
    if (tname == "null")
        return v.type == VAL_NULL;
    return true;   // 未知类型不阻塞
}

static void push_int_operand(Bytecode& bc, int value);
void compile_expr(ASTNode* node, Bytecode& bc);
void compile_statement(ASTNode* node, Bytecode& bc);

static void emit_line(ASTNode* node, Bytecode& bc) {
    bc.code.push_back(OP_SETLINE);
    push_int_operand(bc, node->line);
    push_int_operand(bc, node->col);
}

static Value op_add(const Value& left, const Value& right) {
    // ---- 1. 字符串拼接（若任一方为字符串或 null） ----
    if (left.type == VAL_STRING || right.type == VAL_STRING ||
        left.type == VAL_NULL || right.type == VAL_NULL) {
        char* lstr = value_to_string(left);
        char* rstr = value_to_string(right);
        char* res = (char*)malloc(strlen(lstr) + strlen(rstr) + 1);
        strcpy(res, lstr); strcat(res, rstr);
        Value result = make_string(res);
        free(res); free(lstr); free(rstr);
        return result;
    }

    // ---- 2. 快速路径：双方都是原生 int64（无溢出） ----
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        int64_t a = left.int64_val, b = right.int64_val, res;
        if (!__builtin_add_overflow(a, b, &res)) {
            return make_int64(res);
        }
        // 溢出则回退到 GMP
        mpz_t la, lb, lr;
        mpz_init_set_si(la, a); mpz_init_set_si(lb, b); mpz_init(lr);
        mpz_add(lr, la, lb);
        Value result = make_int_auto(lr);
        mpz_clear(la); mpz_clear(lb); mpz_clear(lr);
        return result;
    }

    // ---- 3. 完整 GMP/浮点逻辑（原 NODE_BINARY '+' 分支） ----
    Value left_c = copy_value(left), right_c = copy_value(right);
    // 将 INT64 转为 GMP
    if (left_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, left_c.int64_val);
        free_value(&left_c);
        left_c.type = VAL_INT; left_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*left_c.big_int, tmp); mpz_clear(tmp);
    }
    if (right_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, right_c.int64_val);
        free_value(&right_c);
        right_c.type = VAL_INT; right_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*right_c.big_int, tmp); mpz_clear(tmp);
    }

    // 检查是否为数值类型
    if (!(left_c.type == VAL_INT || left_c.type == VAL_FLOAT) ||
        !(right_c.type == VAL_INT || right_c.type == VAL_FLOAT)) {
        kr_error("加法需要数值操作数");
    }

    Value result;
    if (left_c.type == VAL_FLOAT || right_c.type == VAL_FLOAT) {
        mpf_t a, b, r; mpf_init(a); mpf_init(b); mpf_init(r);
        if (left_c.type == VAL_INT) mpf_set_z(a, *left_c.big_int); else mpf_set(a, *left_c.mpf_val);
        if (right_c.type == VAL_INT) mpf_set_z(b, *right_c.big_int); else mpf_set(b, *right_c.mpf_val);
        mpf_add(r, a, b);
        result = make_float(r);
        mpf_clear(a); mpf_clear(b); mpf_clear(r);
    } else {
        mpz_t a, b, r; mpz_init_set(a, *left_c.big_int); mpz_init_set(b, *right_c.big_int); mpz_init(r);
        mpz_add(r, a, b);
        result = make_int_auto(r);
        mpz_clear(a); mpz_clear(b); mpz_clear(r);
    }
    free_value(&left_c); free_value(&right_c);
    return result;
}

static Value op_sub(const Value& left, const Value& right) {
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        int64_t a = left.int64_val, b = right.int64_val, res;
        if (!__builtin_sub_overflow(a, b, &res)) return make_int64(res);
        mpz_t la, lb, lr; mpz_init_set_si(la, a); mpz_init_set_si(lb, b); mpz_init(lr);
        mpz_sub(lr, la, lb); Value result = make_int_auto(lr);
        mpz_clear(la); mpz_clear(lb); mpz_clear(lr); return result;
    }
    Value left_c = copy_value(left), right_c = copy_value(right);
    if (left_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, left_c.int64_val);
        free_value(&left_c); left_c.type = VAL_INT; left_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*left_c.big_int, tmp); mpz_clear(tmp);
    }
    if (right_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, right_c.int64_val);
        free_value(&right_c); right_c.type = VAL_INT; right_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*right_c.big_int, tmp); mpz_clear(tmp);
    }
    if (!(left_c.type == VAL_INT || left_c.type == VAL_FLOAT) ||
        !(right_c.type == VAL_INT || right_c.type == VAL_FLOAT)) kr_error("减法需要数值操作数");
    Value result;
    if (left_c.type == VAL_FLOAT || right_c.type == VAL_FLOAT) {
        mpf_t a, b, r; mpf_init(a); mpf_init(b); mpf_init(r);
        if (left_c.type == VAL_INT) mpf_set_z(a, *left_c.big_int); else mpf_set(a, *left_c.mpf_val);
        if (right_c.type == VAL_INT) mpf_set_z(b, *right_c.big_int); else mpf_set(b, *right_c.mpf_val);
        mpf_sub(r, a, b); result = make_float(r);
        mpf_clear(a); mpf_clear(b); mpf_clear(r);
    } else {
        mpz_t a, b, r; mpz_init_set(a, *left_c.big_int); mpz_init_set(b, *right_c.big_int); mpz_init(r);
        mpz_sub(r, a, b); result = make_int_auto(r);
        mpz_clear(a); mpz_clear(b); mpz_clear(r);
    }
    free_value(&left_c); free_value(&right_c);
    return result;
}

static Value op_mul(const Value& left, const Value& right) {
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        int64_t a = left.int64_val, b = right.int64_val, res;
        if (!__builtin_mul_overflow(a, b, &res)) return make_int64(res);
        mpz_t la, lb, lr; mpz_init_set_si(la, a); mpz_init_set_si(lb, b); mpz_init(lr);
        mpz_mul(lr, la, lb); Value result = make_int_auto(lr);
        mpz_clear(la); mpz_clear(lb); mpz_clear(lr); return result;
    }
    Value left_c = copy_value(left), right_c = copy_value(right);
    if (left_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, left_c.int64_val);
        free_value(&left_c); left_c.type = VAL_INT; left_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*left_c.big_int, tmp); mpz_clear(tmp);
    }
    if (right_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, right_c.int64_val);
        free_value(&right_c); right_c.type = VAL_INT; right_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*right_c.big_int, tmp); mpz_clear(tmp);
    }
    if (!(left_c.type == VAL_INT || left_c.type == VAL_FLOAT) ||
        !(right_c.type == VAL_INT || right_c.type == VAL_FLOAT)) kr_error("乘法需要数值操作数");
    Value result;
    if (left_c.type == VAL_FLOAT || right_c.type == VAL_FLOAT) {
        mpf_t a, b, r; mpf_init(a); mpf_init(b); mpf_init(r);
        if (left_c.type == VAL_INT) mpf_set_z(a, *left_c.big_int); else mpf_set(a, *left_c.mpf_val);
        if (right_c.type == VAL_INT) mpf_set_z(b, *right_c.big_int); else mpf_set(b, *right_c.mpf_val);
        mpf_mul(r, a, b); result = make_float(r);
        mpf_clear(a); mpf_clear(b); mpf_clear(r);
    } else {
        mpz_t a, b, r; mpz_init_set(a, *left_c.big_int); mpz_init_set(b, *right_c.big_int); mpz_init(r);
        mpz_mul(r, a, b); result = make_int_auto(r);
        mpz_clear(a); mpz_clear(b); mpz_clear(r);
    }
    free_value(&left_c); free_value(&right_c);
    return result;
}

static Value op_div(const Value& left, const Value& right) {
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        int64_t a = left.int64_val, b = right.int64_val;
        if (b == 0) kr_error("除零错误");
        if (a == INT64_MIN && b == -1) { // 溢出
            mpz_t la, lb, lr; mpz_init_set_si(la, a); mpz_init_set_si(lb, b); mpz_init(lr);
            mpz_tdiv_q(lr, la, lb); Value result = make_int_auto(lr);
            mpz_clear(la); mpz_clear(lb); mpz_clear(lr); return result;
        }
        return make_int64(a / b);
    }
    Value left_c = copy_value(left), right_c = copy_value(right);
    if (left_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, left_c.int64_val);
        free_value(&left_c); left_c.type = VAL_INT; left_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*left_c.big_int, tmp); mpz_clear(tmp);
    }
    if (right_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, right_c.int64_val);
        free_value(&right_c); right_c.type = VAL_INT; right_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*right_c.big_int, tmp); mpz_clear(tmp);
    }
    if (!(left_c.type == VAL_INT || left_c.type == VAL_FLOAT) ||
        !(right_c.type == VAL_INT || right_c.type == VAL_FLOAT)) kr_error("除法需要数值操作数");
    Value result;
    if (left_c.type == VAL_FLOAT || right_c.type == VAL_FLOAT) {
        mpf_t a, b, r; mpf_init(a); mpf_init(b); mpf_init(r);
        if (left_c.type == VAL_INT) mpf_set_z(a, *left_c.big_int); else mpf_set(a, *left_c.mpf_val);
        if (right_c.type == VAL_INT) mpf_set_z(b, *right_c.big_int); else mpf_set(b, *right_c.mpf_val);
        if (mpf_sgn(b) == 0) kr_error("除零错误");
        mpf_div(r, a, b); result = make_float(r);
        mpf_clear(a); mpf_clear(b); mpf_clear(r);
    } else {
        mpz_t a, b, r; mpz_init_set(a, *left_c.big_int); mpz_init_set(b, *right_c.big_int); mpz_init(r);
        if (mpz_sgn(b) == 0) kr_error("除零错误");
        mpz_tdiv_q(r, a, b); result = make_int_auto(r);
        mpz_clear(a); mpz_clear(b); mpz_clear(r);
    }
    free_value(&left_c); free_value(&right_c);
    return result;
}

static Value op_mod(const Value& left, const Value& right) {
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        int64_t a = left.int64_val, b = right.int64_val;
        if (b == 0) kr_error("取模零");
        return make_int64(a % b);
    }
    Value left_c = copy_value(left), right_c = copy_value(right);
    if (left_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, left_c.int64_val);
        free_value(&left_c); left_c.type = VAL_INT; left_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*left_c.big_int, tmp); mpz_clear(tmp);
    }
    if (right_c.type == VAL_INT64) {
        mpz_t tmp; mpz_init_set_si(tmp, right_c.int64_val);
        free_value(&right_c); right_c.type = VAL_INT; right_c.big_int = (mpz_t*)malloc(sizeof(mpz_t));
        mpz_init_set(*right_c.big_int, tmp); mpz_clear(tmp);
    }
    if (left_c.type != VAL_INT || right_c.type != VAL_INT) kr_error("取模仅支持整数");
    mpz_t a, b, r; mpz_init_set(a, *left_c.big_int); mpz_init_set(b, *right_c.big_int); mpz_init(r);
    if (mpz_sgn(b) == 0) kr_error("取模零");
    mpz_mod(r, a, b);
    Value result = make_int_auto(r);
    mpz_clear(a); mpz_clear(b); mpz_clear(r);
    free_value(&left_c); free_value(&right_c);
    return result;
}

static Value op_pow(const Value& left, const Value& right) {
    // 特殊：如果右操作数是指数，左操作数可为整数/浮点
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        int64_t a = left.int64_val, b = right.int64_val;
        if (b < 0) { // 负指数 -> 浮点结果
            double d = pow((double)a, (double)b);
            return make_float(d);
        }
        mpz_t la, lb, lr; mpz_init_set_si(la, a); mpz_init_set_si(lb, b); mpz_init(lr);
        if (!mpz_fits_ulong_p(lb)) kr_error("指数过大");
        mpz_pow_ui(lr, la, mpz_get_ui(lb));
        Value result = make_int_auto(lr);
        mpz_clear(la); mpz_clear(lb); mpz_clear(lr); return result;
    }
    // 通用路径：转为浮点计算（或 GMP 整数幂）
    double a = value_to_double(left), b = value_to_double(right);
    // 如果结果能精确表示为整数且指数非负，尝试 GMP
    if (right.type == VAL_INT || right.type == VAL_INT64) {
        long long exp = value_to_ll(right);
        if (exp >= 0 && exp < 10000 && left.type != VAL_FLOAT) {
            mpz_t base, res; mpz_init(base); mpz_init(res);
            value_to_mpz(left, base);
            mpz_pow_ui(res, base, (unsigned long)exp);
            Value result = make_int_auto(res);
            mpz_clear(base); mpz_clear(res);
            return result;
        }
    }
    return make_float(pow(a, b));
}

static Value op_concat(const Value& left, const Value& right) { // 对应 '##'
    char* lstr = value_to_string(left);
    char* rstr = value_to_string(right);
    char* res = (char*)malloc(strlen(lstr) + strlen(rstr) + 1);
    strcpy(res, lstr); strcat(res, rstr);
    Value result = make_string(res);
    free(res); free(lstr); free(rstr);
    return result;
}

static Value op_xor(const Value& left, const Value& right) { // 对应 'X'
    mpz_t a, b, r; mpz_init(a); mpz_init(b); mpz_init(r);
    value_to_mpz(left, a);
    value_to_mpz(right, b);
    mpz_xor(r, a, b);
    Value result = (mpz_fits_slong_p(r)) ? make_int64(mpz_get_si(r)) : make_int(r);
    mpz_clear(a); mpz_clear(b); mpz_clear(r);
    return result;
}

// 通用比较函数（返回 int64: -1, 0, 1 或 0/1）
static Value op_compare(const Value& left, const Value& right, char op) {
    // ---- 快速路径：双方都是原生 int64 ----
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        int64_t a = left.int64_val, b = right.int64_val;
        int res = 0;
        switch (op) {
            case '>': res = (a > b); break;
            case '<': res = (a < b); break;
            case 'E': res = (a == b); break;
            case 'N': res = (a != b); break;
            case 'G': res = (a >= b); break;
            case 'L': res = (a <= b); break;
            case 'C': res = (a > b) ? 1 : (a < b) ? -1 : 0; break;
        }
        return make_int64(res);
    }
    // ---- 1. null 处理 ----
    if (left.type == VAL_NULL || right.type == VAL_NULL) {
        if (op == 'E') return make_int((left.type == VAL_NULL && right.type == VAL_NULL) ? 1 : 0);
        if (op == 'N') return make_int(!(left.type == VAL_NULL && right.type == VAL_NULL) ? 1 : 0);
        kr_warn("null 与非 '=='/'!=' 运算符比较，返回 false");
        return make_int(0LL);
    }

    bool left_num = (left.type == VAL_INT || left.type == VAL_FLOAT || left.type == VAL_INT64);
    bool right_num = (right.type == VAL_INT || right.type == VAL_FLOAT || right.type == VAL_INT64);
    bool left_str = (left.type == VAL_STRING);
    bool right_str = (right.type == VAL_STRING);

    // ---- 2. 双方都是数值 ----
    if (left_num && right_num) {
        mpf_t a, b; mpf_init(a); mpf_init(b);
        if (left.type == VAL_INT64) mpf_set_si(a, left.int64_val);
        else if (left.type == VAL_INT) mpf_set_z(a, *left.big_int);
        else mpf_set(a, *left.mpf_val);

        if (right.type == VAL_INT64) mpf_set_si(b, right.int64_val);
        else if (right.type == VAL_INT) mpf_set_z(b, *right.big_int);
        else mpf_set(b, *right.mpf_val);

        int cmp = mpf_cmp(a, b);
        mpf_clear(a); mpf_clear(b);
        int res = 0;
        switch (op) {
            case '>': res = (cmp > 0); break;
            case '<': res = (cmp < 0); break;
            case 'E': res = (cmp == 0); break;
            case 'N': res = (cmp != 0); break;
            case 'G': res = (cmp >= 0); break;
            case 'L': res = (cmp <= 0); break;
            case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
        }
        return make_int(res);
    }

    // ---- 3. 字符串与数字混合（或纯字符串） ----
    mpf_t left_mpf, right_mpf; mpf_init(left_mpf); mpf_init(right_mpf);
    bool left_parsed = false, right_parsed = false;
    if (left_str) { if (mpf_set_str(left_mpf, left.str_val, 10) == 0) left_parsed = true; }
    if (right_str) { if (mpf_set_str(right_mpf, right.str_val, 10) == 0) right_parsed = true; }

    bool can_do_numeric = false;
    mpf_t a, b; mpf_init(a); mpf_init(b);
    if (left_num && right_parsed) {
        can_do_numeric = true;
        if (left.type == VAL_INT64) mpf_set_si(a, left.int64_val);
        else if (left.type == VAL_INT) mpf_set_z(a, *left.big_int);
        else mpf_set(a, *left.mpf_val);
        mpf_set(b, right_mpf);
    } else if (left_parsed && right_num) {
        can_do_numeric = true;
        mpf_set(a, left_mpf);
        if (right.type == VAL_INT64) mpf_set_si(b, right.int64_val);
        else if (right.type == VAL_INT) mpf_set_z(b, *right.big_int);
        else mpf_set(b, *right.mpf_val);
    } else if (left_parsed && right_parsed) {
        can_do_numeric = true;
        mpf_set(a, left_mpf); mpf_set(b, right_mpf);
    }

    if (can_do_numeric) {
        int cmp = mpf_cmp(a, b);
        mpf_clear(a); mpf_clear(b); mpf_clear(left_mpf); mpf_clear(right_mpf);
        int res = 0;
        switch (op) {
            case '>': res = (cmp > 0); break;
            case '<': res = (cmp < 0); break;
            case 'E': res = (cmp == 0); break;
            case 'N': res = (cmp != 0); break;
            case 'G': res = (cmp >= 0); break;
            case 'L': res = (cmp <= 0); break;
            case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
        }
        return make_int(res);
    }

    // ---- 4. 单字符与数字比较（旧逻辑） ----
    std::string left_s, right_s;
    if (left_str && right_num && strlen(left.str_val) == 1) {
        long long n = value_to_ll(right);
        if (n >= 0 && n <= 255) { left_s = left.str_val; right_s = std::string(1, (char)n); }
    } else if (left_num && right_str && strlen(right.str_val) == 1) {
        long long n = value_to_ll(left);
        if (n >= 0 && n <= 255) { left_s = std::string(1, (char)n); right_s = right.str_val; }
    }
    if (!left_s.empty() && !right_s.empty()) {
        int cmp = strcmp(left_s.c_str(), right_s.c_str());
        mpf_clear(left_mpf); mpf_clear(right_mpf);
        int res = 0;
        switch (op) {
            case '>': res = (cmp > 0); break;
            case '<': res = (cmp < 0); break;
            case 'E': res = (cmp == 0); break;
            case 'N': res = (cmp != 0); break;
            case 'G': res = (cmp >= 0); break;
            case 'L': res = (cmp <= 0); break;
            case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
        }
        return make_int(res);
    }

    // ---- 5. 纯字符串比较 ----
    char* ls = value_to_string(left);
    char* rs = value_to_string(right);
    int cmp = strcmp(ls, rs);
    free(ls); free(rs);
    mpf_clear(left_mpf); mpf_clear(right_mpf);
    int res = 0;
    switch (op) {
        case '>': res = (cmp > 0); break;
        case '<': res = (cmp < 0); break;
        case 'E': res = (cmp == 0); break;
        case 'N': res = (cmp != 0); break;
        case 'G': res = (cmp >= 0); break;
        case 'L': res = (cmp <= 0); break;
        case 'C': res = (cmp > 0 ? 1 : (cmp < 0 ? -1 : 0)); break;
    }
    return make_int(res);
}

// 若 r 能放进 long 就返回 int64，否则返回 GMP int
static inline Value value_from_mpz_result(mpz_t r) {
    if (mpz_fits_slong_p(r)) {
        return make_int64((int64_t)mpz_get_si(r));
    }
    return make_int(r);
}

static Value op_bit_or(const Value& left, const Value& right) {
    // 快速路径：双方原生 int64（补码按位或，结果必然在 int64 内）
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        return make_int64(left.int64_val | right.int64_val);
    }
    if (!(left.type == VAL_INT64 || left.type == VAL_INT) ||
        !(right.type == VAL_INT64 || right.type == VAL_INT)) {
        kr_error("位运算符要求整数操作数");
    }
    mpz_t a, b, r;
    mpz_init(a); mpz_init(b); mpz_init(r);
    if (left.type  == VAL_INT64) mpz_set_int64(a, left.int64_val);
    else                          mpz_set(a, *left.big_int);
    if (right.type == VAL_INT64) mpz_set_int64(b, right.int64_val);
    else                          mpz_set(b, *right.big_int);
    mpz_ior(r, a, b);
    Value result = value_from_mpz_result(r);
    mpz_clear(a); mpz_clear(b); mpz_clear(r);
    return result;
}

static Value op_bit_and(const Value& left, const Value& right) {
    if (left.type == VAL_INT64 && right.type == VAL_INT64) {
        return make_int64(left.int64_val & right.int64_val);
    }
    if (!(left.type == VAL_INT64 || left.type == VAL_INT) ||
        !(right.type == VAL_INT64 || right.type == VAL_INT)) {
        kr_error("位运算符要求整数操作数");
    }
    mpz_t a, b, r;
    mpz_init(a); mpz_init(b); mpz_init(r);
    if (left.type  == VAL_INT64) mpz_set_int64(a, left.int64_val);
    else                          mpz_set(a, *left.big_int);
    if (right.type == VAL_INT64) mpz_set_int64(b, right.int64_val);
    else                          mpz_set(b, *right.big_int);
    mpz_and(r, a, b);
    Value result = value_from_mpz_result(r);
    mpz_clear(a); mpz_clear(b); mpz_clear(r);
    return result;
}

static Value op_shl(const Value& left, const Value& right) {
    if (!(left.type == VAL_INT64 || left.type == VAL_INT) ||
        !(right.type == VAL_INT64 || right.type == VAL_INT)) {
        kr_error("位运算符要求整数操作数");
    }
    mpz_t a, b, r;
    mpz_init(a); mpz_init(b); mpz_init(r);
    if (left.type  == VAL_INT64) mpz_set_int64(a, left.int64_val);
    else                          mpz_set(a, *left.big_int);
    if (right.type == VAL_INT64) mpz_set_int64(b, right.int64_val);
    else                          mpz_set(b, *right.big_int);
    if (!mpz_fits_ulong_p(b)) {
        mpz_clear(a); mpz_clear(b); mpz_clear(r);
        kr_error("左移位数过大");
    }
    unsigned long shift = mpz_get_ui(b);
    mpz_mul_2exp(r, a, shift);
    Value result = value_from_mpz_result(r);
    mpz_clear(a); mpz_clear(b); mpz_clear(r);
    return result;
}

static Value op_shr(const Value& left, const Value& right) {
    if (!(left.type == VAL_INT64 || left.type == VAL_INT) ||
        !(right.type == VAL_INT64 || right.type == VAL_INT)) {
        kr_error("位运算符要求整数操作数");
    }
    mpz_t a, b, r;
    mpz_init(a); mpz_init(b); mpz_init(r);
    if (left.type  == VAL_INT64) mpz_set_int64(a, left.int64_val);
    else                          mpz_set(a, *left.big_int);
    if (right.type == VAL_INT64) mpz_set_int64(b, right.int64_val);
    else                          mpz_set(b, *right.big_int);
    if (!mpz_fits_ulong_p(b)) {
        mpz_clear(a); mpz_clear(b); mpz_clear(r);
        kr_error("右移位数过大");
    }
    unsigned long shift = mpz_get_ui(b);
    mpz_tdiv_q_2exp(r, a, shift);   // 向零取整，与解释器一致
    Value result = value_from_mpz_result(r);
    mpz_clear(a); mpz_clear(b); mpz_clear(r);
    return result;
}

// ============================================================================
// exec_statement
// ============================================================================

static void push_int_operand(Bytecode& bc, int value) {
    bc.code.push_back((value >> 0) & 0xFF);
    bc.code.push_back((value >> 8) & 0xFF);
    bc.code.push_back((value >> 16) & 0xFF);
    bc.code.push_back((value >> 24) & 0xFF);
}

static int read_int_operand(const Bytecode& bc, size_t& pc) {
    int value;
    std::memcpy(&value, bc.code.data() + pc, 4);
    pc += 4;
    return value;
}

// 将 4 字节整数写入字节码指定偏移位置（用于回填）
static void write_int_operand(Bytecode& bc, size_t offset, int value) {
    if (offset + 4 > bc.code.size()) {
        kr_error("write_int_operand: 偏移越界");
    }
    bc.code[offset] = (value >> 0) & 0xFF;
    bc.code[offset + 1] = (value >> 8) & 0xFF;
    bc.code[offset + 2] = (value >> 16) & 0xFF;
    bc.code[offset + 3] = (value >> 24) & 0xFF;
}

// 压入 64 位整数常量（用于索引初始值等）
static void push_int64_operand(Bytecode& bc, int64_t value) {
    bc.code.push_back(OP_PUSH_INT64);
    for (int i = 0; i < 8; ++i) {
        bc.code.push_back((value >> (i * 8)) & 0xFF);
    }
}

// 压入字符串常量（用于变量名等），返回其在常量池中的索引
static int push_string_operand(Bytecode& bc, const char* str) {
    auto it = bc.string_intern.find(str);
    if (it != bc.string_intern.end()) return it->second;

    int idx = (int)bc.constants.size();
    bc.constants.push_back(make_string(str));
    bc.string_intern[str] = idx;
    return idx;
}

static void push_int64_bytes(Bytecode& bc, int64_t value) {
    for (int i = 0; i < 8; ++i)
        bc.code.push_back((value >> (i * 8)) & 0xFF);
}

static int64_t read_int64_operand(const Bytecode& bc, size_t& pc) {
    int64_t value = 0;
    for (int i = 0; i < 8; ++i)
        value |= (static_cast<int64_t>(bc.code[pc++]) << (i * 8));
    return value;
}

static bool compile_constant_int(ASTNode* node, long long& val, int depth = 0) {
    // 防循环引用栈溢出，最大递归深度
    const int MAX_DEPTH = 32;
    if (depth > MAX_DEPTH)
        return false;
    if (!node)
        return false;

    // 1. 数字字面量 NODE_NUMBER
    if (node->type == NODE_NUMBER) {
        mpz_t tmp;
        mpz_init(tmp);
        bool ok = false;
        if (mpz_set_str(tmp, node->data.number_str, 10) == 0)
        {
            if (mpz_fits_slong_p(tmp))
            {
                val = mpz_get_si(tmp);
                ok = true;
            }
        }
        mpz_clear(tmp);
        return ok;
    }

    // 2. 二元常量表达式 + - * / % ^
    if (node->type == NODE_BINARY) {
        long long L, R;
        if (!compile_constant_int(node->data.binary.left,  L, depth + 1)) return false;
        if (!compile_constant_int(node->data.binary.right, R, depth + 1)) return false;

        switch (node->data.binary.op) {
        case '+': val = L + R; return true;
        case '-': val = L - R; return true;
        case '*': val = L * R; return true;
        case '/':
            if (R == 0) return false;
            val = L / R;
            return true;
        case '%':
            if (R == 0) return false;
            val = L % R;
            return true;
        case '^': {
            // 仅支持非负指数，结果不能溢出int64
            if (R < 0 || R > 62) return false;
            long long r = 1;
            bool overflow = false;
            for (long long k = 0; k < R; ++k)
            {
                if (__builtin_mul_overflow(r, L, &r))
                {
                    overflow = true;
                    break;
                }
            }
            if (overflow) return false;
            val = r;
            return true;
        }
        default:
            return false;
        }
    }

    // 3. 变量引用节点 NODE_VARIABLE：处理 const 编译期常量
    if (node->type == NODE_VARIABLE) {
        const char* name = node->data.var_name;
        ASTNode* const_init_ast = nullptr;

        // 从栈顶(当前scope)向栈底(外层scope)遍历，模拟scope查找、内层遮蔽外层
        for (auto it = g_compile_const_stack.rbegin(); it != g_compile_const_stack.rend(); ++it) {
            auto found = it->find(std::string(name));
            if (found != it->end()) {
                const_init_ast = found->second;
                break;
            }
        }

        if (const_init_ast == nullptr)
            return false;

        return compile_constant_int(const_init_ast, val, depth + 1);
    }

    // 其它节点类型一律判定非编译期整数常量
    return false;
}

// 优化项：
//   [优化一] const 变量引用折叠（通过 compile_constant_int  NODE_VARIABLE 分支）
//   [优化二] const 循环变量跳过写检查（decl_is_const 时跳过 walk_ast）
//   [优化三] 循环变量未读取时跳过刷新（body_reads_var 标志传给解释器）
// 注意：编译器不消除循环本身，保持 OP_NATIVE_FOR 结构
static bool try_compile_native_for(ASTNode* node, Bytecode& bc) {
    ASTNode* init   = node->data.for_stmt.init;
    ASTNode* cond   = node->data.for_stmt.cond;
    ASTNode* update = node->data.for_stmt.update;
    ASTNode* body   = node->data.for_stmt.body;
    if (!init || !cond || !update) return false;

    auto unwrap = [](ASTNode* n) -> ASTNode* {
        return (n && n->type == NODE_EXPR_STMT) ? n->data.expr_stmt.expr : n;
    };
    init = unwrap(init); cond = unwrap(cond); update = unwrap(update);
    if (!init || !cond || !update) return false;

    // --- init：i = const / var i = const ---
    std::string var_name;
    long long start_val;
    bool is_new_decl = false;
    bool decl_is_const = false, decl_is_global = false;
    if (init->type == NODE_VAR_DECL) {
        if (!compile_constant_int(init->data.var_decl.expr, start_val)) return false;
        var_name = init->data.var_decl.name;
        is_new_decl = true;
        decl_is_const = init->data.var_decl.is_const;
        decl_is_global = init->data.var_decl.global;
    } else if (init->type == NODE_ASSIGN) {
        if (!compile_constant_int(init->data.assign.expr, start_val)) return false;
        var_name = init->data.assign.name;
        is_new_decl = true;
    } else return false;

    // --- cond：i <OP> const ---
    // [优化一] compile_constant_int 已支持 const 变量引用，此处可直接折叠 count
    if (cond->type != NODE_BINARY) return false;
    char cmp = cond->data.binary.op;
    if (cmp != '<' && cmp != 'L' && cmp != '>' && cmp != 'G') return false;
    if (cond->data.binary.left->type != NODE_VARIABLE) return false;
    if (strcmp(cond->data.binary.left->data.var_name, var_name.c_str()) != 0)
        return false;
    long long end_val;
    if (!compile_constant_int(cond->data.binary.right, end_val)) return false;

    // --- update：i++ / i-- / i+=k / i-=k / i=i+k / i=i-k ---
    long long step = 0;
    if (update->type == NODE_PRE_INC || update->type == NODE_POST_INC) {
        if (update->data.inc_dec.operand->type != NODE_VARIABLE) return false;
        if (strcmp(update->data.inc_dec.operand->data.var_name,
                   var_name.c_str()) != 0) return false;
        step = 1;
    } else if (update->type == NODE_PRE_DEC || update->type == NODE_POST_DEC) {
        if (update->data.inc_dec.operand->type != NODE_VARIABLE) return false;
        if (strcmp(update->data.inc_dec.operand->data.var_name,
                   var_name.c_str()) != 0) return false;
        step = -1;
    } else if (update->type == NODE_ASSIGN) {
        if (strcmp(update->data.assign.name, var_name.c_str()) != 0) return false;
        ASTNode* rhs = update->data.assign.expr;
        if (!rhs || rhs->type != NODE_BINARY) return false;
        if (rhs->data.binary.op != '+' && rhs->data.binary.op != '-') return false;
        if (rhs->data.binary.left->type != NODE_VARIABLE) return false;
        if (strcmp(rhs->data.binary.left->data.var_name, var_name.c_str()) != 0)
            return false;
        long long k;
        if (!compile_constant_int(rhs->data.binary.right, k)) return false;
        step = (rhs->data.binary.op == '+') ? k : -k;
    } else return false;
    if (step == 0) return false;

    // --- 循环体里不能有 break/continue（第一版保守策略）---
    bool has_break_continue = false;
    if (body) {
        walk_ast(body, [&](ASTNode* n) {
            if (n->type == NODE_BREAK || n->type == NODE_CONTINUE)
                has_break_continue = true;
        });
    }
    if (has_break_continue) return false;

    // --- [优化二] 循环体不能写循环变量 ---
    // 若循环变量声明为 const，则不可能被修改，跳过昂贵的 walk_ast 遍历
    bool body_writes_var = false;
    if (!decl_is_const && body) {  // <-- const 变量跳过检查
        walk_ast(body, [&](ASTNode* n) {
            if (n->type == NODE_ASSIGN &&
                strcmp(n->data.assign.name, var_name.c_str()) == 0)
                body_writes_var = true;
            if ((n->type == NODE_PRE_INC || n->type == NODE_PRE_DEC ||
                 n->type == NODE_POST_INC || n->type == NODE_POST_DEC) &&
                n->data.inc_dec.operand->type == NODE_VARIABLE &&
                strcmp(n->data.inc_dec.operand->data.var_name,
                       var_name.c_str()) == 0)
                body_writes_var = true;
        });
    }
    if (body_writes_var) return false;

    // --- 循环体是否读循环变量 ---
    // [优化三] 用于告诉解释器是否需要每次刷新 var->value
    bool body_reads_var = false;
    if (body) {
        walk_ast(body, [&](ASTNode* n) {
            if (n->type == NODE_VARIABLE &&
                strcmp(n->data.var_name, var_name.c_str()) == 0)
                body_reads_var = true;
        });
    }

    // --- 防溢出 ---
    const long long SAFE = LLONG_MAX / 4;
    if (start_val > SAFE || start_val < -SAFE ||
        end_val   > SAFE || end_val   < -SAFE ||
        step      > SAFE || step      < -SAFE)
        return false;

    // ---------- 发出 OP_NATIVE_FOR ----------
    bc.code.push_back(OP_NATIVE_FOR);
    int name_idx = push_string_operand(bc, var_name.c_str());
    push_int_operand(bc, name_idx);
    push_int64_bytes(bc, (int64_t)start_val);
    push_int64_bytes(bc, (int64_t)end_val);
    push_int64_bytes(bc, (int64_t)step);
    uint8_t cmp_code = (cmp == '<') ? 0 : (cmp == 'L') ? 1 : (cmp == '>') ? 2 : 3;
    bc.code.push_back(cmp_code);
    bc.code.push_back(body_reads_var ? 1 : 0);
    bc.code.push_back(is_new_decl ? 1 : 0);
    bc.code.push_back(decl_is_const ? 1 : 0);
    bc.code.push_back(decl_is_global ? 1 : 0);
    // body_size 占位
    size_t size_pos = bc.code.size();
    push_int_operand(bc, 0);
    size_t body_start = bc.code.size();
    if (body) compile_statement(body, bc);
    size_t body_end = bc.code.size();
    write_int_operand(bc, size_pos, (int)(body_end - body_start));
    return true;
}

static Value eval_const_expr_simple(ASTNode* n) {
    if (!n) return make_null();
    switch (n->type) {
        case NODE_NUMBER: {
            const char* s = n->data.number_str;
            if (!s) return make_null();

            // 快速路径：strtoll 能直接吃下
            errno = 0;
            char* end = nullptr;
            long long v = strtoll(s, &end, 0);
            if (end && *end == '\0' && end != s && errno == 0)
                return make_int64((int64_t)v);

            // 回退 GMP（0x / 0b / 0o / 大整数）
            mpz_t tmp; mpz_init(tmp);
            int base = 10;
            const char* ns = s;
            if (strncmp(s, "0x", 2) == 0 || strncmp(s, "0X", 2) == 0) { base = 16; ns = s + 2; }
            else if (strncmp(s, "0b", 2) == 0 || strncmp(s, "0B", 2) == 0) { base = 2;  ns = s + 2; }
            else if (strncmp(s, "0o", 2) == 0 || strncmp(s, "0O", 2) == 0) { base = 8;  ns = s + 2; }
            if (mpz_set_str(tmp, ns, base) != 0) {
                mpz_clear(tmp);
                return make_null();
            }
            Value r = make_int_auto(tmp);
            mpz_clear(tmp);
            return r;
        }
        case NODE_FLOAT: {
            if (!n->data.float_str) return make_null();
            mpf_t tmp; mpf_init(tmp);
            if (mpf_set_str(tmp, n->data.float_str, 10) != 0) {
                mpf_clear(tmp);
                return make_null();
            }
            Value r = make_float(tmp);
            mpf_clear(tmp);
            return r;
        }
        case NODE_STRING:
            return make_string(n->data.string ? n->data.string : "");
        case NODE_NULL:
            return make_null();
        default:
            // 复杂表达式（三元、函数调用、数组字面量等）暂不折叠 → null
            return make_null();
    }
}

static void collect_param_defaults(ASTNode* def_node,
                                   CompiledFunction& cf,
                                   Bytecode& bc) {
    int pc = def_node->data.func_def.param_count;
    cf.param_defaults_idx.assign(pc, -1);
    cf.param_default_code_off.assign(pc, SIZE_MAX);
    cf.param_default_code_end.assign(pc, SIZE_MAX);
    cf.param_has_default.assign(pc, false);
    cf.param_types.assign(pc, std::string());
    cf.param_is_const.assign(pc, false);

    for (int i = 0; i < pc; ++i) {
        if (def_node->data.func_def.param_is_const)
            cf.param_is_const[i] = def_node->data.func_def.param_is_const[i];

        if (def_node->data.func_def.param_types &&
            def_node->data.func_def.param_types[i]) {
            cf.param_types[i] =
                type_to_string(def_node->data.func_def.param_types[i]);
        }

        ASTNode* dflt = def_node->data.func_def.param_defaults
                            ? def_node->data.func_def.param_defaults[i]
                            : nullptr;
        if (!dflt) continue;

        cf.param_has_default[i] = true;               // 

        Value v = eval_const_expr_simple(dflt);
        //  只要不是"字面量 null"，就认为折叠失败 → 走运行时默认值代码块
        if (v.type == VAL_NULL && dflt->type != NODE_NULL) {
            continue;    // 保留 -1，后续编译时发代码块
        }
        int cidx = (int)bc.constants.size();
        bc.constants.push_back(v);
        cf.param_defaults_idx[i] = cidx;
    }

    if (def_node->data.func_def.return_type)
        cf.return_type = type_to_string(def_node->data.func_def.return_type);
    if (def_node->data.func_def.vararg_name)
        cf.vararg_name = def_node->data.func_def.vararg_name;
    if (def_node->data.func_def.vararg_type)
        cf.vararg_type = type_to_string(def_node->data.func_def.vararg_type);
    if (current_filename)
        cf.defining_file = current_filename;
}

// 预扫描，只注册名字/参数
static void prescan_func_defs(ASTNode* root, Bytecode& bc) {
    walk_ast(root, [&](ASTNode* n) {
        bool is_func = (n->type == NODE_FUNC_DEF ||
                        n->type == NODE_ASYNC_FUNC_DEF ||
                        n->type == NODE_RULE_DEF);
        if (is_func && n->data.func_def.name) {
            const char* name_ptr = intern_name(bc, n->data.func_def.name);
            if (bc.func_by_name.count(name_ptr)) return;

            CompiledFunction cf;
            cf.name = name_ptr;                             // std::string 从 const char* 构造
            cf.params.reserve(n->data.func_def.param_count);
            for (int i = 0; i < n->data.func_def.param_count; ++i)
                cf.params.emplace_back(n->data.func_def.params[i]);
            cf.code_offset  = SIZE_MAX;
            cf.is_async     = (n->type == NODE_ASYNC_FUNC_DEF);
            cf.is_rule      = (n->type == NODE_RULE_DEF);
            cf.is_memoized  = n->data.func_def.is_memoized;
            cf.global_scope = n->data.func_def.global_scope;
            cf.called       = false;

            collect_param_defaults(n, cf, bc);

            int idx = (int)bc.functions.size();
            bc.functions.push_back(std::move(cf));
            bc.func_by_name[name_ptr] = idx;                //  直接裸指针为键
        }
        else if (n->type == NODE_STRUCT_DEF && n->data.struct_def.name) {
            const char* name_ptr = intern_name(bc, n->data.struct_def.name);
            if (bc.func_by_name.count(name_ptr)) return;

            CompiledFunction cf;
            cf.name = name_ptr;
            cf.params.reserve(n->data.struct_def.field_count);
            for (int i = 0; i < n->data.struct_def.field_count; ++i)
                cf.params.emplace_back(n->data.struct_def.fields[i].name);
            cf.code_offset = SIZE_MAX;
            cf.param_defaults_idx.assign(cf.params.size(), -1);
            cf.param_default_code_off.assign(cf.params.size(), SIZE_MAX);
            cf.param_default_code_end.assign(cf.params.size(), SIZE_MAX);
            cf.param_has_default.assign(cf.params.size(), false);
            cf.param_types.assign(cf.params.size(), std::string());
            cf.param_is_const.assign(cf.params.size(), false);
            cf.called = true;

            int idx = (int)bc.functions.size();
            bc.functions.push_back(std::move(cf));
            bc.func_by_name[name_ptr] = idx;
        }
        else if (n->type == NODE_UNION_DEF) {
            // 注意：不再因为 union_name 为空就 return。
            // 变体本身就是独立的函数值，与 union 名无关。
            for (int i = 0; i < n->data.union_def.variant_count; ++i) {
                UnionVariant* v = &n->data.union_def.variants[i];
                const char* vn = v->name;
                if (!vn || !*vn) continue;
        
                // 与普通函数一致：键必须 intern，避免 AST 释放后悬空
                const char* vn_key = intern_name(bc, vn);
                if (bc.func_by_name.count(vn_key)) continue;   // 重名不覆盖
        
                CompiledFunction cf;
                cf.name        = vn_key;
                cf.code_offset = SIZE_MAX;
                cf.is_async    = false;
                cf.is_rule     = false;
                cf.global_scope = false;
                cf.called       = true;
                if (current_filename) cf.defining_file = current_filename;
        
                const int count = (v->param_count > 0) ? v->param_count : v->field_count;
                for (int j = 0; j < count; ++j) {
                    if (v->param_count > 0) {
                        cf.params.emplace_back(std::to_string(j));
                    } else {
                        cf.params.emplace_back(v->named_fields[j].name);
                    }
                }
        
                cf.param_defaults_idx.assign(count, -1);
                cf.param_default_code_off.assign(count, SIZE_MAX);
                cf.param_default_code_end.assign(count, SIZE_MAX);
                cf.param_has_default.assign(count, false);
                cf.param_types.assign(count, std::string());
                cf.param_is_const.assign(count, false);
        
                int idx = (int)bc.functions.size();
                bc.functions.push_back(std::move(cf));
                bc.func_by_name[vn_key] = idx;
            }
        }
        else if (n->type == NODE_ENUM_DEF) {
            // 与 NODE_UNION_DEF 同构：变体是独立函数值，与 enum 名无关。
            // 参数名统一用位置索引 "0"、"1"、...（enum 不携带命名字段信息）。
            for (int i = 0; i < n->data.enum_def.variant_count; ++i) {
                const char* vn = n->data.enum_def.variants
                                    ? n->data.enum_def.variants[i] : nullptr;
                if (!vn || !*vn) continue;
        
                const char* vn_key = intern_name(bc, vn);
                if (bc.func_by_name.count(vn_key)) continue;   // 重名不覆盖
        
                CompiledFunction cf;
                cf.name         = vn_key;
                cf.code_offset  = SIZE_MAX;
                cf.is_async     = false;
                cf.is_rule      = false;
                cf.global_scope = false;
                cf.called       = true;
                if (current_filename) cf.defining_file = current_filename;
        
                const int count = n->data.enum_def.variant_param_counts
                                    ? n->data.enum_def.variant_param_counts[i] : 0;
                for (int j = 0; j < count; ++j)
                    cf.params.emplace_back(std::to_string(j));
        
                cf.param_defaults_idx.assign(count, -1);
                cf.param_default_code_off.assign(count, SIZE_MAX);
                cf.param_default_code_end.assign(count, SIZE_MAX);
                cf.param_has_default.assign(count, false);
                cf.param_types.assign(count, std::string());
                cf.param_is_const.assign(count, false);
        
                int idx = (int)bc.functions.size();
                bc.functions.push_back(std::move(cf));
                bc.func_by_name[vn_key] = idx;
            }
        }
    });
}
static void prescan_class_defs(ASTNode* root, Bytecode& bc) {
    walk_ast(root, [&](ASTNode* n) {
        if (n->type != NODE_CLASS_DEF) return;
        const char* nm = n->data.class_def.name;
        if (!nm || !*nm) return;
        std::string name = nm;
        if (bc.class_by_name.count(name)) return;

        CompiledClass cc;
        cc.name            = name;
        cc.parent          = n->data.class_def.parent ? n->data.class_def.parent : "";
        cc.access_modifier = n->data.class_def.access_modifier;
        cc.is_static_class = n->data.class_def.is_static_class;

        // 构造参数名
        for (int i = 0; i < n->data.class_def.ctor_param_count; ++i)
            cc.ctor_params.emplace_back(n->data.class_def.ctor_params[i]);

        // 构造参数类型（转成字符串，VM 侧用 vm_check_type 比对）
        cc.ctor_param_types.assign(cc.ctor_params.size(), std::string());
        int tn = n->data.class_def.ctor_param_type_count;
        for (int i = 0; i < tn && i < (int)cc.ctor_params.size(); ++i) {
            TypeNode* t = n->data.class_def.ctor_param_types[i];
            if (t) cc.ctor_param_types[i] = type_to_string(t);
        }

        // 默认值索引先用 -1 占位（编译阶段再回填）
        cc.ctor_defaults_idx.assign(cc.ctor_params.size(), -1);

        int idx = (int)bc.classes.size();
        const auto& M = n->data.class_def.methods;

        for (int mi = 0; mi < M.count; ++mi) {
            const char* mname = M.names ? M.names[mi] : nullptr;
            if (!mname) continue;

            // 全局唯一名 Class::method，避免与其他类同名方法冲突
            std::string full = name + "::" + mname;
            const char* full_key = intern_name(bc, full.c_str());

            if (bc.func_by_name.count(full_key)) continue;

            CompiledFunction mf;
            mf.name = full;
            mf.code_offset = SIZE_MAX;
            mf.is_async    = false;
            mf.is_rule     = false;
            mf.global_scope = false;
            if (current_filename) mf.defining_file = current_filename;

            const int pc_count = M.param_counts ? M.param_counts[mi] : 0;
            mf.params.reserve(pc_count);
            for (int i = 0; i < pc_count; ++i)
                mf.params.emplace_back(M.param_lists[mi][i]);

            // 参数元数据（方法没有默认值）
            mf.param_defaults_idx.assign(pc_count, -1);
            mf.param_default_code_off.assign(pc_count, SIZE_MAX);
            mf.param_default_code_end.assign(pc_count, SIZE_MAX);
            mf.param_has_default.assign(pc_count, false);
            mf.param_types.assign(pc_count, std::string());
            mf.param_is_const.assign(pc_count, false);
            for (int i = 0; i < pc_count; ++i) {
                if (M.param_types && M.param_types[mi] && M.param_types[mi][i])
                    mf.param_types[i] = type_to_string(M.param_types[mi][i]);
            }
            if (M.return_types && M.return_types[mi])
                mf.return_type = type_to_string(M.return_types[mi]);
            if (M.vararg_names && M.vararg_names[mi])
                mf.vararg_name = M.vararg_names[mi];
            if (M.vararg_types && M.vararg_types[mi])
                mf.vararg_type = type_to_string(M.vararg_types[mi]);

            int idx = (int)bc.functions.size();
            bc.functions.push_back(std::move(mf));

            cc.methods.emplace_back(mname, idx);
            cc.method_is_static.push_back(M.is_static ? M.is_static[mi] : false);
            cc.method_access.push_back(M.access ? M.access[mi] : 0);
            bc.func_by_name[full_key] = idx;
        }

        bc.classes.push_back(std::move(cc));
        bc.class_by_name[name] = idx;
    });
}

static void prescan_namespace_defs(ASTNode* root, Bytecode& bc) {
    walk_ast(root, [&](ASTNode* n) {
        if (n->type != NODE_UMF_DEF) return;
        const char* nm = n->data.umf_def.name;
        if (!nm || !*nm) return;
        std::string name = nm;
        int idx;
        auto it = bc.ns_by_name.find(name);
        if (it == bc.ns_by_name.end()) {
            idx = (int)bc.namespaces.size();
            bc.ns_by_name[name] = idx;
            bc.namespaces.emplace_back();
            bc.namespaces.back().name = name;
        } else {
            idx = it->second;
        }
        // 收集命名空间体里定义的类短名
        walk_ast(n->data.umf_def.body, [&](ASTNode* c) {
            if (c->type == NODE_CLASS_DEF && c->data.class_def.name)
                bc.namespaces[idx].class_shortnames.emplace_back(
                    c->data.class_def.name);
        });
    });
}

static void emit_push_constant(Bytecode& bc, int const_idx) {
    const Value& v = bc.constants[const_idx];
    switch (v.type) {
        case VAL_INT64:
            push_int64_operand(bc, v.int64_val);
            break;
        case VAL_INT:
            bc.code.push_back(OP_PUSH_INT);
            push_int_operand(bc, const_idx);
            break;
        case VAL_FLOAT:
            bc.code.push_back(OP_PUSH_FLOAT);
            push_int_operand(bc, const_idx);
            break;
        case VAL_STRING:
            bc.code.push_back(OP_PUSH_STRING);
            push_int_operand(bc, const_idx);
            break;
        case VAL_NULL:
            bc.code.push_back(OP_PUSH_NULL);
            break;
        default:
            kr_error("emit_push_constant: 不支持的默认值类型 %d", (int)v.type);
    }
}

static inline void vm_check_return_type(const Bytecode& bc,
                                        int func_idx,
                                        Value& ret) {
    if (func_idx < 0) return;
    const CompiledFunction& cf = bc.functions[func_idx];
    if (cf.return_type.empty()) return;
    if (vm_check_type(ret, cf.return_type)) return;

    char* got = value_to_string(ret);
    kr_warn("函数 '%s' 返回值类型不匹配：期望 '%s'，实际 '%s'",
            cf.name.c_str(), cf.return_type.c_str(), got);
    free(got);
    free_value(&ret);
    ret = make_null();
}

static void compile_param_default_code(ASTNode* def_node,
                                       int func_idx,
                                       Bytecode& bc) {
    if (func_idx < 0 || func_idx >= (int)bc.functions.size()) return;

    // 初始化元数据数组（此块内不 push 新函数，可以安全持引用）
    {
        CompiledFunction& cf = bc.functions[func_idx];
        const int n = (int)cf.params.size();
        if ((int)cf.param_default_code_off.size() < n)
            cf.param_default_code_off.resize(n, SIZE_MAX);
        if ((int)cf.param_default_code_end.size() < n)
            cf.param_default_code_end.resize(n, SIZE_MAX);
    }

    const int n = (int)bc.functions[func_idx].params.size();
    for (int i = 0; i < n; ++i) {
        // 判断折叠状态：每轮重新取引用，不跨 push
        {
            CompiledFunction& cf = bc.functions[func_idx];
            if (i < (int)cf.param_defaults_idx.size() &&
                cf.param_defaults_idx[i] >= 0)
                continue;   // 已折叠
        }
        ASTNode* dflt = def_node->data.func_def.param_defaults
                            ? def_node->data.func_def.param_defaults[i]
                            : nullptr;
        if (!dflt) continue;
        if (dflt->type == NODE_NULL) continue;   // 折叠结果就是 null

        bc.functions[func_idx].param_default_code_off[i] = bc.code.size();
        compile_expr(dflt, bc);                  // 可能 push 新函数
        bc.functions[func_idx].param_default_code_end[i] = bc.code.size();  // 用前重取
    }
}

// 统一的函数值构造：所有需要生成 VAL_FUNCTION 的地方都走这里
static Value make_compiled_func_value(const CompiledFunction& cf,
                                      int func_idx, bool is_rule) {
    Value v;
    memset(&v, 0, sizeof(Value));
    v.type = VAL_FUNCTION;
    v.func_val.name         = strdup(cf.name.c_str());
    v.func_val.param_count  = (int)cf.params.size();
    if (v.func_val.param_count > 0) {
        v.func_val.params = (char**)malloc(
            (size_t)v.func_val.param_count * sizeof(char*));
        for (int i = 0; i < v.func_val.param_count; ++i)
            v.func_val.params[i] = strdup(cf.params[i].c_str());
    }
    v.func_val.global_scope = true;
    v.func_val.filename     = strdup("-");
    v.func_val.is_async     = cf.is_async;
    v.func_val.is_rule      = is_rule;
    v.func_val.compiled_idx = func_idx;
    return v;
}

// 在"原始上下文"里编译一个表达式：只对根节点是 NODE_VARIABLE / NODE_THIS
// 时使用 OP_GET_VAR_RAW；其余情况（含嵌套的 NODE_ARRAY_ACCESS、
// NODE_OBJECT_ACCESS 等）走普通路径，从而与解释器只检查"直接父节点"
// 的语义一致。
static void compile_expr_raw(ASTNode* node, Bytecode& bc) {
    if (!node) return;
    if (node->type == NODE_VARIABLE) {
        int idx = push_string_operand(bc, node->data.var_name);
        bc.code.push_back(OP_GET_VAR_RAW);
        push_int_operand(bc, idx);
    } else if (node->type == NODE_THIS) {
        int idx = push_string_operand(bc, "dies");
        bc.code.push_back(OP_GET_VAR_RAW);
        push_int_operand(bc, idx);
    } else {
        compile_expr(node, bc);
    }
}

static void compile_func_body_implicit_return(ASTNode* body, Bytecode& bc) {
    if (body && body->type == NODE_BLOCK && body->data.block.count > 0) {
        const int n = body->data.block.count;
        for (int i = 0; i < n - 1; ++i)
            compile_statement(body->data.block.stmts[i], bc);

        ASTNode* last = body->data.block.stmts[n - 1];
        if (last->type == NODE_EXPR_STMT &&
            last->data.expr_stmt.expr &&
            last->data.expr_stmt.expr->type != NODE_ASSIGN)
        {
            compile_expr(last->data.expr_stmt.expr, bc);
            bc.code.push_back(OP_RETURN);
            return;
        }
        compile_statement(last, bc);
    } else if (body) {
        compile_statement(body, bc);
    }
    bc.code.push_back(OP_PUSH_NULL);
    bc.code.push_back(OP_RETURN);
}

// 把栈顶对象/数组写回 target 变量；target 不是变量则弹掉
static void emit_store_back_or_pop(ASTNode* target, Bytecode& bc) {
    if (target && target->type == NODE_VARIABLE) {
        const char* raw = target->data.var_name;
        std::string q = qualify_static_name(raw, bc);
        int name_idx = push_string_operand(bc, q.empty() ? raw : q.c_str());
        bc.code.push_back(OP_STORE);
        push_int_operand(bc, name_idx);
    } else {
        bc.code.push_back(OP_POP);
    }
}

static inline void emit_u8 (std::vector<uint8_t>& c, uint8_t v) { c.push_back(v); }
static inline void emit_op (std::vector<uint8_t>& c, uint8_t op) { c.push_back(op); }
static inline void emit_int(std::vector<uint8_t>& c, int v) {
    uint32_t u = static_cast<uint32_t>(v);
    c.push_back(static_cast<uint8_t>(u));
    c.push_back(static_cast<uint8_t>(u >> 8));
    c.push_back(static_cast<uint8_t>(u >> 16));
    c.push_back(static_cast<uint8_t>(u >> 24));
}

void compile_expr(ASTNode* node, Bytecode& bc) {
    if (!node) return;
    compile_trace("compile_expr", node);
    CompileDepthGuard _dg;
    switch (node->type) {
        case NODE_NUMBER: {
            const char* str = node->data.number_str;
            
            // ---- 1. 快速路径：十进制小整数（与解释器一致） ----
            errno = 0;
            char* end = nullptr;
            long long v = strtoll(str, &end, 10);
            if (end && *end == '\0' && end != str && errno == 0) {
                push_int64_operand(bc, (int64_t)v);
                break;
            }
            
            // ---- 2. 回退到 GMP 路径（十六进制、二进制、八进制、大整数等） ----
            mpz_t tmp;
            mpz_init(tmp);
            int base = 10;
            const char* num_start = str;
            if (strncmp(str, "0x", 2) == 0 || strncmp(str, "0X", 2) == 0) {
                base = 16;
                num_start = str + 2;          // 去掉前缀
            } else if (strncmp(str, "0b", 2) == 0 || strncmp(str, "0B", 2) == 0) {
                base = 2;
                num_start = str + 2;
            } else if (strncmp(str, "0o", 2) == 0 || strncmp(str, "0O", 2) == 0) {
                base = 8;
                num_start = str + 2;
            }
            if (mpz_set_str(tmp, num_start, base) != 0) {
                mpz_clear(tmp);
                kr_error("无效的整数常量");
            }
            
            // ---- 3. 编译期能放进 int64 就直接内联，运行时零开销 ----
            //      （覆盖 0x1234、0b1010、0o17、超过 strtoll 范围但不超过 int64 的情形）
            if (mpz_fits_slong_p(tmp)) {
                long long fit = (long long)mpz_get_si(tmp);
                mpz_clear(tmp);
                push_int64_operand(bc, (int64_t)fit);
                break;
            }
            
            // ---- 4. 真正的大整数：转规范十进制字符串放入常量池 ----
            //      VM 侧 OP_PUSH_INT 用 mpz_set_str 解析十进制字符串不会有前缀问题
            char* dec_str = mpz_get_str(nullptr, 10, tmp);
            mpz_clear(tmp);
            bc.code.push_back(OP_PUSH_INT);
            int idx = (int)bc.constants.size();
            bc.constants.push_back(make_string(dec_str));
            free(dec_str);
            push_int_operand(bc, idx);
            break;
        }
        case NODE_FLOAT: {
            const char* str = node->data.float_str;
            mpf_t tmp;
            mpf_init(tmp);
            bool parsed = false;
        
            // 1. 尝试默认十进制
            if (mpf_set_str(tmp, str, 10) == 0) {
                parsed = true;
            }
            // 2. 十六进制浮点格式（0x... / 0X...）
            else if (strncmp(str, "0x", 2) == 0 || strncmp(str, "0X", 2) == 0) {
                // 2a. 尝试 base=0（自动识别）
                if (!parsed && mpf_set_str(tmp, str, 0) == 0) {
                    parsed = true;
                }
                // 2b. 去掉前缀，用 base=16；指数符号缺省时补 '+'
                if (!parsed) {
                    std::string no_prefix = str + 2;
                    size_t ppos = no_prefix.find_first_of("pP");
                    if (ppos != std::string::npos && ppos + 1 < no_prefix.size()) {
                        char next = no_prefix[ppos + 1];
                        if (next != '+' && next != '-') {
                            no_prefix.insert(ppos + 1, "+");
                        }
                    }
                    if (mpf_set_str(tmp, no_prefix.c_str(), 16) == 0) {
                        parsed = true;
                    }
                }
                // 2c. 统一把 'P' 转为 'p' 再试一次
                if (!parsed) {
                    std::string modified = str + 2;
                    for (char& c : modified) if (c == 'P') c = 'p';
                    size_t ppos = modified.find('p');
                    if (ppos != std::string::npos && ppos + 1 < modified.size()) {
                        char next = modified[ppos + 1];
                        if (next != '+' && next != '-') {
                            modified.insert(ppos + 1, "+");
                        }
                    }
                    if (mpf_set_str(tmp, modified.c_str(), 16) == 0) {
                        parsed = true;
                    }
                }
                // 2d. 最后尝试 strtod（某些实现的扩展）
                if (!parsed) {
                    char* end = nullptr;
                    double d = strtod(str, &end);
                    if (end != str && *end == '\0') {
                        mpf_set_d(tmp, d);
                        parsed = true;
                    }
                }
            }
        
            if (!parsed) {
                mpf_clear(tmp);
                kr_error("无效的浮点数常量");
            }
        
            // ---- 编译期已解析，直接存 Value 浮点 ----
            bc.code.push_back(OP_PUSH_FLOAT);
            int idx = (int)bc.constants.size();
            bc.constants.push_back(make_float(tmp));   // 常量池已支持 Value
            mpf_clear(tmp);
            push_int_operand(bc, idx);
            break;
        }
        case NODE_STRING: {
            bc.code.push_back(OP_PUSH_STRING);
            int idx = bc.constants.size();
            bc.constants.push_back(make_string(node->data.string));
            push_int_operand(bc, idx);
            break;
        }
        case NODE_BINARY: {
            char op = node->data.binary.op;
        
            // 编译期折叠纯常量算术
            auto try_fold_const = [&](ASTNode* l, ASTNode* r) -> bool {
                if (!l || !r) return false;
                if (l->type != NODE_NUMBER || r->type != NODE_NUMBER) return false;
                // 只折叠 + - * / % 且都是 int64 范围
                mpz_t a, b, c;
                mpz_init(a); mpz_init(b); mpz_init(c);
                bool ok = mpz_set_str(a, l->data.number_str, 0) == 0 &&
                          mpz_set_str(b, r->data.number_str, 0) == 0;
                if (ok) {
                    switch (op) {
                        case '+': mpz_add(c, a, b); break;
                        case '-': mpz_sub(c, a, b); break;
                        case '*': mpz_mul(c, a, b); break;
                        case '/': if (mpz_sgn(b) == 0) ok = false; else mpz_tdiv_q(c, a, b); break;
                        case '%': if (mpz_sgn(b) == 0) ok = false; else mpz_mod(c, a, b); break;
                        default:  ok = false;
                    }
                }
                if (!ok) { mpz_clear(a); mpz_clear(b); mpz_clear(c); return false; }
        
                if (mpz_fits_slong_p(c)) {
                    push_int64_operand(bc, (int64_t)mpz_get_si(c));
                } else {
                    char* s = mpz_get_str(nullptr, 10, c);
                    bc.code.push_back(OP_PUSH_INT);
                    int idx = (int)bc.constants.size();
                    bc.constants.push_back(make_string(s));
                    free(s);
                    push_int_operand(bc, idx);
                }
                mpz_clear(a); mpz_clear(b); mpz_clear(c);
                return true;
            };
        
            if (try_fold_const(node->data.binary.left, node->data.binary.right)) {
                break;   // 整个 NODE_BINARY 变成了一个 PUSH
            }

            compile_expr(node->data.binary.left,  bc);
            compile_expr(node->data.binary.right, bc);
        
            switch (op) {
                case '+': bc.code.push_back(OP_ADD); break;
                case '-': bc.code.push_back(OP_SUB); break;
                case '*': bc.code.push_back(OP_MUL); break;
                case '/': bc.code.push_back(OP_DIV); break;
                case '%': bc.code.push_back(OP_MOD); break;
                case '^': bc.code.push_back(OP_POW); break;
                case 'H': bc.code.push_back(OP_CONCAT); break;
                case '|': bc.code.push_back(OP_BIT_OR);  break;
                case '&': bc.code.push_back(OP_BIT_AND); break;
                case 'X': bc.code.push_back(OP_XOR); break;
                case 'E': bc.code.push_back(OP_CMP_EQ); break;
                case 'N': bc.code.push_back(OP_CMP_NE); break;
                case '>': bc.code.push_back(OP_CMP_GT); break;
                case '<': bc.code.push_back(OP_CMP_LT); break;
                case 'G': bc.code.push_back(OP_CMP_GE); break;
                case 'L': bc.code.push_back(OP_CMP_LE); break;
                case 'C': bc.code.push_back(OP_CMP_3WAY); break;
                default:
                    kr_error("compile_expr: 不支持的二元操作符 '%c'", op);
            }
            break;
        }
        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT: {
            // 这四个节点与 NODE_BINARY 共用 data.binary.{left,right}
            compile_expr(node->data.binary.left,  bc);
            compile_expr(node->data.binary.right, bc);
            switch (node->type) {
                case NODE_BITWISE_OR:  bc.code.push_back(OP_BIT_OR);  break;
                case NODE_BITWISE_AND: bc.code.push_back(OP_BIT_AND); break;
                case NODE_SHIFT_LEFT:  bc.code.push_back(OP_SHL);     break;
                case NODE_SHIFT_RIGHT: bc.code.push_back(OP_SHR);     break;
                default: break;
            }
            break;
        }
        case NODE_VARIABLE: {
            const char* raw = node->data.var_name;
            std::string q = qualify_static_name(raw, bc);
            int idx = push_string_operand(bc, q.empty() ? raw : q.c_str());
            bc.code.push_back(OP_GET_VAR);
            push_int_operand(bc, idx);
            break;
        }
        case NODE_ASSIGN: {
            // 先求值右侧表达式
            compile_expr(node->data.assign.expr, bc);
            // 复制一份（表达式语义：赋值后应保留值在栈上）
            bc.code.push_back(OP_DUP);
            int name_idx = push_string_operand(bc, node->data.assign.name);
            bc.code.push_back(OP_STORE);
            push_int_operand(bc, name_idx);
            // 注：OP_STORE 弹出的是 DUP 出来的副本，原值仍留在栈上
            break;
        }
        case NODE_RANGE: {
            // 编译 start, end, step（step 可为空）
            compile_expr(node->data.range.start, bc);
            compile_expr(node->data.range.end, bc);
            if (node->data.range.step) {
                compile_expr(node->data.range.step, bc);
            } else {
                // 默认步长为 1
                push_int64_operand(bc, 1);
            }
            bc.code.push_back(OP_RANGE);
            break;
        }
        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC: {
            ASTNode* operand = node->data.inc_dec.operand;
            if (!operand) kr_error("++/-- 缺少操作数");

            // ============================================================
            // 快速路径：普通变量 → 已有专用 opcode（name_idx 编码）
            // 与解释器"current_scope 内 int64 局部变量"的快线语义等价：
            // VM 侧 OP_INC_VAR 等已经内置 int64 原地修改 + GMP 溢出提升。
            // ============================================================
            if (operand->type == NODE_VARIABLE) {
                const char* raw = operand->data.var_name;
                std::string q = qualify_static_name(raw, bc);
                int name_idx = push_string_operand(bc, q.empty() ? raw : q.c_str());
                switch (node->type) {
                    case NODE_PRE_INC:  bc.code.push_back(OP_INC_VAR);       break;
                    case NODE_PRE_DEC:  bc.code.push_back(OP_DEC_VAR);       break;
                    case NODE_POST_INC: bc.code.push_back(OP_POST_INC_VAR);  break;
                    case NODE_POST_DEC: bc.code.push_back(OP_POST_DEC_VAR);  break;
                    default: break;
                }
                push_int_operand(bc, name_idx);
                break;
            }

            // ============================================================
            // 通用路径：任意左值（对象属性 obj.x、数组元素 a[i]、链式
            // obj.a.b[2] 等）。与 NODE_SWAP_ASSIGN 同构：把 AST 注册进
            // aux_ast_refs，VM 侧 get_mutable_ptr 完成寻址。
            // ============================================================
            int ast_id = (int)bc.aux_ast_refs.size();
            bc.aux_ast_refs.push_back(operand);

            uint8_t mode = 0;
            switch (node->type) {
                case NODE_PRE_INC:  mode = 0; break;   // ++x
                case NODE_PRE_DEC:  mode = 1; break;   // --x
                case NODE_POST_INC: mode = 2; break;   // x++
                case NODE_POST_DEC: mode = 3; break;   // x--
                default: break;
            }
            bc.code.push_back(OP_INC_DEC_AST);
            push_int_operand(bc, ast_id);
            bc.code.push_back(mode);
            break;
        }
        case NODE_FUNC_CALL: {
            const int raw_argc = node->data.func_call.arg_count;
            ASTNode** raw_args = node->data.func_call.args;
        
            // ---- 是否存在展开实参 ----
            bool has_spread = false;
            for (int i = 0; i < raw_argc; ++i) {
                if (raw_args[i] && raw_args[i]->type == NODE_SPREAD_ARG)
                    has_spread = true;
            }
        
            // ============ 情形 A：一等函数调用 f(...) ============
            if (node->data.func_call.func_expr != nullptr) {
                compile_expr(node->data.func_call.func_expr, bc);
        
                if (!has_spread) {
                    for (int i = 0; i < raw_argc; ++i)
                        compile_expr(raw_args[i], bc);
                    bc.code.push_back(OP_CALL_VALUE);
                    push_int_operand(bc, raw_argc);
                } else {
                    for (int i = 0; i < raw_argc; ++i) {
                        ASTNode* a = raw_args[i];
                        if (a->type == NODE_SPREAD_ARG) {
                            compile_expr(a->data.spread.expr, bc);
                        } else {
                            compile_expr(a, bc);
                            bc.code.push_back(OP_WRAP_ARRAY_1);
                        }
                    }
                    bc.code.push_back(OP_FLATTEN_ARRAYS);
                    push_int_operand(bc, raw_argc);
                    bc.code.push_back(OP_CALL_VALUE_ARR);
                }
                break;
            }
        
            // ============ 情形 B：命名调用 ============
            const char* fname = node->data.func_call.name;

            // ---- B-0：类实例化优先于函数调用 ----
            //   Tier("x", 5)  等价于  new Tier("x", 5)
            //   与 NODE_NEW 走同一条 OP_NEW_OBJ 路径，语义/栈布局完全一致。
            if (!has_spread && fname && *fname) {
                auto cit = bc.class_by_name.find(fname);
                if (cit != bc.class_by_name.end()) {
                    for (int i = 0; i < raw_argc; ++i)
                        compile_expr(raw_args[i], bc);
                    bc.code.push_back(OP_NEW_OBJ);
                    push_int_operand(bc, cit->second);
                    push_int_operand(bc, raw_argc);
                    break;   // 已经生成完整字节码，不再走函数调用路径
                }
            }

            auto it = bc.func_by_name.find(fname ? fname : "");
        
            // ---- B-1：无展开 ----
            if (!has_spread) {
                for (int i = 0; i < raw_argc; ++i)
                    compile_expr(raw_args[i], bc);
        
                if (it != bc.func_by_name.end()) {
                    const CompiledFunction& cf = bc.functions[it->second];
                    const int param_count = (int)cf.params.size();
                    cf.called = true;
                
                    if (cf.vararg_name.empty() && raw_argc > param_count) {
                        kr_error("函数 '%s' 参数过多：期望 %d，实际 %d",
                                    fname, param_count, raw_argc);
                    }
                
                    // ---- 尝试全部用编译期常量填充 ----
                    bool all_fillable = true;
                    for (int i = raw_argc; i < param_count; ++i) {
                        int di = (i < (int)cf.param_defaults_idx.size())
                                        ? cf.param_defaults_idx[i] : -1;
                        if (di < 0) { all_fillable = false; break; }
                    }
                
                    if (all_fillable) {
                        for (int i = raw_argc; i < param_count; ++i)
                            emit_push_constant(bc, cf.param_defaults_idx[i]);
                        bc.code.push_back(OP_CALL_DIRECT);
                        push_int_operand(bc, it->second);
                        push_int_operand(bc, (raw_argc > param_count) ? raw_argc : param_count);
                    } else {
                        // ---- 有默认值不能折叠 → 交给 VM 运行时求值 ----
                        for (int i = raw_argc; i < param_count; ++i) {
                            bool has = (i < (int)cf.param_has_default.size())
                                            && cf.param_has_default[i];
                            if (!has)
                                kr_error("函数 '%s' 缺少参数 '%s' 且无默认值",
                                            fname, cf.params[i].c_str());
                        }
                        bc.code.push_back(OP_CALL_DIRECT);
                        push_int_operand(bc, it->second);
                        push_int_operand(bc, raw_argc);
                    }
                } else {
                    // 先查内建函数表
                    BuiltinId bid = lookup_builtin(fname ? fname : "");
                    if (bid != BI_NONE) {
                        bc.code.push_back(OP_CALL_BUILTIN);
                        push_int_operand(bc, (int)bid);
                        push_int_operand(bc, raw_argc);
                    } else {
                        // 动态查找（函数在后续编译单元里定义）
                        int name_idx = push_string_operand(bc, fname ? fname : "");
                        bc.code.push_back(OP_CALL);
                        push_int_operand(bc, name_idx);
                        push_int_operand(bc, raw_argc);
                    }
                }
                break;
            }
        
            // ---- B-2：有展开 ----
            for (int i = 0; i < raw_argc; ++i) {
                ASTNode* a = raw_args[i];
                if (a->type == NODE_SPREAD_ARG) {
                    compile_expr(a->data.spread.expr, bc);
                } else {
                    compile_expr(a, bc);
                    bc.code.push_back(OP_WRAP_ARRAY_1);
                }
            }
            bc.code.push_back(OP_FLATTEN_ARRAYS);
            push_int_operand(bc, raw_argc);
        
            if (it != bc.func_by_name.end()) {
                CompiledFunction& cf = bc.functions[it->second];
                cf.called = true;
                bc.code.push_back(OP_CALL_DIRECT_ARR);
                push_int_operand(bc, it->second);
            } else {
                int name_idx = push_string_operand(bc, fname ? fname : "");
                bc.code.push_back(OP_CALL_ARR);
                push_int_operand(bc, name_idx);
            }
            break;
        }
        case NODE_NULL: {
            bc.code.push_back(OP_PUSH_NULL);
            break;
        }

        case NODE_THIS: {
            // 与解释器语义一致：把 this 当作名字为 "dies" 的变量
            int idx = push_string_operand(bc, "dies");
            bc.code.push_back(OP_GET_VAR);
            push_int_operand(bc, idx);
            break;
        }

        case NODE_NOT: {
            compile_expr(node->data.not_expr.expr, bc);
            bc.code.push_back(OP_NOT);
            break;
        }

        case NODE_LOGICAL_AND: {
            // 解释器语义：返回 0 / 1
            //   l = eval(left); if(!bool(l)) → 0
            //   r = eval(right); → bool(r) ? 1 : 0
            compile_expr(node->data.logical_and.left, bc);
            size_t jf1 = bc.code.size();
            bc.code.push_back(OP_JMP_IF_FALSE);
            push_int_operand(bc, 0);

            compile_expr(node->data.logical_and.right, bc);
            size_t jf2 = bc.code.size();
            bc.code.push_back(OP_JMP_IF_FALSE);
            push_int_operand(bc, 0);

            push_int64_operand(bc, 1);       // 两者皆真 → 1
            size_t jend = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);

            // L_false:
            size_t false_addr = bc.code.size();
            write_int_operand(bc, jf1 + 1, false_addr);
            write_int_operand(bc, jf2 + 1, false_addr);
            push_int64_operand(bc, 0);       // → 0

            // L_end:
            size_t end_addr = bc.code.size();
            write_int_operand(bc, jend + 1, end_addr);
            break;
        }

        case NODE_LOGICAL_OR: {
            // 解释器语义：返回 0 / 1
            compile_expr(node->data.logical_or.left, bc);
            size_t jt1 = bc.code.size();
            bc.code.push_back(OP_JMP_IF_TRUE);
            push_int_operand(bc, 0);

            compile_expr(node->data.logical_or.right, bc);
            size_t jt2 = bc.code.size();
            bc.code.push_back(OP_JMP_IF_TRUE);
            push_int_operand(bc, 0);

            push_int64_operand(bc, 0);       // 两者皆假 → 0
            size_t jend = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);

            // L_true:
            size_t true_addr = bc.code.size();
            write_int_operand(bc, jt1 + 1, true_addr);
            write_int_operand(bc, jt2 + 1, true_addr);
            push_int64_operand(bc, 1);       // → 1

            // L_end:
            size_t end_addr = bc.code.size();
            write_int_operand(bc, jend + 1, end_addr);
            break;
        }

        case NODE_TERNARY: {
            // cond ? then : else
            compile_expr(node->data.ternary.cond, bc);
            size_t jf_else = bc.code.size();
            bc.code.push_back(OP_JMP_IF_FALSE);
            push_int_operand(bc, 0);

            // then 分支
            compile_expr(node->data.ternary.true_expr, bc);
            size_t j_end = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);

            // else 分支
            size_t else_addr = bc.code.size();
            write_int_operand(bc, jf_else + 1, else_addr);
            compile_expr(node->data.ternary.false_expr, bc);

            // 合并点
            size_t end_addr = bc.code.size();
            write_int_operand(bc, j_end + 1, end_addr);
            break;
        }
        case NODE_NULL_COALESCE: {
            // left ?? right
            //   [left]                // 栈顶是 left
            //   DUP                   // [left, left]
            //   JMP_IF_NOT_NULL L     // 弹出副本；若 left != null → L（栈剩 [left]）
            //   POP                   // 丢弃 null 的 left
            //   <right>               // 压入 right
            // L:                      // 结果唯一占栈顶
            compile_expr(node->data.null_coalesce.left, bc);
            bc.code.push_back(OP_DUP);

            size_t jnn = bc.code.size();
            bc.code.push_back(OP_JMP_IF_NOT_NULL);
            push_int_operand(bc, 0);

            bc.code.push_back(OP_POP);       // 丢弃 null left
            compile_expr(node->data.null_coalesce.right, bc);

            size_t end_addr = bc.code.size();
            write_int_operand(bc, jnn + 1, end_addr);
            break;
        }

        case NODE_ARRAY_LEN: {
            compile_expr(node->data.array_len.array, bc);
            bc.code.push_back(OP_ARRAY_LEN);
            break;
        }

        case NODE_STRING_LEN: {
            compile_expr(node->data.string_len.str, bc);
            bc.code.push_back(OP_ARRAY_LEN);   // VM 已支持字符串长度
            break;
        }

        case NODE_ARRAY_ACCESS: {
            compile_expr(node->data.array_access.array, bc);
            compile_expr(node->data.array_access.index, bc);
            bc.code.push_back(OP_ARRAY_GET);
            break;
        }

        case NODE_OBJECT_ACCESS: {
            ASTNode* obj_node = node->data.object_access.obj;
            const char* key   = node->data.object_access.key;
        
            // ---- 静态属性快线（原样保留）----
            if (obj_node && obj_node->type == NODE_VARIABLE) {
                std::string full = resolve_static_property(
                    obj_node->data.var_name, key, bc);
                if (!full.empty()) {
                    int idx = push_string_operand(bc, full.c_str());
                    bc.code.push_back(OP_GET_VAR);
                    push_int_operand(bc, idx);
                    break;
                }
            }
        
            // ---- 原始路径 ----
            compile_expr_raw(node->data.object_access.obj, bc);
            int key_idx = push_string_operand(bc, key);
            bc.code.push_back(OP_OBJ_GET);
            push_int_operand(bc, key_idx);
            bc.code.push_back(node->data.object_access.is_optional ? 1 : 0);
            break;
        }

        case NODE_ARRAY_LITERAL: {
            const int n = node->data.array_lit.count;
        
            // ---- 探测是否存在展开元素 ----
            bool has_spread = false;
            for (int i = 0; i < n; ++i) {
                ASTNode* elem = node->data.array_lit.elems[i];
                if (elem && elem->type == NODE_SPREAD_ARRAY) {
                    has_spread = true;
                    break;
                }
            }
        
            // ============================================================
            // 快线：无展开 → 与原实现完全一致，零额外开销
            // ============================================================
            if (!has_spread) {
                for (int i = 0; i < n; ++i)
                    compile_expr(node->data.array_lit.elems[i], bc);
                bc.code.push_back(OP_NEW_ARRAY);
                push_int_operand(bc, n);
                break;
            }
        
            // ============================================================
            // 展开路径：与解释器同构
            //   - 展开元素        → 直接压数组（求值后自然是数组）
            //   - 普通元素        → 求值后 OP_WRAP_ARRAY_1 包成单元素数组
            //   - OP_FLATTEN_ARRAYS n 把 n 个数组拼成一个，压回栈
            // 不用再补 OP_NEW_ARRAY：FLATTEN_ARRAYS 的结果就是数组本身。
            // ============================================================
            for (int i = 0; i < n; ++i) {
                ASTNode* elem = node->data.array_lit.elems[i];
                if (elem->type == NODE_SPREAD_ARRAY) {
                    compile_expr(elem->data.spread.expr, bc);
                    // 注意：这里不对 spread 结果做类型检查——交给 VM 侧
                    // OP_FLATTEN_ARRAYS 统一校验"必须是数组"，与解释器
                    // "kr_error(\"展开运算符只能用于数组\")" 语义等价。
                } else {
                    compile_expr(elem, bc);
                    bc.code.push_back(OP_WRAP_ARRAY_1);
                }
            }
            bc.code.push_back(OP_FLATTEN_ARRAYS);
            push_int_operand(bc, n);
            break;
        }

        case NODE_OBJECT_LITERAL: {
            int n = node->data.object_lit.count;
            // 与解释器相同的求值顺序：key0, val0, key1, val1, ...
            for (int i = 0; i < n; ++i) {
                compile_expr_raw(node->data.object_lit.key_exprs[i], bc);
                compile_expr_raw(node->data.object_lit.vals[i],     bc);
            }
            bc.code.push_back(OP_NEW_OBJECT);
            push_int_operand(bc, n);
            break;
        }

        case NODE_STRING_INTERP: {
            int n = node->data.string_interp.count;

            // 空插值：直接压空串，与解释器"输出空串"等价
            if (n == 0) {
                int idx = (int)bc.constants.size();
                bc.constants.push_back(make_string(""));
                bc.code.push_back(OP_PUSH_STRING);
                push_int_operand(bc, idx);
                break;
            }

            // 第一个片段：只压栈，不 CONCAT
            {
                ASTNode* frag = node->data.string_interp.fragments[0];
                if (frag->type == NODE_STRING) {
                    size_t len = frag->string_len;
                    if (len == 0 && frag->data.string) len = strlen(frag->data.string);
                    int idx = (int)bc.constants.size();
                    bc.constants.push_back(make_string_len(frag->data.string, len));
                    bc.code.push_back(OP_PUSH_STRING);
                    push_int_operand(bc, idx);
                } else {
                    compile_expr(frag, bc);
                }
            }

            // 后续片段：压栈后立刻 OP_CONCAT
            // op_concat 内部会对非字符串走 value_to_string，与解释器
            // "非字符串片段统一转字符串拼接" 的语义一致。
            for (int i = 1; i < n; ++i) {
                ASTNode* frag = node->data.string_interp.fragments[i];
                if (frag->type == NODE_STRING) {
                    size_t len = frag->string_len;
                    if (len == 0 && frag->data.string) len = strlen(frag->data.string);
                    int idx = (int)bc.constants.size();
                    bc.constants.push_back(make_string_len(frag->data.string, len));
                    bc.code.push_back(OP_PUSH_STRING);
                    push_int_operand(bc, idx);
                } else {
                    compile_expr(frag, bc);
                }
                bc.code.push_back(OP_CONCAT);
            }
            break;
        }

        case NODE_REGEX_LITERAL: {
            // 解释器构造 { "muster": pattern, "flags": flags }
            // 用已有 OP_NEW_OBJECT 2 即可，无需新 opcode。
            auto push_str = [&](const char* s) {
                int idx = (int)bc.constants.size();
                bc.constants.push_back(make_string(s));
                bc.code.push_back(OP_PUSH_STRING);
                push_int_operand(bc, idx);
            };
            push_str("muster");
            push_str(node->data.regex_lit.pattern);
            push_str("flags");
            push_str(node->data.regex_lit.flags);
            bc.code.push_back(OP_NEW_OBJECT);
            push_int_operand(bc, 2);
            break;
        }

        case NODE_BITWISE_NOT: {
            compile_expr(node->data.inc_dec.operand, bc);
            bc.code.push_back(OP_BIT_NOT);
            break;
        }
        case NODE_DEGREE: {
            compile_expr(node->data.inc_dec.operand, bc);
            bc.code.push_back(OP_TO_RAD);
            break;
        }
        case NODE_FACTORIAL: {
            compile_expr(node->data.inc_dec.operand, bc);
            bc.code.push_back(OP_FACT);
            break;
        }
        case NODE_DOUBLE_FACTORIAL: {
            compile_expr(node->data.inc_dec.operand, bc);
            bc.code.push_back(OP_DFACT);
            break;
        }
        case NODE_METHOD_CALL: {
            ASTNode* obj_node = node->data.method_call.obj;
            const int argc    = node->data.method_call.arg_count;
            int method_idx    = push_string_operand(bc, node->data.method_call.method);
            uint8_t flags     = node->data.method_call.is_optional ? 1 : 0;
        
            if (obj_node && obj_node->type == NODE_VARIABLE) {
                for (int i = 0; i < argc; ++i)
                    compile_expr(node->data.method_call.args[i], bc);
                int var_idx = push_string_operand(bc, obj_node->data.var_name);
                bc.code.push_back(OP_METHOD_CALL_VAR);
                push_int_operand(bc, var_idx);
                push_int_operand(bc, method_idx);
                push_int_operand(bc, argc);
                bc.code.push_back(flags);
            } else {
                compile_expr_raw(obj_node, bc);
                for (int i = 0; i < argc; ++i)
                    compile_expr_raw(node->data.method_call.args[i], bc);
                bc.code.push_back(OP_METHOD_CALL);
                push_int_operand(bc, method_idx);
                push_int_operand(bc, argc);
                bc.code.push_back(flags);
            }
            break;
        }

        case NODE_FUNC_DEF: {
            // 表达式位置的匿名函数（lambda）。
            // 解释器：copy_scope_chain + make_function → 匿名函数值。
            // 字节码路径没有闭包捕获设施，采用与命名函数相同的布局：
            //   1) 动态分配 CompiledFunction 槽位；
            //   2) JMP 跳过函数体，把函数体内联编译进主代码流；
            //   3) 末尾发 OP_FUNC_DEF，函数值留在栈上作为表达式结果。
            //
            //   g_compiling_class_name 是全局编译状态。若本 lambda 出现在
            //   类方法体 / 类构造函数体内，外层的 ClassContextGuard 已经把它
            //   设为当前类名；本 lambda 的：
            //     - 参数默认值表达式（collect_param_defaults / compile_param_default_code）
            //     - 函数体（compile_func_body_implicit_return）
            //   的编译都在该全局状态下进行，裸名静态属性会被自动改写。
            //   若 lambda 定义在类外，g_compiling_class_name 为空，不会改写。
            //   因此本分支无需任何额外代码。
        
            CompiledFunction cf;
            cf.global_scope = false;
            cf.is_async     = false;
            cf.is_rule      = false;
            cf.called       = false;
            cf.is_memoized  = node->data.func_def.is_memoized;
        
            const int pcount = node->data.func_def.param_count;
            cf.params.reserve((size_t)pcount);
            cf.param_types.reserve((size_t)pcount);
            cf.param_is_const.reserve((size_t)pcount);
        
            for (int i = 0; i < pcount; ++i) {
                const char* pn = node->data.func_def.params
                                    ? node->data.func_def.params[i] : nullptr;
                cf.params.emplace_back(pn ? pn : "");
        
                TypeNode* pt = node->data.func_def.param_types
                                    ? node->data.func_def.param_types[i] : nullptr;
                cf.param_types.emplace_back(
                    pt ? type_to_string(pt) : std::string());
        
                cf.param_is_const.push_back(
                    node->data.func_def.param_is_const
                        ? node->data.func_def.param_is_const[i] : false);
            }
        
            if (node->data.func_def.return_type)
                cf.return_type = type_to_string(node->data.func_def.return_type);
            if (node->data.func_def.vararg_type)
                cf.vararg_type = type_to_string(node->data.func_def.vararg_type);
        
            // 默认值元数据：命名函数走预扫描填过就跳过，匿名函数这里现填
            if (cf.param_defaults_idx.empty())
                collect_param_defaults(node, cf, bc);

            const int func_idx = (int)bc.functions.size();
            bc.functions.push_back(std::move(cf));

            size_t skip_jump = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);

            size_t body_start = bc.code.size();
            compile_func_body_implicit_return(node->data.func_def.body, bc);
            bc.functions[func_idx].code_offset = body_start;   // 索引回写

            compile_param_default_code(node, func_idx, bc);    // 传索引

            size_t after_defaults = bc.code.size();
            write_int_operand(bc, skip_jump + 1, (int)after_defaults);

            bc.code.push_back(OP_FUNC_DEF);
            push_int_operand(bc, func_idx);
            break;
        }
        case NODE_MATCH: {
            // 先把被匹配的值算出来 → 栈 [val]
            compile_expr(node->data.match.expr, bc);
        
            const int branch_count = node->data.match.branch_count;
            std::vector<size_t> end_jumps;      // 各匹配成功分支跳到统一出口
        
            for (int i = 0; i < branch_count; ++i) {
                ASTNode* pattern = node->data.match.branches[i].pattern;
                ASTNode* guard   = node->data.match.branches[i].guard;
                ASTNode* body    = node->data.match.branches[i].body;
        
                // 登记 pattern 到 aux_ast_refs，VM 侧用 idx 取
                int pat_idx = (int)bc.aux_ast_refs.size();
                bc.aux_ast_refs.push_back(pattern);
        
                // 每个分支一个独立子作用域：模式变量、守卫、体都写在里面。
                // 失败/结束都能靠 OP_POP_SCOPE 一次性清干净，等价于解释器里
                // saved_count / var_count 手工回滚那一套。
                bc.code.push_back(OP_PUSH_SCOPE);
        
                // 复制 val 给匹配尝试 —— 原始 val 要留给后续分支
                bc.code.push_back(OP_DUP);           // [val, val]
        
                bc.code.push_back(OP_MATCH_TRY);
                push_int_operand(bc, pat_idx);       // [val, bool]
        
                size_t jmp_pat_fail = bc.code.size();
                bc.code.push_back(OP_JMP_IF_FALSE);
                push_int_operand(bc, 0);             // 占位，稍后回填到 branch_fail
        
                // 可选守卫
                size_t jmp_guard_fail = SIZE_MAX;
                if (guard) {
                    compile_expr(guard, bc);         // [val, gval]
                    jmp_guard_fail = bc.code.size();
                    bc.code.push_back(OP_JMP_IF_FALSE);
                    push_int_operand(bc, 0);         // 占位
                }
        
                // 分支体求值 → [val, result]
                compile_expr(body, bc);
        
                // 撤掉分支作用域（模式变量/守卫临时变量都在里面）
                bc.code.push_back(OP_POP_SCOPE);     // [val, result]
        
                // 用 result 替换 val
                bc.code.push_back(OP_SWAP);          // [result, val]
                bc.code.push_back(OP_POP);           // [result]
        
                // 跳到统一出口
                size_t jmp_end = bc.code.size();
                bc.code.push_back(OP_JMP);
                push_int_operand(bc, 0);
                end_jumps.push_back(jmp_end);
        
                // ---- branch_fail 落点 ----
                // 走到这里栈一定是 [val]：
                //   - 模式失败：OP_MATCH_TRY 压了 0，JMP_IF_FALSE 弹掉 bool
                //   - 守卫失败：同理
                // 唯一要做的是清掉本分支作用域（其中的模式变量/守卫临时变量）
                size_t fail_addr = bc.code.size();
                write_int_operand(bc, jmp_pat_fail + 1, (int)fail_addr);
                if (jmp_guard_fail != SIZE_MAX) {
                    write_int_operand(bc, jmp_guard_fail + 1, (int)fail_addr);
                }
                bc.code.push_back(OP_POP_SCOPE);     // [val]
            }
        
            // ---- 所有分支都没匹配 ----
            // 与解释器 return make_null() 一致
            bc.code.push_back(OP_POP);               // 丢弃 val
            bc.code.push_back(OP_PUSH_NULL);
        
            // ---- 统一出口 ----
            size_t end_addr = bc.code.size();
            for (size_t pos : end_jumps) {
                write_int_operand(bc, pos + 1, (int)end_addr);
            }
            break;
        }
        case NODE_BLOCK: {
            const int n = node->data.block.count;
        
            // 空块 → null
            if (n == 0) {
                bc.code.push_back(OP_PUSH_NULL);
                break;
            }
        
            // 进入子作用域。与 NODE_SCOPE_BLOCK 语句版一致：
            // 块内声明在 OP_POP_SCOPE 时统一释放，不污染外层。
            bc.code.push_back(OP_PUSH_SCOPE);
        
            // ---- 1. 前 n-1 条：纯语句，栈上不留值 ----
            for (int i = 0; i < n - 1; ++i) {
                compile_statement(node->data.block.stmts[i], bc);
            }
        
            // ---- 2. 最后一条：决定块值 ----
            ASTNode* last = node->data.block.stmts[n - 1];
            if (last->type == NODE_EXPR_STMT &&
                last->data.expr_stmt.expr->type != NODE_ASSIGN)
            {
                // 与 NODE_CLASS_DEF 里 stmt_func 的处理完全同构：
                // 纯表达式直接作为返回值压栈，不再走 statement 路径。
                compile_expr(last->data.expr_stmt.expr, bc);
            } else {
                // 赋值 / 控制流 / 声明 / 空语句等：按普通语句编译，
                // 栈上补 null 作为块值。
                compile_statement(last, bc);
                bc.code.push_back(OP_PUSH_NULL);
            }
        
            // ---- 3. 弹作用域，块值留在栈顶 ----
            // OP_POP_SCOPE 只 pop_scope()，不动操作数栈，正好。
            bc.code.push_back(OP_POP_SCOPE);
            break;
        }
        case NODE_SUPER_CALL: {
            // 求值全部实参，按序压栈
            const int argc = node->data.super_call.arg_count;
            for (int i = 0; i < argc; ++i)
                compile_expr(node->data.super_call.args[i], bc);
        
            bc.code.push_back(OP_SUPER_CALL);
            push_int_operand(bc, argc);
            break;
        }
        case NODE_OBJECT_COMPREHENSION: {
            std::string suffix = std::to_string((uintptr_t)node);
            std::string coll_v = "__ocoll_" + suffix;
            std::string acc_v  = "__oacc_"  + suffix;
            std::string idx_v  = "__oidx_"  + suffix;
        
            bc.code.push_back(OP_PUSH_SCOPE);
        
            // coll = <collection>
            compile_expr(node->data.object_comp.collection, bc);
            { int n = push_string_operand(bc, coll_v.c_str());
              bc.code.push_back(OP_DECLARE_VAR); push_int_operand(bc, n);
              bc.code.push_back(0); bc.code.push_back(0); }
        
            // acc = {}
            bc.code.push_back(OP_NEW_OBJECT); push_int_operand(bc, 0);
            { int n = push_string_operand(bc, acc_v.c_str());
              bc.code.push_back(OP_DECLARE_VAR); push_int_operand(bc, n);
              bc.code.push_back(0); bc.code.push_back(0); }
        
            // idx = 0
            bc.code.push_back(OP_PUSH_INT64); push_int64_bytes(bc, 0);
            { int n = push_string_operand(bc, idx_v.c_str());
              bc.code.push_back(OP_DECLARE_VAR); push_int_operand(bc, n);
              bc.code.push_back(0); bc.code.push_back(0); }
        
            // 迭代状态压栈：[coll, iter]
            { int n = push_string_operand(bc, coll_v.c_str());
              bc.code.push_back(OP_GET_VAR); push_int_operand(bc, n); }
            bc.code.push_back(OP_ITER_PREP);
        
            size_t loop_start = bc.code.size();
        
            // OP_ITER_NEXT：越界则跳 done
            size_t iter_jump = bc.code.size();
            bc.code.push_back(OP_ITER_NEXT);
            push_int_operand(bc, 0);
        
            // 栈：[coll, iter, key, value]
        
            // 绑定变量
            int var_idx = push_string_operand(bc, node->data.object_comp.var_name);
            int vv_idx  = -1;
            if (node->data.object_comp.value_var)
                vv_idx = push_string_operand(bc, node->data.object_comp.value_var);
        
            bc.code.push_back(OP_ITER_BIND);
            push_int_operand(bc, var_idx);
            push_int_operand(bc, vv_idx);
        
            // 条件过滤
            size_t skip_jump = (size_t)-1;
            if (node->data.object_comp.cond) {
                compile_expr(node->data.object_comp.cond, bc);
                skip_jump = bc.code.size();
                bc.code.push_back(OP_JMP_IF_FALSE);
                push_int_operand(bc, 0);
            }
        
            // 计算 key / value → 栈 [coll, iter, key, value]
            compile_expr(node->data.object_comp.key_expr,   bc);
            compile_expr(node->data.object_comp.value_expr, bc);
        
            // 直接原地写 acc[key] = value —— 与列表推导式的 OP_ARRAY_PUSH 同构，
            // 不再走 OP_GET_VAR 拷贝副本 → 修改丢失的路径。
            {
                int acc_idx = push_string_operand(bc, acc_v.c_str());
                bc.code.push_back(OP_OBJ_SET_VAR);
                push_int_operand(bc, acc_idx);
            }
            // 栈：[coll, iter]
        
            // 条件为假的目标
            if (node->data.object_comp.cond) {
                size_t after_store = bc.code.size();
                write_int_operand(bc, skip_jump + 1, after_store);
            }
        
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, (int)loop_start);
        
            // done
            size_t done_addr = bc.code.size();
            write_int_operand(bc, iter_jump + 1, done_addr);
        
            // 栈上还有 [coll, iter] 要清
            bc.code.push_back(OP_POP);
            bc.code.push_back(OP_POP);
        
            // 取 acc 作为表达式结果
            { int n = push_string_operand(bc, acc_v.c_str());
              bc.code.push_back(OP_GET_VAR); push_int_operand(bc, n); }
        
            bc.code.push_back(OP_POP_SCOPE);
            break;
        }
        case NODE_LIST_COMPREHENSION: {
            // 每个推导式一个独立后缀，避免嵌套时名字冲突
            std::string suffix = std::to_string((uintptr_t)node);
            std::string coll_v = "__lcoll_" + suffix;
            std::string acc_v  = "__lacc_"  + suffix;
        
            // 独立作用域：循环变量 + 临时变量都在这里
            bc.code.push_back(OP_PUSH_SCOPE);
        
            // ---- 1. 求值集合，绑定到 __lcoll ----
            compile_expr(node->data.list_comp.collection, bc);
            { int n = push_string_operand(bc, coll_v.c_str());
              bc.code.push_back(OP_DECLARE_VAR); push_int_operand(bc, n);
              bc.code.push_back(0); bc.code.push_back(0); }
        
            // ---- 2. 初始化累加器 acc = [] ----
            bc.code.push_back(OP_NEW_ARRAY); push_int_operand(bc, 0);
            { int n = push_string_operand(bc, acc_v.c_str());
              bc.code.push_back(OP_DECLARE_VAR); push_int_operand(bc, n);
              bc.code.push_back(0); bc.code.push_back(0); }
        
            // ---- 3. 迭代器准备：栈上得到 [coll, iter=0] ----
            { int n = push_string_operand(bc, coll_v.c_str());
              bc.code.push_back(OP_GET_VAR); push_int_operand(bc, n); }
            bc.code.push_back(OP_ITER_PREP);
        
            size_t loop_start = bc.code.size();
        
            // ---- 4. OP_ITER_NEXT：越界则跳 done；否则推入 [key, value] ----
            size_t iter_jump = bc.code.size();
            bc.code.push_back(OP_ITER_NEXT);
            push_int_operand(bc, 0);                    // 占位 done_addr
        
            // ---- 5. 绑定循环变量（单变量模式 → 绑 value，丢弃 key）----
            //      与解释器"数组绑元素 / 对象绑属性值"完全一致
            int var_idx = push_string_operand(bc, node->data.list_comp.var_name);
            bc.code.push_back(OP_ITER_BIND);
            push_int_operand(bc, var_idx);
            push_int_operand(bc, -1);
        
            // ---- 6. cond 过滤 ----
            size_t skip_jump = (size_t)-1;
            if (node->data.list_comp.cond) {
                compile_expr(node->data.list_comp.cond, bc);
                skip_jump = bc.code.size();
                bc.code.push_back(OP_JMP_IF_FALSE);
                push_int_operand(bc, 0);
            }
        
            // ---- 7. 求值表达式并追加 ----
            compile_expr(node->data.list_comp.expr, bc);
            {
                int n = push_string_operand(bc, acc_v.c_str());
                bc.code.push_back(OP_ARRAY_PUSH);
                push_int_operand(bc, n);
            }
        
            // cond 为假 → 落在这里（跳过 push，直接下一次迭代）
            if (node->data.list_comp.cond) {
                size_t after_push = bc.code.size();
                write_int_operand(bc, skip_jump + 1, after_push);
            }
        
            // ---- 8. 回到循环开始 ----
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, (int)loop_start);
        
            // ---- 9. done：回填 OP_ITER_NEXT 的跳转目标 ----
            size_t done_addr = bc.code.size();
            write_int_operand(bc, iter_jump + 1, done_addr);
        
            // ---- 10. 栈上残留 [coll, iter] → 清理 ----
            bc.code.push_back(OP_POP);   // iter
            bc.code.push_back(OP_POP);   // coll
        
            // ---- 11. 取出 acc 作为表达式结果 ----
            { int n = push_string_operand(bc, acc_v.c_str());
              bc.code.push_back(OP_GET_VAR); push_int_operand(bc, n); }
        
            bc.code.push_back(OP_POP_SCOPE);
            break;
        }

        case NODE_MARK_USED:
        case NODE_MARK_ALL_USED:
            // 不应出现在表达式中，忽略
            return;
        default:
            kr_error("compile_expr: 不支持的节点类型 %d", node->type);
    }
}

// ================= fastout =================
namespace fastout {
    constexpr size_t BUF_SIZE = 1 << 16;   // 64 KB
    static char   buf[BUF_SIZE];
    static size_t pos = 0;

    inline void flush() {
        if (pos > 0) {
            fwrite(buf, 1, pos, stdout);
            pos = 0;
        }
    }

    inline void ensure(size_t n) {
        if (pos + n > BUF_SIZE) flush();
    }

    inline void put(char c) {
        ensure(1);
        buf[pos++] = c;
    }

    inline void write(const char* s, size_t n) {
        if (n >= BUF_SIZE) {
            flush();
            fwrite(s, 1, n, stdout);
            return;
        }
        ensure(n);
        std::memcpy(buf + pos, s, n);
        pos += n;
    }

    inline void write_cstr(const char* s) {
        write(s, std::strlen(s));
    }

    inline void write_int64(int64_t v) {
        char tmp[24];
        auto res = std::to_chars(tmp, tmp + sizeof(tmp), v);
        write(tmp, static_cast<size_t>(res.ptr - tmp));
    }

    inline void write_double(double d) {
        char tmp[64];
        int n = std::snprintf(tmp, sizeof(tmp), "%g", d);
        if (n > 0) write(tmp, static_cast<size_t>(n));
    }

    struct AutoFlush {
        ~AutoFlush() { flush(); std::fflush(stdout); }
    };
    static AutoFlush _auto_flush;

    static char   buf_stderr[BUF_SIZE];
    static size_t pos_stderr = 0;

    inline void flush_stderr() {
        if (pos_stderr > 0) {
            fwrite(buf_stderr, 1, pos_stderr, stderr);
            pos_stderr = 0;
        }
    }

    inline void ensure_stderr(size_t n) {
        if (pos_stderr + n > BUF_SIZE) flush_stderr();
    }

    inline void put_stderr(char c) {
        ensure_stderr(1);
        buf_stderr[pos_stderr++] = c;
    }

    inline void write_stderr(const char* s, size_t n) {
        if (n >= BUF_SIZE) {
            flush_stderr();
            fwrite(s, 1, n, stderr);
            return;
        }
        ensure_stderr(n);
        std::memcpy(buf_stderr + pos_stderr, s, n);
        pos_stderr += n;
    }

    inline void write_cstr_stderr(const char* s) {
        write_stderr(s, std::strlen(s));
    }

    inline void write_int64_stderr(int64_t v) {
        char tmp[24];
        auto res = std::to_chars(tmp, tmp + sizeof(tmp), v);
        write_stderr(tmp, static_cast<size_t>(res.ptr - tmp));
    }

    inline void write_double_stderr(double d) {
        char tmp[64];
        int n = std::snprintf(tmp, sizeof(tmp), "%g", d);
        if (n > 0) write_stderr(tmp, static_cast<size_t>(n));
    }
} // namespace fastout

// 把一个Value输出到cout，不带换行、不带flush
std::string c_value_to_stdstring(const Value& v) {
    switch(v.type) {
        case VAL_INT64:
            return std::to_string(v.int64_val);

        case VAL_STRING:
            return std::string(v.str_val, v.str_len);

        case VAL_INT: {
            if (mpz_fits_slong_p(*v.big_int))
            {
                long num = mpz_get_si(*v.big_int);
                return std::to_string(num);
            }
            char* s = mpz_get_str(nullptr, 10, *v.big_int);
            std::string res(s);
            free(s);
            return res;
        }

        case VAL_FLOAT:
            return std::to_string(mpf_get_d(*v.mpf_val));

        case VAL_NULL:
            return "null";

        default: {
            char* s = value_to_string(v);
            std::string res(s);
            free(s);
            return res;
        }
    }
}

static void vm_print_value_cout(const Value& v) {
    switch (v.type) {
        case VAL_INT64:
            std::cout << v.int64_val;
            break;
        case VAL_STRING:
            std::cout.write(v.str_val, v.str_len);
            break;
        case VAL_INT: {
            if (mpz_fits_slong_p(*v.big_int))
            {
                long num = mpz_get_si(*v.big_int);
                std::cout << num;
                break;
            }
            char* s = mpz_get_str(nullptr, 10, *v.big_int);
            std::cout << s;
            free(s);
            break;
        }
        case VAL_FLOAT:
            std::cout << mpf_get_d(*v.mpf_val);
            break;
        case VAL_NULL:
            std::cout << "null";
            break;
        default: {
            char* s = value_to_string(v);
            std::cout << s;
            free(s);
            break;
        }
    }
}

void compile_statement(ASTNode* node, Bytecode& bc) {
    if (!node) return;
    g_current_operating_position = "<KOMPILIER>";
    compile_trace("compile_statement", node);
    CompileDepthGuard _dg;
    emit_line(node, bc);
    switch (node->type) {
        case NODE_PROGRAM: {
            for (int i = 0; i < node->data.block.count; ++i)
                compile_statement(node->data.block.stmts[i], bc);
            break;
        }
        case NODE_BLOCK: {
            if (node->data.block.count == 0) {
                kr_warn("块只包含空语句，可能为缩进错误，建议检查或填充 null");
            }
            for (int i = 0; i < node->data.block.count; ++i)
                compile_statement(node->data.block.stmts[i], bc);
            break;
        }
        case NODE_EXPR_STMT: {
            ASTNode* expr = node->data.expr_stmt.expr;
            if (expr->type == NODE_ASSIGN) {
                // 赋值表达式作为语句：直接走语句路径，不要额外 POP
                compile_statement(expr, bc);
            } else {
                compile_expr(expr, bc);
                bc.code.push_back(OP_POP);
            }
            break;
        }
        case NODE_FUNC_CALL: {
            compile_expr(node, bc);
            bc.code.push_back(OP_POP);
            break;
        }
        case NODE_PRINT: {
            compile_expr(node->data.print.expr, bc);
            bc.code.push_back(OP_PRINT);
            break;
        }
        case NODE_PRINT_NO_NEWLINE: {
            compile_expr(node->data.print.expr, bc);
            bc.code.push_back(OP_PRINT_NO_NEWLINE);
            break;
        }
        case NODE_PRINT_MULTI: {
            int n = node->data.print_multi.count;
            for (int i = 0; i < n; ++i)
                compile_expr(node->data.print_multi.exprs[i], bc);
            bc.code.push_back(OP_PRINT_MULTI);
            push_int_operand(bc, n);
            break;
        }
        case NODE_PRINT_NO_NEWLINE_MULTI: {
            int n = node->data.print_multi.count;
            for (int i = 0; i < n; ++i)
                compile_expr(node->data.print_multi.exprs[i], bc);
            bc.code.push_back(OP_PRINT_NO_NEWLINE_MULTI);
            push_int_operand(bc, n);
            break;
        }
        case NODE_PRINT_WITH_LINE: {
            compile_expr(node->data.print_with_line.expr, bc);
            compile_expr(node->data.print_with_line.line, bc);
            bc.code.push_back(OP_PRINT_WITH_LINE);
            break;
        }
        case NODE_MARK_USED: {
            // OP_MARK_USED + uint16 count + [uint16 constantIndex] * count
            bc.code.push_back(OP_MARK_USED);
            uint16_t count = static_cast<uint16_t>(node->data.mark_used.count);
            bc.code.push_back( (count >> 0) & 0xFF );
            bc.code.push_back( (count >> 8) & 0xFF );
        
            for (int i = 0; i < node->data.mark_used.count; ++i) {
                const char* rawName = node->data.mark_used.names[i];
                std::string sname(rawName);
        
                // 存入string_intern + constants常量池
                int cidx;
                auto sit = bc.string_intern.find(sname);
                if (sit != bc.string_intern.end()) {
                    cidx = sit->second;
                } else {
                    cidx = static_cast<int>(bc.constants.size());
                    bc.constants.push_back(make_string(rawName));
                    bc.string_intern[sname] = cidx;
                }
        
                // 写入常量索引（uint16）
                bc.code.push_back( (cidx >> 0) & 0xFF );
                bc.code.push_back( (cidx >> 8) & 0xFF );
            }
            break;
        }
        case NODE_MARK_ALL_USED: {
            bc.code.push_back(OP_MARK_ALL_USED);
            break;
        }
        case NODE_IF: {
            std::vector<size_t> end_jumps; // 记录需要跳转到整个 if 结束的位置
            long long const_val;
            bool is_const_cond = compile_constant_int(node->data.if_stmt.cond, const_val);
        
            if (is_const_cond) {
                if (g_warnings_enabled) {
                    walk_ast(node->data.if_stmt.cond, [](ASTNode* n) {
                        if (n->type == NODE_VARIABLE) {
                            const char* name = n->data.var_name;
                            Scope* s = current_scope;
                            while (s) {
                                int idx = get_var_index_in_scope(s, name);
                                if (idx >= 0) {
                                    s->vars[idx].is_read = true;
                                    break;
                                }
                                s = s->parent;
                            }
                            if (s == nullptr && original_global_scope) {
                                int idx = get_var_index_in_scope(original_global_scope, name);
                                if (idx >= 0) {
                                    original_global_scope->vars[idx].is_read = true;
                                }
                            }
                        }
                    });
                }
                // 编译期常量条件，警告并做分支裁剪
                kr_warn("条件是编译期常量 %lld，将裁剪不可达分支", const_val);
                if (const_val != 0) {
                    // 常量为真：只编译 then 块，丢弃 else-if、else
                    compile_statement(node->data.if_stmt.then_block, bc);
                } else {
                    // 常量为假：跳过 then，只编译 else-if 链 + else
                    // 处理 else-if 链
                    for (int i = 0; i < node->data.if_stmt.else_if_count; ++i) {
                        ASTNode* else_if = node->data.if_stmt.else_ifs[i];
                        compile_expr(else_if->data.if_stmt.cond, bc);
                        size_t else_if_jump = bc.code.size();
                        bc.code.push_back(OP_JMP_IF_FALSE);
                        push_int_operand(bc, 0);
        
                        compile_statement(else_if->data.if_stmt.then_block, bc);
        
                        if (i < node->data.if_stmt.else_if_count - 1 || node->data.if_stmt.else_block) {
                            size_t jmp = bc.code.size();
                            bc.code.push_back(OP_JMP);
                            push_int_operand(bc, 0);
                            end_jumps.push_back(jmp);
                        }
                        size_t next_else_target = bc.code.size();
                        write_int_operand(bc, else_if_jump + 1, next_else_target);
                    }
                    // 处理 else 块
                    if (node->data.if_stmt.else_block) {
                        compile_statement(node->data.if_stmt.else_block, bc);
                    }
                    // 回填所有 end_jumps
                    size_t end_addr = bc.code.size();
                    for (size_t pos : end_jumps) {
                        write_int_operand(bc, pos + 1, end_addr);
                    }
                }
                break;
            }
        
            // 编译当前条件
            compile_expr(node->data.if_stmt.cond, bc);
            size_t cond_jump = bc.code.size();
            bc.code.push_back(OP_JMP_IF_FALSE);
            push_int_operand(bc, 0); // 占位
        
            // then 块
            compile_statement(node->data.if_stmt.then_block, bc);
        
            // then 块结束后，如果有后续分支，跳转到结束
            if (node->data.if_stmt.else_if_count > 0 || node->data.if_stmt.else_block) {
                size_t jmp = bc.code.size();
                bc.code.push_back(OP_JMP);
                push_int_operand(bc, 0);
                end_jumps.push_back(jmp);
            }
        
            // 回填当前条件跳转：指向第一个 else-if 或 else 或结束
            size_t next_target = bc.code.size();
            write_int_operand(bc, cond_jump + 1, next_target);
        
            // 处理 else-if 链
            for (int i = 0; i < node->data.if_stmt.else_if_count; ++i) {
                ASTNode* else_if = node->data.if_stmt.else_ifs[i];
                // else-if 节点本身是 NODE_IF，我们直接使用其 cond 和 then_block
                compile_expr(else_if->data.if_stmt.cond, bc);
                size_t else_if_jump = bc.code.size();
                bc.code.push_back(OP_JMP_IF_FALSE);
                push_int_operand(bc, 0);
        
                compile_statement(else_if->data.if_stmt.then_block, bc);
        
                // 当前 else-if 结束后，如果还有后续分支，跳转到结束
                if (i < node->data.if_stmt.else_if_count - 1 || node->data.if_stmt.else_block) {
                    size_t jmp = bc.code.size();
                    bc.code.push_back(OP_JMP);
                    push_int_operand(bc, 0);
                    end_jumps.push_back(jmp);
                }
        
                // 回填当前 else-if 条件为假时的跳转：指向下一个 else-if 或 else
                size_t next_else_target = bc.code.size();
                write_int_operand(bc, else_if_jump + 1, next_else_target);
            }
        
            // 处理 else 块
            if (node->data.if_stmt.else_block) {
                compile_statement(node->data.if_stmt.else_block, bc);
            }
        
            // 回填所有 end_jumps 到当前结束地址
            size_t end_addr = bc.code.size();
            for (size_t pos : end_jumps) {
                write_int_operand(bc, pos + 1, end_addr);
            }
        
            break;
        }
        case NODE_WHILE: {
            LoopInfo info{};
            info.loop_start = bc.code.size(); // 条件求值开始
            g_loop_stack.push_back(info);
        
            compile_expr(node->data.while_stmt.cond, bc);
            size_t cond_jump = bc.code.size();
            bc.code.push_back(OP_JMP_IF_FALSE);
            push_int_operand(bc, 0);
        
            compile_statement(node->data.while_stmt.body, bc);
        
            // 无条件跳回条件
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, (int)info.loop_start);
        
            size_t end_addr = bc.code.size();
            write_int_operand(bc, cond_jump + 1, end_addr);
        
            // 回填 break 和 continue
            for (size_t pos : g_loop_stack.back().break_jumps) {
                write_int_operand(bc, pos + 1, end_addr);
            }
            for (size_t pos : g_loop_stack.back().continue_jumps) {
                write_int_operand(bc, pos + 1, info.loop_start);
            }
        
            g_loop_stack.pop_back();
            break;
        }
        case NODE_FOR: {
            if (try_compile_native_for(node, bc)) break;
        
            LoopInfo info{};
            info.has_cond = (node->data.for_stmt.cond != nullptr);
            g_loop_stack.push_back(info);
        
            if (node->data.for_stmt.init)
                compile_statement(node->data.for_stmt.init, bc);
        
            size_t cond_start = bc.code.size();
            //  全部改 back()，不要再改局部 info
            g_loop_stack.back().loop_start = cond_start;
        
            if (node->data.for_stmt.cond) {
                compile_expr(node->data.for_stmt.cond, bc);
                g_loop_stack.back().cond_jump_pos = bc.code.size();
                bc.code.push_back(OP_JMP_IF_FALSE);
                push_int_operand(bc, 0);
            }
        
            compile_statement(node->data.for_stmt.body, bc);
        
            size_t update_start = bc.code.size();
            if (node->data.for_stmt.update) {
                compile_statement(node->data.for_stmt.update, bc);
                g_loop_stack.back().continue_target = update_start;
            } else {
                g_loop_stack.back().continue_target = cond_start;
            }
        
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, (int)cond_start);
        
            size_t end_addr = bc.code.size();
        
            for (size_t pos : g_loop_stack.back().break_jumps)
                write_int_operand(bc, pos + 1, end_addr);
            for (size_t pos : g_loop_stack.back().continue_jumps)
                write_int_operand(bc, pos + 1, g_loop_stack.back().continue_target);
        
            if (g_loop_stack.back().has_cond)
                write_int_operand(bc, g_loop_stack.back().cond_jump_pos + 1, end_addr);
        
            g_loop_stack.pop_back();
            break;
        }
        case NODE_FOREACH: {
            // 1. 求值集合表达式（结果压栈）
            compile_expr(node->data.foreach.collection, bc);
        
            // 2. 运行时预处理：字符串→UTF-8 字符数组；压入 [coll, iter=0]
            bc.code.push_back(OP_ITER_PREP);
        
            // 3. 压入循环栈帧，供 break / continue 回填
            LoopInfo info{};
            g_loop_stack.push_back(info);
        
            size_t loop_start = bc.code.size();
        
            // 4. OP_ITER_NEXT <done>：越界则跳到 done
            bc.code.push_back(OP_ITER_NEXT);
            size_t iter_next_operand = bc.code.size();
            push_int_operand(bc, 0);                   // 占位 done_addr
        
            // 5. OP_ITER_BIND：弹 [key,value] 并绑定变量
            //    栈上此时为 [coll, iter, key, value]
            int var_idx = push_string_operand(bc, node->data.foreach.key_var);
            int vv_idx  = -1;
            if (node->data.foreach.value_var)
                vv_idx = push_string_operand(bc, node->data.foreach.value_var);
        
            bc.code.push_back(OP_ITER_BIND);
            push_int_operand(bc, var_idx);
            push_int_operand(bc, vv_idx);
            // 绑定后栈上回到 [coll, iter]
        
            // 6. 循环体
            compile_statement(node->data.foreach.body, bc);
        
            // 7. 无条件跳回循环开始
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, (int)loop_start);
        
            // 8. done 目标（同时是 break 落点）
            size_t done_addr = bc.code.size();
            write_int_operand(bc, iter_next_operand, done_addr);
        
            // 9. 回填 break / continue
            for (size_t pos : g_loop_stack.back().break_jumps) {
                write_int_operand(bc, pos + 1, done_addr);
            }
            for (size_t pos : g_loop_stack.back().continue_jumps) {
                write_int_operand(bc, pos + 1, loop_start);
            }
            g_loop_stack.pop_back();
        
            // 10. 清理栈上残留 [coll, iter]
            bc.code.push_back(OP_POP);   // iter
            bc.code.push_back(OP_POP);   // coll
            break;
        }
        case NODE_DO_WHILE: {
            LoopInfo info{};
            info.loop_start = bc.code.size(); // 循环体开始
            g_loop_stack.push_back(info);
        
            compile_statement(node->data.do_while.body, bc);
        
            // 条件求值（continue 跳转到此处）
            info.continue_target = bc.code.size();
            compile_expr(node->data.do_while.cond, bc);
            // 条件为真时跳回循环开始
            bc.code.push_back(OP_JMP_IF_TRUE);
            push_int_operand(bc, (int)info.loop_start);
        
            size_t end_addr = bc.code.size();
        
            // 回填 break 到 end_addr，continue 到 info.continue_target
            for (size_t pos : g_loop_stack.back().break_jumps) {
                write_int_operand(bc, pos + 1, end_addr);
            }
            for (size_t pos : g_loop_stack.back().continue_jumps) {
                write_int_operand(bc, pos + 1, info.continue_target);
            }
        
            g_loop_stack.pop_back();
            break;
        }
        case NODE_BREAK: {
            if (g_loop_stack.empty()) {
                std::string hint = make_keyword_alias_hint("bruch", "bruch");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "Fehler: bruch 只能在循环中使用");
            }
            int levels = node->data.break_stmt.levels;
            if (levels < 1) levels = 1;
            const int depth = (int)g_loop_stack.size();
            if (levels > depth) {
                kr_error("bruch 层级 %d 超过当前循环嵌套深度 %d",
                         levels, depth);
            }
            size_t jmp_pos = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0); // 占位
            // 登记到第 levels 层循环（最内层是 depth-1，外层是 depth-levels）
            g_loop_stack[(size_t)(depth - levels)].break_jumps.push_back(jmp_pos);
            break;
        }
        case NODE_CONTINUE: {
            if (g_loop_stack.empty()) {
                std::string hint = make_keyword_alias_hint("weiter", "weiter");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "Fehler: weiter 只能在循环中使用");
            }
            int levels = node->data.break_stmt.levels;
            if (levels < 1) levels = 1;
            const int depth = (int)g_loop_stack.size();
            if (levels > depth) {
                kr_error("weiter 层级 %d 超过当前循环嵌套深度 %d",
                         levels, depth);
            }
            size_t jmp_pos = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0); // 占位
            g_loop_stack[(size_t)(depth - levels)].continue_jumps.push_back(jmp_pos);
            break;
        }
        case NODE_VAR_DECL: {
            if (node->data.var_decl.is_const && node->data.var_decl.expr != nullptr) {
                auto& top_table = g_compile_const_stack.back();
                top_table[std::string(node->data.var_decl.name)] = node->data.var_decl.expr;
            }
            // 1. compile initializer if present, else push default
            if (node->data.var_decl.expr) {
                compile_expr(node->data.var_decl.expr, bc);
            } else {
                // no explicit init: use default value based on type annotation if available
                if (node->data.var_decl.type_annotation) {
                    ASTNode* default_expr = make_default_value_for_type(node->data.var_decl.type_annotation);
                    compile_expr(default_expr, bc);
                    free_ast(default_expr);
                } else {
                    // default to null
                    bc.code.push_back(OP_PUSH_NULL);
                }
            }
        
            // 2. emit DECLARE_VAR instruction
            bc.code.push_back(OP_DECLARE_VAR);
            int name_idx = push_string_operand(bc, node->data.var_decl.name);
            push_int_operand(bc, name_idx);
            // operands: const flag, global flag
            bc.code.push_back(node->data.var_decl.is_const ? 1 : 0);
            bc.code.push_back(node->data.var_decl.global ? 1 : 0);
            break;
        }
        case NODE_ASSIGN: {
            ASTNode* rhs = node->data.assign.expr;
            const char* raw = node->data.assign.name;
            std::string q = qualify_static_name(raw, bc);
            const char* store_name = q.empty() ? raw : q.c_str();
        
            // ---- 融合优化：x = x <op> rhs ----
            if (rhs && rhs->type == NODE_BINARY &&
                rhs->data.binary.left &&
                rhs->data.binary.left->type == NODE_VARIABLE &&
                strcmp(rhs->data.binary.left->data.var_name, raw) == 0) {
                Opcode fused = OP_HALT;
                switch (rhs->data.binary.op) {
                    case '+': fused = OP_ADD_TO_VAR; break;
                    case '-': fused = OP_SUB_TO_VAR; break;
                    case '*': fused = OP_MUL_TO_VAR; break;
                    case '/': fused = OP_DIV_TO_VAR; break;
                    case '%': fused = OP_MOD_TO_VAR; break;
                    default:  break;
                }
                if (fused != OP_HALT) {
                    compile_expr(rhs->data.binary.right, bc);
                    int name_idx = push_string_operand(bc, store_name);
                    bc.code.push_back(fused);
                    push_int_operand(bc, name_idx);
                    break;
                }
            }
            // ---- 通用路径 ----
            compile_expr(node->data.assign.expr, bc);
            int name_idx = push_string_operand(bc, store_name);
            bc.code.push_back(OP_STORE);
            push_int_operand(bc, name_idx);
            break;
        }
        case NODE_FUNC_DEF: {
            const char* fname = node->data.func_def.name ? node->data.func_def.name : "";
            int func_idx = bc.func_by_name.at(fname);
        
            // 元数据填充块：内部不 push，可安全持引用
            {
                CompiledFunction& cf = bc.functions[func_idx];
                if (cf.param_defaults_idx.empty())
                    collect_param_defaults(node, cf, bc);
                cf.global_scope = node->data.func_def.global_scope;
                cf.is_async     = false;
                cf.is_memoized  = node->data.func_def.is_memoized;
            }
            // 提前读出后续需要的 is_memoized，因为届时不能再安全取引用
            const bool is_memoized = bc.functions[func_idx].is_memoized;
        
            size_t skip_jump = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            size_t body_start = bc.code.size();
            compile_func_body_implicit_return(node->data.func_def.body, bc);   // ← 可能 push
            bc.functions[func_idx].code_offset = body_start;                   // 索引回写
        
            compile_param_default_code(node, func_idx, bc);                    // 传索引
        
            size_t after_defaults = bc.code.size();
            write_int_operand(bc, skip_jump + 1, (int)after_defaults);
        
            bc.code.push_back(is_memoized ? OP_RULE_DEF : OP_FUNC_DEF);        // 用局部变量
            push_int_operand(bc, func_idx);
        
            bc.code.push_back(OP_DECLARE_VAR);
            int name_idx = push_string_operand(bc, fname);
            push_int_operand(bc, name_idx);
            bc.code.push_back(0);
            bc.code.push_back(node->data.func_def.global_scope ? 1 : 0);
            break;
        }
        case NODE_RETURN: {
            if (node->data.ret.expr) {
                compile_expr(node->data.ret.expr, bc);
            } else {
                bc.code.push_back(OP_PUSH_NULL);
            }
            bc.code.push_back(OP_RETURN);
            break;
        }
        case NODE_CLASS_DEF: {
            const std::string cname = node->data.class_def.name;
            auto it = bc.class_by_name.find(cname);
            if (it == bc.class_by_name.end())
                kr_error("NODE_CLASS_DEF: 预扫描未注册 '%s'", cname.c_str());
            const int cls_idx = it->second;
            CompiledClass& cc = bc.classes[cls_idx];
        
            //  (0) 进入类上下文
            ClassContextGuard class_guard(cname);
        
            // ---- (a) 注册一个合成构造函数 ----
            CompiledFunction ctor_fn;
            ctor_fn.name = cname + "::__ctor";
            for (int i = 0; i < node->data.class_def.ctor_param_count; ++i)
                ctor_fn.params.emplace_back(node->data.class_def.ctor_params[i]);
            ctor_fn.code_offset = SIZE_MAX;
            int ctor_func_idx = (int)bc.functions.size();
            bc.functions.push_back(std::move(ctor_fn));
            cc.ctor_func_idx = ctor_func_idx;
        
            // ============================================================
            //  (a2) 静态属性预收集【 / 从原 (d) 前移】
            //
            // 必须在编译构造函数体、方法体、以及它们内部嵌套的 lambda/匿名函数
            // 之前完成。因为类体内裸名静态属性（如 `zaehler++`）的改写依赖
            // qualify_static_name() → is_current_static_property()，而后者
            // 读取的正是 cc.static_props。
            //
            // 原先此段位于 (b) 之后，导致构造函数体内的裸名静态属性访问
            // 无法被识别为 "Class::name"，运行时报“未定义变量”。
            // ============================================================
            cc.static_props.clear();
            for (int i = 0; i < node->data.class_def.properties.count; ++i) {
                if (!node->data.class_def.properties.is_static[i]) continue;
                const char* pname = node->data.class_def.properties.names[i];
                if (!pname) continue;
        
                ASTNode* def_expr = node->data.class_def.properties.default_exprs[i];
                if (def_expr && def_expr->type == NODE_NULL) def_expr = nullptr;
        
                Value def_val = def_expr ? eval_const_expr_simple(def_expr) : make_null();
                int cidx = (int)bc.constants.size();
                bc.constants.push_back(def_val);
                cc.static_props.emplace_back(std::string(pname), cidx);
            }
        
            // ---- (b) 编译构造函数体 ----
            //   此时 cc.static_props 已就绪，函数体内裸名静态属性会被正确改写
            //   为 "Class::name"。
            size_t skip_jump = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            size_t body_start = bc.code.size();
            if (node->data.class_def.ctor_body)
                compile_statement(node->data.class_def.ctor_body, bc);
            bc.code.push_back(OP_PUSH_NULL);
            bc.code.push_back(OP_RETURN);
        
            size_t body_end = bc.code.size();
            write_int_operand(bc, skip_jump + 1, (int)body_end);
            bc.functions[ctor_func_idx].code_offset = body_start;
        
            // ---- (c) 实例属性默认值 → 常量池 ----
            cc.properties.clear();
            for (int i = 0; i < node->data.class_def.properties.count; ++i) {
                if (node->data.class_def.properties.is_static[i]) continue;
                const char* pname = node->data.class_def.properties.names[i];
                if (!pname) continue;
        
                ASTNode* def_expr = node->data.class_def.properties.default_exprs[i];
                if (def_expr && def_expr->type == NODE_NULL) def_expr = nullptr;
        
                Value def_val;
                if (def_expr) {
                    def_val = eval_const_expr_simple(def_expr);
                } else if (node->data.class_def.properties.types[i]) {
                    ASTNode* de = make_default_value_for_type(
                        node->data.class_def.properties.types[i]);
                    def_val = de ? eval_const_expr_simple(de) : make_null();
                    if (de) free_ast(de);
                } else {
                    def_val = make_null();
                }
        
                int cidx = (int)bc.constants.size();
                bc.constants.push_back(def_val);
                cc.properties.emplace_back(std::string(pname), cidx);
            }
        
            // ---- (d) 静态属性默认值 → 常量池 ----
            //  已在 (a2) 完成（提前到构造函数体编译之前）。
        
            //  (d2) 静态属性运行时声明
            //   在全局作用域声明变量 "Class::attr"，初始值为编译期常量池中的默认值。
            //   之后所有改写为 "Class::attr" 的 GET_VAR / STORE / OP_*_TO_VAR 都能命中。
            for (const auto& [pname, cidx] : cc.static_props) {
                std::string full = cname + "::" + pname;
        
                emit_push_constant(bc, cidx);
        
                int name_idx = push_string_operand(bc, full.c_str());
                bc.code.push_back(OP_DECLARE_VAR);
                push_int_operand(bc, name_idx);
                bc.code.push_back(0);   // 非 const（静态属性可变）
                bc.code.push_back(1);   // 全局作用域
            }
        
            // ---- (e) 构造参数默认值 → 常量池 ----
            for (int i = 0;
                 i < node->data.class_def.ctor_default_count
                     && i < (int)cc.ctor_params.size(); ++i) {
                ASTNode* def_expr = node->data.class_def.ctor_defaults[i];
                if (!def_expr) continue;
                Value def_val = eval_const_expr_simple(def_expr);
                int cidx = (int)bc.constants.size();
                bc.constants.push_back(def_val);
                cc.ctor_defaults_idx[i] = cidx;
            }
        
            // ---- (f) 编译类方法体 ----
            const auto& M = node->data.class_def.methods;
            for (int mi = 0; mi < M.count; ++mi) {
                const char* mname = M.names ? M.names[mi] : nullptr;
                if (!mname) continue;
        
                std::string full = cname + "::" + mname;
                auto mit = bc.func_by_name.find(intern_name(bc, full.c_str()));
                if (mit == bc.func_by_name.end())
                    kr_error("NODE_CLASS_DEF: 方法 '%s' 预扫描未注册", full.c_str());
        
                const int midx = mit->second;
                CompiledFunction& mf = bc.functions[midx];
        
                size_t skip_jump = bc.code.size();
                bc.code.push_back(OP_JMP);
                push_int_operand(bc, 0);
        
                size_t body_start = bc.code.size();
        
                ASTNode* mbody = M.bodies ? M.bodies[mi] : nullptr;
                const bool stmt_func = M.is_stmt_func ? M.is_stmt_func[mi] : false;
        
                //  方法体编译：由外层 class_guard 提供类上下文。
                //   方法内的裸静态属性名会被改写为 "Class::name"。
                if (stmt_func && mbody && mbody->type == NODE_BLOCK &&
                    mbody->data.block.count > 0)
                {
                    const int n = mbody->data.block.count;
                    for (int i = 0; i < n - 1; ++i)
                        compile_statement(mbody->data.block.stmts[i], bc);
        
                    ASTNode* last = mbody->data.block.stmts[n - 1];
                    if (last->type == NODE_EXPR_STMT &&
                        last->data.expr_stmt.expr->type != NODE_ASSIGN)
                    {
                        // 最后一条是纯表达式 → 值直接作返回值
                        compile_expr(last->data.expr_stmt.expr, bc);
                    } else {
                        compile_statement(last, bc);
                        bc.code.push_back(OP_PUSH_NULL);
                    }
                    bc.code.push_back(OP_RETURN);
                } else {
                    if (mbody) compile_statement(mbody, bc);
                    bc.code.push_back(OP_PUSH_NULL);
                    bc.code.push_back(OP_RETURN);
                }
        
                mf.code_offset = body_start;
        
                size_t after = bc.code.size();
                write_int_operand(bc, skip_jump + 1, (int)after);
            }
        
            // ---- (g) 记录定义来源文件 ----
            if (current_filename) cc.defining_file = current_filename;
        
            // 类本身不需要在运行时压栈；后续 new 由 OP_NEW_OBJ 按 cls_idx 处理
            break;
        }

        case NODE_SWAP_ASSIGN: {
            // 与解释器对齐：不限制左值形式，交给 VM 里 get_mutable_ptr 处理。
            // 只需把两侧 AST 节点登记进 aux_ast_refs。
            int l_id = (int)bc.aux_ast_refs.size();
            bc.aux_ast_refs.push_back(node->data.swap.left);
            int r_id = (int)bc.aux_ast_refs.size();
            bc.aux_ast_refs.push_back(node->data.swap.right);

            bc.code.push_back(OP_SWAP_ASSIGN);
            push_int_operand(bc, l_id);
            push_int_operand(bc, r_id);
            bc.code.push_back(node->data.swap.global ? 1 : 0);
            break;
        }

        case NODE_ARRAY_ASSIGN: {
            ASTNode* left_expr = node->data.array_assign.left;
            if (!left_expr || left_expr->type != NODE_ARRAY_ACCESS) {
                kr_error("compile_statement: NODE_ARRAY_ASSIGN 左侧不是 NODE_ARRAY_ACCESS");
            }
            ASTNode* base_expr = left_expr->data.array_access.array;
            ASTNode* idx_expr  = node->data.array_assign.index;
        
            compile_expr(base_expr, bc);                        // [C]
            compile_expr(idx_expr,  bc);                        // [C, I]
            compile_expr(node->data.array_assign.expr, bc);     // [C, I, V]
            bc.code.push_back(OP_ARRAY_SET);                    // [C']  ← 新版会留结果
            emit_store_back_or_pop(base_expr, bc);              // [] 或 写回变量
            break;
        }

        case NODE_OBJECT_ASSIGN: {
            ASTNode* obj_node = node->data.object_assign.obj;
        
            // ---- 静态属性快线 ----
            if (obj_node && obj_node->type == NODE_VARIABLE) {
                std::string full = resolve_static_property(
                    obj_node->data.var_name, node->data.object_assign.key, bc);
                if (!full.empty()) {
                    compile_expr_raw(node->data.object_assign.value, bc);
                    int name_idx = push_string_operand(bc, full.c_str());
                    bc.code.push_back(OP_STORE);
                    push_int_operand(bc, name_idx);
                    break;
                }
            }
        
            // ---- 原始路径 ----
            compile_expr_raw(node->data.object_assign.obj,   bc);
            compile_expr_raw(node->data.object_assign.value, bc);
            int key_idx = push_string_operand(bc, node->data.object_assign.key);
            bc.code.push_back(OP_OBJ_SET);
            push_int_operand(bc, key_idx);                      // [O']
            emit_store_back_or_pop(obj_node, bc);
            break;
        }

        case NODE_ARRAY_COMPOUND_ASSIGN: {
            ASTNode* left_expr = node->data.array_compound_assign.left;
            if (!left_expr || left_expr->type != NODE_ARRAY_ACCESS) {
                kr_error("compile_statement: NODE_ARRAY_COMPOUND_ASSIGN 左侧不是 NODE_ARRAY_ACCESS");
            }
            ASTNode* base_expr = left_expr->data.array_access.array;
            ASTNode* idx_expr  = node->data.array_compound_assign.index;
            char     op        = node->data.array_compound_assign.op;

            compile_expr(base_expr, bc);                        // [C]
            compile_expr(idx_expr,  bc);                        // [C, I]
            bc.code.push_back(OP_DUP2);                         // [C, I, C, I]
            bc.code.push_back(OP_ARRAY_GET);                    // [C, I, elem]
            compile_expr(node->data.array_compound_assign.rhs, bc);  // [C, I, elem, rhs]

            switch (op) {
                case '+': bc.code.push_back(OP_ADD);     break;
                case '-': bc.code.push_back(OP_SUB);     break;
                case '*': bc.code.push_back(OP_MUL);     break;
                case '/': bc.code.push_back(OP_DIV);     break;
                case '%': bc.code.push_back(OP_MOD);     break;
                case '^': bc.code.push_back(OP_POW);     break;
                case '|': bc.code.push_back(OP_BIT_OR);  break;
                case '&': bc.code.push_back(OP_BIT_AND); break;
                case 'X': bc.code.push_back(OP_XOR);     break;
                default:
                    kr_error("NODE_ARRAY_COMPOUND_ASSIGN: 不支持的运算符 '%c'", op);
            }
            // [C, I, result]
            bc.code.push_back(OP_ARRAY_SET);                    // [C']
            emit_store_back_or_pop(base_expr, bc);
            break;
        }

        case NODE_OBJECT_COMPOUND_ASSIGN: {
            ASTNode* obj_node = node->data.object_compound_assign.obj;
            const char* key   = node->data.object_compound_assign.key;
            char        op    = node->data.object_compound_assign.op;
        
            // ---- 静态属性快线：Class.attr op= rhs ----
            if (obj_node && obj_node->type == NODE_VARIABLE) {
                std::string full = resolve_static_property(
                    obj_node->data.var_name, key, bc);
                if (!full.empty()) {
                    int name_idx = push_string_operand(bc, full.c_str());
        
                    // 尝试融合成 OP_<op>_TO_VAR
                    Opcode fused = OP_HALT;
                    switch (op) {
                        case '+': fused = OP_ADD_TO_VAR; break;
                        case '-': fused = OP_SUB_TO_VAR; break;
                        case '*': fused = OP_MUL_TO_VAR; break;
                        case '/': fused = OP_DIV_TO_VAR; break;
                        case '%': fused = OP_MOD_TO_VAR; break;
                        default:  break;
                    }
                    if (fused != OP_HALT) {
                        compile_expr_raw(node->data.object_compound_assign.rhs, bc);
                        bc.code.push_back(fused);
                        push_int_operand(bc, name_idx);
                    } else {
                        // 位运算 / 幂：GET_VAR + OP_<op> + STORE
                        bc.code.push_back(OP_GET_VAR);
                        push_int_operand(bc, name_idx);
                        compile_expr_raw(node->data.object_compound_assign.rhs, bc);
                        switch (op) {
                            case '|': bc.code.push_back(OP_BIT_OR);  break;
                            case '&': bc.code.push_back(OP_BIT_AND); break;
                            case 'X': bc.code.push_back(OP_XOR);     break;
                            case '^': bc.code.push_back(OP_POW);     break;
                            default:
                                kr_error("静态属性复合赋值：不支持的运算符 '%c'", op);
                        }
                        bc.code.push_back(OP_STORE);
                        push_int_operand(bc, name_idx);
                    }
                    break;
                }
            }
        
            // ---- 原始路径 ----
            int key_idx = push_string_operand(bc, key);
            compile_expr_raw(node->data.object_compound_assign.obj, bc);
            bc.code.push_back(OP_DUP);
            bc.code.push_back(OP_OBJ_GET);
            push_int_operand(bc, key_idx);
            bc.code.push_back(0);
            compile_expr_raw(node->data.object_compound_assign.rhs, bc);
            switch (op) {
                case '+': bc.code.push_back(OP_ADD);     break;
                case '-': bc.code.push_back(OP_SUB);     break;
                case '*': bc.code.push_back(OP_MUL);     break;
                case '/': bc.code.push_back(OP_DIV);     break;
                case '%': bc.code.push_back(OP_MOD);     break;
                case '^': bc.code.push_back(OP_POW);     break;
                case '|': bc.code.push_back(OP_BIT_OR);  break;
                case '&': bc.code.push_back(OP_BIT_AND); break;
                case 'X': bc.code.push_back(OP_XOR);     break;
                default:
                    kr_error("NODE_OBJECT_COMPOUND_ASSIGN: 不支持的运算符 '%c'", op);
            }
            bc.code.push_back(OP_OBJ_SET);
            push_int_operand(bc, key_idx);
            emit_store_back_or_pop(obj_node, bc);
            break;
        }
        case NODE_ALIAS_DECL: {
            // 别名声明：只需驻留两个名字并携带 global 位
            int name_idx   = push_string_operand(bc, node->data.alias_decl.name);
            int target_idx = push_string_operand(bc, node->data.alias_decl.target);
            bc.code.push_back(OP_ALIAS_DECL);
            push_int_operand(bc, name_idx);
            push_int_operand(bc, target_idx);
            bc.code.push_back(node->data.alias_decl.global ? 1 : 0);
            break;
        }

        case NODE_SCOPE_BLOCK: {
            // 进入新作用域 → 编译块体 → 退出作用域
            bc.code.push_back(OP_PUSH_SCOPE);
            for (int i = 0; i < node->data.block.count; ++i)
                compile_statement(node->data.block.stmts[i], bc);
            bc.code.push_back(OP_POP_SCOPE);
            break;
        }

        case NODE_GLOBAL_BLOCK: {
            // 切换到全局作用域执行块，之后恢复
            bc.code.push_back(OP_ENTER_GLOBAL_SCOPE);
            for (int i = 0; i < node->data.block.count; ++i)
                compile_statement(node->data.block.stmts[i], bc);
            bc.code.push_back(OP_EXIT_GLOBAL_SCOPE);
            break;
        }

        case NODE_THROW: {
            // 求值待抛出对象 → 发出 OP_THROW
            compile_expr(node->data.throw_expr.expr, bc);
            bc.code.push_back(OP_THROW);
            break;
        }
        case NODE_MULTI_ASSIGN: {
            const int rc = node->data.multi_assign.right_count;
            const int lc = node->data.multi_assign.left_count;
            // 与解释器一致：只取前 lc 个右侧结果，多余的丢弃
            const int use = (rc < lc) ? rc : lc;
        
            for (int i = 0; i < use; ++i)
                compile_expr(node->data.multi_assign.right_exprs[i], bc);
            // 右侧不足，补 null
            for (int i = rc; i < lc; ++i)
                bc.code.push_back(OP_PUSH_NULL);
        
            bc.code.push_back(OP_MULTI_ASSIGN);
            push_int_operand(bc, lc);
            for (int i = 0; i < lc; ++i) {
                const char* raw = node->data.multi_assign.left_names[i];
                std::string q = qualify_static_name(raw, bc);
                int idx = push_string_operand(bc, q.empty() ? raw : q.c_str());
                push_int_operand(bc, idx);
            }
            break;
        }
        case NODE_DESTRUCTURE_ASSIGN: {
            compile_expr(node->data.destructure.expr, bc);
        
            const int count = node->data.destructure.count;
            int rest_idx = -1;
            if (node->data.destructure.rest_name)
                rest_idx = push_string_operand(bc, node->data.destructure.rest_name);
        
            bc.code.push_back(OP_DESTRUCTURE_ASSIGN);
            push_int_operand(bc, count);
            push_int_operand(bc, rest_idx);
            bc.code.push_back(node->data.destructure.is_const ? 1 : 0);
            for (int i = 0; i < count; ++i) {
                const char* raw = node->data.destructure.names[i];
                std::string q = qualify_static_name(raw, bc);
                int idx = push_string_operand(bc, q.empty() ? raw : q.c_str());
                push_int_operand(bc, idx);
            }
            break;
        }
        case NODE_LAZY_VAR_DECL: {
            //   JMP <skip>
            //   OP_DECLARE_LAZY_VAR <name_idx:4> <global:1> <code_off:4> <code_end:4>
            //   <init code>
            // skip:
            size_t jmp_pos = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            bc.code.push_back(OP_DECLARE_LAZY_VAR);
            int name_idx = push_string_operand(bc, node->data.lazy_var_decl.name);
            push_int_operand(bc, name_idx);
            bc.code.push_back(node->data.lazy_var_decl.global ? 1 : 0);   //  global:1
        
            size_t off_pos = bc.code.size();
            push_int_operand(bc, 0);   // code_off 占位
            push_int_operand(bc, 0);   // code_end 占位
        
            size_t code_off = bc.code.size();
            compile_expr(node->data.lazy_var_decl.expr, bc);
            size_t code_end = bc.code.size();
            write_int_operand(bc, off_pos,     (int)code_off);
            write_int_operand(bc, off_pos + 4, (int)code_end);
        
            write_int_operand(bc, jmp_pos + 1, (int)bc.code.size());
            break;
        }
        case NODE_STRUCT_DEF: {
            const char* sname = node->data.struct_def.name ? node->data.struct_def.name : "";
            auto it = bc.func_by_name.find(sname);
            if (it == bc.func_by_name.end())
                kr_error("NODE_STRUCT_DEF: 预扫描未注册 '%s'", sname);
            const int func_idx = it->second;
            const int fc = node->data.struct_def.field_count;
        
            size_t skip_jump = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            size_t body_start = bc.code.size();
            for (int i = 0; i < fc; ++i) {
                const char* fname = node->data.struct_def.fields[i].name;
        
                int kidx = push_string_operand(bc, fname);
                bc.code.push_back(OP_PUSH_STRING);
                push_int_operand(bc, kidx);
        
                int vidx = push_string_operand(bc, fname);
                bc.code.push_back(OP_GET_VAR);
                push_int_operand(bc, vidx);
            }
            bc.code.push_back(OP_NEW_OBJECT);
            push_int_operand(bc, fc);
            bc.code.push_back(OP_RETURN);
        
            size_t body_end = bc.code.size();
            write_int_operand(bc, skip_jump + 1, (int)body_end);
            bc.functions[func_idx].code_offset = body_start;
        
            bc.code.push_back(OP_FUNC_DEF);
            push_int_operand(bc, func_idx);
        
            bc.code.push_back(OP_DECLARE_VAR);
            int name_idx = push_string_operand(bc, sname);
            push_int_operand(bc, name_idx);
            bc.code.push_back(0);
            bc.code.push_back(0);
            break;
        }
        case NODE_DESTRUCTURE: {
            compile_expr(node->data.destructure.expr, bc);
        
            const int count = node->data.destructure.count;
            bc.code.push_back(OP_DESTRUCTURE_ASSIGN);
            push_int_operand(bc, count);
            push_int_operand(bc, -1);                     // 无 rest_name
            bc.code.push_back(node->data.destructure.is_const ? 1 : 0);  // is_const
            for (int i = 0; i < count; ++i) {
                int idx = push_string_operand(bc, node->data.destructure.names[i]);
                push_int_operand(bc, idx);
            }
            break;
        }
        case NODE_SICHER: {
            compile_expr(node->data.sicher.expr, bc);
            size_t jf = bc.code.size();
            bc.code.push_back(OP_JMP_IF_FALSE);
            push_int_operand(bc, 0);
        
            size_t j_skip = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            // 假分支
            size_t fail_addr = bc.code.size();
            write_int_operand(bc, jf + 1, fail_addr);
        
            if (node->data.sicher.msg_expr) {
                compile_expr(node->data.sicher.msg_expr, bc);
            } else {
                int idx = push_string_operand(bc, "Fehler: sicher ist NICH");
                bc.code.push_back(OP_PUSH_STRING);
                push_int_operand(bc, idx);
            }
            bc.code.push_back(OP_SICHER_FAIL);
        
            size_t end_addr = bc.code.size();
            write_int_operand(bc, j_skip + 1, end_addr);
            break;
        }
        case NODE_RULE_DEF: {
            const char* fname = node->data.func_def.name ? node->data.func_def.name : "";
            int func_idx = bc.func_by_name.at(fname);
        
            size_t skip_jump = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            size_t body_start = bc.code.size();
            compile_func_body_implicit_return(node->data.func_def.body, bc);
        
            bc.functions[func_idx].code_offset = body_start;
            bc.functions[func_idx].is_rule     = true;
        
            compile_param_default_code(node, func_idx, bc);   // 传索引
        
            size_t after_defaults = bc.code.size();
            write_int_operand(bc, skip_jump + 1, (int)after_defaults);
        
            bc.code.push_back(OP_RULE_DEF);
            push_int_operand(bc, func_idx);
        
            bc.code.push_back(OP_DECLARE_VAR);
            int name_idx = push_string_operand(bc, fname);
            push_int_operand(bc, name_idx);
            bc.code.push_back(0);
            bc.code.push_back(node->data.func_def.global_scope ? 1 : 0);
            break;
        }
        case NODE_ASYNC_FUNC_DEF: {
            const char* fname = node->data.func_def.name ? node->data.func_def.name : "";
            auto it = bc.func_by_name.find(fname);
            if (it == bc.func_by_name.end())
                kr_error("NODE_ASYNC_FUNC_DEF: 预扫描未注册 '%s'", fname);
            const int func_idx = it->second;
        
            size_t skip_jump = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            size_t body_start = bc.code.size();
            compile_func_body_implicit_return(node->data.func_def.body, bc);
        
            bc.functions[func_idx].code_offset = body_start;
            bc.functions[func_idx].is_async    = true;
        
            compile_param_default_code(node, func_idx, bc);   // 传索引
        
            size_t after_defaults = bc.code.size();
            write_int_operand(bc, skip_jump + 1, (int)after_defaults);
        
            bc.code.push_back(OP_FUNC_DEF);
            push_int_operand(bc, func_idx);
        
            bc.code.push_back(OP_DECLARE_VAR);
            int name_idx = push_string_operand(bc, fname);
            push_int_operand(bc, name_idx);
            bc.code.push_back(0);
            bc.code.push_back(node->data.func_def.global_scope ? 1 : 0);
            break;
        }
        case NODE_TRY: {
            ASTNode* try_body     = node->data.try_stmt.try_body;
            ASTNode* catch_body   = node->data.try_stmt.catch_body;
            const char* catch_var = node->data.try_stmt.catch_var;
            ASTNode* finally_body = node->data.try_stmt.finally_body;
        
            size_t try_begin_pos = bc.code.size();
            bc.code.push_back(OP_TRY_BEGIN);
            push_int_operand(bc, 0);   // catch_addr
            push_int_operand(bc, 0);   // finally_addr（同时作为正常路径出口）
        
            // try 体
            compile_statement(try_body, bc);
            bc.code.push_back(OP_TRY_END);       // 正常完成：弹 handler
        
            size_t jmp_to_finally = bc.code.size();
            bc.code.push_back(OP_JMP);
            push_int_operand(bc, 0);
        
            // catch 入口
            size_t catch_addr = bc.code.size();
            if (catch_body) {
                // 声明 catch 变量
                if (catch_var && strcmp(catch_var, "_") != 0) {
                    bc.code.push_back(OP_GET_CAUGHT);
                    bc.code.push_back(OP_DECLARE_VAR);
                    int ci = push_string_operand(bc, catch_var);
                    push_int_operand(bc, ci);
                    bc.code.push_back(0); bc.code.push_back(0);
                    // 标记 is_read=true 与解释器行为对齐
                    bc.code.push_back(OP_MARK_VAR_READ);
                    push_int_operand(bc, ci);
                } else {
                    // 丢弃
                    bc.code.push_back(OP_GET_CAUGHT);
                    bc.code.push_back(OP_POP);
                }
                compile_statement(catch_body, bc);
            } else {
                // 无 catch：异常一路向上传播
                bc.code.push_back(OP_THROW_RE);
            }
        
            size_t catch_end = bc.code.size();
            write_int_operand(bc, jmp_to_finally + 1, catch_end);
            // 更新 TRY_BEGIN 的 catch_addr
            write_int_operand(bc, try_begin_pos + 1, (int)catch_addr);
        
            // finally 体（只写一次）
            size_t finally_addr = bc.code.size();
            write_int_operand(bc, try_begin_pos + 5, (int)finally_addr);
            if (finally_body) {
                compile_statement(finally_body, bc);
            }
            bc.code.push_back(OP_FINALLY_END);   // 所有路径汇聚于此
            break;
        }
        case NODE_AWAIT: {
            compile_expr(node->data.await.expr, bc);
            bc.code.push_back(OP_AWAIT_PREP);
        
            if (node->data.await.timeout) {
                compile_expr(node->data.await.timeout, bc);
                bc.code.push_back(OP_TO_INT64);       // 新 opcode：任意数值 → int64
                bc.code.push_back(1);
            } else {
                bc.code.push_back(OP_PUSH_INT64); push_int64_bytes(bc, -1);
                bc.code.push_back(0);
            }
            bc.code.push_back(node->data.await.fallback ? 1 : 0);
        
            // fallback 表达式需要在超时时求值——把它也编译在后面
            if (node->data.await.fallback) {
                compile_expr(node->data.await.fallback, bc);
            }
        
            bc.code.push_back(OP_AWAIT_WAIT);
            break;
        }
        case NODE_NEW: {
            const std::string cname = node->data.new_expr.class_name;
            auto it = bc.class_by_name.find(cname);
            if (it == bc.class_by_name.end())
                kr_error("未定义类 '%s'", cname.c_str());
            const int cls_idx = it->second;
        
            int argc = node->data.new_expr.arg_count;
            for (int i = 0; i < argc; ++i)
                compile_expr(node->data.new_expr.args[i], bc);
        
            bc.code.push_back(OP_NEW_OBJ);
            push_int_operand(bc, cls_idx);
            push_int_operand(bc, argc);
            break;
        }
        case NODE_UMF_DEF: {
            const std::string nname = node->data.umf_def.name;
            const std::string pname = node->data.umf_def.parent_name
                                          ? node->data.umf_def.parent_name : "";
        
            int ns_idx = -1;
            auto it = bc.ns_by_name.find(nname);
            if (it != bc.ns_by_name.end() && it->second >= 0)
                ns_idx = it->second;
        
            if (ns_idx < 0 || ns_idx >= (int)bc.namespaces.size()) {
                ns_idx = (int)bc.namespaces.size();
                bc.ns_by_name[nname] = ns_idx;
                bc.namespaces.emplace_back();
                bc.namespaces.back().name = nname;
            }
            if (bc.namespaces[ns_idx].name.empty())
                bc.namespaces[ns_idx].name = nname;
        
            // 把 von "B" 记录下来
            bc.namespaces[ns_idx].parent = pname;
        
            bc.code.push_back(OP_PUSH_NS);
            push_int_operand(bc, ns_idx);
            compile_statement(node->data.umf_def.body, bc);
            bc.code.push_back(OP_POP_NS);
            break;
        }
        case NODE_INPUT: {
            // ---- 1. 编译正则参数（按解释器的求值顺序：全部求值，只有第一个生效）----
            const int argc = node->data.input.arg_count;
            for (int i = 0; i < argc; ++i)
                compile_expr(node->data.input.args[i], bc);

            // ---- 2. 若有 multiline_expr，编译成一段独立 code block ----
            //   JMP <skip>
            //   <multiline_expr code>   ; 求值后栈顶是条件值
            // skip:
            // 运行时通过 run_until(code_off, code_end) 反复调用
            size_t multiline_start = 0, multiline_end = 0;
            if (node->data.input.multiline_expr) {
                size_t jmp_pos = bc.code.size();
                bc.code.push_back(OP_JMP);
                push_int_operand(bc, 0);

                multiline_start = bc.code.size();
                compile_expr(node->data.input.multiline_expr, bc);

                multiline_end = bc.code.size();
                write_int_operand(bc, jmp_pos + 1, (int)multiline_end);
            }

            // ---- 3. 发 OP_INPUT ----
            int name_idx = push_string_operand(bc, node->data.input.name);
            bc.code.push_back(OP_INPUT);
            push_int_operand(bc, name_idx);
            push_int_operand(bc, node->data.input.flags);
            push_int_operand(bc, argc);
            push_int_operand(bc, (int)multiline_start);
            push_int_operand(bc, (int)multiline_end);
            break;
        }
        case NODE_UMF_IMPORT: {
            // 查找命名空间索引（预扫描时已通过 NODE_UMF_DEF 登记到 ns_by_name）
            const char* ns_name = node->data.umf_import.name;
            auto it = bc.ns_by_name.find(ns_name ? ns_name : "");
            if (it == bc.ns_by_name.end())
                kr_error("命名空间 '%s' 未定义", ns_name ? ns_name : "");
        
            // OP_IMPORT_NS <ns_idx:4>
            //   VM 侧语义：
            //     1) 把命名空间 Scope 中的全部变量拷贝进当前作用域（覆盖同名）
            //     2) 把 A::X 形式的类/枚举/变体注册成裸名 X（受 class_shortnames 驱动）
            bc.code.push_back(OP_IMPORT_NS);
            push_int_operand(bc, it->second);
            break;
        }
        case NODE_SUPER_CALL: {
            // ober(...) 作为语句：求值 → 丢弃 null 结果。
            // 与 NODE_FUNC_CALL 语句版同样的处理。
            compile_expr(node, bc);
            bc.code.push_back(OP_POP);
            break;
        }
        case NODE_UNION_DEF: {
            const std::string uname =
                node->data.union_def.name ? node->data.union_def.name : "";
            // 不要因为 uname 为空就 break；变体声明与 union 名无关。
            // 若解析器没填名字，至少变体函数仍应可被调用。
        
            for (int i = 0; i < node->data.union_def.variant_count; ++i) {
                UnionVariant* v = &node->data.union_def.variants[i];
                const char* vn = v->name;
                if (!vn || !*vn) continue;
        
                // 与预扫描使用同一把 intern 键
                const char* vn_key = intern_name(bc, vn);
                auto it = bc.func_by_name.find(vn_key);
                if (it == bc.func_by_name.end())
                    kr_error("NODE_UNION_DEF: 预扫描未注册变体 '%s'", vn);
                const int func_idx = it->second;
                CompiledFunction& cf = bc.functions[func_idx];
        
                // ---- 变体函数体 ----
                //   JMP <skip>
                //   body_start:
                //     PUSH_STRING "__tag" ; PUSH_STRING vn
                //     PUSH_STRING "__felder"   ; PUSH_STRING uname
                //     PUSH_STRING <field_j>   ; GET_VAR <param_j>     (×count)
                //     OP_NEW_OBJECT (2+count)
                //     OP_RETURN
                //   skip:
                //   OP_FUNC_DEF func_idx
                //   OP_DECLARE_VAR vn
                size_t skip_jump = bc.code.size();
                bc.code.push_back(OP_JMP);
                push_int_operand(bc, 0);
        
                size_t body_start = bc.code.size();
                const int count = (v->param_count > 0) ? v->param_count : v->field_count;
                const int total = 2 + count;
        
                // "__tag" : vn
                { int k = push_string_operand(bc, "__tag");
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
                { int k = push_string_operand(bc, vn);
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
        
                // "__felder" : uname（uname 为空时就是一个空字符串，无害）
                { int k = push_string_operand(bc, "__felder");
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
                { int k = push_string_operand(bc, uname.c_str());
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
        
                // 字段（具名或位置）
                for (int j = 0; j < count; ++j) {
                    std::string fname = (v->param_count > 0)
                        ? std::to_string(j)
                        : std::string(v->named_fields[j].name);
                    int fk = push_string_operand(bc, fname.c_str());
                    bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, fk);
        
                    // 读同名参数
                    int pk = push_string_operand(bc, cf.params[j].c_str());
                    bc.code.push_back(OP_GET_VAR); push_int_operand(bc, pk);
                }
        
                bc.code.push_back(OP_NEW_OBJECT);
                push_int_operand(bc, total);
                bc.code.push_back(OP_RETURN);
        
                size_t body_end = bc.code.size();
                write_int_operand(bc, skip_jump + 1, (int)body_end);
                cf.code_offset = body_start;
        
                // 在作用域里注册变体函数
                bc.code.push_back(OP_FUNC_DEF);
                push_int_operand(bc, func_idx);
        
                bc.code.push_back(OP_DECLARE_VAR);
                int name_idx = push_string_operand(bc, vn);
                push_int_operand(bc, name_idx);
                bc.code.push_back(0);   // is_const = 0
                bc.code.push_back(0);   // is_global = 0
            }
            break;
        }
        case NODE_TYPE_DEF: {
            const char* tname = node->data.type_def.name;
            if (!tname || !*tname) break;
        
            std::vector<std::string> values;
            for (int i = 0; i < node->data.type_def.member_count; ++i) {
                ASTNode* member = node->data.type_def.members[i];
                if (!member) continue;
                if (member->type == NODE_STRING) {
                    values.emplace_back(member->data.string ? member->data.string : "");
                } else if (member->type == NODE_VARIABLE) {
                    // 编译期求值：从当前已折叠的常量里找
                    // 拿不到常量值就在 VM 侧解析；这里先只登记名字
                    values.emplace_back(member->data.var_name ? member->data.var_name : "");
                } else {
                    kr_error("类型成员必须是变量引用或字符串常量");
                }
            }
            bc.string_unions[tname] = std::move(values);
            break;
        }
        case NODE_ENUM_DEF: {
            const std::string uname =
                node->data.enum_def.name ? node->data.enum_def.name : "";
        
            for (int i = 0; i < node->data.enum_def.variant_count; ++i) {
                const char* vn = node->data.enum_def.variants
                                    ? node->data.enum_def.variants[i] : nullptr;
                if (!vn || !*vn) continue;
        
                const char* vn_key = intern_name(bc, vn);
                auto it = bc.func_by_name.find(vn_key);
                if (it == bc.func_by_name.end())
                    kr_error("NODE_ENUM_DEF: 预扫描未注册变体 '%s'", vn);
                const int func_idx = it->second;
                CompiledFunction& cf = bc.functions[func_idx];
        
                //   JMP <skip>
                //   body_start:
                //     PUSH_STRING "__tag" ; PUSH_STRING vn
                //     PUSH_STRING "__felder"   ; PUSH_STRING uname
                //     PUSH_STRING "0" ; GET_VAR "0"      (×count)
                //     OP_NEW_OBJECT (2+count)
                //     OP_RETURN
                //   skip:
                //   OP_FUNC_DEF func_idx
                //   OP_DECLARE_VAR vn
                size_t skip_jump = bc.code.size();
                bc.code.push_back(OP_JMP);
                push_int_operand(bc, 0);
        
                size_t body_start = bc.code.size();
                const int count = node->data.enum_def.variant_param_counts
                                    ? node->data.enum_def.variant_param_counts[i] : 0;
                const int total = 2 + count;
        
                // "__tag" : vn
                { int k = push_string_operand(bc, "__tag");
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
                { int k = push_string_operand(bc, vn);
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
        
                // "__felder" : uname
                { int k = push_string_operand(bc, "__felder");
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
                { int k = push_string_operand(bc, uname.c_str());
                  bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, k); }
        
                // 位置字段："0" : 参数0, "1" : 参数1, ...
                for (int j = 0; j < count; ++j) {
                    std::string fname = std::to_string(j);
                    int fk = push_string_operand(bc, fname.c_str());
                    bc.code.push_back(OP_PUSH_STRING); push_int_operand(bc, fk);
        
                    int pk = push_string_operand(bc, cf.params[j].c_str());
                    bc.code.push_back(OP_GET_VAR); push_int_operand(bc, pk);
                }
        
                bc.code.push_back(OP_NEW_OBJECT);
                push_int_operand(bc, total);
                bc.code.push_back(OP_RETURN);
        
                size_t body_end = bc.code.size();
                write_int_operand(bc, skip_jump + 1, (int)body_end);
                cf.code_offset = body_start;
        
                // 在作用域里注册变体函数
                bc.code.push_back(OP_FUNC_DEF);
                push_int_operand(bc, func_idx);
        
                bc.code.push_back(OP_DECLARE_VAR);
                int name_idx = push_string_operand(bc, vn);
                push_int_operand(bc, name_idx);
                bc.code.push_back(0);   // is_const = 0
                bc.code.push_back(0);   // is_global = 0
            }
            break;
        }
        case NODE_NULL:
            break;
        default:
            kr_error("compile_statement: 不支持的语句类型 %d", node->type);
    }
}

// ============================================================================
// 内置函数实现（VM 端）
// ============================================================================

// 辅助：把 Value 转成 double（快慢路径）
static double bi_to_double(const Value& v) {
    switch (v.type) {
        case VAL_INT64: return (double)v.int64_val;
        case VAL_INT:   return mpz_get_d(*v.big_int);
        case VAL_FLOAT: return mpf_get_d(*v.mpf_val);
        default:        return 0.0;
    }
}
static bool bi_is_num(const Value& v) {
    return v.type == VAL_INT64 || v.type == VAL_INT || v.type == VAL_FLOAT;
}

// 一元数学：接受数值，返回 mpf
static Value bi_math_unary(const Value& a, const char* name, double (*fn)(double)) {
    if (!bi_is_num(a)) kr_error("%s 参数必须是数值", name);
    double x = bi_to_double(a);
    double r = fn(x);
    mpf_t t; mpf_init(t); mpf_set_d(t, r);
    Value v = make_float(t); mpf_clear(t);
    return v;
}

namespace {
    std::chrono::steady_clock::time_point g_vm_tick_time;
    bool                                   g_vm_tick_set = false;
}

struct TimerTask {
    int64_t expire_ms;
    std::function<void()> callback;
    bool operator>(const TimerTask& other) const {
        return expire_ms > other.expire_ms;
    }
};

namespace timer_system {
    std::priority_queue<TimerTask, std::vector<TimerTask>, std::greater<TimerTask>> task_queue;
    std::mutex mtx;
    std::condition_variable cv;  // cv，替代裸sleep
    std::atomic<bool> running{false};
    std::thread worker;

    static int64_t get_current_timestamp_ms() {
        auto now = std::chrono::steady_clock::now();
        return std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();
    }

    static void worker_loop() {
        std::unique_lock<std::mutex> lock(mtx);
        while (running.load()) {
            if (task_queue.empty()) {
                cv.wait(lock);
                continue;
            }
            const auto& top_task = task_queue.top();
            int64_t now = get_current_timestamp_ms();
            if (now >= top_task.expire_ms) {
                auto task = std::move(task_queue.top());
                task_queue.pop();
                lock.unlock();
                task.callback();
                lock.lock();
                continue;
            }
            int64_t wait = top_task.expire_ms - now;
            cv.wait_for(lock, std::chrono::milliseconds(wait));
        }
    }

    static void add(int64_t ms, std::function<void()> fn) {
        std::lock_guard<std::mutex> lock(mtx);
        int64_t expire = get_current_timestamp_ms() + ms;
        task_queue.push({expire, std::move(fn)});
        if (!running.load()) {
            running.store(true);
            worker = std::thread(worker_loop);
        }
        cv.notify_one();
    }

    static void stop() {
        std::lock_guard<std::mutex> lock(mtx);
        running.store(false);
        cv.notify_one();
    }
    static void join() {
        if (worker.joinable()) worker.join();
    }
}

static Value vm_builtin_dispatch(BuiltinId id, Value* args, int argc,
    const Bytecode* bc, void* ctx);

class VM {
struct LoopContext {
    size_t start_pc;   // 循环开始地址（用于 continue）
    size_t end_pc;     // 循环结束地址（用于 break）
};
std::vector<LoopContext> loop_stack;

enum PendingAction : uint8_t {
    PENDING_NONE     = 0,
    PENDING_RETURN   = 1,
    PENDING_BREAK    = 2,   // 预留给后续
    PENDING_CONTINUE = 3,   // 预留给后续
    PENDING_RETHROW  = 4,
};

struct CompilerCallFrame {
    size_t return_pc;
    size_t stack_base;
    bool   is_ctor_call = false;
    bool   is_super_call = false;
    int    func_idx     = -1;
};

struct TryFrame {
    size_t catch_pc   = 0;
    size_t finally_pc = 0;
    size_t stack_depth = 0;
    uint8_t pending_action = PENDING_NONE;
    Value   pending_value;              // return 值 / 待重抛的异常值
    TryFrame() { pending_value = make_null(); }
};

std::vector<CompilerCallFrame> frames;

std::vector<TryFrame> try_stack;
Value caught_exception = make_null();
bool  has_caught = false;
std::vector<std::string> frame_rule_keys;

std::unordered_map<std::string, Scope*> vm_named_scopes;
int next_scope_id = 1;

Value* current_constructed_obj = nullptr;
std::string current_filename;

std::vector<Scope*> saved_scope_stack;  // 用于 OP_ENTER/EXIT_GLOBAL_SCOPE

bool vm_dispatch_method(Value& obj, const char* method,
    Value* args, int argc, bool is_optional,
    Value& out_result);

void vm_enter_function_call(const CompiledFunction& cf, int func_idx,
                            int argc, const Value* dies_obj);

// 各类型的子分发
Value vm_method_string(Value& obj, const char* method, Value* args, int argc);
Value vm_method_array (Value& obj, const char* method, Value* args, int argc);
Value vm_method_number(Value& obj, const char* method, Value* args, int argc);
Value vm_method_pointer(Value& obj, const char* method, Value* args, int argc);
Value vm_method_function(Value& obj, const char* method, Value* args, int argc);
bool  vm_method_object_builtin(Value& obj, const char* method,
                                Value* args, int argc, Value& out);
Value vm_method_type_of(Value& obj);
void  vm_method_leeren(Value* obj);

public:
    const Bytecode* bc;
    Bytecode* mutable_bc;
    std::mutex vm_lock;
    bool is_finished = false;
    
    struct ThreadContext {
        VM*    prev_vm;
        Scope* prev_scope;
        size_t prev_pc;
        const Bytecode* prev_bc;
    };

    // HTTP / 异步线程入口：把当前 VM 挂到该线程的 g_active_vm 上，
    // 并把 current_scope 拉到一个干净的起点。
    ThreadContext enter_thread_context(const Bytecode* bytecode, Scope* root_scope) {
        // 后台线程进入前，必须先锁VM，阻止主线程同时跑VM
        vm_lock.lock();

        // 保存旧状态
        ThreadContext ctx{ g_active_vm, current_scope, this->pc, this->bc };

        this->bc = bytecode;
        this->pc = 0;
        g_active_vm = this;
        current_scope = root_scope;
        return ctx;
    }
    
    // ---- 供 vm_invoke 等自由函数使用的最小访问器 ----
    int function_count() const {
        return bc ? (int)bc->functions.size() : 0;
    }

    // 按名字查函数索引；找不到返回 -1。名字必须与 func_by_name 里的键一致。
    int find_func_by_name(const char* name) const {
        if (!bc || !name) return -1;
        auto it = bc->func_by_name.find(name);
        return (it == bc->func_by_name.end()) ? -1 : it->second;
    }

    void exit_thread_context(const ThreadContext& ctx) {
        // 恢复 pc、bc
        this->pc = ctx.prev_pc;
        this->bc = ctx.prev_bc;

        current_scope = ctx.prev_scope;
        g_active_vm   = ctx.prev_vm;

        // 释放锁，主线程可以继续执行VM
        vm_lock.unlock();
    }

    // 在 VM 上下文里执行惰性变量的代码块，把结果写进 cached_value。
    // 幂等：已求值 / 无代码块 / 非惰性都直接返回。
    void force_eval_lazy(Variable* var) {
        if (!var || !var->is_lazy) return;
        if (var->evaluated) return;
        if (var->lazy_code_off == SIZE_MAX) return;   // 无代码块（纯解释器路径）

        Scope* saved = current_scope;
        current_scope = var->lazy_scope ? var->lazy_scope : saved;
        struct ScopeGuard {
            Scope** slot; Scope* old;
            ~ScopeGuard() { *slot = old; }
        } guard{&current_scope, saved};

        size_t save_pc = pc;
        pc = var->lazy_code_off;
        run_until(var->lazy_code_end);
        pc = save_pc;

        Value v = std::move(stack.back());
        stack.pop_back();
        free_value(&var->cached_value);
        var->cached_value = v;
        var->evaluated    = true;
    }

    Value call_compiled(int func_idx, Value* args, int argc) {
        if (func_idx < 0 || func_idx >= (int)bc->functions.size())
            kr_error("call_compiled: 函数索引 %d 越界 (总数 %zu)",
                     func_idx, bc->functions.size());
        const CompiledFunction& cf = bc->functions[func_idx];
        const int  param_count = (int)cf.params.size();
        const bool has_vararg  = !cf.vararg_name.empty();
    
        if (!has_vararg && argc > param_count)
            kr_error("函数 '%s' 参数过多：期望 %d，实际 %d",
                     cf.name.c_str(), param_count, argc);
        for (int i = argc; i < param_count; ++i) {
            bool has = (i < (int)cf.param_defaults_idx.size() && cf.param_defaults_idx[i] >= 0)
                    || (i < (int)cf.param_default_code_off.size() && cf.param_default_code_off[i] != SIZE_MAX)
                    || (i < (int)cf.param_has_default.size() && cf.param_has_default[i]);
            if (!has)
                kr_error("函数 '%s' 缺少参数 '%s'",
                         cf.name.c_str(), cf.params[i].c_str());
        }
        const int check = (argc < param_count) ? argc : param_count;
        for (int i = 0; i < check; ++i) {
            if (i >= (int)cf.param_types.size() || cf.param_types[i].empty()) continue;
            if (!vm_check_type(args[i], cf.param_types[i]))
                kr_error("函数 '%s' 参数 '%s' 类型错误",
                         cf.name.c_str(), cf.params[i].c_str());
        }
    
        const size_t  save_pc      = pc;
        const size_t  base_stack   = stack.size();
        const size_t  base_frames  = frames.size();
        const size_t  base_keys    = frame_rule_keys.size();
        Scope* const  entry_scope  = current_scope;   // 关键：记录进入时的 scope
    
        push_scope();
    
        /* ---- 绑定参数（照旧）---- */
        const int bound = (argc < param_count) ? argc : param_count;
        for (int i = 0; i < bound; ++i) {
            bool is_const = (i < (int)cf.param_is_const.size()) ? cf.param_is_const[i] : false;
            declare_var_in_scope(current_scope, cf.params[i].c_str(), is_const,
                                 copy_value(args[i]));
        }
        for (int i = bound; i < param_count; ++i) {
            Value defval = make_null();
            int di = (i < (int)cf.param_defaults_idx.size()) ? cf.param_defaults_idx[i] : -1;
            if (di >= 0) {
                defval = copy_value(bc->constants[di]);
            } else if (i < (int)cf.param_default_code_off.size()
                    && cf.param_default_code_off[i] != SIZE_MAX) {
                size_t s = pc;
                pc = cf.param_default_code_off[i];
                run_until(cf.param_default_code_end[i]);
                defval = std::move(stack.back());
                stack.pop_back();
                pc = s;
            }
            declare_var_in_scope(current_scope, cf.params[i].c_str(), false, defval);
        }
        if (has_vararg) {
            const int vc = (argc > param_count) ? (argc - param_count) : 0;
            Value* elems = vc ? (Value*)malloc((size_t)vc * sizeof(Value)) : nullptr;
            for (int i = 0; i < vc; ++i) elems[i] = copy_value(args[param_count + i]);
            Value arr = make_array(elems, vc);
            if (elems) free(elems);
            declare_var_in_scope(current_scope, cf.vararg_name.c_str(), false, arr);
        }
    
        CompilerCallFrame frame;
        frame.return_pc  = SIZE_MAX;
        frame.stack_base = base_stack;
        frame.func_idx   = func_idx;
        frames.push_back(frame);
        frame_rule_keys.push_back(std::string());
    
        bool ok = false;
        try {
            pc = cf.code_offset;
            run_until(SIZE_MAX);
            ok = true;
        } catch (...) {
            // 1. 把 frames/frame_rule_keys 精确恢复到本次调用前的状态
            while (frames.size() > base_frames) {
                frames.pop_back();
                if (frame_rule_keys.size() > base_keys) frame_rule_keys.pop_back();
            }
            frame_rule_keys.resize(base_keys);
    
            // 2. 把 scope 链恢复到进入时的状态
            while (current_scope && current_scope != entry_scope) {
                pop_scope();
            }
    
            // 3. 把栈上残留的中间值清掉，避免悬垂 Value 泄漏
            while (stack.size() > base_stack) {
                free_value(&stack.back());
                stack.pop_back();
            }
    
            pc = save_pc;
            throw;
        }
    
        pc = save_pc;
        Value result = make_null();
        if (ok && stack.size() > base_stack) {
            result = std::move(stack.back());
            stack.pop_back();
        }
        return result;
    }

    Value run(Bytecode& bytecode) {
        Value ret;
        VM* prev = g_active_vm;
        g_active_vm = this;
        struct Guard { VM* p; ~Guard() { g_active_vm = p; } } g{prev};
    
        bc = &bytecode;
        mutable_bc = &bytecode;
        pc = 0;
        stack.clear();
        frames.clear();
        try {
            run_until(bc->code.size());
            ret = stack.empty() ? make_null() : stack.back();
        } catch (const KRError& e) {
            if (!e.isAlreadyPrinted()) {
                int line = g_last_error_line;
                int col = g_last_error_col;
                if (line == 0) { line = 1; col = 1; }
        
                const char* filename = find_filename_by_line_col(line, col);
                if (!filename) filename = current_filename.c_str();
                if (!filename) filename = "-";

                print_source_context(line, col, filename);
                
                fprintf(stderr, "%s\n", e.what());
            }
            ret = make_null();
        } catch (const std::exception& e) {
            fprintf(stderr, "[VM] std::exception: %s\n", e.what());
            ret = make_null();
        } catch (...) {
            fprintf(stderr, "[VM] 未捕获未知异常\n");
            ret = make_null();
        }
        is_finished = true;
        timer_system::stop();
        timer_system::join();

        if (g_warnings_enabled && original_global_scope) {
            for (int i = 0; i < original_global_scope->var_count; ++i) {
                Variable* var = &original_global_scope->vars[i];
                if (!var->is_read && var->value.type != VAL_FUNCTION) {
                    auto it = g_var_decl_pos.find(var->name);
                    if (it != g_var_decl_pos.end()) {
                        g_last_error_line = it->second.first;
                        g_last_error_col = it->second.second;
                    } else {
                        g_last_error_line = 1;
                        g_last_error_col = 1;
                    }
                    const char* kind = var->is_const ? "Konstante" : "Variable";
                    std::string type_str = value_type_to_string(var->value);
                    kr_warn("%s '%s' 被声明但从未使用 (typ: %s)", kind, var->name, type_str.c_str());
                }
            }
        }
        
        if (g_warnings_enabled) {
            // bc 是成员指针，指向传入的bytecode
            for (const auto& cf : bc->functions) {
                if (!cf.called) {
                    auto it = g_func_decl_pos.find(cf.name);
                    if (it != g_func_decl_pos.end()) {
                        g_last_error_line = it->second.first;
                        g_last_error_col = it->second.second;
                    } else {
                        g_last_error_line = 1;
                        g_last_error_col = 1;
                    }
                    kr_warn("Funktion '%s' 被定义但从未调用", cf.name.c_str());
                }
            }
        }

        return ret;
    }
    
    void retain()  { vm_refcount++; }
    void release() {
        if (--vm_refcount == 0) {
            delete this;
        }
    }

private:
    int vm_refcount = 1;
    size_t pc;
    std::vector<Value> stack;

    bool run_until(size_t end_pc) {
        g_current_operating_position = "<LAUFZEIT>";
        try {
            while (pc < end_pc) {
                uint8_t op = bc->code[pc++];
                switch (static_cast<Opcode>(op)) {
                    case OP_SETLINE: {
                        int line = read_int_operand(*bc, pc);
                        int col = read_int_operand(*bc, pc);
                        g_last_error_line = line;
                        g_last_error_col = col;
                        break;
                    }
                    // ---- 常量加载 ----
                    case OP_PUSH_INT64: {
                        int64_t val = 0;
                        for (int i = 0; i < 8; ++i)
                            val |= (static_cast<int64_t>(bc->code[pc++]) << (i*8));
                        stack.push_back(make_int64(val));
                        break;
                    }
                    case OP_PUSH_INT: {
                        int idx = read_int_operand(*bc, pc);
                        const Value& s = bc->constants[idx];
                        mpz_t tmp; mpz_init(tmp);
                        if (mpz_set_str(tmp, s.str_val, 0) != 0)
                            kr_error("无效整数常量");
                        stack.push_back(make_int(tmp));
                        mpz_clear(tmp);
                        break;
                    }
                    case OP_PUSH_FLOAT: {
                        int idx = read_int_operand(*bc, pc);
                        const Value& s = bc->constants[idx];
                        if (s.type == VAL_FLOAT) {
                            // 常量池里已经是解析好的浮点值 —— 直接深拷贝
                            stack.push_back(copy_value(s));
                        } else if (s.type == VAL_STRING) {
                            // 兼容：默认值路径 emit_push_constant 也会发 OP_PUSH_FLOAT
                            mpf_t tmp; mpf_init(tmp);
                            if (mpf_set_str(tmp, s.str_val, 10) != 0) {
                                mpf_clear(tmp);
                                kr_error("无效浮点常量");
                            }
                            stack.push_back(make_float(tmp));
                            mpf_clear(tmp);
                        } else {
                            kr_error("OP_PUSH_FLOAT: 常量池类型错误 (type=%d)", (int)s.type);
                        }
                        break;
                    }
                    case OP_PUSH_STRING: {
                        int idx = read_int_operand(*bc, pc);
                        stack.push_back(copy_value(bc->constants[idx]));
                        break;
                    }
                    case OP_MATCH_TRY: {
                        int pat_idx = read_int_operand(*bc, pc);
                        ASTNode* pattern = bc->aux_ast_refs[pat_idx];
                    
                        Value val = std::move(stack.back());
                        stack.pop_back();
                    
                        // 与解释器对齐：如果 try_match_pattern 内部抛异常，
                        // 回滚本分支已经部分绑定的变量，避免污染 scope。
                        const int saved_var_count = current_scope ? current_scope->var_count : 0;
                    
                        bool matched = false;
                        try {
                            matched = try_match_pattern(pattern, val);
                        } catch (...) {
                            if (current_scope) {
                                while (current_scope->var_count > saved_var_count) {
                                    Variable* var = &current_scope->vars[--current_scope->var_count];
                                    free(var->name);
                                    free_value(&var->value);
                                }
                            }
                            free_value(&val);
                            throw;
                        }
                    
                        free_value(&val);
                        stack.push_back(make_int64(matched ? 1 : 0));
                        break;
                    }
                    // ---- 二元运算（弹出右，再弹左，压回结果） ----
                    #define BINOP(opcode, func) \
                        case opcode: { \
                            Value r = std::move(stack.back()); stack.pop_back(); \
                            Value l = std::move(stack.back()); stack.pop_back(); \
                            Value res = func(l, r); \
                            free_value(&l); free_value(&r); \
                            stack.push_back(res); \
                            break; \
                        }
                    BINOP(OP_ADD, op_add);
                    BINOP(OP_SUB, op_sub);
                    BINOP(OP_MUL, op_mul);
                    BINOP(OP_DIV, op_div);
                    BINOP(OP_MOD, op_mod);
                    BINOP(OP_POW, op_pow);
                    BINOP(OP_CONCAT, op_concat);
                    BINOP(OP_XOR, op_xor);
                    BINOP(OP_CMP_EQ, [](const Value& l, const Value& r){ return op_compare(l, r, 'E'); });
                    BINOP(OP_CMP_NE, [](const Value& l, const Value& r){ return op_compare(l, r, 'N'); });
                    BINOP(OP_CMP_GT, [](const Value& l, const Value& r){ return op_compare(l, r, '>'); });
                    BINOP(OP_CMP_LT, [](const Value& l, const Value& r){ return op_compare(l, r, '<'); });
                    BINOP(OP_CMP_GE, [](const Value& l, const Value& r){ return op_compare(l, r, 'G'); });
                    BINOP(OP_CMP_LE, [](const Value& l, const Value& r){ return op_compare(l, r, 'L'); });
                    BINOP(OP_CMP_3WAY, [](const Value& l, const Value& r){ return op_compare(l, r, 'C'); });
                    BINOP(OP_BIT_OR,  op_bit_or);
                    BINOP(OP_BIT_AND, op_bit_and);
                    BINOP(OP_SHL,     op_shl);
                    BINOP(OP_SHR,     op_shr);
                    #undef BINOP

                    // ============================================================================
                    // exec_statement
                    // ============================================================================
                    case OP_PRINT: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        vm_print_value_cout(v);
                        std::cout << '\n';
                        std::cout.flush();
                        free_value(&v);
                        break;
                    }
                    
                    case OP_PRINT_NO_NEWLINE: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        vm_print_value_cout(v);
                        std::cout.flush();
                        free_value(&v);
                        break;
                    }
                    
                    case OP_PRINT_MULTI: {
                        int n = read_int_operand(*bc, pc);
                        for (int i = 0; i < n; ++i) {
                            Value v = std::move(stack[stack.size() - n + i]);
                            vm_print_value_cout(v);
                            free_value(&v);
                        }
                        stack.resize(stack.size() - n);
                        std::cout << '\n';
                        std::cout.flush();
                        break;
                    }
                    
                    case OP_PRINT_NO_NEWLINE_MULTI: {
                        int n = read_int_operand(*bc, pc);
                        for (int i = 0; i < n; ++i) {
                            Value v = std::move(stack[stack.size() - n + i]);
                            vm_print_value_cout(v);
                            free_value(&v);
                        }
                        stack.resize(stack.size() - n);
                        std::cout.flush();
                        break;
                    }
                    
                    case OP_PRINT_WITH_LINE: {
                        Value line_val   = std::move(stack.back()); stack.pop_back();
                        Value content_val = std::move(stack.back()); stack.pop_back();
                        int line = static_cast<int>(value_to_ll(line_val));
                    
                        // 【安全优化】只序列化一次，这个是必须保留的，没有流式buffer风险
                        std::string text = c_value_to_stdstring(content_val);
                        std::cout << text << '\n';
                        std::cout.flush();
                    
                        int scope_id = current_scope ? current_scope->id : 0;
                        print_lines[scope_id][line] = std::move(text);
                    
                        free_value(&line_val);
                        free_value(&content_val);
                        break;
                    }
                    
                    case OP_POP: {
                        if (!stack.empty()) {
                            free_value(&stack.back());
                            stack.pop_back();
                        }
                        break;
                    }
                    case OP_HALT:
                        return true;
                    
                    // ---- 控制流跳转 ----
                    case OP_JMP: {
                        int addr = read_int_operand(*bc, pc);
                        pc = addr;
                        break;
                    }
                    case OP_JMP_IF_FALSE: {
                        int addr = read_int_operand(*bc, pc);
                        Value cond = stack.back(); stack.pop_back();
                        if (!value_to_bool(cond)) {
                            pc = addr;
                        }
                        free_value(&cond);
                        break;
                    }
                    case OP_JMP_IF_TRUE: {
                        int addr = read_int_operand(*bc, pc);
                        Value cond = stack.back(); stack.pop_back();
                        if (value_to_bool(cond)) {
                            pc = addr;
                        }
                        free_value(&cond);
                        break;
                    }
                    case OP_NOT: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        int res = !value_to_bool(v);
                        free_value(&v);
                        stack.push_back(make_int64((int64_t)res));
                        break;
                    }
                    case OP_JMP_IF_NOT_NULL: {
                        int addr = read_int_operand(*bc, pc);
                        Value v = std::move(stack.back()); stack.pop_back();
                        bool not_null = (v.type != VAL_NULL);
                        free_value(&v);
                        if (not_null) pc = addr;
                        break;
                    }

                    
                    case OP_BIT_NOT: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        mpz_t z, r;
                        mpz_init(z); mpz_init(r);
                        value_to_mpz(v, z);
                        mpz_com(r, z);
                        free_value(&v);
                        stack.push_back(value_from_mpz_result(r));
                        mpz_clear(z); mpz_clear(r);
                        break;
                    }
                    case OP_TO_RAD: {
                        Value v = std::move(stack.back()); stack.pop_back();

                        mpf_t num_mpf, rad_mpf, pi_mpf;
                        mpf_init(num_mpf);
                        mpf_init(rad_mpf);
                        mpf_init(pi_mpf);
                        // 与解释器同源：π/180 常量
                        mpf_set_d(pi_mpf, 0.017453292519943295769236907684886);

                        if (v.type == VAL_INT || v.type == VAL_INT64) {
                            mpf_set_int64(num_mpf, value_to_ll(v));
                        } else if (v.type == VAL_FLOAT) {
                            mpf_set_d(num_mpf, value_to_double(v));
                        } else {
                            free_value(&v);
                            mpf_clear(num_mpf); mpf_clear(rad_mpf); mpf_clear(pi_mpf);
                            kr_error("度数操作数必须为数值类型");
                        }
                        free_value(&v);

                        mpf_mul(rad_mpf, num_mpf, pi_mpf);
                        stack.push_back(make_float(rad_mpf));
                        mpf_clear(num_mpf); mpf_clear(rad_mpf); mpf_clear(pi_mpf);
                        break;
                    }
                    case OP_FACT: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        if (v.type != VAL_INT && v.type != VAL_INT64) {
                            free_value(&v);
                            kr_error("阶乘只支持整数");
                        }
                        mpz_t n_mpz;
                        mpz_init(n_mpz);
                        if (v.type == VAL_INT64) mpz_set_int64(n_mpz, v.int64_val);
                        else                     mpz_set(n_mpz, *v.big_int);
                        free_value(&v);

                        if (mpz_sgn(n_mpz) < 0) {
                            mpz_clear(n_mpz);
                            kr_error("阶乘只支持非负整数");
                        }
                        if (!mpz_fits_ulong_p(n_mpz)) {
                            mpz_clear(n_mpz);
                            kr_error("阶乘参数过大（超出 unsigned long）");
                        }
                        unsigned long n = mpz_get_ui(n_mpz);
                        mpz_clear(n_mpz);

                        mpz_t result_mpz;
                        mpz_init(result_mpz);
                        mpz_fac_ui(result_mpz, n);
                        stack.push_back(value_from_mpz_result(result_mpz));
                        mpz_clear(result_mpz);
                        break;
                    }
                    case OP_DFACT: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        if (v.type != VAL_INT && v.type != VAL_INT64) {
                            free_value(&v);
                            kr_error("双阶乘只支持整数");
                        }
                        mpz_t n_mpz;
                        mpz_init(n_mpz);
                        if (v.type == VAL_INT64) mpz_set_int64(n_mpz, v.int64_val);
                        else                     mpz_set(n_mpz, *v.big_int);
                        free_value(&v);

                        if (mpz_sgn(n_mpz) < 0) {
                            mpz_clear(n_mpz);
                            kr_error("双阶乘只支持非负整数");
                        }
                        if (!mpz_fits_ulong_p(n_mpz)) {
                            mpz_clear(n_mpz);
                            kr_error("双阶乘参数过大（超出 unsigned long）");
                        }
                        unsigned long n = mpz_get_ui(n_mpz);
                        mpz_clear(n_mpz);

                        mpz_t result_mpz;
                        mpz_init_set_ui(result_mpz, 1);
                        // 注意：unsigned long 溢出回绕，与解释器保持一致
                        for (unsigned long i = n; i >= 2; i -= 2)
                            mpz_mul_ui(result_mpz, result_mpz, i);

                        stack.push_back(value_from_mpz_result(result_mpz));
                        mpz_clear(result_mpz);
                        break;
                    }
                    case OP_SWAP_ASSIGN: {
                        int l_id    = read_int_operand(*bc, pc);
                        int r_id    = read_int_operand(*bc, pc);
                        int is_glob = bc->code[pc++];
                        ASTNode* L  = bc->aux_ast_refs[l_id];
                        ASTNode* R  = bc->aux_ast_refs[r_id];
                    
                        Scope* old_scope = nullptr;
                        if (is_glob) {
                            old_scope = current_scope;
                            current_scope = get_global_scope();
                        }
                    
                        Value* left_ptr  = vm_get_mutable_ptr(L);
                        Value* right_ptr = vm_get_mutable_ptr(R);
                    
                        if (!left_ptr || !right_ptr) {
                            if (old_scope) current_scope = old_scope;
                            kr_error("交换赋值：左值不可寻址");
                        }
                        if (left_ptr != right_ptr) {
                            Value temp = copy_value(*left_ptr);
                            free_value(left_ptr);
                            *left_ptr  = copy_value(*right_ptr);
                            free_value(right_ptr);
                            *right_ptr = temp;
                        }

                        if (old_scope) current_scope = old_scope;
                        break;
                    }

                    case OP_NEW_ARRAY: {
                        int n = read_int_operand(*bc, pc);
                        Value* elems = (Value*)malloc((size_t)n * sizeof(Value));
                        // 栈顶是 elems[n-1]，从后往前取
                        for (int i = n - 1; i >= 0; --i) {
                            elems[i] = std::move(stack.back());
                            stack.pop_back();
                        }
                        Value arr = make_array(elems, n);
                        // 转移所有权后释放临时槽（堆数据已在 make_array 中深拷贝）
                        for (int i = 0; i < n; ++i) free_value(&elems[i]);
                        free(elems);
                        stack.push_back(arr);
                        break;
                    }
                    case OP_NEW_OBJECT: {
                        int n = read_int_operand(*bc, pc);
                        ObjectEntry* entries = (ObjectEntry*)malloc((size_t)n * sizeof(ObjectEntry));
                        // 栈顺序：[k0, v0, k1, v1, ..., kn-1, vn-1]，栈顶是 vn-1
                        for (int i = n - 1; i >= 0; --i) {
                            Value val = std::move(stack.back()); stack.pop_back();
                            Value key = std::move(stack.back()); stack.pop_back();
                            char* kstr = value_to_string(key);
                            free_value(&key);
                            entries[i].key   = kstr;
                            entries[i].value = val;
                        }
                        Value obj = make_object(entries, n);
                        // 与解释器一致：make_object 深拷贝，这里释放临时条目
                        for (int i = 0; i < n; ++i) {
                            free(entries[i].key);
                            free_value(&entries[i].value);
                        }
                        free(entries);
                        stack.push_back(obj);
                        break;
                    }

                    case OP_DUP2: {
                        if (stack.size() < 2) kr_error("DUP2: 栈元素不足");
                        Value a = stack[stack.size() - 2];
                        Value b = stack[stack.size() - 1];
                        stack.push_back(copy_value(a));
                        stack.push_back(copy_value(b));
                        break;
                    }

                    case OP_OBJ_GET: {
                        int key_idx    = read_int_operand(*bc, pc);
                        int is_optional = bc->code[pc++];
                        const char* key = bc->constants[key_idx].str_val;

                        Value obj = std::move(stack.back()); stack.pop_back();

                        // ---- 1. null 处理 ----
                        if (obj.type == VAL_NULL) {
                            free_value(&obj);
                            if (is_optional) { stack.push_back(make_null()); break; }
                            kr_error("无法访问属性 '%s' 在 null 上", key);
                        }

                        // ---- 2. 数组/字符串的 .län ----
                        if (obj.type == VAL_ARRAY && strcmp(key, "län") == 0) {
                            long long n = obj.arr_val.length;
                            free_value(&obj);
                            stack.push_back(make_int64(n));
                            break;
                        }
                        if (obj.type == VAL_STRING && strcmp(key, "län") == 0) {
                            long long n = (long long)utf8_length(std::string(obj.str_val, obj.str_len));
                            free_value(&obj);
                            stack.push_back(make_int64(n));
                            break;
                        }

                        // ---- 3. 普通对象属性查找 ----
                        if (obj.type == VAL_OBJECT) {
                            Value result = make_null();
                            bool found = false;
                            for (int i = 0; i < obj.obj_val.count; ++i) {
                                if (strcmp(obj.obj_val.entries[i].key, key) == 0) {
                                    result = copy_value(obj.obj_val.entries[i].value);
                                    found = true;
                                    break;
                                }
                            }
                        
                            // 如果查询的key是 "län" 并且没有找到该属性
                            if (strcmp(key, "län") == 0 && !found) {
                                // 返回对象属性条目总数
                                result = make_int64(obj.obj_val.count);
                                found = true; // 标记找到，不再触发未找到警告
                            }
                        
                            // 只有非län键找不到的时候才打印警告
                            if (!found && !is_optional) {
                                kr_warn("在对象中未找到键 '%s'，返回 null", key);
                            }
                            free_value(&obj);
                            stack.push_back(result);
                            break;
                        }

                        // ---- 4. 其它类型 ----
                        free_value(&obj);
                        if (is_optional) { stack.push_back(make_null()); break; }
                        kr_error("属性 '%s' 不存在或不可访问", key);
                    }

                    case OP_OBJ_SET: {
                        int key_idx = read_int_operand(*bc, pc);
                        const char* key = bc->constants[key_idx].str_val;
                    
                        Value val = std::move(stack.back()); stack.pop_back();
                        Value obj = std::move(stack.back()); stack.pop_back();
                    
                        if (obj.type != VAL_OBJECT) {
                            free_value(&obj); free_value(&val);
                            kr_error("尝试为非对象设置属性 '%s'", key);
                        }
                    
                        // 查找已存在的键
                        int found = -1;
                        for (int i = 0; i < obj.obj_val.count; ++i) {
                            if (strcmp(obj.obj_val.entries[i].key, key) == 0) {
                                found = i; break;
                            }
                        }
                    
                        if (found >= 0) {
                            free_value(&obj.obj_val.entries[found].value);
                            obj.obj_val.entries[found].value = val;   // 所有权转移
                        } else {
                            // 键：用 malloc+memcpy 代替 realloc，避免与共享 entries 的
                            // 其它 Value 发生指针分歧
                            const int old_count = obj.obj_val.count;
                            ObjectEntry* new_entries = (ObjectEntry*)malloc(
                                (size_t)(old_count + 1) * sizeof(ObjectEntry));
                            for (int i = 0; i < old_count; ++i)
                                new_entries[i] = obj.obj_val.entries[i];   // 移动所有权
                            new_entries[old_count].key   = strdup(key);
                            new_entries[old_count].value = val;
                            free(obj.obj_val.entries);
                            obj.obj_val.entries = new_entries;
                            obj.obj_val.count   = old_count + 1;
                        }
                    
                        // 关键：把修改后的对象压回栈，供调用方写回原变量
                        stack.push_back(obj);
                        break;
                    }

                    case OP_ARRAY_SET: {
                        // 栈上依次是 [container, index, value]（value 在栈顶）
                        Value v   = std::move(stack.back()); stack.pop_back();
                        Value idx = std::move(stack.back()); stack.pop_back();
                        Value c   = std::move(stack.back()); stack.pop_back();
                    
                        bool consumed = false;
                    
                        if (c.type == VAL_ARRAY) {
                            long long i = value_to_ll(idx);
                            if (i < 0 || i >= c.arr_val.length) {
                                kr_warn("数组索引 %lld 越界（长度 %lld），赋值被忽略",
                                        i, c.arr_val.length);
                            } else {
                                free_value(&c.arr_val.elements[i]);
                                c.arr_val.elements[i] = v;
                                consumed = true;
                            }
                        } else if (c.type == VAL_OBJECT) {
                            char* kstr = value_to_string(idx);
                            int found = -1;
                            for (int i = 0; i < c.obj_val.count; ++i) {
                                if (strcmp(c.obj_val.entries[i].key, kstr) == 0) {
                                    found = i; break;
                                }
                            }
                            if (found >= 0) {
                                free_value(&c.obj_val.entries[found].value);
                                c.obj_val.entries[found].value = v;
                            } else {
                                // 键：同样用 malloc+memcpy 代替 realloc
                                const int old_count = c.obj_val.count;
                                ObjectEntry* new_entries = (ObjectEntry*)malloc(
                                    (size_t)(old_count + 1) * sizeof(ObjectEntry));
                                for (int i = 0; i < old_count; ++i)
                                    new_entries[i] = c.obj_val.entries[i];
                                new_entries[old_count].key   = strdup(kstr);
                                new_entries[old_count].value = v;
                                free(c.obj_val.entries);
                                c.obj_val.entries = new_entries;
                                c.obj_val.count   = old_count + 1;
                            }
                            consumed = true;
                            free(kstr);
                        } else {
                            free_value(&c); free_value(&idx); free_value(&v);
                            kr_error("赋值目标既不是数组也不是对象");
                        }
                    
                        free_value(&idx);
                        if (!consumed) free_value(&v);
                    
                        // 关键：把修改后的容器压回栈，供调用方写回原变量
                        stack.push_back(c);
                        break;
                    }

                    // ---- 栈操作 ----
                    case OP_DUP: {
                        Value v = stack.back();
                        stack.push_back(copy_value(v));
                        break;
                    }
                    case OP_SWAP: {
                        if (stack.size() < 2) kr_error("SWAP: 栈元素不足");
                        Value a = stack[stack.size()-2];
                        Value b = stack[stack.size()-1];
                        stack[stack.size()-2] = b;
                        stack[stack.size()-1] = a;
                        break;
                    }

                    // ---- 集合操作 ----
                    case OP_ARRAY_LEN: {
                        Value v = stack.back(); stack.pop_back();
                        long long len;
                        if (v.type == VAL_ARRAY) {
                            len = v.arr_val.length;
                        } else if (v.type == VAL_STRING) {
                            len = (long long)utf8_length(v.str_val);
                        } else {
                            kr_error("len 仅支持数组或字符串");
                        }
                        free_value(&v);
                        stack.push_back(make_int64(len));
                        break;
                    }
                    case OP_ARRAY_GET: {
                        // 栈上： [集合, 索引]（索引在栈顶）
                        Value idx_val = stack.back(); stack.pop_back();
                        Value coll = stack.back(); stack.pop_back();
                        long long idx = value_to_ll(idx_val);
                        free_value(&idx_val);
                        Value elem;
                        if (coll.type == VAL_ARRAY) {
                            if (idx < 0 || idx >= coll.arr_val.length) {
                                kr_error("数组索引越界");
                            }
                            elem = copy_value(coll.arr_val.elements[idx]);
                        } else if (coll.type == VAL_STRING) {
                            std::string s = coll.str_val;
                            size_t pos = 0;
                            long long count = 0;
                            while (pos < s.size() && count < idx) {
                                size_t len;
                                utf8_char_width(&s[pos], &len);
                                pos += len;
                                count++;
                            }
                            if (count != idx || pos >= s.size()) {
                                kr_error("字符串索引越界");
                            }
                            size_t len;
                            utf8_char_width(&s[pos], &len);
                            std::string ch = s.substr(pos, len);
                            elem = make_string(ch.c_str());
                        } else {
                            kr_error("不支持的类型取值");
                        }
                        free_value(&coll);
                        stack.push_back(elem);
                        break;
                    }
                    case OP_GET_VAR: {
                        int idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[idx].str_val;
                        Variable* var = lookup_var_fast(name);
                        if (!var) kr_error("未定义变量 '%s'", name);
                        var = resolve_alias(var);
                        if (g_warnings_enabled) {
                            var->is_read = true;
                        }
                        vm_push_var_value(var, /*expand_stdwert=*/true);
                        break;
                    }
                    case OP_GET_VAR_RAW: {
                        int idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[idx].str_val;
                        Variable* var = lookup_var_fast(name);
                        if (!var) kr_error("未定义变量 '%s'", name);
                        var = resolve_alias(var);
                        // RAW 语义：不展开 __stdwert，但惰性变量仍需正常求值
                        vm_push_var_value(var, /*expand_stdwert=*/false);
                        break;
                    }
                    case OP_STORE: {
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                        Value val = stack.back(); stack.pop_back();
                        Variable* var = lookup_var_fast(name);
                        if (var && !var->is_const && !var->is_lazy) {
                            free_value(&var->value);
                            var->value = val;
                        } else {
                            set_var(name, val);   // 回退到原逻辑（新声明 / 常量错误等）
                        }
                        break;
                    }
                    case OP_RANGE: {
                        // 栈上依次是：step, end, start（因为编译顺序是先 start, end, step）
                        Value step_val = stack.back(); stack.pop_back();
                        Value end_val   = stack.back(); stack.pop_back();
                        Value start_val = stack.back(); stack.pop_back();
                    
                        long long start = value_to_ll(start_val);
                        long long end   = value_to_ll(end_val);
                        long long step  = value_to_ll(step_val);
                    
                        free_value(&start_val);
                        free_value(&end_val);
                        free_value(&step_val);
                    
                        if (step == 0) kr_error("步长不能为 0");
                    
                        std::vector<Value> elems;
                        if (step > 0) {
                            for (long long v = start; v <= end; v += step) {
                                elems.push_back(make_int64(v));
                            }
                        } else {
                            for (long long v = start; v >= end; v += step) {
                                elems.push_back(make_int64(v));
                            }
                        }
                    
                        Value arr = make_array(elems.data(), (int)elems.size());
                        // 释放临时元素（make_array 已复制）
                        for (auto& e : elems) free_value(&e);
                        stack.push_back(arr);
                        break;
                    }
                    case OP_PUSH_NULL:
                        stack.push_back(make_null());
                        break;
                    case OP_DECLARE_VAR: {
                        int name_idx = read_int_operand(*bc, pc);
                        int is_const  = bc->code[pc++];
                        int is_global = bc->code[pc++];
                        const char* name = bc->constants[name_idx].str_val;
                        Value val = stack.back();
                        stack.pop_back();
                    
                        Scope* target = is_global ? original_global_scope : current_scope;
                        if (!target) {
                            if (!is_global) {
                                push_scope();
                                target = current_scope;
                            } else {
                                kr_error("未初始化的全局范围");
                            }
                        }
                        declare_var_in_scope(target, name, is_const != 0, val);
                        break;
                    }
                    case OP_INC_VAR:
                    case OP_DEC_VAR:
                    case OP_POST_INC_VAR:
                    case OP_POST_DEC_VAR: {
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;

                        Variable* var = find_mutable_var(name);
                        if (!var) kr_error("未定义变量 '%s'", name);
                        if (var->is_const) kr_error("不能修改常量 '%s'", name);

                        const bool is_inc  = (op == OP_INC_VAR || op == OP_POST_INC_VAR);
                        const bool is_post = (op == OP_POST_INC_VAR || op == OP_POST_DEC_VAR);

                        // ---------- 快速路径：就地改 int64，绝不触碰 GMP ----------
                        if (var->value.type == VAL_INT64) {
                            const int64_t old = var->value.int64_val;
                            if (is_inc) {
                                if (old != INT64_MAX) {
                                    const int64_t nv = old + 1;
                                    var->value.int64_val = nv;
                                    var->is_read = true;
                                    stack.push_back(make_int64(is_post ? old : nv));
                                    break;
                                }
                            } else {
                                if (old != INT64_MIN) {
                                    const int64_t nv = old - 1;
                                    var->value.int64_val = nv;
                                    var->is_read = true;
                                    stack.push_back(make_int64(is_post ? old : nv));
                                    break;
                                }
                            }
                            // 溢出 → 落到慢速路径，让 inc_value/dec_value 提升到 GMP
                        }

                        // ---------- 慢速路径：任意数值类型 ----------
                        Value* ptr = &var->value;
                        if (is_post) {
                            Value old_copy = copy_value(*ptr);
                            if (is_inc) inc_value(ptr);
                            else        dec_value(ptr);
                            stack.push_back(old_copy);
                        } else {
                            if (is_inc) inc_value(ptr);
                            else        dec_value(ptr);
                            stack.push_back(copy_value(*ptr));
                        }
                        var->is_read = true;
                        break;
                    }
                    case OP_INC_DEC_AST: {
                        int     ast_id = read_int_operand(*bc, pc);
                        uint8_t mode   = bc->code[pc++];
                        ASTNode* lv    = bc->aux_ast_refs[ast_id];
                    
                        const bool is_inc  = (mode == 0 || mode == 2);
                        const bool is_post = (mode >= 2);
                    
                        // 用 VM 版左值解析器，绝不再碰解释器的 eval_expr
                        Value* ptr = vm_get_mutable_ptr(lv);
                        if (!ptr) kr_error("++/-- 左值不可寻址");
                    
                        // ---------- int64 快速路径（同 OP_INC_VAR） ----------
                        if (ptr->type == VAL_INT64) {
                            const int64_t old = ptr->int64_val;
                            const bool overflow = is_inc ? (old == INT64_MAX)
                                                         : (old == INT64_MIN);
                            if (!overflow) {
                                const int64_t nv = is_inc ? (old + 1) : (old - 1);
                                ptr->int64_val = nv;
                                stack.push_back(make_int64(is_post ? old : nv));
                                break;
                            }
                            // 溢出 → 落到慢速路径，由 inc_value/dec_value 提升到 GMP
                        }
                    
                        // ---------- 慢速路径：任意数值类型 ----------
                        if (is_post) {
                            Value old = copy_value(*ptr);
                            if (is_inc) inc_value(ptr);
                            else        dec_value(ptr);
                            stack.push_back(old);
                        } else {
                            if (is_inc) inc_value(ptr);
                            else        dec_value(ptr);
                            stack.push_back(copy_value(*ptr));
                        }
                        break;
                    }
                    case OP_NATIVE_FOR: {
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                        int64_t start = read_int64_operand(*bc, pc);
                        int64_t end   = read_int64_operand(*bc, pc);
                        int64_t step  = read_int64_operand(*bc, pc);
                        uint8_t cmp_code     = bc->code[pc++];
                        uint8_t body_reads   = bc->code[pc++];
                        uint8_t is_new_decl  = bc->code[pc++];
                        uint8_t is_const     = bc->code[pc++];
                        uint8_t is_global    = bc->code[pc++];
                        int body_size = read_int_operand(*bc, pc);
                        size_t body_start = pc;
                        size_t body_end   = pc + body_size;
                    
                        // 定位或声明循环变量
                        Variable* var = find_mutable_var(name);
                        if (!var && is_new_decl) {
                            Scope* target = is_global ? original_global_scope : current_scope;
                            if (!target) kr_error("OP_NATIVE_FOR: 作用域未初始化");
                            declare_var_in_scope(target, name, is_const != 0, make_int64(start));
                            var = find_mutable_var(name);
                        }
                        if (!var) kr_error("OP_NATIVE_FOR: 变量 '%s' 未定义", name);
                        if (var->is_const) kr_error("OP_NATIVE_FOR: 变量 '%s' 是常量", name);
                    
                        // 保证 value 是 int64 槽位
                        if (var->value.type != VAL_INT64) {
                            free_value(&var->value);
                            var->value = make_int64(start);
                        }
                    
                        int64_t i = start;
                        while (true) {
                            bool keep_going;
                            switch (cmp_code) {
                                case 0: keep_going = (i <  end); break;
                                case 1: keep_going = (i <= end); break;
                                case 2: keep_going = (i >  end); break;
                                case 3: keep_going = (i >= end); break;
                                default: keep_going = false;
                            }
                            if (!keep_going) break;
                    
                            // 循环体不读变量时，连这个写入都省掉（空循环体就是纯 C++ 计数）
                            if (body_reads) var->value.int64_val = i;
                    
                            if (body_size > 0) {
                                pc = body_start;
                                if (run_until(body_end)) return true;   // 传播 HALT
                            }
                    
                            i += step;
                        }
                    
                        // 循环结束后把最终值写回
                        var->value.int64_val = i;
                        var->is_read = true;
                        pc = body_end;
                        break;
                    }
                    // ============================================================
                    // 函数定义：压入一个轻量函数值
                    // ============================================================
                    case OP_FUNC_DEF: {
                        int func_idx = read_int_operand(*bc, pc);
                        const CompiledFunction& cf = bc->functions[func_idx];
                        stack.push_back(make_compiled_func_value(cf, func_idx, /*is_rule=*/false));
                        break;
                    }

                    // ============================================================
                    // 函数调用：查名字 → 压帧 → 跳转
                    // ============================================================
                    case OP_CALL: {
                        int name_idx = read_int_operand(*bc, pc);
                        int argc     = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                    
                        Variable* var = find_mutable_var(name);
                        if (!var || var->value.type != VAL_FUNCTION)
                            kr_error("'%s' 不是函数(未定义)", name);
                    
                        // 优先走编译期绑定的 idx，跳过字符串哈希
                        int func_idx = var->value.func_val.compiled_idx;
                        if (func_idx < 0) {
                            const char* fname = var->value.func_val.name;
                            auto it = bc->func_by_name.find(fname ? fname : "");
                            if (it == bc->func_by_name.end())
                                kr_error("未编译函数 '%s'", fname ? fname : "<anonymous>");
                            func_idx = it->second;
                        }
                        const CompiledFunction& cf = bc->functions[func_idx];
                        if ((int)cf.params.size() != argc)
                            kr_error("函数 '%s' 参数个数不匹配", cf.name.c_str());
                    
                        const size_t stack_base = stack.size() - (size_t)argc;
                        push_scope();
                        for (int i = 0; i < argc; ++i) {
                            Value v = stack[stack_base + i];
                            declare_var_in_scope(current_scope, cf.params[i].c_str(), false, v);
                        }
                        stack.resize(stack_base);
                    
                        CompilerCallFrame frame;
                        frame.return_pc  = pc;
                        frame.stack_base = stack_base;
                        frame.func_idx   = func_idx;
                        frames.push_back(frame);
                        frame_rule_keys.push_back(std::string());
                        pc = cf.code_offset;
                        break;
                    }

                    // ============================================================
                    // 函数返回
                    // ============================================================
                    case OP_RETURN: {
                        Value ret = std::move(stack.back()); stack.pop_back();

                        // ---- 0. super call：丢弃父类构造体的返回值，替换为 null ----
                        //   与解释器 `result = make_null();` 完全一致。
                        if (!frames.empty() && frames.back().is_super_call) {
                            free_value(&ret);
                            ret = make_null();
                        }
                        
                        if (!frames.empty()) {
                            vm_check_return_type(*bc, frames.back().func_idx, ret);
                        }
                    
                        // ---- 1. try 挂起：如果当前处在 try 块内且有 finally，先跑 finally ----
                        if (!try_stack.empty() && try_stack.back().finally_pc != 0) {
                            TryFrame& tf = try_stack.back();
                            free_value(&tf.pending_value);
                            tf.pending_value  = ret;
                            tf.pending_action = PENDING_RETURN;
                            while (stack.size() > tf.stack_depth) {
                                free_value(&stack.back()); stack.pop_back();
                            }
                            pc = tf.finally_pc;
                            break;
                        }
                    
                        // ---- 2. 顶层（无帧）：直接停机 ----
                        if (frames.empty()) { stack.push_back(ret); return true; }
                    
                        // ---- 3. 正常返回 ----
                        CompilerCallFrame frame = frames.back();
                        frames.pop_back();
                        std::string rule_key;
                        if (!frame_rule_keys.empty()) {
                            rule_key = std::move(frame_rule_keys.back());
                            frame_rule_keys.pop_back();
                        }
                    
                        // 构造函数：用 dies 覆盖返回值
                        if (frame.is_ctor_call && current_scope) {
                            for (int i = 0; i < current_scope->var_count; ++i) {
                                if (strcmp(current_scope->vars[i].name, "dies") == 0) {
                                    free_value(&ret);
                                    ret = copy_value(current_scope->vars[i].value);
                                    break;
                                }
                            }
                        }
                    
                        // rule 缓存回写
                        if (!rule_key.empty()) {
                            auto it = g_rule_cache.find(rule_key);
                            if (it != g_rule_cache.end()) free_value(&it->second);
                            g_rule_cache[rule_key] = copy_value(ret);
                        }
                    
                        for (size_t i = frame.stack_base; i < stack.size(); ++i)
                            free_value(&stack[i]);
                        stack.resize(frame.stack_base);
                    
                        pop_scope();
                        pc = frame.return_pc;
                        stack.push_back(ret);
                        break;
                    }
                    case OP_CALL_DIRECT: {
                        int func_idx = read_int_operand(*bc, pc);
                        int argc     = read_int_operand(*bc, pc);
                        vm_do_direct_call(bc->functions[func_idx], func_idx, argc);
                        break;
                    }
                    case OP_ADD_TO_VAR:
                    case OP_SUB_TO_VAR:
                    case OP_MUL_TO_VAR:
                    case OP_DIV_TO_VAR:
                    case OP_MOD_TO_VAR: {
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                        Value rhs = stack.back(); stack.pop_back();

                        Variable* var = find_mutable_var(name);
                        if (!var) kr_error("未定义变量 '%s'", name);
                        if (var->is_const) kr_error("不能修改常量 '%s'", name);

                        // ---- 快速路径：双方都是原生 int64 ----
                        if (var->value.type == VAL_INT64 &&
                            rhs.type         == VAL_INT64) {
                            const int64_t a = var->value.int64_val;
                            const int64_t b = rhs.int64_val;
                            int64_t res = 0;
                            bool ok = false;
                            switch (op) {
                                case OP_ADD_TO_VAR:
                                    ok = !__builtin_add_overflow(a, b, &res); break;
                                case OP_SUB_TO_VAR:
                                    ok = !__builtin_sub_overflow(a, b, &res); break;
                                case OP_MUL_TO_VAR:
                                    ok = !__builtin_mul_overflow(a, b, &res); break;
                                case OP_DIV_TO_VAR:
                                    if (b == 0) { free_value(&rhs); kr_error("除零错误"); }
                                    if (a == INT64_MIN && b == -1) ok = false;
                                    else { res = a / b; ok = true; }
                                    break;
                                case OP_MOD_TO_VAR:
                                    if (b == 0) { free_value(&rhs); kr_error("取模零"); }
                                    res = a % b; ok = true;
                                    break;
                            }
                            if (ok) {
                                var->value.int64_val = res;
                                var->is_read = true;
                                free_value(&rhs);
                                break;
                            }
                            // 溢出 → 落到慢速路径，提升到 GMP
                        }

                        // ---- 慢速路径：任意数值类型 ----
                        Value result;
                        switch (op) {
                            case OP_ADD_TO_VAR: result = op_add(var->value, rhs); break;
                            case OP_SUB_TO_VAR: result = op_sub(var->value, rhs); break;
                            case OP_MUL_TO_VAR: result = op_mul(var->value, rhs); break;
                            case OP_DIV_TO_VAR: result = op_div(var->value, rhs); break;
                            case OP_MOD_TO_VAR: result = op_mod(var->value, rhs); break;
                            default:            result = make_null();            break;
                        }
                        free_value(&rhs);
                        free_value(&var->value);
                        var->value   = result;
                        var->is_read = true;
                        break;
                    }
                    case OP_ALIAS_DECL: {
                        int name_idx   = read_int_operand(*bc, pc);
                        int target_idx = read_int_operand(*bc, pc);
                        int is_global  = bc->code[pc++];
                        const char* alias_name  = bc->constants[name_idx].str_val;
                        const char* target_name = bc->constants[target_idx].str_val;

                        // 目标必须已存在
                        Variable* target_var = find_mutable_var(target_name);
                        if (!target_var) kr_error("别名目标 '%s' 未定义", target_name);

                        Scope* target_scope = is_global ? original_global_scope : current_scope;
                        if (!target_scope) kr_error("OP_ALIAS_DECL: 作用域未初始化");

                        // 重复声明检查
                        for (int i = 0; i < target_scope->var_count; ++i) {
                            if (strcmp(target_scope->vars[i].name, alias_name) == 0)
                                kr_error("变量 '%s' 已声明", alias_name);
                        }

                        // 与解释器同构：直接 realloc 一个新 Variable
                        target_scope->vars = (Variable*)realloc(
                            target_scope->vars,
                            (target_scope->var_count + 1) * sizeof(Variable));
                        Variable* var = &target_scope->vars[target_scope->var_count++];
                        var->name         = strdup(alias_name);
                        var->value        = make_null();   // 不使用
                        var->is_const     = false;
                        var->is_lazy      = false;
                        var->evaluated    = false;
                        var->init_expr    = NULL;
                        var->cached_value = make_null();
                        var->is_alias     = true;
                        var->alias_target = strdup(target_name);
                        break;
                    }

                    case OP_PUSH_SCOPE: {
                        push_scope();
                        break;
                    }

                    case OP_POP_SCOPE: {
                        pop_scope();
                        break;
                    }

                    case OP_ENTER_GLOBAL_SCOPE: {
                        saved_scope_stack.push_back(current_scope);
                        current_scope = original_global_scope;
                        break;
                    }

                    case OP_EXIT_GLOBAL_SCOPE: {
                        if (saved_scope_stack.empty())
                            kr_error("OP_EXIT_GLOBAL_SCOPE: 作用域栈下溢");
                        current_scope = saved_scope_stack.back();
                        saved_scope_stack.pop_back();
                        break;
                    }

                    case OP_THROW: {
                        Value exc = std::move(stack.back()); 
                        stack.pop_back();
                        
                        // 将值转为字符串并强制打印
                        char* c_msg = value_to_string(exc);
                        std::string msg_str(c_msg);
                        free(c_msg);
                        free_value(&exc);
                    
                        // 强制输出异常消息（即使全局警告未开启）
                        bool old_warn = g_warnings_enabled;
                        g_warnings_enabled = true;
                        kr_warn("%s", msg_str.c_str());
                        g_warnings_enabled = old_warn;
                        
                        // 构造异常，标记为"已打印"
                        throw KRError(msg_str, true); 
                    }

                    case OP_MULTI_ASSIGN: {
                        const int count = read_int_operand(*bc, pc);
                        std::vector<int> name_idx(count);
                        for (int i = 0; i < count; ++i)
                            name_idx[i] = read_int_operand(*bc, pc);
                    
                        // 先按原顺序把值弹到临时数组（保持 left_names[0]..left_names[n-1] 的对应）
                        std::vector<Value> vals(count);
                        for (int i = count - 1; i >= 0; --i) {
                            vals[i] = std::move(stack.back());
                            stack.pop_back();
                        }
                    
                        for (int i = 0; i < count; ++i) {
                            const char* name = bc->constants[name_idx[i]].str_val;
                            Value val = vals[i];
                        
                            // ---- 静态属性名（含 "::"）：沿作用域链查找 ----
                            if (strstr(name, "::") != nullptr) {
                                Variable* var = find_mutable_var(name);
                                if (!var) {
                                    free_value(&val);
                                    kr_error("静态属性 '%s' 未声明（类定义缺失？）", name);
                                }
                                if (var->is_const) { free_value(&val); kr_error("常量 '%s' 不能重新赋值", name); }
                                if (var->is_lazy)  { free_value(&val); kr_error("惰性变量 '%s' 不能赋值", name); }
                                free_value(&var->value);
                                var->value = val;
                                continue;
                            }
                        
                            // ---- 普通变量：仅在当前作用域查找（保持与解释器一致） ----
                            int idx = get_var_index_in_scope(current_scope, name);
                            if (idx >= 0) {
                                Variable* var = &current_scope->vars[idx];
                                if (var->is_const) { free_value(&val); kr_error("常量 '%s' 不能重新赋值", name); }
                                if (var->is_lazy)  { free_value(&val); kr_error("惰性变量 '%s' 不能赋值", name); }
                                free_value(&var->value);
                                var->value = val;
                            } else {
                                declare_var_in_scope(current_scope, name, false, val);
                                if (current_scope == original_global_scope) {
                                    g_var_decl_pos[name] = {g_last_error_line, g_last_error_col};
                                    int nidx = get_var_index_in_scope(current_scope, name);
                                    if (nidx >= 0) current_scope->vars[nidx].is_read = false;
                                }
                            }
                        }
                        break;
                    }

                    case OP_DESTRUCTURE_ASSIGN: {
                        const int count    = read_int_operand(*bc, pc);
                        const int rest_idx = read_int_operand(*bc, pc);
                        const int is_const = bc->code[pc++];
                        std::vector<int> name_idx(count);
                        for (int i = 0; i < count; ++i)
                            name_idx[i] = read_int_operand(*bc, pc);
                    
                        const char* rest_name =
                            (rest_idx >= 0) ? bc->constants[rest_idx].str_val : nullptr;
                    
                        Value val = std::move(stack.back());
                        stack.pop_back();
                    
                        // 与解释器 NODE_DESTRUCTURE_ASSIGN 里的 declare_or_assign_with_pos 等价
                        auto declare_or_assign = [&](const char* name, Value elem) {
                            // ---- 静态属性 ----
                            if (strstr(name, "::") != nullptr) {
                                Variable* var = find_mutable_var(name);
                                if (!var) { free_value(&elem); kr_error("静态属性 '%s' 未声明", name); }
                                if (var->is_const) { free_value(&elem); kr_error("常量 '%s' 不能重新赋值", name); }
                                if (var->is_lazy)  { free_value(&elem); kr_error("惰性变量 '%s' 不能赋值", name); }
                                free_value(&var->value);
                                var->value = elem;
                                return;
                            }
                        
                            // ---- 普通变量 ----
                            int idx = get_var_index_in_scope(current_scope, name);
                            if (idx >= 0) {
                                Variable* var = &current_scope->vars[idx];
                                if (var->is_const) { free_value(&elem); kr_error("常量 '%s' 不能重新赋值", name); }
                                if (var->is_lazy)  { free_value(&elem); kr_error("惰性变量 '%s' 不能赋值", name); }
                                free_value(&var->value);
                                var->value = elem;
                            } else {
                                declare_var_in_scope(current_scope, name, is_const != 0, elem);
                                if (current_scope == original_global_scope) {
                                    g_var_decl_pos[name] = {g_last_error_line, g_last_error_col};
                                    int nidx = get_var_index_in_scope(current_scope, name);
                                    if (nidx >= 0) current_scope->vars[nidx].is_read = false;
                                }
                            }
                        };
                    
                        if (val.type == VAL_ARRAY) {
                            if (val.arr_val.length != count) {
                                long long n = val.arr_val.length;
                                free_value(&val);
                                kr_error("解构赋值：数组长度 %lld 与变量数 %d 不匹配", n, count);
                            }
                            for (int i = 0; i < count; ++i) {
                                Value elem = copy_value(val.arr_val.elements[i]);
                                declare_or_assign(bc->constants[name_idx[i]].str_val, elem);
                            }
                        } else if (val.type == VAL_OBJECT) {
                            // 1. 命名属性
                            for (int i = 0; i < count; ++i) {
                                const char* key = bc->constants[name_idx[i]].str_val;
                                bool found = false;
                                for (int j = 0; j < val.obj_val.count; ++j) {
                                    if (strcmp(val.obj_val.entries[j].key, key) == 0) {
                                        Value elem = copy_value(val.obj_val.entries[j].value);
                                        declare_or_assign(key, elem);
                                        found = true;
                                        break;
                                    }
                                }
                                if (!found) {
                                    free_value(&val);
                                    kr_error("解构赋值：对象中未找到键 '%s'", key);
                                }
                            }
                    
                            // 2. rest
                            if (rest_name) {
                                ObjectEntry* rest_entries = nullptr;
                                int rest_count = 0;
                                for (int j = 0; j < val.obj_val.count; ++j) {
                                    const char* key = val.obj_val.entries[j].key;
                                    bool matched = false;
                                    for (int i = 0; i < count; ++i) {
                                        if (strcmp(bc->constants[name_idx[i]].str_val, key) == 0) {
                                            matched = true;
                                            break;
                                        }
                                    }
                                    if (!matched) {
                                        rest_entries = (ObjectEntry*)realloc(
                                            rest_entries, (rest_count + 1) * sizeof(ObjectEntry));
                                        rest_entries[rest_count].key   = strdup(key);
                                        rest_entries[rest_count].value = copy_value(val.obj_val.entries[j].value);
                                        rest_count++;
                                    }
                                }
                                Value rest_obj = make_object(rest_entries, rest_count);
                                for (int i = 0; i < rest_count; ++i) {
                                    free(rest_entries[i].key);
                                    free_value(&rest_entries[i].value);
                                }
                                free(rest_entries);
                                declare_or_assign(rest_name, rest_obj);
                            }
                        } else {
                            int t = val.type;
                            free_value(&val);
                            kr_error("解构赋值要求右侧为数组或对象，实际类型 %d", t);
                        }
                    
                        free_value(&val);
                        break;
                    }
                    case OP_SICHER_FAIL: {
                        Value msg = std::move(stack.back()); stack.pop_back();
                        char* s = value_to_string(msg);
                        fprintf(stderr, "%s\n", s);
                        free(s); free_value(&msg);
                        std::exit(1);
                    }
                    case OP_ITER_PREP: {
                        Value coll = std::move(stack.back()); stack.pop_back();
                    
                        // 字符串 → UTF-8 字符数组（与解释器 NODE_FOREACH 中的切分逻辑一致）
                        if (coll.type == VAL_STRING) {
                            std::string s(coll.str_val ? coll.str_val : "", (size_t)coll.str_len);
                            std::vector<Value> chars;
                            chars.reserve(s.size());
                    
                            size_t i = 0;
                            while (i < s.size()) {
                                unsigned char c = static_cast<unsigned char>(s[i]);
                                size_t len;
                                if (c < 0x80)                len = 1;
                                else if ((c & 0xE0) == 0xC0) len = 2;
                                else if ((c & 0xF0) == 0xE0) len = 3;
                                else if ((c & 0xF8) == 0xF0) len = 4;
                                else                         len = 1;         // 无效字节，单字节收尾
                                if (i + len > s.size()) len = s.size() - i;   // 截断保护
                    
                                chars.push_back(make_string_len(s.data() + i, len));
                                i += len;
                            }
                    
                            Value* elems = chars.empty()
                                ? nullptr
                                : (Value*)malloc(chars.size() * sizeof(Value));
                            for (size_t j = 0; j < chars.size(); ++j) elems[j] = chars[j];
                    
                            Value arr = make_array(elems, (int)chars.size());
                            if (elems) std::free(elems);
                            free_value(&coll);
                    
                            stack.push_back(arr);
                        } else {
                            stack.push_back(coll);
                        }
                    
                        stack.push_back(make_int64(0));   // iter = 0
                        break;
                    }
                    case OP_ITER_NEXT: {
                        int done_addr = read_int_operand(*bc, pc);
                        Value idx = stack.back();
                        Value& coll = stack[stack.size() - 2];
                        long long i = value_to_ll(idx);
                        long long len = 0;
                        if (coll.type == VAL_ARRAY) len = coll.arr_val.length;
                        else if (coll.type == VAL_OBJECT) len = coll.obj_val.count;
                        else kr_error("推导式：集合必须是数组或对象");
                        if (i >= len) { pc = done_addr; break; }
                        Value key, val;
                        if (coll.type == VAL_ARRAY) {
                            key = make_int64(i);
                            val = copy_value(coll.arr_val.elements[i]);
                        } else {
                            key = make_string(coll.obj_val.entries[i].key);
                            val = copy_value(coll.obj_val.entries[i].value);
                        }
                        stack.back() = make_int64(i + 1);   // 递增 iter
                        stack.push_back(key);
                        stack.push_back(val);
                        break;
                    }
                    case OP_ITER_BIND: {
                        int var_idx = read_int_operand(*bc, pc);
                        int vv_idx  = read_int_operand(*bc, pc);
                    
                        Value value = std::move(stack.back()); stack.pop_back();
                        Value key   = std::move(stack.back()); stack.pop_back();
                    
                        const char* vn = bc->constants[var_idx].str_val;
                    
                        if (vv_idx >= 0) {
                            // 双变量模式：key → var, value → value_var
                            //   数组/字符串：key 是索引(int64)，value 是元素
                            //   对象：key 是字段名(string)，value 是字段值
                            set_var(vn, key);
                            set_var(bc->constants[vv_idx].str_val, value);
                        } else {
                            // 单变量模式：把 value 绑到 var；丢弃 key
                            //   数组/字符串：元素 / 字符
                            //   对象：字段值（与解释器“单变量遍历对象取 value”一致）
                            free_value(&key);
                            set_var(vn, value);
                        }
                        break;
                    }
                    case OP_OBJ_SET_DYN: {
                        // 栈：[obj, key, value]
                        Value v   = std::move(stack.back()); stack.pop_back();
                        Value k   = std::move(stack.back()); stack.pop_back();
                        Value obj = std::move(stack.back()); stack.pop_back();
                        if (obj.type != VAL_OBJECT) {
                            free_value(&obj); free_value(&k); free_value(&v);
                            kr_error("对象推导式：累加器不是对象");
                        }
                        char* ks = value_to_string(k); free_value(&k);
                        int found = -1;
                        for (int i = 0; i < obj.obj_val.count; ++i)
                            if (strcmp(obj.obj_val.entries[i].key, ks) == 0) { found = i; break; }
                        if (found >= 0) {
                            free_value(&obj.obj_val.entries[found].value);
                            obj.obj_val.entries[found].value = v;
                        } else {
                            obj.obj_val.count++;
                            obj.obj_val.entries = (ObjectEntry*)realloc(obj.obj_val.entries,
                                obj.obj_val.count * sizeof(ObjectEntry));
                            obj.obj_val.entries[obj.obj_val.count - 1].key   = strdup(ks);
                            obj.obj_val.entries[obj.obj_val.count - 1].value = v;
                        }
                        free(ks);
                        stack.push_back(obj);
                        break;
                    }
                    case OP_ARRAY_PUSH: {
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                        Value v = std::move(stack.back()); stack.pop_back();
                    
                        Variable* var = find_mutable_var(name);
                        if (!var) {
                            free_value(&v);
                            kr_error("列表推导式：累加器变量 '%s' 未定义", name);
                        }
                        if (var->is_const || var->is_lazy) {
                            free_value(&v);
                            kr_error("列表推导式：累加器变量 '%s' 不可写", name);
                        }
                    
                        // 首次使用 → 提升为空数组；后续保持数组类型
                        if (var->value.type != VAL_ARRAY) {
                            free_value(&var->value);
                            var->value = make_array(nullptr, 0);
                        }
                        Value& arr = var->value;
                        arr.arr_val.elements = (Value*)realloc(
                            arr.arr_val.elements,
                            (size_t)(arr.arr_val.length + 1) * sizeof(Value));
                        arr.arr_val.elements[arr.arr_val.length] = v;   // 所有权转移
                        arr.arr_val.length++;
                        var->is_read = true;
                        break;
                    }
                    case OP_RULE_DEF: {
                        int func_idx = read_int_operand(*bc, pc);
                        const CompiledFunction& cf = bc->functions[func_idx];
                        stack.push_back(make_compiled_func_value(cf, func_idx, /*is_rule=*/true));
                        break;
                    }
                    case OP_RULE_CALL: {
                        int func_idx = read_int_operand(*bc, pc);
                        int argc     = read_int_operand(*bc, pc);
                    
                        // ---- 1. 构造无冲突 key：类型前缀 + 长度前缀 ----
                        auto encode_value = [](const Value& v, std::string& out) {
                            switch (v.type) {
                                case VAL_INT64:  out += "i" + std::to_string(v.int64_val); break;
                                case VAL_INT: {
                                    char* s = mpz_get_str(nullptr, 10, *v.big_int);
                                    out += "Z";
                                    out += std::to_string(strlen(s)) + ":";
                                    out += s;
                                    free(s);
                                    break;
                                }
                                case VAL_FLOAT: {
                                    char* s = mpf_get_str(nullptr, nullptr, 10, 0, *v.mpf_val);
                                    out += "f";
                                    out += std::to_string(strlen(s)) + ":";
                                    out += s;
                                    free(s);
                                    break;
                                }
                                case VAL_STRING:
                                    out += "s";
                                    out += std::to_string(v.str_len) + ":";
                                    out.append(v.str_val, (size_t)v.str_len);
                                    break;
                                case VAL_NULL:
                                    out += "n";
                                    break;
                                default: {
                                    char* s = value_to_string(v);
                                    out += "?";
                                    out += std::to_string(strlen(s)) + ":";
                                    out += s;
                                    free(s);
                                    break;
                                }
                            }
                            out += ';';
                        };
                    
                        std::string key = "F" + std::to_string(func_idx) + "|";
                        for (int i = 0; i < argc; ++i) {
                            encode_value(stack[stack.size() - (size_t)argc + i], key);
                        }
                    
                        // ---- 2. 缓存命中 ----
                        auto it = g_rule_cache.find(key);
                        if (it != g_rule_cache.end()) {
                            for (int i = 0; i < argc; ++i) free_value(&stack[stack.size() - 1 - i]);
                            stack.resize(stack.size() - (size_t)argc);
                            stack.push_back(copy_value(it->second));
                            break;
                        }
                    
                        // ---- 3. 未命中：正常调用，OP_RETURN 会把结果写回 g_rule_cache ----
                        const CompiledFunction& cf = bc->functions[func_idx];
                        const size_t stack_base = stack.size() - (size_t)argc;
                        push_scope();
                        for (int i = 0; i < argc; ++i) {
                            Value v = stack[stack_base + i];
                            declare_var_in_scope(current_scope, cf.params[i].c_str(), false, v);
                        }
                        stack.resize(stack_base);
                    
                        CompilerCallFrame frame;
                        frame.return_pc = pc;
                        frame.stack_base = stack_base;
                        frames.push_back(frame);
                        frame_rule_keys.push_back(std::move(key));
                    
                        pc = cf.code_offset;
                        break;
                    }
                    case OP_TRY_BEGIN: {
                        int catch_pc   = read_int_operand(*bc, pc);
                        int finally_pc = read_int_operand(*bc, pc);
                        TryFrame tf;
                        tf.catch_pc    = (size_t)catch_pc;
                        tf.finally_pc  = (size_t)finally_pc;
                        tf.stack_depth = stack.size();
                        try_stack.push_back(std::move(tf));
                        break;
                    }
                    case OP_TRY_END: {
                        if (!try_stack.empty()) try_stack.pop_back();
                        break;
                    }
                    case OP_GET_CAUGHT: {
                        if (!has_caught) kr_error("OP_GET_CAUGHT: 无异常");
                        stack.push_back(copy_value(caught_exception));
                        free_value(&caught_exception);
                        caught_exception = make_null();
                        has_caught = false;
                        break;
                    }
                    case OP_THROW_RE: {
                        if (!has_caught) kr_error("OP_THROW_RE: 无异常");
                        Value e = caught_exception;
                        caught_exception = make_null();
                        has_caught = false;
                    
                        // 若当前有 finally 帧，挂起重抛，跑完 finally 再抛
                        if (!try_stack.empty() && try_stack.back().finally_pc != 0) {
                            TryFrame& tf = try_stack.back();
                            free_value(&tf.pending_value);
                            tf.pending_value  = e;
                            tf.pending_action = PENDING_RETHROW;
                            while (stack.size() > tf.stack_depth) {
                                free_value(&stack.back()); stack.pop_back();
                            }
                            pc = tf.finally_pc;
                            break;
                        }
                    
                        char* msg = value_to_string(e);
                        free_value(&e);
                        KRError err(msg);
                        free(msg);
                        throw err;
                    }
                    case OP_TO_INT64: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        long long r = value_to_ll(v);
                        free_value(&v);
                        stack.push_back(make_int64(r));
                        break;
                    }
                    case OP_NEW_OBJ: {
                        int cls_idx = read_int_operand(*bc, pc);
                        int argc    = read_int_operand(*bc, pc);
                        const CompiledClass& cls = bc->classes[cls_idx];
                    
                        // ---- 1. 收集实参 + 补默认值 ----
                        size_t params_base = stack.size() - (size_t)argc;
                        std::vector<Value> args;
                        args.reserve(cls.ctor_params.size());
                        for (int i = 0; i < argc; ++i) args.push_back(stack[params_base + i]);
                        stack.resize(params_base);   // 参数槽被截断，所有权已在 args 中
                    
                        for (size_t i = (size_t)argc; i < cls.ctor_params.size(); ++i) {
                            int di = cls.ctor_defaults_idx[i];
                            if (di < 0) {
                                for (auto& a : args) free_value(&a);
                                kr_error("构造函数缺少参数 '%s'", cls.ctor_params[i].c_str());
                            }
                            args.push_back(copy_value(bc->constants[di]));
                        }
                    
                        // ---- 2. 类型检查 ----
                        for (size_t i = 0; i < args.size(); ++i) {
                            if (!cls.ctor_param_types[i].empty() &&
                                !vm_check_type(args[i], cls.ctor_param_types[i])) {
                                for (auto& a : args) free_value(&a);
                                kr_error("构造函数参数 '%s' 类型错误", cls.ctor_params[i].c_str());
                            }
                        }
                    
                        // ---- 3. 构造对象（含 __klass + 属性链）----
                        Value obj; memset(&obj, 0, sizeof(Value));
                        obj.type = VAL_OBJECT;
                        obj.obj_val.count = 1;
                        obj.obj_val.entries = (ObjectEntry*)malloc(sizeof(ObjectEntry));
                        obj.obj_val.entries[0].key   = strdup("__klass");
                        obj.obj_val.entries[0].value = make_string(cls.name.c_str());
                    
                        std::unordered_set<std::string> seen;
                        for (int ci = cls_idx; ci >= 0; ) {
                            const CompiledClass& c = bc->classes[ci];
                            for (auto& [pname, pidx] : c.properties) {
                                if (seen.count(pname)) continue;
                                seen.insert(pname);
                                obj.obj_val.count++;
                                obj.obj_val.entries = (ObjectEntry*)realloc(
                                    obj.obj_val.entries, obj.obj_val.count * sizeof(ObjectEntry));
                                obj.obj_val.entries[obj.obj_val.count-1].key   = strdup(pname.c_str());
                                obj.obj_val.entries[obj.obj_val.count-1].value = copy_value(bc->constants[pidx]);
                            }
                            if (c.parent.empty()) break;
                            auto pit = bc->class_by_name.find(c.parent);
                            ci = (pit == bc->class_by_name.end()) ? -1 : pit->second;
                        }
                    
                        // ---- 4. 执行构造函数 ----
                        // 关键：dies 直接接管 obj 的所有权，不 copy。
                        // 于是构造函数里 dies.x = 5 会改到真实对象。
                        push_scope();
                        declare_var_in_scope(current_scope, "dies", false, obj);
                        for (size_t i = 0; i < cls.ctor_params.size(); ++i)
                            declare_var_in_scope(current_scope, cls.ctor_params[i].c_str(),
                                                 false, std::move(args[i]));
                        // 上面 std::move 对 POD 是拷贝，语义上没差异；args 现在被声明槽"接管"
                    
                        CompilerCallFrame cf;
                        cf.return_pc    = pc;
                        cf.stack_base   = stack.size();
                        cf.is_ctor_call = true;
                        frames.push_back(cf);
                        frame_rule_keys.push_back(std::string());   // 占位，保持 frames 与 keys 同步
                    
                        pc = bc->functions[cls.ctor_func_idx].code_offset;
                        break;
                    }
                    case OP_PUSH_NS: {
                        int ns_idx = read_int_operand(*bc, pc);
                        const CompiledNamespace& ns_meta = bc->namespaces[ns_idx];
                    
                        Scope* ns = nullptr;
                        auto it = vm_named_scopes.find(ns_meta.name);
                        if (it != vm_named_scopes.end()) {
                            ns = it->second;
                        } else {
                            ns = (Scope*)calloc(1, sizeof(Scope));
                            ns->id = next_scope_id++;
                    
                            // 父命名空间：优先本 VM，其次解释器表，再退回全局
                            if (!ns_meta.parent.empty()) {
                                auto pit = vm_named_scopes.find(ns_meta.parent);
                                if (pit != vm_named_scopes.end()) {
                                    ns->parent = pit->second;
                                } else {
                                    auto qit = named_scopes.find(ns_meta.parent);
                                    ns->parent = (qit != named_scopes.end())
                                                 ? qit->second
                                                 : original_global_scope;
                                }
                            } else {
                                ns->parent = original_global_scope;
                            }
                    
                            vm_named_scopes[ns_meta.name] = ns;
                            named_scopes[ns_meta.name]    = ns;   //  就加这一行
                        }
                    
                        saved_scope_stack.push_back(current_scope);
                        current_scope = ns;
                        break;
                    }
                    case OP_POP_NS: {
                        current_scope = saved_scope_stack.back();
                        saved_scope_stack.pop_back();
                        break;
                    }
                    case OP_IMPORT_NS: {
                        int ns_idx = read_int_operand(*bc, pc);
                        const std::string& ns_name = bc->namespaces[ns_idx].name;
                        Scope* ns = vm_named_scopes[bc->namespaces[ns_idx].name];
                        if (!ns) kr_error("命名空间未定义");
                        for (int i = 0; i < ns->var_count; ++i) {
                            Variable* v = &ns->vars[i];
                            set_var(v->name, copy_value(v->value));
                        }
                        // 类/枚举/变体短名通过 bc.namespaces[ns_idx].imported_classes 等做绑定
                        for (const auto& cname : bc->namespaces[ns_idx].class_shortnames) {
                            // 把 bc.class_by_name[A::X] 也登记成 bc.class_by_name[X]
                            auto it = bc->class_by_name.find(ns_name + "::" + cname);
                            if (it != bc->class_by_name.end())
                                bc->class_by_name.emplace(cname, it->second);
                        }
                        break;
                    }
                    case OP_RETURN_NS: {
                        // 命名空间 body 结束；直接当作一次 OP_RETURN 语义即可
                        if (!frames.empty()) {
                            CompilerCallFrame frame = frames.back(); frames.pop_back();
                            for (size_t i = frame.stack_base; i < stack.size(); ++i)
                                free_value(&stack[i]);
                            stack.resize(frame.stack_base);
                            pop_scope();
                            pc = frame.return_pc;
                        }
                        break;
                    }
                    case OP_MARK_VAR_READ: {
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                        Variable* var = find_mutable_var(name);
                        if (var) var->is_read = true;
                        break;
                    }
                    case OP_FINALLY_END: {
                        if (try_stack.empty()) break;   // 无 try 帧（例如正常路径 try→finally 后到达）
                        TryFrame tf = std::move(try_stack.back());
                        try_stack.pop_back();
                    
                        if (tf.pending_action == PENDING_RETURN) {
                            Value ret = tf.pending_value;
                            tf.pending_value = make_null();
                            if (!frames.empty()) {
                                vm_check_return_type(*bc, frames.back().func_idx, ret);
                            }
                    
                            // 如果外层还有 try 且带 finally，继续挂起
                            if (!try_stack.empty() && try_stack.back().finally_pc != 0) {
                                TryFrame& outer = try_stack.back();
                                free_value(&outer.pending_value);
                                outer.pending_value  = ret;
                                outer.pending_action = PENDING_RETURN;
                                while (stack.size() > outer.stack_depth) {
                                    free_value(&stack.back()); stack.pop_back();
                                }
                                pc = outer.finally_pc;
                                break;
                            }
                    
                            // 真正执行返回
                            if (frames.empty()) { stack.push_back(ret); return true; }
                            CompilerCallFrame frame = frames.back();
                            frames.pop_back();
                            std::string rule_key;
                            if (!frame_rule_keys.empty()) {
                                rule_key = std::move(frame_rule_keys.back());
                                frame_rule_keys.pop_back();
                            }
                            if (frame.is_ctor_call && current_scope) {
                                for (int i = 0; i < current_scope->var_count; ++i) {
                                    if (strcmp(current_scope->vars[i].name, "dies") == 0) {
                                        free_value(&ret);
                                        ret = copy_value(current_scope->vars[i].value);
                                        break;
                                    }
                                }
                            }
                            if (!rule_key.empty()) {
                                auto it = g_rule_cache.find(rule_key);
                                if (it != g_rule_cache.end()) free_value(&it->second);
                                g_rule_cache[rule_key] = copy_value(ret);
                            }
                            for (size_t i = frame.stack_base; i < stack.size(); ++i)
                                free_value(&stack[i]);
                            stack.resize(frame.stack_base);
                            pop_scope();
                            pc = frame.return_pc;
                            stack.push_back(ret);
                        }
                        else if (tf.pending_action == PENDING_RETHROW) {
                            Value e = tf.pending_value;
                            tf.pending_value = make_null();
                            char* msg = value_to_string(e);
                            free_value(&e);
                            KRError err(msg);
                            free(msg);
                            throw err;
                        }
                        // PENDING_NONE / 其它 → 直接继续
                        break;
                    }
                    case OP_CALL_VALUE: {
                        int argc = read_int_operand(*bc, pc);
                    
                        const size_t func_slot = stack.size() - (size_t)argc - 1;
                        Value func_val = stack[func_slot];
                    
                        if (func_val.type != VAL_FUNCTION)
                            kr_error("尝试调用非函数值（类型 %d）", (int)func_val.type);
                    
                        int func_idx = func_val.func_val.compiled_idx;
                        if (func_idx < 0) {
                            const char* fname = func_val.func_val.name;
                            auto it = bc->func_by_name.find(fname ? fname : "");
                            if (it == bc->func_by_name.end())
                                kr_error("未编译函数 '%s'", fname ? fname : "<anonymous>");
                            func_idx = it->second;
                        }
                    
                        for (size_t i = func_slot; i + 1 < stack.size(); ++i)
                            stack[i] = stack[i + 1];
                        stack.pop_back();
                        free_value(&func_val);
                    
                        vm_do_direct_call(bc->functions[func_idx], func_idx, argc);
                        break;
                    }
                    case OP_WRAP_ARRAY_1: {
                        Value v = std::move(stack.back()); stack.pop_back();
                        Value* elems = (Value*)malloc(sizeof(Value));
                        elems[0] = v;                         // 所有权转移
                        Value arr = make_array(elems, 1);     // make_array 深拷贝
                        free_value(&elems[0]);                // 释放临时槽
                        free(elems);
                        stack.push_back(arr);
                        break;
                    }
                    
                    case OP_FLATTEN_ARRAYS: {
                        int n = read_int_operand(*bc, pc);
                        // 检查类型 + 统计总长度
                        int total = 0;
                        for (int i = 0; i < n; ++i) {
                            Value& v = stack[stack.size() - n + i];
                            if (v.type != VAL_ARRAY)
                                kr_error("展开调用：参数不是数组（类型 %d）", (int)v.type);
                            total += v.arr_val.length;
                        }
                        // 拼接（深拷贝每个元素）
                        Value* elems = total ? (Value*)malloc(total * sizeof(Value)) : nullptr;
                        int k = 0;
                        for (int i = 0; i < n; ++i) {
                            Value& v = stack[stack.size() - n + i];
                            for (int j = 0; j < v.arr_val.length; ++j)
                                elems[k++] = copy_value(v.arr_val.elements[j]);
                        }
                        // 弹出原始数组（释放它们，因为元素已被拷贝）
                        for (int i = 0; i < n; ++i) {
                            free_value(&stack.back());
                            stack.pop_back();
                        }
                        Value arr = make_array(elems, total);
                        for (int i = 0; i < total; ++i) free_value(&elems[i]);
                        free(elems);
                        stack.push_back(arr);
                        break;
                    }
                    
                    case OP_CALL_DIRECT_ARR: {
                        int func_idx = read_int_operand(*bc, pc);
                        Value arr = std::move(stack.back()); stack.pop_back();
                        if (arr.type != VAL_ARRAY) {
                            free_value(&arr);
                            kr_error("展开调用：参数不是数组");
                        }
                        const int argc = arr.arr_val.length;
                        // 把数组元素压回栈上，参数槽之后统一处理
                        for (int i = 0; i < argc; ++i)
                            stack.push_back(copy_value(arr.arr_val.elements[i]));
                        free_value(&arr);
                        // 复用 OP_CALL_DIRECT 的处理逻辑
                        vm_do_direct_call(bc->functions[func_idx], func_idx, argc);
                        break;
                    }
                    
                    case OP_CALL_ARR: {
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                        Value arr = std::move(stack.back()); stack.pop_back();
                        if (arr.type != VAL_ARRAY) {
                            free_value(&arr);
                            kr_error("展开调用：参数不是数组");
                        }
                        Variable* var = find_mutable_var(name);
                        if (!var || var->value.type != VAL_FUNCTION) {
                            free_value(&arr);
                            kr_error("'%s' 不是函数", name);
                        }
                    
                        int func_idx = var->value.func_val.compiled_idx;
                        if (func_idx < 0) {
                            const char* fname = var->value.func_val.name;
                            auto it = bc->func_by_name.find(fname ? fname : "");
                            if (it == bc->func_by_name.end()) {
                                free_value(&arr);
                                kr_error("未编译函数 '%s'", fname ? fname : "<anonymous>");
                            }
                            func_idx = it->second;
                        }
                    
                        const int argc = arr.arr_val.length;
                        for (int i = 0; i < argc; ++i)
                            stack.push_back(copy_value(arr.arr_val.elements[i]));
                        free_value(&arr);
                    
                        vm_do_direct_call(bc->functions[func_idx], func_idx, argc);
                        break;
                    }
                    
                    case OP_CALL_VALUE_ARR: {
                        Value arr = std::move(stack.back()); stack.pop_back();
                        Value func_val = std::move(stack.back()); stack.pop_back();
                    
                        if (func_val.type != VAL_FUNCTION) {
                            free_value(&arr); free_value(&func_val);
                            kr_error("尝试调用非函数值");
                        }
                        if (arr.type != VAL_ARRAY) {
                            free_value(&arr); free_value(&func_val);
                            kr_error("展开调用：参数不是数组");
                        }
                    
                        int func_idx = func_val.func_val.compiled_idx;
                        if (func_idx < 0) {
                            const char* fname = func_val.func_val.name;
                            auto it = bc->func_by_name.find(fname ? fname : "");
                            if (it == bc->func_by_name.end()) {
                                free_value(&arr); free_value(&func_val);
                                kr_error("未编译函数 '%s'", fname ? fname : "<anonymous>");
                            }
                            func_idx = it->second;
                        }
                    
                        const int argc = arr.arr_val.length;
                        for (int i = 0; i < argc; ++i)
                            stack.push_back(copy_value(arr.arr_val.elements[i]));
                        free_value(&arr);
                        free_value(&func_val);
                    
                        vm_do_direct_call(bc->functions[func_idx], func_idx, argc);
                        break;
                    }

                    case OP_METHOD_CALL: {
                        int method_idx = read_int_operand(*bc, pc);
                        int argc       = read_int_operand(*bc, pc);
                        uint8_t flags  = bc->code[pc++];
                        const char* method = bc->constants[method_idx].str_val;
                    
                        const size_t obj_slot = stack.size() - (size_t)argc - 1;
                        Value obj = stack[obj_slot];
                        for (int i = 0; i < argc; ++i)
                            stack[obj_slot + i] = stack[obj_slot + 1 + i];
                        stack.resize(obj_slot + (size_t)argc);
                    
                        // ← 同样把实参搬出 stack
                        Value* args = nullptr;
                        if (argc > 0) {
                            args = (Value*)malloc((size_t)argc * sizeof(Value));
                            for (int i = 0; i < argc; ++i)
                                args[i] = std::move(stack[stack.size() - (size_t)argc + i]);
                            stack.resize(stack.size() - (size_t)argc);
                        }
                    
                        Value out = make_null();
                        vm_dispatch_method(obj, method, args, argc, flags & 1, out);
                    
                        if (args) {
                            for (int i = 0; i < argc; ++i) free_value(&args[i]);
                            free(args);
                        }
                        stack.push_back(out);
                        free_value(&obj);
                        break;
                    }
                    
                    case OP_METHOD_CALL_VAR: {
                        int var_idx    = read_int_operand(*bc, pc);
                        int method_idx = read_int_operand(*bc, pc);
                        int argc       = read_int_operand(*bc, pc);
                        uint8_t flags  = bc->code[pc++];
                        const char* var_name = bc->constants[var_idx].str_val;
                        const char* method   = bc->constants[method_idx].str_val;
                    
                        // ============================================================
                        // 0. 把实参从栈搬进独立堆缓冲区
                        //    - vm_enter_function_call / vm_dispatch_method 内部都可能
                        //      调用 vm_invoke → 被调函数体 push → stack realloc，
                        //      任何指向 stack.data() 的裸指针都会悬垂。
                        //    - 同时把参数从栈上摘下，避免 dispatch 与调用者重复消费。
                        // ============================================================
                        Value* args = nullptr;
                        if (argc > 0) {
                            args = (Value*)malloc((size_t)argc * sizeof(Value));
                            for (int i = 0; i < argc; ++i) {
                                args[i] = std::move(stack[stack.size() - (size_t)argc + i]);
                            }
                            stack.resize(stack.size() - (size_t)argc);
                        }
                    
                        // 统一收尾：任何出口都释放 args
                        auto release_args = [&]() {
                            if (args) {
                                for (int i = 0; i < argc; ++i) free_value(&args[i]);
                                free(args);
                                args = nullptr;
                            }
                        };
                    
                        // ============================================================
                        // 1. 命名空间成员：ns.func(...)
                        // ============================================================
                        auto ns_it = vm_named_scopes.find(var_name);
                        if (ns_it != vm_named_scopes.end()) {
                            Scope* ns = ns_it->second;
                            int idx = get_var_index_in_scope(ns, method);
                            if (idx < 0) {
                                release_args();
                                kr_error("命名空间 '%s' 中没有成员 '%s'", var_name, method);
                            }
                            Variable* fn_var = &ns->vars[idx];
                            fn_var = resolve_alias(fn_var);
                            if (fn_var->value.type != VAL_FUNCTION) {
                                release_args();
                                kr_error("命名空间 '%s' 的成员 '%s' 不是函数", var_name, method);
                            }
                            int func_idx = fn_var->value.func_val.compiled_idx;
                            if (func_idx < 0) {
                                const char* fname = fn_var->value.func_val.name;
                                auto fit = bc->func_by_name.find(fname ? fname : "");
                                if (fit != bc->func_by_name.end()) func_idx = fit->second;
                            }
                            if (func_idx < 0) {
                                release_args();
                                kr_error("未编译命名空间函数 '%s'", method);
                            }
                    
                            // vm_enter_function_call 会消费栈顶 argc 个元素作为实参。
                            // 我们把 args 已摘下，因此先把它压回栈，再调用；
                            // 由 vm_enter_function_call 内部统一 resize。
                            for (int i = 0; i < argc; ++i)
                                stack.push_back(args[i]);           // 转移所有权
                            free(args); args = nullptr;             // 只释放数组壳
                            vm_enter_function_call(bc->functions[func_idx], func_idx,
                                                   argc, nullptr);
                            break;
                        }
                    
                        // ============================================================
                        // 2. 变量存在：走通用方法分发
                        // ============================================================
                        Variable* var = find_mutable_var(var_name);
                        if (var) {
                            var = resolve_alias(var);
                    
                            Value obj = copy_value(var->value);
                            Value out = make_null();
                    
                            // vm_dispatch_method 的契约：
                            //   - 传 args/argc（独立缓冲区，不再指向 stack）
                            //   - 返回 true  → 结果在 out，参数已被内部 cleanup 释放
                            //   - 返回 false → 已接管：调用了 vm_enter_function_call，
                            //                  由后续 OP_RETURN 把结果压栈，参数所有权
                            //                  已交给那次调用（args 内容仍需我们释放）
                            bool ready = vm_dispatch_method(obj, method, args, argc,
                                                            flags & 1, out);
                    
                            // 参数堆缓冲区由本 opcode 统一释放（内容已被 dispatch 消费）
                            if (args) {
                                for (int i = 0; i < argc; ++i) free_value(&args[i]);
                                free(args);
                                args = nullptr;
                            }
                    
                            if (ready) {
                                // 只有白名单里的原地方法才把修改后的 obj 写回原变量
                                if (!var->is_const && !var->is_lazy &&
                                    is_mutating_receiver_method(method))
                                {
                                    free_value(&var->value);
                                    var->value = obj;          // 转移所有权
                                    obj = make_null();
                                } else {
                                    free_value(&obj);
                                }
                                stack.push_back(out);
                            } else {
                                // 接管路径：接收者局部副本不再需要
                                free_value(&obj);
                                // 结果由 OP_RETURN 压栈，这里什么都不做
                            }
                            break;
                        }
                    
                        // ============================================================
                        // 3. 类静态方法：Klasse.methode(...)
                        // ============================================================
                        auto cls_it = bc->class_by_name.find(var_name);
                        if (cls_it != bc->class_by_name.end()) {
                            const CompiledClass& c = bc->classes[cls_it->second];
                            int  midx = -1;
                            bool is_static = false;
                            for (size_t k = 0; k < c.methods.size(); ++k) {
                                if (c.methods[k].first == method) {
                                    midx      = c.methods[k].second;
                                    is_static = c.method_is_static[k];
                                    break;
                                }
                            }
                            if (midx < 0) {
                                release_args();
                                kr_error("类 '%s' 没有方法 '%s'", var_name, method);
                            }
                            if (!is_static) {
                                release_args();
                                kr_error("不能静态调用实例方法 '%s::%s'", var_name, method);
                            }
                    
                            // 同命名空间路径：先把 args 压回栈，交给 vm_enter_function_call
                            for (int i = 0; i < argc; ++i)
                                stack.push_back(args[i]);
                            free(args); args = nullptr;
                            vm_enter_function_call(bc->functions[midx], midx, argc, nullptr);
                            break;
                        }
                    
                        // ============================================================
                        // 4. 都不是
                        // ============================================================
                        release_args();
                        kr_error("'%s' 既不是命名空间、类，也不是已定义变量", var_name);
                    }

                    case OP_DECLARE_LAZY_VAR: {
                        int  name_idx = read_int_operand(*bc, pc);
                        int  is_glob  = bc->code[pc++];
                        int  code_off = read_int_operand(*bc, pc);
                        int  code_end = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                    
                        Scope* target = is_glob ? original_global_scope : current_scope;
                        if (!target) {
                            if (!is_glob) { push_scope(); target = current_scope; }
                            else kr_error("未初始化的全局范围");
                        }
                    
                        Value dummy = make_null();
                        declare_var_in_scope(target, name, /*is_const=*/false, dummy);
                    
                        int vi = get_var_index_in_scope(target, name);
                        if (vi < 0) kr_error("OP_DECLARE_LAZY_VAR: 声明失败 '%s'", name);
                        Variable* var = &target->vars[vi];
                    
                        var->is_lazy       = true;
                        var->evaluated     = false;
                        var->init_expr     = nullptr;
                        var->lazy_scope    = current_scope;       //  声明点
                        var->lazy_code_off = (size_t)code_off;
                        var->lazy_code_end = (size_t)code_end;
                        free_value(&var->cached_value);
                        var->cached_value  = make_null();
                        break;
                    }

                    case OP_CALL_BUILTIN: {
                        int bid  = read_int_operand(*bc, pc);
                        int argc = read_int_operand(*bc, pc);
                    
                        Value* args = nullptr;
                        if (argc > 0) {
                            args = (Value*)malloc((size_t)argc * sizeof(Value));
                            for (int i = 0; i < argc; ++i) {
                                size_t idx = stack.size() - (size_t)argc + i;
                                // std::move转移所有权，消除双重释放
                                args[i] = std::move(stack[idx]);
                                stack[idx] = make_null();
                            }
                        }
                        stack.resize(stack.size() - (size_t)argc);
                    
                        Value r = make_null();
                        try {
                            r = vm_builtin_dispatch((BuiltinId)bid, args, argc, bc, this);
                        } catch (...) {
                            for (int i = 0; i < argc; ++i) free_value(&args[i]);
                            free(args);
                            throw;
                        }
                    
                        for (int i = 0; i < argc; ++i) free_value(&args[i]);
                        free(args);
                    
                        stack.push_back(r);
                        break;
                    }

                    case OP_INPUT: {
                        int name_idx        = read_int_operand(*bc, pc);
                        int flags           = read_int_operand(*bc, pc);
                        int argc            = read_int_operand(*bc, pc);
                        int multiline_start = read_int_operand(*bc, pc);
                        int multiline_end   = read_int_operand(*bc, pc);

                        const char* name = bc->constants[name_idx].str_val;
                        const bool has_multiline = (multiline_end > multiline_start);

                        // =================================================
                        // 1. 解析正则参数（只取第一个，与解释器一致）
                        // =================================================
                        pcre2_code*        re         = nullptr;
                        pcre2_match_data*  match_data = nullptr;
                        bool has_regex = false;

                        if (argc > 0) {
                            // 第一个参数位于 stack[stack.size()-argc]
                            const size_t base = stack.size() - (size_t)argc;
                            Value v = std::move(stack[base]);
                            // 其余参数求值后丢弃（保持语义，但不用）
                            for (int i = 1; i < argc; ++i) {
                                free_value(&stack[base + i]);
                            }
                            stack.resize(base);

                            std::string pattern_str;
                            std::string flags_str;
                            bool handled = false;

                            if (v.type == VAL_OBJECT) {
                                for (int j = 0; j < v.obj_val.count; ++j) {
                                    const auto& e = v.obj_val.entries[j];
                                    if (strcmp(e.key, "muster") == 0 &&
                                        e.value.type == VAL_STRING) {
                                        pattern_str.assign(e.value.str_val,
                                                           e.value.str_len);
                                        handled = true;
                                    }
                                    if (strcmp(e.key, "flags") == 0 &&
                                        e.value.type == VAL_STRING) {
                                        flags_str.assign(e.value.str_val,
                                                         e.value.str_len);
                                    }
                                }
                                if (!handled) {
                                    char* s = value_to_string(v);
                                    pattern_str = s ? s : "";
                                    free(s);
                                }
                            } else if (v.type == VAL_STRING) {
                                pattern_str.assign(v.str_val, v.str_len);
                            } else {
                                char* s = value_to_string(v);
                                pattern_str = s ? s : "";
                                free(s);
                            }
                            free_value(&v);

                            int opts = PCRE2_UTF | PCRE2_UCP;
                            if (strchr(flags_str.c_str(), 'i')) opts |= PCRE2_CASELESS;
                            if (strchr(flags_str.c_str(), 'm')) opts |= PCRE2_MULTILINE;
                            if (strchr(flags_str.c_str(), 's')) opts |= PCRE2_DOTALL;
                            if (strchr(flags_str.c_str(), 'x')) opts |= PCRE2_EXTENDED;

                            int errcode;
                            PCRE2_SIZE erroffset;
                            re = pcre2_compile((PCRE2_SPTR)pattern_str.c_str(),
                                               pattern_str.size(),
                                               opts, &errcode, &erroffset, NULL);
                            if (!re) {
                                PCRE2_UCHAR errbuf[256];
                                pcre2_get_error_message(errcode, errbuf, sizeof(errbuf));
                                kr_error("PCRE2 编译错误: %s (偏移 %zu)",
                                         errbuf, erroffset);
                            }
                            match_data = pcre2_match_data_create_from_pattern(re, NULL);
                            if (!match_data) {
                                pcre2_code_free(re);
                                kr_error("无法创建匹配数据");
                            }
                            has_regex = true;
                        }

                        // 异常清理 lambda：任何 kr_error 都不会泄漏正则资源
                        auto cleanup_regex = [&]() {
                            if (match_data) { pcre2_match_data_free(match_data); match_data = nullptr; }
                            if (re)         { pcre2_code_free(re);                    re         = nullptr; }
                        };

                        // =================================================
                        // 2. 读入第一行
                        // =================================================
                        char buffer[256];
                        if (!fgets(buffer, sizeof(buffer), stdin)) {
                            cleanup_regex();
                            kr_error("lies: 输入错误\n");
                        }
                        {
                            size_t len = strlen(buffer);
                            while (len > 0 &&
                                   (buffer[len-1] == '\n' || buffer[len-1] == '\r' ||
                                    isspace((unsigned char)buffer[len-1])))
                                buffer[--len] = '\0';
                        }

                        const bool do_clear = (flags & FLAG_NO_STORE) != 0;
                        Value result_value = make_null();

                        // =================================================
                        // 3. 多行模式
                        // =================================================
                        if (has_multiline) {
                            std::string full_input;
                            int line_count = 0;

                            if (do_clear) { std::printf("\033[s"); std::fflush(stdout); }

                            push_scope();
                            declare_var_in_scope(current_scope, "_", false,
                                                 make_string(""));

                            // 3a. 用第一行做初始条件判断
                            auto eval_multiline_cond = [&](const std::string& line) -> bool {
                                // 设置 "_"
                                int idx = get_var_index_in_scope(current_scope, "_");
                                if (idx >= 0) {
                                    Variable* var = &current_scope->vars[idx];
                                    free_value(&var->value);
                                    var->value = make_string_len(line.data(), line.size());
                                } else {
                                    declare_var_in_scope(current_scope, "_", false,
                                                         make_string_len(line.data(),
                                                                         line.size()));
                                }
                                // 运行 multiline_expr 代码块
                                size_t save_pc = pc;
                                pc = (size_t)multiline_start;
                                run_until((size_t)multiline_end);
                                pc = save_pc;
                                Value cond = std::move(stack.back());
                                stack.pop_back();
                                bool r = value_to_bool(cond);
                                free_value(&cond);
                                return r;
                            };

                            bool should_stop = false;
                            if (strlen(buffer) > 0)
                                should_stop = eval_multiline_cond(buffer);

                            if (!should_stop && strlen(buffer) > 0) {
                                full_input += buffer;
                                full_input += '\n';
                                line_count++;
                            }

                            while (!should_stop) {
                                char line_buf[4096];
                                if (!fgets(line_buf, sizeof(line_buf), stdin)) break;
                                size_t line_len = strlen(line_buf);
                                while (line_len > 0 &&
                                       (line_buf[line_len-1] == '\n' ||
                                        line_buf[line_len-1] == '\r'))
                                    line_buf[--line_len] = '\0';
                                if (line_len == 0) continue;

                                should_stop = eval_multiline_cond(line_buf);
                                if (should_stop) break;

                                full_input += line_buf;
                                full_input += '\n';
                                line_count++;
                            }
                            pop_scope();

                            // 3b. 终端清理
                            if (do_clear) {
#ifdef _WIN32
                                HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
                                CONSOLE_SCREEN_BUFFER_INFO csbi;
                                if (GetConsoleScreenBufferInfo(hOut, &csbi)) {
                                    COORD cursor = csbi.dwCursorPosition;
                                    int total_lines = line_count + 1;
                                    int startY = cursor.Y - total_lines;
                                    if (startY < 0) startY = 0;
                                    for (int y = startY; y <= cursor.Y; y++) {
                                        COORD pos = { 0, (SHORT)y };
                                        SetConsoleCursorPosition(hOut, pos);
                                        DWORD written;
                                        FillConsoleOutputCharacter(hOut, ' ', csbi.dwSize.X, pos, &written);
                                        FillConsoleOutputAttribute(hOut, csbi.wAttributes, csbi.dwSize.X, pos, &written);
                                    }
                                    COORD newPos = { 0, (SHORT)startY };
                                    SetConsoleCursorPosition(hOut, newPos);
                                }
#else
                                std::printf("\033[2J\033[H");
#endif
                                std::fflush(stdout);
                            }

                            // 3c. 空白处理
                            std::string processed = full_input;
                            if (flags & (FLAG_NUM | FLAG_FLOAT)) {
                                processed.erase(
                                    std::remove_if(processed.begin(), processed.end(),
                                        [](char c){ return std::isspace((unsigned char)c); }),
                                    processed.end());
                            } else {
                                while (!processed.empty() &&
                                       std::isspace((unsigned char)processed.back()))
                                    processed.pop_back();
                                while (!processed.empty() &&
                                       std::isspace((unsigned char)processed.front()))
                                    processed.erase(0, 1);
                            }

                            bool is_empty = (flags & (FLAG_NUM | FLAG_FLOAT)) &&
                                            processed.empty();

                            // 3d. 正则校验 + flags 转换
                            if (has_regex) {
                                int rc = pcre2_match(re,
                                    (PCRE2_SPTR)processed.c_str(), processed.size(),
                                    0, 0, match_data, NULL);
                                if (rc < 0) {
                                    result_value = make_null();
                                } else if (is_empty) {
                                    result_value = make_null();
                                } else if (flags & FLAG_FLOAT) {
                                    char* end = nullptr;
                                    double d = strtod(processed.c_str(), &end);
                                    if (end && *end == '\0') result_value = make_float(d);
                                    else                     result_value = make_null();
                                } else if (flags & FLAG_NUM) {
                                    char* end = nullptr;
                                    long long n = strtoll(processed.c_str(), &end, 10);
                                    if (end && *end == '\0') result_value = make_int64(n);
                                    else {
                                        double d = strtod(processed.c_str(), &end);
                                        if (end && *end == '\0') result_value = make_float(d);
                                        else                     result_value = make_null();
                                    }
                                } else {
                                    result_value = make_string_len(processed.data(),
                                                                   processed.size());
                                }
                            } else {
                                if (is_empty) {
                                    result_value = make_null();
                                } else if (flags & FLAG_FLOAT) {
                                    char* end = nullptr;
                                    double d = strtod(processed.c_str(), &end);
                                    if (end && *end == '\0') result_value = make_float(d);
                                    else                     result_value = make_null();
                                } else if (flags & FLAG_NUM) {
                                    char* end = nullptr;
                                    long long n = strtoll(processed.c_str(), &end, 10);
                                    if (end && *end == '\0') result_value = make_int64(n);
                                    else {
                                        double d = strtod(processed.c_str(), &end);
                                        if (end && *end == '\0') result_value = make_float(d);
                                        else                     result_value = make_null();
                                    }
                                } else {
                                    result_value = make_string_len(processed.data(),
                                                                   processed.size());
                                }
                            }
                        }
                        // =================================================
                        // 4. 单行模式
                        // =================================================
                        else {
                            std::string input_str(buffer);

                            if (has_regex) {
                                // 只在有正则时 trim
                                size_t p = input_str.find_first_not_of(" \t\n\r\f\v");
                                if (p == std::string::npos) {
                                    input_str.clear();
                                } else {
                                    size_t q = input_str.find_last_not_of(" \t\n\r\f\v");
                                    input_str = input_str.substr(p, q - p + 1);
                                }
                            }

                            bool is_empty = (flags & (FLAG_NUM | FLAG_FLOAT)) &&
                                            input_str.find_first_not_of(" \t\n\r") ==
                                            std::string::npos;

                            if (has_regex) {
                                int rc = pcre2_match(re,
                                    (PCRE2_SPTR)input_str.c_str(), input_str.size(),
                                    0, 0, match_data, NULL);
                                if (rc < 0) {
                                    result_value = make_null();
                                } else if (is_empty) {
                                    result_value = make_null();
                                } else if (flags & FLAG_FLOAT) {
                                    char* end = nullptr;
                                    double d = strtod(input_str.c_str(), &end);
                                    if (end && *end == '\0') result_value = make_float(d);
                                    else                     result_value = make_null();
                                } else if (flags & FLAG_NUM) {
                                    char* end = nullptr;
                                    long long n = strtoll(input_str.c_str(), &end, 10);
                                    if (end && *end == '\0') result_value = make_int64(n);
                                    else {
                                        double d = strtod(input_str.c_str(), &end);
                                        if (end && *end == '\0') result_value = make_float(d);
                                        else                     result_value = make_null();
                                    }
                                } else {
                                    result_value = make_string_len(input_str.data(),
                                                                   input_str.size());
                                }
                            } else {
                                if (is_empty) {
                                    result_value = make_null();
                                } else if (flags & FLAG_FLOAT) {
                                    char* end = nullptr;
                                    double d = strtod(buffer, &end);
                                    if (end && *end == '\0') result_value = make_float(d);
                                    else                     result_value = make_null();
                                } else if (flags & FLAG_NUM) {
                                    // 与解释器一致：优先走 GMP（支持大整数）
                                    mpz_t tmp; mpz_init(tmp);
                                    if (mpz_set_str(tmp, buffer, 10) == 0) {
                                        result_value = make_int_auto(tmp);
                                        mpz_clear(tmp);
                                    } else {
                                        mpz_clear(tmp);
                                        char* end = nullptr;
                                        double d = strtod(buffer, &end);
                                        if (end && *end == '\0') result_value = make_float(d);
                                        else                     result_value = make_null();
                                    }
                                } else {
                                    result_value = make_string(buffer);
                                }
                            }

                            if (do_clear) {
                                std::printf("\r\033[K\033[A\033[K");
                                std::fflush(stdout);
                            }
                        }

                        // =================================================
                        // 5. assign_or_declare
                        // =================================================
                        {
                            int idx = get_var_index_in_scope(current_scope, name);
                            if (idx >= 0) {
                                Variable* var = &current_scope->vars[idx];
                                if (var->is_const) {
                                    free_value(&result_value);
                                    cleanup_regex();
                                    kr_error("常量 '%s' 不能重新赋值", name);
                                }
                                if (var->is_lazy) {
                                    free_value(&result_value);
                                    cleanup_regex();
                                    kr_error("惰性变量 '%s' 不能赋值", name);
                                }
                                free_value(&var->value);
                                var->value = result_value;
                            } else {
                                declare_var_in_scope(current_scope, name,
                                                     false, result_value);
                                if (current_scope == original_global_scope) {
                                    g_var_decl_pos[name] = { g_last_error_line,
                                                             g_last_error_col };
                                    int nidx = get_var_index_in_scope(current_scope, name);
                                    if (nidx >= 0)
                                        current_scope->vars[nidx].is_read = false;
                                }
                            }
                        }

                        cleanup_regex();
                        break;
                    }
                    case OP_SUPER_CALL: {
                        int argc = read_int_operand(*bc, pc);
                    
                        // ---- 1. 必须在构造函数里 ----
                        bool in_ctor = false;
                        for (const auto& f : frames) {
                            if (f.is_ctor_call) { in_ctor = true; break; }
                        }
                        if (!in_ctor)
                            kr_error("ober 只能在构造函数内使用");
                    
                        // ---- 2. 沿作用域链找最近的 dies ----
                        Variable* dies_var = nullptr;
                        for (Scope* s = current_scope; s && !dies_var; s = s->parent) {
                            for (int i = 0; i < s->var_count; ++i) {
                                if (strcmp(s->vars[i].name, "dies") == 0) {
                                    dies_var = &s->vars[i];
                                    break;
                                }
                            }
                        }
                        if (!dies_var || dies_var->value.type != VAL_OBJECT)
                            kr_error("ober: 无法找到当前构造对象");
                    
                        // ---- 3. dies.__klass → 当前类 ----
                        const char* cur_klass = nullptr;
                        for (int i = 0; i < dies_var->value.obj_val.count; ++i) {
                            const auto& e = dies_var->value.obj_val.entries[i];
                            if (strcmp(e.key, "__klass") == 0 && e.value.type == VAL_STRING) {
                                cur_klass = e.value.str_val;
                                break;
                            }
                        }
                        if (!cur_klass) kr_error("ober: 对象缺少 __klass");
                    
                        auto cls_it = bc->class_by_name.find(cur_klass);
                        if (cls_it == bc->class_by_name.end())
                            kr_error("ober: 类定义丢失 '%s'", cur_klass);
                        const CompiledClass& cls = bc->classes[cls_it->second];
                        if (cls.parent.empty())
                            kr_error("ober: 当前类 '%s' 没有父类", cur_klass);
                    
                        // ---- 4. 父类 ----
                        auto par_it = bc->class_by_name.find(cls.parent);
                        if (par_it == bc->class_by_name.end())
                            kr_error("ober: 父类 '%s' 未定义", cls.parent.c_str());
                        const CompiledClass& parent = bc->classes[par_it->second];
                        if (parent.ctor_func_idx < 0)
                            kr_error("ober: 父类 '%s' 没有构造函数", cls.parent.c_str());
                    
                        const CompiledFunction& pcf = bc->functions[parent.ctor_func_idx];
                    
                        // ---- 5. 参数个数 / 类型检查（与 vm_do_direct_call 完全一致）----
                        const int  pc_count  = (int)pcf.params.size();
                        const bool has_vararg = !pcf.vararg_name.empty();
                        if (!has_vararg && argc > pc_count)
                            kr_error("ober: 父类构造函数参数过多：期望 %d，实际 %d",
                                     pc_count, argc);
                        for (int i = argc; i < pc_count; ++i) {
                            bool has = (i < (int)pcf.param_defaults_idx.size() && pcf.param_defaults_idx[i] >= 0)
                                    || (i < (int)pcf.param_default_code_off.size() && pcf.param_default_code_off[i] != SIZE_MAX)
                                    || (i < (int)pcf.param_has_default.size() && pcf.param_has_default[i]);
                            if (!has)
                                kr_error("ober: 父类构造函数缺少参数 '%s' 且无默认值",
                                         pcf.params[i].c_str());
                        }
                        for (int i = 0; i < argc && i < pc_count; ++i) {
                            if (i >= (int)pcf.param_types.size() || pcf.param_types[i].empty()) continue;
                            const Value& v = stack[stack.size() - (size_t)argc + i];
                            if (!vm_check_type(v, pcf.param_types[i]))
                                kr_error("ober: 参数 '%s' 类型错误", pcf.params[i].c_str());
                        }
                    
                        // ---- 6. 复用 vm_do_direct_call ----
                        //   它会：push_scope、绑定参数、求默认值、收可变参数、
                        //         推 CallFrame、把 pc 指向父类构造体。
                        //   父类构造体里的 OP_GET_VAR "dies" 会沿作用域链找到
                        //   子类作用域里那个 dies —— 操作到同一个对象。
                        vm_do_direct_call(pcf, parent.ctor_func_idx, argc);
                    
                        // ---- 7. 标记 super call ----
                        //   OP_RETURN 会丢掉父类构造体的返回值，替换为 null。
                        //   is_ctor_call 显式置 false，避免 OP_RETURN 走 dies 覆盖逻辑
                        //   （即使置 true 也没关系：父类作用域里没有 dies，覆盖逻辑会
                        //    找不到目标而保留原值；显式 false 更清晰）。
                        frames.back().is_super_call = true;
                        frames.back().is_ctor_call  = false;
                        break;
                    }
                    case OP_OBJ_SET_VAR: {
                        // 操作数：name_idx
                        // 栈：[..., key, value]（value 在栈顶）
                        int name_idx = read_int_operand(*bc, pc);
                        const char* name = bc->constants[name_idx].str_val;
                    
                        Value v = std::move(stack.back()); stack.pop_back();
                        Value k = std::move(stack.back()); stack.pop_back();
                    
                        Variable* var = find_mutable_var(name);
                        if (!var) {
                            free_value(&v); free_value(&k);
                            kr_error("对象推导式：累加器变量 '%s' 未定义", name);
                        }
                        if (var->is_const || var->is_lazy) {
                            free_value(&v); free_value(&k);
                            kr_error("对象推导式：累加器变量 '%s' 不可写", name);
                        }
                    
                        // 累加器必须（被）保持为对象。首次进入推导式时已由编译期初始化为 {}，
                        // 这里只做兜底防御。
                        if (var->value.type != VAL_OBJECT) {
                            free_value(&var->value);
                            var->value = make_object(nullptr, 0);
                        }
                    
                        char* ks = value_to_string(k);
                        free_value(&k);
                    
                        Value& obj = var->value;   // 直接原地修改变量，不经栈副本
                        int found = -1;
                        for (int i = 0; i < obj.obj_val.count; ++i) {
                            if (strcmp(obj.obj_val.entries[i].key, ks) == 0) {
                                found = i; break;
                            }
                        }
                        if (found >= 0) {
                            free_value(&obj.obj_val.entries[found].value);
                            obj.obj_val.entries[found].value = v;   // 转移所有权
                        } else {
                            obj.obj_val.count++;
                            obj.obj_val.entries = (ObjectEntry*)realloc(
                                obj.obj_val.entries,
                                obj.obj_val.count * sizeof(ObjectEntry));
                            obj.obj_val.entries[obj.obj_val.count - 1].key   = strdup(ks);
                            obj.obj_val.entries[obj.obj_val.count - 1].value = v;   // 转移所有权
                        }
                        free(ks);
                        break;
                    }

                    case OP_MARK_USED: {
                        // 读取uint16 count，小端
                        uint8_t lo = bc->code[pc];
                        uint8_t hi = bc->code[pc+1];
                        uint16_t count = static_cast<uint16_t>(lo | (hi << 8));
                        pc += 2;
                        
                        for (uint16_t k = 0; k < count; ++k) {
                            // 读取常量索引 uint16
                            uint8_t clo = bc->code[pc];
                            uint8_t chi = bc->code[pc+1];
                            uint16_t cidx = static_cast<uint16_t>(clo | (chi << 8));
                            pc += 2;

                            const Value& v = mutable_bc->constants[cidx];
                            if (v.type != VAL_STRING) {
                                continue;
                            }
                            const char* name = v.str_val;

                            bool foundVar = false;
                            Scope* s = original_global_scope;
                            while (s) {
                                int idx = get_var_index_in_scope(s, name);
                                if (idx >= 0) {
                                    Variable* var = &s->vars[idx];
                                    var->is_read = true;
                                    foundVar = true;
                                    break;
                                }
                                s = s->parent;
                            }

                            bool foundFunc = false;
                            auto itFunc = mutable_bc->func_by_name.find(name);
                            if (itFunc != mutable_bc->func_by_name.end()) {
                                CompiledFunction& cf = mutable_bc->functions[itFunc->second];
                                cf.called = true;
                                foundFunc = true;
                            }

                            if (!foundVar && !foundFunc) {
                                kr_warn("%s", name);
                            }
                        }
                        break;
                    }

                    case OP_MARK_ALL_USED: {
                        if (original_global_scope) {
                            for (int i = 0; i < original_global_scope->var_count; ++i) {
                                Variable* var = &original_global_scope->vars[i];
                                var->is_read = true;
                            }
                        }
                        // 使用 mutable_bc 遍历functions
                        for (auto& cf : mutable_bc->functions) {
                            cf.called = true;
                        }
                        break;
                    }

                    default:
                        kr_error("未知操作码: %d", op);
                }
            }
            return false;
        } catch (const KRError& e) {
            while (!try_stack.empty() && try_stack.back().catch_pc == 0)
                try_stack.pop_back();
            if (try_stack.empty()) throw;

            TryFrame tf = std::move(try_stack.back());
            try_stack.pop_back();

            while (stack.size() > tf.stack_depth) {
                free_value(&stack.back()); stack.pop_back();
            }

            free_value(&caught_exception);
            caught_exception = make_string(e.what());
            has_caught = true;

            if (tf.finally_pc != 0) {
                TryFrame cf;
                cf.catch_pc    = 0;
                cf.finally_pc  = tf.finally_pc;
                cf.stack_depth = tf.stack_depth;
                try_stack.push_back(std::move(cf));
            }

            pc = tf.catch_pc;
            // 不 return，不递归；继续外层 while(true) 重新进 try
        }
        return false;
    }

    // 查找可写变量：优先 current_scope 快查（与解释器快线一致），
    // 未命中再沿作用域链向上。
    Variable* find_mutable_var(const char* name) {
        // 这里合并为单次遍历。
        const char c0 = name[0];
        for (Scope* s = current_scope; s; s = s->parent) {
            Variable* vars = s->vars;
            const int n = s->var_count;
            for (int i = 0; i < n; ++i) {
                Variable* v = &vars[i];
                if (v->name[0] == c0 && strcmp(v->name, name) == 0) {
                    return v;
                }
            }
        }
        return nullptr;
    }

    Variable* lookup_var_fast(const char* name) {
        // 首字符快速过滤 + 紧凑内层循环。
        const char c0 = name[0];
        for (Scope* s = current_scope; s; s = s->parent) {
            Variable* vars = s->vars;
            const int n = s->var_count;
            for (int i = 0; i < n; ++i) {
                Variable* v = &vars[i];
                if (v->name[0] == c0 && strcmp(v->name, name) == 0) {
                    return v;
                }
            }
        }
        return nullptr;
    }

    void vm_do_direct_call(const CompiledFunction& cf, int func_idx, int argc) {
        const int param_count = (int)cf.params.size();
        const bool has_vararg = !cf.vararg_name.empty();
    
        // ---- 1. 参数过多检查 ----
        if (!has_vararg && argc > param_count)
            kr_error("函数 '%s' 参数过多：期望 %d，实际 %d",
                     cf.name.c_str(), param_count, argc);
    
        // ---- 2. 缺参必须有默认值（无论是否可折叠）----
        for (int i = argc; i < param_count; ++i) {
            bool has = (i < (int)cf.param_defaults_idx.size() && cf.param_defaults_idx[i] >= 0)
                    || (i < (int)cf.param_default_code_off.size() && cf.param_default_code_off[i] != SIZE_MAX)
                    || (i < (int)cf.param_has_default.size() && cf.param_has_default[i]);
            if (!has)
                kr_error("函数 '%s' 缺少参数 '%s' 且无默认值",
                         cf.name.c_str(), cf.params[i].c_str());
        }
    
        // ---- 3. 固定参数类型检查（仅检查已提供）----
        int check_count = (argc < param_count) ? argc : param_count;
        for (int i = 0; i < check_count; ++i) {
            if (i >= (int)cf.param_types.size() || cf.param_types[i].empty()) continue;
            const Value& v = stack[stack.size() - (size_t)argc + i];
            if (!vm_check_type(v, cf.param_types[i]))
                kr_error("函数 '%s' 参数 '%s' 类型错误：期望 '%s'",
                         cf.name.c_str(), cf.params[i].c_str(),
                         cf.param_types[i].c_str());
        }
    
        // ---- 4. 可变参数类型检查 ----
        if (has_vararg && !cf.vararg_type.empty() && argc > param_count) {
            for (int i = param_count; i < argc; ++i) {
                const Value& v = stack[stack.size() - (size_t)argc + i];
                if (!vm_check_type(v, cf.vararg_type))
                    kr_error("函数 '%s' 可变参数类型错误：期望 '%s'",
                             cf.name.c_str(), cf.vararg_type.c_str());
            }
        }
    
        const size_t stack_base = stack.size() - (size_t)argc;
        push_scope();
    
        // ---- 5. 绑定已提供的固定参数 ----
        int bound = (argc < param_count) ? argc : param_count;
        for (int i = 0; i < bound; ++i) {
            Value v = stack[stack_base + i];
            bool is_const = (i < (int)cf.param_is_const.size())
                                ? cf.param_is_const[i] : false;
            declare_var_in_scope(current_scope, cf.params[i].c_str(), is_const, v);
        }
    
        // ---- 6. 对缺失参数求值默认值 ----
        for (int i = bound; i < param_count; ++i) {
            Value defval;
            int di = (i < (int)cf.param_defaults_idx.size())
                         ? cf.param_defaults_idx[i] : -1;
    
            if (di >= 0) {
                // 编译期已折叠 → 直接复制常量
                defval = copy_value(bc->constants[di]);
            } else if (i < (int)cf.param_default_code_off.size() &&
                       cf.param_default_code_off[i] != SIZE_MAX) {
                //  运行默认值代码块：在当前参数作用域里求值
                size_t save_pc = pc;
                pc = cf.param_default_code_off[i];
                run_until(cf.param_default_code_end[i]);
                defval = std::move(stack.back());
                stack.pop_back();
                pc = save_pc;
            } else {
                defval = make_null();   // 前面已检查，不会走到
            }
    
            bool is_const = (i < (int)cf.param_is_const.size())
                                ? cf.param_is_const[i] : false;
            declare_var_in_scope(current_scope, cf.params[i].c_str(),
                                 is_const, defval);
        }
    
        // ---- 7. 可变参数收集 ----
        if (has_vararg) {
            const int vararg_count = (argc > param_count) ? (argc - param_count) : 0;
            Value* elems = nullptr;
            if (vararg_count > 0) {
                elems = (Value*)malloc(vararg_count * sizeof(Value));
                for (int i = 0; i < vararg_count; ++i)
                    elems[i] = stack[stack_base + param_count + i];
            }
            Value arr = make_array(elems, vararg_count);
            if (elems) {
                for (int i = 0; i < vararg_count; ++i) free_value(&elems[i]);
                free(elems);
            }
            for (int i = param_count; i < argc; ++i)
                free_value(&stack[stack_base + i]);
            declare_var_in_scope(current_scope, cf.vararg_name.c_str(), false, arr);
        }
    
        // ---- 8. 截断参数槽，推入帧 ----
        stack.resize(stack_base);
        CompilerCallFrame frame;
        frame.return_pc  = pc;
        frame.stack_base = stack_base;
        frame.func_idx   = func_idx;
        frames.push_back(frame);
        frame_rule_keys.push_back(std::string());
    
        pc = cf.code_offset;
    }

    // 统一的"把变量值压栈"逻辑。
    // expand_stdwert = true  → OP_GET_VAR 语义（展开 __stdwert）
    // expand_stdwert = false → OP_GET_VAR_RAW 语义（不展开）
    void vm_push_var_value(Variable* var, bool expand_stdwert) {
        // ---- 1. 惰性变量：先求值到 cached_value ----
        if (var->is_lazy) {
            force_eval_lazy(var);
            stack.push_back(copy_value(var->cached_value));
            return;
        }

        // ---- 2. 非对象 / RAW：直接压值 ----
        if (!expand_stdwert || var->value.type != VAL_OBJECT) {
            stack.push_back(copy_value(var->value));
            return;
        }

        // ---- 3. 普通读 + 对象值：尝试展开 __stdwert ----
        for (int i = 0; i < var->value.obj_val.count; ++i) {
            if (strcmp(var->value.obj_val.entries[i].key, "__stdwert") == 0) {
                stack.push_back(copy_value(var->value.obj_val.entries[i].value));
                return;
            }
        }
        // 没有 __stdwert → 展开失败，返回对象本身
        stack.push_back(copy_value(var->value));
    }

    Value vm_call_method_sync(const CompiledFunction& mf, int func_idx,
                            Value& receiver,
                            Value* args, int argc) {
        const int  param_count = (int)mf.params.size();
        const bool has_vararg  = !mf.vararg_name.empty();

        // ---- 0. 参数检查（与 vm_do_direct_call 保持一致）----
        if (!has_vararg && argc > param_count)
            kr_error("方法 '%s' 参数过多：期望 %d，实际 %d",
                    mf.name.c_str(), param_count, argc);
        for (int i = argc; i < param_count; ++i) {
            bool has = (i < (int)mf.param_defaults_idx.size()
                            && mf.param_defaults_idx[i] >= 0)
                    || (i < (int)mf.param_default_code_off.size()
                            && mf.param_default_code_off[i] != SIZE_MAX)
                    || (i < (int)mf.param_has_default.size()
                            && mf.param_has_default[i]);
            if (!has)
                kr_error("方法 '%s' 缺少参数 '%s'",
                        mf.name.c_str(), mf.params[i].c_str());
        }

        // ---- 1. 方法作用域：绑定 dies + 参数 ----
        push_scope();
        declare_var_in_scope(current_scope, "dies", false, copy_value(receiver));

        const int bound = (argc < param_count) ? argc : param_count;
        for (int i = 0; i < bound; ++i) {
            bool is_const = (i < (int)mf.param_is_const.size())
                                ? mf.param_is_const[i] : false;
            declare_var_in_scope(current_scope, mf.params[i].c_str(),
                                is_const, copy_value(args[i]));
        }

        // 缺失参数：编译期折叠的常量直接取；运行时代码块惰性求值
        for (int i = bound; i < param_count; ++i) {
            Value defval = make_null();
            int di = (i < (int)mf.param_defaults_idx.size())
                        ? mf.param_defaults_idx[i] : -1;
            if (di >= 0) {
                defval = copy_value(bc->constants[di]);
            } else if (i < (int)mf.param_default_code_off.size()
                    && mf.param_default_code_off[i] != SIZE_MAX) {
                size_t save = pc;
                pc = mf.param_default_code_off[i];
                run_until(mf.param_default_code_end[i]);
                defval = std::move(stack.back());
                stack.pop_back();
                pc = save;
            }
            declare_var_in_scope(current_scope, mf.params[i].c_str(),
                                false, defval);
        }

        // 变参收集
        if (has_vararg) {
            const int vcount = (argc > param_count) ? (argc - param_count) : 0;
            Value* elems = nullptr;
            if (vcount > 0) {
                elems = (Value*)malloc((size_t)vcount * sizeof(Value));
                for (int i = 0; i < vcount; ++i)
                    elems[i] = copy_value(args[param_count + i]);
            }
            Value arr = make_array(elems, vcount);
            if (elems) free(elems);
            declare_var_in_scope(current_scope, mf.vararg_name.c_str(), false, arr);
        }

        // ---- 2. 推哨兵帧：return_pc = SIZE_MAX ----
        //   OP_RETURN 会把 pc 置为 SIZE_MAX，于是 run_until(SIZE_MAX)
        //   的 `while (pc < SIZE_MAX)` 立即退出。
        //   同时压一个空 rule_key，保持 frames / frame_rule_keys 同步。
        const size_t save_pc    = pc;
        const size_t base_stack = stack.size();

        CompilerCallFrame frame;
        frame.return_pc  = SIZE_MAX;
        frame.stack_base = base_stack;
        frame.func_idx   = func_idx;
        frames.push_back(frame);
        frame_rule_keys.push_back(std::string());

        // ---- 3. 同步跑方法体 ----
        bool ok = false;
        try {
            pc = mf.code_offset;
            run_until(SIZE_MAX);
            ok = true;
        } catch (...) {
            // 异常路径：帧若未被 OP_RETURN 消费则手动弹掉
            if (!frames.empty() && frames.back().return_pc == SIZE_MAX)
                frames.pop_back();
            if (!frame_rule_keys.empty())
                frame_rule_keys.pop_back();
            pc = save_pc;
            throw;
        }

        // ---- 4. 恢复 pc，取返回值 ----
        pc = save_pc;
        Value result = make_null();
        if (ok && stack.size() > base_stack) {
            result = std::move(stack.back());
            stack.pop_back();
        }
        return result;
    }

    // ---------------------------------------------------------------
    // 受限的"左值索引/键表达式"求值器
    //   - 只认字面量和 VM 变量、以及它们的算术组合
    //   - 绝不调用解释器的 eval_expr
    //   - 支持不了就直接报错，好过悄悄崩
    // ---------------------------------------------------------------
    Value vm_eval_lvalue_index(ASTNode* node) {
        if (!node) return make_null();
        switch (node->type) {
            case NODE_NUMBER: {
                const char* str = node->data.number_str;
                if (!str) kr_error("vm_eval_lvalue_index: 空数字字面量");

                // 快线：strtoll 可直接吃下
                errno = 0;
                char* end = nullptr;
                long long v = strtoll(str, &end, 10);
                if (end && *end == '\0' && end != str && errno == 0)
                    return make_int64((int64_t)v);

                // 回退 GMP：0x / 0b / 0o / 大整数
                mpz_t tmp; mpz_init(tmp);
                int base = 10;
                const char* ns = str;
                if      (strncmp(str, "0x", 2) == 0 || strncmp(str, "0X", 2) == 0) { base = 16; ns = str + 2; }
                else if (strncmp(str, "0b", 2) == 0 || strncmp(str, "0B", 2) == 0) { base = 2;  ns = str + 2; }
                else if (strncmp(str, "0o", 2) == 0 || strncmp(str, "0O", 2) == 0) { base = 8;  ns = str + 2; }
                if (mpz_set_str(tmp, ns, base) != 0) {
                    mpz_clear(tmp);
                    kr_error("vm_eval_lvalue_index: 无效整数常量 '%s'", str);
                }
                Value r = make_int_auto(tmp);
                mpz_clear(tmp);
                return r;
            }
            case NODE_STRING:
                return make_string(node->data.string ? node->data.string : "");
            case NODE_NULL:
                return make_null();
            case NODE_VARIABLE: {
                Variable* var = find_mutable_var(node->data.var_name);
                if (!var) kr_error("vm_eval_lvalue_index: 未定义变量 '%s'",
                                node->data.var_name);
                var = resolve_alias(var);
                // 惰性变量需要先在 VM 里求值
                if (var->is_lazy) force_eval_lazy(var);
                return copy_value(var->is_lazy ? var->cached_value : var->value);
            }
            case NODE_BINARY: {
                Value l = vm_eval_lvalue_index(node->data.binary.left);
                Value r = vm_eval_lvalue_index(node->data.binary.right);
                Value result = make_null();
                switch (node->data.binary.op) {
                    case '+': result = op_add(l, r); break;
                    case '-': result = op_sub(l, r); break;
                    case '*': result = op_mul(l, r); break;
                    case '/': result = op_div(l, r); break;
                    case '%': result = op_mod(l, r); break;
                    default:
                        free_value(&l); free_value(&r);
                        kr_error("vm_eval_lvalue_index: 不支持的二元运算符 '%c'",
                                node->data.binary.op);
                }
                free_value(&l); free_value(&r);
                return result;
            }
            default:
                kr_error("vm_eval_lvalue_index: 不支持的节点类型 %d",
                        (int)node->type);
        }
        return make_null();
    }

    // ---------------------------------------------------------------
    // VM 版 get_mutable_ptr
    //   支持：变量、arr[i]、obj.key、以及它们的任意嵌套链
    //   返回指向变量存储/数组元素/对象字段的裸指针
    //   不支持则返回 nullptr（调用方报"左值不可寻址"）
    // ---------------------------------------------------------------
    Value* vm_get_mutable_ptr(ASTNode* node) {
        if (!node) return nullptr;

        switch (node->type) {
            case NODE_VARIABLE: {
                Variable* var = find_mutable_var(node->data.var_name);
                if (!var) return nullptr;
                var = resolve_alias(var);
                return &var->value;
            }
            case NODE_ARRAY_ACCESS: {
                Value* base = vm_get_mutable_ptr(node->data.array_access.array);
                if (!base) return nullptr;

                Value idx = vm_eval_lvalue_index(node->data.array_access.index);
                long long i = value_to_ll(idx);
                free_value(&idx);

                if (base->type != VAL_ARRAY) return nullptr;
                if (i < 0 || i >= base->arr_val.length) return nullptr;
                return &base->arr_val.elements[i];
            }
            case NODE_OBJECT_ACCESS: {
                Value* obj = vm_get_mutable_ptr(node->data.object_access.obj);
                if (!obj || obj->type != VAL_OBJECT) return nullptr;
                const char* key = node->data.object_access.key;
                for (int i = 0; i < obj->obj_val.count; ++i) {
                    if (strcmp(obj->obj_val.entries[i].key, key) == 0)
                        return &obj->obj_val.entries[i].value;
                }
                return nullptr;
            }
            default:
                return nullptr;
        }
    }

    static inline bool is_mutating_receiver_method(const char* method) {
        if (!method) return false;
    
        // ---- 数组原地方法 ----
        if (strcmp(method, "anf")       == 0) return true;  // 尾部追加
        if (strcmp(method, "sort")      == 0) return true;  // 原地排序
        if (strcmp(method, "lösch")     == 0) return true;  // 删除索引（返回被删元素）
        if (strcmp(method, "umk")       == 0) return true;  // 原地反转
        if (strcmp(method, "einfuegen") == 0) return true;  // 原地插入
        if (strcmp(method, "entferne")  == 0) return true;  // 原地删除所有匹配元素
        if (strcmp(method, "mische")    == 0) return true;  // 原地随机打乱
    
        // ---- 对象原地方法（如果将来有，加在这里）----
        return false;
    }
};

static Value vm_builtin_dispatch(BuiltinId id, Value* args, int argc,
                                 const Bytecode* bc, void* ctx)
{
    // 常用快捷断言
    auto A = [&](int i) -> Value& { return args[i]; };
    #define REQ(N, msg) do { if (argc != (N)) kr_error(msg); } while(0)

    switch (id) {

    // ================================================================
    // 数学
    // ================================================================
    case BI_SQRT: {
        REQ(1, "sqrt/wurz 需要 1 个参数");
        if (!bi_is_num(A(0))) kr_error("sqrt: 参数必须为数值");
        // 快路径：非负 int64 且是完全平方数 → 返回 int64
        if (A(0).type == VAL_INT64 && A(0).int64_val >= 0) {
            int64_t x = A(0).int64_val;
            int64_t r = (int64_t)std::sqrt((double)x);
            // 修正整数误差
            while ((__int128)r * r > x) --r;
            while ((__int128)(r+1) * (r+1) <= x) ++r;
            if ((__int128)r * r == x) return make_int64(r);
        }
        double x = bi_to_double(A(0));
        if (x < 0) kr_error("负数不能开方");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::sqrt(x));
        Value v = make_float(t); mpf_clear(t);
        return v;
    }
    case BI_CBRT: {
        REQ(1, "cbrt/kub 需要 1 个参数");
        return bi_math_unary(A(0), "cbrt", std::cbrt);
    }
    case BI_ABS: {
        REQ(1, "abs/btr 需要 1 个参数");
        // 快路径：int64
        if (A(0).type == VAL_INT64) {
            int64_t v = A(0).int64_val;
            if (v == INT64_MIN) {
                // 溢出到 GMP
                mpz_t z; mpz_init_set_si(z, v); mpz_neg(z, z);
                Value r = make_int_auto(z); mpz_clear(z); return r;
            }
            return make_int64(v < 0 ? -v : v);
        }
        if (A(0).type == VAL_INT) {
            mpz_t z; mpz_init(z); mpz_abs(z, *A(0).big_int);
            Value r = value_from_mpz_result(z); mpz_clear(z); return r;
        }
        if (A(0).type == VAL_FLOAT) {
            mpf_t t; mpf_init(t); mpf_abs(t, *A(0).mpf_val);
            Value v = make_float(t); mpf_clear(t); return v;
        }
        kr_error("abs: 参数必须为数值");
    }
    case BI_SIN:  REQ(1, "sin 需要 1 个参数");  return bi_math_unary(A(0), "sin",  std::sin);
    case BI_COS:  REQ(1, "cos 需要 1 个参数");  return bi_math_unary(A(0), "cos",  std::cos);
    case BI_TAN:  REQ(1, "tan 需要 1 个参数");  return bi_math_unary(A(0), "tan",  std::tan);
    case BI_COT:  REQ(1, "cot 需要 1 个参数");  return bi_math_unary(A(0), "cot",  [](double x){return 1.0/std::tan(x);} );
    case BI_SEC:  REQ(1, "sec 需要 1 个参数");  return bi_math_unary(A(0), "sec",  [](double x){return 1.0/std::cos(x);} );
    case BI_CSC:  REQ(1, "csc 需要 1 个参数");  return bi_math_unary(A(0), "csc",  [](double x){return 1.0/std::sin(x);} );
    case BI_ASIN: {
        REQ(1, "asin 需要 1 个参数");
        double x = bi_to_double(A(0));
        if (x < -1 || x > 1) kr_error("asin 定义域 [-1,1]");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::asin(x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_ACOS: {
        REQ(1, "acos 需要 1 个参数");
        double x = bi_to_double(A(0));
        if (x < -1 || x > 1) kr_error("acos 定义域 [-1,1]");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::acos(x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_ATAN: REQ(1, "atan 需要 1 个参数"); return bi_math_unary(A(0), "atan", std::atan);
    case BI_ATAN2: {
        REQ(2, "atan2 需要 2 个参数 (y, x)");
        double y = bi_to_double(A(0)), x = bi_to_double(A(1));
        mpf_t t; mpf_init(t); mpf_set_d(t, std::atan2(y, x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_SINH: REQ(1, "sinh 需要 1 个参数"); return bi_math_unary(A(0), "sinh", std::sinh);
    case BI_COSH: REQ(1, "cosh 需要 1 个参数"); return bi_math_unary(A(0), "cosh", std::cosh);
    case BI_TANH: REQ(1, "tanh 需要 1 个参数"); return bi_math_unary(A(0), "tanh", std::tanh);
    case BI_ASINH:REQ(1, "asinh 需要 1 个参数");return bi_math_unary(A(0), "asinh", std::asinh);
    case BI_ACOSH:{
        REQ(1, "acosh 需要 1 个参数");
        double x = bi_to_double(A(0));
        if (x < 1) kr_error("acosh 定义域 x ≥ 1");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::acosh(x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_ATANH:{
        REQ(1, "atanh 需要 1 个参数");
        double x = bi_to_double(A(0));
        if (x <= -1 || x >= 1) kr_error("atanh 定义域 (-1,1)");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::atanh(x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_EXP: REQ(1, "exp 需要 1 个参数"); return bi_math_unary(A(0), "exp", std::exp);
    case BI_LN: {
        REQ(1, "ln 需要 1 个参数");
        double x = bi_to_double(A(0));
        if (x <= 0) kr_error("ln 定义域 x > 0");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::log(x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_LOG: {
        REQ(1, "log/lg 需要 1 个参数");
        double x = bi_to_double(A(0));
        if (x <= 0) kr_error("log 定义域 x > 0");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::log10(x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_LD: {
        REQ(1, "ld 需要 1 个参数");
        double x = bi_to_double(A(0));
        if (x <= 0) kr_error("ld 定义域 x > 0");
        mpf_t t; mpf_init(t); mpf_set_d(t, std::log2(x));
        Value v = make_float(t); mpf_clear(t); return v;
    }
    case BI_RAND: {
        REQ(0, "rand/zuf 不需要参数");
        return make_int64((int64_t)std::rand());
    }
    case BI_SRAND: {
        REQ(1, "srand/setze 需要 1 个参数");
        std::srand((unsigned)value_to_ll(A(0)));
        return make_null();
    }

    // ================================================================
    // 微积分 / 数值方法
    // ================================================================
    case BI_ABL: {
        if (argc < 2 || argc > 3) kr_error("abl 需要 2 或 3 个参数：函数, x, [步长]");
        if (A(0).type != VAL_FUNCTION) kr_error("abl: 第一个参数必须是函数");
        double x = bi_to_double(A(1));
        double h = (argc == 3) ? bi_to_double(A(2)) : 1e-5;
        if (h == 0.0) kr_error("abl: 步长不能为零");
        Value ap = make_float(x + h), am = make_float(x - h);
        Value fp = vm_invoke(A(0), &ap, 1);
        Value fm = vm_invoke(A(0), &am, 1);
        free_value(&ap); free_value(&am);
        double fpd = bi_to_double(fp), fmd = bi_to_double(fm);
        free_value(&fp); free_value(&fm);
        return make_float((fpd - fmd) / (2 * h));
    }

    case BI_INTE: {
        if (argc < 3 || argc > 4)
            kr_error("inte 需要 3 或 4 个参数：函数, a, b, [n]");
        if (A(0).type != VAL_FUNCTION) kr_error("inte: 第一个参数必须是函数");
        double a = bi_to_double(A(1));
        double b = bi_to_double(A(2));
        int n = (argc == 4) ? (int)value_to_ll(A(3)) : 100;
        if (n < 1) n = 1;
        double h = (b - a) / n, sum = 0.0;
        for (int i = 0; i <= n; ++i) {
            Value arg = make_float(a + i * h);
            Value fv  = vm_invoke(A(0), &arg, 1);
            free_value(&arg);
            double fx = bi_to_double(fv);
            free_value(&fv);
            if (i == 0 || i == n) sum += fx / 2.0; else sum += fx;
        }
        return make_float(sum * h);
    }

    case BI_AB2: {
        if (argc < 2 || argc > 3) kr_error("ab2 需要 2 或 3 个参数：函数, x, [步长]");
        if (A(0).type != VAL_FUNCTION) kr_error("ab2: 第一个参数必须是函数");
        double x = bi_to_double(A(1));
        double h = (argc == 3) ? bi_to_double(A(2)) : 1e-5;
        if (h == 0.0) kr_error("ab2: 步长不能为零");
        Value ap = make_float(x + h), ac = make_float(x), am = make_float(x - h);
        Value fp = vm_invoke(A(0), &ap, 1);
        Value fc = vm_invoke(A(0), &ac, 1);
        Value fm = vm_invoke(A(0), &am, 1);
        free_value(&ap); free_value(&ac); free_value(&am);
        double fpd = bi_to_double(fp), fcd = bi_to_double(fc), fmd = bi_to_double(fm);
        free_value(&fp); free_value(&fc); free_value(&fm);
        return make_float((fpd - 2 * fcd + fmd) / (h * h));
    }

    case BI_SIMP: {
        if (argc < 3 || argc > 4)
            kr_error("simp 需要 3 或 4 个参数：函数, a, b, [n]");
        if (A(0).type != VAL_FUNCTION) kr_error("simp: 第一个参数必须是函数");
        double a = bi_to_double(A(1));
        double b = bi_to_double(A(2));
        int n = (argc == 4) ? (int)value_to_ll(A(3)) : 100;
        if (n % 2) ++n;
        if (n < 2) n = 2;
        double h = (b - a) / n, sum = 0.0;
        for (int i = 0; i <= n; ++i) {
            Value arg = make_float(a + i * h);
            Value fv  = vm_invoke(A(0), &arg, 1);
            free_value(&arg);
            double fx = bi_to_double(fv);
            free_value(&fv);
            if (i == 0 || i == n) sum += fx;
            else if (i % 2 == 1)  sum += 4 * fx;
            else                  sum += 2 * fx;
        }
        return make_float(sum * h / 3.0);
    }

    case BI_GRAD: {
        if (argc < 2)
            kr_error("grad 需要至少 2 个参数：函数, 点坐标...");
        if (A(0).type != VAL_FUNCTION) kr_error("grad: 第一个参数必须是函数");

        int dim;
        double h = 1e-5;
        if (argc > 2 && A(argc - 1).type == VAL_FLOAT) {
            h = bi_to_double(A(argc - 1));
            dim = argc - 2;
        } else {
            dim = argc - 1;
        }
        if (dim < 1) kr_error("grad: 需要至少一个坐标");

        int target_n = A(0).func_val.param_count;
        if (target_n != 1 && target_n != dim)
            kr_error("grad: 目标函数参数个数 (%d) 与点维度 (%d) 不匹配",
                     target_n, dim);

        Value* grad_vals = (Value*)malloc((size_t)dim * sizeof(Value));
        for (int i = 0; i < dim; ++i) {
            Value* pp = (Value*)malloc((size_t)dim * sizeof(Value));
            Value* pm = (Value*)malloc((size_t)dim * sizeof(Value));
            for (int j = 0; j < dim; ++j) {
                if (j == i) {
                    double base = bi_to_double(A(j + 1));
                    pp[j] = make_float(base + h);
                    pm[j] = make_float(base - h);
                } else {
                    pp[j] = copy_value(A(j + 1));
                    pm[j] = copy_value(A(j + 1));
                }
            }
            double fp, fm;
            if (target_n == 1) {
                Value pa = make_array(pp, dim);
                Value ma = make_array(pm, dim);
                Value fpp = vm_invoke(A(0), &pa, 1);
                Value fmm = vm_invoke(A(0), &ma, 1);
                fp = bi_to_double(fpp);
                fm = bi_to_double(fmm);
                free_value(&pa); free_value(&ma);
                free_value(&fpp); free_value(&fmm);
            } else {
                Value fpp = vm_invoke(A(0), pp, dim);
                Value fmm = vm_invoke(A(0), pm, dim);
                fp = bi_to_double(fpp);
                fm = bi_to_double(fmm);
                free_value(&fpp); free_value(&fmm);
            }
            for (int j = 0; j < dim; ++j) {
                free_value(&pp[j]); free_value(&pm[j]);
            }
            free(pp); free(pm);
            grad_vals[i] = make_float((fp - fm) / (2 * h));
        }
        Value r = make_array(grad_vals, dim);
        for (int i = 0; i < dim; ++i) free_value(&grad_vals[i]);
        free(grad_vals);
        return r;
    }

    case BI_NULLST: {
        if (argc < 3 || argc > 4)
            kr_error("nullst 需要 3 或 4 个参数：函数, a, b, [容差]");
        if (A(0).type != VAL_FUNCTION) kr_error("nullst: 第一个参数必须是函数");
        double a = bi_to_double(A(1));
        double b = bi_to_double(A(2));
        double tol = (argc == 4) ? bi_to_double(A(3)) : 1e-7;
        if (tol <= 0) tol = 1e-7;

        auto eval_f = [&](double x) -> double {
            Value arg = make_float(x);
            Value fv  = vm_invoke(A(0), &arg, 1);
            free_value(&arg);
            double r = bi_to_double(fv);
            free_value(&fv);
            return r;
        };
        double fa = eval_f(a), fb = eval_f(b);
        if (fa * fb > 0) kr_error("nullst: 区间端点函数值同号");

        int iter = 0;
        while (b - a > tol && iter < 1000) {
            double c = (a + b) / 2.0;
            double fc = eval_f(c);
            if (fc == 0.0) break;
            if (fa * fc < 0) { b = c; fb = fc; }
            else             { a = c; fa = fc; }
            ++iter;
        }
        return make_float((a + b) / 2.0);
    }

    case BI_EULER: {
        if (argc != 5)
            kr_error("euler 需要 5 个参数：函数, x0, y0, 步长, 步数");
        if (A(0).type != VAL_FUNCTION) kr_error("euler: 第一个参数必须是函数");
        double x = bi_to_double(A(1));
        double y = bi_to_double(A(2));
        double h = bi_to_double(A(3));
        int steps = (int)value_to_ll(A(4));
        if (steps < 0) steps = 0;

        int target_n = A(0).func_val.param_count;
        if (target_n != 1 && target_n != 2)
            kr_error("euler: 目标函数必须接受 1 个数组或 2 个独立参数 (x, y)");

        Value* ys = (Value*)malloc((size_t)(steps + 1) * sizeof(Value));
        ys[0] = make_float(y);
        for (int i = 0; i < steps; ++i) {
            double slope;
            if (target_n == 1) {
                Value e[2] = { make_float(x), make_float(y) };
                Value pt = make_array(e, 2);
                Value fv = vm_invoke(A(0), &pt, 1);
                free_value(&pt);
                slope = bi_to_double(fv);
                free_value(&fv);
            } else {
                Value fa[2] = { make_float(x), make_float(y) };
                Value fv = vm_invoke(A(0), fa, 2);
                free_value(&fa[0]); free_value(&fa[1]);
                slope = bi_to_double(fv);
                free_value(&fv);
            }
            y += h * slope;
            x += h;
            ys[i + 1] = make_float(y);
        }
        Value r = make_array(ys, steps + 1);
        for (int i = 0; i <= steps; ++i) free_value(&ys[i]);
        free(ys);
        return r;
    }

    case BI_PABL: {
        if (argc < 3 || argc > 4)
            kr_error("pabl 需要 3 或 4 个参数：函数, 点数组, 变量索引, [步长]");
        if (A(0).type != VAL_FUNCTION) kr_error("pabl: 第一个参数必须是函数");
        if (A(1).type != VAL_ARRAY)    kr_error("pabl: 第二个参数必须是数组");
        int idx = (int)value_to_ll(A(2));
        double h = (argc == 4) ? bi_to_double(A(3)) : 1e-5;
        if (idx < 0 || idx >= A(1).arr_val.length) kr_error("pabl: 变量索引越界");

        int target_n = A(0).func_val.param_count;
        int dim      = A(1).arr_val.length;

        Value pb = copy_value(A(1));
        Value pp = copy_value(A(1));
        Value pm = copy_value(A(1));
        double orig = bi_to_double(pp.arr_val.elements[idx]);
        free_value(&pp.arr_val.elements[idx]);
        pp.arr_val.elements[idx] = make_float(orig + h);
        free_value(&pm.arr_val.elements[idx]);
        pm.arr_val.elements[idx] = make_float(orig - h);

        auto call_t = [&](Value& pt) -> double {
            if (target_n == 1) {
                Value res = vm_invoke(A(0), &pt, 1);
                double v = bi_to_double(res);
                free_value(&res);
                return v;
            } else if (target_n == dim) {
                Value* up = (Value*)malloc((size_t)dim * sizeof(Value));
                for (int i = 0; i < dim; ++i)
                    up[i] = copy_value(pt.arr_val.elements[i]);
                Value res = vm_invoke(A(0), up, dim);
                for (int i = 0; i < dim; ++i) free_value(&up[i]);
                free(up);
                double v = bi_to_double(res);
                free_value(&res);
                return v;
            }
            kr_error("pabl: 参数个数 (%d) 与点维度 (%d) 不匹配", target_n, dim);
            return 0.0;
        };
        double fp = call_t(pp);
        double fm = call_t(pm);
        free_value(&pb); free_value(&pp); free_value(&pm);
        return make_float((fp - fm) / (2 * h));
    }

    case BI_AB3: {
        if (argc < 2 || argc > 3)
            kr_error("ab3 需要 2 或 3 个参数：函数, x, [步长]");
        if (A(0).type != VAL_FUNCTION) kr_error("ab3: 第一个参数必须是函数");
        double x0 = bi_to_double(A(1));
        double h  = (argc == 3) ? bi_to_double(A(2)) : 1e-4;

        Value a2h  = make_float(x0 + 2 * h);
        Value ah   = make_float(x0 + h);
        Value amh  = make_float(x0 - h);
        Value a2mh = make_float(x0 - 2 * h);

        Value f2h  = vm_invoke(A(0), &a2h,  1);
        Value fh_  = vm_invoke(A(0), &ah,   1);
        Value fmh  = vm_invoke(A(0), &amh,  1);
        Value f2mh = vm_invoke(A(0), &a2mh, 1);

        free_value(&a2h); free_value(&ah); free_value(&amh); free_value(&a2mh);
        double v = (bi_to_double(f2h) - 2 * bi_to_double(fh_)
                  + 2 * bi_to_double(fmh) - bi_to_double(f2mh))
                  / (2 * h * h * h);
        free_value(&f2h); free_value(&fh_); free_value(&fmh); free_value(&f2mh);
        return make_float(v);
    }

    case BI_AB4: {
        if (argc < 2 || argc > 3)
            kr_error("ab4 需要 2 或 3 个参数：函数, x, [步长]");
        if (A(0).type != VAL_FUNCTION) kr_error("ab4: 第一个参数必须是函数");
        double x0 = bi_to_double(A(1));
        double h  = (argc == 3) ? bi_to_double(A(2)) : 1e-2;
        if (h == 0.0) kr_error("ab4: 步长不能为零");

        Value a2h  = make_float(x0 + 2 * h);
        Value ah   = make_float(x0 + h);
        Value a0   = make_float(x0);
        Value amh  = make_float(x0 - h);
        Value a2mh = make_float(x0 - 2 * h);

        Value f2h  = vm_invoke(A(0), &a2h,  1);
        Value fh_  = vm_invoke(A(0), &ah,   1);
        Value f0   = vm_invoke(A(0), &a0,   1);
        Value fmh  = vm_invoke(A(0), &amh,  1);
        Value f2mh = vm_invoke(A(0), &a2mh, 1);

        free_value(&a2h); free_value(&ah); free_value(&a0);
        free_value(&amh); free_value(&a2mh);

        double num = bi_to_double(f2h) - 4 * bi_to_double(fh_)
                   + 6 * bi_to_double(f0) - 4 * bi_to_double(fmh)
                   + bi_to_double(f2mh);
        free_value(&f2h); free_value(&fh_); free_value(&f0);
        free_value(&fmh); free_value(&f2mh);
        double h4 = h * h * h * h;
        return make_float(num / h4);
    }

    case BI_RK: {
        if (argc < 5 || argc > 6)
            kr_error("rk 需要 5 或 6 个参数：函数, x0, y0, 步长, 步数, [容差]");
        if (A(0).type != VAL_FUNCTION) kr_error("rk: 第一个参数必须是函数");
        double x0 = bi_to_double(A(1));
        double h  = bi_to_double(A(3));
        int    n  = (int)value_to_ll(A(4));
        if (n < 0) kr_error("rk: 步数不能为负数");
        double tol = (argc == 6) ? bi_to_double(A(5)) : 1e-6;
        if (tol <= 0) tol = 1e-6;

        int  target_n  = A(0).func_val.param_count;
        bool is_vector = (A(2).type == VAL_ARRAY);
        int  dim       = is_vector ? A(2).arr_val.length : 1;

        // 当前 y 向量（double 表示）
        std::vector<double> y((size_t)dim);
        if (is_vector) {
            for (int i = 0; i < dim; ++i)
                y[i] = bi_to_double(A(2).arr_val.elements[i]);
        } else {
            y[0] = bi_to_double(A(2));
        }

        // 计算导数，返回 double 向量
        auto deriv_d = [&](double xv, const std::vector<double>& yv)
                            -> std::vector<double> {
            Value res;
            if (is_vector) {
                if (target_n != 2)
                    kr_error("rk: 向量模式要求函数接受 (t, y) 两个参数");
                Value* ye = (Value*)malloc((size_t)dim * sizeof(Value));
                for (int i = 0; i < dim; ++i) ye[i] = make_float(yv[i]);
                Value ya = make_array(ye, dim);
                for (int i = 0; i < dim; ++i) free_value(&ye[i]);
                free(ye);
                Value fa[2] = { make_float(xv), ya };
                res = vm_invoke(A(0), fa, 2);
                free_value(&fa[0]); free_value(&fa[1]);
            } else {
                if (target_n == 1) {
                    Value e[2] = { make_float(xv), make_float(yv[0]) };
                    Value pt = make_array(e, 2);
                    res = vm_invoke(A(0), &pt, 1);
                    free_value(&pt);
                } else if (target_n == 2) {
                    Value fa[2] = { make_float(xv), make_float(yv[0]) };
                    res = vm_invoke(A(0), fa, 2);
                    free_value(&fa[0]); free_value(&fa[1]);
                } else {
                    kr_error("rk: 目标函数必须接受 1 个数组或 2 个独立参数");
                }
            }
            std::vector<double> r((size_t)dim, 0.0);
            if (res.type == VAL_ARRAY) {
                for (int i = 0; i < dim && i < res.arr_val.length; ++i)
                    r[i] = bi_to_double(res.arr_val.elements[i]);
            } else {
                r[0] = bi_to_double(res);
            }
            free_value(&res);
            return r;
        };

        const double c2=1.0/4, c3=3.0/8, c4=12.0/13, c5=1.0, c6=1.0/2;
        const double a21=1.0/4;
        const double a31=3.0/32, a32=9.0/32;
        const double a41=1932.0/2197, a42=-7200.0/2197, a43=7296.0/2197;
        const double a51=439.0/216, a52=-8.0, a53=3680.0/513, a54=-845.0/4104;
        const double a61=-8.0/27, a62=2.0, a63=-3544.0/2565, a64=1859.0/4104, a65=-11.0/40;
        const double b41=25.0/216, b43=1408.0/2565, b44=2197.0/4104, b45=-1.0/5;
        const double b51=16.0/135, b53=6656.0/12825, b54=28561.0/56430, b55=-9.0/50, b56=2.0/55;

        auto rkf45_step = [&](double x, const std::vector<double>& yv, double hh,
                              std::vector<double>& yn, double& error) {
            auto k1 = deriv_d(x, yv);
            std::vector<double> y2((size_t)dim), y3((size_t)dim), y4((size_t)dim),
                                y5((size_t)dim), y6((size_t)dim);
            for (int i = 0; i < dim; ++i) y2[i] = yv[i] + hh * a21 * k1[i];
            auto k2 = deriv_d(x + c2*hh, y2);
            for (int i = 0; i < dim; ++i)
                y3[i] = yv[i] + hh * (a31*k1[i] + a32*k2[i]);
            auto k3 = deriv_d(x + c3*hh, y3);
            for (int i = 0; i < dim; ++i)
                y4[i] = yv[i] + hh * (a41*k1[i] + a42*k2[i] + a43*k3[i]);
            auto k4 = deriv_d(x + c4*hh, y4);
            for (int i = 0; i < dim; ++i)
                y5[i] = yv[i] + hh * (a51*k1[i] + a52*k2[i] + a53*k3[i] + a54*k4[i]);
            auto k5 = deriv_d(x + c5*hh, y5);
            for (int i = 0; i < dim; ++i)
                y6[i] = yv[i] + hh * (a61*k1[i] + a62*k2[i] + a63*k3[i]
                                     + a64*k4[i] + a65*k5[i]);
            auto k6 = deriv_d(x + c6*hh, y6);

            yn.resize((size_t)dim);
            for (int i = 0; i < dim; ++i)
                yn[i] = yv[i] + hh * (b51*k1[i] + b53*k3[i] + b54*k4[i]
                                     + b55*k5[i] + b56*k6[i]);
            double max_err = 0.0;
            for (int i = 0; i < dim; ++i) {
                double y4v = yv[i] + hh * (b41*k1[i] + b43*k3[i]
                                         + b44*k4[i] + b45*k5[i]);
                double e = std::fabs(y4v - yn[i]);
                if (e > max_err) max_err = e;
            }
            error = max_err;
        };

        auto pack_y = [&](const std::vector<double>& yv) -> Value {
            if (is_vector) {
                Value* ye = (Value*)malloc((size_t)dim * sizeof(Value));
                for (int i = 0; i < dim; ++i) ye[i] = make_float(yv[i]);
                Value r = make_array(ye, dim);
                for (int i = 0; i < dim; ++i) free_value(&ye[i]);
                free(ye);
                return r;
            }
            return make_float(yv[0]);
        };

        std::vector<Value> steps;
        steps.reserve((size_t)(n + 1));
        steps.push_back(pack_y(y));

        double x       = x0;
        double h_cur   = h;
        const int MAX_SUBSTEPS = 1'000'000;   // 每个大 step 内子步上限

        for (int step = 0; step < n; ++step) {
            double x_target = x + h;
            int substeps = 0;

            while (std::fabs(x - x_target) > 1e-15) {
                // (1) 迭代上限：兜底，绝不允许无限循环
                if (++substeps > MAX_SUBSTEPS) {
                    kr_error("rk: 在 x=%.10g 附近子步数超过上限 %d（tol=%.3g, h_cur=%.3g）",
                            x, MAX_SUBSTEPS, tol, h_cur);
                }

                // (2) 不允许越过 x_target —— 必须放在退化检查之前，
                //     否则上一大步末尾钳制的 0 会让新大步一开始就报错
                if (std::fabs(h_cur) > std::fabs(x_target - x))
                    h_cur = x_target - x;

                // (3) 步长退化：零 / NaN / 低于 x 的浮点精度
                if (h_cur == 0.0 || std::isnan(h_cur) ||
                    std::fabs(h_cur) < std::fabs(x_target) * 1e-16) {
                    kr_error("rk: 步长自适应失败（h_cur=%.3g, x=%.10g）", h_cur, x);
                }

                std::vector<double> yn;
                double error = 0.0;
                rkf45_step(x, y, h_cur, yn, error);

                // (4) 误差估计非有限 → 立刻报错，不要让 NaN 传染 h_cur
                if (!std::isfinite(error)) {
                    kr_error("rk: 误差估计非有限 (error=%g, x=%.10g, h=%.3g)",
                            error, x, h_cur);
                }

                if (error <= tol) {
                    double x_prev = x;
                    x += h_cur;
                    y = yn;

                    // (5) 位移停滞检测：h_cur 已无法推动 x
                    if (x == x_prev) {
                        kr_error("rk: 步进无法推进 x（h_cur=%.3g, x=%.10g）", h_cur, x);
                    }

                    if (error > 0) {
                        double f = 0.9 * std::pow(tol / error, 0.2);
                        if (f > 4.0) f = 4.0;
                        h_cur *= f;
                    } else {
                        h_cur *= 2.0;
                    }
                } else {
                    double f = 0.9 * std::pow(tol / error, 0.25);
                    if (f < 0.1) f = 0.1;
                    h_cur *= f;
                }
            }
            steps.push_back(pack_y(y));
        }
        Value r = make_array(steps.data(), (int)steps.size());
        for (auto& v : steps) free_value(&v);
        return r;
    }

    case BI_NEWTON: {
        if (argc < 2 || argc > 4)
            kr_error("newton 需要 2~4 个参数：函数, 初始值, [容差], [最大迭代]");
        if (A(0).type != VAL_FUNCTION) kr_error("newton: 第一个参数必须是函数");
        double x = bi_to_double(A(1));
        double tol = (argc >= 3) ? bi_to_double(A(2)) : 1e-7;
        int max_iter = (argc >= 4) ? (int)value_to_ll(A(3)) : 100;
        double h = 1e-5;

        for (int iter = 0; iter < max_iter; ++iter) {
            Value ax  = make_float(x);
            Value fxv = vm_invoke(A(0), &ax, 1);
            free_value(&ax);
            double fx = bi_to_double(fxv);
            free_value(&fxv);
            if (std::fabs(fx) < tol) break;

            Value ap = make_float(x + h);
            Value am = make_float(x - h);
            Value fp = vm_invoke(A(0), &ap, 1);
            Value fm = vm_invoke(A(0), &am, 1);
            free_value(&ap); free_value(&am);
            double fpd = bi_to_double(fp), fmd = bi_to_double(fm);
            free_value(&fp); free_value(&fm);
            double df = (fpd - fmd) / (2 * h);
            if (std::fabs(df) < 1e-10)
                kr_error("newton: 导数接近零，牛顿法无法收敛");
            x = x - fx / df;
        }
        return make_float(x);
    }

    case BI_GRADAB: {
        if (argc != 4)
            kr_error("gradab 需要 4 个参数：函数, 起始点数组, 学习率, 迭代次数");
        if (A(0).type != VAL_FUNCTION) kr_error("gradab: 第一个参数必须是函数");
        if (A(1).type != VAL_ARRAY)    kr_error("gradab: 第二个参数必须是数组");
        int dim = A(1).arr_val.length;
        if (dim == 0) kr_error("gradab: 起始点不能为空");
        double lr = bi_to_double(A(2));
        int iter  = (int)value_to_ll(A(3));
        if (iter < 0) kr_error("gradab: 迭代次数不能为负数");

        int target_n = A(0).func_val.param_count;
        if (target_n != 1 && target_n != dim)
            kr_error("gradab: 参数个数 (%d) 与点维度 (%d) 不匹配", target_n, dim);

        Value point = copy_value(A(1));
        double h = 1e-5;
        for (int it = 0; it < iter; ++it) {
            std::vector<double> grad((size_t)dim);
            for (int i = 0; i < dim; ++i) {
                Value pp = copy_value(point);
                Value pm = copy_value(point);
                double orig = bi_to_double(point.arr_val.elements[i]);
                free_value(&pp.arr_val.elements[i]);
                pp.arr_val.elements[i] = make_float(orig + h);
                free_value(&pm.arr_val.elements[i]);
                pm.arr_val.elements[i] = make_float(orig - h);

                auto eval_pt = [&](Value& pt) -> double {
                    if (target_n == 1) {
                        Value res = vm_invoke(A(0), &pt, 1);
                        double v = bi_to_double(res);
                        free_value(&res);
                        return v;
                    } else {
                        Value* up = (Value*)malloc((size_t)dim * sizeof(Value));
                        for (int j = 0; j < dim; ++j)
                            up[j] = copy_value(pt.arr_val.elements[j]);
                        Value res = vm_invoke(A(0), up, dim);
                        for (int j = 0; j < dim; ++j) free_value(&up[j]);
                        free(up);
                        double v = bi_to_double(res);
                        free_value(&res);
                        return v;
                    }
                };
                double fp = eval_pt(pp);
                double fm = eval_pt(pm);
                grad[i] = (fp - fm) / (2 * h);
                free_value(&pp); free_value(&pm);
            }
            for (int i = 0; i < dim; ++i) {
                double nv = bi_to_double(point.arr_val.elements[i])
                          - lr * grad[i];
                free_value(&point.arr_val.elements[i]);
                point.arr_val.elements[i] = make_float(nv);
            }
        }
        return point;
    }

    case BI_KQUAD: {
        if (argc != 2)
            kr_error("kquad 需要 2 个参数：数据点数组, 多项式次数");
        if (A(0).type != VAL_ARRAY) kr_error("kquad: 第一个参数必须是数组");
        int grado = (int)value_to_ll(A(1));
        if (grado < 0) kr_error("kquad: 次数不能为负数");
        int n = A(0).arr_val.length;
        if (n < grado + 1) kr_error("kquad: 数据点数量必须大于次数");

        std::vector<double> xs, ys;
        xs.reserve((size_t)n); ys.reserve((size_t)n);
        for (int i = 0; i < n; ++i) {
            const Value& pt = A(0).arr_val.elements[i];
            if (pt.type != VAL_OBJECT) kr_error("kquad: 每个数据点必须是对象");
            double x = 0, y = 0;
            bool fx = false, fy = false;
            for (int j = 0; j < pt.obj_val.count; ++j) {
                if (strcmp(pt.obj_val.entries[j].key, "x") == 0) {
                    x = bi_to_double(pt.obj_val.entries[j].value); fx = true;
                } else if (strcmp(pt.obj_val.entries[j].key, "y") == 0) {
                    y = bi_to_double(pt.obj_val.entries[j].value); fy = true;
                }
            }
            if (!fx || !fy) kr_error("kquad: 数据点必须包含 x 和 y");
            xs.push_back(x); ys.push_back(y);
        }
        int m = grado + 1;
        std::vector<std::vector<double>> M((size_t)m, std::vector<double>((size_t)m, 0.0));
        std::vector<double> b((size_t)m, 0.0);
        for (int i = 0; i < n; ++i) {
            double xi = xs[i], yi = ys[i];
            std::vector<double> pw((size_t)(2 * m));
            pw[0] = 1.0;
            for (int p = 1; p < 2 * m; ++p) pw[p] = pw[p-1] * xi;
            for (int j = 0; j < m; ++j) {
                b[j] += yi * pw[j];
                for (int k = 0; k < m; ++k) M[j][k] += pw[j + k];
            }
        }
        for (int col = 0; col < m; ++col) {
            int piv = col;
            while (piv < m && std::fabs(M[piv][col]) < 1e-12) ++piv;
            if (piv == m) kr_error("kquad: 法矩阵奇异，无法拟合");
            if (piv != col) { std::swap(M[col], M[piv]); std::swap(b[col], b[piv]); }
            double pv = M[col][col];
            for (int j = col; j < m; ++j) M[col][j] /= pv;
            b[col] /= pv;
            for (int row = 0; row < m; ++row) {
                if (row == col) continue;
                double f = M[row][col];
                for (int j = col; j < m; ++j) M[row][j] -= f * M[col][j];
                b[row] -= f * b[col];
            }
        }
        Value* coeffs = (Value*)malloc((size_t)m * sizeof(Value));
        for (int i = 0; i < m; ++i) coeffs[i] = make_float(b[i]);
        Value r = make_array(coeffs, m);
        for (int i = 0; i < m; ++i) free_value(&coeffs[i]);
        free(coeffs);
        return r;
    }

    case BI_GAUSS: {
        if (argc != 4)
            kr_error("gauss 需要 4 个参数：函数, a, b, 节点数 (2,4,8)");
        if (A(0).type != VAL_FUNCTION) kr_error("gauss: 第一个参数必须是函数");
        double a = bi_to_double(A(1));
        double b = bi_to_double(A(2));
        int n    = (int)value_to_ll(A(3));
        std::vector<std::pair<double,double>> nodes;
        if (n == 2) {
            nodes = { {-0.5773502691896257, 1.0}, {0.5773502691896257, 1.0} };
        } else if (n == 4) {
            nodes = { {-0.8611363115940526, 0.3478548451374538},
                      {-0.3399810435848563, 0.6521451548625461},
                      { 0.3399810435848563, 0.6521451548625461},
                      { 0.8611363115940526, 0.3478548451374538} };
        } else if (n == 8) {
            nodes = { {-0.9602898564975363, 0.1012285362903763},
                      {-0.7966664774136267, 0.2223810344533745},
                      {-0.5255324099163290, 0.3137066458778873},
                      {-0.1834346424956498, 0.3626837833783620},
                      { 0.1834346424956498, 0.3626837833783620},
                      { 0.5255324099163290, 0.3137066458778873},
                      { 0.7966664774136267, 0.2223810344533745},
                      { 0.9602898564975363, 0.1012285362903763} };
        } else {
            kr_error("gauss: 节点数仅支持 2, 4, 8");
        }
        double half = (b - a) / 2.0;
        double mid  = (a + b) / 2.0;
        double sum  = 0.0;
        for (auto& p : nodes) {
            double x = mid + half * p.first;
            Value arg = make_float(x);
            Value fv  = vm_invoke(A(0), &arg, 1);
            free_value(&arg);
            sum += p.second * bi_to_double(fv);
            free_value(&fv);
        }
        return make_float(sum * half);
    }

    // ================================================================
    // 文件
    // ================================================================
    case BI_LESE_DATEI: {
        REQ(1, "leseDatei/lese 需要 1 个参数");
        if (A(0).type != VAL_STRING) kr_error("文件名必须是字符串");
        FILE* fp = std::fopen(A(0).str_val, "rb");
        if (!fp) kr_error("无法打开文件 '%s'", A(0).str_val);
        std::fseek(fp, 0, SEEK_END);
        long len = std::ftell(fp);
        std::fseek(fp, 0, SEEK_SET);
        if (len < 0) len = 0;
        char* buf = (char*)std::malloc((size_t)len + 1);
        size_t rd = std::fread(buf, 1, (size_t)len, fp);
        std::fclose(fp);
        Value v = make_string_len(buf, rd);
        std::free(buf);
        return v;
    }
    case BI_LESE_BIN: {
        REQ(1, "leseBin 需要 1 个参数");
        if (A(0).type != VAL_STRING) kr_error("文件名必须是字符串");
        std::ifstream f(A(0).str_val, std::ios::binary | std::ios::ate);
        if (!f) kr_error("无法打开文件 '%s'", A(0).str_val);
        std::streamsize len = f.tellg();
        if (len <= 0) kr_error("文件为空");
        f.seekg(0, std::ios::beg);
        unsigned char* buf = (unsigned char*)std::malloc((size_t)len);
        f.read((char*)buf, len);
        f.close();
        Value* elems = (Value*)std::malloc((size_t)len * sizeof(Value));
        for (std::streamsize i = 0; i < len; ++i)
            elems[i] = make_int64((int64_t)buf[i]);
        Value r = make_array(elems, (int)len);
        for (std::streamsize i = 0; i < len; ++i) free_value(&elems[i]);
        std::free(elems); std::free(buf);
        return r;
    }
    case BI_SCHRD: {
        REQ(2, "schrd 需要 2 个参数 (文件名, 数据)");
        if (A(0).type != VAL_STRING) kr_error("文件名必须是字符串");
        FILE* fp = std::fopen(A(0).str_val, "wb");
        if (!fp) kr_error("无法写入文件 '%s'", A(0).str_val);
        if (A(1).type == VAL_ARRAY) {
            std::string buf;
            buf.reserve((size_t)A(1).arr_val.length);
            for (long long i = 0; i < A(1).arr_val.length; ++i) {
                const Value& e = A(1).arr_val.elements[i];
                if (e.type != VAL_INT && e.type != VAL_INT64) { std::fclose(fp); kr_error("schrd: 数组元素必须为整数"); }
                long long b = value_to_ll(e);
                if (b < 0 || b > 255) { std::fclose(fp); kr_error("schrd: 字节值越界"); }
                buf.push_back((char)(unsigned char)b);
            }
            if (!buf.empty()) std::fwrite(buf.data(), 1, buf.size(), fp);
        } else if (A(1).type == VAL_STRING) {
            std::fwrite(A(1).str_val, 1, A(1).str_len, fp);
        } else {
            char* s = value_to_string(A(1));
            std::fwrite(s, 1, std::strlen(s), fp);
            std::free(s);
        }
        std::fclose(fp);
        return make_null();
    }

    // ================================================================
    // 字符串
    // ================================================================
    case BI_TRIM: {
        REQ(1, "trim 需要 1 个参数");
        return c_method_trim(A(0), nullptr, 0);
    }
    case BI_ERSETZE: {
        REQ(3, "ersetze/ers 需要 3 个参数");
        return c_method_ersetze(A(0), args + 1, 2);
    }
    case BI_TEIL: {
        REQ(2, "teil 需要 2 个参数");
        return c_method_teile(A(0), args + 1, 1);
    }
    case BI_ENTHAELT: {
        REQ(2, "enthält/hat 需要 2 个参数");
        return c_method_enthaelt(A(0), args + 1, 1);
    }
    case BI_FAENGT_AN_MIT: {
        REQ(2, "fängtAnMit/beg 需要 2 个参数");
        return c_method_faengtAnMit(A(0), args + 1, 1);
    }
    case BI_ABSCHNITT: {
        if (argc < 2 || argc > 3)
            kr_error("abschnitt/ab 需要 2 或 3 个参数（字符串, 起始, [结束]）");
        return c_method_abschnitt(A(0), args + 1, argc - 1);
    }
    case BI_STELLE_VON: {
        REQ(2, "stelleVon/wo 需要 2 个参数");
        return c_method_stelleVon(A(0), args + 1, 1);
    }
    case BI_LETZTE_STELLE_VON: {
        REQ(2, "letzteStelleVon/letzt 需要 2 个参数");
        return c_method_letzteStelleVon(A(0), args + 1, 1);
    }
    case BI_ALS_ZAHL: {
        if (argc < 1) kr_error("alsZahl/alz 至少需要 1 个参数");
        return c_method_alsZahl(A(0), args + 1, argc - 1);
    }
    case BI_ALS_TEXT: {
        REQ(1, "alsText/alt 需要 1 个参数");
        return c_method_alsText(A(0), nullptr, 0);
    }
    case BI_ALS_ARRAY: {
        REQ(1, "alsArray/ala 需要 1 个参数");
        return c_method_alsArray(A(0), nullptr, 0);
    }
    case BI_GROSS: {
        REQ(1, "groß 需要 1 个参数");
        return c_method_toUpper(A(0), nullptr, 0);
    }
    case BI_FORMAT: {
        if (argc < 1) kr_error("format 至少需要一个格式字符串");
        if (A(0).type != VAL_STRING) kr_error("第一个参数必须是格式字符串");
    
        // ---- 检查是否包含未转义的 '%' ----
        bool has_old_percent = false;
        const char* fmt_scan = A(0).str_val;
        for (const char* p = fmt_scan; *p; ++p) {
            if (*p == '\\' && *(p + 1) == '%') { ++p; continue; }
            if (*p == '%') { has_old_percent = true; break; }
        }
    
        // ---- 新语法：无 % 占位符，直接交给 format_value_new ----
        if (!has_old_percent) {
            if (argc < 2) kr_error("format: 需要至少一个值参数");
            Value val = copy_value(A(1));
            Value formatted = format_value_new(val, std::string(fmt_scan));
            free_value(&val);
            return formatted;
        }
    
        // ---- 旧语法：逐字符解析 ----
        std::string output;
        const char* fmt_str = A(0).str_val;
        int arg_idx = 0;
        int total_args = argc - 1;
    
        while (*fmt_str) {
            if (*fmt_str == '%') {
                fmt_str++;
                if (*fmt_str == '%') { output += '%'; fmt_str++; continue; }
    
                // ---- 解析格式说明符 ----
                int          base      = 10;
                bool         zero_pad  = false;
                int          width     = 0;
                char         sep_char  = '\0';
                int          precision = -1;
                RoundingMode mode      = ROUND_HALF_UP;
    
                // 1) 零填充标记
                if (*fmt_str == '0') { zero_pad = true; fmt_str++; }
    
                // 2) 宽度数字
                if (isdigit(*fmt_str)) {
                    width = 0;
                    while (isdigit(*fmt_str)) {
                        width = width * 10 + (*fmt_str - '0');
                        fmt_str++;
                    }
                }
    
                // 3) 分隔符（可选）
                if (*fmt_str && !isdigit(*fmt_str) && !isalpha(*fmt_str) && *fmt_str != '.') {
                    sep_char = *fmt_str;
                    fmt_str++;
                }
    
                // 4) 精度（. 后数字）
                if (*fmt_str == '.') {
                    fmt_str++;
                    precision = 0;
                    while (isdigit(*fmt_str)) {
                        precision = precision * 10 + (*fmt_str - '0');
                        fmt_str++;
                    }
                }
    
                // 5) 类型字符
                char type = *fmt_str;
                fmt_str++;
    
                // 6) 整数类型时，前面的数字其实表示进制
                if (type == 'z' || type == 'd' || type == 'x' || type == 'X') {
                    if (width > 0) {
                        base = width;
                        width = 0;
                    }
                    zero_pad = false;
                }
    
                // 7) 舍入模式（仅对 k/w 有效）
                if (type == 'k' || type == 'w') {
                    if      (*fmt_str == '^') { mode = ROUND_CEIL;  fmt_str++; }
                    else if (*fmt_str == '_') { mode = ROUND_FLOOR; fmt_str++; }
                }
    
                // ---- 取参数 ----
                if (arg_idx >= total_args) kr_error("format: 缺少对应参数");
                Value v = copy_value(args[arg_idx + 1]);
                arg_idx++;
    
                std::string part;
    
                if (type == 'z' || type == 'd' || type == 'x' || type == 'X') {
                    mpz_t num;
                    mpz_init(num);
                    if (v.type == VAL_FLOAT) {
                        mpf_t tmp;
                        mpf_init(tmp);
                        mpf_set(tmp, *v.mpf_val);
                        mpz_set_f(num, tmp);
                        mpf_clear(tmp);
                    } else if (v.type == VAL_INT64) {
                        mpz_set_int64(num, v.int64_val);
                    } else if (v.type == VAL_INT) {
                        mpz_set(num, *v.big_int);
                    } else {
                        mpz_clear(num);
                        free_value(&v);
                        kr_error("format: 整数格式需要整数或浮点数参数");
                    }
                    int radix = (type == 'z') ? base
                              : (type == 'x' || type == 'X') ? 16 : 10;
                    char* s = mpz_get_str(NULL, radix, num);
                    std::string num_str = s;
                    free(s);
                    mpz_clear(num);
                    free_value(&v);
                    if (type == 'X') {
                        for (char& c : num_str)
                            if (c >= 'a' && c <= 'f') c = c - 'a' + 'A';
                    }
                    part = num_str;
                }
                else if (type == 'k' || type == 'w') {
                    if (v.type != VAL_INT && v.type != VAL_INT64 && v.type != VAL_FLOAT)
                        kr_error("format: %%k/%%w 需要整数或浮点数参数");
                    mpf_t tmp;
                    mpf_init(tmp);
                    if      (v.type == VAL_INT64) mpf_set_int64(tmp, v.int64_val);
                    else if (v.type == VAL_INT)   mpf_set_z(tmp, *v.big_int);
                    else                          mpf_set(tmp, *v.mpf_val);
                    part = ::format_mpf_decimal(tmp, precision, sep_char, mode);
                    mpf_clear(tmp);
                    free_value(&v);
                    part = apply_width(part, width, zero_pad);
                }
                else if (type == 'e') {
                    if (v.type != VAL_INT && v.type != VAL_INT64 && v.type != VAL_FLOAT)
                        kr_error("format: %%e 需要整数或浮点数参数");
                    mpf_t tmp;
                    mpf_init(tmp);
                    if      (v.type == VAL_INT64) mpf_set_int64(tmp, v.int64_val);
                    else if (v.type == VAL_INT)   mpf_set_z(tmp, *v.big_int);
                    else                          mpf_set(tmp, *v.mpf_val);
    
                    int digits = (precision >= 0) ? precision + 1 : 7;
                    if (digits < 1) digits = 1;
                    mp_exp_t exp;
                    char* mant = mpf_get_str(NULL, &exp, 10, digits, tmp);
                    mpf_clear(tmp);
    
                    bool neg = false;
                    if (mant[0] == '-') { neg = true; ++mant; }
                    int len = (int)strlen(mant);
                    int real_exp = (int)exp - 1;
    
                    std::string part_str = (neg ? "-" : "") + std::string(1, mant[0]);
                    if (len > 1) {
                        part_str += ".";
                        part_str.append(mant + 1, len - 1);
                        if (precision >= 0 && (len - 1) < precision)
                            part_str.append(precision - (len - 1), '0');
                    } else if (precision > 0) {
                        part_str += ".";
                        part_str.append(precision, '0');
                    }
                    std::ostringstream oss;
                    oss << (real_exp >= 0 ? "+" : "-")
                        << std::setw(2) << std::setfill('0') << std::abs(real_exp);
                    part_str += 'e' + oss.str();
    
                    free(mant - (neg ? 1 : 0));
                    free_value(&v);
                    part = apply_width(part_str, width, zero_pad);
                }
                else if (type == 't') {
                    char* s = value_to_string(v);
                    part = s;
                    free(s);
                    free_value(&v);
                    part = apply_width(part, width, zero_pad);
                }
                else if (type == '%') {
                    if (v.type != VAL_INT && v.type != VAL_INT64 && v.type != VAL_FLOAT)
                        kr_error("format: %% 需要整数或浮点数参数");
                    mpf_t tmp;
                    mpf_init(tmp);
                    if      (v.type == VAL_INT64) mpf_set_int64(tmp, v.int64_val);
                    else if (v.type == VAL_INT)   mpf_set_z(tmp, *v.big_int);
                    else                          mpf_set(tmp, *v.mpf_val);
                    mpf_mul_ui(tmp, tmp, 100);
                    part = ::format_mpf_decimal(
                        tmp, (precision >= 0) ? precision : 0, sep_char, mode);
                    mpf_clear(tmp);
                    free_value(&v);
                    part += '%';
                    part = apply_width(part, width, zero_pad);
                }
                else {
                    kr_error("format: 不支持的格式类型 '%c'", type);
                }
    
                output += part;
            }
            else if (*fmt_str == '\\' && *(fmt_str + 1) == '%') {
                output += '%';
                fmt_str += 2;
            }
            else {
                output += *fmt_str;
                fmt_str++;
            }
        }
    
        if (arg_idx < total_args) {
            kr_warn("format: 存在未使用的参数");
        }
    
        return make_string(output.c_str());
    }
    case BI_LAN: {
        REQ(1, "län 需要 1 个参数");
        return c_method_lan(A(0), nullptr, 0);
    }

    // ================================================================
    // 时间 / 系统
    // ================================================================
    case BI_SLEEP: {
        if (argc < 1 || argc > 2)
            kr_error("sleep 需要 1 或 2 个参数：ms, [callback]");
        int64_t ms = value_to_ll(A(0));
        if (ms < 0)
            kr_error("sleep: 延时毫秒不能为负数");
    
        if (argc == 1) {
            std::this_thread::sleep_for(std::chrono::milliseconds(ms));
            return make_null();
        }
    
        Value cb_val = A(1);
        if (cb_val.type != VAL_FUNCTION)
            kr_error("sleep: 第二个参数必须是函数");
    
        VM* vm = static_cast<VM*>(ctx);
        Value cb_copy = copy_value(cb_val);
        Scope* root_scope = current_scope;
    
        // 增加引用计数，防止主线程提前销毁
        vm->retain();
        root_scope->retain();
    
        timer_system::add(ms, [vm, cb_copy, root_scope]() mutable {
            if(vm->is_finished) {
                // 脚本已经结束，直接放弃执行回调，释放引用计数
                vm->release();
                root_scope->release();
                return;
            }
            try {
                VM::ThreadContext tctx = vm->enter_thread_context(vm->bc, root_scope);
                try {
                    Value ret = vm_invoke(cb_copy, nullptr, 0);
                    free_value(&ret);
                } catch (...) {
                }
                vm->exit_thread_context(tctx);
            } catch (...) {
                // enter_thread_context 失败捕获，防止锁泄漏
            }
            vm->release();
            root_scope->release();
        });        
    
        return make_null();
    }
    
    case BI_ZEIT: {
        REQ(0, "zeit 不需要参数");
        return make_int64((int64_t)std::time(nullptr));
    }
    case BI_ZEIT_US:
    case BI_ZEIT_MS:
    case BI_ZEIT_NS: {
        REQ(0, "zeit_* 不需要参数");
        auto now = std::chrono::system_clock::now().time_since_epoch();
        long long r;
        if (id == BI_ZEIT_US) r = std::chrono::duration_cast<std::chrono::microseconds>(now).count();
        else if (id == BI_ZEIT_MS) r = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
        else r = std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();
        return make_int64(r);
    }
    case BI_DATUM: {
        REQ(0, "datum 不需要参数");
        std::time_t t = std::time(nullptr);
        std::tm* tm_info = std::localtime(&t);
        char buffer[64];
        std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_info);
        return make_string(buffer);
    }
    case BI_TICK: {
        REQ(0, "tick 不需要参数");
        g_vm_tick_time = std::chrono::steady_clock::now();
        g_vm_tick_set  = true;
        return make_null();
    }
    case BI_TOCK:
    case BI_TOCK_MS:
    case BI_TOCK_S: {
        REQ(0, "tock* 不需要参数");
        if (!g_vm_tick_set) kr_error("请先调用 tick");
        auto now = std::chrono::steady_clock::now();
        auto d   = now - g_vm_tick_time;
        if (id == BI_TOCK)
            return make_int64(std::chrono::duration_cast<std::chrono::microseconds>(d).count());
        if (id == BI_TOCK_MS)
            return make_int64(std::chrono::duration_cast<std::chrono::milliseconds>(d).count());
        // tock_s → 返回浮点秒
        mpf_t t; mpf_init(t);
        mpf_set_d(t, std::chrono::duration<double>(d).count());
        Value r = make_float(t);
        mpf_clear(t);
        return r;
    }
    case BI_ENDE: {
        if (argc > 1) kr_error("ende/exit 预期 0 或 1 个参数");
        int code = (argc == 1) ? (int)value_to_ll(A(0)) : 0;
        std::exit(code);
    }
    case BI_ZEILE: {
        // 用 g_last_error_line/col 作为近似
        if (argc == 0) return make_int64(g_last_error_line);
        if (argc == 1 && A(0).type == VAL_STRING) {
            const char* o = A(0).str_val;
            if (std::strcmp(o, "s") == 0 || std::strcmp(o, "spalte") == 0)
                return make_int64(g_last_error_col);
            if (std::strcmp(o, "a") == 0 || std::strcmp(o, "alle") == 0) {
                char buf[32];
                std::snprintf(buf, sizeof(buf), "%d:%d", g_last_error_line, g_last_error_col);
                return make_string(buf);
            }
        }
        kr_error("zeile: 参数无效");
    }
    case BI_FNAME: {
        REQ(0, "fname 不需要参数");
        return make_string(g_last_error_filename ? g_last_error_filename : "");
    }

    // ================================================================
    // 字节 / 编码
    // ================================================================
    case BI_BYTES: {
        REQ(1, "bytes 需要 1 个字符串参数");
        if (A(0).type != VAL_STRING) kr_error("bytes: 参数必须是字符串");
        size_t len = 0;
        char* u = unescape_string(A(0).str_val, &len);
        Value* elems = (Value*)std::malloc(len * sizeof(Value));
        for (size_t i = 0; i < len; ++i)
            elems[i] = make_int64((int64_t)(unsigned char)u[i]);
        Value r = make_array(elems, (int)len);
        for (size_t i = 0; i < len; ++i) free_value(&elems[i]);
        std::free(elems); std::free(u);
        return r;
    }
    case BI_UMBYTES: {
        REQ(1, "umbytes 需要 1 个数组");
        if (A(0).type != VAL_ARRAY) kr_error("umbytes: 参数必须是数组");
        std::string s;
        s.reserve((size_t)A(0).arr_val.length);
        for (long long i = 0; i < A(0).arr_val.length; ++i) {
            long long b = value_to_ll(A(0).arr_val.elements[i]);
            if (b < 0 || b > 255) kr_error("umbytes: 字节越界");
            s.push_back((char)b);
        }
        return make_string_len(s.data(), s.size());
    }
    case BI_KODIER_BASE64: {
        REQ(1, "kodierBase64 需要 1 个参数");
        std::string raw;
        if (A(0).type == VAL_STRING) raw.assign(A(0).str_val, A(0).str_len);
        else if (A(0).type == VAL_ARRAY) {
            for (long long i = 0; i < A(0).arr_val.length; ++i) {
                long long b = value_to_ll(A(0).arr_val.elements[i]);
                if (b < 0 || b > 255) kr_error("kodierBase64: 字节越界");
                raw.push_back((char)b);
            }
        } else kr_error("kodierBase64: 参数必须是字符串或数组");
        std::string enc = base64_encode((const unsigned char*)raw.data(), raw.size());
        return make_string_len(enc.data(), enc.size());
    }
    case BI_KODIER_URL: {
        REQ(1, "kodierURL 需要 1 个参数");
        char* s = value_to_string(A(0));
        static const char* hex = "0123456789ABCDEF";
        std::string out;
        for (const unsigned char* p = (const unsigned char*)s; *p; ++p) {
            unsigned char c = *p;
            if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~')
                out += (char)c;
            else { out += '%'; out += hex[c >> 4]; out += hex[c & 0xF]; }
        }
        std::free(s);
        return make_string_len(out.data(), out.size());
    }
    case BI_DEKODIER_URL: {
        REQ(1, "dekodierURL 需要 1 个参数");
        char* s = value_to_string(A(0));
        std::string in(s), out;
        std::free(s);
        for (size_t i = 0; i < in.size(); ++i) {
            if (in[i] == '+') out += ' ';
            else if (in[i] == '%' && i + 2 < in.size()
                     && std::isxdigit((unsigned char)in[i+1])
                     && std::isxdigit((unsigned char)in[i+2])) {
                char h[3] = { in[i+1], in[i+2], 0 };
                out += (char)std::strtol(h, nullptr, 16);
                i += 2;
            } else out += in[i];
        }
        return make_string_len(out.data(), out.size());
    }

    // ================================================================
    // JSON
    // ================================================================
    case BI_JSONZU: {
        REQ(1, "jsonzu 需要 1 个字符串");
        if (A(0).type != VAL_STRING) kr_error("jsonzu: 参数必须是字符串");
        return json_parse(A(0));
    }
    case BI_ZUJSON: {
        REQ(1, "zujson 需要 1 个参数");
        return json_to_string(A(0));
    }

    // ================================================================
    // 类型
    // ================================================================
    case BI_TYPIST: {
        REQ(1, "typist 需要 1 个参数");
        const Value& v = A(0);
        if (v.type == VAL_OBJECT) {
            // 枚举变体
            for (int i = 0; i < v.obj_val.count; ++i) {
                if (std::strcmp(v.obj_val.entries[i].key, "__tag") == 0
                    && v.obj_val.entries[i].value.type == VAL_STRING) {
                    ObjectEntry e[2];
                    e[0].key = strdup("typ"); e[0].value = make_string("aufz");
                    e[1].key = strdup("aufz"); e[1].value = make_string(v.obj_val.entries[i].value.str_val);
                    Value r = make_object(e, 2);
                    free(e[0].key); free_value(&e[0].value);
                    free(e[1].key); free_value(&e[1].value);
                    return r;
                }
            }
            // 类实例
            for (int i = 0; i < v.obj_val.count; ++i) {
                if (std::strcmp(v.obj_val.entries[i].key, "__klass") == 0
                    && v.obj_val.entries[i].value.type == VAL_STRING) {
                    ObjectEntry e[2];
                    e[0].key = strdup("typ"); e[0].value = make_string("objekt");
                    e[1].key = strdup("klass"); e[1].value = make_string(v.obj_val.entries[i].value.str_val);
                    Value r = make_object(e, 2);
                    free(e[0].key); free_value(&e[0].value);
                    free(e[1].key); free_value(&e[1].value);
                    return r;
                }
            }
        }
        std::string t = value_type_to_string(v);
        return make_string(t.c_str());
    }
    case BI_GTYP: {
        REQ(1, "gtyp 需要 1 个参数");
        std::string t = basic_value_type_to_string(A(0));
        return make_string(t.c_str());
    }

    // ================================================================
    // 指针
    // ================================================================
    case BI_ZGR: {
        REQ(1, "zgr 需要 1 个参数");
        return make_pointer_raw(A(0));
    }
    case BI_SCHLAU: {
        REQ(1, "schlau 需要 1 个参数");
        return make_pointer_smart(A(0));
    }
    case BI_ZGRW: {
        REQ(1, "zgrw 需要 1 个参数");
        if (A(0).type != VAL_POINTER) kr_error("zgrw: 参数不是指针");
        if (A(0).ptr_val.freed) kr_error("访问已释放的指针");
        Value* t = A(0).ptr_val.smart_target
                    ? A(0).ptr_val.smart_target->get()
                    : A(0).ptr_val.raw_target;
        if (!t) kr_error("空指针解引用");
        return copy_value(*t);
    }
    case BI_ZGRS: {
        REQ(2, "zgrs 需要 2 个参数");
        if (A(0).type != VAL_POINTER) kr_error("zgrs: 第一个参数不是指针");
        if (A(0).ptr_val.freed) kr_error("访问已释放的指针");
        Value* t = A(0).ptr_val.smart_target
                    ? A(0).ptr_val.smart_target->get()
                    : A(0).ptr_val.raw_target;
        if (!t) kr_error("空指针写入");
        free_value(t);
        *t = copy_value(A(1));
        return make_null();
    }
    case BI_FREI: {
        REQ(1, "frei 需要 1 个参数");
        if (A(0).type != VAL_POINTER) kr_error("frei: 参数不是指针");
        // 只能就地修改 args[0]；对从栈上取的值，语义上会丢，但解释器行为也如此
        Value* p = &args[0];
        if (p->ptr_val.smart_target) {
            // 智能指针：no-op
        } else if (p->ptr_val.raw_target) {
            if (p->ptr_val.freed) kr_error("指针已释放");
            free_value(p->ptr_val.raw_target);
            delete p->ptr_val.raw_target;
            p->ptr_val.raw_target = nullptr;
            p->ptr_val.freed = true;
        }
        return make_null();
    }
    case BI_ZGR_NULL: {
        REQ(1, "zgrNull 需要 1 个参数");
        if (A(0).type != VAL_POINTER) kr_error("zgrNull: 参数不是指针");
        if (A(0).ptr_val.freed) kr_error("访问已释放的指针");
        bool n = (A(0).ptr_val.smart_target == nullptr) && (A(0).ptr_val.raw_target == nullptr);
        return make_int64(n ? 1 : 0);
    }

    // ================================================================
    // 错误
    // ================================================================
    case BI_KRFEHL: {
        if (argc < 1) kr_error("KRFehl 需要至少 1 个参数");
        std::string msg;
        int line = g_last_error_line, col = g_last_error_col;
        std::string fname = g_last_error_filename ? g_last_error_filename : "-";
        std::string hint;
        if (A(0).type == VAL_OBJECT) {
            for (int i = 0; i < A(0).obj_val.count; ++i) {
                const char* k = A(0).obj_val.entries[i].key;
                const Value& v = A(0).obj_val.entries[i].value;
                if (std::strcmp(k,"msg")==0 || std::strcmp(k,"info")==0 || std::strcmp(k,"text")==0) {
                    char* s = value_to_string(v); msg = s; std::free(s);
                } else if (std::strcmp(k,"line")==0 || std::strcmp(k,"zel")==0) {
                    if (v.type == VAL_INT64 || v.type == VAL_INT) line = (int)value_to_ll(v);
                } else if (std::strcmp(k,"col")==0 || std::strcmp(k,"spl")==0) {
                    if (v.type == VAL_INT64 || v.type == VAL_INT) col = (int)value_to_ll(v);
                } else if (std::strcmp(k,"file")==0 || std::strcmp(k,"datei")==0 || std::strcmp(k,"name")==0) {
                    if (v.type == VAL_STRING) fname.assign(v.str_val, v.str_len);
                } else if (std::strcmp(k,"hint")==0) {
                    if (v.type == VAL_STRING) hint.assign(v.str_val, v.str_len);
                }
            }
        } else {
            char* s = value_to_string(A(0)); msg = s; std::free(s);
            if (argc >= 2 && (A(1).type == VAL_INT || A(1).type == VAL_INT64)) line = (int)value_to_ll(A(1));
            if (argc >= 3 && (A(2).type == VAL_INT || A(2).type == VAL_INT64)) col  = (int)value_to_ll(A(2));
            if (argc >= 4 && A(3).type == VAL_STRING) fname.assign(A(3).str_val, A(3).str_len);
            if (argc >= 6 && A(5).type == VAL_STRING) hint.assign(A(5).str_val, A(5).str_len);
        }
        g_last_error_line = line;
        g_last_error_col  = col;
        if (!hint.empty()) kr_error_hint(hint.c_str(), "%s", msg.c_str());
        else               kr_error("%s", msg.c_str());
        return make_null(); // 不会到达
    }
    case BI_KRWARN: {
        if (argc < 1) kr_error("KRWarn 需要至少 1 个参数");
        std::string msg;
        if (A(0).type == VAL_OBJECT) {
            for (int i = 0; i < A(0).obj_val.count; ++i) {
                const char* k = A(0).obj_val.entries[i].key;
                if (std::strcmp(k,"msg")==0 || std::strcmp(k,"info")==0 || std::strcmp(k,"text")==0) {
                    char* s = value_to_string(A(0).obj_val.entries[i].value);
                    msg = s; std::free(s);
                } else if (std::strcmp(k,"line")==0 || std::strcmp(k,"zel")==0) {
                    const Value& v = A(0).obj_val.entries[i].value;
                    if (v.type == VAL_INT64 || v.type == VAL_INT) g_last_error_line = (int)value_to_ll(v);
                } else if (std::strcmp(k,"col")==0 || std::strcmp(k,"spl")==0) {
                    const Value& v = A(0).obj_val.entries[i].value;
                    if (v.type == VAL_INT64 || v.type == VAL_INT) g_last_error_col = (int)value_to_ll(v);
                }
            }
        } else {
            char* s = value_to_string(A(0)); msg = s; std::free(s);
        }
        bool old = g_warnings_enabled;
        g_warnings_enabled = true;
        kr_warn("%s", msg.c_str());
        g_warnings_enabled = old;
        return make_null();
    }

    case BI_ZEIG_IN:
    case BI_SCHR_IN: {
        const bool add_newline = (id == BI_ZEIG_IN);
        const char* fname = add_newline ? "zeigIn" : "schrIn";

        // ========== 只有1个参数时，默认stdout，参数作为打印内容 ==========
        bool implicit_stdout_mode = (argc == 1);
        long long stream_id = 0; // 默认stdout
        int print_arg_end = argc;
        bool have_flush_arg = false;
        bool need_flush = false;

        if (implicit_stdout_mode) {
            // 仅一个参数：A(0) 就是要打印的内容，流固定 stdout
            print_arg_end = 1;
        } else {
            if (argc < 1)
                kr_error("%s 需要至少 1 个参数（流选择符 stdout / stderr，或仅字符串）", fname);
            // ---- 解析第一个参数：流选择符 ----
            const Value& stream_val = A(0);
            stream_id = -1;
            if (stream_val.type == VAL_INT64) {
                stream_id = stream_val.int64_val;
            } else if (stream_val.type == VAL_INT) {
                if (mpz_fits_slong_p(*stream_val.big_int))
                    stream_id = mpz_get_si(*stream_val.big_int);
            } else if (stream_val.type == VAL_STRING) {
                if (strcmp(stream_val.str_val, "stdout") == 0) stream_id = 0;
                else if (strcmp(stream_val.str_val, "stderr") == 0) stream_id = 1;
            }
            if (stream_id != 0 && stream_id != 1)
                kr_error("%s: 第一个参数必须是 stdout (0) 或 stderr (1)", fname);

            // -------- 解析可选的刷新标记 --------
            have_flush_arg = false;
            need_flush = false;
            print_arg_end = argc;
            if (argc >= 2) {
                const Value& last_arg = A(argc - 1);
                long long flag_val = -1;
                if (last_arg.type == VAL_INT64) {
                    flag_val = last_arg.int64_val;
                } else if (last_arg.type == VAL_INT) {
                    if (mpz_fits_slong_p(*last_arg.big_int))
                        flag_val = mpz_get_si(*last_arg.big_int);
                }
                if (flag_val == 0 || flag_val == 1) {
                    have_flush_arg = true;
                    need_flush = (flag_val == 1);
                    print_arg_end = argc - 1;
                }
            }
        }

        if (stream_id == 0) {
            // ========== STDOUT ==========
            // 起始下标区分：隐式stdout模式从i=0开始；正常模式从i=1开始
            int start_idx = implicit_stdout_mode ? 0 : 1;
            for (int i = start_idx; i < print_arg_end; ++i) {
                const Value& v = A(i);
                switch (v.type) {
                    case VAL_INT64:
                        fastout::write_int64(v.int64_val);
                        break;
                    case VAL_STRING:
                        if (v.str_len > 0)
                            fastout::write(v.str_val, static_cast<size_t>(v.str_len));
                        break;
                    case VAL_INT: {
                        char* s = mpz_get_str(nullptr, 10, *v.big_int);
                        fastout::write_cstr(s);
                        free(s);
                        break;
                    }
                    case VAL_FLOAT:
                        fastout::write_double(mpf_get_d(*v.mpf_val));
                        break;
                    case VAL_NULL:
                        fastout::write_cstr("null");
                        break;
                    default: {
                        char* s = value_to_string(v);
                        fastout::write_cstr(s);
                        free(s);
                        break;
                    }
                }
            }
            if (add_newline)
                fastout::put('\n');
            if (have_flush_arg && need_flush) {
                fastout::flush();
            }
            return make_null();
        } else {
            // ========== STDERR ==========
            int start_idx = 1; // stderr只能是>=2参数模式，永远从i=1开始
            for (int i = start_idx; i < print_arg_end; ++i) {
                const Value& v = A(i);
                switch (v.type) {
                    case VAL_INT64:
                        fastout::write_int64_stderr(v.int64_val);
                        break;
                    case VAL_STRING:
                        if (v.str_len > 0)
                            fastout::write_stderr(v.str_val, static_cast<size_t>(v.str_len));
                        break;
                    case VAL_INT: {
                        char* s = mpz_get_str(nullptr, 10, *v.big_int);
                        fastout::write_cstr_stderr(s);
                        free(s);
                        break;
                    }
                    case VAL_FLOAT:
                        fastout::write_double_stderr(mpf_get_d(*v.mpf_val));
                        break;
                    case VAL_NULL:
                        fastout::write_cstr_stderr("null");
                        break;
                    default: {
                        char* s = value_to_string(v);
                        fastout::write_cstr_stderr(s);
                        free(s);
                        break;
                    }
                }
            }
            if (add_newline)
                fastout::put_stderr('\n');
            // 还原旧版stderr刷新策略
            if (have_flush_arg) {
                if (need_flush) {
                    fastout::flush_stderr();
                    fflush(stderr);
                }
            } else {
                // 无flush参数：默认强制刷新stderr
                fastout::flush_stderr();
                fflush(stderr);
            }
            return make_null();
        }
    }

    // ================================================================
    // HTTP 辅助
    // ================================================================
    case BI_ESC: {
        REQ(1, "esc 需要 1 个参数");
        char* s = value_to_string(A(0));
        std::string out;
        for (char c : std::string(s)) {
            switch (c) {
                case '&': out += "&amp;"; break;
                case '<': out += "&lt;"; break;
                case '>': out += "&gt;"; break;
                case '"': out += "&quot;"; break;
                case '\'':out += "&#39;"; break;
                default:  out += c;
            }
        }
        std::free(s);
        return make_string_len(out.data(), out.size());
    }
    case BI_TEXT:
    case BI_HTML: {
        if (argc < 1 || argc > 2) kr_error("text/html 需要 1 或 2 个参数");
        if (A(0).type != VAL_STRING) kr_error("text/html: 第一个参数必须是字符串");
        int status = 200;
        if (argc == 2 && (A(1).type == VAL_INT || A(1).type == VAL_INT64))
            status = (int)value_to_ll(A(1));
        const char* ctype = (id == BI_HTML) ? "text/html; charset=utf-8"
                                            : "text/plain; charset=utf-8";
        ObjectEntry head[1];
        head[0].key = strdup("Content-Type");
        head[0].value = make_string(ctype);
        ObjectEntry entries[3];
        entries[0].key = strdup("zustand"); entries[0].value = make_int64(status);
        entries[1].key = strdup("kopf");    entries[1].value = make_object(head, 1);
        entries[2].key = strdup("inhalt");  entries[2].value = make_string_len(A(0).str_val, A(0).str_len);
        Value r = make_object(entries, 3);
        free(head[0].key); free_value(&head[0].value);
        for (int i = 0; i < 3; ++i) { free(entries[i].key); free_value(&entries[i].value); }
        return r;
    }
    case BI_JSON_RESP: {
        if (argc < 1 || argc > 2) kr_error("json 需要 1 或 2 个参数");
        int status = 200;
        if (argc == 2 && (A(1).type == VAL_INT || A(1).type == VAL_INT64))
            status = (int)value_to_ll(A(1));
        Value body = json_to_string(A(0));
        ObjectEntry head[1];
        head[0].key = strdup("Content-Type");
        head[0].value = make_string("application/json; charset=utf-8");
        ObjectEntry entries[3];
        entries[0].key = strdup("zustand"); entries[0].value = make_int64(status);
        entries[1].key = strdup("kopf");    entries[1].value = make_object(head, 1);
        entries[2].key = strdup("inhalt");  entries[2].value = body;
        Value r = make_object(entries, 3);
        free(head[0].key); free_value(&head[0].value);
        for (int i = 0; i < 3; ++i) { free(entries[i].key); free_value(&entries[i].value); }
        return r;
    }
    case BI_UMLEITEN: {
        if (argc < 1 || argc > 2) kr_error("umleiten 需要 1 或 2 个参数");
        if (A(0).type != VAL_STRING) kr_error("umleiten: 第一个参数必须是 URL");
        int status = 302;
        if (argc == 2 && (A(1).type == VAL_INT || A(1).type == VAL_INT64))
            status = (int)value_to_ll(A(1));
        ObjectEntry head[1];
        head[0].key = strdup("Location");
        head[0].value = make_string_len(A(0).str_val, A(0).str_len);
        ObjectEntry entries[3];
        entries[0].key = strdup("zustand"); entries[0].value = make_int64(status);
        entries[1].key = strdup("kopf");    entries[1].value = make_object(head, 1);
        entries[2].key = strdup("inhalt");  entries[2].value = make_string("");
        Value r = make_object(entries, 3);
        free(head[0].key); free_value(&head[0].value);
        for (int i = 0; i < 3; ++i) { free(entries[i].key); free_value(&entries[i].value); }
        return r;
    }
    case BI_ABFRAGE: {
        REQ(1, "abfrage 需要 1 个 URL");
        if (A(0).type != VAL_STRING) kr_error("abfrage: 参数必须是字符串");
        std::string url(A(0).str_val, A(0).str_len);
        size_t qm = url.find('?');
        std::string q = (qm == std::string::npos) ? "" : url.substr(qm + 1);
        size_t h = q.find('#'); if (h != std::string::npos) q = q.substr(0, h);
        return parse_urlencoded(q);
    }
    case BI_FORMULAR: {
        REQ(1, "formular 需要 1 个字符串");
        if (A(0).type != VAL_STRING) kr_error("formular: 参数必须是字符串");
        return parse_urlencoded(std::string(A(0).str_val, A(0).str_len));
    }
    case BI_ANFR: {
        if (argc < 2 || argc > 3) kr_error("ANFR 需要 2 或 3 个参数");
        if (A(0).type != VAL_STRING || A(1).type != VAL_STRING)
            kr_error("ANFR: 前两个参数必须是字符串");
        Value opt = (argc == 3) ? copy_value(A(2)) : make_null();
        Value r = http_anfrage(A(0).str_val, A(1).str_val, opt);
        free_value(&opt);
        return r;
    }

    // ================================================================
    // KD 数据集
    // ================================================================
    case BI_LADE_KD: {
        REQ(1, "ladeKD 需要 1 个参数");
        if (A(0).type != VAL_STRING) kr_error("文件名必须是字符串");

        auto ds = std::make_shared<KDDataSet>();
        bool loaded = ds->load(A(0).str_val);
        if (!loaded) {
            FILE* test = std::fopen(A(0).str_val, "rb");
            if (test) {
                std::fclose(test);
                kr_error("文件 '%s' 存在但无法加载", A(0).str_val);
            } else {
                FILE* fp = std::fopen(A(0).str_val, "wb");
                if (!fp) kr_error("无法创建文件 '%s'", A(0).str_val);
                char magic[5] = "KDB";
                uint32_t version = 1;
                uint64_t count   = 0;
                std::fwrite(magic, 4, 1, fp);
                std::fwrite(&version, 4, 1, fp);
                std::fwrite(&count, 8, 1, fp);
                std::fclose(fp);
                if (!ds->load(A(0).str_val)) kr_error("无法加载新建文件");
            }
        }

        Value obj;
        std::memset(&obj, 0, sizeof(Value));
        obj.type = VAL_OBJECT;
        obj.obj_val.count = 1;
        obj.obj_val.entries = (ObjectEntry*)std::malloc(sizeof(ObjectEntry));
        obj.obj_val.entries[0].key = strdup("__kd_daten");

        auto* ptr_holder = new std::shared_ptr<KDDataSet>(ds);

        obj.obj_val.entries[0].value.type = VAL_OBJECT;
        obj.obj_val.entries[0].value.obj_val.count = 1;
        obj.obj_val.entries[0].value.obj_val.entries =
            (ObjectEntry*)std::malloc(sizeof(ObjectEntry));
        obj.obj_val.entries[0].value.obj_val.entries[0].key = strdup("__zgr");

        Value& v = obj.obj_val.entries[0].value.obj_val.entries[0].value;
        std::memset(&v, 0, sizeof(Value));
        v = make_int64((int64_t)ptr_holder);
        return obj;
    }

    case BI_SCHR_KD: {
        REQ(2, "schrKD 需要 2 个参数");
        auto datenmenge = _hole_dataset(A(0));
        if (!datenmenge) kr_error("无效的数据集对象");
        Record eintrag = _wert_zu_eintrag(A(1));
        if (eintrag.id == 0) eintrag.id = datenmenge->naechste_id();
        if (!datenmenge->insert_record(eintrag)) kr_error("写入失败");
        return make_null();
    }

    case BI_ERNEU_KD: {
        REQ(2, "erneuKD 需要 2 个参数");
        auto datenmenge = _hole_dataset(A(0));
        if (!datenmenge) kr_error("无效的数据集对象");
        Record eintrag = _wert_zu_eintrag(A(1));
        if (eintrag.id == 0) kr_error("缺少 ID");
        if (!datenmenge->delete_record(eintrag.id)) kr_error("ID 不存在");
        if (!datenmenge->insert_record(eintrag))  kr_error("更新失败");
        return make_null();
    }

    case BI_LOES_KD: {
        REQ(2, "loesKD 需要 2 个参数");
        auto datenmenge = _hole_dataset(A(0));
        if (!datenmenge) kr_error("无效的数据集对象");
        uint64_t id = (uint64_t)value_to_ll(A(1));
        if (!datenmenge->delete_record(id)) kr_error("ID 不存在");
        return make_null();
    }

    case BI_SUCH_KD: {
        REQ(2, "suchKD 需要 2 个参数");
        if (A(1).type != VAL_STRING) kr_error("模式必须是字符串");
        auto datenmenge = _hole_dataset(A(0));
        if (!datenmenge) kr_error("无效的数据集对象");
        auto treffer = datenmenge->find_by_text(A(1).str_val);

        Value* id_werte = treffer.empty()
            ? nullptr
            : (Value*)std::malloc(treffer.size() * sizeof(Value));
        for (size_t i = 0; i < treffer.size(); ++i)
            id_werte[i] = make_int64((int64_t)treffer[i]);

        Value arr = make_array(id_werte, (int)treffer.size());
        for (size_t i = 0; i < treffer.size(); ++i) free_value(&id_werte[i]);
        std::free(id_werte);
        return arr;
    }

    case BI_SIEBE_KD: {
        REQ(2, "siebeKD 需要 2 个参数");
        if (A(1).type != VAL_FUNCTION) kr_error("第二个参数必须是函数");
        auto datenmenge = _hole_dataset(A(0));
        if (!datenmenge) kr_error("无效的数据集对象");

        Value pred_fn = copy_value(A(1));
        auto pred = [&](const Record& rec) -> bool {
            Value rec_obj = _eintrag_zu_wert(rec);
            Value erg     = vm_invoke(pred_fn, &rec_obj, 1);
            bool  ok      = value_to_bool(erg);
            free_value(&rec_obj);
            free_value(&erg);
            return ok;
        };
        auto gefiltert = datenmenge->filter_records(pred);
        free_value(&pred_fn);

        Value* id_werte = gefiltert.empty()
            ? nullptr
            : (Value*)std::malloc(gefiltert.size() * sizeof(Value));
        for (size_t i = 0; i < gefiltert.size(); ++i)
            id_werte[i] = make_int64((int64_t)gefiltert[i]);

        Value arr = make_array(id_werte, (int)gefiltert.size());
        for (size_t i = 0; i < gefiltert.size(); ++i) free_value(&id_werte[i]);
        std::free(id_werte);
        return arr;
    }

    case BI_ALLE_KD: {
        REQ(1, "alleKD 需要 1 个参数");
        auto datenmenge = _hole_dataset(A(0));
        if (!datenmenge) kr_error("无效的数据集对象");
        auto ids = datenmenge->all_ids();

        Value* id_werte = ids.empty()
            ? nullptr
            : (Value*)std::malloc(ids.size() * sizeof(Value));
        for (size_t i = 0; i < ids.size(); ++i)
            id_werte[i] = make_int64((int64_t)ids[i]);

        Value arr = make_array(id_werte, (int)ids.size());
        for (size_t i = 0; i < ids.size(); ++i) free_value(&id_werte[i]);
        std::free(id_werte);
        return arr;
    }

    case BI_ZAEHLE_KD: {
        REQ(1, "zaehleKD 需要 1 个参数");
        auto datenmenge = _hole_dataset(A(0));
        if (!datenmenge) kr_error("无效的数据集对象");
        return make_int64((int64_t)datenmenge->all_ids().size());
    }

    case BI_VERSCHL_KD: {
        REQ(2, "verschlKD 需要 2 个参数");
        if (A(1).type != VAL_STRING) kr_error("密码必须是字符串");
        auto ds = _hole_dataset(A(0));
        if (!ds) kr_error("无效的数据集对象");
        if (!ds->encrypt(A(1).str_val)) kr_error("加密失败");
        return make_null();
    }

    case BI_ENTSCHL_KD: {
        REQ(2, "entschlKD 需要 2 个参数");
        if (A(1).type != VAL_STRING) kr_error("密码必须是字符串");
        auto ds = _hole_dataset(A(0));
        if (!ds) kr_error("无效的数据集对象");
        if (!ds->decrypt(A(1).str_val)) kr_error("解密失败");
        return make_null();
    }

    // ================================================================
    // HTTP 服务器 / 流
    // ================================================================
    case BI_STARTE_SERVER: {
        REQ(2, "starteServer 需要 2 个参数");
        if (A(0).type != VAL_INT && A(0).type != VAL_INT64)
            kr_error("端口必须是整数");
        if (A(1).type != VAL_FUNCTION)
            kr_error("Handler 必须是函数");
    
        uint16_t port = (uint16_t)value_to_ll(A(0));
        Value handler_copy = copy_value(A(1));
        const Bytecode* captured_bc    = bc;
        Scope*          captured_scope = original_global_scope;

        auto server = std::make_shared<HttpServer>(port,
            [handler_copy, captured_bc, captured_scope](Value req) -> Value {
                return vm_invoke_http_handler(handler_copy, captured_bc,
                                              captured_scope, req);
            });
    
        if (!server->start()) kr_error("无法在端口 %d 启动服务器", port);
        {
            ScopedLockRelease releaser(g_global_mutex);
            releaser.release();
            server->wait();
            releaser.relock();
        }
        free_value(&handler_copy);
        return make_null();
    }

    case BI_AC_STARTE_SERVER: {
        REQ(2, "ac_starteServer 需要 2 个参数");
        if (A(0).type != VAL_INT && A(0).type != VAL_INT64)
            kr_error("端口必须是整数");
        if (A(1).type != VAL_FUNCTION)
            kr_error("Handler 必须是函数");
    
        uint16_t port = (uint16_t)value_to_ll(A(0));
        Value handler_copy = copy_value(A(1));
        const Bytecode* captured_bc    = bc;
        Scope*          captured_scope = original_global_scope;

        auto server = std::make_shared<HttpServer>(port,
            [handler_copy, captured_bc, captured_scope](Value req) -> Value {
                return vm_invoke_http_handler(handler_copy, captured_bc,
                                              captured_scope, req);
            });
    
        if (!server->start()) kr_error("无法在端口 %d 启动服务器", port);
        int id = ++next_future_id;
        auto future = std::async(std::launch::async,
            [server]() -> std::shared_ptr<Value> {
                server->wait();
                return std::make_shared<Value>(make_null());
            });
        {
            std::lock_guard<std::mutex> lock(future_map_mutex);
            future_map[id] = future.share();
        }
        Value fut_val; std::memset(&fut_val, 0, sizeof(Value));
        fut_val.type = VAL_FUTURE;
        fut_val.future_state.future_id = id;
        return fut_val;
    }

    case BI_SSE: {
        REQ(0, "SSE 不需要参数");
        auto state = std::make_shared<StreamState>();
        state->sse = true;
        StreamHandle* user_handle = new StreamHandle{ state };

        ObjectEntry head[1];
        head[0].key   = strdup("Content-Type");
        head[0].value = make_string("text/event-stream; charset=utf-8");

        ObjectEntry entries[4];
        entries[0].key = strdup("__stream");
        entries[0].value = make_int64(1);
        entries[1].key = strdup("__stream_handle");
        entries[1].value = make_int64((int64_t)user_handle);
        entries[2].key = strdup("zustand");
        entries[2].value = make_int64(200);
        entries[3].key = strdup("kopf");
        entries[3].value = make_object(head, 1);

        Value obj = make_object(entries, 4);
        free(head[0].key); free_value(&head[0].value);
        for (int i = 0; i < 4; ++i) {
            free(entries[i].key);
            free_value(&entries[i].value);
        }
        return obj;
    }

    case BI_SENDE: {
        REQ(2, "sende 需要 2 个参数：stream, data");
        if (A(0).type != VAL_OBJECT) kr_error("第一个参数必须是 stream");

        StreamHandle* h = nullptr;
        bool sse_mode = false;
        for (int i = 0; i < A(0).obj_val.count; ++i) {
            if (strcmp(A(0).obj_val.entries[i].key, "__stream_handle") == 0 &&
                A(0).obj_val.entries[i].value.type == VAL_INT64) {
                h = (StreamHandle*)A(0).obj_val.entries[i].value.int64_val;
            } else if (strcmp(A(0).obj_val.entries[i].key, "__stream") == 0) {
                sse_mode = true;
            }
        }
        if (!h || !h->state) kr_error("无效的 stream 对象");

        std::string data = value_to_stdstring(A(1));
        std::string payload;
        if (sse_mode) {
            std::istringstream iss(data);
            std::string line;
            while (std::getline(iss, line)) payload += "data: " + line + "\n";
            payload += "\n";
        } else {
            payload = data;
        }
        h->state->push(std::move(payload));
        return make_null();
    }

    case BI_SENDE_SSE: {
        if (argc < 2 || argc > 3)
            kr_error("sendeSSE 需要 2 或 3 个参数");
        if (A(0).type != VAL_OBJECT) kr_error("第一个参数必须是 stream");

        StreamHandle* h = nullptr;
        for (int i = 0; i < A(0).obj_val.count; ++i) {
            if (strcmp(A(0).obj_val.entries[i].key, "__stream_handle") == 0 &&
                A(0).obj_val.entries[i].value.type == VAL_INT64) {
                h = (StreamHandle*)A(0).obj_val.entries[i].value.int64_val;
                break;
            }
        }
        if (!h || !h->state) kr_error("无效的 stream 对象");

        std::string event, data;
        if (argc == 2) data = value_to_stdstring(A(1));
        else { event = value_to_stdstring(A(1)); data = value_to_stdstring(A(2)); }

        std::string payload;
        if (!event.empty()) payload += "event: " + event + "\n";
        std::istringstream iss(data);
        std::string line;
        while (std::getline(iss, line)) payload += "data: " + line + "\n";
        payload += "\n";
        h->state->push(std::move(payload));
        return make_null();
    }

    case BI_SCHLIESSE: {
        REQ(1, "schliesse 需要 1 个参数");
        if (A(0).type != VAL_OBJECT) kr_error("参数必须是 stream");

        StreamHandle* h = nullptr;
        for (int i = 0; i < A(0).obj_val.count; ++i) {
            if (strcmp(A(0).obj_val.entries[i].key, "__stream_handle") == 0 &&
                A(0).obj_val.entries[i].value.type == VAL_INT64) {
                h = (StreamHandle*)A(0).obj_val.entries[i].value.int64_val;
                break;
            }
        }
        if (!h || !h->state) kr_error("无效的 stream 对象");
        h->state->close();
        return make_null();
    }

    case BI_HOLE_IP: {
        if (argc == 0) {
            return make_host_ip_object();
        } else if (argc == 1) {
            if (A(0).type != VAL_OBJECT)
                kr_error("holeIP(req): 参数必须是 HTTP 请求对象");
            std::string client_ip;
            bool found = false;
            for (int i = 0; i < A(0).obj_val.count; ++i) {
                if (strcmp(A(0).obj_val.entries[i].key, "ip") == 0 &&
                    A(0).obj_val.entries[i].value.type == VAL_STRING) {
                    client_ip.assign(A(0).obj_val.entries[i].value.str_val,
                                     A(0).obj_val.entries[i].value.str_len);
                    found = true;
                    break;
                }
            }
            if (!found) {
                kr_warn("holeIP(req): 请求对象没有 'ip' 字段");
                client_ip = "";
            }

            Value host_obj = make_host_ip_object();

            ObjectEntry entries[5];
            entries[0].key = strdup("client");
            entries[0].value = make_string(client_ip.c_str());
            entries[1].key = strdup("client_lokal");
            entries[1].value = make_int64(is_loopback_ip(client_ip) ? 1 : 0);
            entries[2].key = strdup("host");
            entries[2].value = make_string(host_obj.obj_val.entries[0].value.str_val);
            entries[3].key = strdup("lokal");
            entries[3].value = make_string("127.0.0.1");
            entries[4].key = strdup("ipv4");
            entries[4].value = copy_value(host_obj.obj_val.entries[2].value);

            Value obj = make_object(entries, 5);
            for (int i = 0; i < 5; ++i) {
                free(entries[i].key);
                free_value(&entries[i].value);
            }
            free_value(&host_obj);
            return obj;
        } else {
            kr_error("holeIP 需要 0 或 1 个参数");
        }
    }

    // ================================================================
    // 元信息 / 调试
    // ================================================================
    case BI_TOKENS: {
        // 依赖解释器全局 tokens / token_count / find_filename_by_line_col
        long long startLine = 1, endLine = 0;
        long long startCol = 1, endCol = LLONG_MAX;
        bool hasColRange = false;

        if (argc == 0) {
            for (int i = 0; i < token_count; ++i)
                if (tokens[i].line > endLine) endLine = tokens[i].line;
            if (endLine == 0) endLine = 1;
        } else if (argc == 1) {
            const Value& arg = A(0);
            if (arg.type == VAL_INT || arg.type == VAL_INT64) {
                long long line = value_to_ll(arg);
                startLine = endLine = line;
            } else if (arg.type == VAL_ARRAY && arg.arr_val.length == 2) {
                startLine = value_to_ll(arg.arr_val.elements[0]);
                endLine   = value_to_ll(arg.arr_val.elements[1]);
                if (startLine > endLine) std::swap(startLine, endLine);
            } else {
                kr_error("tokens 参数应为整数或 [行,行] 数组");
            }
        } else if (argc == 2) {
            const Value& a1 = A(0), &a2 = A(1);
            if (a1.type == VAL_ARRAY && a1.arr_val.length == 2 &&
                a2.type == VAL_ARRAY && a2.arr_val.length == 2) {
                startLine = value_to_ll(a1.arr_val.elements[0]);
                startCol  = value_to_ll(a1.arr_val.elements[1]);
                endLine   = value_to_ll(a2.arr_val.elements[0]);
                endCol    = value_to_ll(a2.arr_val.elements[1]);
                hasColRange = true;
                if (startLine > endLine) {
                    std::swap(startLine, endLine);
                    std::swap(startCol, endCol);
                }
            } else {
                kr_error("tokens 两个参数必须都是 [行,列] 数组");
            }
        } else {
            kr_error("tokens 接受 0, 1 或 2 个参数");
        }
        if (endLine == 0) {
            for (int i = 0; i < token_count; ++i)
                if (tokens[i].line > endLine) endLine = tokens[i].line;
            if (endLine == 0) endLine = 1;
        }
        if (!hasColRange) { startCol = 1; endCol = LLONG_MAX; }

        std::string output;
        for (int i = 0; i < token_count; ++i) {
            Token* tok = &tokens[i];
            if (tok->line < startLine || tok->line > endLine) continue;
            if (tok->line == startLine && tok->col < startCol) continue;
            if (tok->line == endLine   && tok->col > endCol)   continue;

            const char* type_str; const char* color_code = "\033[0m";
            switch (tok->type) {
                case TOK_IDENT:   type_str = "<IDENT>";     color_code = "\033[32m"; break;
                case TOK_NUMBER:  type_str = "<ZAHL>";      color_code = "\033[33m"; break;
                case TOK_REGEX:   type_str = "<REGUL>\n";   color_code = "\033[35m"; break;
                case TOK_KEYWORD: type_str = "<KEYWORT>\n"; color_code = "\033[36m"; break;
                case TOK_OP:      type_str = "<OP>";        color_code = "\033[31m"; break;
                case TOK_SYMBOL:  type_str = "<SYMBOL>";    color_code = "\033[34m"; break;
                case TOK_EOF:     type_str = "<EOF>";       color_code = "\033[90m"; break;
                default:          type_str = "<UNBEKAN>";   color_code = "\033[37m"; break;
            }
            char part[256];
            std::snprintf(part, sizeof(part), "%s%s%s%s",
                          tok->value, color_code, type_str, "\033[0m");
            output += part;
        }
        if (!output.empty() && output.back() == ' ') output.pop_back();
        return make_string_len(output.data(), output.size());
    }

    case BI_WORTE: {
        long long startLine = 1, endLine = 0;
        long long startCol = 1, endCol = LLONG_MAX;
        bool hasColRange = false;

        if (argc == 0) {
            for (int i = 0; i < token_count; ++i)
                if (tokens[i].line > endLine) endLine = tokens[i].line;
            if (endLine == 0) endLine = 1;
        } else if (argc == 1) {
            const Value& arg = A(0);
            if (arg.type == VAL_INT || arg.type == VAL_INT64) {
                long long line = value_to_ll(arg);
                startLine = endLine = line;
            } else if (arg.type == VAL_ARRAY && arg.arr_val.length == 2) {
                startLine = value_to_ll(arg.arr_val.elements[0]);
                endLine   = value_to_ll(arg.arr_val.elements[1]);
                if (startLine > endLine) std::swap(startLine, endLine);
            } else {
                kr_error("worte 参数应为整数或 [行,行] 数组");
            }
        } else if (argc == 2) {
            const Value& a1 = A(0), &a2 = A(1);
            if (a1.type == VAL_ARRAY && a1.arr_val.length == 2 &&
                a2.type == VAL_ARRAY && a2.arr_val.length == 2) {
                startLine = value_to_ll(a1.arr_val.elements[0]);
                startCol  = value_to_ll(a1.arr_val.elements[1]);
                endLine   = value_to_ll(a2.arr_val.elements[0]);
                endCol    = value_to_ll(a2.arr_val.elements[1]);
                hasColRange = true;
                if (startLine > endLine) {
                    std::swap(startLine, endLine);
                    std::swap(startCol, endCol);
                }
            } else {
                kr_error("worte 两个参数必须都是 [行,列] 数组");
            }
        } else {
            kr_error("worte 接受 0, 1 或 2 个参数");
        }
        if (endLine == 0) {
            for (int i = 0; i < token_count; ++i)
                if (tokens[i].line > endLine) endLine = tokens[i].line;
            if (endLine == 0) endLine = 1;
        }
        if (!hasColRange) { startCol = 1; endCol = LLONG_MAX; }

        std::string output;
        for (int i = 0; i < token_count; ++i) {
            Token* tok = &tokens[i];
            if (tok->line < startLine || tok->line > endLine) continue;
            if (tok->line == startLine && tok->col < startCol) continue;
            if (tok->line == endLine   && tok->col > endCol)   continue;
            if (tok->type == TOK_OP || tok->type == TOK_SYMBOL ||
                tok->type == TOK_EOF) continue;
            output += tok->value;
            output += ' ';
        }
        if (!output.empty() && output.back() == ' ') output.pop_back();
        return make_string_len(output.data(), output.size());
    }

    case BI_REGGEN: {
        if (argc < 1 || argc > 4)
            kr_error("regGen 需要 1 到 4 个参数：正则, [排除], [起始码点], [结束码点]");

        std::string pattern_str;
        int pcre2_options = PCRE2_UTF | PCRE2_UCP;
        if (A(0).type == VAL_STRING) {
            pattern_str.assign(A(0).str_val, A(0).str_len);
        } else if (A(0).type == VAL_OBJECT) {
            std::string pat, flg;
            bool has_pat = false;
            for (int i = 0; i < A(0).obj_val.count; ++i) {
                if (strcmp(A(0).obj_val.entries[i].key, "muster") == 0 &&
                    A(0).obj_val.entries[i].value.type == VAL_STRING) {
                    pat.assign(A(0).obj_val.entries[i].value.str_val,
                               A(0).obj_val.entries[i].value.str_len);
                    has_pat = true;
                }
                if (strcmp(A(0).obj_val.entries[i].key, "flags") == 0 &&
                    A(0).obj_val.entries[i].value.type == VAL_STRING) {
                    flg.assign(A(0).obj_val.entries[i].value.str_val,
                               A(0).obj_val.entries[i].value.str_len);
                }
            }
            if (!has_pat) kr_error("正则对象缺少 'muster' 字段");
            pattern_str = pat;
            if (strchr(flg.c_str(), 'i')) pcre2_options |= PCRE2_CASELESS;
            if (strchr(flg.c_str(), 'm')) pcre2_options |= PCRE2_MULTILINE;
            if (strchr(flg.c_str(), 's')) pcre2_options |= PCRE2_DOTALL;
            if (strchr(flg.c_str(), 'x')) pcre2_options |= PCRE2_EXTENDED;
        } else {
            kr_error("第一个参数必须是字符串或正则对象");
        }

        std::unordered_set<std::string> exclude_set;
        pcre2_code*       exclude_re = nullptr;
        pcre2_match_data* exclude_md = nullptr;
        int arg_idx = 1;
        if (argc > arg_idx) {
            const Value& ex = A(arg_idx);
            if (ex.type == VAL_STRING) {
                std::string s(ex.str_val, ex.str_len);
                size_t pos = 0;
                while (pos < s.size()) {
                    size_t len; utf8_char_width(&s[pos], &len);
                    exclude_set.insert(s.substr(pos, len));
                    pos += len;
                }
                ++arg_idx;
            } else if (ex.type == VAL_ARRAY) {
                for (long long i = 0; i < ex.arr_val.length; ++i) {
                    if (ex.arr_val.elements[i].type == VAL_STRING) {
                        std::string elem(ex.arr_val.elements[i].str_val,
                                         ex.arr_val.elements[i].str_len);
                        if (utf8_length(elem) == 1) exclude_set.insert(elem);
                    }
                }
                ++arg_idx;
            } else if (ex.type == VAL_OBJECT) {
                const char *pat = nullptr, *flg = "";
                for (int i = 0; i < ex.obj_val.count; ++i) {
                    if (strcmp(ex.obj_val.entries[i].key, "muster") == 0 &&
                        ex.obj_val.entries[i].value.type == VAL_STRING)
                        pat = ex.obj_val.entries[i].value.str_val;
                    if (strcmp(ex.obj_val.entries[i].key, "flags") == 0 &&
                        ex.obj_val.entries[i].value.type == VAL_STRING)
                        flg = ex.obj_val.entries[i].value.str_val;
                }
                if (!pat) kr_error("排除正则对象缺少 'muster' 字段");
                std::string exclude_pattern = convert_ampersand_to_dollar(pat);
                int opt = PCRE2_UTF | PCRE2_UCP;
                if (strchr(flg, 'i')) opt |= PCRE2_CASELESS;
                if (strchr(flg, 'm')) opt |= PCRE2_MULTILINE;
                if (strchr(flg, 's')) opt |= PCRE2_DOTALL;
                if (strchr(flg, 'x')) opt |= PCRE2_EXTENDED;

                int errcode; PCRE2_SIZE erroffset;
                exclude_re = pcre2_compile(
                    (PCRE2_SPTR)exclude_pattern.c_str(),
                    exclude_pattern.size(), opt, &errcode, &erroffset, NULL);
                if (!exclude_re) {
                    PCRE2_UCHAR errbuf[256];
                    pcre2_get_error_message(errcode, errbuf, sizeof(errbuf));
                    kr_error("排除正则编译错误: %s (偏移 %zu)", errbuf, erroffset);
                }
                exclude_md = pcre2_match_data_create_from_pattern(exclude_re, NULL);
                if (!exclude_md) {
                    pcre2_code_free(exclude_re);
                    kr_error("无法创建排除正则匹配数据");
                }
                ++arg_idx;
            }
        }

        int start = 0, end = 0xFFFF;
        if (argc > arg_idx &&
            (A(arg_idx).type == VAL_INT || A(arg_idx).type == VAL_INT64)) {
            start = (int)value_to_ll(A(arg_idx));
            ++arg_idx;
            if (argc > arg_idx &&
                (A(arg_idx).type == VAL_INT || A(arg_idx).type == VAL_INT64)) {
                end = (int)value_to_ll(A(arg_idx));
                ++arg_idx;
            } else {
                end = 0xFFFF;
            }
        }
        if (start > end) std::swap(start, end);
        if (start < 0) start = 0;
        if (end > 0x10FFFF) end = 0x10FFFF;

        pattern_str = convert_ampersand_to_dollar(pattern_str);
        int errorcode; PCRE2_SIZE erroroffset;
        pcre2_code* re = pcre2_compile(
            (PCRE2_SPTR)pattern_str.c_str(), pattern_str.size(),
            pcre2_options, &errorcode, &erroroffset, NULL);
        if (!re) {
            PCRE2_UCHAR errbuf[256];
            pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
            if (exclude_re) { pcre2_code_free(exclude_re); pcre2_match_data_free(exclude_md); }
            kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
        }
        pcre2_match_data* md = pcre2_match_data_create_from_pattern(re, NULL);
        if (!md) {
            pcre2_code_free(re);
            if (exclude_re) { pcre2_code_free(exclude_re); pcre2_match_data_free(exclude_md); }
            kr_error("无法创建匹配数据");
        }

        std::vector<Value> results;
        for (int cp = start; cp <= end; ++cp) {
            char utf8[5]; int len = 0;
            if (cp < 0x80) { utf8[0] = (char)cp; len = 1; }
            else if (cp < 0x800) {
                utf8[0] = (char)(0xC0 | (cp >> 6));
                utf8[1] = (char)(0x80 | (cp & 0x3F));
                len = 2;
            } else if (cp < 0x10000) {
                utf8[0] = (char)(0xE0 | (cp >> 12));
                utf8[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
                utf8[2] = (char)(0x80 | (cp & 0x3F));
                len = 3;
            } else if (cp <= 0x10FFFF) {
                utf8[0] = (char)(0xF0 | (cp >> 18));
                utf8[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
                utf8[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
                utf8[3] = (char)(0x80 | (cp & 0x3F));
                len = 4;
            } else continue;
            utf8[len] = '\0';
            std::string ch(utf8, len);

            if (exclude_set.count(ch)) continue;
            if (exclude_re) {
                int rc = pcre2_match(exclude_re, (PCRE2_SPTR)ch.c_str(),
                                     ch.size(), 0, 0, exclude_md, NULL);
                if (rc >= 0) continue;
            }
            int rc = pcre2_match(re, (PCRE2_SPTR)ch.c_str(),
                                 ch.size(), 0, 0, md, NULL);
            if (rc >= 0) results.push_back(make_string_len(ch.data(), ch.size()));
        }

        pcre2_match_data_free(md);
        pcre2_code_free(re);
        if (exclude_re) { pcre2_match_data_free(exclude_md); pcre2_code_free(exclude_re); }

        Value* elems = results.empty()
            ? nullptr
            : (Value*)std::malloc(results.size() * sizeof(Value));
        for (size_t i = 0; i < results.size(); ++i) elems[i] = results[i];
        Value arr = make_array(elems, (int)results.size());
        std::free(elems);
        return arr;
    }

    case BI_VW: {
        if (argc < 1 || argc > 4)
            kr_error("vw 需要 1 到 4 个参数：Code, [Startzeile, Startspalte, Dateiname]");
        if (A(0).type != VAL_STRING)
            kr_error("第一个参数必须是字符串 (Verwirrt-Code)");

        std::string vw_code(A(0).str_val, A(0).str_len);
        int start_line = g_last_error_line > 0 ? g_last_error_line : 1;
        int start_col  = g_last_error_col  > 0 ? g_last_error_col  : 1;
        const char* filename = current_filename ? current_filename : "-";
        if (argc >= 2) {
            if (A(1).type != VAL_INT && A(1).type != VAL_INT64)
                kr_error("第二个参数必须是整数 (Startzeile)");
            start_line = (int)value_to_ll(A(1));
        }
        if (argc >= 3) {
            if (A(2).type != VAL_INT && A(2).type != VAL_INT64)
                kr_error("第三个参数必须是整数 (Startspalte)");
            start_col = (int)value_to_ll(A(2));
        }
        if (argc >= 4) {
            if (A(3).type != VAL_STRING)
                kr_error("第四个参数必须是字符串 (Dateiname)");
            filename = A(3).str_val;
        }

        auto external_call = [&](const std::string& func_name,
                                 const std::string& args_json) -> std::string {
            JSONParser parser(args_json);
            Value args_val = parser.parse();

            std::vector<Value> call_args;
            if (args_val.type == VAL_ARRAY) {
                for (int i = 0; i < args_val.arr_val.length; ++i)
                    call_args.push_back(copy_value(args_val.arr_val.elements[i]));
            } else {
                call_args.push_back(copy_value(args_val));
            }
            free_value(&args_val);

            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            Function* func = get_function(func_name.c_str());
            if (!func) kr_error("Kernregel-Funktion '%s' nicht gefunden", func_name.c_str());

            Value func_val = make_function(
                func->name, func->params, func->param_count, func->body,
                func->closure_scope, func->is_memoized, func->is_async,
                func->global_scope, false, func->return_type, func->vararg_name,
                func->param_is_const, func->param_defaults,
                func->param_types, func->vararg_type);
            Value result_v = vm_invoke(func_val, call_args.data(),
                                                 (int)call_args.size());
            free_value(&func_val);
            for (auto& v : call_args) free_value(&v);

            std::string result_json = json_stringify_value(result_v, false, 0);
            free_value(&result_v);
            return result_json;
        };

        std::string context_json = export_global_values();
        std::string result_json  = execute_vw(vw_code, context_json,
                                              start_line, start_col,
                                              filename, external_call);

        JSONParser parser(result_json);
        Value result_obj = parser.parse();
        if (result_obj.type == VAL_OBJECT) {
            Scope* gs = get_global_scope();
            for (int i = 0; i < result_obj.obj_val.count; ++i) {
                const char* key = result_obj.obj_val.entries[i].key;
                Value val = copy_value(result_obj.obj_val.entries[i].value);
                int idx = get_var_index_in_scope(gs, key);
                if (idx >= 0) {
                    Variable* var = &gs->vars[idx];
                    if (var->is_const) { free_value(&val); continue; }
                    free_value(&var->value);
                    var->value = val;
                } else {
                    declare_var_in_scope(gs, key, false, val);
                }
            }
        }
        free_value(&result_obj);
        return make_null();
    }

    case BI_UMF: {
        REQ(1, "umf 需要 1 个参数（作用域名称字符串）");
        if (A(0).type != VAL_STRING) kr_error("umf 参数必须是字符串");
        std::string scope_name(A(0).str_val, A(0).str_len);

        // 优先查 VM 的命名作用域；若无则退回解释器的全局 named_scopes
        Scope* ns = nullptr;
        if (g_vm_named_scopes_lookup) {
            ns = g_vm_named_scopes_lookup(scope_name);
        }
        if (!ns) {
            auto it = named_scopes.find(scope_name);
            if (it != named_scopes.end()) ns = it->second;
        }
        if (!ns) kr_error("未找到命名作用域 '%s'", scope_name.c_str());

        std::unordered_map<std::string, Variable*> var_map;
        Scope* cur = ns;
        while (cur && cur != original_global_scope) {
            for (int i = 0; i < cur->var_count; ++i)
                var_map[cur->vars[i].name] = &cur->vars[i];
            cur = cur->parent;
        }

        ObjectEntry* entries = var_map.empty()
            ? nullptr
            : (ObjectEntry*)std::malloc(var_map.size() * sizeof(ObjectEntry));
        int idx = 0;
        for (auto& kv : var_map) {
            Variable* var = kv.second;
            if (var->is_alias) var = resolve_alias(var);
        
            Value val;
            if (var->is_lazy) {
                if (!var->evaluated) {
                    if (var->lazy_code_off != SIZE_MAX) {
                        // 编译模式：走 VM 代码块
                        vm_force_eval_lazy_var(var);
                    } else if (var->init_expr) {
                        // 解释器模式兜底：只有 init_expr 非空才走老路径
                        Value v = eval_expr(var->init_expr);
                        var->cached_value = copy_value(v);
                        var->evaluated = true;
                        free_value(&v);
                    }
                }
                val = copy_value(var->cached_value);
            } else {
                val = copy_value(var->value);
            }
        
            entries[idx].key   = strdup(kv.first.c_str());
            entries[idx].value = val;
            ++idx;
        }
        Value obj = make_object(entries, idx);
        for (int i = 0; i < idx; ++i) {
            free(entries[i].key);
            free_value(&entries[i].value);
        }
        std::free(entries);
        return obj;
    }

    // ================================================================
    // 键盘 / 终端
    // ================================================================
    case BI_DRUECKE: {
        REQ(1, "drücke 需要 1 个参数");
        if (A(0).type != VAL_STRING) kr_error("参数必须是字符串");
        std::string key = normalize_key_string(A(0).str_val);
        auto it = key_bind_map.find(key);
        if (it == key_bind_map.end()) return make_null();

        ASTNode* body     = it->second.first;
        Scope*   captured = it->second.second;

        bool  old_return = return_caught, old_break = break_caught,
              old_continue = continue_caught, old_exception = exception_raised;
        Value old_return_val    = return_value;
        Value old_exception_val = exception_value;
        return_caught = break_caught = continue_caught = exception_raised = false;
        return_value = make_null();
        exception_value = make_null();

        Scope* old_scope = current_scope;
        push_scope();
        current_scope->parent = captured;
        exec_statement(body);
        pop_scope();
        current_scope = old_scope;

        return_caught = old_return; return_value = old_return_val;
        break_caught = old_break;   continue_caught = old_continue;
        exception_raised = old_exception; exception_value = old_exception_val;
        return make_null();
    }

    case BI_TASTE: {
        REQ(0, "taste 不需要参数");
        std::string key_str;
#ifdef _WIN32
        int ch = _getch();
        if (ch == 0xE0 || ch == 0x00) {
            int ch2 = _getch();
            switch (ch2) {
                case 0x3B: key_str = "F1"; break;  case 0x3C: key_str = "F2"; break;
                case 0x3D: key_str = "F3"; break;  case 0x3E: key_str = "F4"; break;
                case 0x3F: key_str = "F5"; break;  case 0x40: key_str = "F6"; break;
                case 0x41: key_str = "F7"; break;  case 0x42: key_str = "F8"; break;
                case 0x43: key_str = "F9"; break;  case 0x44: key_str = "F10"; break;
                case 0x85: key_str = "F11"; break; case 0x86: key_str = "F12"; break;
                default: key_str = std::string(1, (char)ch) + (char)ch2; break;
            }
        } else { key_str = (char)ch; }
#else
        struct termios oldt, newt;
        tcgetattr(STDIN_FILENO, &oldt);
        newt = oldt; newt.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
        int ch = getchar();
        if (ch == 0x1B) {
            int ch2 = getchar();
            std::string seq = "\x1b";
            if (ch2 != EOF) seq += (char)ch2;
            std::string norm = ansi_to_key_name(seq);
            key_str = norm.empty() ? seq : norm;
        } else if (ch != EOF) key_str = (char)ch;
        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif
        return make_string_len(key_str.data(), key_str.size());
    }

    case BI_AC_TASTE: {
        if (argc < 1 || argc > 2) kr_error("ac_taste 需要 1 或 2 个参数");
        if (A(0).type != VAL_STRING) kr_error("第一个参数必须是字符串");
        std::string key = normalize_key_string(A(0).str_val);
        bool stop = false;
        if (argc == 2) {
            if (A(1).type != VAL_STRING ||
                strcmp(A(1).str_val, "stop") != 0)
                kr_error("第二个参数若存在必须为 \"stop\"");
            stop = true;
        }
        {
            std::lock_guard<std::mutex> lock(g_key_listener_mutex);
            auto it = g_key_listeners.find(key);
            if (it != g_key_listeners.end()) {
                g_key_pressed[key] = true;
                if (it->second.joinable()) it->second.join();
                g_key_listeners.erase(it);
            }
            if (!stop) {
                g_key_pressed[key] = false;
                std::thread t(key_listener_thread_func, key);
                t.detach();
                g_key_listeners[key] = std::move(t);
            }
        }
        return make_null();
    }

    case BI_TASTE_G: {
        REQ(1, "taste_g 需要 1 个参数");
        if (A(0).type != VAL_STRING) kr_error("参数必须是字符串");
        std::string key = normalize_key_string(A(0).str_val);
        bool pressed = g_key_pressed[key].load();
        if (pressed) g_key_pressed[key] = false;
        return make_int64(pressed ? 1 : 0);
    }

    case BI_AKTU: {
        if (argc < 1 || argc > 3) kr_error("aktu 需要 1 到 3 个参数");
        char* str = value_to_string(A(0));
        bool has_line = false;
        int line = -1;
        std::string option;
        bool auto_hide = false;
        if (argc >= 2) {
            if (A(1).type == VAL_INT || A(1).type == VAL_INT64) {
                has_line = true;
                line = (int)value_to_ll(A(1));
                if (argc == 3) {
                    if (A(2).type != VAL_STRING)
                        kr_error("第三个参数必须是字符串");
                    option.assign(A(2).str_val, A(2).str_len);
                }
            } else if (A(1).type == VAL_STRING) {
                if (argc != 2)
                    kr_error("如果第二个参数是选项，则只能有两个参数");
                option.assign(A(1).str_val, A(1).str_len);
            } else {
                kr_error("第二个参数必须是整数或字符串");
            }
        }
        if (!option.empty()) {
            if (option == "verstecken" || option == "v") {
                std::printf("\033[?25l"); std::fflush(stdout);
            } else if (option == "anzeigen" || option == "a") {
                std::printf("\033[?25h"); std::fflush(stdout);
            } else if (option == "auto" || option == "t" || option == "temporaer") {
                auto_hide = true;
            } else {
                kr_error("未知选项: %s", option.c_str());
            }
        }
        if (auto_hide) { std::printf("\033[?25l"); std::fflush(stdout); }
        int scope_id = current_scope ? current_scope->id : 0;
        if (has_line) {
            int ansi_line = line + 1;
            std::printf("\033[%d;0H", ansi_line);
            std::printf("\033[K%s\033[K", str);
            std::fflush(stdout);
            print_lines[scope_id][line] = std::string(str);
        } else {
            std::printf("\r%s", str);
            std::fflush(stdout);
        }
        if (auto_hide) { std::printf("\033[?25h"); std::fflush(stdout); }
        std::free(str);
        return make_null();
    }

    case BI_ZEIG_ALLE: {
        if (argc > 3) kr_error("zeigAlle 最多接受 3 个参数");
        bool show_line_num = false, clear_first = false;
        for (int i = 0; i < argc; ++i) {
            if (A(i).type != VAL_STRING) kr_error("参数必须为字符串");
            std::string opt(A(i).str_val, A(i).str_len);
            if (opt == "klar" || opt == "k") clear_first = true;
            else if (opt == "z") show_line_num = true;
            else if (opt == "global") { /* ignore */ }
            else kr_error("未知参数: %s", opt.c_str());
        }
        if (clear_first) { std::printf("\033[2J\033[H"); std::fflush(stdout); }
        int scope_id = current_scope ? current_scope->id : 0;
        auto it = print_lines.find(scope_id);
        if (it != print_lines.end()) {
            std::vector<int> keys;
            for (auto& p : it->second) keys.push_back(p.first);
            std::sort(keys.begin(), keys.end());
            for (int k : keys) {
                if (show_line_num)
                    std::printf("%d: %s\n", k + 1, it->second[k].c_str());
                else
                    std::printf("%s\n", it->second[k].c_str());
            }
        }
        return make_null();
    }

    case BI_LOESCH: {
        int scope_id = current_scope ? current_scope->id : 0;
        if (argc == 0) {
            auto it = print_lines.find(scope_id);
            if (it != print_lines.end()) it->second.clear();
            return make_null();
        } else if (argc == 1) {
            int line = (int)value_to_ll(A(0));
            auto it = print_lines.find(scope_id);
            if (it != print_lines.end()) it->second.erase(line);
            return make_null();
        } else {
            kr_error("loesch 接受 0 或 1 个参数");
        }
    }

    // ================================================================
    // 异步 / 底层
    // ================================================================
    case BI_AC_AUSF: {
        REQ(1, "ac_ausf 需要 1 个参数");
        if (A(0).type != VAL_STRING) kr_error("参数必须是字符串");
        std::string cmd(A(0).str_val, A(0).str_len);
        int id = ++next_future_id;
        auto future = std::async(std::launch::async,
            [cmd]() -> std::shared_ptr<Value> {
                Value r = run_command_and_capture(cmd);
                Value* heap_val = new Value(copy_value(r));
                free_value(&r);
                return std::shared_ptr<Value>(heap_val,
                    [](Value* p) { if (p) { free_value(p); delete p; } });
            });
        {
            std::lock_guard<std::mutex> lock(future_map_mutex);
            future_map[id] = future.share();
        }
        Value fut_val;
        std::memset(&fut_val, 0, sizeof(Value));
        fut_val.type = VAL_FUTURE;
        fut_val.future_state.future_id = id;
        return fut_val;
    }

    case BI_AUSF: {
        REQ(1, "ausf 需要 1 个参数");
        if (A(0).type != VAL_STRING) kr_error("参数必须是字符串");
        std::string cmd(A(0).str_val, A(0).str_len);
    
        Value r = run_command_and_capture(cmd);
        Value res = copy_value(r);
        free_value(&r);
    
        return res;
    }

    case BI_EXEC: {
        REQ(1, "lauf 需要至少1个参数：exe路径，可选第2参数为字符串数组");
        if (A(0).type != VAL_STRING) kr_error("第1参数必须是字符串（exe路径）");
    
        std::string exe(A(0).str_val, A(0).str_len);
        std::vector<std::string> args;
    
        // 有第二个参数才读取参数数组，否则空参数列表
        if (argc >= 2) {
            if (A(1).type != VAL_ARRAY) kr_error("第2参数必须是字符串数组");
            for (long long i=0; i < A(1).arr_val.length; ++i) {
                auto& elem = A(1).arr_val.elements[i];
                if (elem.type != VAL_STRING) kr_error("参数数组只能是字符串");
                args.emplace_back(elem.str_val, elem.str_len);
            }
        }
    
        Value r = run_exec_no_shell(exe, args);
        Value res = copy_value(r);
        free_value(&r);
        return res;
    }
    
    case BI_AC_EXEC: {
        REQ(1, "ac_lauf 需要至少1个参数：exe路径，可选第2参数为字符串数组");
        if (A(0).type != VAL_STRING) kr_error("第1参数必须是字符串（exe路径）");
    
        std::string exe(A(0).str_val, A(0).str_len);
        std::vector<std::string> args;
    
        // 有第二个参数才读取参数数组，否则空参数列表
        if (argc >= 2) {
            if (A(1).type != VAL_ARRAY) kr_error("第2参数必须是字符串数组");
            for (long long i=0; i < A(1).arr_val.length; ++i) {
                auto& elem = A(1).arr_val.elements[i];
                if (elem.type != VAL_STRING) kr_error("参数数组只能是字符串");
                args.emplace_back(elem.str_val, elem.str_len);
            }
        }
    
        int id = ++next_future_id;
        auto task_ptr = std::make_shared<ProcTask>();
        task_ptr->id = id;
        task_ptr->running = true;
    
        auto future = std::async(std::launch::async, [exe, args, task_ptr]() -> std::shared_ptr<Value> {
            ProcHandle ph = proc_start(exe, args);
            {
                std::lock_guard<std::mutex> lock(task_ptr->proc_mtx);
    #ifdef _WIN32
                task_ptr->hProcess = ph.hProcess;
    #else
                task_ptr->pid = ph.pid;
    #endif
            }
            Value r = proc_read_wait_close(ph);
            Value* heap_val = new Value(copy_value(r));
            free_value(&r);
            {
                std::lock_guard<std::mutex> lock(task_ptr->proc_mtx);
                task_ptr->running = false;
    #ifdef _WIN32
                task_ptr->hProcess = nullptr;
    #else
                task_ptr->pid = -1;
    #endif
            }
            std::lock_guard<std::mutex> g_lock(proc_task_mtx);
            auto it = proc_task_map.find(task_ptr->id);
            if (it != proc_task_map.end()) proc_task_map.erase(it);
    
            return std::shared_ptr<Value>(heap_val,
                [](Value* p) { if (p) { free_value(p); delete p; } });
        });
        task_ptr->future = future.share();
        {
            std::lock_guard<std::mutex> lock(proc_task_mtx);
            proc_task_map[id] = task_ptr;
        }
        Value fut_val;
        std::memset(&fut_val, 0, sizeof(Value));
        fut_val.type = VAL_FUTURE;
        fut_val.future_state.future_id = id;
        return fut_val;
    }    
    
    case BI_PROC_KILL: {
        REQ(1, "aufgTöten 需要1个参数：任务id");
        if (A(0).type != VAL_INT) kr_error("参数必须是任务id整数");
        int task_id = A(0).int64_val;
        std::lock_guard<std::mutex> lock(proc_task_mtx);
        auto it = proc_task_map.find(task_id);
        if (it == proc_task_map.end()) {
            Value ret = make_int64(0);
            return ret;
        }
        auto task = it->second;
        std::lock_guard<std::mutex> plock(task->proc_mtx);
        if (!task->running) {
            Value ret = make_int64(0);
            return ret;
        }
        bool ok = false;
    #ifdef _WIN32
        if (task->hProcess != nullptr) {
            ok = TerminateProcess(task->hProcess, 255);
        }
    #else
        if (task->pid > 0) {
            ok = (kill(task->pid, SIGTERM) == 0);
        }
    #endif
        Value ret = make_int(ok ? 1 : 0);
        return ret;
    }
    
    case BI_PROC_QUERY: {
        REQ(1, "aufgAnf 需要1个参数：任务id");
        if (A(0).type != VAL_INT) kr_error("参数必须是任务id整数");
        int task_id = A(0).int64_val;
        std::lock_guard<std::mutex> lock(proc_task_mtx);
        auto it = proc_task_map.find(task_id);
        if (it == proc_task_map.end()) {
            Value ret = make_int64(0);
            return ret;
        }
        auto task = it->second;
        std::lock_guard<std::mutex> plock(task->proc_mtx);
        Value ret = make_int(task->running ? 1 : 0);
        return ret;
    }    

    case BI_BC: {
        REQ(1, "BC 需要 1 个字节数组");
        if (A(0).type != VAL_ARRAY)
            kr_error("参数必须是字节数组 (0-255)");

        size_t size = (size_t)A(0).arr_val.length;
        if (size == 0) return make_int64(0);

        unsigned char* code = (unsigned char*)std::malloc(size);
        if (!code) kr_error("内存分配失败");
        for (size_t i = 0; i < size; ++i) {
            const Value& elem = A(0).arr_val.elements[i];
            if (elem.type != VAL_INT && elem.type != VAL_INT64) {
                std::free(code);
                kr_error("字节数组元素必须是整数");
            }
            long long byte = value_to_ll(elem);
            if (byte < 0 || byte > 255) {
                std::free(code);
                kr_error("字节值必须在 0-255 之间");
            }
            code[i] = (unsigned char)byte;
        }

        void* exec_mem = nullptr;
#ifdef _WIN32
        exec_mem = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE,
                                PAGE_EXECUTE_READWRITE);
        if (!exec_mem) { std::free(code); kr_error("VirtualAlloc 失败"); }
#else
        exec_mem = mmap(NULL, size, PROT_READ | PROT_WRITE | PROT_EXEC,
                        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (exec_mem == MAP_FAILED) {
            std::free(code);
            kr_error("mmap 失败");
        }
#endif
        std::memcpy(exec_mem, code, size);
        std::free(code);
#ifdef __GNUC__
        __builtin___clear_cache((char*)exec_mem, (char*)exec_mem + size);
#endif

        typedef int (*func_t)(void);
        func_t f = (func_t)exec_mem;
        int ret_val = f();

#ifdef _WIN32
        VirtualFree(exec_mem, 0, MEM_RELEASE);
#else
        munmap(exec_mem, size);
#endif
        return make_int64((int64_t)ret_val);
    }

        // ================================================================
    // 元编程 / 外部工具
    // ================================================================
    case BI_KRKOM: {
        if (argc != 3)
            kr_error("KRKom 需要 3 个参数: 文件名, 共享作用域(布尔), 代码字符串");
        if (A(0).type != VAL_STRING)
            kr_error("KRKom 第一个参数必须是文件名(字符串)");
        if (A(1).type != VAL_INT && A(1).type != VAL_INT64)
            kr_error("KRKom 第二个参数必须是布尔值(0 或 1)");
        if (A(2).type != VAL_STRING)
            kr_error("KRKom 第三个参数必须是代码字符串");

        bool share = value_to_bool(A(1)) != 0;
        const char* filename = A(0).str_val;
        const char* code     = A(2).str_val;

        struct ContextGuard {
            const char* old_filename;
            char* old_source;
            int old_line, old_col;
            Token* saved_tokens;
            int saved_token_count;
            int saved_tok_pos;
            int saved_last_token_line, saved_last_token_col;
            int saved_stmt_start_line, saved_stmt_start_col;
            Scope* old_scope;
            bool old_return, old_break, old_continue, old_exception;
            Value old_return_val, old_exception_val;
            std::map<int, std::string> old_line_to_file;
            Value* old_return_slot;
            bool shared;

            ContextGuard(const char* new_filename, const char* new_code, bool share_)
                : old_filename(current_filename),
                  old_source(source_code),
                  old_line(g_last_error_line),
                  old_col(g_last_error_col),
                  saved_tokens(tokens),
                  saved_token_count(token_count),
                  saved_tok_pos(tok_pos),
                  saved_last_token_line(g_last_token_line),
                  saved_last_token_col(g_last_token_col),
                  saved_stmt_start_line(g_stmt_start_line),
                  saved_stmt_start_col(g_stmt_start_col),
                  old_scope(current_scope),
                  old_return(return_caught),
                  old_break(break_caught),
                  old_continue(continue_caught),
                  old_exception(exception_raised),
                  old_return_val(copy_value(return_value)),
                  old_exception_val(copy_value(exception_value)),
                  old_line_to_file(g_line_to_file),
                  old_return_slot(g_current_return_slot),
                  shared(share_)
            {
                static std::string filename_storage;
                filename_storage = new_filename;
                current_filename = filename_storage.c_str();
                g_custom_source_context = new_code;

                g_last_error_line = 1;
                g_last_error_col  = 1;

                return_caught = break_caught = continue_caught = exception_raised = false;

                source_code = strdup(new_code);

                if (!shared) push_scope();
            }

            ~ContextGuard() {
                if (source_code && source_code != old_source) free(source_code);
                source_code = old_source;

                current_filename = old_filename;
                g_custom_source_context.clear();

                g_last_error_line = old_line;
                g_last_error_col  = old_col;

                if (tokens != saved_tokens) free_tokens();
                tokens = saved_tokens;
                token_count = saved_token_count;
                tok_pos = saved_tok_pos;
                g_last_token_line = saved_last_token_line;
                g_last_token_col  = saved_last_token_col;
                g_stmt_start_line = saved_stmt_start_line;
                g_stmt_start_col  = saved_stmt_start_col;

                g_line_to_file = old_line_to_file;

                if (!shared) {
                    if (current_scope != old_scope) pop_scope();
                }
                current_scope = old_scope;

                return_caught    = old_return;
                break_caught     = old_break;
                continue_caught  = old_continue;
                exception_raised = old_exception;

                free_value(&return_value);
                return_value = copy_value(old_return_val);
                free_value(&exception_value);
                exception_value = copy_value(old_exception_val);

                g_current_return_slot = old_return_slot;

                free_value(&old_return_val);
                free_value(&old_exception_val);
            }
        };

        Value result_val = make_null();
        {
            ContextGuard guard(filename, code, share);
            tokenize_impl(code);
            ASTNode* ast = parse_program();
            exec_statement(ast);

            if (return_caught) {
                result_val = copy_value(return_value);
                return_caught = false;
                free_value(&return_value);
                return_value = make_null();
            } else {
                ASTNode* last = get_last_expr_from_block(ast);
                if (last) result_val = eval_expr(last);
                else      result_val = make_null();
            }

            if (exception_raised) {
                free_value(&exception_value);
                exception_raised = false;
            }

            free_ast(ast);
        }
        return result_val;
    }

    case BI_CPP: {
        if (argc < 1) kr_error("cpp 需要至少 1 个参数（源码字符串）");
        if (A(0).type != VAL_STRING) kr_error("cpp 的第一个参数必须是字符串（C++ 源码）");

        bool run = true;
        long long timeout_ms = 5000;
        std::string compiler = "g++";
        std::string flags = "-std=c++17 -O2";
        bool json_mode = false;
        Value bind_obj = make_null();
        bool has_bind = false;

        if (argc >= 2) {
            const Value& opts = A(1);
            if (opts.type == VAL_OBJECT) {
                for (int i = 0; i < opts.obj_val.count; ++i) {
                    const char* key = opts.obj_val.entries[i].key;
                    const Value& val = opts.obj_val.entries[i].value;
                    if (strcmp(key, "compiler") == 0 && val.type == VAL_STRING)
                        compiler = val.str_val;
                    else if (strcmp(key, "flags") == 0 && val.type == VAL_STRING)
                        flags = val.str_val;
                    else if (strcmp(key, "timeout") == 0)
                        timeout_ms = (long long)value_to_double(val);
                    else if (strcmp(key, "run") == 0)
                        run = value_to_bool(val) != 0;
                    else if (strcmp(key, "mode") == 0 && val.type == VAL_STRING) {
                        if (strcmp(val.str_val, "json") == 0) json_mode = true;
                    }
                    else if (strcmp(key, "bind") == 0) {
                        bind_obj = copy_value(val);
                        has_bind = true;
                    }
                }
            } else {
                kr_warn("cpp 第二个参数应为对象，忽略");
            }
        }

        // ---- 内嵌 JSON helper + KR:: 辅助命名空间 ----
        const char* json_helper = R"(
            #include <iostream>
            #include <fstream>
            #include <sstream>
            #include <map>
            #include <vector>
            #include <variant>
            #include <string>
            #include <stdexcept>
            #include <cctype>
            class JSON {
            public:
                using Object = std::map<std::string, JSON>;
                using Array = std::vector<JSON>;
                using Value = std::variant<std::nullptr_t, bool, long long, double, std::string, Object, Array>;
                JSON() : val_(nullptr) {}
                JSON(std::nullptr_t) : val_(nullptr) {}
                JSON(bool b) : val_(b) {}
                JSON(long long i) : val_(i) {}
                explicit JSON(double d) : val_(d) {}
                JSON(const std::string& s) : val_(s) {}
                JSON(const char* s) : val_(std::string(s)) {}
                JSON(const Object& o) : val_(o) {}
                JSON(const Array& a) : val_(a) {}
                static JSON parse(const std::string& str) { size_t pos = 0; return parse_value(str, pos); }
                std::string serialize() const { return serialize_value(*this, 0); }
                bool is_null() const { return std::holds_alternative<std::nullptr_t>(val_); }
                bool is_bool() const { return std::holds_alternative<bool>(val_); }
                bool is_int() const { return std::holds_alternative<long long>(val_); }
                bool is_double() const { return std::holds_alternative<double>(val_); }
                bool is_string() const { return std::holds_alternative<std::string>(val_); }
                bool is_object() const { return std::holds_alternative<Object>(val_); }
                bool is_array() const { return std::holds_alternative<Array>(val_); }
                bool as_bool() const { return std::get<bool>(val_); }
                long long as_int() const { return std::get<long long>(val_); }
                double as_double() const { return std::get<double>(val_); }
                std::string as_string() const { return std::get<std::string>(val_); }
                Object as_object() const { return std::get<Object>(val_); }
                Array as_array() const { return std::get<Array>(val_); }
                JSON& operator[](const std::string& key) { if (!is_object()) val_ = Object{}; return std::get<Object>(val_)[key]; }
                JSON& operator[](size_t idx) { if (!is_array()) val_ = Array{}; auto& a = std::get<Array>(val_); if (idx >= a.size()) a.resize(idx + 1); return a[idx]; }
            private:
                Value val_;
                static void skip_ws(const std::string& s, size_t& pos) { while (pos < s.size() && std::isspace(s[pos])) ++pos; }
                static JSON parse_value(const std::string& s, size_t& pos) {
                    skip_ws(s, pos);
                    if (pos >= s.size()) throw std::runtime_error("Unexpected EOF");
                    char c = s[pos];
                    if (c == 'n') { if (s.compare(pos, 4, "null") == 0) { pos += 4; return JSON(nullptr); } throw std::runtime_error("Expected null"); }
                    else if (c == 't') { if (s.compare(pos, 4, "true") == 0) { pos += 4; return JSON(true); } throw std::runtime_error("Expected true"); }
                    else if (c == 'f') { if (s.compare(pos, 5, "false") == 0) { pos += 5; return JSON(false); } throw std::runtime_error("Expected false"); }
                    else if (c == '"') {
                        ++pos; std::string str;
                        while (pos < s.size() && s[pos] != '"') {
                            if (s[pos] == '\\') { ++pos; char esc = s[pos++];
                                switch (esc) { case '"': str += '"'; break; case '\\': str += '\\'; break;
                                case '/': str += '/'; break; case 'b': str += '\b'; break; case 'f': str += '\f'; break;
                                case 'n': str += '\n'; break; case 'r': str += '\r'; break; case 't': str += '\t'; break;
                                case 'u': { if (pos + 4 > s.size()) throw std::runtime_error("Invalid unicode");
                                    std::string hex = s.substr(pos, 4); pos += 4;
                                    unsigned int code = std::stoul(hex, nullptr, 16);
                                    if (code < 0x80) str += char(code);
                                    else if (code < 0x800) { str += char(0xC0 | (code >> 6)); str += char(0x80 | (code & 0x3F)); }
                                    else { str += char(0xE0 | (code >> 12)); str += char(0x80 | ((code >> 6) & 0x3F)); str += char(0x80 | (code & 0x3F)); }
                                    break; }
                                default: throw std::runtime_error("Unknown escape"); } }
                            else str += s[pos++];
                        }
                        if (pos >= s.size() || s[pos] != '"') throw std::runtime_error("Unterminated string");
                        ++pos; return JSON(str);
                    } else if (c == '{') {
                        ++pos; Object obj; skip_ws(s, pos);
                        if (pos < s.size() && s[pos] == '}') { ++pos; return JSON(obj); }
                        while (true) {
                            JSON key = parse_value(s, pos);
                            if (!key.is_string()) throw std::runtime_error("Object key must be string");
                            skip_ws(s, pos);
                            if (pos >= s.size() || s[pos] != ':') throw std::runtime_error("Expected ':'");
                            ++pos; JSON val = parse_value(s, pos); obj[key.as_string()] = val; skip_ws(s, pos);
                            if (pos >= s.size()) throw std::runtime_error("Unterminated object");
                            if (s[pos] == ',') { ++pos; continue; } else if (s[pos] == '}') { ++pos; break; }
                            else throw std::runtime_error("Expected ',' or '}'");
                        }
                        return JSON(obj);
                    } else if (c == '[') {
                        ++pos; Array arr; skip_ws(s, pos);
                        if (pos < s.size() && s[pos] == ']') { ++pos; return JSON(arr); }
                        while (true) {
                            arr.push_back(parse_value(s, pos)); skip_ws(s, pos);
                            if (pos >= s.size()) throw std::runtime_error("Unterminated array");
                            if (s[pos] == ',') { ++pos; continue; } else if (s[pos] == ']') { ++pos; break; }
                            else throw std::runtime_error("Expected ',' or ']'");
                        }
                        return JSON(arr);
                    } else if (c == '-' || std::isdigit(c)) {
                        size_t start = pos; if (c == '-') ++pos;
                        while (pos < s.size() && std::isdigit(s[pos])) ++pos;
                        bool is_float = false;
                        if (pos < s.size() && s[pos] == '.') { ++pos; while (pos < s.size() && std::isdigit(s[pos])) ++pos; is_float = true; }
                        if (pos < s.size() && (s[pos] == 'e' || s[pos] == 'E')) {
                            ++pos; if (pos < s.size() && (s[pos] == '+' || s[pos] == '-')) ++pos;
                            while (pos < s.size() && std::isdigit(s[pos])) ++pos; is_float = true;
                        }
                        std::string num = s.substr(start, pos - start);
                        if (is_float) return JSON(std::stod(num));
                        else return JSON(std::stoll(num));
                    } else throw std::runtime_error("Unexpected character");
                }
                static std::string serialize_value(const JSON& val, int indent) {
                    std::string indent_str(indent, ' ');
                    std::string result;
                    if (val.is_null()) result = "null";
                    else if (val.is_bool()) result = val.as_bool() ? "true" : "false";
                    else if (val.is_int()) result = std::to_string(val.as_int());
                    else if (val.is_double()) { std::string s = std::to_string(val.as_double());
                        if (s.find('.') != std::string::npos) { while (s.size() > 1 && s.back() == '0') s.pop_back(); if (s.back() == '.') s.pop_back(); } result = s; }
                    else if (val.is_string()) result = "\"" + escape_string(val.as_string()) + "\"";
                    else if (val.is_object()) {
                        result = "{"; bool first = true;
                        for (const auto& pair : std::get<Object>(val.val_)) {
                            if (!first) result += ",";
                            if (indent >= 0) result += "\n" + indent_str + "  "; else result += " ";
                            result += "\"" + escape_string(pair.first) + "\":" + (indent >= 0 ? " " : "");
                            result += serialize_value(pair.second, indent >= 0 ? indent + 2 : -1);
                            first = false;
                        }
                        if (indent >= 0) result += "\n" + indent_str;
                        result += "}";
                    } else if (val.is_array()) {
                        result = "[";
                        const auto& arr = std::get<Array>(val.val_);
                        for (size_t i = 0; i < arr.size(); ++i) {
                            if (i > 0) result += ",";
                            if (indent >= 0) result += "\n" + indent_str + "  "; else result += " ";
                            result += serialize_value(arr[i], indent >= 0 ? indent + 2 : -1);
                        }
                        if (indent >= 0 && !arr.empty()) result += "\n" + indent_str;
                        result += "]";
                    }
                    return result;
                }
                static std::string escape_string(const std::string& s) {
                    std::string out;
                    for (char c : s) {
                        switch (c) {
                            case '"':  out += "\\\""; break;
                            case '\\': out += "\\\\"; break;
                            case '\b': out += "\\b"; break;
                            case '\f': out += "\\f"; break;
                            case '\n': out += "\\n"; break;
                            case '\r': out += "\\r"; break;
                            case '\t': out += "\\t"; break;
                            default: if (static_cast<unsigned char>(c) < 0x20) { char buf[7]; snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c); out += buf; } else out += c;
                        }
                    }
                    return out;
                }
            };
        )";

        const char* kr_helper = R"(
            namespace KR {
                inline JSON get(const JSON& input, const std::string& name) {
                    if (input.is_object()) { auto obj = input.as_object(); auto it = obj.find(name); if (it != obj.end()) return it->second; }
                    return JSON(nullptr);
                }
                inline void set(JSON& output, const std::string& name, long long value)      { output["__kr_set"][name] = JSON(value); }
                inline void set(JSON& output, const std::string& name, int value)            { set(output, name, static_cast<long long>(value)); }
                inline void set(JSON& output, const std::string& name, double value)         { output["__kr_set"][name] = JSON(value); }
                inline void set(JSON& output, const std::string& name, const char* value)    { output["__kr_set"][name] = JSON(value); }
                inline void set(JSON& output, const std::string& name, const std::string& v) { output["__kr_set"][name] = JSON(v); }
                inline void set(JSON& output, const std::string& name, const JSON& value)    { output["__kr_set"][name] = value; }
            }
        )";

        static std::atomic<int> cpp_counter{0};
        auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        std::string base_name = "kr_cpp_" + std::to_string(now) + "_" + std::to_string(cpp_counter++);

#ifdef _WIN32
        std::string exe_suffix = ".exe";
#else
        std::string exe_suffix = "";
#endif

        fs::path temp_dir    = fs::temp_directory_path();
        fs::path src_path    = temp_dir / (base_name + ".cpp");
        fs::path exe_path    = temp_dir / (base_name + exe_suffix);
        fs::path out_path    = temp_dir / (base_name + ".out");
        fs::path err_path    = temp_dir / (base_name + ".err");
        fs::path input_path  = temp_dir / (base_name + ".json");

        if (json_mode && has_bind) {
            std::string json_str = json_stringify_value(bind_obj, false, 0);
            std::ofstream ifs(input_path.string());
            if (!ifs) kr_error("无法创建临时 JSON 输入文件");
            ifs << json_str;
            ifs.close();
        }

        std::string user_code(A(0).str_val, A(0).str_len);
        std::string source_code_full = std::string(json_helper) + "\n" + kr_helper + "\n\n" + user_code;

        std::ofstream src_file(src_path.string(), std::ios::binary);
        if (!src_file) kr_error("无法创建临时源码文件");
        src_file << source_code_full;
        src_file.close();

        std::string compile_cmd = compiler + " " + flags + " " + src_path.string()
                                + " -o " + exe_path.string() + " 2>" + err_path.string();
        int compile_ret = std::system(compile_cmd.c_str());

        std::string stderr_content;
        {
            std::ifstream ef(err_path.string());
            if (ef) { std::stringstream ss; ss << ef.rdbuf(); stderr_content = ss.str(); }
        }

        auto cleanup_files = [&]() {
            std::remove(src_path.string().c_str());
            std::remove(exe_path.string().c_str());
            std::remove(out_path.string().c_str());
            std::remove(err_path.string().c_str());
            std::remove(input_path.string().c_str());
        };

        if (compile_ret != 0) {
            ObjectEntry entries[3];
            entries[0].key = strdup("ok");    entries[0].value = make_int64(0LL);
            entries[1].key = strdup("code");  entries[1].value = make_int64(compile_ret);
            entries[2].key = strdup("fehl");  entries[2].value = make_string(stderr_content.c_str());
            Value r = make_object(entries, 3);
            for (int i = 0; i < 3; ++i) { free(entries[i].key); free_value(&entries[i].value); }
            cleanup_files();
            return r;
        }

        if (!run) {
            ObjectEntry entries[3];
            entries[0].key = strdup("ok");    entries[0].value = make_int64(1LL);
            entries[1].key = strdup("code");  entries[1].value = make_int64(0LL);
            entries[2].key = strdup("fehl");  entries[2].value = make_string(stderr_content.c_str());
            Value r = make_object(entries, 3);
            for (int i = 0; i < 3; ++i) { free(entries[i].key); free_value(&entries[i].value); }
            cleanup_files();
            return r;
        }

        std::string run_cmd = exe_path.string();
        if (json_mode && has_bind) run_cmd += " " + input_path.string();
        run_cmd += " > " + out_path.string() + " 2> " + err_path.string();

        auto future = std::async(std::launch::async, [&]() -> int {
            return std::system(run_cmd.c_str());
        });

        int exit_code = -1;
        bool timeout = false;
        if (timeout_ms > 0) {
            auto status = future.wait_for(std::chrono::milliseconds(timeout_ms));
            if (status == std::future_status::timeout) { timeout = true; exit_code = -1; }
            else                                       exit_code = future.get();
        } else {
            exit_code = future.get();
        }

        std::string stdout_content, stderr_content2;
        {
            std::ifstream of(out_path.string());
            if (of) { std::stringstream ss; ss << of.rdbuf(); stdout_content = ss.str(); }
        }
        {
            std::ifstream ef(err_path.string());
            if (ef) { std::stringstream ss; ss << ef.rdbuf(); stderr_content2 = ss.str(); }
        }

        cleanup_files();

        if (json_mode && exit_code == 0 && !timeout) {
            try {
                JSONParser parser(stdout_content);
                Value json_val = parser.parse();

                if (json_val.type == VAL_OBJECT) {
                    // 应用 __kr_set
                    for (int i = 0; i < json_val.obj_val.count; ++i) {
                        if (strcmp(json_val.obj_val.entries[i].key, "__kr_set") == 0) {
                            Value& set_obj = json_val.obj_val.entries[i].value;
                            if (set_obj.type == VAL_OBJECT) {
                                for (int j = 0; j < set_obj.obj_val.count; ++j) {
                                    const char* varname = set_obj.obj_val.entries[j].key;
                                    Value varval = copy_value(set_obj.obj_val.entries[j].value);
                                    Variable* var = get_var(varname, false);
                                    if (var) {
                                        if (var->is_const) { free_value(&varval); continue; }
                                        free_value(&var->value);
                                        var->value = varval;
                                    } else {
                                        declare_var(varname, false, varval);
                                    }
                                }
                            }
                            break;
                        }
                    }

                    // 剥掉 __kr_set 返回干净对象
                    ObjectEntry* new_entries = nullptr;
                    int new_count = 0;
                    for (int i = 0; i < json_val.obj_val.count; ++i) {
                        if (strcmp(json_val.obj_val.entries[i].key, "__kr_set") != 0) {
                            new_entries = (ObjectEntry*)realloc(new_entries, (new_count + 1) * sizeof(ObjectEntry));
                            new_entries[new_count].key   = strdup(json_val.obj_val.entries[i].key);
                            new_entries[new_count].value = copy_value(json_val.obj_val.entries[i].value);
                            ++new_count;
                        }
                    }
                    free_value(&json_val);
                    Value clean_obj = make_object(new_entries, new_count);
                    for (int i = 0; i < new_count; ++i) { free(new_entries[i].key); free_value(&new_entries[i].value); }
                    free(new_entries);
                    return clean_obj;
                }
                return json_val;
            } catch (const KRError& e) {
                ObjectEntry entries[4];
                entries[0].key = strdup("ok");   entries[0].value = make_int64(0LL);
                entries[1].key = strdup("code"); entries[1].value = make_int64(exit_code);
                entries[2].key = strdup("fehl"); entries[2].value = make_string(("JSON 解析失败: " + std::string(e.what())).c_str());
                entries[3].key = strdup("out");  entries[3].value = make_string(stdout_content.c_str());
                Value r = make_object(entries, 4);
                for (int i = 0; i < 4; ++i) { free(entries[i].key); free_value(&entries[i].value); }
                return r;
            }
        }

        ObjectEntry entries[4];
        entries[0].key = strdup("ok");   entries[0].value = make_int64((exit_code == 0 && !timeout) ? 1LL : 0LL);
        entries[1].key = strdup("code"); entries[1].value = make_int64(exit_code);
        entries[2].key = strdup("fehl"); entries[2].value = make_string((timeout ? std::string("超时") : stderr_content2).c_str());
        entries[3].key = strdup("erg");  entries[3].value = make_string(stdout_content.c_str());
        Value r = make_object(entries, 4);
        for (int i = 0; i < 4; ++i) { free(entries[i].key); free_value(&entries[i].value); }
        return r;
    }

    case BI_ASM: {
        if (argc < 1) kr_error("asm benötigt mindestens 1 Argument (Assembler-Code)");
        if (A(0).type != VAL_STRING) kr_error("asm erster Parameter muss ein String sein");

        std::string asm_code(A(0).str_val, A(0).str_len);

        static std::atomic<int> asm_counter{0};
        auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        std::string base_name = "kr_asm_" + std::to_string(now) + "_" + std::to_string(asm_counter++);
        fs::path temp_dir = fs::temp_directory_path();
        fs::path src_path = temp_dir / (base_name + ".asm");
        fs::path bin_path = temp_dir / (base_name + ".bin");

        {
            std::ofstream sf(src_path.string());
            if (!sf) kr_error("无法创建临时汇编文件");
            sf << asm_code;
        }

        std::string compile_cmd = "nasm -f bin -o " + bin_path.string() + " " + src_path.string() + " 2>&1";
        int ret = std::system(compile_cmd.c_str());
        if (ret != 0) {
            std::remove(src_path.string().c_str());
            kr_error("nasm 编译失败 (返回码 %d)，请确保 nasm 已安装并在 PATH 中", ret);
        }

        std::ifstream bf(bin_path.string(), std::ios::binary | std::ios::ate);
        if (!bf) {
            std::remove(src_path.string().c_str());
            std::remove(bin_path.string().c_str());
            kr_error("无法读取生成的二进制文件");
        }
        std::streamsize size = bf.tellg();
        if (size <= 0) {
            bf.close();
            std::remove(src_path.string().c_str());
            std::remove(bin_path.string().c_str());
            kr_error("生成的二进制文件为空");
        }
        bf.seekg(0, std::ios::beg);
        std::vector<unsigned char> code((size_t)size);
        bf.read(reinterpret_cast<char*>(code.data()), size);
        bf.close();

        std::remove(src_path.string().c_str());
        std::remove(bin_path.string().c_str());

        void* exec_mem = nullptr;
#ifdef _WIN32
        exec_mem = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
        if (!exec_mem) kr_error("VirtualAlloc fehlgeschlagen");
#else
        exec_mem = mmap(NULL, (size_t)size, PROT_READ | PROT_WRITE | PROT_EXEC,
                        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (exec_mem == MAP_FAILED) kr_error("mmap fehlgeschlagen");
#endif
        std::memcpy(exec_mem, code.data(), (size_t)size);
#ifdef __GNUC__
        __builtin___clear_cache((char*)exec_mem, (char*)exec_mem + size);
#endif

        typedef int (*func_t)(void);
        func_t f = (func_t)exec_mem;
        int result_val = f();

#ifdef _WIN32
        VirtualFree(exec_mem, 0, MEM_RELEASE);
#else
        munmap(exec_mem, (size_t)size);
#endif
        return make_int64((int64_t)result_val);
    }

    case BI_VA: {
        if (argc != 1) kr_error("va 需要 1 个参数（代码字符串）");
        if (A(0).type != VAL_STRING || A(0).str_val == nullptr)
            kr_error("va 参数必须是字符串");
        if (A(0).str_len == 0) return make_null();
        std::string arg_str(A(0).str_val, A(0).str_len);
        static std::atomic<int> va_counter{0};
        auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        std::string base_name = "kr_va_" + std::to_string(now) + "_" + std::to_string(va_counter++);
        fs::path temp_dir = fs::temp_directory_path();
        fs::path va_file  = temp_dir / (base_name + ".va");
        {
            std::ofstream ofs(va_file.string(), std::ios::binary);
            if (!ofs) kr_error("无法创建临时 VA 文件");
            ofs << arg_str;
        }
    
        Value result_val;
        std::vector<std::string> args;
        args.push_back(va_file.string()); // va 的命令行参数：va [va_file]
        try {
            result_val = run_exec_no_shell("va", args);
        } catch (...) {
            // 捕获执行异常，标记为找不到程序，进入 fallback 分支
            free_value(&result_val);
            ObjectEntry err_entries[4];
            err_entries[0].key = strdup("code");
            err_entries[0].value = make_int(127);
            err_entries[1].key = strdup("erg");
            err_entries[1].value = make_string("");
            err_entries[2].key = strdup("fehl");
            err_entries[2].value = make_string("nicht gefunden");
            err_entries[3].key = strdup("abnorm");
            err_entries[3].value = make_int64(0);
            result_val = make_object(err_entries, 4);
            for (int i = 0; i <4; ++i) {
                free(err_entries[i].key);
                free_value(&err_entries[i].value);
            }
        }
    
        long long exit_code = 0;
        if (result_val.type == VAL_OBJECT && result_val.obj_val.count > 0) {
            Value& cv = result_val.obj_val.entries[0].value;
            if (cv.type == VAL_INT || cv.type == VAL_INT64) exit_code = value_to_ll(cv);
        }
        bool use_fallback = false;
        if (exit_code != 0 && result_val.type == VAL_OBJECT && result_val.obj_val.count > 2) {
            Value& err_val = result_val.obj_val.entries[2].value;
            if (err_val.type == VAL_STRING) {
                std::string err_msg(err_val.str_val, err_val.str_len);
                if (err_msg.find("nicht gefunden") != std::string::npos ||
                    err_msg.find("nicht erkannt") != std::string::npos ||
                    err_msg.find("Keine solche Datei") != std::string::npos) {
                    use_fallback = true;
                }
            }
        }
        if (use_fallback) {
            fs::path va_path = exe_dir / "va" / "va";
    #ifdef _WIN32
            va_path.replace_extension(".exe");
    #endif
            if (fs::exists(va_path)) {
                std::vector<std::string> fallback_args;
                fallback_args.push_back(va_file.string());
                free_value(&result_val);
                // fallback 也使用无shell执行
                result_val = run_exec_no_shell(va_path.string(), fallback_args);
            } else {
                free_value(&result_val);
                std::remove(va_file.string().c_str());
                kr_error("找不到 va 程序，请确保 va 在 PATH 中或位于 %s", exe_dir.string().c_str());
            }
        }
        // 检查是否系统级崩溃
        {
            long long final_exit = 0;
            bool has_exit = false, is_abnormal = false;
            if (result_val.type == VAL_OBJECT && result_val.obj_val.count > 0) {
                Value& cv = result_val.obj_val.entries[0].value;
                if (cv.type == VAL_INT || cv.type == VAL_INT64) {
                    final_exit = value_to_ll(cv);
                    has_exit = true;
                }
                for (int i = 0; i < result_val.obj_val.count; ++i) {
                    if (strcmp(result_val.obj_val.entries[i].key, "abnorm") == 0) {
                        Value& abn = result_val.obj_val.entries[i].value;
                        if (abn.type == VAL_INT || abn.type == VAL_INT64)
                            is_abnormal = value_to_ll(abn) != 0;
                        break;
                    }
                }
            }
            if (has_exit && is_abnormal) {
                std::string err_msg;
                if (result_val.type == VAL_OBJECT && result_val.obj_val.count > 2 &&
                    result_val.obj_val.entries[2].value.type == VAL_STRING) {
                    err_msg.assign(result_val.obj_val.entries[2].value.str_val,
                                   result_val.obj_val.entries[2].value.str_len);
                }
                std::remove(va_file.string().c_str());
                free_value(&result_val);
                kr_error("va 异常终止（可能发生段错误或崩溃，退出码 %lld）%s%s",
                         final_exit,
                         err_msg.empty() ? "" : ": ", err_msg.c_str());
            }
        }
        std::remove(va_file.string().c_str());
        return result_val;
    }    

    default:
        kr_error("未实现的内置函数 ID=%u", (unsigned)id);
    }
    return make_null();
    #undef REQ
}

static Value vm_invoke(const Value& fn, Value* args, int argc) {
    if (fn.type != VAL_FUNCTION)
        kr_error("vm_invoke: 实参不是函数 (type=%d)", (int)fn.type);
    if (!g_active_vm)
        kr_error("vm_invoke: 当前线程没有活动 VM");

    int func_idx = fn.func_val.compiled_idx;

    // compiled_idx 不可用 → 按名字回退（和 OP_CALL / OP_CALL_VALUE 同策略）
    if (func_idx < 0 && fn.func_val.name)
        func_idx = g_active_vm->find_func_by_name(fn.func_val.name);

    if (func_idx < 0)
        kr_error("vm_invoke: 函数 '%s' 未编译 (compiled_idx=%d)",
                 fn.func_val.name ? fn.func_val.name : "<?>",
                 fn.func_val.compiled_idx);

    const int total = g_active_vm->function_count();
    if (func_idx >= total)
        kr_error("vm_invoke: 函数索引 %d 越界 (总数 %d)", func_idx, total);

    return g_active_vm->call_compiled(func_idx, args, argc);
}

static Value vm_invoke_http_handler(const Value& handler,
                                    const Bytecode* bc,
                                    Scope*          root_scope,
                                    Value           req) {
    VM local_vm;
    auto ctx = local_vm.enter_thread_context(bc, root_scope);

    Value result = make_null();
    try {
        int func_idx = handler.func_val.compiled_idx;
        if (func_idx >= 0) {
            result = local_vm.call_compiled(func_idx, &req, 1);
        } else {
            // 旧式（解释期）函数值，回退原路径
            result = call_function_value(handler, &req, 1, nullptr);
        }
    } catch (...) {
        local_vm.exit_thread_context(ctx);
        throw;
    }
    local_vm.exit_thread_context(ctx);
    return result;
}

static void vm_force_eval_lazy_var(Variable* var) {
    if (g_active_vm) g_active_vm->force_eval_lazy(var);
}

void VM::vm_enter_function_call(const CompiledFunction& cf,
                                int func_idx, int argc,
                                const Value* dies_obj)
{
    const int param_count = (int)cf.params.size();
    const bool has_vararg = !cf.vararg_name.empty();

    // ---- 1. 参数数量校验 ----
    if (!has_vararg && argc > param_count)
        kr_error("'%s' 参数过多：期望 %d，实际 %d",
                 cf.name.c_str(), param_count, argc);
    for (int i = argc; i < param_count; ++i) {
        bool has = (i < (int)cf.param_has_default.size() && cf.param_has_default[i])
                || (i < (int)cf.param_defaults_idx.size() && cf.param_defaults_idx[i] >= 0);
        if (!has)
            kr_error("'%s' 缺少参数 '%s'",
                     cf.name.c_str(), cf.params[i].c_str());
    }

    const size_t stack_base = stack.size() - (size_t)argc;

    // ---- 2. 类型校验（只校验实际提供的固定参数）----
    const int check = (argc < param_count) ? argc : param_count;
    for (int i = 0; i < check; ++i) {
        if (i >= (int)cf.param_types.size() || cf.param_types[i].empty()) continue;
        if (!vm_check_type(stack[stack_base + i], cf.param_types[i]))
            kr_error("'%s' 参数 '%s' 类型错误：期望 '%s'",
                     cf.name.c_str(), cf.params[i].c_str(),
                     cf.param_types[i].c_str());
    }

    // ---- 3. 新作用域 ----
    push_scope();

    // ---- 4. dies 注入（类方法 / 对象函数值专用）----
    if (dies_obj)
        declare_var_in_scope(current_scope, "dies", false, copy_value(*dies_obj));

    // ---- 5. 绑已提供的固定参数 ----
    const int bound = (argc < param_count) ? argc : param_count;
    for (int i = 0; i < bound; ++i) {
        bool is_const = (i < (int)cf.param_is_const.size()) ? cf.param_is_const[i] : false;
        declare_var_in_scope(current_scope, cf.params[i].c_str(), is_const,
                             stack[stack_base + i]);
    }

    // ---- 6. 缺失参数求默认值 ----
    for (int i = bound; i < param_count; ++i) {
        Value defval;
        int di = (i < (int)cf.param_defaults_idx.size()) ? cf.param_defaults_idx[i] : -1;
        if (di >= 0) {
            defval = copy_value(bc->constants[di]);
        } else if (i < (int)cf.param_default_code_off.size()
                   && cf.param_default_code_off[i] != SIZE_MAX) {
            size_t save_pc = pc;
            pc = cf.param_default_code_off[i];
            run_until(cf.param_default_code_end[i]);
            defval = std::move(stack.back());
            stack.pop_back();
            pc = save_pc;
        } else {
            defval = make_null();
        }
        bool is_const = (i < (int)cf.param_is_const.size()) ? cf.param_is_const[i] : false;
        declare_var_in_scope(current_scope, cf.params[i].c_str(), is_const, defval);
    }

    // ---- 7. 可变参数收集 ----
    if (has_vararg) {
        const int vc = (argc > param_count) ? (argc - param_count) : 0;
        Value* elems = vc ? (Value*)malloc((size_t)vc * sizeof(Value)) : nullptr;
        for (int i = 0; i < vc; ++i)
            elems[i] = stack[stack_base + param_count + i];
        Value arr = make_array(elems, vc);
        if (elems) {
            for (int i = 0; i < vc; ++i) free_value(&elems[i]);
            free(elems);
        }
        declare_var_in_scope(current_scope, cf.vararg_name.c_str(), false, arr);
    }

    // ---- 8. 截断参数槽 + push CompilerCallFrame ----
    stack.resize(stack_base);

    CompilerCallFrame frame;
    frame.return_pc  = pc;
    frame.stack_base = stack_base;
    frame.func_idx   = func_idx;
    frames.push_back(frame);

    frame_rule_keys.push_back(std::string());  // 保持与 frames 同步

    pc = cf.code_offset;
}

bool VM::vm_dispatch_method(Value& obj, const char* method,
    Value* args, int argc, bool is_optional,
    Value& out_result)
{
    // 清理 lambda：所有"立即返回"的出口都用它收尾
    auto cleanup = [&]() {
        for (int i = 0; i < argc; ++i) free_value(&args[i]);
    };

    // =========================================================
    // A. 可选链短路
    // =========================================================
    if (obj.type == VAL_NULL && is_optional) {
        cleanup();
        out_result = make_null();
        return true;
    }

    // =========================================================
    // B. 通用方法（不按类型区分）
    // =========================================================
    if (strcmp(method, "keine") == 0) {
        if (argc != 0) { cleanup(); kr_error("keine 不接受参数"); }
        bool is_null = (obj.type == VAL_NULL);
        cleanup();
        out_result = make_int64(is_null ? 1 : 0);
        return true;
    }
    if (strcmp(method, "zgr") == 0) {
        if (argc != 0) { cleanup(); kr_error("zgr 不接受参数"); }
        Value p = make_pointer_raw(obj);
        cleanup();
        out_result = p;
        return true;
    }
    if (strcmp(method, "schlau") == 0) {
        if (argc != 0) { cleanup(); kr_error("schlau 不接受参数"); }
        Value p = make_pointer_smart(obj);
        cleanup();
        out_result = p;
        return true;
    }
    if (strcmp(method, "typ") == 0) {
        if (argc != 0) { cleanup(); kr_error("typ 不接受参数"); }
        Value r = vm_method_type_of(obj);
        cleanup();
        out_result = r;
        return true;
    }
    if (strcmp(method, "gtyp") == 0) {
        if (argc != 0) { cleanup(); kr_error("gtyp 不接受参数"); }
        out_result = make_string(basic_value_type_to_string(obj).c_str());
        cleanup();
        return true;
    }
    if (strcmp(method, "leer") == 0) {
        if (argc != 0) { cleanup(); kr_error("leer 不接受参数"); }
        bool empty = false;
        switch (obj.type) {
            case VAL_NULL:   empty = true; break;
            case VAL_STRING: empty = (obj.str_len == 0); break;
            case VAL_ARRAY:  empty = (obj.arr_val.length == 0); break;
            case VAL_OBJECT: empty = (obj.obj_val.count == 0); break;
            default: break;
        }
        cleanup();
        out_result = make_int64(empty ? 1 : 0);
        return true;
    }
    if (strcmp(method, "leeren") == 0) {
        if (argc != 0) { cleanup(); kr_error("leeren 不接受参数"); }
        vm_method_leeren(&obj);   // 尽量原地改；非左值就走临时副本
        cleanup();
        out_result = make_null();
        return true;
    }

    // =========================================================
    // C. 按类型分发
    // =========================================================
    switch (obj.type) {

    // ---------------- 对象 ----------------
    case VAL_OBJECT: {

        // C.1 实例属性上的函数值（最高优先级，与解释器一致）
        for (int i = 0; i < obj.obj_val.count; ++i) {
            Value& v = obj.obj_val.entries[i].value;
            if (v.type != VAL_FUNCTION) continue;              // 快线
            if (strcmp(obj.obj_val.entries[i].key, method) != 0) continue;

            int func_idx = v.func_val.compiled_idx;
            if (func_idx < 0) {
                const char* fname = v.func_val.name;
                auto it = bc->func_by_name.find(fname ? fname : "");
                if (it != bc->func_by_name.end()) func_idx = it->second;
            }
            if (func_idx < 0) {
                cleanup();
                kr_error("未编译函数 '%s'",
                         v.func_val.name ? v.func_val.name : "<?>");
            }
            vm_enter_function_call(bc->functions[func_idx], func_idx, argc, &obj);
            cleanup();
            return false;   //  接管：结果由 OP_RETURN 负责入栈
        }

        // C.2 对象内置只读方法
        {
            Value r;
            if (vm_method_object_builtin(obj, method, args, argc, r)) {
                cleanup();
                out_result = r;
                return true;
            }
        }

        // C.3 类方法（沿 __klass → parent 链查找）
        {
            std::string cls_name;
            for (int i = 0; i < obj.obj_val.count; ++i) {
                const auto& e = obj.obj_val.entries[i];
                if (strcmp(e.key, "__klass") == 0 && e.value.type == VAL_STRING) {
                    cls_name = e.value.str_val;
                    break;
                }
            }
            if (!cls_name.empty()) {
                std::string cur = cls_name;
                int  midx = -1;
                bool is_static = false;
                while (!cur.empty()) {
                    auto it = bc->class_by_name.find(cur);
                    if (it == bc->class_by_name.end()) break;
                    const CompiledClass& c = bc->classes[it->second];
                    for (size_t k = 0; k < c.methods.size(); ++k) {
                        if (c.methods[k].first == method) {
                            midx      = c.methods[k].second;
                            is_static = c.method_is_static[k];
                            break;
                        }
                    }
                    if (midx >= 0) break;
                    cur = c.parent;
                }
                if (midx >= 0) {
                    const CompiledFunction& cf = bc->functions[midx];
                    const Value* dies_ptr = is_static ? nullptr : &obj;
                    vm_enter_function_call(cf, midx, argc, dies_ptr);
                    cleanup();
                    return false;   //  接管
                }
            }
        }

        // C.4 兜底：alt / alsText
        if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
            if (argc != 0) { cleanup(); kr_error("alt 不接受参数"); }
            char* s = value_to_string(obj);
            Value r = make_string(s);
            free(s);
            cleanup();
            out_result = r;
            return true;
        }

        cleanup();
        kr_error("对象不支持方法 '%s'", method);
    }

    // ---------------- 字符串 ----------------
    case VAL_STRING: {
        Value r = vm_method_string(obj, method, args, argc);
        cleanup();
        out_result = r;
        return true;
    }

    // ---------------- 数组 ----------------
    case VAL_ARRAY: {
        Value r = vm_method_array(obj, method, args, argc);
        cleanup();
        out_result = r;
        return true;
    }

    // ---------------- 数字 ----------------
    case VAL_INT:
    case VAL_INT64:
    case VAL_FLOAT: {
        Value r = vm_method_number(obj, method, args, argc);
        cleanup();
        out_result = r;
        return true;
    }

    // ---------------- 指针 ----------------
    case VAL_POINTER: {
        Value r = vm_method_pointer(obj, method, args, argc);
        cleanup();
        out_result = r;
        return true;
    }

    // ---------------- 函数值 ----------------
    case VAL_FUNCTION: {
        Value r = vm_method_function(obj, method, args, argc);
        cleanup();
        out_result = r;
        return true;
    }

    // ---------------- null ----------------
    case VAL_NULL: {
        if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
            if (argc != 0) kr_error("alt 不接受参数");
            cleanup();
            out_result = make_string("null");
            return true;
        }
        kr_warn("在 null 上调用 '%s'，返回 null", method);
        cleanup();
        out_result = make_null();
        return true;
    }

    default:
        cleanup();
        kr_error("不支持的方法调用类型 (type=%d)", (int)obj.type);
    }

    // 不可达
    out_result = make_null();
    return true;
}

// ============================================================================
// VM::vm_method_type_of
// ============================================================================
Value VM::vm_method_type_of(Value& obj) {
    // Enum variant detection: object with __tag
    if (obj.type == VAL_OBJECT) {
        for (int i = 0; i < obj.obj_val.count; ++i) {
            const auto& e = obj.obj_val.entries[i];
            if (strcmp(e.key, "__tag") == 0 && e.value.type == VAL_STRING) {
                ObjectEntry entries[2];
                entries[0].key = strdup("typ");
                entries[0].value = make_string("aufz");
                entries[1].key = strdup("aufz");
                entries[1].value = make_string(e.value.str_val);
                Value result = make_object(entries, 2);
                free(entries[0].key); free_value(&entries[0].value);
                free(entries[1].key); free_value(&entries[1].value);
                return result;
            }
        }
        // Class instance detection: object with __klass
        for (int i = 0; i < obj.obj_val.count; ++i) {
            const auto& e = obj.obj_val.entries[i];
            if (strcmp(e.key, "__klass") == 0 && e.value.type == VAL_STRING) {
                ObjectEntry entries[2];
                entries[0].key = strdup("typ");
                entries[0].value = make_string("objekt");
                entries[1].key = strdup("klass");
                entries[1].value = make_string(e.value.str_val);
                Value result = make_object(entries, 2);
                free(entries[0].key); free_value(&entries[0].value);
                free(entries[1].key); free_value(&entries[1].value);
                return result;
            }
        }
    }
    return make_string(value_type_to_string(obj).c_str());
}

// ============================================================================
// VM::vm_method_leeren
// ============================================================================
void VM::vm_method_leeren(Value* obj) {
    if (!obj) return;
    if (obj->type == VAL_ARRAY) {
        for (long long i = 0; i < obj->arr_val.length; ++i)
            free_value(&obj->arr_val.elements[i]);
        free(obj->arr_val.elements);
        obj->arr_val.elements = nullptr;
        obj->arr_val.length = 0;
    } else if (obj->type == VAL_OBJECT) {
        int w = 0;
        for (int i = 0; i < obj->obj_val.count; ++i) {
            const char* k = obj->obj_val.entries[i].key;
            bool internal = (k && k[0] == '_' && k[1] == '_');
            if (internal) {
                if (w != i) obj->obj_val.entries[w] = obj->obj_val.entries[i];
                ++w;
            } else {
                free(obj->obj_val.entries[i].key);
                free_value(&obj->obj_val.entries[i].value);
            }
        }
        obj->obj_val.count = w;
        if (w == 0) {
            free(obj->obj_val.entries);
            obj->obj_val.entries = nullptr;
        } else {
            obj->obj_val.entries = (ObjectEntry*)realloc(
                obj->obj_val.entries, w * sizeof(ObjectEntry));
        }
    } else if (obj->type == VAL_STRING) {
        free_value(obj);
        *obj = make_string("");
    } else {
        std::string ty = value_type_to_string(*obj);
        kr_error("leeren 不支持类型: %s", ty.c_str());
    }
}

// ============================================================================
// VM::vm_method_object_builtin
// ============================================================================
bool VM::vm_method_object_builtin(Value& obj, const char* method,
                                  Value* args, int argc, Value& out) {
    // =========================================================
    // 解释器里走独立 method_* 函数的 → 换 c_method_*
    // =========================================================
    if (strcmp(method, "anf") == 0 || strcmp(method, "hinzufügen") == 0) {
        out = c_method_hinzufuegen(obj, args, argc);
        return true;
    }
    if (strcmp(method, "lösch") == 0) {
        out = c_method_loeschen(obj, args, argc);
        return true;
    }
    if (strcmp(method, "vereinige") == 0) {
        out = c_method_vereinige_obj(obj, args, argc);
        return true;
    }
    if (strcmp(method, "kopiere") == 0 || strcmp(method, "copy") == 0) {
        out = c_method_kopiere(obj, args, argc);
        return true;
    }
    if (strcmp(method, "ala") == 0 || strcmp(method, "alsArray") == 0) {
        out = c_method_alsArray(obj, args, argc);
        return true;
    }

    // =========================================================
    // 解释器里内联的 → 保持内联
    // =========================================================
    if (strcmp(method, "län") == 0) {
        // ---- 1. 取 __klass ----
        const char* cls_name = nullptr;
        for (int i = 0; i < obj.obj_val.count; ++i) {
            if (strcmp(obj.obj_val.entries[i].key, "__klass") == 0 &&
                obj.obj_val.entries[i].value.type == VAL_STRING) {
                cls_name = obj.obj_val.entries[i].value.str_val;
                break;
            }
        }

        // ---- 2. 查类 → 查方法 "län" ----
        if (cls_name) {
            auto cit = bc->class_by_name.find(cls_name);
            if (cit != bc->class_by_name.end()) {
                const CompiledClass& c = bc->classes[cit->second];
                for (const auto& m : c.methods) {
                    if (m.first == "län") {
                        const int midx = m.second;
                        // 同步执行方法体（无参；若将来支持参数，
                        // 把 args/argc 原样传进来即可）
                        out = vm_call_method_sync(bc->functions[midx],
                                                  midx, obj,
                                                  nullptr, 0);
                        return true;
                    }
                }
            }
        }

        // ---- 3. 回退：序列化为字符串，返回字节长度 ----
        char* s = value_to_string(obj);
        long long byte_len = (long long)strlen(s);
        free(s);
        out = make_int64(byte_len);
        return true;
    }

    // ---- schl / keys ----
    if (strcmp(method, "schl") == 0 || strcmp(method, "keys") == 0) {
        if (argc != 0) kr_error("schl/keys benötigt keine Argumente");
        std::vector<Value> kvs;
        for (int i = 0; i < obj.obj_val.count; ++i) {
            const char* k = obj.obj_val.entries[i].key;
            if (k[0] == '_' && k[1] == '_') continue;
            kvs.push_back(make_string(k));
        }
        out = make_array(kvs.data(), (int)kvs.size());
        for (auto& v : kvs) free_value(&v);
        return true;
    }

    // ---- werts / values ----
    if (strcmp(method, "werts") == 0 || strcmp(method, "values") == 0) {
        if (argc != 0) kr_error("werts/values benötigt keine Argumente");
        std::vector<Value> vvs;
        for (int i = 0; i < obj.obj_val.count; ++i) {
            const char* k = obj.obj_val.entries[i].key;
            if (k[0] == '_' && k[1] == '_') continue;
            vvs.push_back(copy_value(obj.obj_val.entries[i].value));
        }
        out = make_array(vvs.data(), (int)vvs.size());
        for (auto& v : vvs) free_value(&v);
        return true;
    }

    // ---- eintr / entries ----
    if (strcmp(method, "eintr") == 0 || strcmp(method, "entries") == 0) {
        if (argc != 0) kr_error("eintr/entries benötigt keine Argumente");
        std::vector<Value> objs;
        for (int i = 0; i < obj.obj_val.count; ++i) {
            const char* k = obj.obj_val.entries[i].key;
            if (k[0] == '_' && k[1] == '_') continue;
            ObjectEntry entries[2];
            entries[0].key = strdup("key");
            entries[0].value = make_string(k);
            entries[1].key = strdup("wert");
            entries[1].value = copy_value(obj.obj_val.entries[i].value);
            Value eo = make_object(entries, 2);
            free(entries[0].key); free_value(&entries[0].value);
            free(entries[1].key); free_value(&entries[1].value);
            objs.push_back(eo);
        }
        out = make_array(objs.data(), (int)objs.size());
        for (auto& v : objs) free_value(&v);
        return true;
    }

    // ---- hat ----
    if (strcmp(method, "hat") == 0) {
        if (argc != 1) kr_error("hat benötigt genau 1 Argument (Schlüssel)");
        if (args[0].type != VAL_STRING) kr_error("Schlüssel muss ein String sein");
        bool found = false;
        for (int i = 0; i < obj.obj_val.count; ++i) {
            if (strcmp(obj.obj_val.entries[i].key, args[0].str_val) == 0) {
                found = true; break;
            }
        }
        out = make_int64(found ? 1 : 0);
        return true;
    }

    // ---- zufall / random ----
    if (strcmp(method, "zufall") == 0 || strcmp(method, "random") == 0) {
        if (argc > 1) kr_error("zufall/random benötigt höchstens 1 Argument");
        if (obj.obj_val.count == 0) { out = make_null(); return true; }

        std::vector<std::string> candidates;
        if (argc == 0) {
            for (int i = 0; i < obj.obj_val.count; ++i)
                candidates.emplace_back(obj.obj_val.entries[i].key);
        } else {
            const Value& a = args[0];
            if (a.type == VAL_STRING) {
                candidates.emplace_back(a.str_val, a.str_len);
            } else if (a.type == VAL_ARRAY) {
                for (long long i = 0; i < a.arr_val.length; ++i) {
                    const Value& e = a.arr_val.elements[i];
                    if (e.type == VAL_STRING) candidates.emplace_back(e.str_val, e.str_len);
                }
            } else {
                kr_error("zufall: Argument muss String oder Array sein");
            }
        }
        std::vector<std::string> valid;
        for (auto& k : candidates) {
            for (int i = 0; i < obj.obj_val.count; ++i) {
                if (k == obj.obj_val.entries[i].key) { valid.push_back(k); break; }
            }
        }
        if (valid.empty()) { out = make_null(); return true; }
        const std::string& chosen = valid[rand() % valid.size()];
        Value chosen_val = make_null();
        for (int i = 0; i < obj.obj_val.count; ++i) {
            if (chosen == obj.obj_val.entries[i].key) {
                chosen_val = copy_value(obj.obj_val.entries[i].value); break;
            }
        }
        ObjectEntry entries[2];
        entries[0].key = strdup("key");
        entries[0].value = make_string(chosen.c_str());
        entries[1].key = strdup("wert");
        entries[1].value = chosen_val;
        out = make_object(entries, 2);
        free(entries[0].key); free_value(&entries[0].value);
        free(entries[1].key); free_value(&entries[1].value);
        return true;
    }

    // ---- zufWert / randomValue ----
    if (strcmp(method, "zufWert") == 0 || strcmp(method, "randomValue") == 0) {
        if (argc > 1) kr_error("zufWert/randomValue benötigt höchstens 1 Argument");
        if (obj.obj_val.count == 0) { out = make_null(); return true; }

        std::vector<std::string> candidates;
        if (argc == 0) {
            for (int i = 0; i < obj.obj_val.count; ++i)
                candidates.emplace_back(obj.obj_val.entries[i].key);
        } else {
            const Value& a = args[0];
            if (a.type == VAL_STRING) {
                candidates.emplace_back(a.str_val, a.str_len);
            } else if (a.type == VAL_ARRAY) {
                for (long long i = 0; i < a.arr_val.length; ++i) {
                    const Value& e = a.arr_val.elements[i];
                    if (e.type == VAL_STRING) candidates.emplace_back(e.str_val, e.str_len);
                }
            } else {
                kr_error("zufWert: Argument muss String oder Array sein");
            }
        }
        std::vector<std::string> valid;
        for (auto& k : candidates) {
            for (int i = 0; i < obj.obj_val.count; ++i) {
                if (k == obj.obj_val.entries[i].key) { valid.push_back(k); break; }
            }
        }
        if (valid.empty()) { out = make_null(); return true; }
        const std::string& chosen = valid[rand() % valid.size()];
        for (int i = 0; i < obj.obj_val.count; ++i) {
            if (chosen == obj.obj_val.entries[i].key) {
                out = copy_value(obj.obj_val.entries[i].value); return true;
            }
        }
        out = make_null();
        return true;
    }

    // ---- umk / umkehren ----
    if (strcmp(method, "umk") == 0 || strcmp(method, "umkehren") == 0) {
        int n = obj.obj_val.count;
        ObjectEntry* entries = (ObjectEntry*)malloc((size_t)n * sizeof(ObjectEntry));
        for (int i = 0; i < n; ++i) {
            entries[i].key   = strdup(obj.obj_val.entries[n-1-i].key);
            entries[i].value = copy_value(obj.obj_val.entries[n-1-i].value);
        }
        out = make_object(entries, n);
        for (int i = 0; i < n; ++i) {
            free(entries[i].key);
            free_value(&entries[i].value);
        }
        free(entries);
        return true;
    }

    return false;   // 未处理
}

// ============================================================================
// VM::vm_method_string
// ============================================================================
Value VM::vm_method_string(Value& obj, const char* method,
                           Value* args, int argc) {
    if (strcmp(method, "alsText") == 0 || strcmp(method, "alt") == 0)
        return c_method_alsText(obj, args, argc);

    // 解释器里 län 是内联的
    if (strcmp(method, "län") == 0) {
        if (argc != 0) kr_error("län 不需要参数");
        return make_int64((int64_t)obj.str_len);
    }

    if (strcmp(method, "passende") == 0 || strcmp(method, "pass") == 0)
        return c_method_passende(obj, args, argc);
    if (strcmp(method, "ersetze") == 0 || strcmp(method, "ers") == 0)
        return c_method_ersetze(obj, args, argc);
    if (strcmp(method, "teil") == 0)
        return c_method_teile(obj, args, argc);
    if (strcmp(method, "entfal") == 0)
        return c_method_entfal(obj, args, argc);
    if (strcmp(method, "enthält") == 0 || strcmp(method, "hat") == 0)
        return c_method_enthaelt(obj, args, argc);
    if (strcmp(method, "fängtAnMit") == 0 || strcmp(method, "beg") == 0)
        return c_method_faengtAnMit(obj, args, argc);
    if (strcmp(method, "abschnitt") == 0 || strcmp(method, "ab") == 0)
        return c_method_abschnitt(obj, args, argc);
    if (strcmp(method, "stelleVon") == 0 || strcmp(method, "wo") == 0)
        return c_method_stelleVon(obj, args, argc);
    if (strcmp(method, "letzteStelleVon") == 0 || strcmp(method, "letzt") == 0)
        return c_method_letzteStelleVon(obj, args, argc);
    if (strcmp(method, "trim") == 0)
        return c_method_trim(obj, args, argc);
    if (strcmp(method, "alsZahl") == 0 || strcmp(method, "alz") == 0)
        return c_method_alsZahl(obj, args, argc);
    if (strcmp(method, "groß") == 0)
        return c_method_toUpper(obj, args, argc);
    if (strcmp(method, "klein") == 0)
        return c_method_toLower(obj, args, argc);
    if (strcmp(method, "umkehren") == 0 || strcmp(method, "umk") == 0)
        return c_method_reverse(obj, args, argc);
    if (strcmp(method, "zähle") == 0)
        return c_method_count(obj, args, argc);
    if (strcmp(method, "ohneAnfang") == 0)
        return c_method_remove_prefix(obj, args, argc);
    if (strcmp(method, "ohneEnde") == 0)
        return c_method_remove_suffix(obj, args, argc);
    if (strcmp(method, "füll") == 0)
        return c_method_pad(obj, args, argc);
    if (strcmp(method, "endetMit") == 0)
        return c_method_ends_with(obj, args, argc);
    if (strcmp(method, "wieder") == 0)
        return c_method_repeat(obj, args, argc);
    if (strcmp(method, "zeich") == 0)
        return c_method_char_at(obj, args, argc);
    if (strcmp(method, "istZiffer") == 0)
        return c_method_istZiffer(obj, args, argc);
    if (strcmp(method, "istBuchstabe") == 0)
        return c_method_istBuchstabe(obj, args, argc);
    if (strcmp(method, "istAlnum") == 0)
        return c_method_istAlnum(obj, args, argc);
    if (strcmp(method, "istRaum") == 0)
        return c_method_istRaum(obj, args, argc);
    if (strcmp(method, "istGroß") == 0)
        return c_method_istGroß(obj, args, argc);
    if (strcmp(method, "istKlein") == 0)
        return c_method_istKlein(obj, args, argc);
    if (strcmp(method, "istZahl") == 0)
        return c_method_istZahl(obj, args, argc);
    if (strcmp(method, "entferne") == 0)
        return c_method_entferne(obj, args, argc);
    if (strcmp(method, "anfang") == 0)
        return c_method_anfang(obj, args, argc);
    if (strcmp(method, "rechts") == 0)
        return c_method_rechts(obj, args, argc);
    if (strcmp(method, "ala") == 0 || strcmp(method, "alsArray") == 0)
        return c_method_alsArray(obj, args, argc);

    kr_error("未知字符串方法 '%s'", method);
}

// ============================================================================
// VM::vm_method_array
// ============================================================================
Value VM::vm_method_array(Value& obj, const char* method,
                          Value* args, int argc) {
    const long long N = obj.arr_val.length;

    // ---- län：解释器内联 ----
    if (strcmp(method, "län") == 0) return make_int64(N);

    // =========================================================
    // 解释器里走独立 method_* 函数的 → 换 c_method_*
    // =========================================================
    if (strcmp(method, "hinzufügen") == 0 || strcmp(method, "anf") == 0)
        return c_method_hinzufuegen(obj, args, argc);
    if (strcmp(method, "finde") == 0)
        return c_method_finde(obj, args, argc);
    if (strcmp(method, "findeIndex") == 0 || strcmp(method, "idx") == 0)
        return c_method_findeIndex(obj, args, argc);
    if (strcmp(method, "letzt") == 0 || strcmp(method, "letzteStelleVon") == 0)
        return c_method_array_last(obj, args, argc);
    if (strcmp(method, "ab") == 0 || strcmp(method, "abschnitt") == 0 ||
        strcmp(method, "teil") == 0)
        return c_method_slice(obj, args, argc);
    if (strcmp(method, "sort") == 0)
        return c_method_sort(obj, args, argc);
    if (strcmp(method, "unique") == 0)
        return c_method_unique(obj, args, argc);
    if (strcmp(method, "hat") == 0)
        return c_method_contains_array(obj, args, argc);
    if (strcmp(method, "alle") == 0)
        return c_method_all_indices(obj, args, argc);
    if (strcmp(method, "max") == 0)      return c_method_max(obj, args, argc);
    if (strcmp(method, "min") == 0)      return c_method_min(obj, args, argc);
    if (strcmp(method, "sum") == 0)      return c_method_sum(obj, args, argc);
    if (strcmp(method, "mittel") == 0)   return c_method_mittel(obj, args, argc);
    if (strcmp(method, "produkt") == 0)  return c_method_produkt(obj, args, argc);
    if (strcmp(method, "erstes") == 0)   return c_method_erstes(obj, args, argc);
    if (strcmp(method, "einfuegen") == 0)return c_method_einfuegen(obj, args, argc);
    if (strcmp(method, "vereinige") == 0)return c_method_vereinige_array(obj, args, argc);
    if (strcmp(method, "schnitt") == 0)  return c_method_schnitt(obj, args, argc);
    if (strcmp(method, "differenz") == 0)return c_method_differenz(obj, args, argc);
    if (strcmp(method, "entferne") == 0) return c_method_entferne_array(obj, args, argc);
    if (strcmp(method, "mische") == 0)   return c_method_mische(obj, args, argc);

    // =========================================================
    // 解释器里内联的 → 保持内联
    // =========================================================

    // ---- lösch ----
    if (strcmp(method, "lösch") == 0) {
        if (argc != 1) kr_error("lösch benötigt 1 Argument (Index)");
        long long idx = value_to_ll(args[0]);
        if (idx < 0 || idx >= N) kr_error("索引超出范围 (Länge %lld, Index %lld)", N, idx);
        return copy_value(obj.arr_val.elements[idx]);
    }

    // ---- map ----
    if (strcmp(method, "map") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("map benötigt 1 Funktion");
        Value* out = (Value*)malloc((size_t)N * sizeof(Value));
        for (long long i = 0; i < N; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            out[i] = vm_invoke(args[0], &a, 1);
            free_value(&a);
        }
        Value r = make_array(out, (int)N);
        for (long long i = 0; i < N; ++i) free_value(&out[i]);
        free(out);
        return r;
    }

    // ---- filter ----
    if (strcmp(method, "filter") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("filter benötigt 1 Funktion");
        std::vector<Value> keep;
        for (long long i = 0; i < N; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value p = vm_invoke(args[0], &a, 1);
            bool k = value_to_bool(p);
            free_value(&p); free_value(&a);
            if (k) keep.push_back(copy_value(obj.arr_val.elements[i]));
        }
        Value r = make_array(keep.data(), (int)keep.size());
        for (auto& v : keep) free_value(&v);
        return r;
    }

    // ---- reduz ----
    if (strcmp(method, "reduz") == 0) {
        if (argc != 2 || args[0].type != VAL_FUNCTION) kr_error("reduz benötigt (Funktion, Startwert)");
        Value acc = copy_value(args[1]);
        for (long long i = 0; i < N; ++i) {
            Value pair[2] = { copy_value(acc), copy_value(obj.arr_val.elements[i]) };
            Value nacc = vm_invoke(args[0], pair, 2);
            free_value(&acc); free_value(&pair[0]); free_value(&pair[1]);
            acc = nacc;
        }
        return acc;
    }

    // ---- jeden ----
    if (strcmp(method, "jeden") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("jeden benötigt 1 Funktion");
        for (long long i = 0; i < N; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value r = vm_invoke(args[0], &a, 1);
            free_value(&r); free_value(&a);
        }
        return make_null();
    }

    // ---- manche ----
    if (strcmp(method, "manche") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("manche benötigt 1 Funktion");
        bool found = false;
        for (long long i = 0; i < N && !found; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value r = vm_invoke(args[0], &a, 1);
            found = value_to_bool(r);
            free_value(&r); free_value(&a);
        }
        return make_int64(found ? 1 : 0);
    }

    // ---- keiner ----
    if (strcmp(method, "keiner") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("keiner benötigt 1 Funktion");
        bool found = false;
        for (long long i = 0; i < N && !found; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value r = vm_invoke(args[0], &a, 1);
            found = value_to_bool(r);
            free_value(&r); free_value(&a);
        }
        return make_int64(found ? 0 : 1);
    }

    // ---- zähl ----
    if (strcmp(method, "zähl") == 0) {
        if (argc == 0) return make_int64(N);
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("zähl benötigt 0 oder 1 Funktion");
        int64_t cnt = 0;
        for (long long i = 0; i < N; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value r = vm_invoke(args[0], &a, 1);
            if (value_to_bool(r)) ++cnt;
            free_value(&r); free_value(&a);
        }
        return make_int64(cnt);
    }

    // ---- grupp ----
    if (strcmp(method, "grupp") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("grupp benötigt 1 Funktion");
        std::vector<ObjectEntry> entries;
        for (long long i = 0; i < N; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value k = vm_invoke(args[0], &a, 1);
            char* ks = value_to_string(k);
            int found = -1;
            for (size_t j = 0; j < entries.size(); ++j)
                if (strcmp(entries[j].key, ks) == 0) { found = (int)j; break; }
            if (found >= 0) {
                Value& arr = entries[found].value;
                arr.arr_val.elements = (Value*)realloc(arr.arr_val.elements,
                    (arr.arr_val.length + 1) * sizeof(Value));
                arr.arr_val.elements[arr.arr_val.length++] = copy_value(a);
            } else {
                ObjectEntry e;
                e.key = strdup(ks);
                Value one = copy_value(a);
                e.value = make_array(&one, 1);
                free_value(&one);
                entries.push_back(e);
            }
            free(ks); free_value(&k); free_value(&a);
        }
        Value r = make_object(entries.data(), (int)entries.size());
        for (auto& e : entries) { free(e.key); free_value(&e.value); }
        return r;
    }

    // ---- partit ----
    if (strcmp(method, "partit") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("partit benötigt 1 Funktion");
        std::vector<Value> ja, nein;
        for (long long i = 0; i < N; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value r = vm_invoke(args[0], &a, 1);
            if (value_to_bool(r)) ja.push_back(a);
            else nein.push_back(a);
            free_value(&r);
        }
        Value pair[2] = { make_array(ja.data(), (int)ja.size()),
                          make_array(nein.data(), (int)nein.size()) };
        for (auto& v : ja) free_value(&v);
        for (auto& v : nein) free_value(&v);
        Value r = make_array(pair, 2);
        free_value(&pair[0]); free_value(&pair[1]);
        return r;
    }

    // ---- erste ----
    if (strcmp(method, "erste") == 0) {
        if (argc != 1 || args[0].type != VAL_FUNCTION) kr_error("erste benötigt 1 Funktion");
        for (long long i = 0; i < N; ++i) {
            Value a = copy_value(obj.arr_val.elements[i]);
            Value r = vm_invoke(args[0], &a, 1);
            bool ok = value_to_bool(r);
            free_value(&r);
            if (ok) return a;
            free_value(&a);
        }
        return make_null();
    }

    // ---- flach ----
    if (strcmp(method, "flach") == 0) {
        if (argc > 1) kr_error("flach benötigt 0 oder 1 Argument (Tiefe)");
        int depth = (argc == 1) ? (int)value_to_ll(args[0]) : 1;
        std::vector<Value> out;
        std::function<void(const Value&, int)> rec = [&](const Value& v, int d) {
            if (v.type == VAL_ARRAY && d > 0) {
                for (long long i = 0; i < v.arr_val.length; ++i)
                    rec(v.arr_val.elements[i], d - 1);
            } else {
                out.push_back(copy_value(v));
            }
        };
        rec(obj, depth);
        Value r = make_array(out.data(), (int)out.size());
        for (auto& v : out) free_value(&v);
        return r;
    }

    // ---- nehmen ----
    if (strcmp(method, "nehmen") == 0) {
        if (argc != 1) kr_error("nehmen benötigt 1 Argument");
        long long k = value_to_ll(args[0]);
        if (k < 0) k = 0;
        if (k > N) k = N;
        Value* elems = (Value*)malloc((size_t)k * sizeof(Value));
        for (long long i = 0; i < k; ++i) elems[i] = copy_value(obj.arr_val.elements[i]);
        Value r = make_array(elems, (int)k);
        for (long long i = 0; i < k; ++i) free_value(&elems[i]);
        free(elems);
        return r;
    }

    // ---- fallen ----
    if (strcmp(method, "fallen") == 0) {
        if (argc != 1) kr_error("fallen benötigt 1 Argument");
        long long k = value_to_ll(args[0]);
        if (k < 0) k = 0;
        if (k > N) k = N;
        long long cnt = N - k;
        Value* elems = (Value*)malloc((size_t)cnt * sizeof(Value));
        for (long long i = 0; i < cnt; ++i) elems[i] = copy_value(obj.arr_val.elements[k + i]);
        Value r = make_array(elems, (int)cnt);
        for (long long i = 0; i < cnt; ++i) free_value(&elems[i]);
        free(elems);
        return r;
    }

    // ---- zip ----
    if (strcmp(method, "zip") == 0) {
        if (argc != 1 || args[0].type != VAL_ARRAY) kr_error("zip benötigt 1 Array");
        const Value& other = args[0];
        long long n = std::min(N, other.arr_val.length);
        Value* pairs = (Value*)malloc((size_t)n * sizeof(Value));
        for (long long i = 0; i < n; ++i) {
            Value two[2] = { copy_value(obj.arr_val.elements[i]),
                             copy_value(other.arr_val.elements[i]) };
            pairs[i] = make_array(two, 2);
            free_value(&two[0]); free_value(&two[1]);
        }
        Value r = make_array(pairs, (int)n);
        for (long long i = 0; i < n; ++i) free_value(&pairs[i]);
        free(pairs);
        return r;
    }

    // ---- beit ----
    if (strcmp(method, "beit") == 0) {
        if (argc != 1 || args[0].type != VAL_STRING) kr_error("beit benötigt 1 String");
        std::string sep(args[0].str_val, args[0].str_len);
        std::string out;
        for (long long i = 0; i < N; ++i) {
            if (i > 0) out += sep;
            const Value& e = obj.arr_val.elements[i];
            if (e.type == VAL_STRING) out.append(e.str_val, e.str_len);
            else {
                char* s = value_to_string(e);
                out += s;
                free(s);
            }
        }
        return make_string_len(out.data(), out.size());
    }

    // ---- zufall / random ----
    if (strcmp(method, "zufall") == 0 || strcmp(method, "random") == 0) {
        if (argc > 1) kr_error("zufall benötigt höchstens 1 Argument");
        if (N == 0) return make_null();
        std::vector<long long> cand;
        if (argc == 0) {
            for (long long i = 0; i < N; ++i) cand.push_back(i);
        } else if (args[0].type == VAL_INT || args[0].type == VAL_INT64) {
            long long idx = value_to_ll(args[0]);
            if (idx >= 0 && idx < N) cand.push_back(idx);
        } else if (args[0].type == VAL_ARRAY) {
            for (long long i = 0; i < args[0].arr_val.length; ++i) {
                const Value& e = args[0].arr_val.elements[i];
                if (e.type == VAL_INT || e.type == VAL_INT64) {
                    long long idx = value_to_ll(e);
                    if (idx >= 0 && idx < N) cand.push_back(idx);
                }
            }
        } else kr_error("zufall: Argument muss Integer oder Integer-Array sein");
        if (cand.empty()) return make_null();
        long long chosen = cand[rand() % cand.size()];
        Value val = copy_value(obj.arr_val.elements[chosen]);
        ObjectEntry e[2];
        e[0].key = strdup("index"); e[0].value = make_int64(chosen);
        e[1].key = strdup("wert");  e[1].value = val;
        Value r = make_object(e, 2);
        free(e[0].key); free_value(&e[0].value);
        free(e[1].key); free_value(&e[1].value);
        return r;
    }

    // ---- zufWert ----
    if (strcmp(method, "zufWert") == 0 || strcmp(method, "randomValue") == 0) {
        if (argc > 1) kr_error("zufWert benötigt höchstens 1 Argument");
        if (N == 0) return make_null();
        std::vector<long long> cand;
        if (argc == 0) {
            for (long long i = 0; i < N; ++i) cand.push_back(i);
        } else if (args[0].type == VAL_INT || args[0].type == VAL_INT64) {
            long long idx = value_to_ll(args[0]);
            if (idx >= 0 && idx < N) cand.push_back(idx);
        } else if (args[0].type == VAL_ARRAY) {
            for (long long i = 0; i < args[0].arr_val.length; ++i) {
                const Value& e = args[0].arr_val.elements[i];
                if (e.type == VAL_INT || e.type == VAL_INT64) {
                    long long idx = value_to_ll(e);
                    if (idx >= 0 && idx < N) cand.push_back(idx);
                }
            }
        } else kr_error("zufWert: Argument muss Integer oder Integer-Array sein");
        if (cand.empty()) return make_null();
        long long chosen = cand[rand() % cand.size()];
        return copy_value(obj.arr_val.elements[chosen]);
    }

    // ---- umk / umkehren（数组上是内联的）----
    if (strcmp(method, "umk") == 0 || strcmp(method, "umkehren") == 0) {
        Value* elems = (Value*)malloc((size_t)N * sizeof(Value));
        for (long long i = 0; i < N; ++i)
            elems[i] = copy_value(obj.arr_val.elements[N - 1 - i]);
        Value r = make_array(elems, (int)N);
        for (long long i = 0; i < N; ++i) free_value(&elems[i]);
        free(elems);
        return r;
    }

    // ---- kopiere（数组是内联的浅拷贝）----
    if (strcmp(method, "kopiere") == 0) {
        return copy_value(obj);
    }

    // ---- alt / alsText ----
    if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0)
        return c_method_alsText(obj, args, argc);

    kr_error("未知数组方法 '%s'", method);
}

// ============================================================================
// VM::vm_method_number
// ============================================================================
Value VM::vm_method_number(Value& obj, const char* method,
                           Value* args, int argc) {
    if (strcmp(method, "alsText") == 0 || strcmp(method, "alt") == 0)
        return c_method_alsText(obj, args, argc);
    if (strcmp(method, "alsZahl") == 0 || strcmp(method, "alz") == 0)
        return c_method_alsZahl(obj, args, argc);

    // ---- runden：解释器里内联 ----
    if (strcmp(method, "runden") == 0) {
        if (argc != 1) kr_error("runden benötigt 1 Argument (Stellen)");
        int digits = (int)value_to_ll(args[0]);
        if (digits < 0) kr_error("小数位数不能为负数");
        double val = value_to_double(obj);
        double factor = pow(10.0, digits);
        double rounded = round(val * factor) / factor;
        return make_float(rounded);
    }

    kr_error("数字不支持方法 '%s'", method);
}

// ============================================================================
// VM::vm_method_pointer
// ============================================================================
Value VM::vm_method_pointer(Value& obj, const char* method,
                            Value* args, int argc) {
    if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0)
        return c_method_alsText(obj, args, argc);

    if (strcmp(method, "zgrw") == 0) {
        if (argc != 0) kr_error("zgrw 不需要参数");
        Value* target = obj.ptr_val.smart_target
                        ? obj.ptr_val.smart_target->get()
                        : obj.ptr_val.raw_target;
        if (!target) kr_error("空指针解引用");
        if (obj.ptr_val.freed) kr_error("访问已释放的指针");
        return copy_value(*target);
    }
    if (strcmp(method, "setz") == 0 || strcmp(method, "zgrs") == 0) {
        if (argc != 1) kr_error("setz/zgrs 需要 1 个参数");
        Value* target = obj.ptr_val.smart_target
                        ? obj.ptr_val.smart_target->get()
                        : obj.ptr_val.raw_target;
        if (!target) kr_error("空指针写入");
        if (obj.ptr_val.freed) kr_error("访问已释放的指针");
        free_value(target);
        *target = copy_value(args[0]);
        return make_null();
    }
    if (strcmp(method, "frei") == 0) {
        if (argc != 0) kr_error("frei 不需要参数");
        if (obj.ptr_val.smart_target) {
            kr_warn("frei 对智能指针无效果；引用计数自动管理生命周期");
            return make_null();
        }
        if (obj.ptr_val.raw_target) {
            if (obj.ptr_val.freed) kr_error("指针已经被释放，不能重复释放");
            free_value(obj.ptr_val.raw_target);
            delete obj.ptr_val.raw_target;
        }
        return make_null();
    }
    if (strcmp(method, "zgrNull") == 0) {
        if (argc != 0) kr_error("zgrNull 不需要参数");
        bool is_null = (obj.ptr_val.smart_target == nullptr) &&
                       (obj.ptr_val.raw_target  == nullptr);
        return make_int64(is_null ? 1 : 0);
    }
    kr_error("未知指针方法 '%s'", method);
}

// ============================================================================
// VM::vm_method_function
// ============================================================================
Value VM::vm_method_function(Value& obj, const char* method,
                             Value* args, int argc) {
    if (strcmp(method, "aufruf") == 0 || strcmp(method, "call") == 0) {
        Value fn = copy_value(obj);
        Value r = vm_invoke(fn, args, argc);
        free_value(&fn);
        return r;
    }
    if (strcmp(method, "name") == 0) {
        if (argc != 0) kr_error("name 不需要参数");
        return make_string(obj.func_val.name ? obj.func_val.name : "anonym");
    }
    if (strcmp(method, "alt") == 0 || strcmp(method, "alsText") == 0) {
        if (argc != 0) kr_error("alt 不需要参数");
        char* s = value_to_string(obj);
        Value r = make_string(s);
        free(s);
        return r;
    }
    kr_error("函数不支持方法 '%s'", method);
}