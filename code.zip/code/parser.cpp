#include "ast.cpp"

// 解析函数参数列表，返回参数名数组、常量标志数组、默认值数组
// 参数：tok_pos 当前已解析到 '(' 之后，返回时指向 ')' 之后
static void parse_param_list(char*** out_names, int* out_count, bool** out_is_const,
    ASTNode*** out_defaults, TypeNode*** out_param_types,
    char** out_vararg_name, TypeNode** out_vararg_type) {
    *out_names = NULL;
    *out_count = 0;
    *out_is_const = NULL;
    *out_defaults = NULL;
    *out_vararg_name = NULL;
    *out_param_types = NULL;
    *out_vararg_type = NULL;

    if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
        consume();
        return;
    }

    while (true) {
        bool is_const = false;

        // ---- 1. 修饰符：das（常量）或 der（普通可变） ----
        if (strcmp(peek()->value, "das") == 0 && peek()->type == TOK_KEYWORD) {
            consume();
            is_const = true;
        }
        if (strcmp(peek()->value, "der") == 0 && peek()->type == TOK_KEYWORD) {
            consume();
            // 不修改 is_const，即普通可变参数
        }

        // ---- 2. 可变参数（必须放在类型前缀之前） ----
        if (strcmp(peek()->value, "...") == 0 || strcmp(peek()->value, "&") == 0) {
            consume();
            if (strcmp(peek()->value, "...") == 0) consume(); // 兼容写法
            Token* vararg_tok = consume();
            if (vararg_tok->type != TOK_IDENT)
                error_at(vararg_tok->line, vararg_tok->col, "期望可变参数名");
            *out_vararg_name = strdup(vararg_tok->value);
            TypeNode* vararg_type = nullptr;
            if (strcmp(peek()->value, ":") == 0) {
                consume();
                vararg_type = parse_type_expr();
            }
            *out_vararg_type = vararg_type;
            if (strcmp(peek()->value, ")") != 0)
                error_at(peek()->line, peek()->col, "可变参数必须是最后一个参数");
            consume(); // 消费 ')'
            break;
        }

        // ---- 3. 尝试解析前缀类型（仅当当前 token 不是标识符或关键字） ----
        TypeNode* prefix_type = nullptr;
        bool has_prefix_type = false;
        int saved_pos = tok_pos;
        // 仅当当前 token 是类型的可能开头（如标识符、'['、'{'等）时尝试
        // 这里简单通过 parse_type_expr() 尝试，失败则回退
        try {
            TypeNode* t = parse_type_expr();
            if (t && tok_pos < token_count &&
                tokens[tok_pos].type == TOK_IDENT &&
                strcmp(tokens[tok_pos].value, "das") != 0 &&
                strcmp(tokens[tok_pos].value, "der") != 0 &&
                strcmp(tokens[tok_pos].value, "...") != 0 &&
                strcmp(tokens[tok_pos].value, "&") != 0) {
                prefix_type = t;
                has_prefix_type = true;
            } else {
                tok_pos = saved_pos;
                free_type_node(t);
            }
        } catch (...) {
            tok_pos = saved_pos;
        }

        // ---- 4. 读取参数名 ----
        Token* p = consume();
        if (p->type != TOK_IDENT)
            error_at(p->line, p->col, "期望参数名");
        char* name = strdup(p->value);

        // ---- 5. 类型注解 ----
        TypeNode* param_type = nullptr;
        if (has_prefix_type) {
            param_type = prefix_type;
            // 如果后面还有 ': type'，则警告并忽略
            if (strcmp(peek()->value, ":") == 0) {
                kr_warn("参数 '%s' 已有类型前缀，忽略后面的 ': 类型'", name);
                consume();
                TypeNode* extra = parse_type_expr();
                free_type_node(extra);
            }
        } else {
            if (strcmp(peek()->value, ":") == 0) {
                consume();
                param_type = parse_type_expr();
            }
        }

        // ---- 6. 默认值 ----
        ASTNode* default_expr = NULL;
        if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
            consume();
            default_expr = parse_expression();
        }

        // ---- 7. 存储参数信息 ----
        *out_names = (char**)realloc(*out_names, (*out_count + 1) * sizeof(char*));
        (*out_names)[*out_count] = name;

        *out_is_const = (bool*)realloc(*out_is_const, (*out_count + 1) * sizeof(bool));
        (*out_is_const)[*out_count] = is_const;

        *out_defaults = (ASTNode**)realloc(*out_defaults, (*out_count + 1) * sizeof(ASTNode*));
        (*out_defaults)[*out_count] = default_expr;

        *out_param_types = (TypeNode**)realloc(*out_param_types, (*out_count + 1) * sizeof(TypeNode*));
        (*out_param_types)[*out_count] = param_type;

        (*out_count)++;

        // ---- 8. 逗号或结束 ----
        if (strcmp(peek()->value, ",") == 0) {
            consume();
            continue;
        } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
            consume();
            break;
        } else {
            error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
        }
    }
}

ASTNode* parse_match_expression(int als_col, int als_line) {
    // als 的缩进级别（列数从 1 开始）
    int als_indent = als_col - 1;

    // 解析 als 后面的值表达式（如 "v"）
    ASTNode* expr = parse_expression();

    // 创建匹配节点
    ASTNode* match_node = new_node(NODE_MATCH);
    match_node->data.match.expr = expr;
    match_node->data.match.branches = NULL;
    match_node->data.match.branch_count = 0;

    // ---- 花括号模式 ----
    if (strcmp(peek()->value, "{") == 0) {
        expect("{");
        while (strcmp(peek()->value, "}") != 0) {
            // 解析模式（支持 | 分隔的多个模式）
            ASTNode* pattern = parse_pattern_list();
            ASTNode* guard = NULL;
            // 可选的守卫
            if (strcmp(peek()->value, "fa") == 0) {
                consume();
                guard = parse_expression();
            }
            expect("=>");
            ASTNode* body;
            // 分支体可以是块或表达式
            if (strcmp(peek()->value, "{") == 0) {
                expect("{");
                body = parse_block();
                expect("}");
            } else {
                ASTNode* expr_body = parse_expression();
                body = new_node(NODE_BLOCK);
                body->data.block.count = 1;
                body->data.block.stmts = (ASTNode**)malloc(sizeof(ASTNode*));
                ASTNode* stmt = new_node(NODE_EXPR_STMT);
                stmt->data.expr_stmt.expr = expr_body;
                body->data.block.stmts[0] = stmt;
                if (strcmp(peek()->value, ";") == 0) consume();
            }
            // 添加分支
            match_node->data.match.branches = (MatchBranch*)realloc(
                match_node->data.match.branches,
                (match_node->data.match.branch_count + 1) * sizeof(MatchBranch)
            );
            match_node->data.match.branches[match_node->data.match.branch_count].pattern = pattern;
            match_node->data.match.branches[match_node->data.match.branch_count].guard   = guard;
            match_node->data.match.branches[match_node->data.match.branch_count].body    = body;
            match_node->data.match.branch_count++;
        }
        expect("}");
    }
    // ---- 缩进模式 ----
    else {
        while (peek()->type != TOK_EOF) {
            // 检查缩进是否回退到 als 级别或行号回退（防止跨行干扰）
            if (peek()->col - 1 <= als_indent || peek()->line <= als_line) {
                break;
            }
            // 记录当前分支的缩进（用于内部的 parse_body_block 识别子块）
            int branch_indent = peek()->col - 1;

            // 解析模式
            ASTNode* pattern = parse_pattern_list();
            ASTNode* guard = NULL;
            if (strcmp(peek()->value, "fa") == 0) {
                consume();
                guard = parse_expression();
            }
            expect("=>");

            // 分支体：使用 parse_body_block 以识别缩进的子块
            ASTNode* body = parse_body_block(branch_indent);

            // 添加分支
            match_node->data.match.branches = (MatchBranch*)realloc(
                match_node->data.match.branches,
                (match_node->data.match.branch_count + 1) * sizeof(MatchBranch)
            );
            match_node->data.match.branches[match_node->data.match.branch_count].pattern = pattern;
            match_node->data.match.branches[match_node->data.match.branch_count].guard   = guard;
            match_node->data.match.branches[match_node->data.match.branch_count].body    = body;
            match_node->data.match.branch_count++;
        }
    }

    return match_node;
}

ASTNode* parse_backtick_interp(const char* raw) {
    ASTNode* interp = new_node(NODE_STRING_INTERP);
    interp->data.string_interp.fragments = NULL;
    interp->data.string_interp.count = 0;

    const char* p = raw;
    while (*p) {
        // 查找下一个 &{
        const char* interp_start = strstr(p, "&{");
        // 分支 A：没有更多插值，剩余作为纯文本
        if (!interp_start) {
            char* text = strdup(p);
            size_t unesc_len = 0;
            char* unescaped = unescape_string(text, &unesc_len);
            free(text);
            ASTNode* text_node = new_node(NODE_STRING);
            text_node->string_len = unesc_len;
            text_node->data.string = unescaped;
            interp->data.string_interp.fragments = (ASTNode**)realloc(
                interp->data.string_interp.fragments,
                (interp->data.string_interp.count + 1) * sizeof(ASTNode*)
            );
            interp->data.string_interp.fragments[interp->data.string_interp.count++] = text_node;
            break;
        }

        // 分支 B：文本部分（从 p 到 interp_start）
        if (interp_start > p) {
            char* text = (char*)malloc(interp_start - p + 1);
            memcpy(text, p, interp_start - p);
            text[interp_start - p] = '\0';
            size_t unesc_len = 0;
            char* unescaped = unescape_string(text, &unesc_len);
            free(text);
            ASTNode* text_node = new_node(NODE_STRING);
            text_node->string_len = unesc_len;
            text_node->data.string = unescaped;
            interp->data.string_interp.fragments = (ASTNode**)realloc(
                interp->data.string_interp.fragments,
                (interp->data.string_interp.count + 1) * sizeof(ASTNode*)
            );
            interp->data.string_interp.fragments[interp->data.string_interp.count++] = text_node;
        }

        // 跳过 '&{'
        const char* expr_start = interp_start + 2;

        // 寻找匹配的 '}'，支持嵌套和转义
        int depth = 1;
        const char* expr_end = expr_start;
        while (*expr_end && depth > 0) {
            if (*expr_end == '\\' && *(expr_end+1)) {
                expr_end += 2;
                continue;
            }
            if (*expr_end == '{') depth++;
            else if (*expr_end == '}') depth--;
            expr_end++;
        }
        if (depth != 0) {
            kr_error("未终止的插值表达式，缺少 '}'");
        }

        // 提取表达式源码（不含花括号）
        int expr_len = expr_end - expr_start - 1; // 因为 expr_end 指向 '}' 后的下一个字符
        char* expr_src = (char*)malloc(expr_len + 1);
        memcpy(expr_src, expr_start, expr_len);
        expr_src[expr_len] = '\0';

        // 解析表达式（复用双引号插值表达式解析器）
        std::string processed_expr = process_interp_expr(expr_src);
        free(expr_src);
        ASTNode* expr_node = parse_interp_expression(processed_expr.c_str());

        interp->data.string_interp.fragments = (ASTNode**)realloc(
            interp->data.string_interp.fragments,
            (interp->data.string_interp.count + 1) * sizeof(ASTNode*)
        );
        interp->data.string_interp.fragments[interp->data.string_interp.count++] = expr_node;

        // 继续处理剩余部分
        p = expr_end;  // 现在指向 '}' 之后的字符
    }

    return interp;
}

// 尝试解析 "标识符 in 表达式列表" 模式，返回 OR 节点，失败返回 nullptr
static ASTNode* parse_ident_in_list() {
    int save_pos = tok_pos;
    Token* ident_tok = peek();
    if (ident_tok->type != TOK_IDENT) {
        tok_pos = save_pos;
        return nullptr;
    }
    consume(); // 消费标识符
    if (peek()->type != TOK_KEYWORD || strcmp(peek()->value, "in") != 0) {
        tok_pos = save_pos;
        return nullptr;
    }
    consume(); // 消费 'in'
    std::vector<ASTNode*> values;
    bool parse_ok = true;
    while (true) {
        ASTNode* val = parse_expression();
        if (!val) { parse_ok = false; break; }
        values.push_back(val);
        if (strcmp(peek()->value, ",") == 0) {
            consume();
            continue;
        } else {
            break; // 列表结束
        }
    }
    if (!parse_ok || values.empty()) {
        tok_pos = save_pos;
        for (auto v : values) free_ast(v);
        return nullptr;
    }
    // 构建 OR 树
    ASTNode* ident_node = new_node(NODE_VARIABLE, ident_tok->line, ident_tok->col);
    ident_node->data.var_name = strdup(ident_tok->value);
    ASTNode* cond = nullptr;
    for (ASTNode* val : values) {
        ASTNode* eq = new_node(NODE_BINARY);
        eq->data.binary.left = copy_ast(ident_node);
        eq->data.binary.right = val;
        eq->data.binary.op = 'E'; // ==
        if (!cond) cond = eq;
        else {
            ASTNode* or_node = new_node(NODE_LOGICAL_OR);
            or_node->data.logical_or.left = cond;
            or_node->data.logical_or.right = eq;
            cond = or_node;
        }
    }
    free_ast(ident_node);
    return cond;
}

ASTNode* parse_complex_type(char* type_name, bool is_brace) {
    // 收集公共字段（直到遇到 '=>' 或块结束）
    std::vector<StructField> common_fields;
    bool has_arrow = false;

    // 辅助 lambda：解析一个字段（支持类型前缀或 IDENT : type）
    auto parse_field = [&]() -> StructField {
        // ---- 尝试类型前缀： type_expr IDENT ----
        int saved_pos = tok_pos;
        try {
            TypeNode* maybe_type = parse_type_expr();
            Token* next = peek();
            if (next->type == TOK_IDENT &&
                strcmp(next->value, "ist") != 0 &&
                strcmp(next->value, "=") != 0 &&
                strcmp(next->value, ",") != 0 &&
                strcmp(next->value, "}") != 0 &&
                strcmp(next->value, "=>") != 0) {
                consume();  // 消费标识符作为字段名
                StructField f;
                f.name = strdup(next->value);
                f.type = maybe_type;
                return f;
            } else {
                tok_pos = saved_pos;
                free_type_node(maybe_type);
            }
        } catch (...) {
            tok_pos = saved_pos;
        }

        // ---- 回退格式： IDENT : type_expr ----
        Token* fname_tok = consume();
        if (fname_tok->type != TOK_IDENT)
            error_at(fname_tok->line, fname_tok->col, "期望字段名");
        expect(":");
        TypeNode* ftype = parse_type_expr();
        StructField f;
        f.name = strdup(fname_tok->value);
        f.type = ftype;
        return f;
    };

    // 记录第一个公共字段的缩进（用于花括号内的换行分隔）
    int field_indent = 0;
    if (is_brace && strcmp(peek()->value, "}") != 0) {
        field_indent = peek()->col - 1;
    }

    // ---------- 1. 解析公共字段 ----------
    while (true) {
        // 结束条件：花括号模式遇到 '}'，或缩进模式缩进回退
        if (is_brace && strcmp(peek()->value, "}") == 0) {
            consume();
            break;
        }
        if (!is_brace) {
            int base_indent = g_stmt_start_col - 1;
            int cur_indent = peek()->col - 1;
            if (cur_indent <= base_indent) break;
        }

        // 检测是否为 '=>'（进入变体列表）
        if (strcmp(peek()->value, "=>") == 0) {
            consume();
            has_arrow = true;
            break;
        }

        // 解析一个公共字段
        StructField f = parse_field();
        common_fields.push_back(f);

        // ---- 分隔符处理（支持换行） ----
        if (is_brace) {
            if (strcmp(peek()->value, ",") == 0) {
                consume();   // 逗号分隔
            } else if (strcmp(peek()->value, ";") == 0) {
                consume();   // 分号分隔
            } else if (strcmp(peek()->value, "}") == 0) {
                // 由循环开头处理，此处忽略
            } else if (peek()->col - 1 >= field_indent) {
            } else {
                error_at(peek()->line, peek()->col, "期望 ',' 或 '}'");
            }
        } else {
            // 缩进模式：逗号可选，换行由缩进控制
            if (strcmp(peek()->value, ",") == 0)
                consume();
            else if (strcmp(peek()->value, ";") == 0)
                consume();   // 分号支持（可选）
        }
    }

    // ---------- 2. 如果遇到 '=>'，解析变体列表（联合） ----------
    if (has_arrow) {
        std::vector<UnionVariant> variants;
        bool variant_brace = false;
        int variant_indent = 0;

        if (strcmp(peek()->value, "{") == 0) {
            consume();
            variant_brace = true;
            if (strcmp(peek()->value, "}") != 0) {
                variant_indent = peek()->col - 1;   // 第一个变体的缩进
            }
        }

        int base_indent = g_stmt_start_col - 1;

        while (true) {
            // 结束条件
            if (variant_brace) {
                if (strcmp(peek()->value, "}") == 0) {
                    consume();
                    break;
                }
            } else {
                int cur_indent = peek()->col - 1;
                if (cur_indent <= base_indent) break;
            }

            // 解析变体名称
            Token* vname_tok = consume();
            if (vname_tok->type != TOK_IDENT)
                error_at(vname_tok->line, vname_tok->col, "期望变体名称");

            UnionVariant var;
            var.name = strdup(vname_tok->value);
            var.param_count = 0;
            var.param_types = NULL;
            var.field_count = 0;
            var.named_fields = NULL;

            // 匿名参数列表 (type1, type2, ...)
            if (strcmp(peek()->value, "(") == 0) {
                consume();
                if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                    while (true) {
                        TypeNode* ptype = parse_type_expr();
                        var.param_types = (TypeNode**)realloc(var.param_types,
                                        (var.param_count + 1) * sizeof(TypeNode*));
                        var.param_types[var.param_count++] = ptype;
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();
                        } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                            break;
                        } else {
                            error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                        }
                    }
                }
                expect(")");
            }
            // 具名参数字段 { field: type, ... }
            else if (strcmp(peek()->value, "{") == 0) {
                consume();
                if (strcmp(peek()->value, "}") != 0) {
                    // 记录第一个字段的缩进（列号从1开始，缩进 = col-1）
                    int field_indent = peek()->col - 1;
                    while (true) {
                        StructField f = parse_field();
                        var.named_fields = (StructField*)realloc(var.named_fields,
                                        (var.field_count + 1) * sizeof(StructField));
                        var.named_fields[var.field_count++] = f;
            
                        // 检测结束符或分隔符
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();          // 逗号分隔，继续下一个字段
                            continue;
                        } else if (strcmp(peek()->value, "}") == 0) {
                            break;              // 结束变体字段
                        } else {
                            // 支持换行分隔：如果当前 token 的缩进 >= 第一个字段的缩进，则视为换行分隔
                            int cur_indent = peek()->col - 1;
                            if (cur_indent >= field_indent) {
                                // 换行分隔，不消费任何 token，继续循环解析下一个字段
                                continue;
                            } else {
                                error_at(peek()->line, peek()->col, "期望 ',' 或 '}'");
                            }
                        }
                    }
                }
                expect("}");  // 消费变体内部的结束 '}'
            }
            variants.push_back(var);

            // ---- 分隔符处理（修改点：支持换行） ----
            if (variant_brace) {
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                    continue;
                } else if (strcmp(peek()->value, "}") == 0) {
                    continue;   // 由循环开头处理
                } else if (peek()->col - 1 >= variant_indent) {
                    // 换行分隔（缩进 >= 第一个变体的缩进），继续解析下一个变体
                    continue;
                } else {
                    error_at(peek()->line, peek()->col, "期望 ',' 或 '}'");
                }
            } else {
                // 缩进模式：逗号可选
                if (strcmp(peek()->value, ",") == 0)
                    consume();
                // 缩进回退由循环开头判断
            }
        }

        // ---- 构建 UNION 节点 ----
        ASTNode* node = new_node(NODE_UNION_DEF);
        node->data.union_def.name = type_name;
        node->data.union_def.common_count = common_fields.size();
        node->data.union_def.common_fields = (StructField*)malloc(common_fields.size() * sizeof(StructField));
        for (size_t i = 0; i < common_fields.size(); i++)
            node->data.union_def.common_fields[i] = common_fields[i];
        node->data.union_def.variant_count = variants.size();
        node->data.union_def.variants = (UnionVariant*)malloc(variants.size() * sizeof(UnionVariant));
        for (size_t i = 0; i < variants.size(); i++)
            node->data.union_def.variants[i] = variants[i];
            
        // ----- 注册联合类型 (TYPE_UNION) -----
        TypeNode* type = new TypeNode;
        type->kind = TYPE_UNION;
        type->variant_type.variant_count = node->data.union_def.variant_count;
        type->variant_type.variants = (UnionVariant*)malloc(type->variant_type.variant_count * sizeof(UnionVariant));
        for (int i = 0; i < type->variant_type.variant_count; i++) {
            UnionVariant* sv = &node->data.union_def.variants[i];
            UnionVariant* dv = &type->variant_type.variants[i];
            dv->name = strdup(sv->name);
            dv->param_count = sv->param_count;
            if (sv->param_count > 0) {
                dv->param_types = (TypeNode**)malloc(dv->param_count * sizeof(TypeNode*));
                for (int j = 0; j < dv->param_count; j++)
                    dv->param_types[j] = copy_type_node(sv->param_types[j]);
                dv->named_fields = NULL;
                dv->field_count = 0;
            } else {
                dv->param_types = NULL;
                dv->field_count = sv->field_count;
                if (dv->field_count > 0) {
                    dv->named_fields = (StructField*)malloc(dv->field_count * sizeof(StructField));
                    for (int j = 0; j < dv->field_count; j++) {
                        dv->named_fields[j].name = strdup(sv->named_fields[j].name);
                        dv->named_fields[j].type = copy_type_node(sv->named_fields[j].type);
                    }
                } else {
                    dv->named_fields = NULL;
                }
            }
        }
        type_aliases[type_key_parse(type_name)] = type;

        if (is_brace && strcmp(peek()->value, "}") == 0) {
            consume();
        }
        
        return node;
    }
    else {
        // ---- 纯结构体（无 '=>'） ----
        ASTNode* node = new_node(NODE_STRUCT_DEF);
        node->data.struct_def.name = type_name;
        node->data.struct_def.field_count = common_fields.size();
        node->data.struct_def.fields = (StructField*)malloc(common_fields.size() * sizeof(StructField));
        for (size_t i = 0; i < common_fields.size(); i++)
            node->data.struct_def.fields[i] = common_fields[i];

        // ----- 注册结构体类型 (TYPE_STRUCT) -----
        TypeNode* type = new TypeNode;
        type->kind = TYPE_STRUCT;
        type->struct_type.field_count = node->data.struct_def.field_count;
        type->struct_type.fields = (StructField*)malloc(type->struct_type.field_count * sizeof(StructField));
        for (int i = 0; i < type->struct_type.field_count; i++) {
            type->struct_type.fields[i].name = strdup(node->data.struct_def.fields[i].name);
            type->struct_type.fields[i].type = copy_type_node(node->data.struct_def.fields[i].type);
        }
        type_aliases[type_key_parse(type_name)] = type;
        return node;
    }
}

 ASTNode* parse_statement(int allow_semicolon) {
    if (allow_semicolon) {
        while (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ";") == 0) {
            consume();
        }
        // 跳完后遇到 EOF 或块结束，返回空节点（exec_statement 中 NODE_NULL 是 no-op）
        if (peek()->type == TOK_EOF ||
            (peek()->type == TOK_SYMBOL && strcmp(peek()->value, "}") == 0)) {
            return new_node(NODE_NULL);
        }
    }
    Token* t = peek();

    bool is_static = false;
    bool is_stmt_func = false;
    g_stmt_start_line = t->line;
    g_stmt_start_col = t->col;
    
    // 尝试解析类定义（可带修饰符：privat/schutz/öffent/stati）
    int saved_pos_class = tok_pos;
    int access = 0;                // 0=public, 1=private, 2=protected
    bool is_static_class = false;

    while (true) {
        if (strcmp(peek()->value, "privat") == 0) {
            consume(); access = 1;
        } else if (strcmp(peek()->value, "schutz") == 0) {
            consume(); access = 2;
        } else if (strcmp(peek()->value, "öffent") == 0) {
            consume(); access = 0;
        } else if (strcmp(peek()->value, "stati") == 0) {
            consume(); is_static_class = true;
        } else {
            break;
        }
    }

    if (strcmp(peek()->value, "klass") == 0) {
        consume();  // 消耗 'klass'
        ASTNode* node = parse_class_definition(access, is_static_class);
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    } else {
        tok_pos = saved_pos_class;   // 回退，尝试其他语句
    }

    if (strcmp(t->value, "umf") == 0) {
        consume(); // 消费 'umf'
        Token* name_tok = peek();
        char* name = nullptr;
    
        // 名称可以是字符串或标识符
        if (name_tok->type == TOK_REGEX || name_tok->type == TOK_STRING) {
            consume();
            name = strdup(name_tok->value);
        } else if (name_tok->type == TOK_IDENT) {
            consume();
            name = strdup(name_tok->value);
        } else {
            error_at(name_tok->line, name_tok->col, "期望作用域名称（标识符或字符串）");
        }
    
        char* parent = NULL;
        if (strcmp(peek()->value, "von") == 0) {
            consume();
            Token* parent_tok = peek();
            if (parent_tok->type == TOK_REGEX || parent_tok->type == TOK_STRING) {
                consume();
                parent = strdup(parent_tok->value);
            } else if (parent_tok->type == TOK_IDENT) {
                consume();
                parent = strdup(parent_tok->value);
            } else {
                error_at(parent_tok->line, parent_tok->col, "期望父作用域名称");
            }
        }
    
        // 判断是定义还是解引用
        bool is_definition = false;
        if (strcmp(peek()->value, "{") == 0) {
            is_definition = true;
        } else {
            // 缩进块：下一 token 列号大于 umf 的列号
            int cur_indent = t->col - 1;
            if (peek()->type != TOK_EOF && peek()->line > t->line && (peek()->col - 1) > cur_indent) {
                is_definition = true;
            }
        }
    
        if (is_definition) {
            int base_indent = t->col - 1;
            g_umf_parse_stack.push_back(name);
            ASTNode* body = parse_body_block(base_indent);
            g_umf_parse_stack.pop_back();
            ASTNode* node = new_node(NODE_UMF_DEF);
            node->data.umf_def.name = name;
            node->data.umf_def.parent_name = parent;
            node->data.umf_def.body = body;
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        } else {
            // 解引用：umf A
            if (parent) {
                free(parent); // 解引用不支持 von
                kr_error("umf 解引用不支持 'von'");
            }
            ASTNode* node = new_node(NODE_UMF_IMPORT);
            node->data.umf_import.name = name;
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        }
    }

    // ---- 尝试解析返回类型前缀的函数定义 ----
    while (strcmp(peek()->value, "stati") == 0 || strcmp(peek()->value, "satz") == 0) {
        if (strcmp(peek()->value, "satz") == 0) {
            consume();
            is_stmt_func = true;
        }
        if (strcmp(peek()->value, "stati") == 0) {
            consume();
            is_static = true;
        }
    }

    // 再尝试解析返回类型（如果有）
    int saved_pos = tok_pos;
    TypeNode* ret_type = nullptr;
    bool has_ret_type_def = false;
    try {
        ret_type = parse_type_expr();
        // 检查后面是否跟标识符和 '('，确定是否为函数定义
        if (peek()->type == TOK_IDENT && tok_pos + 1 < token_count &&
            strcmp(tokens[tok_pos + 1].value, "(") == 0 &&
            tokens[saved_pos].line == tokens[tok_pos].line) {
            has_ret_type_def = true;
        } else {
            tok_pos = saved_pos;
            if (ret_type) free_type_node(ret_type);
            ret_type = nullptr;
        }
    } catch (const KRError&) {
        tok_pos = saved_pos;
    }

    t = peek();

    if (has_ret_type_def) {
        // ----- 解析函数名 -----
        Token* name_tok = consume();
        if (name_tok->type != TOK_IDENT)
            error_at(name_tok->line, name_tok->col, "期望函数名");

        char* name = strdup(name_tok->value);

        // ----- 解析参数列表 -----
        expect("(");
        char** params = NULL;
        int param_count = 0;
        bool* param_is_const = NULL;
        ASTNode** param_defaults = NULL;
        TypeNode** param_types = NULL;
        char* vararg_name = NULL;
        TypeNode* vararg_type = nullptr;
        parse_param_list(&params, &param_count, &param_is_const, &param_defaults, &param_types, &vararg_name, &vararg_type);

        if (strcmp(peek()->value, ":") == 0) {
            consume();
            ret_type = parse_type_expr();
        }

        // ----- 解析函数体 -----
        int base_indent = g_stmt_start_col - 1;
        ASTNode* body = parse_body_block(base_indent);

        // ----- 构建 AST 节点 -----
        ASTNode* node = new_node(NODE_FUNC_DEF);
        node->data.func_def.name = name;
        node->data.func_def.params = params;
        node->data.func_def.param_count = param_count;
        node->data.func_def.body = body;
        node->data.func_def.is_memoized = false;
        node->data.func_def.global_scope = false;
        node->data.func_def.is_static = is_static;
        node->data.func_def.return_type = ret_type;
        node->data.func_def.vararg_name = vararg_name;
        node->data.func_def.param_is_const = param_is_const;
        node->data.func_def.param_defaults = param_defaults;
        node->data.func_def.param_types = param_types;
        node->data.func_def.vararg_type = vararg_type;
        node->data.func_def.is_stmt_func = is_stmt_func;

        if (is_stmt_func && name) {
            g_stmt_func_names.insert(name);
        }

        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    {
        Token* ident_tok = peek();
        if (ident_tok->type == TOK_IDENT) {
            std::string ident_name = ident_tok->value;
            bool is_stmt_func = (g_stmt_func_names.find(ident_name) != g_stmt_func_names.end());
            if (is_stmt_func) {
                // 检查后面是否跟 '('（带括号的函数调用由其他逻辑处理）
                int next_pos = tok_pos + 1;
                bool has_paren = (next_pos < token_count && strcmp(tokens[next_pos].value, "(") == 0);
                if (!has_paren) {
                    // 这是一个无括号的语句函数调用
                    consume(); // 消费标识符
                    std::vector<ASTNode*> args;
                    int func_line = ident_tok->line;
                    while (true) {
                        Token* cur = peek();
                        // 结束条件：换行、分号、右花括号、EOF
                        if (cur->line != func_line || strcmp(cur->value, ";") == 0 ||
                            strcmp(cur->value, "}") == 0 || cur->type == TOK_EOF) {
                            break;
                        }
                        // 跳过多余逗号
                        if (strcmp(cur->value, ",") == 0) {
                            consume();
                            continue;
                        }
                        ASTNode* arg = nullptr;
                        if (strcmp(cur->value, "...") == 0 && cur->type == TOK_OP) {
                            consume();
                            ASTNode* expr = parse_expression();
                            ASTNode* spread_node = new_node(NODE_SPREAD_ARG);
                            spread_node->data.spread.expr = expr;
                            arg = spread_node;
                        } else {
                            arg = parse_expression();
                        }
                        args.push_back(arg);
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();
                            continue;
                        } else {
                            break;
                        }
                    }
                    ASTNode* node = new_node(NODE_FUNC_CALL);
                    node->data.func_call.name = strdup(ident_name.c_str());
                    node->data.func_call.arg_count = (int)args.size();
                    node->data.func_call.args = (ASTNode**)malloc(args.size() * sizeof(ASTNode*));
                    for (size_t i = 0; i < args.size(); i++) {
                        node->data.func_call.args[i] = args[i];
                    }
                    node->data.func_call.func_expr = nullptr;
                    CONSUME_OPTIONAL_SEMICOLON();
                    return node;
                }
            }
        }
    }
    int saved_pos_var = tok_pos;
    TypeNode* prefix_type = nullptr;
    bool is_var_prefix = false;
    try {
        prefix_type = parse_type_expr();
        if (peek()->type == TOK_IDENT) {
            int next_pos = tok_pos + 1;
            if (next_pos < token_count && strcmp(tokens[next_pos].value, "(") != 0) {
                if (peek()->line == tokens[saved_pos_var].line) {
                    is_var_prefix = true;
                } else {
                    tok_pos = saved_pos_var;
                    free_type_node(prefix_type);
                    prefix_type = nullptr;
                }
            } else {
                tok_pos = saved_pos_var;
                free_type_node(prefix_type);
                prefix_type = nullptr;
            }
        } else {
            tok_pos = saved_pos_var;
            free_type_node(prefix_type);
            prefix_type = nullptr;
        }
    } catch (const KRError&) {
        tok_pos = saved_pos_var;
    }

    if (is_var_prefix && prefix_type) {
        Token* name_tok = consume();
        if (name_tok->type != TOK_IDENT)
            error_at(name_tok->line, name_tok->col, "期望变量名");
        char* name = strdup(name_tok->value);

        // 忽略多余的 ': 类型'
        if (strcmp(peek()->value, ":") == 0) {
            consume();
            TypeNode* extra = parse_type_expr();
            free_type_node(extra);
            kr_warn("变量 '%s' 已有类型前缀，忽略后面的类型注解", name);
        }

        ASTNode* expr = nullptr;
        if (strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) {
            consume();
            expr = parse_expression();
        } else {
            expr = make_default_value_for_type(prefix_type);
        }

        ASTNode* node = new_node(NODE_VAR_DECL);
        node->data.var_decl.name = name;
        node->data.var_decl.expr = expr;
        node->data.var_decl.is_const = false;
        node->data.var_decl.type_annotation = prefix_type;  // 转移所有权
        node->data.var_decl.global = false;                 // 由 global 修饰决定

        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }

    if (strcmp(t->value, "imp") == 0) {
        consume();  // 消费 'imp'
        bool has_quote = false;
        char* filename = nullptr;
    
        Token* name_tok = peek();
        if (name_tok->type == TOK_REGEX || name_tok->type == TOK_STRING) {
            has_quote = true;
            consume();
            filename = strdup(name_tok->value);
        } else if (name_tok->type == TOK_IDENT) {
            // 无引号模块名，支持连字符
            std::string modname = name_tok->value;
            consume();
            // 向后合并 "- 标识符" 序列，但遇到 "as" 或非标识符时停止
            while (tok_pos < token_count) {
                Token* cur = peek();
                // 必须是 '-' 且下一个 token 是标识符（且不能是 'as'）
                if (strcmp(cur->value, "-") == 0 &&
                    tok_pos + 1 < token_count &&
                    tokens[tok_pos + 1].type == TOK_IDENT &&
                    strcmp(tokens[tok_pos + 1].value, "as") != 0) {
                    consume(); // 消费 '-'
                    modname += "-";
                    modname += tokens[tok_pos].value;
                    consume(); // 消费标识符
                } else {
                    break;
                }
            }
            filename = strdup(modname.c_str());
        } else {
            error_at(name_tok->line, name_tok->col, "期望模块名（标识符或字符串）");
        }
    
        char* alias = nullptr;
        if (strcmp(peek()->value, "as") == 0) {
            consume();
            Token* alias_tok = consume();
            if (alias_tok->type != TOK_IDENT)
                error_at(alias_tok->line, alias_tok->col, "期望别名标识符");
            alias = strdup(alias_tok->value);
        }
    
        CONSUME_OPTIONAL_SEMICOLON();
        ASTNode* node = new_node(NODE_IMPORT);
        node->data.import.filename = filename;
        node->data.import.alias = alias;
        node->data.import.has_quote = has_quote; // false
        node->data.import.module_ast = nullptr;
        return node;
    }

    if (strcmp(t->value, "global") == 0) {
        consume(); // 消费 'global'
        int saved_pos_global = tok_pos;

        if (strcmp(peek()->value, "faul") == 0) {
            consume(); // 消费 'faul'
            Token* name_tok = consume();
            if (name_tok->type != TOK_IDENT)
                error_at(name_tok->line, name_tok->col, "期望变量名");
            char* name = strdup(name_tok->value);

            if (strcmp(peek()->value, "ist") == 0 ||
                strcmp(peek()->value, "=") == 0) {
                consume();
            } else {
                g_last_error_line = peek()->line;
                g_last_error_col  = peek()->col;
                std::string hint = make_keyword_alias_hint("ist", "ist");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                            "语法错误: 期望 'ist' 或 '='");
            }

            ASTNode* expr = parse_expression();
            ASTNode* node = new_node(NODE_LAZY_VAR_DECL);
            node->data.lazy_var_decl.name   = name;
            node->data.lazy_var_decl.expr   = expr;
            node->data.lazy_var_decl.global = true;   // 
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        }

        TypeNode* prefix_type_global = nullptr;
        bool is_typed_global = false;
        try {
            prefix_type_global = parse_type_expr();
            if (peek()->type == TOK_IDENT) {
                int next_pos = tok_pos + 1;
                if (next_pos < token_count && strcmp(tokens[next_pos].value, "(") != 0) {
                    if (peek()->line == tokens[saved_pos_global].line) {
                        is_typed_global = true;
                    } else {
                        tok_pos = saved_pos_global;
                        free_type_node(prefix_type_global);
                        prefix_type_global = nullptr;
                    }
                } else {
                    tok_pos = saved_pos_global;
                    free_type_node(prefix_type_global);
                    prefix_type_global = nullptr;
                }
            } else {
                tok_pos = saved_pos_global;
                free_type_node(prefix_type_global);
                prefix_type_global = nullptr;
            }
        } catch (const KRError&) {
            tok_pos = saved_pos_global;
        }

        if (is_typed_global && prefix_type_global) {
            Token* name_tok = consume();
            if (name_tok->type != TOK_IDENT)
                error_at(name_tok->line, name_tok->col, "期望变量名");
            char* name = strdup(name_tok->value);

            if (strcmp(peek()->value, ":") == 0) {
                consume();
                TypeNode* extra = parse_type_expr();
                free_type_node(extra);
                kr_warn("全局变量 '%s' 已有类型前缀，忽略后面的类型注解", name);
            }

            ASTNode* expr = nullptr;
            if (strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) {
                consume();
                expr = parse_expression();
            } else {
                expr = make_default_value_for_type(prefix_type_global);
            }

            ASTNode* node = new_node(NODE_VAR_DECL);
            node->data.var_decl.name = name;
            node->data.var_decl.expr = expr;
            node->data.var_decl.is_const = false;
            node->data.var_decl.type_annotation = prefix_type_global;
            node->data.var_decl.global = true;

            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        }
        if (strcmp(peek()->value, "{") == 0) {
            consume(); // 消费 '{'
            ASTNode* block = parse_block();   // 解析块内容
            expect("}");                      // 消费 '}'
            ASTNode* node = new_node(NODE_GLOBAL_BLOCK);
            // 直接接管块内的语句数组（转移所有权）
            node->data.block.stmts = block->data.block.stmts;
            node->data.block.count = block->data.block.count;
            free(block);                      // 释放外壳，内部 stmts 已被接管
            CONSUME_OPTIONAL_SEMICOLON();     // 允许后面加分号
            return node;
        }
        Token* next = peek();
    
        // ---------- 情况1：global der/das/des 声明 ----------
        if (strcmp(next->value, "der") == 0 || strcmp(next->value, "das") == 0 ||
            strcmp(next->value, "des") == 0) {
            bool is_const = (strcmp(next->value, "das") == 0);
            bool is_alias = (strcmp(next->value, "des") == 0);
            consume(); // 消费 der/das/des
            Token* name_tok = consume();
            if (name_tok->type != TOK_IDENT)
                error_at(name_tok->line, name_tok->col, "期望标识符");
            char* name = strdup(name_tok->value);
            
            // 可选的类型注解（仅对 der/das 有效，des 不支持类型注解）
            TypeNode* type_anno = nullptr;
            if (!is_alias && strcmp(peek()->value, ":") == 0) {
                consume();
                type_anno = parse_type_expr();
            }
            
            ASTNode* expr;
            if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                consume();
                expr = parse_expression();
            } else {
                // 有类型注解时使用默认值，否则 null
                expr = type_anno ? make_default_value_for_type(type_anno) : new_node(NODE_NULL);
            }
            
            if (is_alias) {
                // des 右侧必须是标识符（目标变量名）
                Token* target_tok = peek();
                if (target_tok->type != TOK_IDENT)
                    error_at(target_tok->line, target_tok->col, "别名目标必须是一个变量名");
                consume(); // 消费目标名
                ASTNode* node = new_node(NODE_ALIAS_DECL);
                node->data.alias_decl.name = strdup(name);
                node->data.alias_decl.target = strdup(target_tok->value);
                node->data.alias_decl.global = true; // 全局别名
                free(name);
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            } else {
                // der/das 处理
                ASTNode* node = new_node(NODE_VAR_DECL);
                node->data.var_decl.name = name;
                node->data.var_decl.expr = expr;
                node->data.var_decl.is_const = is_const;
                node->data.var_decl.type_annotation = type_anno;
                node->data.var_decl.global = true;
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
        }
        // ---------- 情况2 和 3：global 变量 ... ----------
        else if (next->type == TOK_IDENT) {
            // 保存第一个标识符的 token
            Token* name1_tok = consume();
            char* name1 = strdup(name1_tok->value);
        
            // ---- 检测类型注解（global x: type [= expr]） ----
            if (strcmp(peek()->value, ":") == 0) {
                consume(); // 跳过 ':'
                TypeNode* type_anno = parse_type_expr();
                ASTNode* expr;
                if (strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) {
                    consume();
                    expr = parse_expression();
                } else {
                    expr = make_default_value_for_type(type_anno);
                }
                ASTNode* node = new_node(NODE_VAR_DECL);
                node->data.var_decl.name = name1;        // 接管 name1
                node->data.var_decl.expr = expr;
                node->data.var_decl.is_const = false;    // global 默认可变
                node->data.var_decl.type_annotation = type_anno;
                node->data.var_decl.global = true;
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
        
            // ---------- 情况3：交换 global a <-> b ----------
            if (strcmp(peek()->value, "<->") == 0 && peek()->type == TOK_OP) {
                consume(); // 消费 '<->'
                Token* name2_tok = peek();
                if (name2_tok->type != TOK_IDENT)
                    error_at(name2_tok->line, name2_tok->col, "期望标识符");
                consume(); // 消费第二个标识符
                char* name2 = strdup(name2_tok->value);
        
                // 创建变量节点并传入正确的行列
                ASTNode* left_var = new_node(NODE_VARIABLE, name1_tok->line, name1_tok->col);
                left_var->data.var_name = name1;  // 节点接管 name1
        
                ASTNode* right_var = new_node(NODE_VARIABLE, name2_tok->line, name2_tok->col);
                right_var->data.var_name = name2; // 节点接管 name2
        
                ASTNode* node = new_node(NODE_SWAP_ASSIGN);
                node->data.swap.left = left_var;
                node->data.swap.right = right_var;
                node->data.swap.global = true;
        
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            // ---------- 情况2：赋值 global a ist expr ----------
            else {
                ASTNode* expr;
                if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                    consume();
                    expr = parse_expression();
                } else {
                    // 无初始化时，默认赋 null
                    expr = new_node(NODE_NULL);
                }
        
                ASTNode* node = new_node(NODE_ASSIGN);
                node->data.assign.name = name1;   // 节点接管 name1
                node->data.assign.expr = expr;
                node->data.assign.global = true;
        
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
        }
        else {
            g_last_error_line = next->line;
            g_last_error_col  = next->col;
            std::string hint = make_keyword_alias_hint("global", "global");
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                          "global 后必须跟 der/das 或变量名");
        }
    }

    if (strcmp(t->value, "bind") == 0) {
        consume();
        std::vector<char*> keys;
        do {
            Token* key_tok = peek();
            if (key_tok->type != TOK_REGEX && key_tok->type != TOK_STRING) {
                error_at(key_tok->line, key_tok->col, "按键必须是字符串");
            }
            consume();
            std::string norm_key = normalize_key_string(key_tok->value);
            keys.push_back(strdup(norm_key.c_str()));
            if (strcmp(peek()->value, ",") == 0) {
                consume();
            } else {
                break;
            }
        } while (true);
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);

        if (keys.size() == 1) {
            ASTNode* node = new_node(NODE_KEY_BIND);
            node->data.key_bind.key = keys[0];
            node->data.key_bind.body = body;
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        } else {
            ASTNode* block = new_node(NODE_BLOCK);
            block->data.block.stmts = (ASTNode**)malloc(keys.size() * sizeof(ASTNode*));
            block->data.block.count = keys.size();
            for (size_t i = 0; i < keys.size(); i++) {
                ASTNode* node = new_node(NODE_KEY_BIND);
                node->data.key_bind.key = keys[i];
                node->data.key_bind.body = copy_ast(body);
                block->data.block.stmts[i] = node;
            }
            free_ast(body);                 // 释放原始 body，因为已复制
            CONSUME_OPTIONAL_SEMICOLON();
            return block;
        }
    }

    if (strcmp(t->value, "art") == 0) {
        consume(); // 'art'
        Token* name_tok = consume();
        if (name_tok->type != TOK_IDENT)
            error_at(name_tok->line, name_tok->col, "期望类型名称");
        char* type_name = strdup(name_tok->value);
    
        if (strcmp(peek()->value, "=") == 0) {
            consume(); // '='
            // ---- 检测联合（标识符或字符串混合） ----
            if ((peek()->type == TOK_IDENT || peek()->type == TOK_REGEX) &&
                tok_pos + 1 < token_count && strcmp(tokens[tok_pos+1].value, "|") == 0) {
                std::vector<ASTNode*> members;
                while (true) {
                    if (strcmp(peek()->value, "|") == 0) consume();
                    Token* tok = peek();
                    if (tok->type == TOK_IDENT) {
                        consume();
                        ASTNode* var_node = new_node(NODE_VARIABLE);
                        var_node->data.var_name = strdup(tok->value);
                        members.push_back(var_node);
                    } else if (tok->type == TOK_REGEX) { // 字符串字面量
                        consume();
                        char* unescaped = unescape_string(tok->value);
                        ASTNode* str_node = new_node(NODE_STRING);
                        str_node->data.string = unescaped;
                        members.push_back(str_node);
                    } else {
                        error_at(tok->line, tok->col, "联合成员必须是标识符或字符串");
                    }
                    if (strcmp(peek()->value, "|") != 0) break;
                }
                // 构建 NODE_TYPE_DEF 节点
                ASTNode* node = new_node(NODE_TYPE_DEF);
                node->data.type_def.name = type_name;   // 接管 type_name
                node->data.type_def.member_count = (int)members.size();
                node->data.type_def.members = (ASTNode**)malloc(node->data.type_def.member_count * sizeof(ASTNode*));
                for (int i = 0; i < node->data.type_def.member_count; ++i) {
                    node->data.type_def.members[i] = members[i];
                }
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            // ---- 旧式类型别名：立即注册 ----
            TypeNode* type = parse_type_expr();
            type_aliases[type_key_parse(type_name)] = type;
            free(type_name);
            CONSUME_OPTIONAL_SEMICOLON();
            return new_node(NODE_NULL);
        }
    
        // 无 '=' 的复合定义（结构体/联合）
        bool is_brace = (strcmp(peek()->value, "{") == 0);
        if (is_brace) consume();
        ASTNode* node = parse_complex_type(type_name, is_brace);
        CONSUME_OPTIONAL_SEMICOLON();
        free(type_name);
        return node;
    }
    // ---- 关键字处理 ----
    if (strcmp(t->value, "nutz") == 0) {
        consume(); // 消费 'nutz'
        std::vector<char*> names;
    
        if (strcmp(peek()->value, "(") == 0) {
            consume(); // 消费 '('
            if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                while (true) {
                    Token* name_tok = consume();
                    if (name_tok->type != TOK_IDENT)
                        error_at(name_tok->line, name_tok->col, "期望标识符");
                    names.push_back(strdup(name_tok->value));
                    if (strcmp(peek()->value, ",") == 0)
                        consume();
                    else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)
                        break;
                    else
                        error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                }
            }
            expect(")");
        } else {
            // 无括号：直接读取标识符列表
            while (peek()->type == TOK_IDENT) {
                Token* name_tok = consume();
                names.push_back(strdup(name_tok->value));
                if (strcmp(peek()->value, ",") == 0)
                    consume();
                else
                    break;
            }
        }
    
        CONSUME_OPTIONAL_SEMICOLON();
    
        // ---- 特殊处理：nutz _ ----
        if (names.size() == 1 && strcmp(names[0], "_") == 0) {
            free(names[0]); // 释放临时字符串
            ASTNode* node = new_node(NODE_MARK_ALL_USED);
            return node;
        }
    
        // 普通 nutz 标识符列表
        ASTNode* node = new_node(NODE_MARK_USED);
        node->data.mark_used.count = names.size();
        node->data.mark_used.names = (char**)malloc(names.size() * sizeof(char*));
        for (size_t i = 0; i < names.size(); ++i)
            node->data.mark_used.names[i] = names[i];
        return node;
    }
    if (strcmp(t->value, "der") == 0 || strcmp(t->value, "das") == 0) {
        int is_const = (strcmp(t->value, "das") == 0);
        consume(); // 消费 'der' 或 'das'

        // ---- 尝试解析类型前缀 ----
        int saved_pos = tok_pos;
        TypeNode* type_anno = nullptr;
        bool has_type_prefix = false;
        Token* name_tok = nullptr;
        try {
            TypeNode* possible_type = parse_type_expr();
            // 如果解析成功，且下一个 token 是标识符，且不是关键字 ist, =, , 
            if (peek()->type == TOK_IDENT &&
                strcmp(peek()->value, "ist") != 0 &&
                strcmp(peek()->value, "=") != 0 &&
                strcmp(peek()->value, ",") != 0) {
                type_anno = possible_type;
                has_type_prefix = true;
                name_tok = consume(); // 消费标识符作为变量名
            } else {
                // 解析出的类型不适用，回退并释放
                tok_pos = saved_pos;
                free_type_node(possible_type);
            }
        } catch (...) {
            // 解析类型失败，回退
            tok_pos = saved_pos;
        }

        // ---- 类型前缀情况 ----
        if (has_type_prefix) {
            if (name_tok->type != TOK_IDENT) {
                error_at(name_tok->line, name_tok->col, "期望标识符作为变量名");
            }
            char* name = strdup(name_tok->value);

            // 处理赋值（可选）
            ASTNode* expr = nullptr;
            if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                consume();
                expr = parse_expression();
            } else {
                // 无赋值时，若存在类型注解则使用默认值，否则 null
                expr = type_anno ? make_default_value_for_type(type_anno) : new_node(NODE_NULL);
            }

            ASTNode* node = new_node(NODE_VAR_DECL);
            node->data.var_decl.name = name;
            node->data.var_decl.expr = expr;
            node->data.var_decl.is_const = is_const;
            node->data.var_decl.type_annotation = type_anno; // 类型前缀作为注解
            node->data.var_decl.global = false; // 默认局部

            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        }
        
        // 解析第一个变量名
        Token* first_name_tok = consume();
        if (first_name_tok->type != TOK_IDENT) {
            error_at(first_name_tok->line, first_name_tok->col, "期望标识符作为变量名");
        }
        char* first_name = strdup(first_name_tok->value);
        
        // 检查下一个 token，决定是统一赋值还是分别赋值
        if (strcmp(peek()->value, ",") == 0) {
            // 收集所有变量名
            std::vector<char*> names;
            names.push_back(first_name); // first_name 已 strdup
        
            while (strcmp(peek()->value, ",") == 0) {
                consume();
                Token* next_name_tok = consume();
                if (next_name_tok->type != TOK_IDENT)
                    error_at(next_name_tok->line, next_name_tok->col, "期望标识符作为变量名");
                names.push_back(strdup(next_name_tok->value));
            }
        
            // 消费 'ist' 或 '='
            TypeNode* type_anno = nullptr;
            if (strcmp(peek()->value, ":") == 0) {
                consume();
                type_anno = parse_type_expr();
            }
            ASTNode* expr;
            if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                consume();
                expr = parse_expression();
            } else {
                expr = type_anno ? make_default_value_for_type(type_anno) : new_node(NODE_NULL);
            }
        
            // 如果是多个变量，生成解构节点；否则保持普通声明
            ASTNode* result;
            if (names.size() == 1) {
                // 单个变量：普通声明
                ASTNode* decl = new_node(NODE_VAR_DECL, first_name_tok->line, first_name_tok->col);
                decl->data.var_decl.name = names[0];
                decl->data.var_decl.expr = expr;
                decl->data.var_decl.is_const = is_const;
                decl->data.var_decl.type_annotation = nullptr;
                result = decl;
            } else {
                // 多个变量：解构赋值
                ASTNode* dest = new_node(NODE_DESTRUCTURE);
                dest->data.destructure.count = names.size();
                dest->data.destructure.names = (char**)malloc(dest->data.destructure.count * sizeof(char*));
                for (size_t i = 0; i < names.size(); i++)
                    dest->data.destructure.names[i] = names[i]; // 直接接管（已在堆上）
                dest->data.destructure.expr = expr;
                dest->data.destructure.is_const = is_const;
                result = dest;
            }
        
            CONSUME_OPTIONAL_SEMICOLON();
            return result;
        } else {
            // ========== 分别赋值模式 ==========
            ASTNode** decls = NULL;
            int decl_count = 0;
            
            // 处理第一个变量 first_name
            // 可选的类型注解
            TypeNode* type_anno = nullptr;
            if (strcmp(peek()->value, ":") == 0) {
                consume();
                type_anno = parse_type_expr();
            }
            ASTNode* expr;
            if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                consume();
                expr = parse_expression();
            } else {
                expr = type_anno ? make_default_value_for_type(type_anno) : new_node(NODE_NULL);
            }
            
            ASTNode* decl_node = new_node(NODE_VAR_DECL, first_name_tok->line, first_name_tok->col);
            decl_node->data.var_decl.name = first_name;
            decl_node->data.var_decl.expr = expr;
            decl_node->data.var_decl.is_const = is_const;
            decl_node->data.var_decl.type_annotation = type_anno;
            decls = (ASTNode**)realloc(decls, (decl_count + 1) * sizeof(ASTNode*));
            decls[decl_count++] = decl_node;
            
            // 循环处理后续变量（如果有逗号）
            while (strcmp(peek()->value, ",") == 0) {
                consume(); // 消费逗号
                Token* next_name_tok = consume();
                if (next_name_tok->type != TOK_IDENT) {
                    error_at(next_name_tok->line, next_name_tok->col, "期望标识符作为变量名");
                }
                char* next_name = strdup(next_name_tok->value);
                
                TypeNode* next_type_anno = nullptr;
                if (strcmp(peek()->value, ":") == 0) {
                    consume();
                    next_type_anno = parse_type_expr();
                }
                ASTNode* expr;
                if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                    consume();
                    expr = parse_expression();
                } else {
                    expr = type_anno ? make_default_value_for_type(type_anno) : new_node(NODE_NULL);
                }
                
                ASTNode* next_decl = new_node(NODE_VAR_DECL);
                next_decl->data.var_decl.name = next_name;
                next_decl->data.var_decl.expr = expr;
                next_decl->data.var_decl.is_const = is_const;
                next_decl->data.var_decl.type_annotation = next_type_anno;
                decls = (ASTNode**)realloc(decls, (decl_count + 1) * sizeof(ASTNode*));
                decls[decl_count++] = next_decl;
            }
            
            // 打包返回
            ASTNode* result;
            if (decl_count == 1) {
                result = decls[0];
                free(decls);
            } else {
                ASTNode* block = new_node(NODE_BLOCK);
                block->data.block.stmts = decls;
                block->data.block.count = decl_count;
                result = block;
            }
            CONSUME_OPTIONAL_SEMICOLON();
            return result;
        }
    }
    else if (strcmp(t->value, "des") == 0) {
        consume();
        Token* name_tok = consume();
        if (name_tok->type != TOK_IDENT)
            error_at(name_tok->line, name_tok->col, "期望标识符作为别名");
        if (strcmp(peek()->value, "ist") != 0 && strcmp(peek()->value, "=") != 0) {
            g_last_error_line = peek()->line;
            g_last_error_col  = peek()->col;
            std::string hint = make_keyword_alias_hint("ist", "ist");
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "期望 'ist' 或 '='");
        }
        consume();
        Token* target_tok = peek();
        if (target_tok->type != TOK_IDENT)
            error_at(target_tok->line, target_tok->col, "期望标识符作为目标变量");
        consume();
        ASTNode* node = new_node(NODE_ALIAS_DECL);
        node->data.alias_decl.name = strdup(name_tok->value);
        node->data.alias_decl.target = strdup(target_tok->value);
        node->data.alias_decl.global = false;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else     if (strcmp(t->value, "ver") == 0) {
        consume();
        ASTNode* try_body = NULL;
        char* catch_var = NULL;
        ASTNode* catch_body = NULL;
        ASTNode* finally_body = NULL;

        if (strcmp(peek()->value, "{") == 0) {
            // ---- 花括号模式 ----
            expect("{");
            try_body = parse_block();
            expect("}");

            // 处理 catch (den)
            if (strcmp(peek()->value, "den") == 0) {
                consume(); // 消费 'den'
                // 判断是否带括号
                if (strcmp(peek()->value, "(") == 0) {
                    consume(); // 消费 '('
                    Token* var_tok = consume();
                    if (var_tok->type != TOK_IDENT)
                        error_at(var_tok->line, var_tok->col, "期望标识符作为 catch 变量");
                    catch_var = strdup(var_tok->value);
                    expect(")");
                } else {
                    // 这里直接读取标识符，允许通配符 `_`
                    Token* var_tok = consume();
                    if (var_tok->type != TOK_IDENT)
                        error_at(var_tok->line, var_tok->col, "期望标识符作为 catch 变量");
                    catch_var = strdup(var_tok->value);
                }
                expect("{");
                catch_body = parse_block();
                expect("}");
            }

            // 处理 finally (die)
            if (strcmp(peek()->value, "die") == 0) {
                consume();
                expect("{");
                finally_body = parse_block();
                expect("}");
            }
        } else {
            // ---- 缩进模式 ----
            int base_indent = t->col - 1;
            try_body = parse_body_block(base_indent);

            // 只识别与 ver 同缩进的 den 和 die
            while (true) {
                if (peek()->type == TOK_EOF) break;
                Token* next = peek();
                if ((strcmp(next->value, "den") == 0 || strcmp(next->value, "die") == 0) && (next->col - 1 == base_indent)) {
                    if (strcmp(next->value, "den") == 0) {
                        consume();  // 消费 'den'
                        // 解析 catch 变量
                        if (strcmp(peek()->value, "(") == 0) {
                            consume();
                            Token* var_tok = consume();
                            if (var_tok->type != TOK_IDENT)
                                error_at(var_tok->line, var_tok->col, "期望标识符作为 catch 变量");
                            catch_var = strdup(var_tok->value);
                            expect(")");
                        } else {
                            Token* var_tok = consume();
                            if (var_tok->type != TOK_IDENT)
                                error_at(var_tok->line, var_tok->col, "期望标识符作为 catch 变量");
                            catch_var = strdup(var_tok->value);
                        }
                        int catch_indent = next->col - 1;
                        catch_body = parse_body_block(catch_indent);
                        continue;
                    } else { // die
                        consume();
                        int finally_indent = next->col - 1;
                        finally_body = parse_body_block(finally_indent);
                        break;
                    }
                } else {
                    break;
                }
            }
        }

        // 构造 try 节点
        ASTNode* node = new_node(NODE_TRY);
        node->data.try_stmt.try_body = try_body;
        node->data.try_stmt.catch_var = catch_var;
        node->data.try_stmt.catch_body = catch_body;
        node->data.try_stmt.finally_body = finally_body;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "dem") == 0) {
        consume();
        ASTNode* expr = parse_expression();
        ASTNode* node = new_node(NODE_THROW);
        node->data.throw_expr.expr = expr;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "zeig") == 0) {
        consume();
        ASTNode** exprs = NULL;
        int count = 0;
    
        // 检查是否带括号
        if (strcmp(peek()->value, "(") == 0) {
            consume(); // 消费 '('
            // 解析括号内逗号分隔的表达式列表
            if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                while (true) {
                    ASTNode* expr = parse_expression();
                    exprs = (ASTNode**)realloc(exprs, (count + 1) * sizeof(ASTNode*));
                    exprs[count++] = expr;
                    if (strcmp(peek()->value, ",") == 0) {
                        consume();
                        continue;
                    } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                        break;
                    } else {
                        error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                    }
                }
            }
            expect(")"); // 消费 ')'
        } else {
            // 无括号形式
            ASTNode* first = parse_expression();
            exprs = (ASTNode**)realloc(exprs, sizeof(ASTNode*));
            exprs[count++] = first;
            while (strcmp(peek()->value, ",") == 0) {
                consume();
                ASTNode* next = parse_expression();
                exprs = (ASTNode**)realloc(exprs, (count + 1) * sizeof(ASTNode*));
                exprs[count++] = next;
            }
        }
    
        // 处理 "bei" 行号标记（仅支持单个表达式）
        if (strcmp(peek()->value, "bei") == 0 && peek()->type == TOK_KEYWORD) {
            if (count != 1) {
                error_at(peek()->line, peek()->col, "bei 只能与单个表达式一起使用");
            }
            consume();
            ASTNode* line_expr = parse_expression();
            ASTNode* node = new_node(NODE_PRINT_WITH_LINE);
            node->data.print_with_line.expr = exprs[0];
            node->data.print_with_line.line = line_expr;
            free(exprs);
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        } else {
            ASTNode* node = new_node(NODE_PRINT_MULTI);
            node->data.print_multi.exprs = exprs;
            node->data.print_multi.count = count;
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        }
    }
    else if (strcmp(t->value, "schr") == 0) {
        consume();
        ASTNode** exprs = NULL;
        int count = 0;
    
        // 检查是否带括号
        if (strcmp(peek()->value, "(") == 0) {
            consume(); // 消费 '('
            if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                while (true) {
                    ASTNode* expr = parse_expression();
                    exprs = (ASTNode**)realloc(exprs, (count + 1) * sizeof(ASTNode*));
                    exprs[count++] = expr;
                    if (strcmp(peek()->value, ",") == 0) {
                        consume();
                        continue;
                    } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                        break;
                    } else {
                        error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                    }
                }
            }
            expect(")"); // 消费 ')'
        } else {
            // 无括号形式
            ASTNode* first = parse_expression();
            exprs = (ASTNode**)realloc(exprs, sizeof(ASTNode*));
            exprs[count++] = first;
            while (strcmp(peek()->value, ",") == 0) {
                consume();
                ASTNode* next = parse_expression();
                exprs = (ASTNode**)realloc(exprs, (count + 1) * sizeof(ASTNode*));
                exprs[count++] = next;
            }
        }
    
        ASTNode* node = new_node(NODE_PRINT_NO_NEWLINE_MULTI);
        node->data.print_multi.exprs = exprs;
        node->data.print_multi.count = count;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "sicher") == 0) {
        consume();
        ASTNode* expr = parse_expression();
        ASTNode* msg = NULL;
        if (strcmp(peek()->value, ",") == 0) {
            consume();                 // 消费逗号
            msg = parse_expression();  // 解析消息表达式（通常为字符串）
        }
        ASTNode* node = new_node(NODE_SICHER);
        node->data.sicher.expr = expr;
        node->data.sicher.msg_expr = msg;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "lies") == 0) {
        consume();
        Token* name_tok = consume();
        char* name = strdup(name_tok->value);
    
        ASTNode** args = NULL;
        int arg_count = 0;
        ASTNode* multiline_expr = NULL;
        int flags = 0;
    
        if (strcmp(peek()->value, "mit") == 0) {
            consume();
            expect("(");                      // 强制括号
    
            while (strcmp(peek()->value, ")") != 0) {
                if (strcmp(peek()->value, "bis") == 0) {
                    consume();
                    expect("(");
                    multiline_expr = parse_expression();
                    expect(")");
                } else {
                    // 普通参数解析（对象含 m 键、标志字符串等）
                    ASTNode* expr = parse_expression();
                    // 处理对象字面量含 m 键
                    if (expr->type == NODE_OBJECT_LITERAL) {
                        bool found_m = false;
                        for (int i = 0; i < expr->data.object_lit.count; i++) {
                            ASTNode* key_node = expr->data.object_lit.key_exprs[i];
                            if (key_node->type == NODE_STRING && strcmp(key_node->data.string, "m") == 0) {
                                if (multiline_expr != NULL) {
                                    error_at(peek()->line, peek()->col, "只能指定一个 m: 标记");
                                }
                                multiline_expr = expr->data.object_lit.vals[i];
                                expr->data.object_lit.vals[i] = NULL;
                                found_m = true;
                                break;
                            }
                        }
                        if (found_m) {
                            free_ast(expr);
                        } else {
                            args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                            args[arg_count++] = expr;
                        }
                    } else if (expr->type == NODE_STRING) {
                        // 处理标志字符串 "v", "z", "k"
                        const char* val = expr->data.string;
                        if (strcmp(val, "v") == 0) {
                            flags |= FLAG_NO_STORE;
                            free_ast(expr);
                        } else if (strcmp(val, "z") == 0) {
                            if (flags & FLAG_FLOAT) error_at(peek()->line, peek()->col, "lies 参数 k 和 z 冲突");
                            flags |= FLAG_NUM;
                            free_ast(expr);
                        } else if (strcmp(val, "k") == 0) {
                            if (flags & FLAG_NUM) error_at(peek()->line, peek()->col, "lies 参数 k 和 z 冲突");
                            flags |= FLAG_FLOAT;
                            free_ast(expr);
                        } else {
                            args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                            args[arg_count++] = expr;
                        }
                    } else {
                        // 其他任意表达式
                        args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                        args[arg_count++] = expr;
                    }
                }
            
                // 处理逗号或结束
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                    break;
                } else {
                    error_at(peek()->line, peek()->col, "参数列表期望 ',' 或 ')'");
                }
            }
            expect(")");
        }
    
        ASTNode* node = new_node(NODE_INPUT);
        node->data.input.name = name;
        node->data.input.args = args;
        node->data.input.arg_count = arg_count;
        node->data.input.multiline_expr = multiline_expr;
        node->data.input.flags = flags;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "als") == 0) {
        int als_col = t->col;
        int als_line = t->line;
        consume();  // 消费 "als"
        ASTNode* match_node = parse_match_expression(als_col, als_line);
        ASTNode* stmt = new_node(NODE_EXPR_STMT);
        stmt->data.expr_stmt.expr = match_node;
        CONSUME_OPTIONAL_SEMICOLON();
        return stmt;
    }
    else if (strcmp(t->value, "snfa") == 0) {
        g_last_error_line = t->line;
        g_last_error_col = t->col;
        std::string hint = make_keyword_alias_hint("snfa", "fa");
        kr_error_hint(hint.c_str(), "'snfa' 只能在 'fa' 语句中使用。");
    }
    else if (strcmp(t->value, "sonst") == 0) {
        g_last_error_line = t->line;
        g_last_error_col = t->col;
        std::string hint = make_keyword_alias_hint("sonst", "fa");
        kr_error_hint(hint.c_str(), "'sonst' 只能在 'fa' 语句中使用。");
    }
    else if (strcmp(t->value, "fa") == 0) {
        consume(); // 消费 'fa'
        ASTNode* cond = nullptr;
    
        // 尝试解析无括号 in 列表，失败则回退到普通表达式
        cond = parse_ident_in_list();
        if (!cond) {
            cond = parse_expression();
        }
    
        ASTNode* then_block = NULL;
        ASTNode** else_ifs = NULL;
        int else_if_count = 0;
        ASTNode* else_block = NULL;
    
        // 判断是否使用花括号
        if (strcmp(peek()->value, "{") == 0) {
            // ---- 花括号模式 ----
            expect("{");
            then_block = parse_block();
            expect("}");
    
            while (true) {
                if (peek()->type == TOK_EOF) break;
                if (strcmp(peek()->value, "snfa") == 0) {
                    consume();
                    ASTNode* else_if_cond = parse_ident_in_list();
                    if (!else_if_cond) {
                        else_if_cond = parse_expression();
                    }
                    expect("{");
                    ASTNode* else_if_block = parse_block();
                    expect("}");
                    // 构造 else-if 节点
                    ASTNode* node = new_node(NODE_IF);
                    node->data.if_stmt.cond = else_if_cond;
                    node->data.if_stmt.then_block = else_if_block;
                    node->data.if_stmt.else_ifs = NULL;
                    node->data.if_stmt.else_if_count = 0;
                    node->data.if_stmt.else_block = NULL;
                    else_ifs = (ASTNode**)realloc(else_ifs, (else_if_count + 1) * sizeof(ASTNode*));
                    else_ifs[else_if_count++] = node;
                    continue;
                } else if (strcmp(peek()->value, "sonst") == 0) {
                    consume();
                    expect("{");
                    else_block = parse_block();
                    expect("}");
                    break;
                } else {
                    break;
                }
            }
        } else {
            // ---- 缩进模式 ----
            int base_indent = t->col - 1;   // 'fa' 的缩进
            then_block = parse_body_block(base_indent);
    
            while (true) {
                if (peek()->type == TOK_EOF) break;
                Token* next = peek();
                if ((strcmp(next->value, "snfa") == 0 || strcmp(next->value, "sonst") == 0) && (next->col - 1 == base_indent)) {
                    if (strcmp(next->value, "snfa") == 0) {
                        consume();  // 吃掉 snfa
                        ASTNode* else_if_cond = parse_ident_in_list();
                        if (!else_if_cond) {
                            else_if_cond = parse_expression();
                        }
                        int else_if_indent = next->col - 1;
                        ASTNode* else_if_block = parse_body_block(else_if_indent);
                        // 构造 else-if 节点
                        ASTNode* node = new_node(NODE_IF);
                        node->data.if_stmt.cond = else_if_cond;
                        node->data.if_stmt.then_block = else_if_block;
                        node->data.if_stmt.else_ifs = NULL;
                        node->data.if_stmt.else_if_count = 0;
                        node->data.if_stmt.else_block = NULL;
                        else_ifs = (ASTNode**)realloc(else_ifs, (else_if_count + 1) * sizeof(ASTNode*));
                        else_ifs[else_if_count++] = node;
                        continue;
                    } else { // sonst
                        consume();  // 吃掉 sonst
                        int else_indent = next->col - 1;
                        else_block = parse_body_block(else_indent);
                        break;
                    }
                } else {
                    break;
                }
            }
        }
    
        // 构造最终的 if 节点
        ASTNode* node = new_node(NODE_IF);
        node->data.if_stmt.cond = cond;
        node->data.if_stmt.then_block = then_block;
        node->data.if_stmt.else_ifs = else_ifs;
        node->data.if_stmt.else_if_count = else_if_count;
        node->data.if_stmt.else_block = else_block;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "tu") == 0) {
        consume();  // 消费 'tu'
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);

        if (strcmp(peek()->value, "indes") != 0) {
            g_last_error_line = peek()->line; g_last_error_col = peek()->col; std::string h = make_keyword_alias_hint("indes","indes"); kr_error_hint(h.c_str(), "期望 'indes'");
        }
        consume();  // 消费 'indes'

        ASTNode* cond = nullptr;
        if (strcmp(peek()->value, "(") == 0) {
            consume();   // 消费 '('
            cond = parse_condition();
            expect(")");
        } else {
            cond = parse_condition();   // 无括号形式（与 while 兼容）
        }

        CONSUME_OPTIONAL_SEMICOLON();

        ASTNode* node = new_node(NODE_DO_WHILE);
        node->data.do_while.body = body;
        node->data.do_while.cond = cond;
        return node;
    }
    else if (strcmp(t->value, "indes") == 0) {
        consume(); // 消费 'indes'
        ASTNode* cond = NULL;
        // 如果后面是 '('，则按带括号方式解析
        if (strcmp(peek()->value, "(") == 0) {
            consume(); // 消费 '('
            cond = parse_condition();
            expect(")");
        } else {
            // 否则直接解析条件表达式（无括号）
            cond = parse_condition();
        }
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);
        ASTNode* node = new_node(NODE_WHILE);
        node->data.while_stmt.cond = cond;
        node->data.while_stmt.body = body;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    if (strcmp(t->value, "für") == 0) {
        consume(); // 消费 'für'
    
        // ---- 1. 保留 für jedes（旧语法） ----
        if (strcmp(peek()->value, "jedes") == 0) {
            ASTNode* node = parse_foreach();
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        }
    
        // ---- 2. 无括号解析（变量名开头） ----
        if (peek()->type == TOK_IDENT) {
            int save_pos2 = tok_pos;
            Token* ident_tok = consume();
            char* var_name = strdup(ident_tok->value);
            char* second_var = NULL;
            bool multi = false;
    
            // ---------- 多变量检测 (k, v in ...) ----------
            if (strcmp(peek()->value, ",") == 0) {
                consume();
                Token* second_tok = consume();
                if (second_tok->type != TOK_IDENT) {
                    error_at(second_tok->line, second_tok->col, "期望第二个变量名");
                }
                second_var = strdup(second_tok->value);
                multi = true;
                if (strcmp(peek()->value, "in") != 0) {
                    error_at(peek()->line, peek()->col, "期望 'in'");
                }
            }
    
            if (multi) {
                // ---------- 多变量遍历：für k, v in collection ----------
                consume(); // 吃掉 'in'
                ASTNode* collection = parse_expression();
                int base_indent = t->col - 1;
                ASTNode* body = parse_body_block(base_indent);
                ASTNode* node = new_node(NODE_FOREACH);
                node->data.foreach.key_var = var_name;
                node->data.foreach.value_var = second_var;
                node->data.foreach.collection = collection;
                node->data.foreach.body = body;
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            } else {
                // ---------- 2a. 无括号传统 for：für var = init ; cond ; update ----------
                if ((strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) && peek()->type == TOK_OP) {
                    consume();
                    ASTNode* rhs = parse_expression();
                    ASTNode* init = new_node(NODE_ASSIGN);
                    init->data.assign.name = strdup(var_name);
                    init->data.assign.expr = rhs;
    
                    if (strcmp(peek()->value, ";") != 0) {
                        error_at(peek()->line, peek()->col, "语法错误: 期望 ';'");
                    }
                    consume(); // 消费第一个分号
    
                    ASTNode* cond = NULL;
                    if (strcmp(peek()->value, ";") != 0) {
                        cond = parse_expression();
                    }
                    expect(";");
    
                    ASTNode* update = NULL;
                    if (strcmp(peek()->value, "{") != 0) {
                        // 使用 parse_statement(0) 解析更新部分（支持 i++、i += size 等）
                        update = parse_statement(0);
                    }
                    int base_indent = t->col - 1;
                    ASTNode* body = parse_body_block(base_indent);
    
                    ASTNode* node = new_node(NODE_FOR);
                    node->data.for_stmt.init = init;
                    node->data.for_stmt.cond = cond;
                    node->data.for_stmt.update = update;
                    node->data.for_stmt.body = body;
                    free(var_name);
                    CONSUME_OPTIONAL_SEMICOLON();
                    return node;
                }
    
                // ---------- 2b. 无括号范围/集合遍历（in 或 von） ----------
                else if (strcmp(peek()->value, "in") == 0 || strcmp(peek()->value, "von") == 0) {
                    consume();
                    ASTNode* first_expr = parse_expression();
                
                    // ---- 如果 first_expr 是范围节点，转为传统 for 循环 ----
                    if (first_expr->type == NODE_RANGE) {
                        // 提取范围信息
                        ASTNode* start = first_expr->data.range.start;
                        ASTNode* end   = first_expr->data.range.end;
                        ASTNode* step  = first_expr->data.range.step;
                        // 将 first_expr 的子指针置空，避免 free_ast 重复释放
                        first_expr->data.range.start = nullptr;
                        first_expr->data.range.end   = nullptr;
                        first_expr->data.range.step  = nullptr;
                        free_ast(first_expr);
                
                        if (!step) {
                            step = new_node(NODE_NUMBER);
                            step->data.number_str = strdup("1");
                        }
                
                        // 构造 init: var_name = start
                        ASTNode* init = new_node(NODE_VAR_DECL);
                        init->data.var_decl.name = strdup(var_name);
                        init->data.var_decl.expr = start;
                        init->data.var_decl.is_const = false;
                
                        // 构造条件: var_name <= end
                        ASTNode* var_node = new_node(NODE_VARIABLE);
                        var_node->data.var_name = strdup(var_name);
                        ASTNode* cond = new_node(NODE_BINARY);
                        cond->data.binary.left = var_node;
                        cond->data.binary.right = end;
                        cond->data.binary.op = 'L';   // <=
                
                        // 构造更新: var_name = var_name + step
                        ASTNode* inc = new_node(NODE_BINARY);
                        inc->data.binary.left = new_node(NODE_VARIABLE);
                        inc->data.binary.left->data.var_name = strdup(var_name);
                        inc->data.binary.right = step;
                        inc->data.binary.op = '+';
                        ASTNode* update = new_node(NODE_ASSIGN);
                        update->data.assign.name = strdup(var_name);
                        update->data.assign.expr = inc;
                
                        // 循环体（缩进块）
                        int base_indent = g_stmt_start_col - 1;
                        ASTNode* body = parse_body_block(base_indent);
                
                        ASTNode* node = new_node(NODE_FOR);
                        node->data.for_stmt.init = init;
                        node->data.for_stmt.cond = cond;
                        node->data.for_stmt.update = update;
                        node->data.for_stmt.body = body;
                
                        free(var_name);
                        CONSUME_OPTIONAL_SEMICOLON();
                        return node;
                    }
                
                    if (strcmp(peek()->value, "bis") == 0) {
                        consume();
                        ASTNode* end_expr = parse_expression();
                        ASTNode* step_expr = NULL;
                        if (strcmp(peek()->value, "sch") == 0) {
                            consume();
                            step_expr = parse_expression();
                        }
                        // 构建 for 循环（与上面类似，但使用 first_expr 作为 start）
                        ASTNode* init = new_node(NODE_VAR_DECL);
                        init->data.var_decl.name = strdup(var_name);
                        init->data.var_decl.expr = first_expr;
                        init->data.var_decl.is_const = false;
                
                        ASTNode* var_node2 = new_node(NODE_VARIABLE);
                        var_node2->data.var_name = strdup(var_name);
                        ASTNode* cond2 = new_node(NODE_BINARY);
                        cond2->data.binary.left = var_node2;
                        cond2->data.binary.right = end_expr;
                        cond2->data.binary.op = 'L';
                
                        ASTNode* inc2 = new_node(NODE_BINARY);
                        inc2->data.binary.left = new_node(NODE_VARIABLE);
                        inc2->data.binary.left->data.var_name = strdup(var_name);
                        inc2->data.binary.right = step_expr;
                        inc2->data.binary.op = '+';
                
                        ASTNode* update2 = new_node(NODE_ASSIGN);
                        update2->data.assign.name = strdup(var_name);
                        update2->data.assign.expr = inc2;
                
                        int base_indent2 = g_stmt_start_col - 1;
                        ASTNode* body2 = parse_body_block(base_indent2);
                
                        ASTNode* node2 = new_node(NODE_FOR);
                        node2->data.for_stmt.init = init;
                        node2->data.for_stmt.cond = cond2;
                        node2->data.for_stmt.update = update2;
                        node2->data.for_stmt.body = body2;
                
                        free(var_name);
                        CONSUME_OPTIONAL_SEMICOLON();
                        return node2;
                    }
                
                    // ---- 否则：集合遍历（für jedes） ----
                    int base_indent = g_stmt_start_col - 1;
                    ASTNode* body = parse_body_block(base_indent);
                    ASTNode* node = new_node(NODE_FOREACH);
                    node->data.foreach.key_var = var_name;
                    node->data.foreach.value_var = NULL;
                    node->data.foreach.collection = first_expr;
                    node->data.foreach.body = body;
                
                    CONSUME_OPTIONAL_SEMICOLON();
                    return node;
                }
                else {
                    free(var_name);
                    tok_pos = save_pos2;
                }
            }
        }
    
        // ---- 3. 带括号解析（传统 for 和带括号的 in/von） ----
        int save_pos = tok_pos;
        if (strcmp(peek()->value, "(") == 0) {
            consume();
            if (peek()->type == TOK_IDENT) {
                Token* ident_tok = peek();
                consume();
                char* var_name = strdup(ident_tok->value);
                if (strcmp(peek()->value, "in") == 0 || strcmp(peek()->value, "von") == 0) {
                    bool is_in = (strcmp(peek()->value, "in") == 0);
                    consume();
                    ASTNode* first_expr = parse_expression();
    
                    if (strcmp(peek()->value, "bis") == 0) {
                        consume();
                        ASTNode* end_expr = parse_expression();
                        ASTNode* step_expr = NULL;
                        if (strcmp(peek()->value, "sch") == 0) {
                            consume();
                            step_expr = parse_expression();
                        }
                        expect(")");
                        int base_indent = t->col - 1;
                        ASTNode* body = parse_body_block(base_indent);
    
                        ASTNode* init = new_node(NODE_VAR_DECL);
                        init->data.var_decl.name = strdup(var_name);
                        init->data.var_decl.expr = first_expr;
                        init->data.var_decl.is_const = false;
    
                        ASTNode* var_node = new_node(NODE_VARIABLE);
                        var_node->data.var_name = strdup(var_name);
                        ASTNode* cond = new_node(NODE_BINARY);
                        cond->data.binary.left = var_node;
                        cond->data.binary.right = end_expr;
                        cond->data.binary.op = 'L';
    
                        ASTNode* inc = new_node(NODE_BINARY);
                        inc->data.binary.left = new_node(NODE_VARIABLE);
                        inc->data.binary.left->data.var_name = strdup(var_name);
                        inc->data.binary.right = step_expr;
                        inc->data.binary.op = '+';
    
                        ASTNode* update = new_node(NODE_ASSIGN);
                        update->data.assign.name = strdup(var_name);
                        update->data.assign.expr = inc;
    
                        ASTNode* node = new_node(NODE_FOR);
                        node->data.for_stmt.init = init;
                        node->data.for_stmt.cond = cond;
                        node->data.for_stmt.update = update;
                        node->data.for_stmt.body = body;
                        free(var_name);
                        CONSUME_OPTIONAL_SEMICOLON();
                        return node;
                    } else {
                        if (!is_in) {
                            g_last_error_line = peek()->line;
                            g_last_error_col  = peek()->col;
                            std::string hint = make_keyword_alias_hint("von", "bis");
                            kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                                          "语法错误: 'von' 需要配合 'bis' 使用");
                        }
                        expect(")");
                        int base_indent = t->col - 1;
                        ASTNode* body = parse_body_block(base_indent);
    
                        ASTNode* node = new_node(NODE_FOREACH);
                        node->data.foreach.key_var = var_name;
                        node->data.foreach.value_var = NULL;
                        node->data.foreach.collection = first_expr;
                        node->data.foreach.body = body;
                        CONSUME_OPTIONAL_SEMICOLON();
                        return node;
                    }
                } else {
                    free(var_name);
                    tok_pos = save_pos;
                }
            } else {
                tok_pos = save_pos;
            }
        } else {
            tok_pos = save_pos;
        }
    
        // ---- 4. 传统 for（必须带括号）: für (init; cond; update) ----
        expect("(");
        ASTNode* init = NULL;
        if (strcmp(peek()->value, ";") != 0) {
            init = parse_statement(0);
        }
        expect(";");
        ASTNode* cond = NULL;
        if (strcmp(peek()->value, ";") != 0) {
            cond = parse_expression();
        }
        expect(";");
        ASTNode* update = NULL;
        if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
            update = parse_statement(0);
        }
        expect(")");
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);
    
        ASTNode* node = new_node(NODE_FOR);
        node->data.for_stmt.init = init;
        node->data.for_stmt.cond = cond;
        node->data.for_stmt.update = update;
        node->data.for_stmt.body = body;
    
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "bruch") == 0) {
        consume();                                     // 消费 'bruch'
        ASTNode* node = new_node(NODE_BREAK);
        node->data.break_stmt.levels = 1;
        if (peek()->type == TOK_NUMBER) {
            long long n = atoll(peek()->value);
            if (n < 1)   error_at(peek()->line, peek()->col, "bruch 层级必须 ≥ 1");
            if (n > 10000) error_at(peek()->line, peek()->col, "bruch 层级过大（最大 10000）");
            node->data.break_stmt.levels = (int)n;
            consume();
        }
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "weiter") == 0) {
        consume();                                     // 消费 'weiter'
        ASTNode* node = new_node(NODE_CONTINUE);
        node->data.break_stmt.levels = 1;
        if (peek()->type == TOK_NUMBER) {
            long long n = atoll(peek()->value);
            if (n < 1)   error_at(peek()->line, peek()->col, "weiter 层级必须 ≥ 1");
            if (n > 10000) error_at(peek()->line, peek()->col, "weiter 层级过大（最大 10000）");
            node->data.break_stmt.levels = (int)n;
            consume();
        }
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }

    if (strcmp(t->value, "makro") == 0) {
        consume();
        Token* name_tok = consume();
        if (name_tok->type != TOK_IDENT)
            error_at(name_tok->line, name_tok->col, "期望宏名称");
        char* name = strdup(name_tok->value);   // 确保 name 变量被定义
        expect("(");
        std::vector<std::string> params;
        if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
            while (true) {
                Token* p = consume();
                if (p->type != TOK_IDENT)
                    error_at(p->line, p->col, "期望参数名");
                params.push_back(p->value);
                if (strcmp(peek()->value, ",") == 0) consume();
                else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) break;
                else error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
            }
        }
        expect(")");
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);
        macros[name] = {params, body};
        free(name);  // 释放，因为 key 是字符串
        return new_node(NODE_NULL);
    }

    // ---- 处理 * 和 # 前缀（全局作用域和记忆化） ----
    bool is_memoized = false;
    bool is_global_scope = false;
    while (strcmp(peek()->value, "**") == 0 || strcmp(peek()->value, "#") == 0 ||
       strcmp(peek()->value, "stati") == 0 || strcmp(peek()->value, "satz") == 0) {
        if (strcmp(peek()->value, "**") == 0) { consume(); is_global_scope = true; }
        else if (strcmp(peek()->value, "#") == 0) { consume(); is_memoized = true; }
        else if (strcmp(peek()->value, "stati") == 0) { consume(); is_static = true; }
        else if (strcmp(peek()->value, "satz") == 0) { consume(); is_stmt_func = true; }
    }
    t = peek();   // 更新 t 到当前 token（可能是 ac 或 fkt）

    // ---- ac fkt (异步函数) ----
    if (strcmp(t->value, "ac") == 0) {
        consume();  // 消费 'ac'
        if (strcmp(peek()->value, "fkt") != 0) {
            g_last_error_line = peek()->line;
            g_last_error_col  = peek()->col;
            std::string hint = make_keyword_alias_hint("fkt", "fkt");
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "语法错误: ac 后必须跟 fkt");
        }
        consume();  // 消费 'fkt'
        Token* name_tok = consume();
        TypeNode* ret_type = nullptr;
        if (name_tok->type != TOK_IDENT)
            error_at(name_tok->line, name_tok->col, "期望函数名");
        char* name = strdup(name_tok->value);

        expect("(");
        char** params = NULL;
        int param_count = 0;
        bool* param_is_const = NULL;
        ASTNode** param_defaults = NULL;
        TypeNode** param_types = NULL;
        char* vararg_name = NULL;
        TypeNode* vararg_type = nullptr;
        parse_param_list(&params, &param_count, &param_is_const, &param_defaults, &param_types, &vararg_name, &vararg_type);

        if (strcmp(peek()->value, ":") == 0) {
            consume();
            ret_type = parse_type_expr();
        }
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);

        ASTNode* node = new_node(NODE_ASYNC_FUNC_DEF, name_tok->line, name_tok->col);
        node->data.func_def.name = name;
        node->data.func_def.params = params;
        node->data.func_def.param_count = param_count;
        node->data.func_def.body = body;
        node->data.func_def.is_memoized = is_memoized;      // 使用解析出的值
        node->data.func_def.global_scope = is_global_scope; // 使用解析出的值
        node->data.func_def.is_static = is_static;
        node->data.func_def.return_type = ret_type;
        node->data.func_def.param_types = param_types;
        node->data.func_def.vararg_name = vararg_name;
        node->data.func_def.param_is_const = param_is_const;
        node->data.func_def.param_defaults = param_defaults;
        node->data.func_def.vararg_type = vararg_type;
        node->data.func_def.is_stmt_func = is_stmt_func;
        
        if (is_stmt_func && name) {
            g_stmt_func_names.insert(name);
        }

        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }

    // ---- fkt (普通函数) ----
    if (strcmp(t->value, "fkt") == 0) {
        consume();   // 消费 'fkt'
        Token* name_tok = consume();
        TypeNode* ret_type = nullptr;
        char* name = strdup(name_tok->value);

        expect("(");
        char** params = NULL;
        int param_count = 0;
        bool* param_is_const = NULL;
        ASTNode** param_defaults = NULL;
        TypeNode** param_types = NULL;
        char* vararg_name = NULL;
        TypeNode* vararg_type = nullptr;
        parse_param_list(&params, &param_count, &param_is_const, &param_defaults, &param_types, &vararg_name, &vararg_type);

        if (strcmp(peek()->value, ":") == 0) {
            consume();
            ret_type = parse_type_expr();
        }
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);

        ASTNode* node = new_node(NODE_FUNC_DEF, name_tok->line, name_tok->col);
        node->data.func_def.name = name;
        node->data.func_def.params = params;
        node->data.func_def.param_count = param_count;
        node->data.func_def.body = body;
        node->data.func_def.is_memoized = is_memoized;
        node->data.func_def.global_scope = is_global_scope;
        node->data.func_def.is_static = is_static;
        node->data.func_def.return_type = ret_type;
        node->data.func_def.vararg_name = vararg_name;
        node->data.func_def.param_is_const = param_is_const;
        node->data.func_def.param_defaults = param_defaults;
        node->data.func_def.param_types = param_types;
        node->data.func_def.vararg_type = vararg_type;
        node->data.func_def.is_stmt_func = is_stmt_func;
        
        if (is_stmt_func && name) {
            g_stmt_func_names.insert(name);
        }

        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    if (strcmp(t->value, "neu") == 0) {
        consume();
        if (strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) {
            g_last_error_line = peek()->line;
            g_last_error_col  = peek()->col;
            std::string hint = make_keyword_alias_hint("neu", "neu");
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "关键字 'neu' 不能被赋值");
        }
        Token* class_tok = consume();
        if (class_tok->type != TOK_IDENT)
        error_at(class_tok->line, class_tok->col, "期望类名");
        char* class_name = strdup(class_tok->value);
        expect("(");
        ASTNode** args = NULL;
        int arg_count = 0;
        if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
            while (true) {
                ASTNode* arg = parse_expression();
                args = (ASTNode**)realloc(args, (arg_count+1)*sizeof(ASTNode*));
                args[arg_count++] = arg;
                if (strcmp(peek()->value, ",") == 0) consume();
                else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) break;
                else error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
            }
        }
        expect(")");
        ASTNode* node = new_node(NODE_NEW);
        node->data.new_expr.class_name = class_name;
        node->data.new_expr.args = args;
        node->data.new_expr.arg_count = arg_count;
        return node;
    }
    if (strcmp(t->value, "ober") == 0) {
        consume();
        expect("(");
        ASTNode** args = NULL;
        int arg_count = 0;
        if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
            while (true) {
                ASTNode* arg = parse_expression();
                args = (ASTNode**)realloc(args, (arg_count+1)*sizeof(ASTNode*));
                args[arg_count++] = arg;
                if (strcmp(peek()->value, ",") == 0) consume();
                else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) break;
                else error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
            }
        }
        expect(")");
        ASTNode* node = new_node(NODE_SUPER_CALL);
        node->data.super_call.args = args;
        node->data.super_call.arg_count = arg_count;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "kernregel") == 0) {
        consume(); // 消费 'kernregel'
        Token* name_tok = consume();
        TypeNode* ret_type = nullptr;
        if (name_tok->type != TOK_IDENT)
            error_at(name_tok->line, name_tok->col, "期望函数名");
        char* name = strdup(name_tok->value);
        
        expect("(");
        char** params = NULL;
        int param_count = 0;
        bool* param_is_const = NULL;
        ASTNode** param_defaults = NULL;
        TypeNode** param_types = NULL;
        char* vararg_name = NULL;
        TypeNode* vararg_type = nullptr;
        parse_param_list(&params, &param_count, &param_is_const, &param_defaults, &param_types, &vararg_name, &vararg_type);

        // 可选返回类型注解
        if (strcmp(peek()->value, ":") == 0) {
            consume();
            ret_type = parse_type_expr();
        }
        int base_indent = t->col - 1;
        ASTNode* body = parse_body_block(base_indent);
    
        ASTNode* node = new_node(NODE_RULE_DEF, name_tok->line, name_tok->col);
        node->data.func_def.name = name;
        node->data.func_def.params = params;
        node->data.func_def.param_count = param_count;
        node->data.func_def.body = body;
        node->data.func_def.is_memoized = false;   // 规则默认不记忆化
        node->data.func_def.global_scope = false;  // 默认局部作用域
        node->data.func_def.is_static = is_static;
        node->data.func_def.return_type = ret_type;
        node->data.func_def.param_types = param_types;
        node->data.func_def.vararg_name = vararg_name;
        node->data.func_def.param_is_const = param_is_const;
        node->data.func_def.param_defaults = param_defaults;
        node->data.func_def.vararg_type = vararg_type;
        node->data.func_def.is_stmt_func = is_stmt_func;

        // 规则不是异步函数，不设置 is_async（但字段不存在于 func_def 中，忽略）
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "faul") == 0) {
        consume();   // 消费 'faul'
        Token* name_tok = consume();
        char* name = strdup(name_tok->value);
        if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0)
            consume();
        else {
            g_last_error_line = peek()->line;
            g_last_error_col  = peek()->col;
            std::string hint = make_keyword_alias_hint("ist", "ist");
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                            "语法错误: 期望 'ist' 或 '='");
        }
        ASTNode* expr = parse_expression();
        ASTNode* node = new_node(NODE_LAZY_VAR_DECL);
        node->data.lazy_var_decl.name = name;
        node->data.lazy_var_decl.expr = expr;
        node->data.lazy_var_decl.global = false;
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "aufz") == 0) {
        ASTNode* node = parse_enum_definition();
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    else if (strcmp(t->value, "gib") == 0) {
        consume();  // 消费 'gib'
        ASTNode* expr = nullptr;
        bool has_expr = false;
    
        // 检测括号形式：gib( ... )
        if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, "(") == 0) {
            consume();  // 消费 '('
            // 检查是否空括号
            if (peek()->type == TOK_SYMBOL && peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                expect(")");        // 空括号，无表达式
                has_expr = false;
            } else {
                expr = parse_expression();  // 解析括号内的表达式
                expect(")");               // 消费 ')'
                has_expr = true;
            }
        } else {
            // 判断是否有表达式（无括号形式）
            Token* next = peek();
            if (next->type != TOK_EOF && strcmp(next->value, ";") != 0 && strcmp(next->value, "}") != 0) {
                if (next->line == t->line) {
                    has_expr = true;
                } else if (next->col > g_stmt_start_col) {
                    has_expr = true;
                }
            }
            if (has_expr) {
                expr = parse_expression();
            }
        }
    
        ASTNode* node = new_node(NODE_RETURN);
        node->data.ret.expr = expr;
        CONSUME_OPTIONAL_SEMICOLON();   // 吃掉可选的分号
        return node;
    }
    // 解构赋值：{ var1, var2, ... } = expr
    else if (strcmp(peek()->value, "{") == 0) {
        int save_pos = tok_pos;
        consume();
        std::vector<char*> names;
        char* rest_name = nullptr;
        bool valid = true;
        bool has_rest = false;
    
        while (strcmp(peek()->value, "}") != 0) {
            // 检查是否为 rest 运算符
            if (strcmp(peek()->value, "...") == 0 && peek()->type == TOK_OP) {
                if (has_rest) { valid = false; break; }   // 只能有一个 rest
                consume(); // 消费 '...'
                Token* rest_tok = consume();
                if (rest_tok->type != TOK_IDENT) { valid = false; break; }
                rest_name = strdup(rest_tok->value);
                has_rest = true;
                // rest 必须是最后一个元素，后面不能跟逗号或更多元素
                if (strcmp(peek()->value, ",") == 0) { valid = false; break; }
                // 跳出循环，等待 '}'
                break;
            } else {
                // 普通标识符
                if (peek()->type != TOK_IDENT) { valid = false; break; }
                names.push_back(strdup(peek()->value));
                consume();
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                    continue;
                } else if (strcmp(peek()->value, "}") == 0) {
                    break;
                } else {
                    valid = false;
                    break;
                }
            }
        }
    
        if (valid) {
            consume(); // 消费 '}'
            if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                consume();
                ASTNode* rhs = parse_expression();
                ASTNode* node = new_node(NODE_DESTRUCTURE_ASSIGN);
                node->data.destructure.count = names.size();
                node->data.destructure.names = (char**)malloc(names.size() * sizeof(char*));
                for (size_t i = 0; i < names.size(); i++)
                    node->data.destructure.names[i] = names[i];
                node->data.destructure.expr = rhs;
                node->data.destructure.rest_name = rest_name;   // 可能为 nullptr
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
        }
    
        // 回退
        for (char* n : names) free(n);
        free(rest_name);
        tok_pos = save_pos;
    }
    if (peek()->type == TOK_IDENT) {
        int save_pos = tok_pos;
        Token* name_tok = peek();
        consume(); // 标识符
        if (strcmp(peek()->value, ":") == 0) {
            consume(); // ':'
            TypeNode* type_anno = parse_type_expr();
            ASTNode* expr = nullptr;
            if (strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) {
                consume(); // '=' 或 'ist'
                expr = parse_expression();
            } else {
                expr = make_default_value_for_type(type_anno);
            }
            ASTNode* node = new_node(NODE_VAR_DECL);
            node->data.var_decl.name = strdup(name_tok->value);
            node->data.var_decl.expr = expr;
            node->data.var_decl.is_const = false;
            node->data.var_decl.type_annotation = type_anno;
            node->data.var_decl.global = false;
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        } else {
            tok_pos = save_pos;
        }
    }    
    // ---- 孤立块作用域（仅当 allow_semicolon 为真时有效） ----
    if (strcmp(peek()->value, "{") == 0 && allow_semicolon) {
        consume(); // 消费 '{'
        ASTNode* block = parse_block();
        expect("}");
        ASTNode* node = new_node(NODE_SCOPE_BLOCK);
        node->data.block.stmts = block->data.block.stmts;
        node->data.block.count = block->data.block.count;
        free(block);
        CONSUME_OPTIONAL_SEMICOLON();
        return node;
    }
    // ---- 所有其他情况：表达式（可能带赋值） ----
    else {
        // ---- 尝试多变量赋值 ----
        int save_pos = tok_pos;
        std::vector<char*> left_names;
        bool multi_valid = true;
        while (true) {
            if (peek()->type != TOK_IDENT) {
                multi_valid = false;
                break;
            }
            left_names.push_back(strdup(peek()->value));
            consume();
            if (strcmp(peek()->value, ",") == 0) {
                consume();
                continue;
            } else if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
                consume(); // 消费 'ist' 或 '='
                break;
            } else {
                multi_valid = false;
                break;
            }
        }
        if (multi_valid && left_names.size() >= 2) {
            // 已经是多变量，消费赋值符号（已消费）
            // 解析右侧表达式列表
            ASTNode** right_exprs = NULL;
            int right_count = 0;
            while (true) {
                ASTNode* expr = parse_expression();
                right_exprs = (ASTNode**)realloc(right_exprs, (right_count + 1) * sizeof(ASTNode*));
                right_exprs[right_count++] = expr;
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                    continue;
                } else {
                    break;
                }
            }
            ASTNode* node = new_node(NODE_MULTI_ASSIGN);
            node->data.multi_assign.left_count = (int)left_names.size();
            node->data.multi_assign.left_names = (char**)malloc(node->data.multi_assign.left_count * sizeof(char*));
            for (size_t i = 0; i < left_names.size(); i++)
                node->data.multi_assign.left_names[i] = left_names[i]; // 转移所有权
            node->data.multi_assign.right_count = right_count;
            node->data.multi_assign.right_exprs = right_exprs;
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        } else {
            // 回退
            tok_pos = save_pos;
            for (char* name : left_names) free(name);
        }

        // ---- 解析单个表达式 ----
        ASTNode* expr = parse_expression();

        // 交换赋值
        if (strcmp(peek()->value, "<->") == 0 && peek()->type == TOK_OP) {
            consume();
            ASTNode* right = parse_expression();
            ASTNode* node = new_node(NODE_SWAP_ASSIGN);
            node->data.swap.left = expr;
            node->data.swap.right = right;
            CONSUME_OPTIONAL_SEMICOLON();
            return node;
        }

        // 检查普通赋值（ist 或 =）
        if (strcmp(peek()->value, "ist") == 0 || strcmp(peek()->value, "=") == 0) {
            consume();
            ASTNode* rhs = parse_expression();

            if (expr->type == NODE_VARIABLE) {
                ASTNode* node = new_node(NODE_ASSIGN);
                node->data.assign.name = strdup(expr->data.var_name);
                node->data.assign.expr = rhs;
                free_ast(expr);
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            else if (expr->type == NODE_ARRAY_ACCESS) {
                // 允许任意左值
                ASTNode* node = new_node(NODE_ARRAY_ASSIGN);
                node->data.array_assign.left = expr;                // 整个左值
                node->data.array_assign.index = expr->data.array_access.index;
                node->data.array_assign.expr = rhs;
                expr->data.array_access.index = NULL;               // 防止二次释放
                // 不释放 expr，因为 left 已接管
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            else if (expr->type == NODE_OBJECT_ACCESS) {
                ASTNode* node = new_node(NODE_OBJECT_ASSIGN);
                node->data.object_assign.obj = expr->data.object_access.obj;
                node->data.object_assign.key = expr->data.object_access.key;
                node->data.object_assign.value = rhs;
                expr->data.object_access.obj = NULL;
                expr->data.object_access.key = NULL;
                free_ast(expr);
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            else {
                error_at(peek()->line, peek()->col, "赋值左侧必须是变量、数组元素或对象属性");
            }
        }

        // 检查复合赋值（+=, -=, *=, /=, %=）
        if (is_compound_assign(peek()->value) && peek()->type == TOK_OP) {
            char* op = strdup(consume()->value);
            ASTNode* rhs = parse_expression();
            char bin_op = compound_op_to_binary(op);
            free(op);

            if (expr->type == NODE_VARIABLE) {
                ASTNode* var_node = new_node(NODE_VARIABLE);
                var_node->data.var_name = strdup(expr->data.var_name);
                ASTNode* binary = new_node(NODE_BINARY);
                binary->data.binary.left = var_node;
                binary->data.binary.right = rhs;
                binary->data.binary.op = bin_op;
                ASTNode* node = new_node(NODE_ASSIGN);
                node->data.assign.name = strdup(expr->data.var_name);
                node->data.assign.expr = binary;
                free_ast(expr);
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            else if (expr->type == NODE_ARRAY_ACCESS) {
                // 允许任意左值
                ASTNode* node = new_node(NODE_ARRAY_COMPOUND_ASSIGN);
                node->data.array_compound_assign.left = expr;
                node->data.array_compound_assign.index = expr->data.array_access.index;
                node->data.array_compound_assign.op = bin_op;
                node->data.array_compound_assign.rhs = rhs;
                expr->data.array_access.index = NULL;
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            else if (expr->type == NODE_OBJECT_ACCESS) {
                ASTNode* node = new_node(NODE_OBJECT_COMPOUND_ASSIGN);
                node->data.object_compound_assign.obj = expr->data.object_access.obj;
                node->data.object_compound_assign.key = expr->data.object_access.key;
                node->data.object_compound_assign.op  = bin_op;
                node->data.object_compound_assign.rhs = rhs;
                expr->data.object_access.obj = NULL;
                expr->data.object_access.key = NULL;
                free_ast(expr);
                CONSUME_OPTIONAL_SEMICOLON();
                return node;
            }
            else {
                error_at(peek()->line, peek()->col, "复合赋值左侧必须为变量或数组元素");
            }
        }

        // 否则作为表达式语句
        ASTNode* stmt = new_node(NODE_EXPR_STMT);
        stmt->data.expr_stmt.expr = expr;
        CONSUME_OPTIONAL_SEMICOLON();
        return stmt;
    }

    return nullptr;
 }
 
 ASTNode* parse_block() {
     ASTNode* block = new_node(NODE_BLOCK);
     block->data.block.stmts = NULL;
     block->data.block.count = 0;
     while (strcmp(peek()->value, "}") != 0 && peek()->type != TOK_EOF) {
         ASTNode* stmt = parse_statement(1);
         block->data.block.stmts = (ASTNode**)realloc(block->data.block.stmts,
                                           (block->data.block.count+1)*sizeof(ASTNode*));
         block->data.block.stmts[block->data.block.count++] = stmt;
     }
     return block;
 }

// 根据缩进或花括号解析代码块
ASTNode* parse_body_block(int base_indent) {
    bool has_dann = false;
    if (strcmp(peek()->value, "dann") == 0 && peek()->type == TOK_KEYWORD) {
        consume(); // 消费 "dann"
        has_dann = true;
    }

    // 辅助 lambda：判断位置 pos 处的 '{' 后面是否跟随“键: 值”模式（对象字面量）
    auto looks_like_object_literal = [&](int pos) -> bool {
        int lookahead = pos + 1;   // 跳过 '{'
        if (lookahead >= token_count) return false;
        Token* k = &tokens[lookahead];
        // 空对象 {}
        if (k->type == TOK_SYMBOL && strcmp(k->value, "}") == 0) return true;
        // 键必须是标识符/字符串/数字/关键字
        if (k->type != TOK_IDENT && k->type != TOK_REGEX &&
            k->type != TOK_STRING && k->type != TOK_KEYWORD &&
            k->type != TOK_NUMBER) return false;
        // 键后面必须是 ':'
        if (lookahead + 1 >= token_count) return false;
        return strcmp(tokens[lookahead + 1].value, ":") == 0;
    };

    // ---- 花括号形式 ----
    if (strcmp(peek()->value, "{") == 0) {
        // 若使用了 dann 且看起来是对象字面量，则作为表达式解析
        if (has_dann && looks_like_object_literal(tok_pos)) {
            ASTNode* expr = parse_expression();   // parse_primary 会构造 NODE_OBJECT_LITERAL
            ASTNode* stmt = new_node(NODE_EXPR_STMT);
            stmt->data.expr_stmt.expr = expr;
            ASTNode* block = new_node(NODE_BLOCK);
            block->data.block.stmts = (ASTNode**)malloc(sizeof(ASTNode*));
            block->data.block.stmts[0] = stmt;
            block->data.block.count = 1;
            return block;
        }
        // 否则按原逻辑当作代码块
        consume();
        ASTNode* block = parse_block();
        expect("}");
        return block;
    }

    // ---- 缩进模式：收集所有缩进大于 base_indent 的语句 ----
    ASTNode* block = new_node(NODE_BLOCK);
    block->data.block.stmts = NULL;
    block->data.block.count = 0;

    while (true) {
        Token* tok = peek();
        if (tok->type == TOK_EOF) break;

        int cur_indent = tok->col - 1;   // 当前 token 的缩进级别
        if (cur_indent <= base_indent) break;

        // 缩进块中，若 has_dann 且遇到对象字面量，作为单条表达式语句解析
        if (has_dann && tok->type == TOK_SYMBOL && strcmp(tok->value, "{") == 0 &&
            looks_like_object_literal(tok_pos)) {
            ASTNode* expr = parse_expression();
            ASTNode* stmt = new_node(NODE_EXPR_STMT);
            stmt->data.expr_stmt.expr = expr;
            block->data.block.stmts = (ASTNode**)realloc(
                block->data.block.stmts,
                (block->data.block.count + 1) * sizeof(ASTNode*)
            );
            block->data.block.stmts[block->data.block.count++] = stmt;
            continue;
        }

        // 普通语句
        ASTNode* stmt = parse_statement(1);
        block->data.block.stmts = (ASTNode**)realloc(
            block->data.block.stmts,
            (block->data.block.count + 1) * sizeof(ASTNode*)
        );
        block->data.block.stmts[block->data.block.count++] = stmt;
    }
    return block;
}

 ASTNode* parse_list_comprehension() {
    expect("[");
    ASTNode* expr = parse_expression();          // 生成表达式
    expect("für");
    Token* var_tok = consume();                  // 变量名
    char* var_name = strdup(var_tok->value);
    expect("in");

    // ---------- 范围解析（兼容两种 token 形式） ----------
    ASTNode* left = parse_expression();          // 解析左边界
    ASTNode* collection = NULL;

    // 情况1：单 token ".."（标准情况）
    if (strcmp(peek()->value, "..") == 0 && peek()->type == TOK_OP) {
        consume();                               // 消费 '..'
        ASTNode* right = parse_expression();     // 右边界
        collection = new_node(NODE_RANGE);
        collection->data.range.start = left;
        collection->data.range.end = right;
    }
    // 情况2：两个独立的 '.' 符号（若词法分析出错）
    else if (strcmp(peek()->value, ".") == 0 && tok_pos + 1 < token_count &&
             strcmp(tokens[tok_pos + 1].value, ".") == 0 && peek()->type == TOK_SYMBOL) {
        consume();  // 消费第一个 '.'
        consume();  // 消费第二个 '.'
        ASTNode* right = parse_expression();
        collection = new_node(NODE_RANGE);
        collection->data.range.start = left;
        collection->data.range.end = right;
    }
    // 否则，将 left 作为普通集合（不是范围）
    else {
        collection = left;
    }

    // ---------- 条件过滤 ----------
    ASTNode* cond = NULL;
    if (strcmp(peek()->value, "fa") == 0) {
        consume();
        cond = parse_expression();
    }
    expect("]");

    ASTNode* node = new_node(NODE_LIST_COMPREHENSION);
    node->data.list_comp.expr = expr;
    node->data.list_comp.var_name = var_name;
    node->data.list_comp.collection = collection;
    node->data.list_comp.cond = cond;
    return node;
 }

 ASTNode* parse_object_literal() {
    // 假定调用前已经消费了 '{'
    int start_pos = tok_pos;
    ASTNode** key_exprs = NULL;
    ASTNode** vals = NULL;
    ASTNode** spreads = NULL;
    int count = 0, spread_count = 0;
    bool valid_object = true;

    while (true) {
        // ---- 1. 检测展开运算符 ----
        if (peek()->type == TOK_OP && strcmp(peek()->value, "...") == 0) {
            consume();
            ASTNode* spread_expr = parse_expression();
            spreads = (ASTNode**)realloc(spreads, (spread_count + 1) * sizeof(ASTNode*));
            spreads[spread_count++] = spread_expr;
            // 展开后可能紧跟逗号或 '}'，由下面的分隔符处理统一控制
        }
        // ---- 2. 解析键值对 ----
        else {
            Token* key_tok = peek();
            // 键可以是标识符、字符串、数字、关键字
            if (key_tok->type != TOK_IDENT && key_tok->type != TOK_REGEX &&
                key_tok->type != TOK_STRING && key_tok->type != TOK_KEYWORD &&
                key_tok->type != TOK_NUMBER) {
                valid_object = false;
                break;
            }

            ASTNode* key_node = nullptr;
            // 处理不同类型的键
            if (key_tok->type == TOK_IDENT) {
                key_node = new_node(NODE_VARIABLE, key_tok->line, key_tok->col);
                key_node->data.var_name = strdup(key_tok->value);
            } else if (key_tok->type == TOK_NUMBER) {
                key_node = new_node(NODE_STRING, key_tok->line, key_tok->col);
                key_node->data.string = strdup(key_tok->value);
                key_node->string_len = strlen(key_tok->value);
            } else {
                // TOK_REGEX 或 TOK_STRING 或 TOK_KEYWORD
                char* key_str = nullptr;
                if (key_tok->type == TOK_REGEX) {
                    if (key_tok->flags && strcmp(key_tok->flags, "raw") == 0)
                        key_str = strdup(key_tok->value);
                    else
                        key_str = unescape_string(key_tok->value);
                } else {
                    key_str = strdup(key_tok->value);
                }
                key_node = new_node(NODE_STRING, key_tok->line, key_tok->col);
                key_node->data.string = key_str;
                key_node->string_len = strlen(key_str);
            }
            consume(); // 消费键 token

            // 必须有冒号
            if (strcmp(peek()->value, ":") != 0) {
                free_ast(key_node);
                valid_object = false;
                break;
            }
            consume(); // 消费 ':'

            // 解析值表达式
            ASTNode* val_expr = parse_expression();

            // 存入临时数组
            key_exprs = (ASTNode**)realloc(key_exprs, (count + 1) * sizeof(ASTNode*));
            vals = (ASTNode**)realloc(vals, (count + 1) * sizeof(ASTNode*));
            key_exprs[count] = key_node;
            vals[count] = val_expr;
            count++;

            if (count == 1 && spread_count == 0 &&
                strcmp(peek()->value, "für") == 0 && peek()->type == TOK_KEYWORD) {
                // 这是对象推导式，回退到 start_pos 并返回 nullptr
                tok_pos = start_pos;
                // 释放已分配的键和值
                for (int i = 0; i < count; i++) {
                    free_ast(key_exprs[i]);
                    free_ast(vals[i]);
                }
                free(key_exprs);
                free(vals);
                // 理论上此时 spread_count 应为 0，但为保险：
                for (int i = 0; i < spread_count; i++) free_ast(spreads[i]);
                free(spreads);
                return nullptr;
            }
        }

        // ---- 3. 处理分隔符（逗号 或 结束大括号） ----
        if (strcmp(peek()->value, ",") == 0) {
            consume();
            if (strcmp(peek()->value, "}") == 0) {
                // 允许尾随逗号，直接跳出循环
                break;
            }
            continue; // 继续解析下一个键值对或展开
        } else if (strcmp(peek()->value, "}") == 0) {
            break; // 对象结束
        } else {
            // 遇到意外的 token，标记无效并退出
            valid_object = false;
            break;
        }
    }

    // ---- 4. 校验并消费结束 '}' ----
    if (!valid_object || strcmp(peek()->value, "}") != 0) {
        error_at(peek()->line, peek()->col, "无效的对象字面量（期望 '}' 或逗号）");
    }
    consume(); // 消费 '}'

    // ---- 5. 构造 AST 节点 ----
    ASTNode* node = new_node(NODE_OBJECT_LITERAL);
    node->data.object_lit.key_exprs = key_exprs;
    node->data.object_lit.vals = vals;
    node->data.object_lit.count = count;
    node->data.object_lit.spreads = spreads;
    node->data.object_lit.spread_count = spread_count;
    return node;
}

ASTNode* parse_object_comprehension() {
    // 假定 '{' 已被消费
    ASTNode* key = parse_expression();
    expect(":");
    ASTNode* value = parse_expression();
    expect("für");
    Token* var_tok = consume();
    if (var_tok->type != TOK_IDENT)
        error_at(var_tok->line, var_tok->col, "期望标识符作为循环变量");
    char* var_name = strdup(var_tok->value);
    char* value_var = nullptr;

    // ---- 检测双变量模式 ----
    if (strcmp(peek()->value, ",") == 0) {
        consume(); // 消费 ','
        Token* second_tok = consume();
        if (second_tok->type != TOK_IDENT)
            error_at(second_tok->line, second_tok->col, "期望标识符作为值变量");
        value_var = strdup(second_tok->value);
    }

    expect("in");
    ASTNode* collection = parse_expression();
    ASTNode* cond = nullptr;
    if (strcmp(peek()->value, "fa") == 0) {
        consume();
        cond = parse_expression();
    }
    expect("}");

    ASTNode* node = new_node(NODE_OBJECT_COMPREHENSION);
    node->data.object_comp.key_expr = key;
    node->data.object_comp.value_expr = value;
    node->data.object_comp.var_name = var_name;
    node->data.object_comp.value_var = value_var;
    node->data.object_comp.collection = collection;
    node->data.object_comp.cond = cond;
    return node;
}
 
 /* 解析逻辑表达式 (支持 &&, ||, !, 比较) */
 ASTNode* parse_condition() {
    ++g_in_expr_depth;
    ASTNode* result = parse_logical_or();
    --g_in_expr_depth;
    return result;
 }
 
 ASTNode* parse_logical_or() {
     ASTNode* left = parse_logical_and();
     while (strcmp(peek()->value, "||") == 0 && peek()->type == TOK_OP) {
         consume();
         ASTNode* right = parse_logical_and();
         ASTNode* node = new_node(NODE_LOGICAL_OR);
         node->data.logical_or.left = left;
         node->data.logical_or.right = right;
         left = node;
     }
     return left;
 }
 
 ASTNode* parse_logical_and() {
     ASTNode* left = parse_unary();
     while (strcmp(peek()->value, "&&") == 0 && peek()->type == TOK_OP) {
         consume();
         ASTNode* right = parse_unary();
         ASTNode* node = new_node(NODE_LOGICAL_AND);
         node->data.logical_and.left = left;
         node->data.logical_and.right = right;
         left = node;
     }
     return left;
 }
 
 ASTNode* parse_unary() {
     // 前置 ++ / --
     if (strcmp(peek()->value, "++") == 0 && peek()->type == TOK_OP) {
         consume();
         ASTNode* operand = parse_term();
         ASTNode* node = new_node(NODE_PRE_INC);
         node->data.inc_dec.operand = operand;
         return node;
     }
     if (strcmp(peek()->value, "--") == 0 && peek()->type == TOK_OP) {
         consume();
         ASTNode* operand = parse_term();
         ASTNode* node = new_node(NODE_PRE_DEC);
         node->data.inc_dec.operand = operand;
         return node;
     }
     // 逻辑非
     if ((strcmp(peek()->value, "NICH") == 0 || strcmp(peek()->value, "nich") == 0) && peek()->type == TOK_KEYWORD) {
        consume();
        ASTNode* expr = parse_unary();
        ASTNode* node = new_node(NODE_NOT);
        node->data.not_expr.expr = expr;
        return node;
     }
     if (strcmp(peek()->value, "~") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* operand = parse_unary();
        ASTNode* node = new_node(NODE_BITWISE_NOT);
        node->data.inc_dec.operand = operand;   // 复用 inc_dec 结构存储操作数
        return node;
     }
     if (strcmp(peek()->value, "!") == 0 && peek()->type == TOK_OP) {
         consume();
         ASTNode* expr = parse_unary();
         ASTNode* node = new_node(NODE_NOT);
         node->data.not_expr.expr = expr;
         return node;
     }
     // 一元加（忽略）和一元负（转换成 0 - operand）
     if (strcmp(peek()->value, "+") == 0 && peek()->type == TOK_OP) {
         consume();
         return parse_unary();
     }
     if (strcmp(peek()->value, "-") == 0 && peek()->type == TOK_OP) {
         consume();
         ASTNode* operand = parse_unary();
         ASTNode* node = new_node(NODE_BINARY);
         node->data.binary.left = new_node(NODE_NUMBER);
         node->data.binary.left->data.number_str = strdup("0");
         node->data.binary.right = operand;
         node->data.binary.op = '-';
         return node;
     }
     return parse_comparison();
 }
 
 ASTNode* parse_comparison() {
    ASTNode* left = parse_range();
    Token* op = peek();

    // 处理 'in' 运算符（它是关键字，不是 TOK_OP，但保留此逻辑）
    if (strcmp(op->value, "in") == 0 && op->type == TOK_KEYWORD) {
        consume();  // 消费 'in'
        // 尝试无括号列表
        int saved = tok_pos;
        std::vector<ASTNode*> elems;
        // 检查是否以 '(' 开头
        if (strcmp(peek()->value, "(") == 0) {
            consume();
            if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                while (true) {
                    ASTNode* elem = parse_expression();
                    elems.push_back(elem);
                    if (strcmp(peek()->value, ",") == 0) {
                        consume();
                        continue;
                    } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                        break;
                    } else {
                        error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                    }
                }
            }
            expect(")");
        } else {
            // 无括号：读取逗号分隔的表达式（直到遇到低优先级运算符或语句结束）
            while (true) {
                ASTNode* elem = parse_expression();
                elems.push_back(elem);
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                    continue;
                } else {
                    // 停止条件：遇到运算符优先级低于 'in' 的符号，或换行/分号等
                    if (peek()->type == TOK_OP || peek()->type == TOK_SYMBOL) {
                        const char* v = peek()->value;
                        if (strcmp(v, ",") != 0 && strcmp(v, ")") != 0 && strcmp(v, "]") != 0 &&
                            strcmp(v, "}") != 0 && strcmp(v, ";") != 0) {
                            if (strcmp(v, ")") == 0 || strcmp(v, "]") == 0 ||
                                strcmp(v, "}") == 0 || peek()->type == TOK_EOF) {
                                break;
                            }
                            if (strcmp(v, "+") == 0 || strcmp(v, "-") == 0 ||
                                strcmp(v, "*") == 0 || strcmp(v, "/") == 0 ||
                                strcmp(v, "==") == 0 || strcmp(v, "!=") == 0 ||
                                strcmp(v, "<") == 0 || strcmp(v, ">") == 0 ||
                                strcmp(v, "<=") == 0 || strcmp(v, ">=") == 0 ||
                                strcmp(v, "&&") == 0 || strcmp(v, "||") == 0) {
                                // 回退到没有列表的情况，交给上层处理
                                tok_pos = saved;
                                elems.clear();
                                break;
                            }
                        }
                    }
                    // 否则认为列表结束
                    break;
                }
            }
        }
    
        // 如果 elems 为空，说明没有成功解析列表，回退并报错
        if (elems.empty()) {
            tok_pos = saved;
            error_at(peek()->line, peek()->col, "期望 '(' 或逗号分隔的表达式列表");
        }
    
        // 构建 OR 节点
        ASTNode* result = nullptr;
        for (size_t i = 0; i < elems.size(); ++i) {
            ASTNode* cmp = new_node(NODE_BINARY);
            cmp->data.binary.left = copy_ast(left);
            cmp->data.binary.right = elems[i];
            cmp->data.binary.op = 'E'; // ==
            if (result == nullptr) {
                result = cmp;
            } else {
                ASTNode* or_node = new_node(NODE_LOGICAL_OR);
                or_node->data.logical_or.left = result;
                or_node->data.logical_or.right = cmp;
                result = or_node;
            }
        }
        return result;
    }

    // 只有 TOK_OP 类型的 token 才能被视为比较运算符
    if (op->type == TOK_OP &&
        (strcmp(op->value, ">") == 0 || strcmp(op->value, "<") == 0 ||
         strcmp(op->value, "==") == 0 || strcmp(op->value, "!=") == 0 ||
         strcmp(op->value, ">=") == 0 || strcmp(op->value, "<=") == 0 ||
         strcmp(op->value, "<=>") == 0)) {
        consume();
        ASTNode* right = parse_range();
        ASTNode* node = new_node(NODE_BINARY);
        node->data.binary.left = left;
        node->data.binary.right = right;
        char opc = op->value[0];
        if (strcmp(op->value, ">=") == 0) opc = 'G';
        else if (strcmp(op->value, "<=") == 0) opc = 'L';
        else if (strcmp(op->value, "==") == 0) opc = 'E';
        else if (strcmp(op->value, "!=") == 0) opc = 'N';
        else if (strcmp(op->value, "<=>") == 0) opc = 'C';
        node->data.binary.op = opc;
        return node;
    }
    return left;
 }
 
 /* 表达式解析 —— 处理加减 */
 ASTNode* parse_expression() {
    ++g_in_expr_depth;
    ASTNode* result = parse_pipe();

    // 检测赋值运算符（仅当左操作数是变量时）
    if ((peek()->type == TOK_OP && strcmp(peek()->value, "=") == 0) ||
        (peek()->type == TOK_KEYWORD && strcmp(peek()->value, "ist") == 0)) {
        if (result->type == NODE_VARIABLE) {
            consume(); // 消费 '=' 或 'ist'
            ASTNode* right = parse_expression(); // 右递归，支持右结合
            ASTNode* node = new_node(NODE_ASSIGN);
            node->data.assign.name = strdup(result->data.var_name);
            node->data.assign.expr = right;
            free_ast(result); // 释放原变量节点（名称已复制）
            result = node;    // 更新返回值为赋值表达式节点
        }
        // 若左操作数不是变量，则不消耗 token，交给语句处理
    }

    --g_in_expr_depth;
    return result;
}

ASTNode* parse_range() {
    ASTNode* left = parse_bitwise_or();
    bool is_range = false;
    
    // 情况 1：直接匹配 ".." 操作符（无空格）
    if (strcmp(peek()->value, "..") == 0 && peek()->type == TOK_OP) {
        consume(); // 消费 ".."
        is_range = true;
    }
    // 情况 2：匹配两个独立的 '.' 符号（允许空格）
    else if (strcmp(peek()->value, ".") == 0 && tok_pos + 1 < token_count &&
         strcmp(tokens[tok_pos + 1].value, ".") == 0) {
        consume(); // 第一个 '.'
        consume(); // 第二个 '.'
        is_range = true;
    }
    
    if (!is_range) {
        return left; // 不是范围，直接返回
    }
    
    // 解析右边界（与原来一致，使用 parse_add_sub）
    ASTNode* end = parse_add_sub();
    ASTNode* step = NULL;
    
    // 检查并解析可选的步长（'sch'）
    if (peek()->type == TOK_KEYWORD && strcmp(peek()->value, "sch") == 0) {
        consume();
        step = parse_add_sub();
    }
    
    ASTNode* node = new_node(NODE_RANGE);
    node->data.range.start = left;
    node->data.range.end = end;
    node->data.range.step = step;
    return node;
}

ASTNode* parse_bitwise_or() {
    ASTNode* left = parse_bitwise_xor();
    while (strcmp(peek()->value, "|") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* right = parse_bitwise_xor();
        ASTNode* node = new_node(NODE_BITWISE_OR);
        node->data.binary.left = left;
        node->data.binary.right = right;
        left = node;
    }
    return left;
}

ASTNode* parse_bitwise_xor() {
    ASTNode* left = parse_bitwise_and();
    while (strcmp(peek()->value, "~~") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* right = parse_bitwise_and();
        ASTNode* node = new_node(NODE_BINARY);
        node->data.binary.left = left;
        node->data.binary.right = right;
        node->data.binary.op = 'X';
        left = node;
    }
    return left;
}

ASTNode* parse_bitwise_and() {
    ASTNode* left = parse_shift();
    while (strcmp(peek()->value, "&") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* right = parse_shift();
        ASTNode* node = new_node(NODE_BITWISE_AND);
        node->data.binary.left = left;
        node->data.binary.right = right;
        left = node;
    }
    return left;
}

ASTNode* parse_shift() {
    ASTNode* left = parse_add_sub();
    while (true) {
        Token* op = peek();
        if (op->type == TOK_OP && (strcmp(op->value, "<<") == 0 || strcmp(op->value, ">>") == 0)) {
            consume();
            ASTNode* right = parse_add_sub();
            ASTNode* node = new_node(
                strcmp(op->value, "<<") == 0 ? NODE_SHIFT_LEFT : NODE_SHIFT_RIGHT
            );
            node->data.binary.left = left;
            node->data.binary.right = right;
            left = node;
        } else break;
    }
    return left;
}

 ASTNode* parse_pipe() {
    ASTNode* left = parse_null_coalesce();
    while (strcmp(peek()->value, "|>") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* right = parse_null_coalesce();
        // 如果右侧是函数调用，则改造之
        if (right->type == NODE_FUNC_CALL) {
            // 将 left 作为第一个参数插入
            ASTNode** new_args = (ASTNode**)malloc((right->data.func_call.arg_count + 1) * sizeof(ASTNode*));
            new_args[0] = left;
            for (int i = 0; i < right->data.func_call.arg_count; i++) {
                new_args[i+1] = right->data.func_call.args[i];
            }
            free(right->data.func_call.args);
            right->data.func_call.args = new_args;
            right->data.func_call.arg_count++;
            left = right;
        } else if (right->type == NODE_VARIABLE) {
            char* func_name = right->data.var_name;
            ASTNode* call_node = new_node(NODE_FUNC_CALL);
            call_node->data.func_call.name = strdup(func_name);
            call_node->data.func_call.arg_count = 1;
            call_node->data.func_call.args = (ASTNode**)malloc(sizeof(ASTNode*));
            call_node->data.func_call.args[0] = left;
            free_ast(right);
            left = call_node;
        } else {
            kr_error("管道右侧必须是函数调用\n");
            
        }
    }
    return left;
 }
 
 /* 三元运算符 */
 ASTNode* parse_ternary() {
     ASTNode* cond = parse_logical_or();
     if (strcmp(peek()->value, "?") == 0 && peek()->type == TOK_SYMBOL) {
         consume();
         ASTNode* true_expr = parse_ternary();
         expect(":");
         ASTNode* false_expr = parse_ternary();
         ASTNode* node = new_node(NODE_TERNARY);
         node->data.ternary.cond = cond;
         node->data.ternary.true_expr = true_expr;
         node->data.ternary.false_expr = false_expr;
         return node;
     }
     return cond;
 }

 ASTNode* parse_null_coalesce() {
    ASTNode* left = parse_ternary();
    while (strcmp(peek()->value, "??") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* right = parse_ternary();
        ASTNode* node = new_node(NODE_NULL_COALESCE);
        node->data.null_coalesce.left = left;
        node->data.null_coalesce.right = right;
        left = node;
    }
    return left;
 }
 
 ASTNode* parse_add_sub() {
    ASTNode* left = parse_mul_div();
    while (true) {
        Token* op = peek();
        // 仅当 token 类型为 TOK_OP 时才视为运算符
        if (op->type == TOK_OP && (strcmp(op->value, "+") == 0 || strcmp(op->value, "-") == 0 || strcmp(op->value, "##") == 0)) {
            consume();
            ASTNode* right = parse_mul_div();
            ASTNode* node = new_node(NODE_BINARY);
            node->data.binary.left = left;
            node->data.binary.right = right;
            node->data.binary.op = (strcmp(op->value, "##") == 0) ? 'H' : op->value[0];
            left = node;
        } else break;
    }
    return left;
 }
 
 /* 表达式解析 —— 处理乘除取模 */
 ASTNode* parse_mul_div() {
    ASTNode* left = parse_term();
    while (true) {
        Token* op = peek();
        if (op->type == TOK_OP && (strcmp(op->value, "*") == 0 || strcmp(op->value, "/") == 0 || strcmp(op->value, "%") == 0)) {
            consume();
            ASTNode* right = parse_term();
            ASTNode* node = new_node(NODE_BINARY);
            node->data.binary.left = left;
            node->data.binary.right = right;
            node->data.binary.op = op->value[0];
            left = node;
        } else break;
    }
    return left;
 }

 // 辅助函数：深拷贝类型节点
 TypeNode* copy_type_node(TypeNode* src) {
    if (!src) return nullptr;
    TypeNode* dst = new TypeNode;
    dst->kind = src->kind;
    switch (src->kind) {
        case TYPE_INT:
        case TYPE_FLOAT:
        case TYPE_STRING:
        case TYPE_BOOL:
        case TYPE_CHAR:
        case TYPE_NUM:
        case TYPE_ANY:
            break;
        case TYPE_ARRAY:
            dst->array_type.elem_type = copy_type_node(src->array_type.elem_type);
            break;
        case TYPE_OBJECT: {
            dst->object_type.count = src->object_type.count;
            dst->object_type.keys = (char**)malloc(dst->object_type.count * sizeof(char*));
            dst->object_type.types = (TypeNode**)malloc(dst->object_type.count * sizeof(TypeNode*));
            for (int i = 0; i < dst->object_type.count; i++) {
                dst->object_type.keys[i] = strdup(src->object_type.keys[i]);
                dst->object_type.types[i] = copy_type_node(src->object_type.types[i]);
            }
            break;
        }
        case TYPE_ALIAS:
            dst->alias_type.name = strdup(src->alias_type.name);
            break;
        case TYPE_FUNCTION:
            dst->func_type.param_count = src->func_type.param_count;
            dst->func_type.param_types = (TypeNode**)malloc(dst->func_type.param_count * sizeof(TypeNode*));
            for (int i = 0; i < dst->func_type.param_count; i++)
                dst->func_type.param_types[i] = copy_type_node(src->func_type.param_types[i]);
            dst->func_type.ret_type = copy_type_node(src->func_type.ret_type);
            break;
        case TYPE_OPTIONAL:
            dst->optional_type.inner_type = copy_type_node(src->optional_type.inner_type);
            break;
        case TYPE_STRING_UNION:
            dst->union_type.string_union = new std::unordered_set<std::string>(*src->union_type.string_union);
            break;
        case TYPE_STRUCT: {
            dst->struct_type.field_count = src->struct_type.field_count;
            dst->struct_type.fields = (StructField*)malloc(dst->struct_type.field_count * sizeof(StructField));
            for (int i = 0; i < dst->struct_type.field_count; i++) {
                dst->struct_type.fields[i].name = strdup(src->struct_type.fields[i].name);
                dst->struct_type.fields[i].type = copy_type_node(src->struct_type.fields[i].type);
            }
            break;
        }
        case TYPE_UNION: {
            dst->variant_type.variant_count = src->variant_type.variant_count;
            dst->variant_type.variants = (UnionVariant*)malloc(dst->variant_type.variant_count * sizeof(UnionVariant));
            for (int i = 0; i < dst->variant_type.variant_count; i++) {
                UnionVariant* sv = &src->variant_type.variants[i];
                UnionVariant* dv = &dst->variant_type.variants[i];        
                dv->name = strdup(sv->name);
                dv->param_count = sv->param_count;
                if (sv->param_count > 0) {
                    dv->param_types = (TypeNode**)malloc(dv->param_count * sizeof(TypeNode*));
                    for (int j = 0; j < dv->param_count; j++)
                        dv->param_types[j] = copy_type_node(sv->param_types[j]);
                    dv->named_fields = NULL;
                    dv->field_count = 0;
                } else {
                    dv->param_types = NULL;
                    dv->field_count = sv->field_count;
                    if (dv->field_count > 0) {
                        dv->named_fields = (StructField*)malloc(dv->field_count * sizeof(StructField));
                        for (int j = 0; j < dv->field_count; j++) {
                            dv->named_fields[j].name = strdup(sv->named_fields[j].name);
                            dv->named_fields[j].type = copy_type_node(sv->named_fields[j].type);
                        }
                    } else {
                        dv->named_fields = NULL;
                    }
                }
            }
            break;
        }
        case TYPE_POINTER:
            dst->ptr_type.elem_type = copy_type_node(src->ptr_type.elem_type);
            dst->ptr_type.smart     = src->ptr_type.smart;
            break;
        default:
            break;
    }
    return dst;
 }

 // 辅助函数：释放类型节点
 void free_type_node(TypeNode* type) {
    if (!type) return;
    switch (type->kind) {
        case TYPE_OBJECT:
            for (int i = 0; i < type->object_type.count; i++) {
                free(type->object_type.keys[i]);
                free_type_node(type->object_type.types[i]);
            }
            free(type->object_type.keys);
            free(type->object_type.types);
            break;
        case TYPE_ARRAY:
            free_type_node(type->array_type.elem_type);
            break;
        case TYPE_ALIAS:
            free(type->alias_type.name);
            break;
        case TYPE_OPTIONAL:
            free_type_node(type->optional_type.inner_type);
            break;
        case TYPE_FUNCTION:
            for (int i = 0; i < type->func_type.param_count; i++)
                free_type_node(type->func_type.param_types[i]);
            free(type->func_type.param_types);
            free_type_node(type->func_type.ret_type);
            break;
        case TYPE_STRING_UNION:
            delete type->union_type.string_union;
            break;
            case TYPE_STRUCT:
            for (int i = 0; i < type->struct_type.field_count; i++) {
                free(type->struct_type.fields[i].name);
                free_type_node(type->struct_type.fields[i].type);
            }
            free(type->struct_type.fields);
            break;
        case TYPE_UNION:
            for (int i = 0; i < type->variant_type.variant_count; i++) {
                UnionVariant* v = &type->variant_type.variants[i];
                free(v->name);
                if (v->param_count > 0) {
                    for (int j = 0; j < v->param_count; j++)
                        free_type_node(v->param_types[j]);
                    free(v->param_types);
                } else {
                    for (int j = 0; j < v->field_count; j++) {
                        free(v->named_fields[j].name);
                        free_type_node(v->named_fields[j].type);
                    }
                    free(v->named_fields);
                }
            }
            free(type->variant_type.variants);
            break;
        case TYPE_POINTER:
            free_type_node(type->ptr_type.elem_type);
            break;
        default:
            break;
    }
    free(type);
 }

 TypeNode* parse_string_union() {
    std::vector<std::string> strings;
    while (true) {
        Token* t = peek();
        if (t->type != TOK_REGEX || t->flags != NULL) {
            kr_error("期望字符串字面量作为类型");
        }
        consume();
        char* unescaped = unescape_string(t->value);
        strings.emplace_back(unescaped);
        free(unescaped);

        if (strcmp(peek()->value, "|") == 0 && peek()->type == TOK_OP) {
            consume();
            continue;
        } else {
            break;
        }
    }

    TypeNode* node = new TypeNode;
    node->kind = TYPE_STRING_UNION;
    node->union_type.string_union = new std::unordered_set<std::string>(strings.begin(), strings.end());
    return node;
}

 TypeNode* parse_type_expr() {
    Token* t = peek();
    if (t->type == TOK_REGEX && t->flags == NULL) {
        // 是双引号字符串，尝试解析联合
        return parse_string_union();
    }
    // ---- 函数类型：fkt(类型1, 类型2, ...) [: 返回类型] ----
    if (strcmp(t->value, "fkt") == 0 && t->type == TOK_KEYWORD) {
        consume(); // 消费 'fkt'
        expect("(");
        std::vector<TypeNode*> param_types;
        if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
            while (true) {
                TypeNode* param = parse_type_expr();
                param_types.push_back(param);
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                    continue;
                } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                    break;
                } else {
                    error_at(peek()->line, peek()->col, "函数类型参数列表期望 ',' 或 ')'");
                }
            }
        }
        expect(")");
        // 返回类型是可选的，仅当后面显式跟 ':' 时才解析
        TypeNode* ret_type = nullptr;
        if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ":") == 0) {
            consume();
            ret_type = parse_type_expr();
        }
        TypeNode* func = new TypeNode;
        func->kind = TYPE_FUNCTION;
        func->func_type.param_count = (int)param_types.size();
        func->func_type.param_types = (TypeNode**)malloc(func->func_type.param_count * sizeof(TypeNode*));
        for (size_t i = 0; i < param_types.size(); i++) {
            func->func_type.param_types[i] = param_types[i];
        }
        func->func_type.ret_type = ret_type;
        return func;
    }
    TypeNode* base = nullptr;   // 用于存储基础类型节点

    // 指针类型：zeiger<T> 或 schlau<T> / smart<T>
    if (t->type == TOK_IDENT &&
        (strcmp(t->value, "zgr") == 0 ||
        strcmp(t->value, "schlau") == 0)) {
        bool smart = (strcmp(t->value, "schlau") == 0);
        if (tok_pos + 1 < token_count &&
            strcmp(tokens[tok_pos + 1].value, "<") == 0) {
            consume();          // 消费 "zgr"/"schlau"
            expect("<");
            TypeNode* elem = parse_type_expr();
            expect(">");
            TypeNode* ptr = new TypeNode;
            ptr->kind = TYPE_POINTER;
            ptr->ptr_type.elem_type = elem;
            ptr->ptr_type.smart     = smart;
            if (strcmp(peek()->value, "?") == 0) {
                consume();
                TypeNode* opt = new TypeNode;
                opt->kind = TYPE_OPTIONAL;
                opt->optional_type.inner_type = ptr;
                return opt;
            }
            return ptr;
        }
        // 否则视为普通标识符（继续走已有逻辑）
    }

    if (strcmp(t->value, "{") == 0) {
        consume();
        TypeNode* obj = new TypeNode;
        obj->kind = TYPE_OBJECT;
        obj->object_type.keys = NULL;
        obj->object_type.types = NULL;
        obj->object_type.count = 0;
        if (strcmp(peek()->value, "}") != 0) {
            while (true) {
                Token* key_tok = consume();
                if (key_tok->type != TOK_IDENT)
                    error_at(key_tok->line, key_tok->col, "期望标识符作为对象键");
                expect(":");
                TypeNode* val_type = parse_type_expr();
                obj->object_type.keys = (char**)realloc(obj->object_type.keys,
                                    (obj->object_type.count + 1) * sizeof(char*));
                obj->object_type.types = (TypeNode**)realloc(obj->object_type.types,
                                    (obj->object_type.count + 1) * sizeof(TypeNode*));
                obj->object_type.keys[obj->object_type.count] = strdup(key_tok->value);
                obj->object_type.types[obj->object_type.count] = val_type;
                obj->object_type.count++;
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                    continue;
                } else if (strcmp(peek()->value, "}") == 0) {
                    break;
                } else {
                    error_at(peek()->line, peek()->col, "对象类型期望 ',' 或 '}'");
                }
            }
        }
        expect("}");
        base = obj;
    } 
    else if (strcmp(t->value, "[") == 0) {
        consume();
        TypeNode* elem = parse_type_expr();
        expect("]");
        TypeNode* arr = new TypeNode;
        arr->kind = TYPE_ARRAY;
        arr->array_type.elem_type = elem;
        base = arr;
    }
    else if (t->type == TOK_IDENT) {
        consume();
        TypeNode* node = new TypeNode;
        if (strcmp(t->value, "zahl") == 0 || strcmp(t->value, "lang") == 0)
            node->kind = TYPE_NUM;
        else if (strcmp(t->value, "zkt") == 0)
            node->kind = TYPE_STRING;
        else if (strcmp(t->value, "bool") == 0)
            node->kind = TYPE_BOOL;
        else if (strcmp(t->value, "leer") == 0)
            node->kind = TYPE_ANY; 
        else if (strcmp(t->value, "einz") == 0)
            node->kind = TYPE_CHAR;
        else if (strcmp(t->value, "kzl") == 0)
            node->kind = TYPE_FLOAT;
        else if (strcmp(t->value, "gzl") == 0)
            node->kind = TYPE_INT;
        else {
            node->kind = TYPE_ALIAS;
            // ---- 支持命名空间限定类型名：A.int → "A::int" ----
            std::string qualified = t->value;
            while (strcmp(peek()->value, ".") == 0 &&
                    tok_pos + 1 < token_count &&
                    tokens[tok_pos + 1].type == TOK_IDENT) {
                consume();                    // 消费 '.'
                Token* part = consume();      // 消费标识符段
                qualified += "::";
                qualified += part->value;
            }
            node->alias_type.name = strdup(qualified.c_str());
        }
        base = node;
    } 
    else {
        error_at(t->line, t->col, "无效的类型别名表达式");
        return NULL;
    }

    if (strcmp(peek()->value, "?") == 0) {
        consume();
        TypeNode* optional = new TypeNode;
        optional->kind = TYPE_OPTIONAL;
        optional->optional_type.inner_type = base;
        base = optional;
    }

    return base;
}
 
 /* ---------- 后缀处理（索引、属性、方法调用、后缀 ++/--） ---------- */
 ASTNode* parse_postfix(ASTNode* left) {
    while (1) {
        if (strcmp(peek()->value, "[") == 0) {
            consume();
            ASTNode* start = nullptr;
            ASTNode* end = nullptr;
            bool is_slice = false;
        
            // 检测冒号
            if (strcmp(peek()->value, ":") == 0) {
                is_slice = true;
                consume();
                // end 可能缺省
                if (strcmp(peek()->value, "]") != 0)
                    end = parse_expression();
            } else {
                start = parse_expression();
                if (strcmp(peek()->value, ":") == 0) {
                    is_slice = true;
                    consume();
                    if (strcmp(peek()->value, "]") != 0)
                        end = parse_expression();
                }
            }
            expect("]");
        
            if (is_slice) {
                // 新方式：生成方法调用 .ab(start, end)
                // 缺省起始 → 0，缺省结束 → -1
                if (!start) {
                    start = new_node(NODE_NUMBER);
                    start->data.number_str = strdup("0");
                }
                if (!end) {
                    end = new_node(NODE_NUMBER);
                    end->data.number_str = strdup("-1");
                }
        
                ASTNode* call = new_node(NODE_METHOD_CALL);
                call->data.method_call.obj = left;          // left 是当前表达式的左值（字符串变量）
                call->data.method_call.method = strdup("ab");
                call->data.method_call.arg_count = 2;
                call->data.method_call.args = (ASTNode**)malloc(2 * sizeof(ASTNode*));
                call->data.method_call.args[0] = start;
                call->data.method_call.args[1] = end;
                call->data.method_call.is_optional = false;
        
                left = call;   // 继续后续后缀处理
                continue;
            } else {
                ASTNode* node = new_node(NODE_ARRAY_ACCESS);
                node->data.array_access.array = left;
                node->data.array_access.index = start; // start 实际就是索引表达式
                left = node;
            }
        }
        // 方法调用或属性
        else if (strcmp(peek()->value, ".") == 0) {
            consume();
            // 检查是否为 ?.
            bool is_optional = false;
            if (strcmp(peek()->value, "?.") == 0) { // 此时 token 已是 ?.
                is_optional = true;
                consume(); // 消耗 ?.
            }
            Token* ident_tok = consume();
            char* ident = strdup(ident_tok->value);
            if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, "(") == 0) {
                // --- 方法调用 ---
                consume(); // 消耗 '('
                ASTNode** args = NULL;
                int arg_count = 0;
                if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                    while (true) {
                        if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) break;
                        ASTNode* arg = parse_expression();
                        args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                        args[arg_count++] = arg;
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();
                        } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                            break;
                        } else {
                            error_at(peek()->line, peek()->col,
                                     "语法错误: 方法参数期望 ',' 或 ')'，得到 '%s'", peek()->value);
                        }
                    }
                }
                expect(")");
                ASTNode* node = new_node(NODE_METHOD_CALL, ident_tok->line, ident_tok->col);
                node->data.method_call.obj = left;
                node->data.method_call.method = ident;
                node->data.method_call.args = args;
                node->data.method_call.arg_count = arg_count;
                node->data.method_call.is_optional = is_optional; 
                left = node;
            } else {
                // --- 属性访问（包括 län） ---
                ASTNode* node = new_node(NODE_OBJECT_ACCESS, ident_tok->line, ident_tok->col);
                node->data.object_access.obj = left;
                node->data.object_access.key = ident;
                node->data.object_access.is_optional = is_optional;  // 赋值
                left = node;
            }
        }
        else if (strcmp(peek()->value, "?.") == 0 && peek()->type == TOK_OP) {
            consume(); // 消费 '?.'
            Token* ident_tok = consume();
            char* ident = strdup(ident_tok->value);
            // 检查是否为方法调用（?. 后跟标识符和括号）
            if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, "(") == 0) {
                // --- 可选方法调用 ---
                consume(); // 消耗 '('
                ASTNode** args = NULL;
                int arg_count = 0;
                if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                    while (true) {
                        if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) break;
                        ASTNode* arg = parse_expression();
                        args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                        args[arg_count++] = arg;
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();
                        } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                            break;
                        } else {
                            error_at(peek()->line, peek()->col, "语法错误: 方法参数期望 ',' 或 ')'");
                        }
                    }
                }
                expect(")");
                ASTNode* node = new_node(NODE_METHOD_CALL, ident_tok->line, ident_tok->col);
                node->data.method_call.obj = left;
                node->data.method_call.method = ident;
                node->data.method_call.args = args;
                node->data.method_call.arg_count = arg_count;
                node->data.method_call.is_optional = true;
                left = node;
            } else {
                // --- 可选属性访问 ---
                ASTNode* node = new_node(NODE_OBJECT_ACCESS, ident_tok->line, ident_tok->col);
                node->data.object_access.obj = left;
                node->data.object_access.key = ident;
                node->data.object_access.is_optional = true;   // 标记为可选链
                left = node;
            }
        }
        else if (strcmp(peek()->value, "(") == 0) {
            consume(); // '('
            ASTNode* call_node = new_node(NODE_FUNC_CALL, left->line, left->col);
            call_node->data.func_call.func_expr = left;
            ASTNode** args = NULL;
            int arg_count = 0;
            if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                while (true) {
                    if (peek()->type == TOK_OP && strcmp(peek()->value, "...") == 0) {
                        consume(); // 消费 '...'
                        ASTNode* spread_expr = parse_expression();
                        ASTNode* spread_node = new_node(NODE_SPREAD_ARG);
                        spread_node->data.spread.expr = spread_expr;
                        args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                        args[arg_count++] = spread_node;
                    } else {
                        ASTNode* arg = parse_expression();
                        args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                        args[arg_count++] = arg;
                    }
                    if (strcmp(peek()->value, ",") == 0) {
                        consume();
                    } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                        break;
                    } else {
                        error_at(peek()->line, peek()->col, "语法错误: 函数参数期望 ',' 或 ')'");
                    }
                }
            }
            expect(")");
            call_node->data.func_call.args = args;
            call_node->data.func_call.arg_count = arg_count;
            left = call_node;
        }
        // 后缀递增/递减
        else if ((strcmp(peek()->value, "++") == 0 || strcmp(peek()->value, "--") == 0) && peek()->type == TOK_OP) {
            char* op = strdup(consume()->value);
            NodeType type = (strcmp(op, "++") == 0) ? NODE_POST_INC : NODE_POST_DEC;
            ASTNode* node = new_node(type, left->line, left->col);
            node->data.inc_dec.operand = left;
            left = node;
            free(op);
        }
        else if (strcmp(peek()->value, "°") == 0 && peek()->type == TOK_OP) {
            consume();
            ASTNode* node = new_node(NODE_DEGREE);
            node->data.inc_dec.operand = left;
            left = node;
        }
        else if (strcmp(peek()->value, "!!") == 0 && peek()->type == TOK_OP) {
            consume();
            ASTNode* node = new_node(NODE_DOUBLE_FACTORIAL);
            node->data.inc_dec.operand = left;
            left = node;
        }
        else if (strcmp(peek()->value, "!") == 0 && peek()->type == TOK_OP) {
            consume();
            ASTNode* node = new_node(NODE_FACTORIAL);
            node->data.inc_dec.operand = left;
            left = node;
        }
        else {
            break; // 无更多后缀
        }
    }
    return left;
 }

 ASTNode* parse_class_definition(int access_modifier, bool is_static_class) {
    // 已消费 'klass'
    Token* name_tok = consume();
    if (name_tok->type != TOK_IDENT)
        error_at(name_tok->line, name_tok->col, "期望类名");
    char* name = strdup(name_tok->value);
    char* parent = NULL;
    TypeNode** ctor_param_types = nullptr;
    int ctor_param_type_count = 0;
    if (strcmp(peek()->value, "(") == 0) {
        consume(); // 消费 '('
        Token* parent_tok = consume();
        if (parent_tok->type != TOK_IDENT)
            error_at(parent_tok->line, parent_tok->col, "期望父类名");
        parent = strdup(parent_tok->value);
        expect(")");
    }
    if (strcmp(peek()->value, "erbt") == 0) {
        consume();
        Token* parent_tok = consume();
        if (parent_tok->type != TOK_IDENT)
            error_at(parent_tok->line, parent_tok->col, "期望父类名");
        parent = strdup(parent_tok->value);
    }

    int base_indent = g_stmt_start_col - 1;
    bool is_brace_mode = false;
    if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, "{") == 0) {
        consume();
        is_brace_mode = true;
    }

    // 存储解析结果
    char** ctor_params = NULL;
    int ctor_param_count = 0;
    ASTNode* ctor_body = NULL;
    ASTNode** ctor_defaults = nullptr;
    int ctor_default_count = 0;

    char** method_names = NULL;
    char*** method_param_lists = NULL;
    int* method_param_counts = NULL;
    ASTNode** method_bodies = NULL;
    char** method_vararg_names = NULL;
    TypeNode** method_vararg_types = NULL;
    bool* method_static_flags = NULL;
    int* method_access = NULL;
    TypeNode** method_return_types = NULL;
    TypeNode*** method_param_types = NULL;
    int method_count = 0;
    bool* method_stmt_flags = NULL;

    std::vector<PropertyDef> properties;

    // ---------- 辅助 lambda：解析单个成员（不读取修饰符和 stati） ----------
    // 参数 base_indent 用于缩进解析体（如方法体）
    auto parse_single_member = [&](int& mem_access, bool& mem_is_static, bool& mem_is_stmt_func, int base_indent) {
        bool mem_is_lazy = false;
        while (true) {
            Token* tok = peek();
            if (strcmp(tok->value, "stati") == 0) {
                consume();
                mem_is_static = true;
            } else if (strcmp(tok->value, "satz") == 0) {
                consume();
                mem_is_stmt_func = true;
            } else if (strcmp(tok->value, "privat") == 0) {
                consume();
                mem_access = 1;
            } else if (strcmp(tok->value, "schutz") == 0) {
                consume();
                mem_access = 2;
            } else if (strcmp(tok->value, "öffent") == 0) {
                consume();
                mem_access = 0;
            } else if (strcmp(tok->value, "faul") == 0)  {
                consume(); mem_is_lazy = true; 
            } else {
                break;
            }
        }

        int saved_pos = tok_pos;
        TypeNode* ret_type = nullptr;
        bool has_ret_type = false;
    
        // ---- 1. 尝试解析返回类型前缀的方法 ----
        try {
            ret_type = parse_type_expr();
            if (peek()->type == TOK_IDENT && tok_pos + 1 < token_count &&
                strcmp(tokens[tok_pos + 1].value, "(") == 0) {
                has_ret_type = true;
            } else {
                tok_pos = saved_pos;
                free_type_node(ret_type);
                ret_type = nullptr;
            }
        } catch (...) {
            tok_pos = saved_pos;
        }
    
        if (has_ret_type) {
            Token* name_tok = consume();
            if (name_tok->type != TOK_IDENT)
                error_at(name_tok->line, name_tok->col, "期望方法名");
            char* name = strdup(name_tok->value);
            expect("(");
            char** params = nullptr;
            int param_count = 0;
            bool* param_is_const = nullptr;
            ASTNode** param_defaults = nullptr;
            TypeNode** param_types = nullptr;
            char* vararg_name = nullptr;
            TypeNode* vararg_type = nullptr;
            parse_param_list(&params, &param_count, &param_is_const,
                             &param_defaults, &param_types,
                             &vararg_name, &vararg_type);
    
            if (strcmp(peek()->value, ":") == 0) {
                kr_warn("方法 '%s' 已有返回类型前缀，忽略后面的 ': 类型'", name);
                consume();
                TypeNode* extra = parse_type_expr();
                free_type_node(extra);
            }
    
            ASTNode* body = parse_body_block(base_indent);
    
            method_names = (char**)realloc(method_names, (method_count + 1) * sizeof(char*));
            method_param_counts = (int*)realloc(method_param_counts, (method_count + 1) * sizeof(int));
            method_param_lists = (char***)realloc(method_param_lists, (method_count + 1) * sizeof(char**));
            method_bodies = (ASTNode**)realloc(method_bodies, (method_count + 1) * sizeof(ASTNode*));
            method_static_flags = (bool*)realloc(method_static_flags, (method_count + 1) * sizeof(bool));
            method_access = (int*)realloc(method_access, (method_count + 1) * sizeof(int));
            method_return_types = (TypeNode**)realloc(method_return_types, (method_count + 1) * sizeof(TypeNode*));
            method_param_types = (TypeNode***)realloc(method_param_types, (method_count + 1) * sizeof(TypeNode**));
            method_vararg_names = (char**)realloc(method_vararg_names, (method_count + 1) * sizeof(char*));
            method_vararg_types = (TypeNode**)realloc(method_vararg_types, (method_count + 1) * sizeof(TypeNode*));
    
            method_names[method_count] = name;
            method_param_counts[method_count] = param_count;
            method_param_lists[method_count] = params;
            method_bodies[method_count] = body;
            method_static_flags[method_count] = mem_is_static;
            method_access[method_count] = mem_access;
            method_return_types[method_count] = ret_type;
            method_param_types[method_count] = param_types;
            method_vararg_names[method_count] = vararg_name;
            method_vararg_types[method_count] = vararg_type;
            method_count++;
            return;
        }
    
        Token* tok = peek();
    
        // ---- 2. 构造函数 ----
        if (strcmp(tok->value, "konstr") == 0) {
            if (ctor_body) error_at(tok->line, tok->col, "类中只能有一个构造函数");
            consume();
            expect("(");
        
            // ----- 使用 parse_param_list 支持类型前缀 -----
            char** param_names = nullptr;
            int param_count = 0;
            bool* param_is_const = nullptr;
            ASTNode** param_defaults = nullptr;
            TypeNode** param_types = nullptr;
            char* vararg_name = nullptr;
            TypeNode* vararg_type = nullptr;
        
            parse_param_list(&param_names, &param_count,
                             &param_is_const, &param_defaults,
                             &param_types, &vararg_name, &vararg_type);
            // parse_param_list 已消费 ')'
        
            // 存储参数名和类型（接管堆内存）
            ctor_param_count = param_count;
            ctor_params = (char**)malloc(ctor_param_count * sizeof(char*));
            for (int i = 0; i < ctor_param_count; ++i)
                ctor_params[i] = param_names[i];          // 直接接管
        
            ctor_param_type_count = param_count;
            ctor_param_types = (TypeNode**)malloc(ctor_param_type_count * sizeof(TypeNode*));
            for (int i = 0; i < ctor_param_type_count; ++i)
                ctor_param_types[i] = param_types[i];     // 直接接管

            ctor_default_count = param_count;
            ctor_defaults = (ASTNode**)malloc(ctor_default_count * sizeof(ASTNode*));
            for (int i = 0; i < ctor_default_count; ++i)
                ctor_defaults[i] = param_defaults[i];   // 接管所有权（不释放）
        
            // 释放辅助数组（但不要释放元素）
            free(param_names);
            free(param_types);
            free(param_is_const);
            free(param_defaults);       // 只释放外壳，元素已接管
            free(vararg_name);
            free_type_node(vararg_type);
        
            // 解析构造函数体
            ASTNode* body = parse_body_block(base_indent);
            ctor_body = body;
        }
    
        // ---- 3. 方法（fkt/methode） ----
        else if (strcmp(tok->value, "fkt") == 0 || strcmp(tok->value, "methode") == 0) {
            consume();
            Token* mname_tok = consume();
            if (mname_tok->type != TOK_IDENT)
                error_at(mname_tok->line, mname_tok->col, "期望方法名");
    
            expect("(");
            char** params = NULL;
            int param_count = 0;
            bool* param_is_const = NULL;
            ASTNode** param_defaults = NULL;
            TypeNode** param_types = NULL;
            char* vararg_name = NULL;
            TypeNode* vararg_type = nullptr;
            parse_param_list(&params, &param_count, &param_is_const,
                             &param_defaults, &param_types,
                             &vararg_name, &vararg_type);
    
            TypeNode* return_type = NULL;
            if (strcmp(peek()->value, ":") == 0) {
                consume();
                return_type = parse_type_expr();
            }
    
            ASTNode* body = parse_body_block(base_indent);
    
            method_names = (char**)realloc(method_names, (method_count + 1) * sizeof(char*));
            method_param_counts = (int*)realloc(method_param_counts, (method_count + 1) * sizeof(int));
            method_param_lists = (char***)realloc(method_param_lists, (method_count + 1) * sizeof(char**));
            method_bodies = (ASTNode**)realloc(method_bodies, (method_count + 1) * sizeof(ASTNode*));
            method_static_flags = (bool*)realloc(method_static_flags, (method_count + 1) * sizeof(bool));
            method_access = (int*)realloc(method_access, (method_count + 1) * sizeof(int));
            method_return_types = (TypeNode**)realloc(method_return_types, (method_count + 1) * sizeof(TypeNode*));
            method_param_types = (TypeNode***)realloc(method_param_types, (method_count + 1) * sizeof(TypeNode**));
    
            method_names[method_count] = strdup(mname_tok->value);
            method_param_counts[method_count] = param_count;
            method_param_lists[method_count] = params;
            method_bodies[method_count] = body;
            method_static_flags[method_count] = mem_is_static;
            method_access[method_count] = mem_access;
            method_return_types[method_count] = return_type;
            method_param_types[method_count] = param_types;
    
            method_vararg_names = (char**)realloc(method_vararg_names, (method_count + 1) * sizeof(char*));
            method_vararg_types = (TypeNode**)realloc(method_vararg_types, (method_count + 1) * sizeof(TypeNode*));
            method_vararg_names[method_count] = vararg_name ? strdup(vararg_name) : NULL;
            method_vararg_types[method_count] = vararg_type ? copy_type_node(vararg_type) : NULL;
            method_stmt_flags = (bool*)realloc(method_stmt_flags, (method_count + 1) * sizeof(bool));
            method_stmt_flags[method_count] = mem_is_stmt_func;
    
            method_count++;
        }
        else if (tok->type == TOK_IDENT && tok_pos + 1 < token_count && strcmp(tokens[tok_pos + 1].value, "(") == 0) {
            // 消费方法名
            char* name = strdup(tok->value);
            consume(); // 消耗标识符
        
            expect("(");
            char** params = nullptr;
            int param_count = 0;
            bool* param_is_const = nullptr;
            ASTNode** param_defaults = nullptr;
            TypeNode** param_types = nullptr;
            char* vararg_name = nullptr;
            TypeNode* vararg_type = nullptr;
            parse_param_list(&params, &param_count, &param_is_const,
                             &param_defaults, &param_types,
                             &vararg_name, &vararg_type);
        
            // 可选返回类型注解
            TypeNode* return_type = nullptr;
            if (strcmp(peek()->value, ":") == 0) {
                consume();
                return_type = parse_type_expr();
            }
        
            // 方法体（花括号或缩进块）
            ASTNode* body = parse_body_block(base_indent);
        
            // 存储到方法列表（与现有逻辑一致）
            method_names = (char**)realloc(method_names, (method_count + 1) * sizeof(char*));
            method_param_counts = (int*)realloc(method_param_counts, (method_count + 1) * sizeof(int));
            method_param_lists = (char***)realloc(method_param_lists, (method_count + 1) * sizeof(char**));
            method_bodies = (ASTNode**)realloc(method_bodies, (method_count + 1) * sizeof(ASTNode*));
            method_static_flags = (bool*)realloc(method_static_flags, (method_count + 1) * sizeof(bool));
            method_access = (int*)realloc(method_access, (method_count + 1) * sizeof(int));
            method_return_types = (TypeNode**)realloc(method_return_types, (method_count + 1) * sizeof(TypeNode*));
            method_param_types = (TypeNode***)realloc(method_param_types, (method_count + 1) * sizeof(TypeNode**));
            method_vararg_names = (char**)realloc(method_vararg_names, (method_count + 1) * sizeof(char*));
            method_vararg_types = (TypeNode**)realloc(method_vararg_types, (method_count + 1) * sizeof(TypeNode*));
            method_stmt_flags = (bool*)realloc(method_stmt_flags, (method_count + 1) * sizeof(bool));
        
            method_names[method_count] = name;
            method_param_counts[method_count] = param_count;
            method_param_lists[method_count] = params;
            method_bodies[method_count] = body;
            method_static_flags[method_count] = mem_is_static;   // 使用已解析的静态标志
            method_access[method_count] = mem_access;            // 使用已解析的访问修饰符
            method_return_types[method_count] = return_type;
            method_param_types[method_count] = param_types;
            method_vararg_names[method_count] = vararg_name;
            method_vararg_types[method_count] = vararg_type;
            method_stmt_flags[method_count] = mem_is_stmt_func;
            method_count++;
            return; // 结束当前成员解析
        }
    
        // ---- 4. 属性（包括类型前缀） ----
        else {
            // ---- 4a. 尝试解析类型前缀（如 "zkt name"） ----
            int saved_pos2 = tok_pos;
            TypeNode* prefix_type = nullptr;
            bool has_prefix_type = false;
    
            try {
                prefix_type = parse_type_expr();
                // 检查后面是否跟标识符，且该标识符后面是 '=', ';' 或 'ist'（属性声明的特征）
                if (peek()->type == TOK_IDENT &&
                    strcmp(peek()->value, "der") != 0 &&
                    strcmp(peek()->value, "das") != 0) {
                    int next_pos = tok_pos + 1;
                    if (next_pos < token_count &&
                        (strcmp(tokens[next_pos].value, "=") == 0 ||
                         strcmp(tokens[next_pos].value, ";") == 0 ||
                         strcmp(tokens[next_pos].value, "ist") == 0)) {
                        has_prefix_type = true;
                    }
                }
                if (!has_prefix_type) {
                    tok_pos = saved_pos2;
                    free_type_node(prefix_type);
                    prefix_type = nullptr;
                }
            } catch (...) {
                tok_pos = saved_pos2;
                prefix_type = nullptr;
            }
    
            // ---- 4b. 属性识别（原有逻辑 + 类型前缀） ----
            bool is_property = false;
            bool had_der_das = false;
            Token* tok2 = peek();  // 重新获取当前 token
    
            if (has_prefix_type) {
                is_property = true;
                // 此时 tok2 应为属性名（标识符）
            } else if (strcmp(tok2->value, "der") == 0 || strcmp(tok2->value, "das") == 0) {
                is_property = true;
                had_der_das = true;
            } else if (tok2->type == TOK_IDENT) {
                if (tok_pos + 1 < token_count &&
                    (strcmp(tokens[tok_pos + 1].value, ":") == 0 ||
                     strcmp(tokens[tok_pos + 1].value, "=") == 0 ||
                     strcmp(tokens[tok_pos + 1].value, ";") == 0)) {
                    is_property = true;
                }
            }
    
            if (is_property) {
                bool is_const = false;
                if (had_der_das) {
                    if (strcmp(tok2->value, "das") == 0) is_const = true;
                    consume(); // 消费 der/das

                    // 在消费 der/das 后尝试解析类型前缀，
                    // 以支持形如 "das zgr<int> x" / "der schlau<T> y" 的声明。
                    int saved_pos3 = tok_pos;
                    try {
                        TypeNode* t = parse_type_expr();
                        if (peek()->type == TOK_IDENT &&
                            strcmp(peek()->value, "der") != 0 &&
                            strcmp(peek()->value, "das") != 0) {
                            prefix_type = t;
                            has_prefix_type = true;
                        } else {
                            tok_pos = saved_pos3;
                            free_type_node(t);
                        }
                    } catch (const KRError&) {
                        tok_pos = saved_pos3;
                    }
                }
    
                // ---- 处理属性（支持逗号分隔，但类型前缀模式不支持逗号） ----
                while (true) {
                    Token* prop_tok;
                    if (has_prefix_type) {
                        // 类型前缀模式：当前 token 已经是属性名
                        prop_tok = peek();
                        if (prop_tok->type != TOK_IDENT)
                            error_at(prop_tok->line, prop_tok->col, "期望属性名");
                        consume();
                    } else {
                        prop_tok = consume();
                        if (prop_tok->type != TOK_IDENT)
                            error_at(prop_tok->line, prop_tok->col, "期望属性名");
                    }
    
                    char* prop_name = strdup(prop_tok->value);
                    TypeNode* type_anno = nullptr;
                    if (has_prefix_type) {
                        type_anno = prefix_type;   // 使用前缀类型
                        // 如果后面还跟 ": 类型"，则忽略（只警告）
                        if (strcmp(peek()->value, ":") == 0) {
                            kr_warn("属性 '%s' 已有类型前缀，忽略后面的 ': 类型'", prop_name);
                            consume();
                            TypeNode* extra = parse_type_expr();
                            free_type_node(extra);
                        }
                        // 类型前缀属性只允许单个声明，不支持逗号分隔
                    } else {
                        if (strcmp(peek()->value, ":") == 0) {
                            consume();
                            type_anno = parse_type_expr();
                        }
                    }
    
                    ASTNode* init_expr = nullptr;
                    if (strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) {
                        consume();
                        init_expr = parse_expression();
                    }
    
                    PropertyDef prop;
                    prop.name = prop_name;
                    prop.type = type_anno;
                    prop.default_expr = init_expr;
                    prop.is_const = is_const;
                    prop.is_static = mem_is_static;
                    prop.is_lazy = mem_is_lazy;
                    prop.access = mem_access;
                    properties.push_back(prop);
    
                    // ---- 分隔符处理 ----
                    if (has_prefix_type) {
                        // 类型前缀模式不允许逗号分隔多个属性
                        if (strcmp(peek()->value, ",") == 0) {
                            error_at(peek()->line, peek()->col, "类型前缀属性声明不允许逗号分隔多个属性");
                        }
                        break;  // 仅处理一个属性
                    } else {
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();
                            continue;
                        } else {
                            break;
                        }
                    }
                }
                // 消耗末尾的分号（可选）
                if (strcmp(peek()->value, ";") == 0)
                    consume();
            } else {
                {
                    g_last_error_line = tok2->line;
                    g_last_error_col  = tok2->col;
                    std::string hint = make_keyword_alias_hint("klass", "klass");
                    kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                                  "类体中只允许 'konstr', 'fkt/methode', 或属性声明");
                }
            }
        }
    };

    // ---- 主循环：解析成员 ----
    while (true) {
        Token* tok = peek();
        if (tok->type == TOK_EOF) break;

        if (is_brace_mode) {
            if (strcmp(tok->value, "}") == 0) {
                consume();
                break;
            }
        } else {
            int cur_indent = tok->col - 1;
            if (cur_indent <= base_indent)
                break;
        }

        // 保存当前 token 的列作为该成员声明行的基准缩进
        int current_base_indent = tok->col - 1;

        // ---- 读取访问修饰符和 stati ----
        int access = 0;
        bool is_static = false;
        bool is_stmt_func = false;
        tok = peek();   // 重新获取

        if (strcmp(tok->value, "privat") == 0) {
            access = 1;
            consume();
            tok = peek();
        } else if (strcmp(tok->value, "schutz") == 0) {
            access = 2;
            consume();
            tok = peek();
        } else if (strcmp(tok->value, "öffent") == 0) {
            consume();
            tok = peek();
        }

        if (strcmp(tok->value, "stati") == 0) {
            is_static = true;
            consume();
            tok = peek();
        }

        if (strcmp(tok->value, "satz") == 0) {
            is_stmt_func = true;
            consume();
            tok = peek();
        }

        if (is_static_class && !is_static) {
            is_static = true;   // 类为静态类，且成员未显式标注 stati → 默认静态
        }

        // ---- 判断是否为修饰符块 ----
        bool is_brace_block = (strcmp(tok->value, "{") == 0);
        bool is_indent_block = false;
        if (!is_brace_block && tok_pos < token_count) {
            int next_line = tok->line;
            int next_col  = tok->col;
            if (next_line > tok->line && next_col > tok->col) {
                is_indent_block = true;
            }
        }

        // ---- 处理花括号块 ----
        if (is_brace_block) {
            consume();  // 吃掉 '{'
            while (peek()->type != TOK_EOF && strcmp(peek()->value, "}") != 0) {
                // 块内成员也使用其声明行的缩进作为基准
                int member_base = peek()->col - 1;
                parse_single_member(access, is_static, is_stmt_func, member_base);
            }
            expect("}");
            continue;
        }

        // ---- 处理缩进块 ----
        if (is_indent_block) {
            // 以当前 token 的列作为基准（即块首行）
            int block_base = tok->col - 1;
            while (peek()->type != TOK_EOF) {
                int cur_indent2 = peek()->col - 1;
                if (cur_indent2 <= block_base) break;
                int member_base = peek()->col - 1;
                parse_single_member(access, is_static, is_stmt_func, member_base);
            }
            continue;
        }

        // ---- 普通单个成员 ----
        parse_single_member(access, is_static, is_stmt_func, current_base_indent);
    }

    // ---- 构建 AST 节点 ----
    ASTNode* node = new_node(NODE_CLASS_DEF);
    node->data.class_def.name = name;
    node->data.class_def.parent = parent;
    node->data.class_def.access_modifier = access_modifier;
    node->data.class_def.ctor_param_count = ctor_param_count;
    node->data.class_def.ctor_params = ctor_params;
    node->data.class_def.ctor_body = ctor_body;

    node->data.class_def.ctor_defaults = ctor_defaults;
    node->data.class_def.ctor_default_count = ctor_default_count;

    node->data.class_def.methods.count = method_count;
    node->data.class_def.methods.names = method_names;
    node->data.class_def.methods.param_lists = method_param_lists;
    node->data.class_def.methods.param_counts = method_param_counts;
    node->data.class_def.methods.bodies = method_bodies;
    node->data.class_def.methods.is_static = method_static_flags;
    node->data.class_def.methods.access = method_access;
    node->data.class_def.methods.return_types = method_return_types;
    node->data.class_def.methods.param_types = method_param_types;
    node->data.class_def.methods.vararg_names = method_vararg_names;
    node->data.class_def.methods.vararg_types = method_vararg_types;

    node->data.class_def.properties.count = (int)properties.size();
    node->data.class_def.properties.names = (char**)malloc(node->data.class_def.properties.count * sizeof(char*));
    node->data.class_def.properties.types = (TypeNode**)malloc(node->data.class_def.properties.count * sizeof(TypeNode*));
    node->data.class_def.properties.default_exprs = (ASTNode**)malloc(node->data.class_def.properties.count * sizeof(ASTNode*));
    node->data.class_def.properties.is_const = (bool*)malloc(node->data.class_def.properties.count * sizeof(bool));
    node->data.class_def.properties.is_static = (bool*)malloc(node->data.class_def.properties.count * sizeof(bool));
    node->data.class_def.properties.access = (int*)malloc(node->data.class_def.properties.count * sizeof(int));
    node->data.class_def.properties.is_lazy   = (bool*)malloc(node->data.class_def.properties.count * sizeof(bool));

    for (size_t i = 0; i < properties.size(); i++) {
        node->data.class_def.properties.names[i] = strdup(properties[i].name.c_str());
        node->data.class_def.properties.types[i] = properties[i].type ? copy_type_node(properties[i].type) : nullptr;
        node->data.class_def.properties.default_exprs[i] = properties[i].default_expr ? copy_ast(properties[i].default_expr) : nullptr;
        node->data.class_def.properties.is_const[i] = properties[i].is_const;
        node->data.class_def.properties.is_static[i] = properties[i].is_static;
        node->data.class_def.properties.is_lazy[i]      = properties[i].is_lazy;
        node->data.class_def.properties.access[i] = properties[i].access;
    }

    node->data.class_def.ctor_param_types = ctor_param_types;
    node->data.class_def.ctor_param_type_count = ctor_param_type_count;

    node->data.class_def.methods.is_stmt_func = method_stmt_flags;
    node->data.class_def.is_static_class = is_static_class;

    return node;
}

ASTNode* parse_enum_definition() {
    consume(); // 消费 'aufz'
    Token* name_tok = consume();
    if (name_tok->type != TOK_IDENT)
        error_at(name_tok->line, name_tok->col, "期望枚举名称");
    char* name = strdup(name_tok->value);

    // ---- 花括号模式 ----
    if (strcmp(peek()->value, "{") == 0) {
        consume();
        char** variants = NULL;
        int* param_counts = NULL;
        int count = 0;
        while (strcmp(peek()->value, "}") != 0) {
            Token* var_tok = consume();
            if (var_tok->type != TOK_IDENT)
                error_at(var_tok->line, var_tok->col, "期望变体名称");
            char* var_name = strdup(var_tok->value);
            int param_count = 0;
            if (strcmp(peek()->value, "(") == 0) {
                consume();
                if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                    while (true) {
                        Token* p = consume();
                        if (p->type != TOK_IDENT)
                            error_at(p->line, p->col, "期望参数名");
                        param_count++;
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();
                            continue;
                        } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                            break;
                        } else {
                            error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                        }
                    }
                }
                expect(")");
            }
            variants = (char**)realloc(variants, (count + 1) * sizeof(char*));
            param_counts = (int*)realloc(param_counts, (count + 1) * sizeof(int));
            variants[count] = var_name;
            param_counts[count] = param_count;
            count++;
            if (strcmp(peek()->value, ",") == 0) {
                consume();
            } else if (strcmp(peek()->value, "}") == 0) {
                break;
            } else {
                error_at(peek()->line, peek()->col, "期望 ',' 或 '}'");
            }
        }
        expect("}");

        EnumInfo info;
        info.variants.reserve(count);
        info.param_counts.reserve(count);
        for (int i = 0; i < count; i++) {
            info.variants.push_back(variants[i]);
            info.param_counts.push_back(param_counts[i]);
        }
        enum_table[type_key(name)] = std::move(info);

        ASTNode* node = new_node(NODE_ENUM_DEF);
        node->data.enum_def.name = name;
        node->data.enum_def.variants = variants;
        node->data.enum_def.variant_param_counts = param_counts;
        node->data.enum_def.variant_count = count;
        return node;
    }

    // ---- 缩进模式 ----
    int base_indent = g_stmt_start_col - 1;  // 以 `aufz` 关键字所在列为基准
    char** variants = NULL;
    int* param_counts = NULL;
    int count = 0;

    while (peek()->type != TOK_EOF) {
        int cur_indent = peek()->col - 1;
        if (cur_indent <= base_indent) {
            break;  // 缩进回退或持平，枚举定义结束
        }

        // 在当前缩进块内，连续解析变体（支持逗号分隔）
        while (true) {
            if (peek()->type == TOK_EOF) break;
            int indent = peek()->col - 1;
            if (indent <= base_indent) break;          // 缩进回退，结束
            if (peek()->type != TOK_IDENT) break;      // 非标识符，结束

            Token* var_tok = consume();
            char* var_name = strdup(var_tok->value);
            int param_count = 0;

            // 可选参数列表
            if (strcmp(peek()->value, "(") == 0) {
                consume();
                if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                    while (true) {
                        Token* p = consume();
                        if (p->type != TOK_IDENT)
                            error_at(p->line, p->col, "期望参数名");
                        param_count++;
                        if (strcmp(peek()->value, ",") == 0) {
                            consume();
                            continue;
                        } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                            break;
                        } else {
                            error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                        }
                    }
                }
                expect(")");
            }

            variants = (char**)realloc(variants, (count + 1) * sizeof(char*));
            param_counts = (int*)realloc(param_counts, (count + 1) * sizeof(int));
            variants[count] = var_name;
            param_counts[count] = param_count;
            count++;

            // 检查是否跟着逗号（同行分隔符）
            if (strcmp(peek()->value, ",") == 0) {
                consume();  // 消费逗号
                // 如果逗号后直接结束了枚举块（文件结束或缩进回退），视为尾随逗号，允许
                if (peek()->type == TOK_EOF || peek()->col - 1 <= base_indent) {
                    break;  // 跳出内层循环，结束变体解析
                }
                // 否则，下一个 token 必须是标识符（变体名），否则报错
                if (peek()->type != TOK_IDENT) {
                    error_at(peek()->line, peek()->col, "逗号后必须紧跟枚举变体名称");
                }
                continue;  // 继续解析下一个变体
            } else {
                // 没有逗号时，下一个 token 必须在新行，或缩进回退/EOF
                if (peek()->type != TOK_EOF && peek()->line == var_tok->line) {
                    error_at(peek()->line, peek()->col, "枚举变体后期望 ',' 或换行");
                }
                break;
            }
        }
    }

    // 存入枚举表
    EnumInfo info;
    info.variants.reserve(count);
    info.param_counts.reserve(count);
    for (int i = 0; i < count; i++) {
        info.variants.push_back(variants[i]);
        info.param_counts.push_back(param_counts[i]);
    }
    enum_table[type_key(name)] = std::move(info);

    ASTNode* node = new_node(NODE_ENUM_DEF);
    node->data.enum_def.name = name;
    node->data.enum_def.variants = variants;
    node->data.enum_def.variant_param_counts = param_counts;
    node->data.enum_def.variant_count = count;
    return node;
}

 ASTNode* parse_pattern() {
    Token* t = peek();
    if (t->type == TOK_NUMBER) {
        consume();
        ASTNode* node = new_node(NODE_PATTERN_CONSTANT);
        const char* str = t->value;
        bool is_float = (strchr(str, '.') != NULL || strchr(str, 'e') != NULL || strchr(str, 'E') != NULL ||
                         strchr(str, 'p') != NULL || strchr(str, 'P') != NULL);
        if (is_float) {
            // 浮点数只支持十进制（可扩展十六进制浮点，但模式匹配较少用）
            mpf_t f;
            mpf_init(f);
            if (mpf_set_str(f, str, 10) != 0) {
                mpf_clear(f);
                kr_error("无效的浮点数常量");
            }
            node->data.pattern_constant.constant = make_float(f);
            mpf_clear(f);
        } else {
            int base = 10;
            const char* num_start = str;
            if (strncmp(str, "0x", 2) == 0 || strncmp(str, "0X", 2) == 0) {
                base = 16;
                num_start = str + 2;
            } else if (strncmp(str, "0b", 2) == 0 || strncmp(str, "0B", 2) == 0) {
                base = 2;
                num_start = str + 2;
            } else if (strncmp(str, "0o", 2) == 0 || strncmp(str, "0O", 2) == 0) {
                base = 8;
                num_start = str + 2;
            }
            mpz_t z;
            mpz_init(z);
            if (mpz_set_str(z, num_start, base) != 0) {
                mpz_clear(z);
                kr_error("无效的整数常量");
            }
            node->data.pattern_constant.constant = make_int_auto(z); // 自动选择 int64 或大整数
            mpz_clear(z);
        }
        return node;
    }
    if (t->type == TOK_REGEX) { // 字符串
        consume();
        size_t unesc_len = 0;
        char* unescaped = unescape_string(t->value, &unesc_len);
        ASTNode* node = new_node(NODE_PATTERN_CONSTANT);
        node->data.pattern_constant.constant = make_string_len(unescaped, unesc_len);
        free(unescaped);
        return node;
    }
    if (t->type == TOK_IDENT) {
        consume();
        char* name = strdup(t->value);

        if (strcmp(name, "_") == 0) {
            ASTNode* node = new_node(NODE_PATTERN_BIND);
            node->data.pattern_bind.name = strdup("_");  // 标记为通配符
            return node;
        }

        // 大写开头 => 变体模式
        if (isupper(name[0])) {
            ASTNode* node = new_node(NODE_PATTERN_VARIANT);
            node->data.pattern_variant.tag = name;
            node->data.pattern_variant.params = NULL;
            node->data.pattern_variant.param_count = 0;
            if (strcmp(peek()->value, "(") == 0) {
                consume();
                if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                    while (true) {
                        Token* p = consume();
                        if (p->type != TOK_IDENT)
                            error_at(p->line, p->col, "期望参数名");
                        node->data.pattern_variant.params = (char**)realloc(
                            node->data.pattern_variant.params,
                            (node->data.pattern_variant.param_count + 1) * sizeof(char*)
                        );
                        node->data.pattern_variant.params[node->data.pattern_variant.param_count++] = strdup(p->value);
                        if (strcmp(peek()->value, ",") == 0) consume();
                        else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) break;
                        else error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                    }
                }
                expect(")");
            }
            return node;
        } else {
            // 小写开头 => 变量绑定
            ASTNode* node = new_node(NODE_PATTERN_BIND);
            node->data.pattern_bind.name = name;
            return node;
        }
    } else if (strcmp(t->value, "{") == 0) {
        consume();
        ASTNode* node = new_node(NODE_PATTERN_OBJECT);
        node->data.pattern_object.keys = NULL;
        node->data.pattern_object.count = 0;
        if (strcmp(peek()->value, "}") != 0) {
            while (true) {
                Token* key_tok = consume();
                if (key_tok->type != TOK_IDENT)
                    error_at(key_tok->line, key_tok->col, "期望标识符作为键");
                node->data.pattern_object.keys = (char**)realloc(
                    node->data.pattern_object.keys,
                    (node->data.pattern_object.count + 1) * sizeof(char*)
                );
                node->data.pattern_object.keys[node->data.pattern_object.count++] = strdup(key_tok->value);
                if (strcmp(peek()->value, ",") == 0) consume();
                else if (strcmp(peek()->value, "}") == 0) break;
                else error_at(peek()->line, peek()->col, "期望 ',' 或 '}'");
            }
        }
        expect("}");
        return node;
    } else {
        error_at(t->line, t->col, "无效的模式");
        return NULL;
    }
 }

// 解析一个或多个由 '|' 分隔的模式，返回模式节点（单个或 NODE_PATTERN_OR）
ASTNode* parse_pattern_list() {
    ASTNode* first = parse_pattern();
    if (strcmp(peek()->value, "|") != 0) {
        return first;   // 单个模式
    }
    // 收集所有模式
    std::vector<ASTNode*> patterns;
    patterns.push_back(first);
    while (strcmp(peek()->value, "|") == 0) {
        consume(); // 消费 '|'
        ASTNode* next = parse_pattern();
        patterns.push_back(next);
    }
    // 创建 OR 节点
    ASTNode* or_node = new_node(NODE_PATTERN_OR);
    or_node->data.pattern_or.count = patterns.size();
    or_node->data.pattern_or.patterns = (ASTNode**)malloc(patterns.size() * sizeof(ASTNode*));
    for (size_t i = 0; i < patterns.size(); ++i) {
        or_node->data.pattern_or.patterns[i] = patterns[i];
    }
    return or_node;
}

// 前向声明
static ASTNode* parse_interp_add_sub(const char* s, int* pos);
static Value* get_mutable_ptr(ASTNode* node);

// ---------- 独立插值表达式解析器 ----------
static void skip_ws(const char* s, int* pos) {
    while (s[*pos] && isspace((unsigned char)s[*pos])) (*pos)++;
}

// 前向声明
static ASTNode* parse_interp_add_sub(const char* s, int* pos);

// 解析参数列表（用逗号分隔）
static ASTNode** parse_interp_args(const char* s, int* pos, int* arg_count) {
    ASTNode** args = NULL;
    *arg_count = 0;
    skip_ws(s, pos);
    if (s[*pos] == ')') {
        (*pos)++;
        return args; // 无参数
    }
    while (1) {
        ASTNode* arg = parse_interp_add_sub(s, pos);
        args = (ASTNode**)realloc(args, (*arg_count + 1) * sizeof(ASTNode*));
        args[*arg_count] = arg;
        (*arg_count)++;
        skip_ws(s, pos);
        if (s[*pos] == ',') {
            (*pos)++;
            continue;
        } else if (s[*pos] == ')') {
            (*pos)++;
            break;
        } else {
            kr_error("参数列表期望 ',' 或 ')'\n");
            
        }
    }
    return args;
}

static ASTNode* parse_interp_primary(const char* s, int* pos) {
    skip_ws(s, pos);
    char c = s[*pos];
    ASTNode* node = NULL;

    // ---------- 颜色字面量 ----------
    if (c == '#') {
        (*pos)++; // 跳过 '#'
        const char* start = s + *pos;

        if (strncmp(s + *pos, "zurück", 7) == 0) {
            *pos += 7;
            node = new_node(NODE_STRING);
            node->data.string = strdup("\033[0m");
            return node;
        }
        if (strncmp(s + *pos, "end", 3) == 0) {
            *pos += 3;
            node = new_node(NODE_STRING);
            node->data.string = strdup("\033[0m");
            return node;
        }

        // 否则读取十六进制颜色（#RGB 或 #RRGGBB）
        int len = 0;
        while (isxdigit((unsigned char)s[*pos])) {
            (*pos)++;
            len++;
        }
        if (len != 3 && len != 6) {
            kr_error("颜色必须为 #RGB 或 #RRGGBB（如 #F00 或 #FF0000）\n");
            
        }
        char hex[7];
        strncpy(hex, start, len);
        hex[len] = '\0';
        int r, g, b;
        if (len == 3) {
            char full[7];
            full[0] = hex[0]; full[1] = hex[0];
            full[2] = hex[1]; full[3] = hex[1];
            full[4] = hex[2]; full[5] = hex[2];
            full[6] = '\0';
            sscanf(full, "%02x%02x%02x", &r, &g, &b);
        } else {
            sscanf(hex, "%02x%02x%02x", &r, &g, &b);
        }
        char ansi[32];
        snprintf(ansi, sizeof(ansi), "\033[38;2;%d;%d;%dm", r, g, b);
        char* ansi_str = strdup(ansi);
        node = new_node(NODE_STRING);
        node->data.string = ansi_str;
        return node;
    }
    
    if (c == '(') {
        (*pos)++;                      // 跳过 '('
        skip_ws(s, pos);               // 跳过内部空白
    
        // ---- 空括号 () ----
        if (s[*pos] == ')') {
            (*pos)++;
            node = new_node(NODE_NULL);
            return parse_interp_postfix(s, pos, node);
        }
    
        // ---- 非空括号：提取子表达式 ----
        int depth = 1;
        int sub_start = *pos;          // 子表达式开始位置（跳过 '(' 和空白后）
        while (s[*pos] && depth > 0) {
            // 处理转义（虽然括号内不太需要，但保留兼容性）
            if (s[*pos] == '\\' && s[*pos + 1]) {
                (*pos) += 2;
                continue;
            }
            if (s[*pos] == '(') depth++;
            else if (s[*pos] == ')') depth--;
            (*pos)++;
        }
        if (depth != 0) {
            kr_error("插值表达式括号不匹配\n");
        }
    
        // sub_end 指向匹配的 ')' 的位置，子串范围 [sub_start, sub_end)
        int sub_end = *pos - 1;
        int sub_len = sub_end - sub_start;
        char* sub_expr = (char*)malloc(sub_len + 1);
        memcpy(sub_expr, s + sub_start, sub_len);
        sub_expr[sub_len] = '\0';
    
        // 解析子表达式（递归调用现有的解析器）
        node = parse_interp_expression(sub_expr);
        free(sub_expr);
    
        // 此时 *pos 已经指向 ')' 之后的字符（因为循环结束时 *pos 在 ')' 后面）
        // 继续处理后缀运算符（如 °）
        return parse_interp_postfix(s, pos, node);
    } else if (c == '"' || c == '\'') {
        // 字符串字面量（支持单双引号）
        char quote = c;
        (*pos)++;
        const char* start = s + *pos;
        while (s[*pos] && s[*pos] != quote) {
            if (s[*pos] == '\\' && s[*pos+1]) (*pos) += 2;
            else (*pos)++;
        }
        if (s[*pos] != quote) {
            kr_error("插值字符串未终止\n");
            
        }
        int len = *pos - (int)(start - s);
        char* str = (char*)malloc(len + 1);
        memcpy(str, start, len);
        str[len] = '\0';
        size_t unesc_len = 0;
        char* unescaped = unescape_string(str, &unesc_len);
        free(str);
        node = new_node(NODE_STRING);
        node->data.string = unescaped;
        node->string_len = unesc_len;
        (*pos)++; // 跳过结束引号
    } else if (isdigit(c) || (c == '-' && isdigit(s[*pos + 1]))) {
        const char* start = s + *pos;
        if (c == '-') (*pos)++; // 跳过负号，保留在字符串中
        // 解析整数部分（允许下划线分隔符，如 1_000_000）
        while (isdigit(s[*pos]) || s[*pos] == '_') (*pos)++;
        bool is_float = false;
        // 仅当小数点后紧跟数字时才视为浮点数
        if (s[*pos] == '.' && isdigit(s[*pos + 1])) {
            is_float = true;
            (*pos)++; // 跳过 '.'
            while (isdigit(s[*pos]) || s[*pos] == '_') (*pos)++;
            // 处理科学计数法（可选）
            if (s[*pos] == 'e' || s[*pos] == 'E') {
                (*pos)++;
                if (s[*pos] == '+' || s[*pos] == '-') (*pos)++;
                while (isdigit(s[*pos]) || s[*pos] == '_') (*pos)++;
            }
        }
        int raw_len = *pos - (int)(start - s);
        char* raw = (char*)malloc(raw_len + 1);
        strncpy(raw, start, raw_len);
        raw[raw_len] = '\0';
        // 去除下划线（与主词法分析器 tokenize_impl 保持一致）
        char* str = (char*)malloc(raw_len + 1);
        int j = 0;
        for (int i = 0; i < raw_len; ++i) {
            if (raw[i] != '_') str[j++] = raw[i];
        }
        str[j] = '\0';
        free(raw);
        if (is_float) {
            node = new_node(NODE_FLOAT);
            node->data.float_str = str; // 原始字符串（已去下划线）
        } else {
            node = new_node(NODE_NUMBER);
            node->data.number_str = str;
        }
        return parse_interp_postfix(s, pos, node);
    } else if (is_ident_start(c)) {
        const char* start = s + *pos;
        while (is_ident_char(s[*pos])) (*pos)++;
        char* name = (char*)malloc(*pos - (int)(start - s) + 1);
        memcpy(name, start, *pos - (int)(start - s));
        name[*pos - (int)(start - s)] = '\0';
        skip_ws(s, pos);
        if (s[*pos] == '(') {
            // 函数调用
            (*pos)++; // 跳过 '('
            int arg_count;
            ASTNode** args = parse_interp_args(s, pos, &arg_count);
            node = new_node(NODE_FUNC_CALL);
            node->data.func_call.name = name;
            node->data.func_call.args = args;
            node->data.func_call.arg_count = arg_count;
        } else {
            node = new_node(NODE_VARIABLE, 0, 0);
            node->data.var_name = name;
        }
    } else {
        kr_error("插值表达式语法错误: 意外的字符 '%c' (ASCII %d)\n", c, (int)(unsigned char)c);
        
    }
    // 后缀处理（属性、索引、方法调用）
    return parse_interp_postfix(s, pos, node);
}

static ASTNode* parse_interp_postfix(const char* s, int* pos, ASTNode* left) {
    while (1) {
        skip_ws(s, pos);
        char c = s[*pos];
        if (c == '.') {
            (*pos)++;
            skip_ws(s, pos);
            if (!is_ident_start(s[*pos])) {
                kr_error("属性名必须以字母或下划线开头\n");
                
            }
            const char* start = s + *pos;
            while (is_ident_char(s[*pos])) (*pos)++;
            char* key = (char*)malloc(*pos - (int)(start - s) + 1);
            memcpy(key, start, *pos - (int)(start - s));
            key[*pos - (int)(start - s)] = '\0';
            skip_ws(s, pos);
            if (s[*pos] == '(') {
                // 方法调用
                (*pos)++;
                int arg_count;
                ASTNode** args = parse_interp_args(s, pos, &arg_count);
                ASTNode* node = new_node(NODE_METHOD_CALL);
                node->data.method_call.obj = left;
                node->data.method_call.method = key;
                node->data.method_call.args = args;
                node->data.method_call.arg_count = arg_count;
                left = node;
            } else {
                // 普通属性访问
                ASTNode* node = new_node(NODE_OBJECT_ACCESS);
                node->data.object_access.obj = left;
                node->data.object_access.key = key;
                node->data.object_access.is_optional = false;
                left = node;
            }
        } else if (c == '[') {
            (*pos)++;
            ASTNode* index = parse_interp_add_sub(s, pos);
            skip_ws(s, pos);
            if (s[*pos] != ']') {
                kr_error("索引表达式缺少 ']'\n");
                
            }
            (*pos)++;
            ASTNode* node = new_node(NODE_ARRAY_ACCESS);
            node->data.array_access.array = left;
            node->data.array_access.index = index;
            left = node;
        } else if (strncmp(s + *pos, "!!", 2) == 0) {
            (*pos) += 2;
            ASTNode* node = new_node(NODE_DOUBLE_FACTORIAL);
            node->data.inc_dec.operand = left;
            left = node;
        } else if ((unsigned char)s[*pos] == 0xC2 && (unsigned char)s[*pos+1] == 0xB0) {
            (*pos) += 2;
            ASTNode* node = new_node(NODE_DEGREE);
            node->data.inc_dec.operand = left;
            left = node;
        } else if (c == '!') {
            if (s[*pos + 1] == '!') {
                (*pos) += 2;
                ASTNode* node = new_node(NODE_DOUBLE_FACTORIAL);
                node->data.inc_dec.operand = left;
                left = node;
            } else {
                (*pos)++;
                ASTNode* node = new_node(NODE_FACTORIAL);
                node->data.inc_dec.operand = left;
                left = node;
            }
        } else {
            break;
        }
    }
    return left;
}

static ASTNode* parse_interp_mul_div(const char* s, int* pos) {
    ASTNode* left = parse_interp_primary(s, pos);
    while (1) {
        skip_ws(s, pos);
        char op = s[*pos];
        if (op != '*' && op != '/') break;
        (*pos)++;
        ASTNode* right = parse_interp_primary(s, pos);
        ASTNode* node = new_node(NODE_BINARY);
        node->data.binary.left = left;
        node->data.binary.right = right;
        node->data.binary.op = op;
        left = node;
    }
    return left;
}

static ASTNode* parse_interp_add_sub(const char* s, int* pos) {
    // 处理一元负号
    skip_ws(s, pos);
    if (s[*pos] == '-') {
        (*pos)++;
        ASTNode* operand = parse_interp_add_sub(s, pos);
        ASTNode* node = new_node(NODE_BINARY);
        node->data.binary.left = new_node(NODE_NUMBER);
        node->data.binary.left->data.number_str = strdup("0");
        node->data.binary.right = operand;
        node->data.binary.op = '-';
        return node;
    }
    ASTNode* left = parse_interp_mul_div(s, pos);
    while (1) {
        skip_ws(s, pos);
        char op = s[*pos];
        if (op != '+' && op != '-') break;
        (*pos)++;
        ASTNode* right = parse_interp_mul_div(s, pos);
        ASTNode* node = new_node(NODE_BINARY);
        node->data.binary.left = left;
        node->data.binary.right = right;
        node->data.binary.op = op;
        left = node;
    }
    return left;
}

static ASTNode* parse_interp_expression(const char* src) {
    // 先对插值表达式进行宏展开
    std::unordered_map<size_t, int> dummy;          // 空的行号映射即可
    std::string expanded = expand_macros(std::string(src), dummy);

    int pos = 0;
    ASTNode* node = parse_interp_add_sub(expanded.c_str(), &pos);
    skip_ws(expanded.c_str(), &pos);
    if (expanded[pos] != '\0') {
        kr_error("插值表达式包含多余字符: '%s'\n", expanded.c_str() + pos);
    }
    return node;
}

// 转义格式字符串中的反斜杠和双引号
static std::string escape_format_string(const std::string& s) {
    std::string out;
    for (char c : s) {
        if (c == '\\' || c == '"') out.push_back('\\');
        out.push_back(c);
    }
    return out;
}

// 处理插值表达式，如果存在格式说明则转换为 expr.alt("format")
static std::string process_interp_expr(const char* expr_src) {
    int depth = 0;
    bool in_string = false;
    bool in_char = false;
    bool escape = false;
    int colon_pos = -1;
    int i = 0;
    while (expr_src[i]) {
        if (escape) { escape = false; i++; continue; }
        if (expr_src[i] == '\\') { escape = true; i++; continue; }
        if (!in_string && !in_char) {
            if (expr_src[i] == '"') { in_string = true; i++; continue; }
            if (expr_src[i] == '\'') { in_char = true; i++; continue; }
            if (expr_src[i] == '(') { depth++; i++; continue; }
            if (expr_src[i] == ')') { if (depth > 0) depth--; i++; continue; }
            if (expr_src[i] == ':' && depth == 0) {
                colon_pos = i;
                break;
            }
        } else {
            if (in_string && expr_src[i] == '"') in_string = false;
            if (in_char && expr_src[i] == '\'') in_char = false;
        }
        i++;
    }

    if (colon_pos == -1)
        return std::string(expr_src);

    std::string expr_part(expr_src, expr_src + colon_pos);
    std::string format_part(expr_src + colon_pos + 1);

    // ---------- 1. 定位对齐段 [align][width] ----------
    int align_idx = -1;
    char align_char = '\0';
    for (int k = 0; k < (int)format_part.size(); ++k) {
        char c = format_part[k];
        if (c == '<' || c == '>' || c == '^') {
            if (k + 1 < (int)format_part.size()) {
                bool all_digits = true;
                for (int j = k + 1; j < (int)format_part.size(); ++j) {
                    if (!std::isdigit((unsigned char)format_part[j])) {
                        all_digits = false;
                        break;
                    }
                }
                if (all_digits) {
                    align_idx = k;
                    align_char = c;
                }
            }
            break;
        }
    }

    // ---------- 2. 无对齐段：整段作为 alt 格式 ----------
    if (align_idx == -1) {
        std::string escaped = escape_format_string(format_part);
        // 关键：必须给表达式加括号
        return "(" + expr_part + ").alt(\"" + escaped + "\")";
    }

    // ---------- 3. 分析 fill ----------
    char fill_char = '\0';
    bool has_fill = false;
    int alt_end = align_idx;

    if (align_idx > 0) {
        char prev = format_part[align_idx - 1];
        bool prev_is_alpha = std::isalpha((unsigned char)prev) != 0;
        bool prev_is_digit = std::isdigit((unsigned char)prev) != 0;
        bool prev_digit_preceded_by_digit =
            prev_is_digit && align_idx >= 2 &&
            std::isdigit((unsigned char)format_part[align_idx - 2]) != 0;

        if (!prev_is_alpha && !prev_digit_preceded_by_digit) {
            fill_char = prev;
            has_fill = true;
            alt_end = align_idx - 1;
        }
    }

    // ---------- 4. 提取 alt 段和宽度 ----------
    std::string alt_part  = format_part.substr(0, alt_end);
    std::string width_str = format_part.substr(align_idx + 1);

    const char* richtung =
        (align_char == '<') ? "r" :
        (align_char == '>') ? "l" :
                              "c";

    // ---------- 5. 组装方法调用链 ----------
    // 关键：必须给表达式加括号
    std::string result = "(" + expr_part + ")";

    if (!alt_part.empty()) {
        std::string escaped_alt = escape_format_string(alt_part);
        result += ".alt(\"" + escaped_alt + "\")";
    }

    result += ".füll(" + width_str + ", \"" + std::string(richtung) + "\"";

    if (has_fill) {
        std::string fill_lit;
        if (fill_char == '"' || fill_char == '\\') fill_lit += '\\';
        fill_lit += fill_char;
        result += ", \"" + fill_lit + "\"";
    }

    result += ")";
    return result;
}
 
 ASTNode* parse_primary() {
    Token* t = peek();
    
    // ----- 对象字面量 { key: val, ... } -----
    if (strcmp(t->value, "{") == 0) {
        // 快速检测空对象
        if (tok_pos + 1 < token_count && strcmp(tokens[tok_pos + 1].value, "}") == 0) {
            consume(); consume();
            ASTNode* node = new_node(NODE_OBJECT_LITERAL);
            node->data.object_lit.key_exprs = NULL;
            node->data.object_lit.vals = NULL;
            node->data.object_lit.spreads = NULL;
            node->data.object_lit.count = 0;
            node->data.object_lit.spread_count = 0;
            return node;
        }
    
        int save_pos = tok_pos;
        consume(); // 消费 '{'
        ASTNode* obj_node = parse_object_literal();
        if (obj_node == nullptr) {
            // 遇到对象推导式，回退并重新解析
            tok_pos = save_pos;
            consume(); // 重新消费 '{'
            return parse_object_comprehension();
        }
        return obj_node;
    }

    if (strcmp(peek()->value, "warte") == 0 && peek()->type == TOK_KEYWORD) {
        consume();
        ASTNode* expr = parse_expression();          // 基础表达式
        ASTNode* timeout_expr = nullptr;
        ASTNode* fallback_expr = nullptr;
    
        // 可选：检测 "mit" 子句（超时）
        if (strcmp(peek()->value, "mit") == 0) {
            consume();
            if (strcmp(peek()->value, "Zeit") == 0) {
                consume();
                timeout_expr = parse_expression();   // 解析超时数值（毫秒）
            } else {
                error_at(peek()->line, peek()->col, "期望 'Zeit' 关键字");
            }
        }
    
        // 可选：检测 "sonst" 子句（备用值）
        if (strcmp(peek()->value, "sonst") == 0) {
            consume();
            fallback_expr = parse_expression();
        }
    
        ASTNode* node = new_node(NODE_AWAIT);
        node->data.await.expr = expr;
        node->data.await.timeout = timeout_expr;
        node->data.await.fallback = fallback_expr;
        return node;
    }
    
    // ----- 数字（整数或浮点数）-----
    if (t->type == TOK_NUMBER) {
        consume();
        const char* val = t->value;
        
        // 判断是否为十六进制整数（不以 0x/0X 开头且无 '.' 和 'p'/'P'）
        bool is_hex_int = false;
        if ((strncmp(val, "0x", 2) == 0 || strncmp(val, "0X", 2) == 0) &&
            !strchr(val, '.') && !strchr(val, 'p') && !strchr(val, 'P')) {
            is_hex_int = true;
        }
        
        bool is_float = (!is_hex_int) && (strchr(val, '.') != NULL ||
                         strchr(val, 'e') != NULL ||
                         strchr(val, 'E') != NULL ||
                         strchr(val, 'p') != NULL ||
                         strchr(val, 'P') != NULL);
        if (is_float) {
            ASTNode* node = new_node(NODE_FLOAT);
            node->data.float_str = strdup(val);
            return node;
        } else {
            ASTNode* node = new_node(NODE_NUMBER);
            node->data.number_str = strdup(val);
            return node;
        }
    }
    
    else if (t->type == TOK_REGEX) {
        consume();
        char* raw = t->value;
    
        // 1. 原始字符串（反引号）
        if (t->flags && strcmp(t->flags, "raw") == 0) {
            char* content = strdup(raw);
            // 检查是否包含插值标记 &{
            bool has_interp = false;
            for (const char* p = content; *p; ++p) {
                if (*p == '&' && *(p+1) == '{') { has_interp = true; break; }
            }
            if (has_interp) {
                ASTNode* interp_node = parse_backtick_interp(content);
                free(content);
                return interp_node;
            } else {
                ASTNode* node = new_node(NODE_STRING);
                node->data.string = content;  // 直接接管
                node->string_len = strlen(content);
                return node;
            }
        }

        if (t->flags && strcmp(t->flags, "uraw") == 0) {
            char* content = strdup(raw);
            ASTNode* node = new_node(NODE_STRING);
            node->data.string = content;  // 直接接管
            node->string_len = strlen(content);
            return node;
        }

        if (t->flags && strcmp(t->flags, "bytes") == 0) {
            char* content = strdup(raw);
            ASTNode* str_node = new_node(NODE_STRING);
            str_node->data.string = content;
            str_node->string_len = strlen(content);
        
            ASTNode* call_node = new_node(NODE_FUNC_CALL, t->line, t->col);
            call_node->data.func_call.name = strdup("bytes");
            call_node->data.func_call.func_expr = NULL;
            call_node->data.func_call.args = (ASTNode**)malloc(sizeof(ASTNode*));
            call_node->data.func_call.args[0] = str_node;
            call_node->data.func_call.arg_count = 1;
        
            return call_node;
        }
        
        if (t->flags && strcmp(t->flags, "escape") == 0) {
            size_t seq_len = 0;
            char* ansi_buf = unescape_string(raw, &seq_len);
            if (!ansi_buf) {
                error_at(t->line, t->col, "escape字符串转义失败");
                return nullptr;
            }
            std::string ansi_seq(ansi_buf, seq_len);
            free(ansi_buf);
    
            std::string key_name = ansi_to_key_name(ansi_seq);
    
            ASTNode* node = new_node(NODE_STRING);
            char* content = strdup(key_name.c_str());
            node->data.string = content;
            node->string_len = key_name.size();
            return node;
        }  

        if (t->flags && strcmp(t->flags, "single") == 0) {
            size_t len = strlen(raw);
            ASTNode* node = new_node(NODE_STRING);
            node->data.string = strdup(raw);
            node->string_len = len;
            return node;
        }
    
        // 2. 正则字面量（flags 存在且不是 "raw"）
        if (t->flags != NULL) {
            char* flags = (strcmp(t->flags, "regex") == 0) ? strdup("") : strdup(t->flags);
            ASTNode* node = new_node(NODE_REGEX_LITERAL);
            node->data.regex_lit.pattern = strdup(raw);
            node->data.regex_lit.flags = flags;
            return node;
        }
    
        // 3. 双引号字符串（flags == NULL）—— 处理插值
        bool has_interp = false;
        for (const char* p = raw; *p; ++p) {
            if (*p == '\\' && *(p+1)) { p++; continue; }
            if (*p == '{') { has_interp = true; break; }
        }
        if (!has_interp) {
            size_t unesc_len = 0;
            char* unescaped = unescape_string(raw, &unesc_len);
            ASTNode* node = new_node(NODE_STRING);
            node->data.string = unescaped;
            node->string_len = unesc_len;
            return node;
        }
    
        // 构建插值节点
        ASTNode* interp = new_node(NODE_STRING_INTERP);
        interp->data.string_interp.fragments = NULL;
        interp->data.string_interp.count = 0;
    
        const char* p = raw;
        while (*p) {
            // 查找下一个非转义的 '{'
            const char* interp_start = p;
            while (*interp_start) {
                if (*interp_start == '\\' && *(interp_start+1)) {
                    interp_start += 2;   // 跳过转义序列
                    continue;
                }
                if (*interp_start == '{') break;
                interp_start++;
            }
    
            if (!*interp_start) {
                // 没有更多插值，剩余部分作为纯文本
                char* text = strdup(p);
                size_t unesc_len = 0;
                char* unescaped = unescape_string(text, &unesc_len);
                free(text);
                ASTNode* text_node = new_node(NODE_STRING);
                text_node->string_len = unesc_len;
                text_node->data.string = unescaped;
                interp->data.string_interp.fragments = (ASTNode**)realloc(
                    interp->data.string_interp.fragments,
                    (interp->data.string_interp.count + 1) * sizeof(ASTNode*)
                );
                interp->data.string_interp.fragments[interp->data.string_interp.count++] = text_node;
                break;
            }
    
            // 文本部分（从 p 到 interp_start，不含 '{'）
            if (interp_start > p) {
                char* text = (char*)malloc(interp_start - p + 1);
                memcpy(text, p, interp_start - p);
                text[interp_start - p] = '\0';
                size_t unesc_len = 0;
                char* unescaped = unescape_string(text, &unesc_len);
                free(text);
                ASTNode* text_node = new_node(NODE_STRING);
                text_node->string_len = unesc_len;
                text_node->data.string = unescaped;
                interp->data.string_interp.fragments = (ASTNode**)realloc(
                    interp->data.string_interp.fragments,
                    (interp->data.string_interp.count + 1) * sizeof(ASTNode*)
                );
                interp->data.string_interp.fragments[interp->data.string_interp.count++] = text_node;
            }
    
            // 跳过 '{'
            const char* expr_start = interp_start + 1;
    
            // 寻找匹配的 '}'，支持嵌套和转义
            int depth = 1;
            const char* expr_end = expr_start;
            while (*expr_end && depth > 0) {
                if (*expr_end == '\\' && *(expr_end+1)) {
                    expr_end += 2;
                    continue;
                }
                if (*expr_end == '{') depth++;
                else if (*expr_end == '}') depth--;
                expr_end++;
            }
            if (depth != 0) {
                error_at(t->line, t->col, "未终止的插值表达式，缺少 '}'");
            }
    
            // 提取表达式源码（不含花括号）
            int expr_len = expr_end - expr_start - 1; // 因为 expr_end 指向 '}' 后的下一个字符
            char* expr_src = (char*)malloc(expr_len + 1);
            memcpy(expr_src, expr_start, expr_len);
            expr_src[expr_len] = '\0';

            std::string processed_expr = process_interp_expr(expr_src);
            free(expr_src);
            ASTNode* expr_node = parse_interp_expression(processed_expr.c_str());
    
            interp->data.string_interp.fragments = (ASTNode**)realloc(
                interp->data.string_interp.fragments,
                (interp->data.string_interp.count + 1) * sizeof(ASTNode*)
            );
            interp->data.string_interp.fragments[interp->data.string_interp.count++] = expr_node;
    
            // 继续处理剩余部分
            p = expr_end;  // 现在指向 '}' 之后的字符
        }
    
        return interp;
    }
    
    // ----- 关键字 -----
    else if (t->type == TOK_KEYWORD) {
        if (strcmp(t->value, "null") == 0) {
            consume();
            return new_node(NODE_NULL);
        }
        else if (strcmp(t->value, "wahr") == 0) {
            consume();
            ASTNode* node = new_node(NODE_NUMBER);
            node->data.number_str = strdup("1");
            return node;
        }
        else if (strcmp(t->value, "fals") == 0) {
            consume();
            ASTNode* node = new_node(NODE_NUMBER);
            node->data.number_str = strdup("0");
            return node;
        }
        else if (strcmp(t->value, "fkt") == 0) {
            consume(); // 消费 'fkt'
        
            char* name = NULL;
            // 如果下一个 token 是标识符，则作为函数名
            if (peek()->type == TOK_IDENT) {
                Token* name_tok = consume();
                name = strdup(name_tok->value);
            }
        
            // 现在必须遇到 '('
            if (strcmp(peek()->value, "(") != 0) {
                if (name) free(name);
                g_last_error_line = peek()->line;
                g_last_error_col  = peek()->col;
                std::string hint = make_keyword_alias_hint("fkt", "fkt");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "fkt 定义后期望 '('");
            }
            expect("(");
        
            // ----- 使用 parse_param_list 解析参数列表 -----
            char** params = NULL;
            int param_count = 0;
            bool* param_is_const = NULL;
            ASTNode** param_defaults = NULL;
            TypeNode** param_types = NULL;
            char* vararg_name = NULL;
            TypeNode* vararg_type = nullptr;
            parse_param_list(&params, &param_count, &param_is_const, &param_defaults, &param_types, &vararg_name, &vararg_type);
            // parse_param_list 已消费 ')'
        
            // 可选的返回类型注解
            if (strcmp(peek()->value, ":") == 0) {
                consume();
                TypeNode* ann = parse_type_expr();
                free_type_node(ann);
            }
        
            // 解析函数体
            int base_indent = t->col - 1;
            ASTNode* body = parse_body_block(base_indent);
        
            // 创建 AST 节点
            ASTNode* node = new_node(NODE_FUNC_DEF);
            node->data.func_def.name = name;          // 可为 NULL
            node->data.func_def.params = params;
            node->data.func_def.param_count = param_count;
            node->data.func_def.body = body;
            node->data.func_def.is_memoized = false;
            node->data.func_def.global_scope = false;
            node->data.func_def.is_static = false;
            node->data.func_def.return_type = nullptr;
            node->data.func_def.vararg_name = vararg_name;
            node->data.func_def.param_is_const = param_is_const;
            node->data.func_def.param_defaults = param_defaults;
            node->data.func_def.param_types = param_types;
            node->data.func_def.vararg_type = vararg_type;
            node->data.func_def.is_stmt_func = false;
        
            return node;
        }
        else if (strcmp(t->value, "dies") == 0) {
            consume();
            return new_node(NODE_THIS);
        }
        else if (strcmp(t->value, "neu") == 0) {
            consume(); // 消费 'neu'
            if (strcmp(peek()->value, "=") == 0 || strcmp(peek()->value, "ist") == 0) {
                g_last_error_line = peek()->line;
                g_last_error_col  = peek()->col;
                std::string hint = make_keyword_alias_hint("neu", "neu");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "关键字 'neu' 不能被赋值");
            }
            Token* class_tok = consume();
            if (class_tok->type != TOK_IDENT)
                error_at(class_tok->line, class_tok->col, "期望类名");
            char* class_name = strdup(class_tok->value);
            expect("(");
            ASTNode** args = NULL;
            int arg_count = 0;
            if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                while (true) {
                    ASTNode* arg = parse_expression();
                    args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                    args[arg_count++] = arg;
                    if (strcmp(peek()->value, ",") == 0)
                        consume();
                    else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)
                        break;
                    else
                        error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                }
            }
            expect(")");
            ASTNode* node = new_node(NODE_NEW);
            node->data.new_expr.class_name = class_name;
            node->data.new_expr.args = args;
            node->data.new_expr.arg_count = arg_count;
            return node;
        }
        else if (strcmp(t->value, "als") == 0) {
            int als_col = t->col;
            int als_line = t->line;
            consume();  // 消费 "als"
            return parse_match_expression(als_col, als_line);
        }
        else {
            g_last_error_line = t->line;
            g_last_error_col  = t->col;
            std::string hint = make_keyword_alias_hint(t->value, t->value);
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                          "关键字 '%s' 不能出现在该位置", t->value);
            return NULL;
        }
    }
    // ----- 标识符（变量或函数调用）-----
    else if (t->type == TOK_IDENT) {
        Token* ident_tok = consume();
        char* name = strdup(ident_tok->value);
        if (strcmp(peek()->value, "(") == 0) {
            // 1) 宏展开（优先）
            if (macros.find(name) != macros.end()) {
                consume(); // '('
                std::vector<ASTNode*> args;
                if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                    while (true) {
                        ASTNode* arg = parse_expression();
                        args.push_back(arg);
                        if (strcmp(peek()->value, ",") == 0) consume();
                        else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) break;
                        else error_at(peek()->line, peek()->col, "期望 ',' 或 ')'");
                    }
                }
                expect(")");
                ASTNode* expanded = expand_macro(name, args, ident_tok->line, ident_tok->col);
                free(name);
                for (auto a : args) free_ast(a);
                return expanded;
            }

            // 2) 检查是否为类名 → 实例化
            {
                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                if (class_table.find(name) != class_table.end()) {
                    consume(); // '('
                    ASTNode** args = NULL;
                    int arg_count = 0;
                    if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                        while (true) {
                            ASTNode* arg = parse_expression();
                            args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                            args[arg_count++] = arg;
                            if (strcmp(peek()->value, ",") == 0) {
                                consume();
                            } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                                break;
                            } else {
                                error_at(peek()->line, peek()->col,
                                            "语法错误: 类实例化参数期望 ',' 或 ')'");
                            }
                        }
                    }
                    expect(")");
                    ASTNode* node = new_node(NODE_NEW, ident_tok->line, ident_tok->col);
                    node->data.new_expr.class_name = name;   // 接管 name
                    node->data.new_expr.args = args;
                    node->data.new_expr.arg_count = arg_count;
                    return node;
                }
            }

            // 3) 否则作为普通函数调用
            consume(); // '('
            ASTNode** args = NULL;
            int arg_count = 0;
            if (!(peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0)) {
                while (true) {
                    if (peek()->type == TOK_OP && strcmp(peek()->value, "...") == 0) {
                        consume();
                        ASTNode* spread_expr = parse_expression();
                        ASTNode* spread_node = new_node(NODE_SPREAD_ARG);
                        spread_node->data.spread.expr = spread_expr;
                        args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                        args[arg_count++] = spread_node;
                    } else {
                        ASTNode* arg = parse_expression();
                        args = (ASTNode**)realloc(args, (arg_count + 1) * sizeof(ASTNode*));
                        args[arg_count++] = arg;
                    }
                    if (strcmp(peek()->value, ",") == 0) {
                        consume();
                    } else if (peek()->type == TOK_SYMBOL && strcmp(peek()->value, ")") == 0) {
                        break;
                    } else {
                        error_at(peek()->line, peek()->col, "语法错误: 函数参数期望 ',' 或 ')'");
                    }
                }
            }
            expect(")");
            ASTNode* node = new_node(NODE_FUNC_CALL, ident_tok->line, ident_tok->col);
            node->data.func_call.name = name;          // 接管 name
            node->data.func_call.func_expr = NULL;
            node->data.func_call.args = args;
            node->data.func_call.arg_count = arg_count;
            return node;
        }
        else {
            // 变量引用
            ASTNode* node = new_node(NODE_VARIABLE, ident_tok->line, ident_tok->col);
            node->data.var_name = name;               // 接管 name
            return node;
        }
    }
    
    // ----- 括号表达式 -----
    else if (strcmp(t->value, "(") == 0) {
        consume();
        ASTNode* expr = parse_expression();
        expect(")");
        return expr;
    }
    
    // ----- 数组字面量或列表推导式 -----
    else if (strcmp(t->value, "[") == 0) {
        int save_pos = tok_pos;
        consume(); // 消费 '['
        // 检查是否为空数组
        if (strcmp(peek()->value, "]") == 0) {
            consume();
            ASTNode* node = new_node(NODE_ARRAY_LITERAL);
            node->data.array_lit.elems = NULL;
            node->data.array_lit.count = 0;
            return node;
        }
        // 如果第一个元素是展开运算符，则直接进入普通数组处理（不是列表推导式）
        bool is_spread_start = (strcmp(peek()->value, "...") == 0);
        if (!is_spread_start) {
            // 尝试解析一个表达式，判断是否为列表推导式
            ASTNode* test_expr = parse_expression();
            if (test_expr && strcmp(peek()->value, "für") == 0) {
                tok_pos = save_pos;
                free_ast(test_expr);
                return parse_list_comprehension();
            }
            // 普通数组字面量（非展开开头）
            tok_pos = save_pos;
            if (test_expr) free_ast(test_expr);
            consume(); // 重新消费 '['
        }
        // ========== 普通数组字面量处理 ==========
        ASTNode** elems = NULL;
        int count = 0;
        if (strcmp(peek()->value, "]") != 0) {
            while (true) {
                if (peek()->type == TOK_OP && strcmp(peek()->value, "...") == 0) {
                    consume();
                    ASTNode* spread_expr = parse_expression();
                    ASTNode* spread_node = new_node(NODE_SPREAD_ARRAY);
                    spread_node->data.spread.expr = spread_expr;
                    elems = (ASTNode**)realloc(elems, (count + 1) * sizeof(ASTNode*));
                    elems[count++] = spread_node;
                } else {
                    ASTNode* elem = parse_expression();
                    elems = (ASTNode**)realloc(elems, (count + 1) * sizeof(ASTNode*));
                    elems[count++] = elem;
                }
                if (strcmp(peek()->value, ",") == 0) {
                    consume();
                    continue;
                } else if (strcmp(peek()->value, "]") == 0) {
                    break;
                } else {
                    error_at(peek()->line, peek()->col, "语法错误: 数组字面量期望 ',' 或 ']'");
                    return NULL;
                }
            }
        }
        expect("]");
        ASTNode* node = new_node(NODE_ARRAY_LITERAL);
        node->data.array_lit.elems = elems;
        node->data.array_lit.count = count;
        return node;
    }
    
    // ----- 无效项 -----
    else {
        error_at(t->line, t->col, "语法错误: 无效的项 '%s'", t->value);
        return NULL;
    }
 }

  /* ========== 解释器 ========== */
  ASTNode* parse_term() {
    // 处理前缀一元运算符
    if (strcmp(peek()->value, "++") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* operand = parse_term();
        ASTNode* node = new_node(NODE_PRE_INC);
        node->data.inc_dec.operand = operand;
        return node;
    }
    if (strcmp(peek()->value, "--") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* operand = parse_term();
        ASTNode* node = new_node(NODE_PRE_DEC);
        node->data.inc_dec.operand = operand;
        return node;
    }
    if (strcmp(peek()->value, "+") == 0 && peek()->type == TOK_OP) {
        consume();
        return parse_term(); // 一元加，直接忽略
    }
    if (strcmp(peek()->value, "-") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* operand = parse_term();
        // 构建 0 - operand 节点
        ASTNode* node = new_node(NODE_BINARY);
        node->data.binary.left = new_node(NODE_NUMBER);
        node->data.binary.left->data.number_str = strdup("0");
        node->data.binary.right = operand;
        node->data.binary.op = '-';
        return node;
    }

    // primary + postfix + 乘方
    ASTNode* node = parse_primary();
    node = parse_postfix(node);
    if (strcmp(peek()->value, "^") == 0 && peek()->type == TOK_OP) {
        consume();
        ASTNode* right = parse_term();
        ASTNode* bin = new_node(NODE_BINARY);
        bin->data.binary.left = node;
        bin->data.binary.right = right;
        bin->data.binary.op = '^';
        node = bin;
    }
    return node;
 }

 std::string convert_ampersand_to_dollar(const std::string& pattern) {
    std::string result;
    for (size_t i = 0; i < pattern.size(); ++i) {
        if (pattern[i] == '\\' && i + 1 < pattern.size()) {
            // 保留转义序列（不处理其中的 &）
            result += pattern[i];
            result += pattern[i + 1];
            i++; // 跳过下一个字符
        } else if (pattern[i] == '&') {
            // 非转义的 & -> 转换为行尾锚点 $
            result += '$';
        } else {
            result += pattern[i];
        }
    }
    return result;
 }

static inline Value take_value(Value* v) {
    Value out = *v;
    v->type = VAL_NULL;   // 源置空，之后 free_value(v) 不会释放资源
    return out;
}

static inline void move_value(Value* dst, Value* src) {
    if (dst == src) return;
    free_value(dst);
    *dst = *src;
    src->type = VAL_NULL;
}

 // 调用一个函数值，传入参数数组，返回结果
 Value call_function_value(const Value& func, Value* args, int arg_count,
    ASTNode* call_node, bool move_args) {
    if (!call_node) call_node = g_current_eval_node;
    // 保存调用者文件名（此时 current_filename 尚未被修改）
    const char* caller_file = current_filename;
    // 压入调用帧（使用调用者文件名）
    CallStackGuard guard(g_call_stack,
                        call_node ? call_node->line : 0,
                        call_node ? call_node->col : 0,
                        caller_file);

    int saved_line = g_last_error_line;
    int saved_col = g_last_error_col;
    const char* saved_filename = g_last_error_filename;
    if (call_node) {
        g_last_error_line = call_node->line;
        g_last_error_col = call_node->col;
        static thread_local std::string filename_storage;
        filename_storage = caller_file ? caller_file : current_filename;
        g_last_error_filename = filename_storage.c_str();
    }

    // ---- 保存旧控制标志（深拷贝） ----
    struct SavedFlags {
        bool return_caught, break_caught, continue_caught, exception_raised;
        Value return_value, exception_value;
    };
    SavedFlags saved = {
        return_caught,
        break_caught,
        continue_caught,
        exception_raised,
        take_value(&return_value),
        take_value(&exception_value)
    };

    // ---- 保存旧上下文 ----
    Scope* old_scope = current_scope;
    char* old_func_name = current_func_name;
    const Value* old_func_value = current_func_value;
    Value* old_constructed_obj = current_constructed_obj;
    Value* old_return_slot = g_current_return_slot;

    // ---- 设置当前函数上下文（被调用函数） ----
    if (func.func_val.name) {
        current_func_name = func.func_val.name;
        current_func_value = &func;
    } else {
        current_func_name = nullptr;
        current_func_value = nullptr;
    }
    current_constructed_obj = nullptr;

    // ---- 参数校验 ----
    int fixed_param_count = func.func_val.param_count;
    bool has_vararg = (func.func_val.vararg_name != nullptr);

    const char* fname = func.func_val.name ? func.func_val.name : "anonym";
    if (has_vararg) {
        if (arg_count < fixed_param_count)
            kr_error("函数 '%s' 参数数量不足: 期望至少 %d, 实际 %d", fname, fixed_param_count, arg_count);
    } else {
        if (arg_count > fixed_param_count)
            kr_error("函数 '%s' 参数数量过多: 期望 %d, 实际 %d", fname, fixed_param_count, arg_count);
        for (int i = arg_count; i < fixed_param_count; ++i) {
            if (!func.func_val.param_defaults[i])
                kr_error("函数 '%s' 缺少参数 '%s' 且无默认值", fname, func.func_val.params[i]);
        }
    }
    if (func.func_val.name) {
        std::lock_guard<std::mutex> lock(functions_mutex);
        if (g_marked_funcs_called.find(func.func_val.name) == g_marked_funcs_called.end()) {
            for (int i = 0; i < func_count; ++i) {
                if (strcmp(functions[i].name, func.func_val.name) == 0) {
                    functions[i].called = true;
                    g_marked_funcs_called.insert(func.func_val.name);
                    break;
                }
            }
        }
    }

    // ---- 创建局部作用域 ----
    push_scope();
    current_scope->parent = func.func_val.global_scope ? get_global_scope() : func.func_val.closure_scope;

    // ---- 声明固定参数（零参数函数直接跳过，省掉循环初始化） ----
    if (fixed_param_count > 0) {
        for (int i = 0; i < fixed_param_count; ++i) {
            Value arg_val;
            if (i < arg_count) {
                arg_val = move_args ? take_value(&args[i]) : copy_value(args[i]);
            } else {
                arg_val = eval_expr(func.func_val.param_defaults[i]);
            }
            if (func.func_val.param_types && func.func_val.param_types[i]) {
                if (!check_type(func.func_val.param_types[i], arg_val)) {
                    std::string expected = type_to_string(func.func_val.param_types[i]);
                    char* got = value_to_string(arg_val);
                    std::string msg = "参数 '" + std::string(func.func_val.params[i]) +
                                    "' 类型错误: 期望 '" + expected + "', 实际 '" + got + "'";
                    free(got);
                    free_value(&arg_val);
                    kr_error("%s", msg.c_str());
                }
            }
            declare_var_in_scope(current_scope, func.func_val.params[i], false, arg_val);
        }
    }

    // ---- 可变参数 ----
    if (has_vararg) {
        int vararg_count = arg_count - fixed_param_count;
        Value* elems = (Value*)malloc(vararg_count * sizeof(Value));
        for (int i = 0; i < vararg_count; ++i) {
            elems[i] = copy_value(args[fixed_param_count + i]);
            if (func.func_val.vararg_type) {
                if (!check_type(func.func_val.vararg_type, elems[i])) {
                    std::string expected = type_to_string(func.func_val.vararg_type);
                    char* got = value_to_string(elems[i]);
                    kr_error("可变参数元素类型错误: 期望 '%s', 实际 '%s'", expected.c_str(), got);
                }
            }
        }
        Value vararr = make_array(elems, vararg_count);
        free(elems);
        declare_var(func.func_val.vararg_name, false, vararr);
    }
    
    g_last_error_line = saved_line;
    g_last_error_col = saved_col;
    g_last_error_filename = saved_filename;

    // ---- 重置标志 ----
    return_caught = break_caught = continue_caught = exception_raised = false;

    break_levels = 1;
    continue_levels = 1;

    Value return_val;
    bool need_throw = false;
    std::string error_msg;

    const char* old_filename = current_filename;
    if (func.func_val.filename) {
        current_filename = func.func_val.filename;
    }

    // ==================== 执行函数体 ====================
    try {
        exec_statement(func.func_val.body);
        break_caught = false;
        continue_caught = false;

        // ---- 检查异常 ----
        if (exception_raised) {
            char* msg = value_to_string(exception_value);
            bool old_warn = g_warnings_enabled;
            g_warnings_enabled = true;
            kr_warn("%s", msg);
            g_warnings_enabled = old_warn;
            free(msg);
            free_value(&exception_value);
            exception_raised = false;
            // 清理并返回 null
            pop_scope();
            current_scope = old_scope;
            current_func_name = old_func_name;
            current_func_value = old_func_value;
            current_constructed_obj = old_constructed_obj;
            return_caught = saved.return_caught;
            break_caught = saved.break_caught;
            continue_caught = saved.continue_caught;
            exception_raised = saved.exception_raised;
            free_value(&return_value);
            return_value = saved.return_value;
            free_value(&exception_value);
            exception_value = saved.exception_value;
            break_levels = 1;
            continue_levels = 1;
            return make_null();
        }

        // ---- 提取返回值 ----
        if (return_caught) {
            return_val = copy_value(return_value);
            return_caught = false;
        } else {
            // 如果返回类型为 any，则默认返回 null
            if (func.func_val.return_type && func.func_val.return_type->kind == TYPE_ANY) {
                return_val = make_null();
            } else {
                ASTNode* last = get_last_expr_from_block(func.func_val.body);
                return_val = last ? eval_expr(last) : make_int(0LL);
            }
        }

        // ---- 返回类型检查（错误位置由 kr_error 自动获取） ----
        if (func.func_val.return_type && !check_type(func.func_val.return_type, return_val)) {
            std::string expected = type_to_string(func.func_val.return_type);
            char* got_val = value_to_string(return_val);
            std::string actual_type = value_type_to_string(return_val);
            std::string func_name = func.func_val.name ? func.func_val.name : "<anonymous>";
            error_msg = "返回值类型不匹配: 函数 '" + func_name +
                        "' 声明返回 '" + expected + "', 但实际返回 '" + std::string(got_val) +
                        "' (类型: '" + actual_type + "')";
            free(got_val);
            free_value(&return_val);
            need_throw = true;
        }

    } catch (...) {
        // ---- 任何异常（包括 kr_error）----
        pop_scope();
        current_scope = old_scope;
        current_func_name = old_func_name;
        current_func_value = old_func_value;
        current_constructed_obj = old_constructed_obj;
        g_current_return_slot = old_return_slot;
        return_caught = saved.return_caught;
        break_caught = saved.break_caught;
        continue_caught = saved.continue_caught;
        exception_raised = saved.exception_raised;
        free_value(&return_value);
        return_value = saved.return_value;
        free_value(&exception_value);
        exception_value = saved.exception_value;
        break_levels = 1;
        continue_levels = 1;
        throw;
    }

    // ---- 如果 need_throw 为 true，清理后抛出 ----
    if (need_throw) {
        pop_scope();
        current_scope = old_scope;
        current_func_name = old_func_name;
        current_func_value = old_func_value;
        current_constructed_obj = old_constructed_obj;
        g_current_return_slot = old_return_slot;
        return_caught = saved.return_caught;
        break_caught = saved.break_caught;
        continue_caught = saved.continue_caught;
        exception_raised = saved.exception_raised;
        free_value(&return_value);
        return_value = saved.return_value;
        free_value(&exception_value);
        exception_value = saved.exception_value;
        break_levels = 1;
        continue_levels = 1;
        kr_error("%s", error_msg.c_str());
    }

    // ---- 正常结束：清理并返回 ----
    pop_scope();
    current_scope = old_scope;
    current_func_name = old_func_name;
    current_func_value = old_func_value;
    current_constructed_obj = old_constructed_obj;
    g_current_return_slot = old_return_slot;

    return_caught = saved.return_caught;
    break_caught = saved.break_caught;
    continue_caught = saved.continue_caught;
    exception_raised = saved.exception_raised;
    free_value(&return_value);
    return_value = saved.return_value;
    free_value(&exception_value);
    exception_value = saved.exception_value;
    break_levels = 1;
    continue_levels = 1;

    // 清除标志（防止传播）
    return_caught = false;
    break_caught = false;
    continue_caught = false;
    exception_raised = false;
    current_filename = old_filename;

    return return_val;
}

// 访问权限检查
static void check_access(int access_level,
                         const std::string& defining_file,
                         const std::string& target_class_name,
                         const std::string& member_name,
                         const std::string& caller_class,
                         ASTNode* call_node) {
    if (access_level == 0) return; // public

    // 1. 优先使用调用节点的位置查找文件名
    const char* caller_file = nullptr;
    if (call_node) {
        caller_file = find_filename_by_line_col(call_node->line, call_node->col);
    }
    // 2. 若未找到，回退到当前全局文件名（保底）
    if (!caller_file) {
        caller_file = current_filename ? current_filename : "";
    }

    // 如果调用者文件与定义文件相同，允许访问（同文件内）
    if (strcmp(caller_file, defining_file.c_str()) == 0) return;

    // 不同文件则根据访问级别报错
    if (access_level == 1) { // private
        kr_error("无法从文件 '%s' 访问私有成员 '%s'（在 '%s' 中定义）",
                 caller_file, member_name.c_str(), defining_file.c_str());
    } else if (access_level == 2) { // protected
        // 检查是否为子类（仅当 caller_class 非空且与 target_class_name 有继承关系）
        if (!caller_class.empty() && !target_class_name.empty()) {
            if (is_subclass(caller_class, target_class_name)) {
                return; // 子类允许访问
            }
        }
        kr_error("受保护的成员 '%s' 不能从文件 '%s' 访问（在 '%s' 中定义）",
                 member_name.c_str(), caller_file, defining_file.c_str());
    }
}

// 加载模块（返回模块作用域）
static Scope* load_module(const std::string& module_name,
                          bool has_quote,
                          const std::string& base_dir,
                          std::vector<std::string>* out_funcs = nullptr) {
    std::map<int, std::string> saved_line_map = g_line_to_file;
    g_line_to_file.clear();
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    std::string abs_path = resolve_module_path(module_name, has_quote, base_dir);
    if (abs_path.empty()) {
        kr_error("无法解析模块 '%s'", module_name.c_str());
    }

    // 检查缓存和循环导入
    {
        std::lock_guard<std::mutex> lock(module_cache_mutex);
        auto it = module_cache.find(abs_path);
        if (it != module_cache.end()) {
            return it->second;
        }
        if (loading_modules.find(abs_path) != loading_modules.end()) {
            kr_error("循环导入检测: %s", abs_path.c_str());
        }
        loading_modules.insert(abs_path);
    }

    // 读取文件内容
    std::ifstream ifs(abs_path, std::ios::binary);
    if (!ifs) {
        kr_error("无法打开模块文件 '%s'", abs_path.c_str());
    }
    ifs.seekg(0, std::ios::end);
    std::streamsize len = ifs.tellg();
    ifs.seekg(0, std::ios::beg);
    std::string content((size_t)len, '\0');
    ifs.read(&content[0], len);
    ifs.close();

    // 保存旧上下文（文件/源码）
    const char* old_filename = current_filename;
    char* old_source = source_code;

    // 设置新上下文（模块内容）
    static std::string current_module_path;
    current_module_path = abs_path;
    current_filename = current_module_path.c_str();

    char* new_source = strdup(content.c_str());
    source_code = new_source;

    // ---- 保存主文件的词法分析状态 ----
    Token* saved_tokens = tokens;
    int saved_token_count = token_count;
    int saved_tok_pos = tok_pos;
    int saved_last_token_line = g_last_token_line;
    int saved_last_token_col = g_last_token_col;
    int saved_stmt_start_line = g_stmt_start_line;
    int saved_stmt_start_col = g_stmt_start_col;
    int saved_last_error_line = g_last_error_line;
    int saved_last_error_col = g_last_error_col;

    Scope* module_scope = nullptr;

    try {
        std::unordered_map<std::string, std::vector<std::string>> local_alias;
        std::string processed = preprocess_source(content.c_str(), true, local_alias);
        tokenize_impl(processed.c_str());
        ASTNode* module_ast = parse_program();

        Scope* old_scope = current_scope;
        push_scope();
        module_scope = current_scope;
        module_scope->parent = original_global_scope;

        save_flags();
        return_caught = false;
        break_caught = false;
        continue_caught = false;
        exception_raised = false;

        int old_func_count = func_count;

        exec_statement(module_ast);

        if (out_funcs) {
            for (int i = old_func_count; i < func_count; ++i) {
                if (functions[i].name) {
                    out_funcs->push_back(functions[i].name);
                }
            }
        }

        restore_flags();
        current_scope = old_scope;
        g_loaded_module_asts.push_back(module_ast);

        // ---- 释放模块 tokens 并恢复主文件状态 ----
        free_tokens();  // 释放模块的 tokens

        // 恢复主文件的 tokens 和相关状态
        tokens = saved_tokens;
        token_count = saved_token_count;
        tok_pos = saved_tok_pos;
        g_last_token_line = saved_last_token_line;
        g_last_token_col = saved_last_token_col;
        g_stmt_start_line = saved_stmt_start_line;
        g_stmt_start_col = saved_stmt_start_col;
        g_last_error_line = saved_last_error_line;
        g_last_error_col = saved_last_error_col;

        // 注意：g_custom_source_context 和 current_filename 已在函数末尾恢复
    } catch (...) {
        // 如果发生异常，确保释放模块 tokens（如果存在）并恢复主文件状态
        if (tokens != saved_tokens) {
            free_tokens();  // 释放当前（模块）的 tokens
        }
        // 恢复主文件 tokens 和相关状态
        tokens = saved_tokens;
        token_count = saved_token_count;
        tok_pos = saved_tok_pos;
        g_last_token_line = saved_last_token_line;
        g_last_token_col = saved_last_token_col;
        g_stmt_start_line = saved_stmt_start_line;
        g_stmt_start_col = saved_stmt_start_col;
        g_last_error_line = saved_last_error_line;
        g_last_error_col = saved_last_error_col;

        // 清理模块上下文
        {
            std::lock_guard<std::mutex> lock(module_cache_mutex);
            loading_modules.erase(abs_path);
        }
        throw;
    }

    // 恢复旧上下文（文件/源码）
    free(new_source);
    source_code = old_source;
    g_line_to_file = saved_line_map;
    current_filename = old_filename;

    {
        std::lock_guard<std::mutex> lock(module_cache_mutex);
        loading_modules.erase(abs_path);
        module_cache[abs_path] = module_scope;
    }
    g_line_to_file = saved_line_map;

    return module_scope;
}

 #define C_BLUE   "\033[34m"
 #define C_YELLOW "\033[33m"
 #define C_GREEN  "\033[32m"
 #define C_PURPLE "\033[35m"
 #define C_CYAN   "\033[36m"
 #define C_GRAY   "\033[90m"
 #define C_RESET  "\033[0m"

 const char* node_type_to_string(NodeType type) {
    switch (type) {
        case NODE_PROGRAM:          return "PROGRAM";
        // ---------- 蓝色：声明 / 定义 / 块 ----------
        case NODE_BLOCK:            return C_BLUE "BLOCK" C_RESET;
        case NODE_VAR_DECL:         return C_BLUE "VAR_DECL" C_RESET;
        case NODE_FUNC_DEF:         return C_BLUE "FUNC_DEF" C_RESET;
        case NODE_LAZY_VAR_DECL:    return C_BLUE "LAZY_VAR_DECL" C_RESET;
        case NODE_ALIAS_DECL:       return C_BLUE "ALIAS_DECL" C_RESET;
        case NODE_RULE_DEF:         return C_BLUE "RULE_DEF" C_RESET;
        case NODE_CLASS_DEF:        return C_BLUE "CLASS_DEF" C_RESET;
        case NODE_METHOD_DEF:       return C_BLUE "METHOD_DEF" C_RESET;
        case NODE_UMF_DEF:          return C_BLUE "UMF_DEF" C_RESET;
        case NODE_TYPE_DEF:         return C_BLUE "TYPE_DEF" C_RESET;
        case NODE_STRUCT_DEF:       return C_BLUE "STRUCT_DEF" C_RESET;
        case NODE_UNION_DEF:        return C_BLUE "UNION_DEF" C_RESET;
        case NODE_ENUM_DEF:         return C_BLUE "ENUM_DEF" C_RESET;
        case NODE_GLOBAL_BLOCK:     return C_BLUE "GLOBAL_BLOCK" C_RESET;
        case NODE_SCOPE_BLOCK:      return C_BLUE "SCOPE_BLOCK" C_RESET;
        case NODE_IMPORT:           return C_BLUE "IMPORT" C_RESET;
        case NODE_UMF_IMPORT:       return C_BLUE "UMF_IMPORT" C_RESET;

        // ---------- 黄色：控制流 ----------
        case NODE_IF:               return C_YELLOW "IF" C_RESET;
        case NODE_WHILE:            return C_YELLOW "WHILE" C_RESET;
        case NODE_FOR:              return C_YELLOW "FOR" C_RESET;
        case NODE_DO_WHILE:         return C_YELLOW "DO_WHILE" C_RESET;
        case NODE_BREAK:            return C_YELLOW "BREAK" C_RESET;
        case NODE_CONTINUE:         return C_YELLOW "CONTINUE" C_RESET;
        case NODE_RETURN:           return C_YELLOW "RETURN" C_RESET;
        case NODE_TRY:              return C_YELLOW "TRY" C_RESET;
        case NODE_THROW:            return C_YELLOW "THROW" C_RESET;
        case NODE_MATCH:            return C_YELLOW "MATCH" C_RESET;
        case NODE_FOREACH:          return C_YELLOW "FOREACH" C_RESET;
        case NODE_SICHER:           return C_YELLOW "SICHER" C_RESET;

        // ---------- 绿色：语句 / 赋值 / 操作符 / 表达式 ----------
        case NODE_ASSIGN:                   return C_GREEN "ASSIGN" C_RESET;
        case NODE_ARRAY_ASSIGN:             return C_GREEN "ARRAY_ASSIGN" C_RESET;
        case NODE_OBJECT_ASSIGN:            return C_GREEN "OBJECT_ASSIGN" C_RESET;
        case NODE_OBJECT_COMPOUND_ASSIGN:   return C_GREEN "OBJECT_COMPOUND_ASSIGN" C_RESET;
        case NODE_SWAP_ASSIGN:              return C_GREEN "SWAP_ASSIGN" C_RESET;
        case NODE_DESTRUCTURE_ASSIGN:       return C_GREEN "DESTRUCTURE_ASSIGN" C_RESET;
        case NODE_MULTI_ASSIGN:             return C_GREEN "MULTI_ASSIGN" C_RESET;
        case NODE_ARRAY_COMPOUND_ASSIGN:    return C_GREEN "ARRAY_COMPOUND_ASSIGN" C_RESET;
        case NODE_PRINT:                    return C_GREEN "PRINT" C_RESET;
        case NODE_PRINT_NO_NEWLINE:         return C_GREEN "PRINT_NO_NEWLINE" C_RESET;
        case NODE_PRINT_WITH_LINE:          return C_GREEN "PRINT_WITH_LINE" C_RESET;
        case NODE_PRINT_MULTI:              return C_GREEN "PRINT_MULTI" C_RESET;
        case NODE_PRINT_NO_NEWLINE_MULTI:   return C_GREEN "PRINT_NO_NEWLINE_MULTI" C_RESET;
        case NODE_INPUT:                    return C_GREEN "INPUT" C_RESET;
        case NODE_BINARY:                   return C_GREEN "BINARY" C_RESET;
        case NODE_BITWISE_OR:               return C_GREEN "BITWISE_OR" C_RESET;
        case NODE_BITWISE_AND:              return C_GREEN "BITWISE_AND" C_RESET;
        case NODE_SHIFT_LEFT:               return C_GREEN "SHIFT_LEFT" C_RESET;
        case NODE_SHIFT_RIGHT:              return C_GREEN "SHIFT_RIGHT" C_RESET;
        case NODE_NOT:                      return C_GREEN "NOT" C_RESET;
        case NODE_LOGICAL_AND:              return C_GREEN "LOGICAL_AND" C_RESET;
        case NODE_LOGICAL_OR:               return C_GREEN "LOGICAL_OR" C_RESET;
        case NODE_PRE_INC:                  return C_GREEN "PRE_INC" C_RESET;
        case NODE_PRE_DEC:                  return C_GREEN "PRE_DEC" C_RESET;
        case NODE_POST_INC:                 return C_GREEN "POST_INC" C_RESET;
        case NODE_POST_DEC:                 return C_GREEN "POST_DEC" C_RESET;
        case NODE_TERNARY:                  return C_GREEN "TERNARY" C_RESET;
        case NODE_NULL_COALESCE:            return C_GREEN "NULL_COALESCE" C_RESET;
        case NODE_PIPE:                     return C_GREEN "PIPE" C_RESET;
        case NODE_RANGE:                    return C_GREEN "RANGE" C_RESET;
        case NODE_CONCAT:                   return C_GREEN "CONCAT" C_RESET;
        case NODE_CMP_THREE_WAY:            return C_GREEN "CMP_THREE_WAY" C_RESET;
        case NODE_BITWISE_NOT:              return C_GREEN "BITWISE_NOT" C_RESET;
        case NODE_DEGREE:                   return C_GREEN "DEGREE" C_RESET;
        case NODE_FACTORIAL:                return C_GREEN "FACTORIAL" C_RESET;
        case NODE_DOUBLE_FACTORIAL:         return C_GREEN "DOUBLE_FACTORIAL" C_RESET;
        case NODE_EXPR_STMT:                return C_GREEN "EXPR_STMT" C_RESET;
        case NODE_LIST_COMPREHENSION:       return C_GREEN "LIST_COMPREHENSION" C_RESET;
        case NODE_SPREAD_ARRAY:             return C_GREEN "SPREAD_ARRAY" C_RESET;
        case NODE_SPREAD_OBJECT:            return C_GREEN "SPREAD_OBJECT" C_RESET;
        case NODE_SPREAD_ARG:               return C_GREEN "SPREAD_ARG" C_RESET;
        case NODE_MARK_USED:                return C_GREEN "MARK_USED" C_RESET;
        case NODE_MARK_ALL_USED:            return C_GREEN "MARK_ALL_USED" C_RESET;

        // ---------- 紫色：字面量 / 常量 ----------
        case NODE_NUMBER:           return C_PURPLE "NUMBER" C_RESET;
        case NODE_FLOAT:            return C_PURPLE "FLOAT" C_RESET;
        case NODE_STRING:           return C_PURPLE "STRING" C_RESET;
        case NODE_STRING_INTERP:    return C_PURPLE "STRING_INTERP" C_RESET;
        case NODE_REGEX_LITERAL:    return C_PURPLE "REGEX_LITERAL" C_RESET;
        case NODE_ARRAY_LITERAL:    return C_PURPLE "ARRAY_LITERAL" C_RESET;
        case NODE_OBJECT_LITERAL:   return C_PURPLE "OBJECT_LITERAL" C_RESET;
        case NODE_NULL:             return C_PURPLE "NULL" C_RESET;
        case NODE_THIS:             return C_PURPLE "THIS" C_RESET;

        // ---------- 青色：访问 / 调用 / 成员 ----------
        case NODE_VARIABLE:         return C_CYAN "VARIABLE" C_RESET;
        case NODE_ARRAY_ACCESS:     return C_CYAN "ARRAY_ACCESS" C_RESET;
        case NODE_STRING_ACCESS:    return C_CYAN "STRING_ACCESS" C_RESET;
        case NODE_OBJECT_ACCESS:    return C_CYAN "OBJECT_ACCESS" C_RESET;
        case NODE_FUNC_CALL:        return C_CYAN "FUNC_CALL" C_RESET;
        case NODE_METHOD_CALL:      return C_CYAN "METHOD_CALL" C_RESET;
        case NODE_SUPER_CALL:       return C_CYAN "SUPER_CALL" C_RESET;
        case NODE_NEW:              return C_CYAN "NEW" C_RESET;
        case NODE_AWAIT:            return C_CYAN "AWAIT" C_RESET;
        case NODE_KEY_BIND:         return C_CYAN "KEY_BIND" C_RESET;

        // ---------- 灰色：模式匹配 / 解构 ----------
        case NODE_PATTERN_BIND:     return C_GRAY "PATTERN_BIND" C_RESET;
        case NODE_PATTERN_OBJECT:   return C_GRAY "PATTERN_OBJECT" C_RESET;
        case NODE_PATTERN_VARIANT:  return C_GRAY "PATTERN_VARIANT" C_RESET;
        case NODE_PATTERN_CONSTANT: return C_GRAY "PATTERN_CONSTANT" C_RESET;
        case NODE_PATTERN_OR:       return C_GRAY "PATTERN_OR" C_RESET;
        case NODE_DESTRUCTURE:      return C_GRAY "DESTRUCTURE" C_RESET;

        default:                    return "UNKNOWN_NODE";
    }
}

std::string ast_to_string(ASTNode* node, int indent = 0) {
    if (!node) return std::string(indent, ' ') + "null\n";
    std::string prefix(indent, ' ');
    std::string result = prefix + node_type_to_string(node->type) +
                         " (line:" + std::to_string(node->line) +
                         " col:" + std::to_string(node->col) + ")\n";

    // 处理所有节点类型的详细字段
    switch (node->type) {
        case NODE_VAR_DECL:
            result += prefix + "  name: " + node->data.var_decl.name + "\n";
            result += prefix + "  is_const: " + (node->data.var_decl.is_const ? "true" : "false") + "\n";
            result += prefix + "  global: " + (node->data.var_decl.global ? "true" : "false") + "\n";
            if (node->data.var_decl.type_annotation)
                result += prefix + "  type_annotation: " + type_to_string(node->data.var_decl.type_annotation) + "\n";
            result += prefix + "  expr:\n" + ast_to_string(node->data.var_decl.expr, indent + 4);
            break;

        case NODE_ASSIGN:
            result += prefix + "  name: " + node->data.assign.name + "\n";
            result += prefix + "  global: " + (node->data.assign.global ? "true" : "false") + "\n";
            result += prefix + "  expr:\n" + ast_to_string(node->data.assign.expr, indent + 4);
            break;

        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT:
            result += prefix + "  op: " + node->data.binary.op + "\n";
            result += prefix + "  left:\n" + ast_to_string(node->data.binary.left, indent + 4);
            result += prefix + "  right:\n" + ast_to_string(node->data.binary.right, indent + 4);
            break;

        case NODE_NUMBER:
            result += prefix + "  value: " + node->data.number_str + "\n";
            break;

        case NODE_FLOAT:
            result += prefix + "  value: " + node->data.float_str + "\n";
            break;

        case NODE_VARIABLE:
            result += prefix + "  name: " + node->data.var_name + "\n";
            break;

        case NODE_STRING:
            result += prefix + "  value: \"" + node->data.string + "\"\n";
            break;

        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF:
            result += prefix + "  name: " + (node->data.func_def.name ? node->data.func_def.name : "<anon>") + "\n";
            result += prefix + "  params: [";
            for (int i = 0; i < node->data.func_def.param_count; ++i) {
                if (i) result += ", ";
                result += node->data.func_def.params[i];
            }
            result += "]\n";
            if (node->data.func_def.return_type)
                result += prefix + "  return_type: " + type_to_string(node->data.func_def.return_type) + "\n";
            result += prefix + "  body:\n" + ast_to_string(node->data.func_def.body, indent + 4);
            break;

        case NODE_FUNC_CALL:
            if (node->data.func_call.name)
                result += prefix + "  name: " + node->data.func_call.name + "\n";
            if (node->data.func_call.func_expr)
                result += prefix + "  func_expr:\n" + ast_to_string(node->data.func_call.func_expr, indent + 4);
            result += prefix + "  args:\n";
            for (int i = 0; i < node->data.func_call.arg_count; ++i)
                result += ast_to_string(node->data.func_call.args[i], indent + 4);
            break;

        case NODE_BLOCK:
        case NODE_PROGRAM:
        case NODE_SCOPE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            result += prefix + "  statements:\n";
            for (int i = 0; i < node->data.block.count; ++i)
                result += ast_to_string(node->data.block.stmts[i], indent + 4);
            break;

        case NODE_IF:
            result += prefix + "  cond:\n" + ast_to_string(node->data.if_stmt.cond, indent + 4);
            result += prefix + "  then_block:\n" + ast_to_string(node->data.if_stmt.then_block, indent + 4);
            for (int i = 0; i < node->data.if_stmt.else_if_count; ++i)
                result += prefix + "  else_if " + std::to_string(i) + ":\n" +
                          ast_to_string(node->data.if_stmt.else_ifs[i], indent + 4);
            if (node->data.if_stmt.else_block)
                result += prefix + "  else_block:\n" + ast_to_string(node->data.if_stmt.else_block, indent + 4);
            break;
        
        case NODE_EXPR_STMT:
            // 关键修复：y = 2 这类隐式声明/赋值语句现在是 EXPR_STMT → ASSIGN
            if (node->data.expr_stmt.expr)
                result += prefix + "  expr:\n" + ast_to_string(node->data.expr_stmt.expr, indent + 4);
            break;

        case NODE_CLASS_DEF: {
            // 关键修复：klass 定义必须输出类名
            result += prefix + "  name: " +
                      std::string(node->data.class_def.name ? node->data.class_def.name : "<anon>") + "\n";
            if (node->data.class_def.parent)
                result += prefix + "  parent: " + std::string(node->data.class_def.parent) + "\n";
            result += prefix + "  is_static_class: " +
                      std::string(node->data.class_def.is_static_class ? "true" : "false") + "\n";
            result += prefix + "  access_modifier: " +
                      std::to_string(node->data.class_def.access_modifier) + "\n";

            result += prefix + "  ctor_params: [";
            for (int i = 0; i < node->data.class_def.ctor_param_count; i++) {
                if (i) result += ", ";
                result += node->data.class_def.ctor_params[i];
            }
            result += "]\n";
            if (node->data.class_def.ctor_body)
                result += prefix + "  ctor_body:\n" +
                          ast_to_string(node->data.class_def.ctor_body, indent + 4);

            result += prefix + "  methods (" +
                      std::to_string(node->data.class_def.methods.count) + "):\n";
            for (int i = 0; i < node->data.class_def.methods.count; i++) {
                result += prefix + "    method: " +
                          std::string(node->data.class_def.methods.names[i]);
                if (node->data.class_def.methods.is_static[i]) result += " (static)";
                result += "\n";
                result += prefix + "      params: [";
                for (int j = 0; j < node->data.class_def.methods.param_counts[i]; j++) {
                    if (j) result += ", ";
                    result += node->data.class_def.methods.param_lists[i][j];
                }
                result += "]\n";
                if (node->data.class_def.methods.bodies[i])
                    result += prefix + "      body:\n" +
                              ast_to_string(node->data.class_def.methods.bodies[i], indent + 8);
            }

            result += prefix + "  properties (" +
                      std::to_string(node->data.class_def.properties.count) + "):\n";
            for (int i = 0; i < node->data.class_def.properties.count; i++) {
                result += prefix + "    property: " +
                          std::string(node->data.class_def.properties.names[i]);
                if (node->data.class_def.properties.is_static[i]) result += " (static)";
                if (node->data.class_def.properties.is_const[i])  result += " (const)";
                if (node->data.class_def.properties.is_lazy[i]) result += " (lazy)";
                result += "\n";
            }
            break;
        }

        case NODE_METHOD_CALL:
            if (node->data.method_call.obj)
                result += prefix + "  obj:\n" + ast_to_string(node->data.method_call.obj, indent + 4);
            result += prefix + "  method: " + std::string(node->data.method_call.method) + "\n";
            if (node->data.method_call.is_optional) result += prefix + "  optional: true\n";
            result += prefix + "  args (" + std::to_string(node->data.method_call.arg_count) + "):\n";
            for (int i = 0; i < node->data.method_call.arg_count; i++)
                result += ast_to_string(node->data.method_call.args[i], indent + 4);
            break;

        case NODE_ARRAY_LITERAL:
            result += prefix + "  elems (" + std::to_string(node->data.array_lit.count) + "):\n";
            for (int i = 0; i < node->data.array_lit.count; i++)
                result += ast_to_string(node->data.array_lit.elems[i], indent + 4);
            break;

        case NODE_ARRAY_ACCESS:
            result += prefix + "  array:\n" + ast_to_string(node->data.array_access.array, indent + 4);
            result += prefix + "  index:\n" + ast_to_string(node->data.array_access.index, indent + 4);
            break;

        case NODE_OBJECT_LITERAL:
            result += prefix + "  entries (" + std::to_string(node->data.object_lit.count) + "):\n";
            for (int i = 0; i < node->data.object_lit.count; i++) {
                result += prefix + "    key:\n"   + ast_to_string(node->data.object_lit.key_exprs[i], indent + 8);
                result += prefix + "    value:\n" + ast_to_string(node->data.object_lit.vals[i], indent + 8);
            }
            if (node->data.object_lit.spread_count > 0) {
                result += prefix + "  spreads (" + std::to_string(node->data.object_lit.spread_count) + "):\n";
                for (int i = 0; i < node->data.object_lit.spread_count; i++)
                    result += ast_to_string(node->data.object_lit.spreads[i], indent + 4);
            }
            break;

        case NODE_OBJECT_ACCESS:
            result += prefix + "  obj:\n" + ast_to_string(node->data.object_access.obj, indent + 4);
            result += prefix + "  key: " + std::string(node->data.object_access.key) + "\n";
            if (node->data.object_access.is_optional) result += prefix + "  optional: true\n";
            break;

        case NODE_OBJECT_COMPOUND_ASSIGN:
            result += prefix + "  obj:\n"   + ast_to_string(node->data.object_compound_assign.obj, indent + 4);
            result += prefix + "  key: " + std::string(node->data.object_compound_assign.key) + "\n";
            result += prefix + "  op: "  + node->data.object_compound_assign.op + "\n";
            result += prefix + "  rhs:\n"   + ast_to_string(node->data.object_compound_assign.rhs, indent + 4);
            break;

        case NODE_RETURN:
            if (node->data.ret.expr)
                result += prefix + "  expr:\n" + ast_to_string(node->data.ret.expr, indent + 4);
            break;

        case NODE_WHILE:
            result += prefix + "  cond:\n" + ast_to_string(node->data.while_stmt.cond, indent + 4);
            result += prefix + "  body:\n" + ast_to_string(node->data.while_stmt.body, indent + 4);
            break;

        case NODE_DO_WHILE:
            result += prefix + "  body:\n" + ast_to_string(node->data.do_while.body, indent + 4);
            result += prefix + "  cond:\n" + ast_to_string(node->data.do_while.cond, indent + 4);
            break;

        case NODE_FOR:
            if (node->data.for_stmt.init)
                result += prefix + "  init:\n" + ast_to_string(node->data.for_stmt.init, indent + 4);
            if (node->data.for_stmt.cond)
                result += prefix + "  cond:\n" + ast_to_string(node->data.for_stmt.cond, indent + 4);
            if (node->data.for_stmt.update)
                result += prefix + "  update:\n" + ast_to_string(node->data.for_stmt.update, indent + 4);
            result += prefix + "  body:\n" + ast_to_string(node->data.for_stmt.body, indent + 4);
            break;

        case NODE_FOREACH:
            result += prefix + "  key_var: " + std::string(node->data.foreach.key_var) + "\n";
            if (node->data.foreach.value_var)
                result += prefix + "  value_var: " + std::string(node->data.foreach.value_var) + "\n";
            result += prefix + "  collection:\n" + ast_to_string(node->data.foreach.collection, indent + 4);
            result += prefix + "  body:\n" + ast_to_string(node->data.foreach.body, indent + 4);
            break;

        case NODE_NEW:
            result += prefix + "  class_name: " + std::string(node->data.new_expr.class_name) + "\n";
            result += prefix + "  args (" + std::to_string(node->data.new_expr.arg_count) + "):\n";
            for (int i = 0; i < node->data.new_expr.arg_count; i++)
                result += ast_to_string(node->data.new_expr.args[i], indent + 4);
            break;

        case NODE_SUPER_CALL:
            result += prefix + "  args (" + std::to_string(node->data.super_call.arg_count) + "):\n";
            for (int i = 0; i < node->data.super_call.arg_count; i++)
                result += ast_to_string(node->data.super_call.args[i], indent + 4);
            break;

        case NODE_THIS:
            break;   // 无子节点

        case NODE_TRY:
            result += prefix + "  try_body:\n" + ast_to_string(node->data.try_stmt.try_body, indent + 4);
            if (node->data.try_stmt.catch_var)
                result += prefix + "  catch_var: " + std::string(node->data.try_stmt.catch_var) + "\n";
            if (node->data.try_stmt.catch_body)
                result += prefix + "  catch_body:\n" + ast_to_string(node->data.try_stmt.catch_body, indent + 4);
            if (node->data.try_stmt.finally_body)
                result += prefix + "  finally_body:\n" + ast_to_string(node->data.try_stmt.finally_body, indent + 4);
            break;

        case NODE_THROW:
            result += prefix + "  expr:\n" + ast_to_string(node->data.throw_expr.expr, indent + 4);
            break;

        case NODE_ENUM_DEF: {
            result += prefix + "  name: " + std::string(node->data.enum_def.name) + "\n";
            result += prefix + "  variants (" +
                    std::to_string(node->data.enum_def.variant_count) + "):\n";
            for (int i = 0; i < node->data.enum_def.variant_count; ++i) {
                // 变体位置信息：解释器未单独记录，这里统一用枚举定义的行列
                result += prefix + "    ENUM_VARIANT (line:" + std::to_string(node->line) +
                        " col:" + std::to_string(node->col) + ")\n";
                result += prefix + "      name: " +
                        std::string(node->data.enum_def.variants[i]) + "\n";
                if (node->data.enum_def.variant_param_counts) {
                    result += prefix + "      param_count: " +
                            std::to_string(node->data.enum_def.variant_param_counts[i]) + "\n";
                }
            }
            break;
        }

        case NODE_IMPORT:
            result += prefix + "  filename: " + std::string(node->data.import.filename) + "\n";
            if (node->data.import.alias)
                result += prefix + "  alias: " + std::string(node->data.import.alias) + "\n";
            result += prefix + "  has_quote: " +
                      std::string(node->data.import.has_quote ? "true" : "false") + "\n";
            break;

        case NODE_STRING_INTERP:
            result += prefix + "  fragments (" +
                      std::to_string(node->data.string_interp.count) + "):\n";
            for (int i = 0; i < node->data.string_interp.count; i++)
                result += ast_to_string(node->data.string_interp.fragments[i], indent + 4);
            break;

        case NODE_REGEX_LITERAL:
            result += prefix + "  pattern: " + std::string(node->data.regex_lit.pattern) + "\n";
            result += prefix + "  flags: "   + std::string(node->data.regex_lit.flags) + "\n";
            break;

        case NODE_TERNARY:
            result += prefix + "  cond:\n"       + ast_to_string(node->data.ternary.cond, indent + 4);
            result += prefix + "  true_expr:\n"  + ast_to_string(node->data.ternary.true_expr, indent + 4);
            result += prefix + "  false_expr:\n" + ast_to_string(node->data.ternary.false_expr, indent + 4);
            break;

        case NODE_NOT:
            result += prefix + "  expr:\n" + ast_to_string(node->data.not_expr.expr, indent + 4);
            break;

        case NODE_LOGICAL_AND:
            result += prefix + "  left:\n"  + ast_to_string(node->data.logical_and.left, indent + 4);
            result += prefix + "  right:\n" + ast_to_string(node->data.logical_and.right, indent + 4);
            break;

        case NODE_LOGICAL_OR:
            result += prefix + "  left:\n"  + ast_to_string(node->data.logical_or.left, indent + 4);
            result += prefix + "  right:\n" + ast_to_string(node->data.logical_or.right, indent + 4);
            break;

        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
        case NODE_DOUBLE_FACTORIAL:
        case NODE_BITWISE_NOT:
            result += prefix + "  operand:\n" + ast_to_string(node->data.inc_dec.operand, indent + 4);
            break;

        case NODE_NULL:
        case NODE_BREAK:
        case NODE_CONTINUE:
            break;   // 无子节点

        case NODE_ENUM_VARIANT:
            break;

        case NODE_MATCH:
            result += prefix + "  expr:\n" + ast_to_string(node->data.match.expr, indent + 4);
            result += prefix + "  branches (" + std::to_string(node->data.match.branch_count) + "):\n";
            for (int i = 0; i < node->data.match.branch_count; i++) {
                result += prefix + "    branch " + std::to_string(i) + " pattern:\n" +
                          ast_to_string(node->data.match.branches[i].pattern, indent + 6);
                if (node->data.match.branches[i].guard)
                    result += prefix + "    guard:\n" +
                              ast_to_string(node->data.match.branches[i].guard, indent + 6);
                result += prefix + "    body:\n" +
                          ast_to_string(node->data.match.branches[i].body, indent + 6);
            }
            break;

        case NODE_PATTERN_BIND:
            result += prefix + "  name: " + std::string(node->data.pattern_bind.name) + "\n";
            break;

        case NODE_PATTERN_VARIANT:
            result += prefix + "  tag: " + std::string(node->data.pattern_variant.tag) + "\n";
            result += prefix + "  params: [";
            for (int i = 0; i < node->data.pattern_variant.param_count; i++) {
                if (i) result += ", ";
                result += node->data.pattern_variant.params[i];
            }
            result += "]\n";
            break;

        case NODE_PATTERN_OBJECT:
            result += prefix + "  keys: [";
            for (int i = 0; i < node->data.pattern_object.count; i++) {
                if (i) result += ", ";
                result += node->data.pattern_object.keys[i];
            }
            result += "]\n";
            break;

        case NODE_PATTERN_CONSTANT:
            result += prefix + "  value: " + std::string(value_to_string(node->data.pattern_constant.constant)) + "\n";
            break;

        case NODE_PATTERN_OR:
            result += prefix + "  patterns (" + std::to_string(node->data.pattern_or.count) + "):\n";
            for (int i = 0; i < node->data.pattern_or.count; i++)
                result += ast_to_string(node->data.pattern_or.patterns[i], indent + 4);
            break;

        case NODE_AWAIT:
            if (node->data.await.expr)
                result += prefix + "  expr:\n" + ast_to_string(node->data.await.expr, indent + 4);
            if (node->data.await.timeout)
                result += prefix + "  timeout:\n" + ast_to_string(node->data.await.timeout, indent + 4);
            if (node->data.await.fallback)
                result += prefix + "  fallback:\n" + ast_to_string(node->data.await.fallback, indent + 4);
            break;

        case NODE_SICHER:
            result += prefix + "  expr:\n" + ast_to_string(node->data.sicher.expr, indent + 4);
            if (node->data.sicher.msg_expr)
                result += prefix + "  msg_expr:\n" + ast_to_string(node->data.sicher.msg_expr, indent + 4);
            break;

        case NODE_LAZY_VAR_DECL:
            result += prefix + "  name: " + std::string(node->data.lazy_var_decl.name) + "\n";
            result += prefix + "  expr:\n" + ast_to_string(node->data.lazy_var_decl.expr, indent + 4);
            break;

        case NODE_ALIAS_DECL:
            result += prefix + "  alias: "  + std::string(node->data.alias_decl.name)   + "\n";
            result += prefix + "  target: " + std::string(node->data.alias_decl.target) + "\n";
            result += prefix + "  global: " + std::string(node->data.alias_decl.global ? "true" : "false") + "\n";
            break;

        case NODE_SWAP_ASSIGN:
            result += prefix + "  left:\n"  + ast_to_string(node->data.swap.left,  indent + 4);
            result += prefix + "  right:\n" + ast_to_string(node->data.swap.right, indent + 4);
            result += prefix + "  global: " + std::string(node->data.swap.global ? "true" : "false") + "\n";
            break;

        case NODE_DESTRUCTURE:
        case NODE_DESTRUCTURE_ASSIGN:
            result += prefix + "  names: [";
            for (int i = 0; i < node->data.destructure.count; i++) {
                if (i) result += ", ";
                result += node->data.destructure.names[i];
            }
            result += "]\n";
            if (node->data.destructure.rest_name)
                result += prefix + "  rest: " + std::string(node->data.destructure.rest_name) + "\n";
            result += prefix + "  expr:\n" + ast_to_string(node->data.destructure.expr, indent + 4);
            break;

        case NODE_MULTI_ASSIGN:
            result += prefix + "  left: [";
            for (int i = 0; i < node->data.multi_assign.left_count; i++) {
                if (i) result += ", ";
                result += node->data.multi_assign.left_names[i];
            }
            result += "]\n";
            result += prefix + "  right (" + std::to_string(node->data.multi_assign.right_count) + "):\n";
            for (int i = 0; i < node->data.multi_assign.right_count; i++)
                result += ast_to_string(node->data.multi_assign.right_exprs[i], indent + 4);
            break;

        case NODE_TYPE_DEF:
            result += prefix + "  name: " + std::string(node->data.type_def.name) + "\n";
            result += prefix + "  members (" + std::to_string(node->data.type_def.member_count) + "):\n";
            for (int i = 0; i < node->data.type_def.member_count; i++)
                result += ast_to_string(node->data.type_def.members[i], indent + 4);
            break;

        case NODE_STRUCT_DEF:
            result += prefix + "  name: " + std::string(node->data.struct_def.name) + "\n";
            result += prefix + "  fields (" + std::to_string(node->data.struct_def.field_count) + "):\n";
            for (int i = 0; i < node->data.struct_def.field_count; i++) {
                result += prefix + "    field: " + std::string(node->data.struct_def.fields[i].name);
                if (node->data.struct_def.fields[i].type)
                    result += " : " + type_to_string(node->data.struct_def.fields[i].type);
                result += "\n";
            }
            break;

        case NODE_UNION_DEF:
            result += prefix + "  name: " + std::string(node->data.union_def.name) + "\n";
            result += prefix + "  variants (" + std::to_string(node->data.union_def.variant_count) + "):\n";
            for (int i = 0; i < node->data.union_def.variant_count; i++)
                result += prefix + "    variant: " +
                          std::string(node->data.union_def.variants[i].name) + "\n";
            break;

        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT:
            result += prefix + "  left:\n"  + ast_to_string(node->data.binary.left,  indent + 4);
            result += prefix + "  right:\n" + ast_to_string(node->data.binary.right, indent + 4);
            break;

        case NODE_NULL_COALESCE:
            result += prefix + "  left:\n"  + ast_to_string(node->data.null_coalesce.left,  indent + 4);
            result += prefix + "  right:\n" + ast_to_string(node->data.null_coalesce.right, indent + 4);
            break;

        case NODE_PIPE:
            result += prefix + "  left:\n"  + ast_to_string(node->data.pipe.left,  indent + 4);
            result += prefix + "  right:\n" + ast_to_string(node->data.pipe.right, indent + 4);
            break;

        case NODE_RANGE:
            if (node->data.range.start)
                result += prefix + "  start:\n" + ast_to_string(node->data.range.start, indent + 4);
            if (node->data.range.end)
                result += prefix + "  end:\n"   + ast_to_string(node->data.range.end,   indent + 4);
            if (node->data.range.step)
                result += prefix + "  step:\n"  + ast_to_string(node->data.range.step,  indent + 4);
            break;

        case NODE_UMF_DEF:
            result += prefix + "  name: " + std::string(node->data.umf_def.name) + "\n";
            if (node->data.umf_def.parent_name)
                result += prefix + "  parent: " + std::string(node->data.umf_def.parent_name) + "\n";
            result += prefix + "  body:\n" + ast_to_string(node->data.umf_def.body, indent + 4);
            break;

        case NODE_KEY_BIND:
            result += prefix + "  key: " + std::string(node->data.key_bind.key) + "\n";
            result += prefix + "  body:\n" + ast_to_string(node->data.key_bind.body, indent + 4);
            break;

        case NODE_MARK_USED:
            result += prefix + "  names: [";
            for (int i = 0; i < node->data.mark_used.count; i++) {
                if (i) result += ", ";
                result += node->data.mark_used.names[i];
            }
            result += "]\n";
            break;

        case NODE_MARK_ALL_USED:
            break;

        default:
            break;
    }
    return result;
}