import os

exclude = "verwirrt.cpp"
total_size = 0
total_lines = 0
files = []

for f in sorted(os.listdir(".")):
    if f.endswith(".cpp") and f != exclude:
        size = os.path.getsize(f)
        with open(f, "r", encoding="utf-8", errors="ignore") as fp:
            lines = sum(1 for _ in fp)
        total_size += size
        total_lines += lines
        files.append((f, lines, size))

# 计算各列宽度
w_name = max(len(f[0]) for f in files) if files else 10
w_name = max(w_name, 4)  # 至少和表头一样宽
w_lines = max(len(f"{f[1]:,}") for f in files) if files else 10
w_size = max(len(f"{f[2]:,}") for f in files) if files else 10

# 表头
print(f"{'File':<{w_name}}  {'Lines':>{w_lines}}  {'Size (B)':>{w_size}}  {'Size (KB)':>{w_size}}")
print(f"{'-'*w_name}  {'-'*w_lines}  {'-'*w_size}  {'-'*w_size}")

# 逐文件输出
for name, lines, size in files:
    print(f"{name:<{w_name}}  {lines:>{w_lines},}  {size:>{w_size},}  {size / 1024:>{w_size},.2f}")

# 汇总
print(f"{'-'*w_name}  {'-'*w_lines}  {'-'*w_size}  {'-'*w_size}")
print(f"{'Total':<{w_name}}  {total_lines:>{w_lines},}  {total_size:>{w_size},}  {total_size / 1024:>{w_size},.2f}")
print()
print(f"Total: {total_size / 1024 / 1024:,.2f} MB")