#include "parser.cpp"
 
// ---------- 使用 POSIX regex 实现的方法 ----------
static Value method_passende(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) {
        kr_error("Fehler: passende 只能用于字符串\n");
    }
    if (arg_count != 1) {
        kr_error("Fehler: passende 需要 1 个参数（正则字符串或正则对象）\n");
    }

    // 求值参数
    Value pattern_val = eval_expr(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;  // 默认启用 Unicode

    // 判断参数类型：对象（正则字面量）或字符串
    if (pattern_val.type == VAL_OBJECT) {
        // 提取 pattern 和 flags
        std::string pat, flg;
        bool has_pat = false;
        for (int i = 0; i < pattern_val.obj_val.count; ++i) {
            Value& entry_val = pattern_val.obj_val.entries[i].value;   // ← 用这个
            if (strcmp(pattern_val.obj_val.entries[i].key, "muster") == 0 &&
                entry_val.type == VAL_STRING) {
                pat.assign(entry_val.str_val, entry_val.str_len);
                has_pat = true;
            }
            if (strcmp(pattern_val.obj_val.entries[i].key, "flags") == 0 &&
                entry_val.type == VAL_STRING) {
                flg.assign(entry_val.str_val, entry_val.str_len);
            }
        }
        if (!has_pat) kr_error("正则对象缺少 'muster' 字段");
        pattern_str = pat;
    
        // 解析 flags
        if (strchr(flg.c_str(), 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg.c_str(), 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg.c_str(), 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg.c_str(), 'x')) pcre2_options |= PCRE2_EXTENDED;
    
        free_value(&pattern_val);
    } else if (pattern_val.type == VAL_STRING) {
        pattern_str.assign(pattern_val.str_val, pattern_val.str_len);   // ← 顺手也改这里
        free_value(&pattern_val);
    } else {
        kr_error("passende 参数必须是字符串或正则对象\n");
    }

    pattern_str = convert_ampersand_to_dollar(pattern_str);

    // 编译正则表达式
    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)pattern_str.c_str(),
        pattern_str.size(),
        pcre2_options,
        &errorcode,
        &erroroffset,
        NULL
    );
    if (!re) {
        PCRE2_UCHAR errbuf[256];
        pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
    }

    // 准备匹配
    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    if (!match_data) {
        pcre2_code_free(re);
        kr_error("无法创建匹配数据");
    }

    std::string s(obj.str_val, obj.str_len);
    int rc = pcre2_match(re, (PCRE2_SPTR)s.c_str(), s.size(), 0, 0, match_data, NULL);
    if (rc <= 0) {
        // 无匹配
        pcre2_match_data_free(match_data);
        pcre2_code_free(re);
        return make_null();
    }

    // 提取所有捕获组（包括第0组）
    PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
    Value* elems = (Value*)malloc(rc * sizeof(Value));
    if (!elems) {
        pcre2_match_data_free(match_data);
        pcre2_code_free(re);
        kr_error("内存分配失败");
    }

    for (int i = 0; i < rc; ++i) {
        size_t start = ovector[2 * i];
        size_t end = ovector[2 * i + 1];
        if (start == PCRE2_UNSET) {
            // 未参与匹配的捕获组，返回空字符串
            elems[i] = make_string("");
        } else {
            std::string submatch = s.substr(start, end - start);
            elems[i] = make_string(submatch.c_str());
        }
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(re);

    return make_array(elems, rc);
 }
 
 static Value method_ersetze(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("ersetze 只能用于字符串");
    if (arg_count != 2) kr_error("ersetze 需要 2 个参数");

    // ------ 1. 解析正则参数（与之前相同）------
    Value pat_val = eval_expr(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;

    if (pat_val.type == VAL_STRING) {
        pattern_str = pat_val.str_val;
    } else if (pat_val.type == VAL_OBJECT) {
        const char* pat = nullptr;
        const char* flg = "";
        for (int i = 0; i < pat_val.obj_val.count; ++i) {
            if (strcmp(pat_val.obj_val.entries[i].key, "muster") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                pat = pat_val.obj_val.entries[i].value.str_val;
            }
            if (strcmp(pat_val.obj_val.entries[i].key, "flags") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                flg = pat_val.obj_val.entries[i].value.str_val;
            }
        }
        if (!pat) kr_error("正则对象缺少 pattern");
        pattern_str = pat;
        if (strchr(flg, 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg, 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg, 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg, 'x')) pcre2_options |= PCRE2_EXTENDED;
    } else {
        kr_error("第一个参数必须是字符串或正则对象");
    }
    free_value(&pat_val);

    // ------ 2. 求值替换字符串 ------
    Value repl_val = eval_expr(args[1]);
    if (repl_val.type != VAL_STRING) kr_error("第二个参数必须是字符串");
    std::string repl_str = repl_val.str_val;
    free_value(&repl_val);
    
    pattern_str = convert_ampersand_to_dollar(pattern_str);

    // ------ 3. 编译正则 ------
    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)pattern_str.c_str(),
        pattern_str.size(),
        pcre2_options,
        &errorcode,
        &erroroffset,
        NULL
    );
    if (!re) {
        PCRE2_UCHAR errbuf[256];
        pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
    }

    // ------ 4. 创建匹配数据 ------
    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    if (!match_data) {
        pcre2_code_free(re);
        kr_error("无法创建匹配数据");
    }

    // ------ 5. 循环替换（逐个匹配）------
    std::string input(obj.str_val, obj.str_len);
    std::string output;
    PCRE2_SIZE offset = 0;
    PCRE2_SIZE input_len = input.size();

    while (true) {
        int rc = pcre2_match(re,
                             (PCRE2_SPTR)input.c_str(), input_len,
                             offset,
                             0,
                             match_data,
                             NULL);
        if (rc <= 0) {
            // 没有更多匹配，将剩余部分追加到输出
            output.append(input, offset, std::string::npos);
            break;
        }

        PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
        PCRE2_SIZE match_start = ovector[0];
        PCRE2_SIZE match_end   = ovector[1];

        // 1) 追加匹配前的文本
        output.append(input, offset, match_start - offset);

        // 2) 构建替换文本（处理 $1, $2, ...）
        std::string replacement;
        for (size_t i = 0; i < repl_str.size(); ++i) {
            if (repl_str[i] == '\\') {
                // 转义字符
                if (i + 1 < repl_str.size()) replacement.push_back(repl_str[++i]);
            } 
            else if (repl_str[i] == '&') {
                if (i + 1 < repl_str.size() && isdigit(repl_str[i+1])) {
                    // & 后跟数字：捕获组引用
                    int group = repl_str[i+1] - '0';
                    i++; // 跳过数字
                    if (group < rc) {
                        PCRE2_SIZE start = ovector[2*group];
                        PCRE2_SIZE end   = ovector[2*group + 1];
                        if (start != PCRE2_UNSET) {
                            replacement.append(input, start, end - start);
                        }
                    }
                } else if (i + 1 < repl_str.size() && repl_str[i+1] == '&') {
                    // && 表示字面 &
                    replacement.push_back('&');
                    i++; // 跳过第二个 &
                } else {
                    // 单独的 & 表示整个匹配（group 0）
                    PCRE2_SIZE start = ovector[0];
                    PCRE2_SIZE end   = ovector[1];
                    if (start != PCRE2_UNSET) {
                        replacement.append(input, start, end - start);
                    }
                }
            }
            else {
                // 普通字符
                replacement.push_back(repl_str[i]);
            }
        }

        output += replacement;

        // 3) 更新偏移量（如果匹配长度为0，则必须前进1个字符防止无限循环）
        if (match_end == match_start) {
            offset = match_end + 1;
            if (offset > input_len) break;
        } else {
            offset = match_end;
        }

        // 如果已经到达末尾，退出
        if (offset >= input_len) break;
    }

    // ------ 6. 清理资源 ------
    pcre2_match_data_free(match_data);
    pcre2_code_free(re);

    return make_string(output.c_str());
 }
 
 static Value method_teile(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) {
        kr_error("Fehler: teil 只能用于字符串\n");
    }
    if (arg_count != 1) {
        kr_error("Fehler: teil 需要 1 个参数（正则/分隔符）\n");
    }

    Value sep = eval_expr(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;  // 默认启用 Unicode

    // ---- 处理参数（支持字符串或正则对象） ----
    if (sep.type == VAL_OBJECT) {
        // 正则对象：提取 pattern 和 flags
        const char* pat = nullptr;
        const char* flg = "";
        for (int i = 0; i < sep.obj_val.count; ++i) {
            if (strcmp(sep.obj_val.entries[i].key, "muster") == 0 &&
                sep.obj_val.entries[i].value.type == VAL_STRING) {
                pat = sep.obj_val.entries[i].value.str_val;
            }
            if (strcmp(sep.obj_val.entries[i].key, "flags") == 0 &&
                sep.obj_val.entries[i].value.type == VAL_STRING) {
                flg = sep.obj_val.entries[i].value.str_val;
            }
        }
        if (!pat) {
            kr_error("正则对象缺少 'muster' 字段");
        }
        pattern_str = pat;

        // 解析 flags
        if (strchr(flg, 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg, 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg, 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg, 'x')) pcre2_options |= PCRE2_EXTENDED;
        // 可添加其他标志

        free_value(&sep);
    } else if (sep.type == VAL_STRING) {
        // 普通字符串：直接使用（convert_ampersand_to_dollar 仍会处理）
        pattern_str = sep.str_val;
        free_value(&sep);
    } else {
        kr_error("teil 参数必须是字符串或正则对象");
    }

    // ---- 编译正则表达式（与之前相同） ----
    std::string converted = convert_ampersand_to_dollar(pattern_str);
    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)converted.c_str(), converted.size(),
        pcre2_options,
        &errorcode, &erroroffset, NULL
    );
    if (!re) {
        kr_error("PCRE2 编译错误: 偏移 %zu", erroroffset);
    }

    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    std::string s(obj.str_val, obj.str_len);
    std::vector<Value> parts;
    size_t pos = 0;

    // ---- 循环分割 ----
    while (true) {
        int rc = pcre2_match(re, (PCRE2_SPTR)s.c_str() + pos, s.size() - pos, 0, 0, match_data, NULL);
        if (rc <= 0) {
            // 剩余部分
            std::string rest = s.substr(pos);
            parts.push_back(make_string(rest.c_str()));
            break;
        }
        PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
        size_t match_start = pos + ovector[0];
        size_t match_end   = pos + ovector[1];
        // 分隔符之前的部分
        if (match_start > pos) {
            std::string part = s.substr(pos, match_start - pos);
            parts.push_back(make_string(part.c_str()));
        } else {
            // 空部分（分隔符在开头）
            parts.push_back(make_string(""));
        }
        pos = match_end;
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(re);

    Value result = make_array(parts.data(), (int)parts.size());
    for (auto& v : parts) free_value(&v);
    return result;
 }

 static Value method_entfal(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING)
        kr_error("entfal 只能用于字符串");
    if (arg_count < 2 || arg_count > 3)
        kr_error("entfal 需要 2 或 3 个参数：字符串, 正则, [模板]");

    // 求值正则参数（args[0]）
    Value pat_val = eval_expr(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;

    if (pat_val.type == VAL_STRING) {
        pattern_str = pat_val.str_val;
    } else if (pat_val.type == VAL_OBJECT) {
        const char* pat = nullptr;
        const char* flg = "";
        for (int i = 0; i < pat_val.obj_val.count; ++i) {
            if (strcmp(pat_val.obj_val.entries[i].key, "muster") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                pat = pat_val.obj_val.entries[i].value.str_val;
            }
            if (strcmp(pat_val.obj_val.entries[i].key, "flags") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                flg = pat_val.obj_val.entries[i].value.str_val;
            }
        }
        if (!pat) kr_error("正则对象缺少 'muster' 字段");
        pattern_str = pat;
        if (strchr(flg, 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg, 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg, 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg, 'x')) pcre2_options |= PCRE2_EXTENDED;
    } else {
        kr_error("第二个参数必须是字符串或正则对象");
    }
    free_value(&pat_val);

    // 求值模板参数（args[1]，可选）
    std::string tmpl = "&";   // 默认：完整匹配
    if (arg_count == 3) {
        Value tmpl_val = eval_expr(args[1]);
        if (tmpl_val.type != VAL_STRING)
            kr_error("模板必须是字符串");
        tmpl = tmpl_val.str_val;
        free_value(&tmpl_val);
    }

    // 编译 PCRE2 正则
    pattern_str = convert_ampersand_to_dollar(pattern_str);
    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)pattern_str.c_str(),
        pattern_str.size(),
        pcre2_options,
        &errorcode,
        &erroroffset,
        NULL
    );
    if (!re) {
        PCRE2_UCHAR errbuf[256];
        pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
    }

    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    if (!match_data) {
        pcre2_code_free(re);
        kr_error("无法创建匹配数据");
    }

    // 循环匹配并生成展开结果
    std::string input(obj.str_val, obj.str_len);
    std::vector<Value> results;
    PCRE2_SIZE offset = 0;
    PCRE2_SIZE input_len = input.size();

    while (true) {
        int rc = pcre2_match(re,
                             (PCRE2_SPTR)input.c_str(), input_len,
                             offset,
                             0,
                             match_data,
                             NULL);
        if (rc <= 0) break;

        PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
        PCRE2_SIZE match_start = ovector[0];
        PCRE2_SIZE match_end   = ovector[1];

        // 按模板生成字符串
        std::string expanded;
        for (size_t i = 0; i < tmpl.size(); ++i) {
            char c = tmpl[i];
            if (c == '&') {
                if (i + 1 < tmpl.size() && isdigit(tmpl[i+1])) {
                    int group = tmpl[i+1] - '0';
                    i++;
                    if (group < rc) {
                        PCRE2_SIZE start = ovector[2*group];
                        PCRE2_SIZE end   = ovector[2*group + 1];
                        if (start != PCRE2_UNSET) {
                            expanded.append(input, start, end - start);
                        }
                    }
                } else if (i + 1 < tmpl.size() && tmpl[i+1] == '&') {
                    expanded.push_back('&');
                    i++;
                } else {
                    PCRE2_SIZE start = ovector[0];
                    PCRE2_SIZE end   = ovector[1];
                    if (start != PCRE2_UNSET) {
                        expanded.append(input, start, end - start);
                    }
                }
            } else {
                expanded.push_back(c);
            }
        }

        results.push_back(make_string(expanded.c_str()));

        if (match_end == match_start) {
            offset = match_end + 1;
            if (offset > input_len) break;
        } else {
            offset = match_end;
        }
        if (offset >= input_len) break;
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(re);

    // 返回数组
    Value* elems = (Value*)malloc(results.size() * sizeof(Value));
    for (size_t i = 0; i < results.size(); ++i)
        elems[i] = results[i];   // 移动（已有所有权）
    Value result_arr = make_array(elems, (int)results.size());
    free(elems);
    return result_arr;
}

// 解析 application/x-www-form-urlencoded 字符串 → 对象
static Value parse_urlencoded(const std::string& input) {
    std::vector<ObjectEntry> pairs;
    size_t pos = 0;

    auto url_decode = [](const std::string& s) -> std::string {
        std::string out;
        for (size_t i = 0; i < s.size(); i++) {
            if (s[i] == '+') {
                out += ' ';
            } else if (s[i] == '%' && i + 2 < s.size() &&
                       isxdigit((unsigned char)s[i+1]) &&
                       isxdigit((unsigned char)s[i+2])) {
                char hex[3] = { s[i+1], s[i+2], 0 };
                out += (char)strtol(hex, nullptr, 16);
                i += 2;
            } else {
                out += s[i];
            }
        }
        return out;
    };

    while (pos < input.size()) {
        size_t amp = input.find('&', pos);
        if (amp == std::string::npos) amp = input.size();
        std::string pair = input.substr(pos, amp - pos);
        pos = amp + 1;
        if (pair.empty()) continue;

        size_t eq = pair.find('=');
        std::string key = (eq == std::string::npos) ? pair : pair.substr(0, eq);
        std::string val = (eq == std::string::npos) ? ""   : pair.substr(eq + 1);
        key = url_decode(key);
        val = url_decode(val);

        pairs.push_back({ strdup(key.c_str()), make_string(val.c_str()) });
    }

    Value obj = make_object(pairs.data(), (int)pairs.size());
    for (auto& p : pairs) { free(p.key); free_value(&p.value); }
    return copy_value(obj);
}
 
 static Value method_enthaelt(Value obj, ASTNode** args, int arg_count) {
     if (obj.type != VAL_STRING) {
         kr_error("Fehler: enthält 只能用于字符串\n");
         
     }
     if (arg_count != 1) {
         kr_error("Fehler: enthält 需要 1 个参数\n");
         
     }
     Value sub = eval_expr(args[0]);
     if (sub.type != VAL_STRING) {
         kr_error("Fehler: enthält 参数必须是字符串\n");
         
     }
     std::string hay(obj.str_val, obj.str_len);
     std::string needle(sub.str_val, sub.str_len);
     int res = (hay.find(needle) != std::string::npos) ? 1 : 0;
     free_value(&sub);
     return make_int(res);
 }
 
 static Value method_faengtAnMit(Value obj, ASTNode** args, int arg_count) {
     if (obj.type != VAL_STRING) {
         kr_error("Fehler: fängtAnMit 只能用于字符串\n");
         
     }
     if (arg_count != 1) {
         kr_error("Fehler: fängtAnMit 需要 1 个参数\n");
         
     }
     Value sub = eval_expr(args[0]);
     if (sub.type != VAL_STRING) {
         kr_error("Fehler: fängtAnMit 参数必须是字符串\n");
         
     }
     int res = 0;
    if (obj.str_len >= sub.str_len) {
        res = (memcmp(obj.str_val, sub.str_val, sub.str_len) == 0);
    }
     free_value(&sub);
     return make_int(res);
 }
 
 static Value method_abschnitt(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING)
        kr_error("abschnitt/ab 只能用于字符串");
    if (arg_count < 1 || arg_count > 2)
        kr_error("abschnitt/ab 需要 1 或 2 个参数（起始, [结束]）");

    Value start_val = eval_expr(args[0]);
    long long start = value_to_ll(start_val);
    free_value(&start_val);

    std::string s(obj.str_val, obj.str_len);
    long long char_len = (long long)utf8_length(s);

    long long end;
    if (arg_count == 2) {
        Value end_val = eval_expr(args[1]);
        end = value_to_ll(end_val);
        free_value(&end_val);
    } else {
        end = char_len;   // 默认到末尾，相当于 [x:]
    }

    // 处理负数索引
    if (start < 0) start = char_len + start;
    if (end < 0)   end   = char_len + end + 1;   // 开区间，-1 表示到最后一个字符（含）

    // 边界裁剪
    if (start < 0) start = 0;
    if (end > char_len) end = char_len;
    if (start > end) start = end;    // 空切片

    // 定位字节偏移
    size_t byte_start = 0, byte_end = 0;
    long long pos = 0;
    for (size_t i = 0; i < s.size(); ) {
        size_t len;
        utf8_char_width(&s[i], &len);
        if (pos == start) byte_start = i;
        if (pos == end)   { byte_end = i; break; }
        i += len;
        pos++;
    }
    if (end >= char_len) byte_end = s.size();

    std::string result = s.substr(byte_start, byte_end - byte_start);
    return make_string(result.c_str());
}
 
 static Value method_stelleVon(Value obj, ASTNode** args, int arg_count) {
     if (obj.type != VAL_STRING) {
         kr_error("Fehler: stelleVon 只能用于字符串\n");
         
     }
     if (arg_count != 1) {
         kr_error("Fehler: stelleVon 需要 1 个参数\n");
         
     }
     Value sub = eval_expr(args[0]);
     if (sub.type != VAL_STRING) {
         kr_error("Fehler: stelleVon 参数必须是字符串\n");
         
     }
     std::string hay(obj.str_val, obj.str_len);
    std::string needle(sub.str_val, sub.str_len);
    size_t p = hay.find(needle);
    int pos = (p == std::string::npos) ? -1 : (int)p;
     free_value(&sub);
     return make_int(pos);
 }
 
 static Value method_letzteStelleVon(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) {
        kr_error("Fehler: letzteStelleVon 只能用于字符串\n");
    }
    if (arg_count != 1) {
        kr_error("Fehler: letzteStelleVon 需要 1 个参数\n");
    }
    Value sub = eval_expr(args[0]);
    if (sub.type != VAL_STRING) {
        kr_error("Fehler: letzteStelleVon 参数必须是字符串\n");
    }

    std::string hay(obj.str_val, obj.str_len);
    std::string needle(sub.str_val, sub.str_len);
    size_t p = hay.rfind(needle);
    int pos = (p == std::string::npos) ? -1 : (int)p;

    free_value(&sub);
    return make_int(pos);
}
 
 static Value method_trim(Value obj, ASTNode** args, int arg_count) {
     if (obj.type != VAL_STRING) {
         kr_error("Fehler: trim 只能用于字符串\n");
         
     }
     if (arg_count != 0) {
         kr_error("Fehler: trim 不需要参数\n");
         
     }
     std::string s(obj.str_val, obj.str_len);
    size_t start = 0, end = s.size();
    while (start < end && isspace((unsigned char)s[start])) start++;
    while (end > start && isspace((unsigned char)s[end-1])) end--;
    return make_string_len(s.data() + start, end - start);
 }
 
 static Value method_alsZahl(Value obj, ASTNode** fmt_args, int fmt_count) {
    // ---------- 1. 如果已经是数值，直接返回 ----------
    if (obj.type == VAL_INT || obj.type == VAL_INT64 || obj.type == VAL_FLOAT) {
        return copy_value(obj);
    }

    // ---------- 2. 只支持字符串 ----------
    if (obj.type != VAL_STRING) {
        kr_error("alsZahl 仅支持字符串、整数或浮点数");
    }

    // ---------- 3. 解析格式参数 ----------
    int base = 0;              // 0 表示自动检测
    bool want_int = false;
    bool want_float = false;
    RoundingMode mode = ROUND_HALF_UP;

    for (int i = 0; i < fmt_count; i++) {
        Value v = eval_expr(fmt_args[i]);
        if (v.type == VAL_INT || v.type == VAL_INT64) {
            long long b = value_to_ll(v);
            if (b < 2 || b > 36) kr_error("进制必须在 2 到 36 之间");
            base = (int)b;
        } else if (v.type == VAL_STRING) {
            std::string s = v.str_val;
            if (s == "z") {
                want_int = true;
            } else if (s == "k") {
                want_float = true;
            } else if (s == "^" || s == "auf") {
                mode = ROUND_CEIL;
            } else if (s == "_" || s == "ab") {
                mode = ROUND_FLOOR;
            } else {
                // 未知字符串，忽略或警告
            }
        }
        free_value(&v);
    }

    // ---------- 4. 准备数字字符串（去除前导空白） ----------
    std::string num_str(obj.str_val, obj.str_len);
    size_t start = num_str.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) {
        kr_error("空字符串无法转换为数字");
    }
    size_t end = num_str.find_last_not_of(" \t\n\r");
    num_str = num_str.substr(start, end - start + 1);

    // ---------- 5. 如果显式指定了进制，剥离常见前缀 ----------
    if (base != 0) {
        if (num_str.size() >= 2 && num_str[0] == '0') {
            char second = num_str[1];
            if ((second == 'x' || second == 'X') && base == 16) {
                num_str = num_str.substr(2);
            } else if ((second == 'b' || second == 'B') && base == 2) {
                num_str = num_str.substr(2);
            } else if ((second == 'o' || second == 'O') && base == 8) {
                num_str = num_str.substr(2);
            }
        }
    }

    // ---------- 6. 自动检测进制（若未指定） ----------
    if (base == 0) {
        if (num_str.size() > 2 && num_str[0] == '0') {
            char second = num_str[1];
            if (second == 'x' || second == 'X') {
                base = 16;
            } else if (second == 'b' || second == 'B') {
                base = 2;
            } else if (second == 'o' || second == 'O') {
                base = 8;
            } else {
                base = 10;   // 普通十进制（允许前导零，但不视为八进制）
            }
        } else {
            base = 10;
        }
    }

    // ---------- 7. 根据内容决定类型（若未明确指定） ----------
    if (!want_int && !want_float) {
        // 检查是否存在小数点、指数（e/E）或十六进制指数（p/P）
        bool has_dot = (num_str.find('.') != std::string::npos);
        bool has_exp = (num_str.find('e') != std::string::npos || 
                        num_str.find('E') != std::string::npos ||
                        num_str.find('p') != std::string::npos ||
                        num_str.find('P') != std::string::npos);
        if (has_dot || has_exp) {
            want_float = true;
        } else {
            want_int = true;
        }
    }

    // ---------- 8. 执行转换 ----------
    Value result;
    if (want_int) {
        mpz_t z;
        mpz_init(z);
        // 尝试解析为整数（mpz_set_str 在 base=0 时也能自动检测，但这里 base 已确定）
        if (mpz_set_str(z, num_str.c_str(), base) == 0) {
            result = make_int(z);
        } else {
            // 整数解析失败 → 尝试浮点数解析后再取整
            mpf_t f;
            mpf_init(f);
            if (mpf_set_str(f, num_str.c_str(), base) == 0) {
                mpf_t rounded;
                mpf_init(rounded);
                switch (mode) {
                    case ROUND_CEIL:    mpf_ceil(rounded, f);   break;
                    case ROUND_FLOOR:   mpf_floor(rounded, f);  break;
                    default:            mpf_round(rounded, f);  break;
                }
                mpz_set_f(z, rounded);
                result = make_int(z);
                mpf_clear(rounded);
                mpf_clear(f);
            } else {
                mpf_clear(f);
                mpz_clear(z);
                kr_error("alsZahl: 无法将 '%s' 解析为整数（进制 %d）", num_str.c_str(), base);
            }
        }
        mpz_clear(z);
    } else { // want_float
        mpf_t f;
        mpf_init(f);
        if (mpf_set_str(f, num_str.c_str(), base) == 0) {
            result = make_float(f);
        } else {
            mpf_clear(f);
            kr_error("alsZahl: 无法将 '%s' 解析为浮点数（进制 %d）", num_str.c_str(), base);
        }
        mpf_clear(f);
    }

    return result;
}

// 格式说明符结构
struct FormatSpec {
    int width = 0;
    int precision = -1;
    char separator = '\0';
    char type = 't';
    bool has_width = false;
    bool zero_pad = false;
    RoundingMode mode = ROUND_HALF_UP;
};

// 解析格式字符串（如 "10.2k^"）
static FormatSpec parse_new_format(const std::string& fmt) {
    FormatSpec spec;
    if (fmt.empty()) return spec;

    size_t pos = 0;
    size_t len = fmt.size();

    // 1. 解析前导 '0' 填充标志
    if (pos < len && fmt[pos] == '0') {
        spec.zero_pad = true;
        pos++;
    }

    // 2. 解析宽度（数字）
    if (pos < len && isdigit(fmt[pos])) {
        spec.width = 0;
        while (pos < len && isdigit(fmt[pos])) {
            spec.width = spec.width * 10 + (fmt[pos] - '0');
            pos++;
        }
        spec.has_width = true;
    }

    // 3. 解析分隔符（非数字、非点、非字母、非取整符、非%）
    if (pos < len && !isdigit(fmt[pos]) && fmt[pos] != '.' &&
        !isalpha(fmt[pos]) && fmt[pos] != '^' && fmt[pos] != '_' && fmt[pos] != '%') {
        spec.separator = fmt[pos];
        pos++;
    }

    // 4. 解析精度（以 '.' 开头）
    if (pos < len && fmt[pos] == '.') {
        pos++;
        if (pos < len && isdigit(fmt[pos])) {
            spec.precision = 0;
            while (pos < len && isdigit(fmt[pos])) {
                spec.precision = spec.precision * 10 + (fmt[pos] - '0');
                pos++;
            }
        } else {
            spec.precision = 0;   // 点后无数字 => 精度0
        }
    }

    // 5. 解析类型（字母或 '%'）
    if (pos < len && (isalpha(fmt[pos]) || fmt[pos] == '%')) {
        spec.type = fmt[pos];
        pos++;
    } else {
        spec.type = 't';   // 默认文本
    }

    // 6. 解析取整修饰符（仅对 k/w 有效）
    if (pos < len && (fmt[pos] == '^' || fmt[pos] == '_')) {
        if (spec.type == 'k' || spec.type == 'w') {
            spec.mode = (fmt[pos] == '^') ? ROUND_CEIL : ROUND_FLOOR;
        }
        pos++;
    }

    // 忽略多余字符（可警告）
    return spec;
}

static std::string insert_thousands(const std::string& num, char sep) {
    if (num.empty() || sep == '\0') return num;
    std::string res;
    size_t start = 0;
    if (num[0] == '-' || num[0] == '+') {
        res += num[0];
        start = 1;
    }
    std::string part = num.substr(start);
    if (part.empty()) return res;
    std::string with_sep;
    int cnt = 0;
    for (int i = (int)part.length() - 1; i >= 0; --i) {
        with_sep = part[i] + with_sep;
        cnt++;
        if (cnt % 3 == 0 && i != 0) {
            with_sep = sep + with_sep;
        }
    }
    return res + with_sep;
}

static inline void mpf_round_half_up(mpf_t rop, const mpf_t op) {
    mpf_t tmp, half, eps;
    mpf_init(tmp);
    mpf_init_set_d(half, 0.5);
    mpf_init_set_d(eps, 1e-15);          // 微小修正，仅用于抵消浮点误差
    if (mpf_sgn(op) >= 0) {
        mpf_add(tmp, op, half);
        mpf_add(tmp, tmp, eps);          // 加 eps 确保 0.5 进位
        mpf_floor(rop, tmp);
    } else {
        mpf_sub(tmp, op, half);
        mpf_sub(tmp, tmp, eps);          // 减 eps 确保 -0.5 向负无穷进位
        mpf_ceil(rop, tmp);
    }
    mpf_clear(tmp);
    mpf_clear(half);
    mpf_clear(eps);
}

static std::string format_mpf_decimal(mpf_t val_mpf, int precision, char sep_char, RoundingMode mode) {
    if (precision < 0) {
        // 检查是否为整数
        if (mpf_integer_p(val_mpf)) {
            mpz_t z;
            mpz_init(z);
            mpz_set_f(z, val_mpf);
            char* s = mpz_get_str(NULL, 10, z);
            std::string result(s);
            free(s);
            mpz_clear(z);
            return result;
        } else {
            char* s = value_to_string(make_float(val_mpf));
            std::string result(s);
            free(s);
            return result;
        }
    }

    // 1. 计算 factor = 10^precision (精确整数)
    mpz_t factor;
    mpz_init(factor);
    mpz_ui_pow_ui(factor, 10, precision);

    // 2. 将 val_mpf 乘以 factor，得到浮点数 scaled
    mpf_t scaled;
    mpf_init(scaled);
    mpf_t factor_f;
    mpf_init(factor_f);
    mpf_set_z(factor_f, factor);          // 将整数转为浮点数
    mpf_mul(scaled, val_mpf, factor_f);   // 浮点乘法
    mpf_clear(factor_f);

    // 3. 根据舍入模式对 scaled 进行舍入，得到整数（以浮点形式存储）
    mpf_t rounded;
    mpf_init(rounded);
    switch (mode) {
        case ROUND_CEIL:    mpf_ceil(rounded, scaled); break;
        case ROUND_FLOOR:   mpf_floor(rounded, scaled); break;
        case ROUND_HALF_UP: mpf_round_half_up(rounded, scaled); break;
        default:            mpf_round(rounded, scaled); break;  // 若环境无 mpf_round，可改用 mpf_round_half_up
    }
    mpf_clear(scaled);

    // 4. 将舍入后的浮点数（实际是整数）转换为 mpz_t
    mpz_t integer;
    mpz_init(integer);
    mpz_set_f(integer, rounded);
    mpf_clear(rounded);

    // 5. 获取整数的十进制字符串
    char* int_str = mpz_get_str(NULL, 10, integer);
    std::string s(int_str);
    free(int_str);
    mpz_clear(integer);

    // 6. 处理负号
    bool negative = false;
    if (!s.empty() && s[0] == '-') {
        negative = true;
        s = s.substr(1);
    }

    // 7. 补零到至少 precision+1 位（保证整数部分至少有1位）
    if ((int)s.length() <= precision) {
        s = std::string(precision + 1 - s.length(), '0') + s;
    }

    // 8. 拆分整数部分和小数部分
    int int_len = s.length() - precision;
    std::string int_part = s.substr(0, int_len);
    std::string frac_part = s.substr(int_len);

    // 9. 应用千位分隔符（仅整数部分）
    if (sep_char != '\0') {
        std::string with_sep;
        int cnt = 0;
        for (int i = (int)int_part.length() - 1; i >= 0; --i) {
            with_sep = int_part[i] + with_sep;
            cnt++;
            if (cnt % 3 == 0 && i != 0)
                with_sep = sep_char + with_sep;
        }
        int_part = with_sep;
    }

    // 10. 组装结果
    std::string result;
    if (negative) result = "-";
    result += int_part;
    if (precision > 0)
        result += "." + frac_part;

    mpz_clear(factor);
    return result;
}

// 应用宽度和零填充，正确处理负数
static std::string apply_width(const std::string& s, int width, bool zero_pad) {
    if (width <= 0) return s;
    // 负数零填充：符号保留，数字部分补零至宽度 width
    if (zero_pad && !s.empty() && s[0] == '-') {
        std::string num = s.substr(1);
        int num_width = width;  // 宽度针对数字部分
        if ((int)num.length() >= num_width) return s;
        int needed = num_width - num.length();
        std::string filled = std::string(needed, '0') + num;
        return "-" + filled;
    }
    // 普通填充
    if ((int)s.length() >= width) return s;
    int needed = width - s.length();
    return std::string(needed, zero_pad ? '0' : ' ') + s;
}

static const std::array<const char*, 40> CUSTOM_DIGITS = {{
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j",
    "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
    "u", "v", "w", "x", "y", "z",
    "ä", "ö", "ü", "ß"
}};
static_assert(CUSTOM_DIGITS.size() == 40, "字符集长度必须为 40");

static std::string mpz_to_string_custom(const mpz_t z, int base) {
    if (base < 2 || base > 40) {
        kr_error("进制必须在 2 到 40 之间");
    }
    if (mpz_sgn(z) == 0) return "0";

    mpz_t tmp;
    mpz_init_set(tmp, z);
    bool negative = mpz_sgn(tmp) < 0;
    if (negative) mpz_neg(tmp, tmp);

    std::vector<std::string> chars;   // 存储每个字符（可能是多字节）
    while (mpz_sgn(tmp) > 0) {
        unsigned long rem = mpz_fdiv_ui(tmp, base);
        chars.push_back(CUSTOM_DIGITS[rem]);   // 先存低位
        mpz_fdiv_q_ui(tmp, tmp, base);
    }
    mpz_clear(tmp);

    // 反转 vector（此时元素为完整字符，不会破坏 UTF‑8）
    std::reverse(chars.begin(), chars.end());

    std::string result;
    for (const auto& ch : chars) result += ch;
    if (negative) result.insert(0, "-");
    return result;
}

// 将 Value 按新格式规范化为字符串（供 .alt 和 format 新语法共用）
static Value format_value_new(const Value& val, const std::string& fmt) {
    if (!fmt.empty()) {
        bool is_numeric = true;
        size_t start = 0;
        if (fmt[0] == '-' || fmt[0] == '+') start = 1;
        for (size_t i = start; i < fmt.size(); ++i) {
            if (!isdigit(fmt[i])) { is_numeric = false; break; }
        }
        if (is_numeric) {
            long long base_ll = std::stoll(fmt);
            if (base_ll < 2 || base_ll > 40) {
                kr_error("进制必须在 2 到 40 之间");
            }
            int base = (int)base_ll;
            std::string result_str;
        
            if (val.type == VAL_INT64) {
                mpz_t z;
                mpz_init(z);
                mpz_set_int64(z, val.int64_val);
                if (base == 40) {
                    result_str = mpz_to_string_custom(z, base);
                } else {
                    char* s = mpz_get_str(NULL, base, z);
                    result_str = s;
                    free(s);
                }
                mpz_clear(z);
            } 
            else if (val.type == VAL_INT) {
                if (base == 40) {
                    result_str = mpz_to_string_custom(*val.big_int, base);
                } else {
                    char* s = mpz_get_str(NULL, base, *val.big_int);
                    result_str = s;
                    free(s);
                }
            }
            else if (val.type == VAL_FLOAT) {
                // 浮点数通常不支持进制转换，直接转为字符串表示
                if (mpf_integer_p(*val.mpf_val)) {
                    mpz_t z;
                    mpz_init(z);
                    mpz_set_f(z, *val.mpf_val);
                    if (base == 40) {
                        result_str = mpz_to_string_custom(z, base);
                    } else {
                        char* s = mpz_get_str(NULL, base, z);
                        result_str = s;
                        free(s);
                    }
                    mpz_clear(z);
                } else {
                    char* s = value_to_string(val);
                    result_str = s;
                    free(s);
                }
            } else {
                char* s = value_to_string(val);
                result_str = s;
                free(s);
            }
        
            return make_string(result_str.c_str());
        }
    }
    FormatSpec spec = parse_new_format(fmt);
    std::string result_str;

    if (val.type == VAL_INT64) {
        mpf_t f;
        mpf_init(f);
        mpf_set_int64(f, val.int64_val);

        if (spec.type == 'z' || spec.type == 'd' || spec.type == 'x' || spec.type == 'X') {
            mpz_t num;
            mpz_init(num);
            // 根据 val.type 获取整数值
            if (val.type == VAL_INT64) {
                mpz_set_int64(num, val.int64_val);
            } else if (val.type == VAL_INT) {
                mpz_set(num, *val.big_int);
            } else if (val.type == VAL_FLOAT) {
                // 浮点数需要先舍入为整数
                mpf_t rounded;
                mpf_init(rounded);
                switch (spec.mode) { // 使用解析出的舍入模式
                    case ROUND_CEIL:    mpf_ceil(rounded, *val.mpf_val); break;
                    case ROUND_FLOOR:   mpf_floor(rounded, *val.mpf_val); break;
                    case ROUND_HALF_UP: mpf_round(rounded, *val.mpf_val); break;
                    default:            mpf_round(rounded, *val.mpf_val); break;
                }
                mpz_set_f(num, rounded);
                mpf_clear(rounded);
            } else {
                kr_error("format_value_new: 整数格式不支持该类型");
            }
        
            int radix = (spec.type == 'x' || spec.type == 'X') ? 16 : 10;
            char* s = mpz_get_str(NULL, radix, num);
            std::string num_str = s;
            free(s);
            mpz_clear(num);
        
            if (spec.type == 'X') {
                for (char& c : num_str) if (c >= 'a' && c <= 'f') c = c - 'a' + 'A';
            }
            // 千位分隔符仅十进制有效
            if (spec.separator != '\0' && radix == 10) {
                num_str = insert_thousands(num_str, spec.separator);
            }
            // 宽度填充（可根据需要保留）
            num_str = apply_width(num_str, spec.width, spec.zero_pad);
            result_str = num_str;
        } else if (spec.type == 'k' || spec.type == 'w') {
            result_str = format_mpf_decimal(f, spec.precision, spec.separator, spec.mode);
            result_str = apply_width(result_str, spec.width, spec.zero_pad);
        } else if (spec.type == 'e') {
            // 科学计数法
            int digits = (spec.precision >= 0) ? spec.precision + 1 : 7;
            mp_exp_t exp;
            char* mant = mpf_get_str(NULL, &exp, 10, digits, f);
            bool neg = false;
            if (mant[0] == '-') { neg = true; ++mant; }
            int len = strlen(mant);
            int real_exp = exp - 1;
            std::string part = (neg ? "-" : "") + std::string(1, mant[0]);
            if (len > 1) {
                part += ".";
                part.append(mant + 1, len - 1);
                if (spec.precision >= 0 && (len - 1) < spec.precision) {
                    part.append(spec.precision - (len - 1), '0');
                }
            } else if (spec.precision > 0) {
                part += ".";
                part.append(spec.precision, '0');
            }
            // 指数部分补零到两位
            std::ostringstream oss;
            oss << (real_exp >= 0 ? "+" : "-") << std::setw(2) << std::setfill('0') << abs(real_exp);
            part += 'e' + oss.str();
            free(mant - (neg ? 1 : 0));
            result_str = apply_width(part, spec.width, spec.zero_pad);
        } else if (spec.type == '%') {
            mpf_mul_ui(f, f, 100);
            result_str = format_mpf_decimal(f, (spec.precision >= 0) ? spec.precision : 0, spec.separator, spec.mode);
            result_str += '%';
            result_str = apply_width(result_str, spec.width, spec.zero_pad);
        } else {
            // 默认：字符串表示
            char* s = value_to_string(val);
            result_str = s;
            free(s);
        }
        mpf_clear(f);
        return make_string(result_str.c_str());
    } else if (val.type == VAL_INT) {
        // 将整数转为 mpf_t 以便统一处理
        mpf_t f;
        mpf_init(f);
        mpf_set_z(f, *val.big_int);

        if (spec.type == 'z' || spec.type == 'd' || spec.type == 'x' || spec.type == 'X') {
            mpz_t num;
            mpz_init(num);
            // 根据 val.type 获取整数值
            if (val.type == VAL_INT64) {
                mpz_set_int64(num, val.int64_val);
            } else if (val.type == VAL_INT) {
                mpz_set(num, *val.big_int);
            } else if (val.type == VAL_FLOAT) {
                // 浮点数需要先舍入为整数
                mpf_t rounded;
                mpf_init(rounded);
                switch (spec.mode) { // 使用解析出的舍入模式
                    case ROUND_CEIL:    mpf_ceil(rounded, *val.mpf_val); break;
                    case ROUND_FLOOR:   mpf_floor(rounded, *val.mpf_val); break;
                    case ROUND_HALF_UP: mpf_round(rounded, *val.mpf_val); break;
                    default:            mpf_round(rounded, *val.mpf_val); break;
                }
                mpz_set_f(num, rounded);
                mpf_clear(rounded);
            } else {
                kr_error("format_value_new: 整数格式不支持该类型");
            }
        
            int radix = (spec.type == 'x' || spec.type == 'X') ? 16 : 10;
            char* s = mpz_get_str(NULL, radix, num);
            std::string num_str = s;
            free(s);
            mpz_clear(num);
        
            if (spec.type == 'X') {
                for (char& c : num_str) if (c >= 'a' && c <= 'f') c = c - 'a' + 'A';
            }
            // 千位分隔符仅十进制有效
            if (spec.separator != '\0' && radix == 10) {
                num_str = insert_thousands(num_str, spec.separator);
            }
            // 宽度填充（可根据需要保留）
            num_str = apply_width(num_str, spec.width, spec.zero_pad);
            result_str = num_str;
        } else if (spec.type == 'k' || spec.type == 'w') {
            result_str = format_mpf_decimal(f, spec.precision, spec.separator, spec.mode);
            result_str = apply_width(result_str, spec.width, spec.zero_pad);
        } else if (spec.type == 'e') {
            // 科学计数法
            int digits = (spec.precision >= 0) ? spec.precision + 1 : 7;
            mp_exp_t exp;
            char* mant = mpf_get_str(NULL, &exp, 10, digits, f);
            bool neg = false;
            if (mant[0] == '-') { neg = true; ++mant; }
            int len = strlen(mant);
            int real_exp = exp - 1;
            std::string part = (neg ? "-" : "") + std::string(1, mant[0]);
            if (len > 1) {
                part += ".";
                part.append(mant + 1, len - 1);
                if (spec.precision >= 0 && (len - 1) < spec.precision) {
                    part.append(spec.precision - (len - 1), '0');
                }
            } else if (spec.precision > 0) {
                part += ".";
                part.append(spec.precision, '0');
            }
            // 指数部分补零到两位
            std::ostringstream oss;
            oss << (real_exp >= 0 ? "+" : "-") << std::setw(2) << std::setfill('0') << abs(real_exp);
            part += 'e' + oss.str();
            free(mant - (neg ? 1 : 0));
            result_str = apply_width(part, spec.width, spec.zero_pad);
        } else if (spec.type == '%') {
            mpf_mul_ui(f, f, 100);
            result_str = format_mpf_decimal(f, (spec.precision >= 0) ? spec.precision : 0, spec.separator, spec.mode);
            result_str += '%';
            result_str = apply_width(result_str, spec.width, spec.zero_pad);
        } else {
            // 默认：字符串表示
            char* s = value_to_string(val);
            result_str = s;
            free(s);
        }
        mpf_clear(f);
        return make_string(result_str.c_str());
    }
    else if (val.type == VAL_FLOAT) {
        mpf_t f;
        mpf_init_set(f, *val.mpf_val);

        if (spec.type == 'z' || spec.type == 'd' || spec.type == 'x' || spec.type == 'X') {
            mpz_t num;
            mpz_init(num);
            // 根据 val.type 获取整数值
            if (val.type == VAL_INT64) {
                mpz_set_int64(num, val.int64_val);
            } else if (val.type == VAL_INT) {
                mpz_set(num, *val.big_int);
            } else if (val.type == VAL_FLOAT) {
                // 浮点数需要先舍入为整数
                mpf_t rounded;
                mpf_init(rounded);
                switch (spec.mode) { // 使用解析出的舍入模式
                    case ROUND_CEIL:    mpf_ceil(rounded, *val.mpf_val); break;
                    case ROUND_FLOOR:   mpf_floor(rounded, *val.mpf_val); break;
                    case ROUND_HALF_UP: mpf_round(rounded, *val.mpf_val); break;
                    default:            mpf_round(rounded, *val.mpf_val); break;
                }
                mpz_set_f(num, rounded);
                mpf_clear(rounded);
            } else {
                kr_error("format_value_new: 整数格式不支持该类型");
            }
        
            int radix = (spec.type == 'x' || spec.type == 'X') ? 16 : 10;
            char* s = mpz_get_str(NULL, radix, num);
            std::string num_str = s;
            free(s);
            mpz_clear(num);
        
            if (spec.type == 'X') {
                for (char& c : num_str) if (c >= 'a' && c <= 'f') c = c - 'a' + 'A';
            }
            // 千位分隔符仅十进制有效
            if (spec.separator != '\0' && radix == 10) {
                num_str = insert_thousands(num_str, spec.separator);
            }
            // 宽度填充（可根据需要保留）
            num_str = apply_width(num_str, spec.width, spec.zero_pad);
            result_str = num_str;
        } else if (spec.type == 'k' || spec.type == 'w') {
            result_str = format_mpf_decimal(f, spec.precision, spec.separator, spec.mode);
            result_str = apply_width(result_str, spec.width, spec.zero_pad);
        } else if (spec.type == 'e') {
            int digits = (spec.precision >= 0) ? spec.precision + 1 : 7;
            mp_exp_t exp;
            char* mant = mpf_get_str(NULL, &exp, 10, digits, f);
            bool neg = false;
            if (mant[0] == '-') { neg = true; ++mant; }
            int len = strlen(mant);
            int real_exp = exp - 1;
            std::string part = (neg ? "-" : "") + std::string(1, mant[0]);
            if (len > 1) {
                part += ".";
                part.append(mant + 1, len - 1);
                if (spec.precision >= 0 && (len - 1) < spec.precision) {
                    part.append(spec.precision - (len - 1), '0');
                }
            } else if (spec.precision > 0) {
                part += ".";
                part.append(spec.precision, '0');
            }
            std::ostringstream oss;
            oss << (real_exp >= 0 ? "+" : "-") << std::setw(2) << std::setfill('0') << abs(real_exp);
            part += 'e' + oss.str();
            free(mant - (neg ? 1 : 0));
            result_str = apply_width(part, spec.width, spec.zero_pad);
        } else if (spec.type == '%') {
            mpf_mul_ui(f, f, 100);
            result_str = format_mpf_decimal(f, (spec.precision >= 0) ? spec.precision : 0, spec.separator, spec.mode);
            result_str += '%';
            result_str = apply_width(result_str, spec.width, spec.zero_pad);
        } else {
            char* s = value_to_string(val);
            result_str = s;
            free(s);
        }
        mpf_clear(f);
        return make_string(result_str.c_str());
    }
    else if (val.type == VAL_STRING) {
        if (spec.type == 't' || spec.type == '\0') {
            return make_string_len(val.str_val, val.str_len);
        } else {
            kr_warn("alt: 字符串不支持 '%c' 格式，按原样输出", spec.type);
            return make_string_len(val.str_val, val.str_len);
        }
    }
    else if (val.type == VAL_POINTER) {
        // 取到裸地址
        void* addr = val.ptr_val.smart_target
                     ? (void*)val.ptr_val.smart_target->get()
                     : (void*)val.ptr_val.raw_target;
        uintptr_t iaddr = reinterpret_cast<uintptr_t>(addr);

        char buf[64];

        // ---------- 格式类型解析 ----------
        //  t (默认)  → <Zeiger 0x...>  /  <schlauer Zeiger 0x...>
        //  p         → 纯地址（类似 printf 的 %p）: 0x...
        //  x / X     → 十六进制地址（无 0x 前缀，X 大写）
        //  d / z     → 十进制地址
        //  v / *     → 解引用并格式化被指向的值
        if (spec.type == 'p') {
            if (!addr) {
                result_str = "(null)";
            } else {
                snprintf(buf, sizeof(buf), "0x%llx",
                         (unsigned long long)iaddr);
                result_str = buf;
            }
        }
        else if (spec.type == 'x' || spec.type == 'X') {
            if (!addr) {
                result_str = "0";
            } else {
                snprintf(buf, sizeof(buf), "%llx",
                         (unsigned long long)iaddr);
                result_str = buf;
                if (spec.type == 'X') {
                    for (char& c : result_str)
                        c = (char)toupper((unsigned char)c);
                }
            }
        }
        else if (spec.type == 'd' || spec.type == 'z') {
            if (!addr) {
                result_str = "0";
            } else {
                result_str = std::to_string((unsigned long long)iaddr);
            }
        }
        else if (spec.type == 'v' || spec.type == '*') {
            // 解引用：显示指针所指目标的值
            Value* target = val.ptr_val.smart_target
                            ? val.ptr_val.smart_target->get()
                            : val.ptr_val.raw_target;
            if (!target) {
                result_str = "null";
            } else {
                char* s = value_to_string(*target);
                result_str = s ? s : "";
                free(s);
            }
        }
        else {
            // 't' 或未识别：完整文本表示（带尖括号）
            char* s = value_to_string(val);
            result_str = s ? s : "";
            free(s);
        }

        // 宽度 / 零填充（十六进制地址用零填充比较自然）
        result_str = apply_width(result_str, spec.width, spec.zero_pad);
        return make_string(result_str.c_str());
    }
    else {
        kr_error("format_value_new: 不支持的类型");
        return make_null();
    }
}
 
static Value method_alsText(Value obj, ASTNode** args, int arg_count) {
    int base = 10;
    std::string fmt_str;
    RoundingMode mode = ROUND_HALF_UP;
    bool has_fmt = false;

    for (int i = 0; i < arg_count; i++) {
        Value v = eval_expr(args[i]);
        if (v.type == VAL_INT || v.type == VAL_INT64) {
            long long val;
            if (v.type == VAL_INT64) {
                val = v.int64_val;
            } else { // VAL_INT
                if (!mpz_fits_slong_p(*v.big_int)) {
                    kr_error("进制参数过大，无法转换为整数");
                }
                val = mpz_get_si(*v.big_int);
            }
            if (!has_fmt && base == 10) {
                base = (int)val;
                if (base < 2 || base > 40) {
                    kr_error("进制必须在 2 到 40 之间");
                }
            }
        } else if (v.type == VAL_STRING) {
            std::string s = v.str_val;
            if (s == "^" || s == "auf") {
                mode = ROUND_CEIL;
            } else if (s == "_" || s == "ab") {
                mode = ROUND_FLOOR;
            } else {
                fmt_str = s;
                has_fmt = true;
            }
        } else {
            kr_error("alsText 参数必须是整数或字符串");
            free_value(&v);
        }
        free_value(&v);
    }

    if (!has_fmt) {
        if (base != 10) {
            return format_value_new(obj, std::to_string(base));
        }
        if (obj.type == VAL_STRING) {
            return make_string_len(obj.str_val, obj.str_len);
        }
        if (obj.type == VAL_INT || obj.type == VAL_FLOAT) {
            char* s = value_to_string(obj);
            Value res = make_string(s);
            free(s);
            return res;
        } else {
            char* s = value_to_string(obj);
            Value res = make_string(s);
            free(s);
            return res;
        }
    }

    // 追加取整修饰符（如果 mode 非默认）
    if (mode != ROUND_HALF_UP) {
        char mode_char = (mode == ROUND_CEIL) ? '^' : '_';
        if (!fmt_str.empty()) {
            char last = fmt_str.back();
            if (last == '^' || last == '_') {
                fmt_str.back() = mode_char;
            } else {
                fmt_str += mode_char;
            }
        } else {
            fmt_str = "t";
            fmt_str += mode_char;
        }
    }

    Value result = format_value_new(obj, fmt_str);
    return result;
}

static std::wstring utf8_to_wstring(const std::string& str) {
    int len = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, nullptr, 0);
    if (len == 0) {
        kr_error("UTF-8 转宽字符失败");
    }
    std::wstring wstr(len, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, &wstr[0], len);
    wstr.pop_back();  // 移除结尾的 L'\0'
    return wstr;
}

static std::string wstring_to_utf8(const std::wstring& wstr) {
    int len = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (len == 0) {
        kr_error("宽字符转 UTF-8 失败");
    }
    std::string str(len, '\0');
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &str[0], len, nullptr, nullptr);
    str.pop_back();
    return str;
}

static Value method_toUpper(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) {
        kr_error("groß 只能用于字符串");
    }
    if (arg_count != 0) {
        kr_error("groß 不需要参数");
    }
    std::string src(obj.str_val, obj.str_len);
    std::wstring wide = utf8_to_wstring(src);
    // 使用 Windows API 转换为大写（就地修改）
    CharUpperW(&wide[0]);
    std::string result = wstring_to_utf8(wide);
    return make_string(result.c_str());
}

// 1. 小写转换（groß 的反向）
static Value method_toLower(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("klein 只能用于字符串");
    if (arg_count != 0) kr_error("klein 不需要参数");
    std::string src(obj.str_val, obj.str_len);
    std::wstring wide = utf8_to_wstring(src);
    CharLowerW(&wide[0]);                       // Windows API
    std::string result = wstring_to_utf8(wide);
    return make_string(result.c_str());
}

// 2. 反转字符串（按 UTF-8 字符）
static Value method_reverse(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("umk: 类型错误(当前用于字符串)");
    if (arg_count != 0) kr_error("umkehren 不需要参数");

    std::string s(obj.str_val, obj.str_len);
    std::vector<std::string> chars;
    size_t i = 0;
    while (i < s.size()) {
        size_t len = 1;
        if ((s[i] & 0xE0) == 0xC0) len = 2;
        else if ((s[i] & 0xF0) == 0xE0) len = 3;
        else if ((s[i] & 0xF8) == 0xF0) len = 4;
        chars.push_back(s.substr(i, len));
        i += len;
    }
    std::reverse(chars.begin(), chars.end());
    std::string result;
    for (const auto& c : chars) result += c;
    return make_string(result.c_str());
}

// 3. 统计子串出现次数（不重叠）
static Value method_count(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("zähle 只能用于字符串");
    if (arg_count != 1) kr_error("zähle 需要 1 个参数（子串）");
    Value sub = eval_expr(args[0]);
    if (sub.type != VAL_STRING) kr_error("参数必须是字符串");
    std::string text(obj.str_val, obj.str_len);
    std::string pat(sub.str_val, sub.str_len);
    int count = 0;
    size_t pos = 0;
    while ((pos = text.find(pat, pos)) != std::string::npos) {
        ++count;
        pos += pat.size();
        if (pat.empty()) break;   // 防止空串死循环
    }
    free_value(&sub);
    return make_int(count);
}

// 4. 去除前缀
static Value method_remove_prefix(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("ohnePräfix 只能用于字符串");
    if (arg_count != 1) kr_error("ohnePräfix 需要 1 个参数（前缀）");

    Value prefix = eval_expr(args[0]);
    if (prefix.type != VAL_STRING) kr_error("参数必须是字符串");

    std::string s(obj.str_val, obj.str_len);
    std::string p(prefix.str_val, prefix.str_len);
    if (s.compare(0, p.size(), p) == 0)
        s.erase(0, p.size());
    free_value(&prefix);
    return make_string_len(s.data(), s.size());
}

// 5. 去除后缀
static Value method_remove_suffix(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("ohneSuffix 只能用于字符串");
    if (arg_count != 1) kr_error("ohneSuffix 需要 1 个参数（后缀）");

    Value suffix = eval_expr(args[0]);
    if (suffix.type != VAL_STRING) kr_error("参数必须是字符串");

    std::string s(obj.str_val, obj.str_len);
    std::string p(suffix.str_val, suffix.str_len);
    if (s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0)
        s.erase(s.size() - p.size());
    free_value(&suffix);
    return make_string_len(s.data(), s.size());
}

// 6. 填充（默认左填充）
static Value method_pad(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("füllen 只能用于字符串");
    if (arg_count < 1 || arg_count > 3)
        kr_error("füllen 需要 1~3 个参数：宽度, [Richtung l/r/c], [Füllzeichen]");
    Value width_val = eval_expr(args[0]);
    int width = (int)value_to_ll(width_val);
    free_value(&width_val);
    if (width < 0) kr_error("宽度不能为负数");

    char dir = 'l';
    char fill_char = ' ';
    if (arg_count >= 2) {
        Value dir_val = eval_expr(args[1]);
        if (dir_val.type != VAL_STRING || dir_val.str_val[0] == '\0')
            kr_error("Richtung muss ein String sein (l, r oder c)");
        dir = dir_val.str_val[0];
        free_value(&dir_val);
        if (dir != 'l' && dir != 'r' && dir != 'c')
            kr_error("Richtung muss 'l', 'r' oder 'c' sein");
    }
    if (arg_count >= 3) {
        Value char_val = eval_expr(args[2]);
        if (char_val.type != VAL_STRING || char_val.str_val[0] == '\0')
            kr_error("Füllzeichen muss ein Einzelzeichen sein");
        fill_char = char_val.str_val[0];
        free_value(&char_val);
    }
    std::string s(obj.str_val, obj.str_len);
    int current_len = (int)utf8_length(s);   // 字符数
    if (width <= current_len) return make_string(s.c_str());

    int pad = width - current_len;
    std::string pad_str(pad, fill_char);
    std::string result;
    if (dir == 'l') result = pad_str + s;
    else if (dir == 'r') result = s + pad_str;
    else { // center
        int left = pad / 2;
        int right = pad - left;
        result = std::string(left, fill_char) + s + std::string(right, fill_char);
    }
    return make_string(result.c_str());
}

// 7. 检查是否以某后缀结尾
static Value method_ends_with(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("endetMit 只能用于字符串");
    if (arg_count != 1) kr_error("endetMit 需要 1 个参数（后缀）");
    Value suffix = eval_expr(args[0]);
    if (suffix.type != VAL_STRING) kr_error("参数必须是字符串");
    std::string s(obj.str_val, obj.str_len);
    std::string p(suffix.str_val, suffix.str_len);
    int ok = (s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0);
    free_value(&suffix);
    return make_int(ok);
}

// 8. 重复字符串
static Value method_repeat(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("wiederholen 只能用于字符串");
    if (arg_count != 1) kr_error("wiederholen 需要 1 个参数（次数）");
    Value n_val = eval_expr(args[0]);
    long long n = value_to_ll(n_val);
    free_value(&n_val);
    if (n < 0) kr_error("重复次数不能为负数");
    std::string s(obj.str_val, obj.str_len);
    std::string result;
    for (long long i = 0; i < n; ++i) result += s;
    return make_string(result.c_str());
}

// 9. 按索引取字符（返回单字符字符串）
static Value method_char_at(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("zeichen 只能用于字符串");
    if (arg_count != 1) kr_error("zeichen 需要 1 个参数（索引）");
    Value idx_val = eval_expr(args[0]);
    long long idx = value_to_ll(idx_val);
    free_value(&idx_val);

    std::string src(obj.str_val, obj.str_len);
    int len = (int)utf8_length(src);
    if (idx < 0 || idx >= len) kr_error("索引越界");
    std::string ch = utf8_char_at(src, idx);
    return make_string(ch.c_str());
}

// 10. 排序（升序，可传入比较函数）
static Value method_sort(Value obj, ASTNode** args, int arg_count, ASTNode* obj_node) {
    if (obj.type != VAL_ARRAY) kr_error("sortieren 只能用于数组");
    if (arg_count > 1) kr_error("sortieren 可选一个比较函数");

    // 获取可修改的指针：左值则修改原变量，否则修改临时副本
    Value* arr_ptr = is_lvalue_node(obj_node) ? get_mutable_ptr(obj_node) : &obj;

    int len = arr_ptr->arr_val.length;
    if (len <= 1) {
        return copy_value(*arr_ptr);   // 长度≤1 无需排序，直接深拷贝返回
    }

    // 1. 复制元素到 vector（深拷贝）
    std::vector<Value> elems(len);
    for (int i = 0; i < len; ++i)
        elems[i] = copy_value(arr_ptr->arr_val.elements[i]);

    // 2. 创建索引数组，准备对索引排序
    std::vector<int> indices(len);
    std::iota(indices.begin(), indices.end(), 0);   // 需要 <numeric>

    Value cmp_func;
    bool has_cmp = false;
    if (arg_count == 1) {
        cmp_func = eval_expr(args[0]);
        if (cmp_func.type != VAL_FUNCTION) kr_error("比较参数必须是函数");
        has_cmp = true;
    }

    // 3. 排序（对索引进行）
    if (has_cmp) {
        std::sort(indices.begin(), indices.end(),
            [&](int i, int j) {
                const Value& a = elems[i];
                const Value& b = elems[j];
                Value call_args[2] = { copy_value(a), copy_value(b) };
                Value ret = call_function_value(cmp_func, call_args, 2, obj_node);
                long long cmp = value_to_ll(ret);
                free_value(&call_args[0]);
                free_value(&call_args[1]);
                free_value(&ret);
                return cmp < 0;
            });
        free_value(&cmp_func);
    } else {
        // 默认比较（按类型和值）
        std::sort(indices.begin(), indices.end(),
            [&](int i, int j) {
                const Value& a = elems[i];
                const Value& b = elems[j];
                if (a.type != b.type) return a.type < b.type;
                switch (a.type) {
                    case VAL_INT64:  return a.int64_val < b.int64_val;
                    case VAL_INT:    return mpz_cmp(*a.big_int, *b.big_int) < 0;
                    case VAL_FLOAT:  return mpf_cmp(*a.mpf_val, *b.mpf_val) < 0;
                    case VAL_STRING: {
                        int cmp = memcmp(a.str_val, b.str_val,
                                         std::min(a.str_len, b.str_len));
                        if (cmp != 0) return cmp < 0;
                        return a.str_len < b.str_len;
                    }
                    case VAL_ARRAY:  return a.arr_val.length < b.arr_val.length;
                    case VAL_OBJECT: return a.obj_val.count < b.obj_val.count;
                    case VAL_FUNCTION: {
                        const char* na = a.func_val.name ? a.func_val.name : "";
                        const char* nb = b.func_val.name ? b.func_val.name : "";
                        return strcmp(na, nb) < 0;
                    }
                    case VAL_NULL:   return false;
                    case VAL_FUTURE: return a.future_state.future_id < b.future_state.future_id;
                    default:         return false;
                }
            });
    }

    // 4. 按排序后的索引重建数组（深拷贝）
    std::vector<Value> sorted(len);
    for (int i = 0; i < len; ++i)
        sorted[i] = copy_value(elems[indices[i]]);

    // 5. 释放 elems 中的临时值
    for (auto& v : elems) free_value(&v);

    // 6. 写回原数组（如果 arr_ptr 指向临时对象也无妨，我们最终返回深拷贝）
    for (int i = 0; i < len; ++i) {
        free_value(&arr_ptr->arr_val.elements[i]);
        arr_ptr->arr_val.elements[i] = copy_value(sorted[i]);
    }

    // 7. 释放 sorted 中的临时值（已复制到 arr_ptr）
    for (auto& v : sorted) free_value(&v);

    // 8. 返回排序后数组的深拷贝（保证返回值独立）
    return copy_value(*arr_ptr);
}

// 11. 去重（返回新数组，保持首次出现顺序）
static Value method_unique(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("entfernenDuplikate 只能用于数组");
    if (arg_count != 0) kr_error("entfernenDuplikate 不需要参数");

    std::vector<Value> result;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        bool found = false;
        for (const auto& existing : result) {
            if (value_to_stdstring(existing) == value_to_stdstring(obj.arr_val.elements[i])) {
                found = true; break;
            }
        }
        if (!found)
            result.push_back(copy_value(obj.arr_val.elements[i]));
    }
    return make_array(result.data(), (int)result.size());
}

// 12. 子数组（切片）
static Value method_slice(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("ab/abschnitt/teil 只能用于数组");
    if (arg_count < 1 || arg_count > 2)
        kr_error("ab/abschnitt/teil 需要 1 或 2 个参数（起始, [结束]）");

    Value start_val = eval_expr(args[0]);
    long long start = value_to_ll(start_val);
    free_value(&start_val);

    long long len = obj.arr_val.length;
    long long end;
    if (arg_count == 2) {
        Value end_val = eval_expr(args[1]);
        end = value_to_ll(end_val);
        free_value(&end_val);
    } else {
        end = len;   // 默认到末尾，相当于 [x:]
    }

    if (start < 0) start = len + start;
    if (end < 0)   end = len + end + 1;   // 开区间，-1 表示到末尾
    if (start < 0) start = 0;
    if (end > len) end = len;
    if (start > end) start = end;
    long long count = end - start;
    if (count <= 0) return make_array(nullptr, 0);

    Value* elems = (Value*)malloc(count * sizeof(Value));
    for (long long i = 0; i < count; ++i)
        elems[i] = copy_value(obj.arr_val.elements[start + i]);
    Value result = make_array(elems, (int)count);
    free(elems);
    return result;
}

// 13. 检查数组是否包含某元素
static Value method_contains_array(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("enthält (Array) 只能用于数组");
    if (arg_count != 1) kr_error("enthält 需要 1 个参数（元素）");
    Value target = eval_expr(args[0]);
    for (int i = 0; i < obj.arr_val.length; ++i) {
        std::string a = value_to_stdstring(obj.arr_val.elements[i]);
        std::string b = value_to_stdstring(target);
        if (a == b) {
            free_value(&target);
            return make_int(1LL);
        }
    }
    free_value(&target);
    return make_int(0LL);
}

// 14. 查找所有匹配索引
static Value method_all_indices(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("alleIndices 只能用于数组");
    if (arg_count != 1) kr_error("alleIndices 需要 1 个参数（元素）");
    Value target = eval_expr(args[0]);
    std::vector<long long> indices;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        std::string a = value_to_stdstring(obj.arr_val.elements[i]);
        std::string b = value_to_stdstring(target);
        if (a == b) {
            indices.push_back(i);
        }
    }
    free_value(&target);
    Value* idx_vals = (Value*)malloc(indices.size() * sizeof(Value));
    for (size_t i = 0; i < indices.size(); ++i)
        idx_vals[i] = make_int(indices[i]);
    Value result = make_array(idx_vals, (int)indices.size());
    free(idx_vals);
    return result;
}

// 15. 最大值
static Value method_max(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("max 只能用于数组");
    if (arg_count != 0) kr_error("max 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有最大值");
    Value best = copy_value(obj.arr_val.elements[0]);
    for (int i = 1; i < obj.arr_val.length; ++i) {
        // 用 value_to_double 简单比较，若都是数值则用数值比较，否则字符串
        bool is_num = (best.type == VAL_INT || best.type == VAL_INT64 || best.type == VAL_FLOAT) &&
                      (obj.arr_val.elements[i].type == VAL_INT || obj.arr_val.elements[i].type == VAL_INT64 || obj.arr_val.elements[i].type == VAL_FLOAT);
        if (is_num) {
            double a = value_to_double(best);
            double b = value_to_double(obj.arr_val.elements[i]);
            if (b > a) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        } else {
            std::string sa = value_to_stdstring(best);
            std::string sb = value_to_stdstring(obj.arr_val.elements[i]);
            if (sb > sa) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        }
    }
    return best;
}

// 16. 最小值
static Value method_min(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("min 只能用于数组");
    if (arg_count != 0) kr_error("min 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有最小值");
    Value best = copy_value(obj.arr_val.elements[0]);
    for (int i = 1; i < obj.arr_val.length; ++i) {
        bool is_num = (best.type == VAL_INT || best.type == VAL_INT64 || best.type == VAL_FLOAT) &&
                      (obj.arr_val.elements[i].type == VAL_INT || obj.arr_val.elements[i].type == VAL_INT64 || obj.arr_val.elements[i].type == VAL_FLOAT);
        if (is_num) {
            double a = value_to_double(best);
            double b = value_to_double(obj.arr_val.elements[i]);
            if (b < a) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        } else {
            std::string sa = value_to_stdstring(best);
            std::string sb = value_to_stdstring(obj.arr_val.elements[i]);
            if (sb > sa) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        }
    }
    return best;
}

// 17. 求和（只对数值数组有效）
static Value method_sum(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("summe 只能用于数组");
    if (arg_count != 0) kr_error("summe 不需要参数");
    if (obj.arr_val.length == 0) return make_int(0LL);

    bool any_float = false;
    mpf_t sum; mpf_init(sum);
    mpf_set_d(sum, 0.0);
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& elem = obj.arr_val.elements[i];
        if (elem.type == VAL_FLOAT) any_float = true;
        if (elem.type == VAL_INT || elem.type == VAL_INT64 || elem.type == VAL_FLOAT) {
            mpf_t tmp; mpf_init(tmp);
            if (elem.type == VAL_FLOAT) mpf_set(tmp, *elem.mpf_val);
            else mpf_set_int64(tmp, value_to_ll(elem));
            mpf_add(sum, sum, tmp);
            mpf_clear(tmp);
        } else {
            kr_error("summe 仅支持数值数组");
        }
    }
    Value result = any_float ? make_float(sum) : make_int((long long)mpf_get_si(sum));
    mpf_clear(sum);
    return result;
}

// ---------- Base64 编码 ----------
static std::string base64_encode(const unsigned char* data, size_t len) {
    const char* base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string ret;
    int i = 0;
    unsigned char char_array_3[3];
    unsigned char char_array_4[4];
    while (len--) {
        char_array_3[i++] = *(data++);
        if (i == 3) {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
            char_array_4[3] = char_array_3[2] & 0x3f;
            for (i = 0; i < 4; i++) ret += base64_chars[char_array_4[i]];
            i = 0;
        }
    }
    if (i) {
        for (int j = i; j < 3; j++) char_array_3[j] = '\0';
        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
        char_array_4[3] = char_array_3[2] & 0x3f;
        for (int j = 0; j < i + 1; j++) ret += base64_chars[char_array_4[j]];
        while (i++ < 3) ret += '=';
    }
    return ret;
}
 
 // 数组方法
 static Value method_hinzufuegen(Value obj, ASTNode** args, int arg_count, ASTNode* obj_node) {
    // 处理数组
    if (obj.type == VAL_ARRAY) {
        if (arg_count != 1) {
            kr_error("anf/hinzufügen 对于数组需要 1 个参数");
        }
        Value new_elem = eval_expr(args[0]);
        Value* arr_ptr;
        bool is_temp = false;
        if (is_lvalue_node(obj_node)) {
            arr_ptr = get_mutable_ptr(obj_node);
        } else {
            arr_ptr = &obj;
            is_temp = true;
        }
        int old_len = arr_ptr->arr_val.length;
        arr_ptr->arr_val.elements = (Value*)realloc(arr_ptr->arr_val.elements,
                                                    (old_len + 1) * sizeof(Value));
        arr_ptr->arr_val.elements[old_len] = copy_value(new_elem);
        arr_ptr->arr_val.length++;
        free_value(&new_elem);
        return is_temp ? *arr_ptr : copy_value(*arr_ptr);
    }
    // 处理对象
    else if (obj.type == VAL_OBJECT) {
        char* key = NULL;
        Value value = make_null();

        if (arg_count == 1) {
            // ---- 方式1：参数为 { key: ..., wert: ... } ----
            Value arg = eval_expr(args[0]);
            if (arg.type != VAL_OBJECT) {
                kr_error("anf/hinzufügen 对于对象，单个参数必须是 { key: ..., wert: ... }");
            }
            for (int i = 0; i < arg.obj_val.count; i++) {
                if (strcmp(arg.obj_val.entries[i].key, "key") == 0) {
                    if (arg.obj_val.entries[i].value.type == VAL_STRING) {
                        key = dup_object_key(arg.obj_val.entries[i].value);
                    } else {
                        char* s = value_to_string(arg.obj_val.entries[i].value);
                        key = strdup(s);
                        free(s);
                    }
                } else if (strcmp(arg.obj_val.entries[i].key, "wert") == 0) {
                    value = copy_value(arg.obj_val.entries[i].value);
                }
            }
            if (!key) {
                kr_error("anf/hinzufügen 对象参数缺少 'key' 字段");
            }
            free_value(&arg);
        } else if (arg_count == 2) {
            // ---- 方式2：直接传入 (key, value) ----
            Value key_val = eval_expr(args[0]);
            if (key_val.type == VAL_STRING) {
                key = dup_object_key(key_val);
            } else {
                char* s = value_to_string(key_val);
                key = strdup(s);
                free(s);
            }
            free_value(&key_val);
            value = eval_expr(args[1]);
        } else {
            kr_error("anf/hinzufügen 对于对象需要 1 个对象参数或 2 个参数 (key, value)");
        }

        // ---- 获取可修改的对象指针 ----
        Value* obj_ptr;
        bool is_temp_obj = false;
        if (is_lvalue_node(obj_node)) {
            obj_ptr = get_mutable_ptr(obj_node);
        } else {
            obj_ptr = &obj;
            is_temp_obj = true;
        }

        // 查找或插入属性
        int found = -1;
        for (int i = 0; i < obj_ptr->obj_val.count; i++) {
            if (strcmp(obj_ptr->obj_val.entries[i].key, key) == 0) {
                found = i;
                break;
            }
        }
        if (found >= 0) {
            // 键已存在：更新值，释放新 key（因为未使用）
            free_value(&obj_ptr->obj_val.entries[found].value);
            obj_ptr->obj_val.entries[found].value = copy_value(value);
            free(key);
        } else {
            // 键不存在：添加新条目，接管 key
            obj_ptr->obj_val.count++;
            obj_ptr->obj_val.entries = (ObjectEntry*)realloc(obj_ptr->obj_val.entries,
                                        obj_ptr->obj_val.count * sizeof(ObjectEntry));
            obj_ptr->obj_val.entries[obj_ptr->obj_val.count - 1].key = key; // 接管
            obj_ptr->obj_val.entries[obj_ptr->obj_val.count - 1].value = copy_value(value);
        }
        free_value(&value);

        return is_temp_obj ? *obj_ptr : copy_value(*obj_ptr);
    }
    else {
        kr_error("anf/hinzufügen 只能用于数组或对象");
        return make_null();
    }
}

static Value method_loeschen(Value obj, ASTNode** args, int arg_count, ASTNode* obj_node) {
    if (obj.type != VAL_OBJECT) {
        kr_error("lösch 只能用于对象");
    }
    if (arg_count != 1) {
        kr_error("lösch 需要 1 个参数（键名）");
    }

    Value key_val = eval_expr(args[0]);
    if (key_val.type != VAL_STRING) {
        kr_error("键必须是字符串");
    }
    const char* key_str = key_val.str_val;

    Value* obj_ptr;
    if (is_lvalue_node(obj_node)) {
        obj_ptr = get_mutable_ptr(obj_node);
        if (obj_ptr->type != VAL_OBJECT) {
            kr_error("目标不是对象");
        }
    } else {
        obj_ptr = &obj;
    }

    int found_idx = -1;
    for (int i = 0; i < obj_ptr->obj_val.count; i++) {
        if (strcmp(obj_ptr->obj_val.entries[i].key, key_str) == 0) {
            found_idx = i;
            break;
        }
    }

    if (found_idx == -1) {
        free_value(&key_val);
        return make_null();
    }

    Value removed = copy_value(obj_ptr->obj_val.entries[found_idx].value);

    free(obj_ptr->obj_val.entries[found_idx].key);
    free_value(&obj_ptr->obj_val.entries[found_idx].value);

    // 移动后续条目
    for (int i = found_idx; i < obj_ptr->obj_val.count - 1; i++) {
        obj_ptr->obj_val.entries[i] = obj_ptr->obj_val.entries[i + 1];
    }
    obj_ptr->obj_val.count--;

    // 调整内存
    if (obj_ptr->obj_val.count > 0) {
        obj_ptr->obj_val.entries = (ObjectEntry*)realloc(
            obj_ptr->obj_val.entries,
            obj_ptr->obj_val.count * sizeof(ObjectEntry)
        );
    } else {
        free(obj_ptr->obj_val.entries);
        obj_ptr->obj_val.entries = NULL;
    }

    free_value(&key_val);
    return removed;
}
 
 static Value method_finde(Value obj, ASTNode** args, int arg_count) {
     if (obj.type != VAL_ARRAY) {
         kr_error("Fehler: finde 只能用于数组\n");
         
     }
     if (arg_count != 1) {
         kr_error("Fehler: finde 需要 1 个参数（要查找的值）\n");
         
     }
     Value target = eval_expr(args[0]);
     for (int i = 0; i < obj.arr_val.length; i++) {
         Value cur = obj.arr_val.elements[i];
         if ((cur.type == VAL_INT || cur.type == VAL_INT64) && (target.type == VAL_INT || target.type == VAL_INT64) && value_to_ll(cur) == value_to_ll(target)) {
             free_value(&target);
             return copy_value(cur);
         }
         if (cur.type == VAL_STRING && target.type == VAL_STRING &&
            cur.str_len == target.str_len &&
            memcmp(cur.str_val, target.str_val, cur.str_len) == 0) {
             free_value(&target);
             return copy_value(cur);
         }
     }
     free_value(&target);
     return make_null();
 }
 
 static Value method_findeIndex(Value obj, ASTNode** args, int arg_count) {
     if (obj.type != VAL_ARRAY) {
         kr_error("Fehler: findeIndex 只能用于数组\n");
         
     }
     if (arg_count != 1) {
         kr_error("Fehler: findeIndex 需要 1 个参数（要查找的值）\n");
         
     }
     Value target = eval_expr(args[0]);
     for (int i = 0; i < obj.arr_val.length; i++) {
         Value cur = obj.arr_val.elements[i];
         if ((cur.type == VAL_INT || cur.type == VAL_INT64) && (target.type == VAL_INT || target.type == VAL_INT64) && value_to_ll(cur) == value_to_ll(target)) {
             free_value(&target);
             return make_int(i);
         }
         if (cur.type == VAL_STRING && target.type == VAL_STRING &&
            cur.str_len == target.str_len &&
            memcmp(cur.str_val, target.str_val, cur.str_len) == 0) {
             free_value(&target);
             return make_int(i);
         }
     }
     free_value(&target);
     return make_int(-1);
 }

// 数组的 letzt 方法：无参返回最后一个元素，有参返回该元素最后出现的位置
static Value method_array_last(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) {
        kr_error("letzt 只能用于数组");
    }
    if (arg_count == 0) {
        if (obj.arr_val.length == 0) {
            kr_error("空数组没有最后一个元素");
        }
        return copy_value(obj.arr_val.elements[obj.arr_val.length - 1]);
    }
    else if (arg_count == 1) {
        Value target = eval_expr(args[0]);
        int last_idx = -1;
        for (int i = 0; i < obj.arr_val.length; i++) {
            // 使用与 findeIndex 一致的比较方式
            Value cur = obj.arr_val.elements[i];
            if ((cur.type == VAL_INT || cur.type == VAL_INT64) && (target.type == VAL_INT || target.type == VAL_INT64) && value_to_ll(cur) == value_to_ll(target)) {
                last_idx = i;
            }
            else if (cur.type == VAL_STRING && target.type == VAL_STRING &&
                cur.str_len == target.str_len &&
                memcmp(cur.str_val, target.str_val, cur.str_len) == 0) {
                last_idx = i;
            }
            // 可扩展其他类型（如浮点数、布尔等）
        }
        free_value(&target);
        return make_int(last_idx);
    }
    else {
        kr_error("letzt 需要 0 或 1 个参数");
        return make_null(); // 不会执行
    }
}

// 全部字符是否为数字（0-9）
static Value method_istZiffer(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("istZiffer 只能用于字符串");
    if (arg_count != 0) kr_error("istZiffer 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i) {
        if (!isdigit((unsigned char)obj.str_val[i])) return make_int64(0LL);
    }
    return make_int64(1LL);
}

// 全部字符是否为字母
static Value method_istBuchstabe(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("istBuchstabe 只能用于字符串");
    if (arg_count != 0) kr_error("istBuchstabe 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i) {
        if (!isalpha((unsigned char)obj.str_val[i])) return make_int64(0LL);
    }
    return make_int64(1LL);
}

// 全部字符是否为字母或数字
static Value method_istAlnum(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("istAlnum 只能用于字符串");
    if (arg_count != 0) kr_error("istAlnum 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i) {
        if (!isalnum((unsigned char)obj.str_val[i])) return make_int64(0LL);
    }
    return make_int64(1LL);
}

// 全部字符是否为空白字符（含空格、\t、\n、\r、\f、\v）
static Value method_istRaum(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("istRaum 只能用于字符串");
    if (arg_count != 0) kr_error("istRaum 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i) {
        if (!isspace((unsigned char)obj.str_val[i])) return make_int64(0LL);
    }
    return make_int64(1LL);
}

// 是否含有字母且所有字母都是大写（数字/符号不影响判断）
static Value method_istGroß(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("istGroß 只能用于字符串");
    if (arg_count != 0) kr_error("istGroß 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    bool has_alpha = false;
    for (size_t i = 0; i < obj.str_len; ++i) {
        unsigned char c = (unsigned char)obj.str_val[i];
        if (isalpha(c)) {
            has_alpha = true;
            if (!isupper(c)) return make_int64(0LL);
        }
    }
    return make_int64(has_alpha ? 1LL : 0LL);
}

// 是否含有字母且所有字母都是小写
static Value method_istKlein(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("istKlein 只能用于字符串");
    if (arg_count != 0) kr_error("istKlein 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    bool has_alpha = false;
    for (size_t i = 0; i < obj.str_len; ++i) {
        unsigned char c = (unsigned char)obj.str_val[i];
        if (isalpha(c)) {
            has_alpha = true;
            if (!islower(c)) return make_int64(0LL);
        }
    }
    return make_int64(has_alpha ? 1LL : 0LL);
}

// 检查字符串是否只包含数字（可选正负号）
static Value method_istZahl(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("istZahl 只能用于字符串");
    if (arg_count != 0) kr_error("istZahl 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    size_t i = 0;
    if (obj.str_val[0] == '-' || obj.str_val[0] == '+') i = 1;
    if (i >= obj.str_len) return make_int64(0LL);
    for (; i < obj.str_len; ++i) {
        if (!isdigit((unsigned char)obj.str_val[i])) return make_int64(0LL);
    }
    return make_int64(1LL);
}

// 删除所有出现的子串
static Value method_entferne(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("entferne 只能用于字符串");
    if (arg_count != 1) kr_error("entferne 需要 1 个参数（子串）");
    Value sub = eval_expr(args[0]);
    if (sub.type != VAL_STRING) kr_error("参数必须是字符串");
    std::string s(obj.str_val, obj.str_len);
    std::string p(sub.str_val, sub.str_len);
    free_value(&sub);
    if (p.empty()) return make_string_len(s.data(), s.size());
    std::string result;
    size_t pos = 0, prev = 0;
    while ((pos = s.find(p, prev)) != std::string::npos) {
        result.append(s, prev, pos - prev);
        prev = pos + p.size();
    }
    result.append(s, prev, std::string::npos);
    return make_string_len(result.data(), result.size());
}

// 取前 n 个字符
static Value method_anfang(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("anfang 只能用于字符串");
    if (arg_count != 1) kr_error("anfang 需要 1 个参数（长度）");
    Value n_val = eval_expr(args[0]);
    long long n = value_to_ll(n_val);
    free_value(&n_val);
    if (n < 0) n = 0;
    std::string s(obj.str_val, obj.str_len);
    size_t char_len = utf8_length(s);
    if ((size_t)n > char_len) n = char_len;
    size_t byte_end = 0;
    size_t pos = 0;
    for (long long i = 0; i < n; ++i) {
        size_t len;
        utf8_char_width(&s[pos], &len);
        pos += len;
    }
    byte_end = pos;
    return make_string_len(s.data(), byte_end);
}

// 取后 n 个字符
static Value method_rechts(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_STRING) kr_error("rechts 只能用于字符串");
    if (arg_count != 1) kr_error("rechts 需要 1 个参数（长度）");
    Value n_val = eval_expr(args[0]);
    long long n = value_to_ll(n_val);
    free_value(&n_val);
    if (n < 0) n = 0;
    std::string s(obj.str_val, obj.str_len);
    size_t char_len = utf8_length(s);
    if ((size_t)n > char_len) n = char_len;
    size_t pos = s.size();
    for (long long i = 0; i < n; ++i) {
        do { --pos; } while (pos > 0 && (s[pos] & 0xC0) == 0x80);
    }
    return make_string_len(s.data() + pos, s.size() - pos);
}

// 平均值
static Value method_mittel(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("mittel 只能用于数组");
    if (arg_count != 0) kr_error("mittel 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有平均值");
    mpf_t sum;
    mpf_init_set_d(sum, 0.0);
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& e = obj.arr_val.elements[i];
        if (e.type == VAL_FLOAT) {
            mpf_add(sum, sum, *e.mpf_val);
        } else if (e.type == VAL_INT64) {
            mpf_t t; mpf_init_set_si(t, e.int64_val); mpf_add(sum, sum, t); mpf_clear(t);
        } else if (e.type == VAL_INT) {
            mpf_t t; mpf_init(t); mpf_set_z(t, *e.big_int); mpf_add(sum, sum, t); mpf_clear(t);
        } else {
            mpf_clear(sum);
            kr_error("mittel 仅支持数值数组");
        }
    }
    mpf_t count;
    mpf_init_set_ui(count, obj.arr_val.length);
    mpf_div(sum, sum, count);
    Value res = make_float(sum);
    mpf_clear(sum); mpf_clear(count);
    return res;
}

// 乘积
static Value method_produkt(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("produkt 只能用于数组");
    if (arg_count != 0) kr_error("produkt 不需要参数");
    if (obj.arr_val.length == 0) return make_int(1LL);
    mpf_t prod;
    mpf_init_set_ui(prod, 1);
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& e = obj.arr_val.elements[i];
        if (e.type == VAL_FLOAT) {
            mpf_mul(prod, prod, *e.mpf_val);
        } else if (e.type == VAL_INT64) {
            mpf_t t; mpf_init_set_si(t, e.int64_val); mpf_mul(prod, prod, t); mpf_clear(t);
        } else if (e.type == VAL_INT) {
            mpf_t t; mpf_init(t); mpf_set_z(t, *e.big_int); mpf_mul(prod, prod, t); mpf_clear(t);
        } else {
            mpf_clear(prod);
            kr_error("produkt 仅支持数值数组");
        }
    }
    Value res = make_float(prod);
    mpf_clear(prod);
    return res;
}

// 第一个元素
static Value method_erstes(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("erstes 只能用于数组");
    if (arg_count != 0) kr_error("erstes 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有第一个元素");
    return copy_value(obj.arr_val.elements[0]);
}

// 插入元素
static Value method_einfuegen(Value obj, ASTNode** args, int arg_count, ASTNode* obj_node) {
    if (obj.type != VAL_ARRAY) kr_error("einfuegen 只能用于数组");
    if (arg_count != 2) kr_error("einfuegen 需要 2 个参数（索引, 元素）");
    Value idx_val = eval_expr(args[0]);
    long long idx = value_to_ll(idx_val);
    free_value(&idx_val);
    Value elem = eval_expr(args[1]);

    Value* arr_ptr;
    bool is_temp = false;
    if (is_lvalue_node(obj_node)) {
        arr_ptr = get_mutable_ptr(obj_node);
    } else {
        arr_ptr = &obj;
        is_temp = true;
    }
    if (idx < 0 || idx > arr_ptr->arr_val.length) {
        free_value(&elem);
        kr_error("索引越界（0 到 %lld）", arr_ptr->arr_val.length);
    }
    arr_ptr->arr_val.elements = (Value*)realloc(arr_ptr->arr_val.elements,
        (arr_ptr->arr_val.length + 1) * sizeof(Value));
    for (long long i = arr_ptr->arr_val.length; i > idx; --i) {
        arr_ptr->arr_val.elements[i] = arr_ptr->arr_val.elements[i-1];
    }
    arr_ptr->arr_val.elements[idx] = copy_value(elem);
    arr_ptr->arr_val.length++;
    free_value(&elem);
    return is_temp ? *arr_ptr : copy_value(*arr_ptr);
}

// 合并数组（返回新数组）
static Value method_vereinige_array(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("vereinige 只能用于数组");
    if (arg_count != 1) kr_error("vereinige 需要 1 个参数（另一个数组）");
    Value other = eval_expr(args[0]);
    if (other.type != VAL_ARRAY) kr_error("参数必须是数组");
    int total = obj.arr_val.length + other.arr_val.length;
    Value* elems = (Value*)malloc(total * sizeof(Value));
    for (int i = 0; i < obj.arr_val.length; ++i)
        elems[i] = copy_value(obj.arr_val.elements[i]);
    for (int i = 0; i < other.arr_val.length; ++i)
        elems[obj.arr_val.length + i] = copy_value(other.arr_val.elements[i]);
    Value res = make_array(elems, total);
    free(elems);
    free_value(&other);
    return res;
}

// 交集
static Value method_schnitt(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("schnitt 只能用于数组");
    if (arg_count != 1) kr_error("schnitt 需要 1 个参数（另一个数组）");
    Value other = eval_expr(args[0]);
    if (other.type != VAL_ARRAY) kr_error("参数必须是数组");
    std::vector<Value> result;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& a = obj.arr_val.elements[i];
        for (int j = 0; j < other.arr_val.length; ++j) {
            if (value_to_stdstring(a) == value_to_stdstring(other.arr_val.elements[j])) {
                result.push_back(copy_value(a));
                break;
            }
        }
    }
    Value res = make_array(result.data(), (int)result.size());
    for (auto& v : result) free_value(&v);
    free_value(&other);
    return res;
}

// 差集
static Value method_differenz(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_ARRAY) kr_error("differenz 只能用于数组");
    if (arg_count != 1) kr_error("differenz 需要 1 个参数（另一个数组）");
    Value other = eval_expr(args[0]);
    if (other.type != VAL_ARRAY) kr_error("参数必须是数组");
    std::vector<Value> result;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& a = obj.arr_val.elements[i];
        bool found = false;
        for (int j = 0; j < other.arr_val.length; ++j) {
            if (value_to_stdstring(a) == value_to_stdstring(other.arr_val.elements[j])) {
                found = true;
                break;
            }
        }
        if (!found) result.push_back(copy_value(a));
    }
    Value res = make_array(result.data(), (int)result.size());
    for (auto& v : result) free_value(&v);
    free_value(&other);
    return res;
}

// 删除所有等于给定值的元素
static Value method_entferne_array(Value obj, ASTNode** args, int arg_count, ASTNode* obj_node) {
    if (obj.type != VAL_ARRAY) kr_error("entferne 只能用于数组");
    if (arg_count != 1) kr_error("entferne 需要 1 个参数（要删除的值）");
    Value target = eval_expr(args[0]);
    Value* arr_ptr;
    bool is_temp = false;
    if (is_lvalue_node(obj_node)) {
        arr_ptr = get_mutable_ptr(obj_node);
    } else {
        arr_ptr = &obj;
        is_temp = true;
    }
    std::string target_str = value_to_stdstring(target);
    int write = 0;
    for (int i = 0; i < arr_ptr->arr_val.length; ++i) {
        if (value_to_stdstring(arr_ptr->arr_val.elements[i]) != target_str) {
            if (write != i) {
                arr_ptr->arr_val.elements[write] = arr_ptr->arr_val.elements[i];
            }
            write++;
        } else {
            free_value(&arr_ptr->arr_val.elements[i]);
        }
    }
    arr_ptr->arr_val.length = write;
    if (write > 0) {
        arr_ptr->arr_val.elements = (Value*)realloc(arr_ptr->arr_val.elements, write * sizeof(Value));
    } else {
        free(arr_ptr->arr_val.elements);
        arr_ptr->arr_val.elements = NULL;
    }
    free_value(&target);
    return is_temp ? *arr_ptr : copy_value(*arr_ptr);
}

// 随机打乱数组
static Value method_mische(Value obj, ASTNode** args, int arg_count, ASTNode* obj_node) {
    if (obj.type != VAL_ARRAY) kr_error("mische 只能用于数组");
    if (arg_count != 0) kr_error("mische 不需要参数");
    Value* arr_ptr;
    bool is_temp = false;
    if (is_lvalue_node(obj_node)) {
        arr_ptr = get_mutable_ptr(obj_node);
    } else {
        arr_ptr = &obj;
        is_temp = true;
    }
    int n = arr_ptr->arr_val.length;
    for (int i = n - 1; i > 0; --i) {
        int j = rand() % (i + 1);
        Value tmp = arr_ptr->arr_val.elements[i];
        arr_ptr->arr_val.elements[i] = arr_ptr->arr_val.elements[j];
        arr_ptr->arr_val.elements[j] = tmp;
    }
    return is_temp ? *arr_ptr : copy_value(*arr_ptr);
}

// 合并对象（浅合并，返回新对象）
static Value method_vereinige_obj(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_OBJECT) kr_error("vereinige 只能用于对象");
    if (arg_count != 1) kr_error("vereinige 需要 1 个参数（另一个对象）");
    Value other = eval_expr(args[0]);
    if (other.type != VAL_OBJECT) kr_error("参数必须是对象");
    std::unordered_map<std::string, Value> map;
    for (int i = 0; i < obj.obj_val.count; ++i) {
        map[obj.obj_val.entries[i].key] = copy_value(obj.obj_val.entries[i].value);
    }
    for (int i = 0; i < other.obj_val.count; ++i) {
        auto it = map.find(other.obj_val.entries[i].key);
        if (it != map.end()) free_value(&it->second);
        map[other.obj_val.entries[i].key] = copy_value(other.obj_val.entries[i].value);
    }
    ObjectEntry* entries = (ObjectEntry*)malloc(map.size() * sizeof(ObjectEntry));
    int idx = 0;
    for (auto& kv : map) {
        entries[idx].key = strdup(kv.first.c_str());
        entries[idx].value = kv.second;
        idx++;
    }
    Value res = make_object(entries, idx);
    for (int i = 0; i < idx; ++i) {
        free(entries[i].key);
        free_value(&entries[i].value);
    }
    free(entries);
    free_value(&other);
    return res;
}

// 浅拷贝对象
static Value method_kopiere(Value obj, ASTNode** args, int arg_count) {
    if (obj.type != VAL_OBJECT) kr_error("kopiere 只能用于对象");
    if (arg_count != 0) kr_error("kopiere 不需要参数");
    return copy_value(obj);
}

// ============================================================================
// 编译器版方法（c_ 前缀，非 static，接收已求值的 Value* 参数）
// 追加到 method.cpp 末尾。辅助函数不在此重复。
// ============================================================================

Value c_method_passende(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("Fehler: passende 只能用于字符串\n");
    if (argc != 1) kr_error("Fehler: passende 需要 1 个参数（正则字符串或正则对象）\n");

    Value pattern_val = copy_value(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;

    if (pattern_val.type == VAL_OBJECT) {
        std::string pat, flg;
        bool has_pat = false;
        for (int i = 0; i < pattern_val.obj_val.count; ++i) {
            Value& entry_val = pattern_val.obj_val.entries[i].value;
            if (strcmp(pattern_val.obj_val.entries[i].key, "muster") == 0 &&
                entry_val.type == VAL_STRING) {
                pat.assign(entry_val.str_val, entry_val.str_len);
                has_pat = true;
            }
            if (strcmp(pattern_val.obj_val.entries[i].key, "flags") == 0 &&
                entry_val.type == VAL_STRING) {
                flg.assign(entry_val.str_val, entry_val.str_len);
            }
        }
        if (!has_pat) { free_value(&pattern_val); kr_error("正则对象缺少 'muster' 字段"); }
        pattern_str = pat;
        if (strchr(flg.c_str(), 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg.c_str(), 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg.c_str(), 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg.c_str(), 'x')) pcre2_options |= PCRE2_EXTENDED;
        free_value(&pattern_val);
    } else if (pattern_val.type == VAL_STRING) {
        pattern_str.assign(pattern_val.str_val, pattern_val.str_len);
        free_value(&pattern_val);
    } else {
        free_value(&pattern_val);
        kr_error("passende 参数必须是字符串或正则对象\n");
    }

    pattern_str = convert_ampersand_to_dollar(pattern_str);

    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)pattern_str.c_str(), pattern_str.size(),
        pcre2_options, &errorcode, &erroroffset, NULL);
    if (!re) {
        PCRE2_UCHAR errbuf[256];
        pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
    }

    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    if (!match_data) { pcre2_code_free(re); kr_error("无法创建匹配数据"); }

    std::string s(obj.str_val, obj.str_len);
    int rc = pcre2_match(re, (PCRE2_SPTR)s.c_str(), s.size(), 0, 0, match_data, NULL);
    if (rc <= 0) {
        pcre2_match_data_free(match_data);
        pcre2_code_free(re);
        return make_null();
    }

    PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
    Value* elems = (Value*)malloc(rc * sizeof(Value));
    if (!elems) {
        pcre2_match_data_free(match_data);
        pcre2_code_free(re);
        kr_error("内存分配失败");
    }

    for (int i = 0; i < rc; ++i) {
        size_t start = ovector[2 * i];
        size_t end = ovector[2 * i + 1];
        if (start == PCRE2_UNSET) {
            elems[i] = make_string("");
        } else {
            std::string submatch = s.substr(start, end - start);
            elems[i] = make_string(submatch.c_str());
        }
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(re);
    return make_array(elems, rc);
}

Value c_method_ersetze(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("ersetze 只能用于字符串");
    if (argc != 2) kr_error("ersetze 需要 2 个参数");

    Value pat_val = copy_value(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;

    if (pat_val.type == VAL_STRING) {
        pattern_str.assign(pat_val.str_val, pat_val.str_len);
    } else if (pat_val.type == VAL_OBJECT) {
        const char* pat = nullptr;
        const char* flg = "";
        for (int i = 0; i < pat_val.obj_val.count; ++i) {
            if (strcmp(pat_val.obj_val.entries[i].key, "muster") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                pat = pat_val.obj_val.entries[i].value.str_val;
            }
            if (strcmp(pat_val.obj_val.entries[i].key, "flags") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                flg = pat_val.obj_val.entries[i].value.str_val;
            }
        }
        if (!pat) { free_value(&pat_val); kr_error("正则对象缺少 pattern"); }
        pattern_str = pat;
        if (strchr(flg, 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg, 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg, 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg, 'x')) pcre2_options |= PCRE2_EXTENDED;
    } else {
        free_value(&pat_val);
        kr_error("第一个参数必须是字符串或正则对象");
    }
    free_value(&pat_val);

    Value repl_val = copy_value(args[1]);
    if (repl_val.type != VAL_STRING) { free_value(&repl_val); kr_error("第二个参数必须是字符串"); }
    std::string repl_str(repl_val.str_val, repl_val.str_len);
    free_value(&repl_val);

    pattern_str = convert_ampersand_to_dollar(pattern_str);

    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)pattern_str.c_str(), pattern_str.size(),
        pcre2_options, &errorcode, &erroroffset, NULL);
    if (!re) {
        PCRE2_UCHAR errbuf[256];
        pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
    }

    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    if (!match_data) { pcre2_code_free(re); kr_error("无法创建匹配数据"); }

    std::string input(obj.str_val, obj.str_len);
    std::string output;
    PCRE2_SIZE offset = 0;
    PCRE2_SIZE input_len = input.size();

    while (true) {
        int rc = pcre2_match(re, (PCRE2_SPTR)input.c_str(), input_len,
                             offset, 0, match_data, NULL);
        if (rc <= 0) { output.append(input, offset, std::string::npos); break; }

        PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
        PCRE2_SIZE match_start = ovector[0];
        PCRE2_SIZE match_end   = ovector[1];

        output.append(input, offset, match_start - offset);

        std::string replacement;
        for (size_t i = 0; i < repl_str.size(); ++i) {
            if (repl_str[i] == '\\') {
                if (i + 1 < repl_str.size()) replacement.push_back(repl_str[++i]);
            } else if (repl_str[i] == '&') {
                if (i + 1 < repl_str.size() && isdigit(repl_str[i+1])) {
                    int group = repl_str[i+1] - '0';
                    i++;
                    if (group < rc) {
                        PCRE2_SIZE start = ovector[2*group];
                        PCRE2_SIZE end   = ovector[2*group + 1];
                        if (start != PCRE2_UNSET) replacement.append(input, start, end - start);
                    }
                } else if (i + 1 < repl_str.size() && repl_str[i+1] == '&') {
                    replacement.push_back('&');
                    i++;
                } else {
                    PCRE2_SIZE start = ovector[0];
                    PCRE2_SIZE end   = ovector[1];
                    if (start != PCRE2_UNSET) replacement.append(input, start, end - start);
                }
            } else {
                replacement.push_back(repl_str[i]);
            }
        }

        output += replacement;

        if (match_end == match_start) {
            offset = match_end + 1;
            if (offset > input_len) break;
        } else {
            offset = match_end;
        }
        if (offset >= input_len) break;
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(re);
    return make_string(output.c_str());
}

Value c_method_teile(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("Fehler: teil 只能用于字符串\n");
    if (argc != 1) kr_error("Fehler: teil 需要 1 个参数（正则/分隔符）\n");

    Value sep = copy_value(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;

    if (sep.type == VAL_OBJECT) {
        const char* pat = nullptr;
        const char* flg = "";
        for (int i = 0; i < sep.obj_val.count; ++i) {
            if (strcmp(sep.obj_val.entries[i].key, "muster") == 0 &&
                sep.obj_val.entries[i].value.type == VAL_STRING) {
                pat = sep.obj_val.entries[i].value.str_val;
            }
            if (strcmp(sep.obj_val.entries[i].key, "flags") == 0 &&
                sep.obj_val.entries[i].value.type == VAL_STRING) {
                flg = sep.obj_val.entries[i].value.str_val;
            }
        }
        if (!pat) { free_value(&sep); kr_error("正则对象缺少 'muster' 字段"); }
        pattern_str = pat;
        if (strchr(flg, 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg, 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg, 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg, 'x')) pcre2_options |= PCRE2_EXTENDED;
    } else if (sep.type == VAL_STRING) {
        pattern_str.assign(sep.str_val, sep.str_len);
    } else {
        free_value(&sep);
        kr_error("teil 参数必须是字符串或正则对象");
    }
    free_value(&sep);

    std::string converted = convert_ampersand_to_dollar(pattern_str);
    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)converted.c_str(), converted.size(),
        pcre2_options, &errorcode, &erroroffset, NULL);
    if (!re) kr_error("PCRE2 编译错误: 偏移 %zu", erroroffset);

    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    std::string s(obj.str_val, obj.str_len);
    std::vector<Value> parts;
    size_t pos = 0;

    while (true) {
        int rc = pcre2_match(re, (PCRE2_SPTR)s.c_str() + pos, s.size() - pos, 0, 0, match_data, NULL);
        if (rc <= 0) {
            std::string rest = s.substr(pos);
            parts.push_back(make_string(rest.c_str()));
            break;
        }
        PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
        size_t match_start = pos + ovector[0];
        size_t match_end   = pos + ovector[1];
        if (match_start > pos) {
            std::string part = s.substr(pos, match_start - pos);
            parts.push_back(make_string(part.c_str()));
        } else {
            parts.push_back(make_string(""));
        }
        pos = match_end;
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(re);

    Value result = make_array(parts.data(), (int)parts.size());
    for (auto& v : parts) free_value(&v);
    return result;
}

Value c_method_entfal(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("entfal 只能用于字符串");
    if (argc < 1 || argc > 2) kr_error("entfal 需要 1 或 2 个参数：正则, [模板]");

    Value pat_val = copy_value(args[0]);
    std::string pattern_str;
    int pcre2_options = PCRE2_UTF | PCRE2_UCP;

    if (pat_val.type == VAL_STRING) {
        pattern_str.assign(pat_val.str_val, pat_val.str_len);
    } else if (pat_val.type == VAL_OBJECT) {
        const char* pat = nullptr;
        const char* flg = "";
        for (int i = 0; i < pat_val.obj_val.count; ++i) {
            if (strcmp(pat_val.obj_val.entries[i].key, "muster") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                pat = pat_val.obj_val.entries[i].value.str_val;
            }
            if (strcmp(pat_val.obj_val.entries[i].key, "flags") == 0 &&
                pat_val.obj_val.entries[i].value.type == VAL_STRING) {
                flg = pat_val.obj_val.entries[i].value.str_val;
            }
        }
        if (!pat) { free_value(&pat_val); kr_error("正则对象缺少 'muster' 字段"); }
        pattern_str = pat;
        if (strchr(flg, 'i')) pcre2_options |= PCRE2_CASELESS;
        if (strchr(flg, 'm')) pcre2_options |= PCRE2_MULTILINE;
        if (strchr(flg, 's')) pcre2_options |= PCRE2_DOTALL;
        if (strchr(flg, 'x')) pcre2_options |= PCRE2_EXTENDED;
    } else {
        free_value(&pat_val);
        kr_error("第二个参数必须是字符串或正则对象");
    }
    free_value(&pat_val);

    std::string tmpl = "&";
    if (argc == 2) {
        Value tmpl_val = copy_value(args[1]);
        if (tmpl_val.type != VAL_STRING) { free_value(&tmpl_val); kr_error("模板必须是字符串"); }
        tmpl.assign(tmpl_val.str_val, tmpl_val.str_len);
        free_value(&tmpl_val);
    }

    pattern_str = convert_ampersand_to_dollar(pattern_str);
    int errorcode;
    PCRE2_SIZE erroroffset;
    pcre2_code* re = pcre2_compile(
        (PCRE2_SPTR)pattern_str.c_str(), pattern_str.size(),
        pcre2_options, &errorcode, &erroroffset, NULL);
    if (!re) {
        PCRE2_UCHAR errbuf[256];
        pcre2_get_error_message(errorcode, errbuf, sizeof(errbuf));
        kr_error("PCRE2 编译错误: %s (偏移 %zu)", errbuf, erroroffset);
    }

    pcre2_match_data* match_data = pcre2_match_data_create_from_pattern(re, NULL);
    if (!match_data) { pcre2_code_free(re); kr_error("无法创建匹配数据"); }

    std::string input(obj.str_val, obj.str_len);
    std::vector<Value> results;
    PCRE2_SIZE offset = 0;
    PCRE2_SIZE input_len = input.size();

    while (true) {
        int rc = pcre2_match(re, (PCRE2_SPTR)input.c_str(), input_len,
                             offset, 0, match_data, NULL);
        if (rc <= 0) break;

        PCRE2_SIZE* ovector = pcre2_get_ovector_pointer(match_data);
        PCRE2_SIZE match_start = ovector[0];
        PCRE2_SIZE match_end   = ovector[1];

        std::string expanded;
        for (size_t i = 0; i < tmpl.size(); ++i) {
            char c = tmpl[i];
            if (c == '&') {
                if (i + 1 < tmpl.size() && isdigit(tmpl[i+1])) {
                    int group = tmpl[i+1] - '0';
                    i++;
                    if (group < rc) {
                        PCRE2_SIZE start = ovector[2*group];
                        PCRE2_SIZE end   = ovector[2*group + 1];
                        if (start != PCRE2_UNSET) expanded.append(input, start, end - start);
                    }
                } else if (i + 1 < tmpl.size() && tmpl[i+1] == '&') {
                    expanded.push_back('&');
                    i++;
                } else {
                    PCRE2_SIZE start = ovector[0];
                    PCRE2_SIZE end   = ovector[1];
                    if (start != PCRE2_UNSET) expanded.append(input, start, end - start);
                }
            } else {
                expanded.push_back(c);
            }
        }

        results.push_back(make_string(expanded.c_str()));

        if (match_end == match_start) {
            offset = match_end + 1;
            if (offset > input_len) break;
        } else {
            offset = match_end;
        }
        if (offset >= input_len) break;
    }

    pcre2_match_data_free(match_data);
    pcre2_code_free(re);

    Value* elems = (Value*)malloc(results.size() * sizeof(Value));
    for (size_t i = 0; i < results.size(); ++i) elems[i] = results[i];
    Value result_arr = make_array(elems, (int)results.size());
    free(elems);
    return result_arr;
}

Value c_method_enthaelt(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("Fehler: enthält 只能用于字符串\n");
    if (argc != 1) kr_error("Fehler: enthält 需要 1 个参数\n");
    if (args[0].type != VAL_STRING) kr_error("Fehler: enthält 参数必须是字符串\n");
    std::string hay(obj.str_val, obj.str_len);
    std::string needle(args[0].str_val, args[0].str_len);
    int res = (hay.find(needle) != std::string::npos) ? 1 : 0;
    return make_int(res);
}

Value c_method_faengtAnMit(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("Fehler: fängtAnMit 只能用于字符串\n");
    if (argc != 1) kr_error("Fehler: fängtAnMit 需要 1 个参数\n");
    if (args[0].type != VAL_STRING) kr_error("Fehler: fängtAnMit 参数必须是字符串\n");
    int res = 0;
    if (obj.str_len >= args[0].str_len) {
        res = (memcmp(obj.str_val, args[0].str_val, args[0].str_len) == 0);
    }
    return make_int(res);
}

Value c_method_abschnitt(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("abschnitt/ab 只能用于字符串");
    if (argc < 1 || argc > 2) kr_error("abschnitt/ab 需要 1 或 2 个参数（起始, [结束]）");

    long long start = value_to_ll(args[0]);

    std::string s(obj.str_val, obj.str_len);
    long long char_len = (long long)utf8_length(s);

    long long end;
    if (argc == 2) end = value_to_ll(args[1]);
    else           end = char_len;

    if (start < 0) start = char_len + start;
    if (end < 0)   end   = char_len + end + 1;

    if (start < 0) start = 0;
    if (end > char_len) end = char_len;
    if (start > end) start = end;

    size_t byte_start = 0, byte_end = 0;
    long long pos = 0;
    for (size_t i = 0; i < s.size(); ) {
        size_t len;
        utf8_char_width(&s[i], &len);
        if (pos == start) byte_start = i;
        if (pos == end)   { byte_end = i; break; }
        i += len;
        pos++;
    }
    if (end >= char_len) byte_end = s.size();

    std::string result = s.substr(byte_start, byte_end - byte_start);
    return make_string(result.c_str());
}

Value c_method_stelleVon(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("Fehler: stelleVon 只能用于字符串\n");
    if (argc != 1) kr_error("Fehler: stelleVon 需要 1 个参数\n");
    if (args[0].type != VAL_STRING) kr_error("Fehler: stelleVon 参数必须是字符串\n");
    std::string hay(obj.str_val, obj.str_len);
    std::string needle(args[0].str_val, args[0].str_len);
    size_t p = hay.find(needle);
    int pos = (p == std::string::npos) ? -1 : (int)p;
    return make_int(pos);
}

Value c_method_letzteStelleVon(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("Fehler: letzteStelleVon 只能用于字符串\n");
    if (argc != 1) kr_error("Fehler: letzteStelleVon 需要 1 个参数\n");
    if (args[0].type != VAL_STRING) kr_error("Fehler: letzteStelleVon 参数必须是字符串\n");
    std::string hay(obj.str_val, obj.str_len);
    std::string needle(args[0].str_val, args[0].str_len);
    size_t p = hay.rfind(needle);
    int pos = (p == std::string::npos) ? -1 : (int)p;
    return make_int(pos);
}

Value c_method_trim(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("Fehler: trim 只能用于字符串\n");
    if (argc != 0) kr_error("Fehler: trim 不需要参数\n");
    std::string s(obj.str_val, obj.str_len);
    size_t start = 0, end = s.size();
    while (start < end && isspace((unsigned char)s[start])) start++;
    while (end > start && isspace((unsigned char)s[end-1])) end--;
    return make_string_len(s.data() + start, end - start);
}

Value c_method_alsZahl(Value& obj, Value* fmt_args, int fmt_count) {
    if (obj.type == VAL_INT || obj.type == VAL_INT64 || obj.type == VAL_FLOAT) {
        return copy_value(obj);
    }
    if (obj.type != VAL_STRING) kr_error("alsZahl 仅支持字符串、整数或浮点数");

    int base = 0;
    bool want_int = false;
    bool want_float = false;
    RoundingMode mode = ROUND_HALF_UP;

    for (int i = 0; i < fmt_count; i++) {
        const Value& v = fmt_args[i];
        if (v.type == VAL_INT || v.type == VAL_INT64) {
            long long b = value_to_ll(v);
            if (b < 2 || b > 36) kr_error("进制必须在 2 到 36 之间");
            base = (int)b;
        } else if (v.type == VAL_STRING) {
            std::string s(v.str_val, v.str_len);
            if (s == "z") want_int = true;
            else if (s == "k") want_float = true;
            else if (s == "^" || s == "auf") mode = ROUND_CEIL;
            else if (s == "_" || s == "ab")  mode = ROUND_FLOOR;
        }
    }

    std::string num_str(obj.str_val, obj.str_len);
    size_t start = num_str.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) kr_error("空字符串无法转换为数字");
    size_t end = num_str.find_last_not_of(" \t\n\r");
    num_str = num_str.substr(start, end - start + 1);

    if (base != 0 && num_str.size() >= 2 && num_str[0] == '0') {
        char second = num_str[1];
        if ((second == 'x' || second == 'X') && base == 16) num_str = num_str.substr(2);
        else if ((second == 'b' || second == 'B') && base == 2)  num_str = num_str.substr(2);
        else if ((second == 'o' || second == 'O') && base == 8)  num_str = num_str.substr(2);
    }

    if (base == 0) {
        if (num_str.size() > 2 && num_str[0] == '0') {
            char second = num_str[1];
            if (second == 'x' || second == 'X') base = 16;
            else if (second == 'b' || second == 'B') base = 2;
            else if (second == 'o' || second == 'O') base = 8;
            else base = 10;
        } else base = 10;
    }

    if (!want_int && !want_float) {
        bool has_dot = (num_str.find('.') != std::string::npos);
        bool has_exp = (num_str.find('e') != std::string::npos ||
                        num_str.find('E') != std::string::npos ||
                        num_str.find('p') != std::string::npos ||
                        num_str.find('P') != std::string::npos);
        if (has_dot || has_exp) want_float = true;
        else                    want_int = true;
    }

    Value result;
    if (want_int) {
        mpz_t z; mpz_init(z);
        if (mpz_set_str(z, num_str.c_str(), base) == 0) {
            result = make_int(z);
        } else {
            mpf_t f; mpf_init(f);
            if (mpf_set_str(f, num_str.c_str(), base) == 0) {
                mpf_t rounded; mpf_init(rounded);
                switch (mode) {
                    case ROUND_CEIL:  mpf_ceil(rounded, f);  break;
                    case ROUND_FLOOR: mpf_floor(rounded, f); break;
                    default:          mpf_round(rounded, f); break;
                }
                mpz_set_f(z, rounded);
                result = make_int(z);
                mpf_clear(rounded);
                mpf_clear(f);
            } else {
                mpf_clear(f); mpz_clear(z);
                kr_error("alsZahl: 无法将 '%s' 解析为整数（进制 %d）", num_str.c_str(), base);
            }
        }
        mpz_clear(z);
    } else {
        mpf_t f; mpf_init(f);
        if (mpf_set_str(f, num_str.c_str(), base) == 0) {
            result = make_float(f);
        } else {
            mpf_clear(f);
            kr_error("alsZahl: 无法将 '%s' 解析为浮点数（进制 %d）", num_str.c_str(), base);
        }
        mpf_clear(f);
    }
    return result;
}

Value c_method_alsText(Value& obj, Value* args, int argc) {
    int base = 10;
    std::string fmt_str;
    RoundingMode mode = ROUND_HALF_UP;
    bool has_fmt = false;

    for (int i = 0; i < argc; i++) {
        const Value& v = args[i];
        if (v.type == VAL_INT || v.type == VAL_INT64) {
            long long val = (v.type == VAL_INT64) ? v.int64_val
                                                  : mpz_get_si(*v.big_int);
            if (!has_fmt && base == 10) {
                base = (int)val;
                if (base < 2 || base > 40) kr_error("进制必须在 2 到 40 之间");
            }
        } else if (v.type == VAL_STRING) {
            std::string s(v.str_val, v.str_len);
            if (s == "^" || s == "auf") mode = ROUND_CEIL;
            else if (s == "_" || s == "ab") mode = ROUND_FLOOR;
            else { fmt_str = s; has_fmt = true; }
        } else {
            kr_error("alsText 参数必须是整数或字符串");
        }
    }

    if (!has_fmt) {
        if (base != 10) return format_value_new(obj, std::to_string(base));
        if (obj.type == VAL_STRING) return make_string_len(obj.str_val, obj.str_len);
        char* s = value_to_string(obj);
        Value res = make_string(s);
        free(s);
        return res;
    }

    if (mode != ROUND_HALF_UP) {
        char mode_char = (mode == ROUND_CEIL) ? '^' : '_';
        if (!fmt_str.empty()) {
            char last = fmt_str.back();
            if (last == '^' || last == '_') fmt_str.back() = mode_char;
            else fmt_str += mode_char;
        } else {
            fmt_str = "t";
            fmt_str += mode_char;
        }
    }

    return format_value_new(obj, fmt_str);
}

Value c_method_alsArray(Value& obj, Value* args, int argc) {
    std::string mode = "";

    // 1. 参数解析 (模仿 alsText)
    for (int i = 0; i < argc; i++) {
        const Value& v = args[i];
        if (v.type == VAL_STRING) {
            std::string s(v.str_val, v.str_len);
            if (s == "k" || s == "w") {
                mode = s;
            } else {
                kr_error("als_Array 未知参数: %s", s);
            }
        } else {
            kr_error("als_Array 参数必须是字符串 ('k' 或 'w')");
        }
    }

    // 2. 字符串处理逻辑：按 UTF-8 拆分为字符数组
    if (obj.type == VAL_STRING) {
        const char* str = obj.str_val;
        size_t len = obj.str_len;
        
        // 预分配内存，最坏情况全是 ASCII 字符
        Value* elems = (Value*)malloc(len * sizeof(Value));
        long long count = 0;
        size_t pos = 0;

        while (pos < len) {
            size_t char_len;
            // 复用你提供的 utf8_char_width 获取当前字符的字节长度
            utf8_char_width(&str[pos], &char_len);
            
            // make_string_len 返回 Value，直接存入 elems
            elems[count] = make_string_len(&str[pos], char_len);
            count++;
            pos += char_len;
        }

        Value res;
        res.type = VAL_ARRAY;
        res.arr_val = { .elements = elems, .length = count };
        return res;
    }

    // 3. 对象处理逻辑：根据模式提取键值
    if (obj.type == VAL_OBJECT) {
        int count = obj.obj_val.count;
        ObjectEntry* entries = obj.obj_val.entries;
        
        // 预分配内存
        Value* elems = (Value*)malloc(count * sizeof(Value));
        long long elem_count = 0;

        for (int i = 0; i < count; i++) {
            if (mode == "k") {
                // 只要键：将 char* key 转为字符串 Value
                elems[elem_count] = make_string(entries[i].key);
                elem_count++;
            } else if (mode == "w") {
                // 只要值：直接拷贝 Value
                elems[elem_count] = entries[i].value;
                elem_count++;
            } else {
                // 默认：生成 [键, 值] 对
                // 创建一个包含 2 个元素的子数组
                Value* pair_elems = (Value*)malloc(2 * sizeof(Value));
                pair_elems[0] = make_string(entries[i].key); // 键
                pair_elems[1] = entries[i].value;            // 值

                Value pair_array;
                pair_array.type = VAL_ARRAY;
                pair_array.arr_val = { .elements = pair_elems, .length = 2 };

                elems[elem_count] = pair_array;
                elem_count++;
            }
        }

        Value res;
        res.type = VAL_ARRAY;
        res.arr_val = { .elements = elems, .length = elem_count };
        return res;
    }

    kr_error("alsArray 仅支持字符串或对象类型");
    return make_null();
}

Value c_method_toUpper(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("groß 只能用于字符串");
    if (argc != 0) kr_error("groß 不需要参数");
    std::string src(obj.str_val, obj.str_len);
    std::wstring wide = utf8_to_wstring(src);
    CharUpperW(&wide[0]);
    std::string result = wstring_to_utf8(wide);
    return make_string(result.c_str());
}

Value c_method_toLower(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("klein 只能用于字符串");
    if (argc != 0) kr_error("klein 不需要参数");
    std::string src(obj.str_val, obj.str_len);
    std::wstring wide = utf8_to_wstring(src);
    CharLowerW(&wide[0]);
    std::string result = wstring_to_utf8(wide);
    return make_string(result.c_str());
}

Value c_method_reverse(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("umk: 类型错误(当前用于字符串)");
    if (argc != 0) kr_error("umkehren 不需要参数");
    std::string s(obj.str_val, obj.str_len);
    std::vector<std::string> chars;
    size_t i = 0;
    while (i < s.size()) {
        size_t len = 1;
        if ((s[i] & 0xE0) == 0xC0) len = 2;
        else if ((s[i] & 0xF0) == 0xE0) len = 3;
        else if ((s[i] & 0xF8) == 0xF0) len = 4;
        chars.push_back(s.substr(i, len));
        i += len;
    }
    std::reverse(chars.begin(), chars.end());
    std::string result;
    for (const auto& c : chars) result += c;
    return make_string(result.c_str());
}

Value c_method_count(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("zähle 只能用于字符串");
    if (argc != 1) kr_error("zähle 需要 1 个参数（子串）");
    if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
    std::string text(obj.str_val, obj.str_len);
    std::string pat(args[0].str_val, args[0].str_len);
    int count = 0;
    size_t pos = 0;
    while ((pos = text.find(pat, pos)) != std::string::npos) {
        ++count;
        pos += pat.size();
        if (pat.empty()) break;
    }
    return make_int(count);
}

Value c_method_remove_prefix(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("ohnePräfix 只能用于字符串");
    if (argc != 1) kr_error("ohnePräfix 需要 1 个参数（前缀）");
    if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
    std::string s(obj.str_val, obj.str_len);
    std::string p(args[0].str_val, args[0].str_len);
    if (s.compare(0, p.size(), p) == 0) s.erase(0, p.size());
    return make_string_len(s.data(), s.size());
}

Value c_method_remove_suffix(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("ohneSuffix 只能用于字符串");
    if (argc != 1) kr_error("ohneSuffix 需要 1 个参数（后缀）");
    if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
    std::string s(obj.str_val, obj.str_len);
    std::string p(args[0].str_val, args[0].str_len);
    if (s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0)
        s.erase(s.size() - p.size());
    return make_string_len(s.data(), s.size());
}

Value c_method_pad(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("füllen 只能用于字符串");
    if (argc < 1 || argc > 3)
        kr_error("füllen 需要 1~3 个参数：宽度, [Richtung l/r/c], [Füllzeichen]");
    int width = (int)value_to_ll(args[0]);
    if (width < 0) kr_error("宽度不能为负数");

    char dir = 'l';
    char fill_char = ' ';
    if (argc >= 2) {
        if (args[1].type != VAL_STRING || args[1].str_val[0] == '\0')
            kr_error("Richtung muss ein String sein (l, r oder c)");
        dir = args[1].str_val[0];
        if (dir != 'l' && dir != 'r' && dir != 'c')
            kr_error("Richtung muss 'l', 'r' oder 'c' sein");
    }
    if (argc >= 3) {
        if (args[2].type != VAL_STRING || args[2].str_val[0] == '\0')
            kr_error("Füllzeichen muss ein Einzelzeichen sein");
        fill_char = args[2].str_val[0];
    }
    std::string s(obj.str_val, obj.str_len);
    int current_len = (int)utf8_length(s);
    if (width <= current_len) return make_string(s.c_str());

    int pad = width - current_len;
    std::string pad_str(pad, fill_char);
    std::string result;
    if (dir == 'l') result = pad_str + s;
    else if (dir == 'r') result = s + pad_str;
    else {
        int left = pad / 2;
        int right = pad - left;
        result = std::string(left, fill_char) + s + std::string(right, fill_char);
    }
    return make_string(result.c_str());
}

Value c_method_ends_with(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("endetMit 只能用于字符串");
    if (argc != 1) kr_error("endetMit 需要 1 个参数（后缀）");
    if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
    std::string s(obj.str_val, obj.str_len);
    std::string p(args[0].str_val, args[0].str_len);
    int ok = (s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0);
    return make_int(ok);
}

Value c_method_repeat(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("wiederholen 只能用于字符串");
    if (argc != 1) kr_error("wiederholen 需要 1 个参数（次数）");
    long long n = value_to_ll(args[0]);
    if (n < 0) kr_error("重复次数不能为负数");
    std::string s(obj.str_val, obj.str_len);
    std::string result;
    for (long long i = 0; i < n; ++i) result += s;
    return make_string(result.c_str());
}

Value c_method_char_at(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("zeichen 只能用于字符串");
    if (argc != 1) kr_error("zeichen 需要 1 个参数（索引）");
    long long idx = value_to_ll(args[0]);
    std::string src(obj.str_val, obj.str_len);
    int len = (int)utf8_length(src);
    if (idx < 0 || idx >= len) kr_error("索引越界");
    std::string ch = utf8_char_at(src, idx);
    return make_string(ch.c_str());
}

Value c_method_sort(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("sortieren 只能用于数组");
    if (argc > 1) kr_error("sortieren 可选一个比较函数");

    Value* arr_ptr = &obj;
    int len = arr_ptr->arr_val.length;
    if (len <= 1) return copy_value(*arr_ptr);

    std::vector<Value> elems(len);
    for (int i = 0; i < len; ++i)
        elems[i] = copy_value(arr_ptr->arr_val.elements[i]);

    std::vector<int> indices(len);
    std::iota(indices.begin(), indices.end(), 0);

    Value cmp_func;
    bool has_cmp = false;
    if (argc == 1) {
        cmp_func = copy_value(args[0]);
        if (cmp_func.type != VAL_FUNCTION) kr_error("比较参数必须是函数");
        has_cmp = true;
    }

    if (has_cmp) {
        std::sort(indices.begin(), indices.end(), [&](int i, int j) {
            const Value& a = elems[i];
            const Value& b = elems[j];
            Value call_args[2] = { copy_value(a), copy_value(b) };
            Value ret = call_function_value(cmp_func, call_args, 2);
            long long cmp = value_to_ll(ret);
            free_value(&call_args[0]);
            free_value(&call_args[1]);
            free_value(&ret);
            return cmp < 0;
        });
        free_value(&cmp_func);
    } else {
        std::sort(indices.begin(), indices.end(), [&](int i, int j) {
            const Value& a = elems[i];
            const Value& b = elems[j];
            if (a.type != b.type) return a.type < b.type;
            switch (a.type) {
                case VAL_INT64:  return a.int64_val < b.int64_val;
                case VAL_INT:    return mpz_cmp(*a.big_int, *b.big_int) < 0;
                case VAL_FLOAT:  return mpf_cmp(*a.mpf_val, *b.mpf_val) < 0;
                case VAL_STRING: {
                    int cmp = memcmp(a.str_val, b.str_val, std::min(a.str_len, b.str_len));
                    if (cmp != 0) return cmp < 0;
                    return a.str_len < b.str_len;
                }
                case VAL_ARRAY:  return a.arr_val.length < b.arr_val.length;
                case VAL_OBJECT: return a.obj_val.count < b.obj_val.count;
                case VAL_FUNCTION: {
                    const char* na = a.func_val.name ? a.func_val.name : "";
                    const char* nb = b.func_val.name ? b.func_val.name : "";
                    return strcmp(na, nb) < 0;
                }
                case VAL_NULL:   return false;
                case VAL_FUTURE: return a.future_state.future_id < b.future_state.future_id;
                default:         return false;
            }
        });
    }

    std::vector<Value> sorted(len);
    for (int i = 0; i < len; ++i)
        sorted[i] = copy_value(elems[indices[i]]);

    for (auto& v : elems) free_value(&v);

    for (int i = 0; i < len; ++i) {
        free_value(&arr_ptr->arr_val.elements[i]);
        arr_ptr->arr_val.elements[i] = copy_value(sorted[i]);
    }
    for (auto& v : sorted) free_value(&v);

    return copy_value(*arr_ptr);
}

Value c_method_unique(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("entfernenDuplikate 只能用于数组");
    if (argc != 0) kr_error("entfernenDuplikate 不需要参数");
    std::vector<Value> result;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        bool found = false;
        for (const auto& existing : result) {
            if (value_to_stdstring(existing) == value_to_stdstring(obj.arr_val.elements[i])) {
                found = true; break;
            }
        }
        if (!found) result.push_back(copy_value(obj.arr_val.elements[i]));
    }
    return make_array(result.data(), (int)result.size());
}

Value c_method_slice(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("ab/abschnitt/teil 只能用于数组");
    if (argc < 1 || argc > 2) kr_error("ab/abschnitt/teil 需要 1 或 2 个参数（起始, [结束]）");

    long long start = value_to_ll(args[0]);
    long long len = obj.arr_val.length;
    long long end = (argc == 2) ? value_to_ll(args[1]) : len;

    if (start < 0) start = len + start;
    if (end < 0)   end = len + end + 1;
    if (start < 0) start = 0;
    if (end > len) end = len;
    if (start > end) start = end;
    long long count = end - start;
    if (count <= 0) return make_array(nullptr, 0);

    Value* elems = (Value*)malloc(count * sizeof(Value));
    for (long long i = 0; i < count; ++i)
        elems[i] = copy_value(obj.arr_val.elements[start + i]);
    Value result = make_array(elems, (int)count);
    free(elems);
    return result;
}

Value c_method_contains_array(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("enthält (Array) 只能用于数组");
    if (argc != 1) kr_error("enthält 需要 1 个参数（元素）");
    for (int i = 0; i < obj.arr_val.length; ++i) {
        if (value_to_stdstring(obj.arr_val.elements[i]) == value_to_stdstring(args[0]))
            return make_int(1LL);
    }
    return make_int(0LL);
}

Value c_method_all_indices(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("alleIndices 只能用于数组");
    if (argc != 1) kr_error("alleIndices 需要 1 个参数（元素）");
    std::vector<long long> indices;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        if (value_to_stdstring(obj.arr_val.elements[i]) == value_to_stdstring(args[0]))
            indices.push_back(i);
    }
    Value* idx_vals = (Value*)malloc(indices.size() * sizeof(Value));
    for (size_t i = 0; i < indices.size(); ++i) idx_vals[i] = make_int(indices[i]);
    Value result = make_array(idx_vals, (int)indices.size());
    free(idx_vals);
    return result;
}

Value c_method_max(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("max 只能用于数组");
    if (argc != 0) kr_error("max 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有最大值");
    Value best = copy_value(obj.arr_val.elements[0]);
    for (int i = 1; i < obj.arr_val.length; ++i) {
        bool is_num = (best.type == VAL_INT || best.type == VAL_INT64 || best.type == VAL_FLOAT) &&
                      (obj.arr_val.elements[i].type == VAL_INT || obj.arr_val.elements[i].type == VAL_INT64 || obj.arr_val.elements[i].type == VAL_FLOAT);
        if (is_num) {
            double a = value_to_double(best);
            double b = value_to_double(obj.arr_val.elements[i]);
            if (b > a) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        } else {
            std::string sa = value_to_stdstring(best);
            std::string sb = value_to_stdstring(obj.arr_val.elements[i]);
            if (sb > sa) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        }
    }
    return best;
}

Value c_method_min(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("min 只能用于数组");
    if (argc != 0) kr_error("min 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有最小值");
    Value best = copy_value(obj.arr_val.elements[0]);
    for (int i = 1; i < obj.arr_val.length; ++i) {
        bool is_num = (best.type == VAL_INT || best.type == VAL_INT64 || best.type == VAL_FLOAT) &&
                      (obj.arr_val.elements[i].type == VAL_INT || obj.arr_val.elements[i].type == VAL_INT64 || obj.arr_val.elements[i].type == VAL_FLOAT);
        if (is_num) {
            double a = value_to_double(best);
            double b = value_to_double(obj.arr_val.elements[i]);
            if (b < a) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        } else {
            std::string sa = value_to_stdstring(best);
            std::string sb = value_to_stdstring(obj.arr_val.elements[i]);
            if (sb > sa) { free_value(&best); best = copy_value(obj.arr_val.elements[i]); }
        }
    }
    return best;
}

Value c_method_sum(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("summe 只能用于数组");
    if (argc != 0) kr_error("summe 不需要参数");
    if (obj.arr_val.length == 0) return make_int(0LL);

    bool any_float = false;
    mpf_t sum; mpf_init(sum); mpf_set_d(sum, 0.0);
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& elem = obj.arr_val.elements[i];
        if (elem.type == VAL_FLOAT) any_float = true;
        if (elem.type == VAL_INT || elem.type == VAL_INT64 || elem.type == VAL_FLOAT) {
            mpf_t tmp; mpf_init(tmp);
            if (elem.type == VAL_FLOAT) mpf_set(tmp, *elem.mpf_val);
            else mpf_set_int64(tmp, value_to_ll(elem));
            mpf_add(sum, sum, tmp);
            mpf_clear(tmp);
        } else {
            mpf_clear(sum);
            kr_error("summe 仅支持数值数组");
        }
    }
    Value result = any_float ? make_float(sum) : make_int((long long)mpf_get_si(sum));
    mpf_clear(sum);
    return result;
}

Value c_method_hinzufuegen(Value& obj, Value* args, int argc) {
    if (obj.type == VAL_ARRAY) {
        if (argc != 1) kr_error("anf/hinzufügen 对于数组需要 1 个参数");
        Value new_elem = copy_value(args[0]);
        Value* arr_ptr = &obj;
        int old_len = arr_ptr->arr_val.length;
        arr_ptr->arr_val.elements = (Value*)realloc(arr_ptr->arr_val.elements,
                                                    (old_len + 1) * sizeof(Value));
        arr_ptr->arr_val.elements[old_len] = copy_value(new_elem);
        arr_ptr->arr_val.length++;
        free_value(&new_elem);
        return copy_value(obj);
    }
    else if (obj.type == VAL_OBJECT) {
        char* key = NULL;
        Value value = make_null();

        if (argc == 1) {
            Value arg = copy_value(args[0]);
            if (arg.type != VAL_OBJECT) {
                free_value(&arg);
                kr_error("anf/hinzufügen 对于对象，单个参数必须是 { key: ..., wert: ... }");
            }
            for (int i = 0; i < arg.obj_val.count; i++) {
                if (strcmp(arg.obj_val.entries[i].key, "key") == 0) {
                    if (arg.obj_val.entries[i].value.type == VAL_STRING) {
                        key = dup_object_key(arg.obj_val.entries[i].value);
                    } else {
                        char* s = value_to_string(arg.obj_val.entries[i].value);
                        key = strdup(s);
                        free(s);
                    }
                } else if (strcmp(arg.obj_val.entries[i].key, "wert") == 0) {
                    value = copy_value(arg.obj_val.entries[i].value);
                }
            }
            if (!key) { free_value(&arg); kr_error("anf/hinzufügen 对象参数缺少 'key' 字段"); }
            free_value(&arg);
        } else if (argc == 2) {
            if (args[0].type == VAL_STRING) key = dup_object_key(args[0]);
            else { char* s = value_to_string(args[0]); key = strdup(s); free(s); }
            value = copy_value(args[1]);
        } else {
            kr_error("anf/hinzufügen 对于对象需要 1 个对象参数或 2 个参数 (key, value)");
        }

        Value* obj_ptr = &obj;
        int found = -1;
        for (int i = 0; i < obj_ptr->obj_val.count; i++) {
            if (strcmp(obj_ptr->obj_val.entries[i].key, key) == 0) { found = i; break; }
        }
        if (found >= 0) {
            free_value(&obj_ptr->obj_val.entries[found].value);
            obj_ptr->obj_val.entries[found].value = copy_value(value);
            free(key);
        } else {
            obj_ptr->obj_val.count++;
            obj_ptr->obj_val.entries = (ObjectEntry*)realloc(obj_ptr->obj_val.entries,
                                        obj_ptr->obj_val.count * sizeof(ObjectEntry));
            obj_ptr->obj_val.entries[obj_ptr->obj_val.count - 1].key = key;
            obj_ptr->obj_val.entries[obj_ptr->obj_val.count - 1].value = copy_value(value);
        }
        free_value(&value);
        return copy_value(obj);
    }
    else {
        kr_error("anf/hinzufügen 只能用于数组或对象");
        return make_null();
    }
}

Value c_method_loeschen(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_OBJECT) kr_error("lösch 只能用于对象");
    if (argc != 1) kr_error("lösch 需要 1 个参数（键名）");
    if (args[0].type != VAL_STRING) kr_error("键必须是字符串");
    const char* key_str = args[0].str_val;

    Value* obj_ptr = &obj;
    int found_idx = -1;
    for (int i = 0; i < obj_ptr->obj_val.count; i++) {
        if (strcmp(obj_ptr->obj_val.entries[i].key, key_str) == 0) { found_idx = i; break; }
    }
    if (found_idx == -1) return make_null();

    Value removed = copy_value(obj_ptr->obj_val.entries[found_idx].value);
    free(obj_ptr->obj_val.entries[found_idx].key);
    free_value(&obj_ptr->obj_val.entries[found_idx].value);

    for (int i = found_idx; i < obj_ptr->obj_val.count - 1; i++)
        obj_ptr->obj_val.entries[i] = obj_ptr->obj_val.entries[i + 1];
    obj_ptr->obj_val.count--;

    if (obj_ptr->obj_val.count > 0) {
        obj_ptr->obj_val.entries = (ObjectEntry*)realloc(
            obj_ptr->obj_val.entries, obj_ptr->obj_val.count * sizeof(ObjectEntry));
    } else {
        free(obj_ptr->obj_val.entries);
        obj_ptr->obj_val.entries = NULL;
    }
    return removed;
}

Value c_method_finde(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("Fehler: finde 只能用于数组\n");
    if (argc != 1) kr_error("Fehler: finde 需要 1 个参数（要查找的值）\n");
    for (int i = 0; i < obj.arr_val.length; i++) {
        Value& cur = obj.arr_val.elements[i];
        if ((cur.type == VAL_INT || cur.type == VAL_INT64) &&
            (args[0].type == VAL_INT || args[0].type == VAL_INT64) &&
            value_to_ll(cur) == value_to_ll(args[0]))
            return copy_value(cur);
        if (cur.type == VAL_STRING && args[0].type == VAL_STRING &&
            cur.str_len == args[0].str_len &&
            memcmp(cur.str_val, args[0].str_val, cur.str_len) == 0)
            return copy_value(cur);
    }
    return make_null();
}

Value c_method_findeIndex(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("Fehler: findeIndex 只能用于数组\n");
    if (argc != 1) kr_error("Fehler: findeIndex 需要 1 个参数（要查找的值）\n");
    for (int i = 0; i < obj.arr_val.length; i++) {
        Value& cur = obj.arr_val.elements[i];
        if ((cur.type == VAL_INT || cur.type == VAL_INT64) &&
            (args[0].type == VAL_INT || args[0].type == VAL_INT64) &&
            value_to_ll(cur) == value_to_ll(args[0]))
            return make_int(i);
        if (cur.type == VAL_STRING && args[0].type == VAL_STRING &&
            cur.str_len == args[0].str_len &&
            memcmp(cur.str_val, args[0].str_val, cur.str_len) == 0)
            return make_int(i);
    }
    return make_int(-1);
}

Value c_method_array_last(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("letzt 只能用于数组");
    if (argc == 0) {
        if (obj.arr_val.length == 0) kr_error("空数组没有最后一个元素");
        return copy_value(obj.arr_val.elements[obj.arr_val.length - 1]);
    }
    else if (argc == 1) {
        int last_idx = -1;
        for (int i = 0; i < obj.arr_val.length; i++) {
            Value& cur = obj.arr_val.elements[i];
            if ((cur.type == VAL_INT || cur.type == VAL_INT64) &&
                (args[0].type == VAL_INT || args[0].type == VAL_INT64) &&
                value_to_ll(cur) == value_to_ll(args[0]))
                last_idx = i;
            else if (cur.type == VAL_STRING && args[0].type == VAL_STRING &&
                cur.str_len == args[0].str_len &&
                memcmp(cur.str_val, args[0].str_val, cur.str_len) == 0)
                last_idx = i;
        }
        return make_int(last_idx);
    }
    else {
        kr_error("letzt 需要 0 或 1 个参数");
        return make_null();
    }
}

Value c_method_istZiffer(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("istZiffer 只能用于字符串");
    if (argc != 0) kr_error("istZiffer 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i)
        if (!isdigit((unsigned char)obj.str_val[i])) return make_int64(0LL);
    return make_int64(1LL);
}

Value c_method_istBuchstabe(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("istBuchstabe 只能用于字符串");
    if (argc != 0) kr_error("istBuchstabe 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i)
        if (!isalpha((unsigned char)obj.str_val[i])) return make_int64(0LL);
    return make_int64(1LL);
}

Value c_method_istAlnum(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("istAlnum 只能用于字符串");
    if (argc != 0) kr_error("istAlnum 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i)
        if (!isalnum((unsigned char)obj.str_val[i])) return make_int64(0LL);
    return make_int64(1LL);
}

Value c_method_istRaum(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("istRaum 只能用于字符串");
    if (argc != 0) kr_error("istRaum 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    for (size_t i = 0; i < obj.str_len; ++i)
        if (!isspace((unsigned char)obj.str_val[i])) return make_int64(0LL);
    return make_int64(1LL);
}

Value c_method_istGroß(Value obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("istGroß 只能用于字符串");
    if (argc != 0) kr_error("istGroß 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    bool has_alpha = false;
    for (size_t i = 0; i < obj.str_len; ++i) {
        unsigned char c = (unsigned char)obj.str_val[i];
        if (isalpha(c)) {
            has_alpha = true;
            if (!isupper(c)) return make_int64(0LL);
        }
    }
    return make_int64(has_alpha ? 1LL : 0LL);
}

Value c_method_istKlein(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("istKlein 只能用于字符串");
    if (argc != 0) kr_error("istKlein 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    bool has_alpha = false;
    for (size_t i = 0; i < obj.str_len; ++i) {
        unsigned char c = (unsigned char)obj.str_val[i];
        if (isalpha(c)) {
            has_alpha = true;
            if (!islower(c)) return make_int64(0LL);
        }
    }
    return make_int64(has_alpha ? 1LL : 0LL);
}

Value c_method_istZahl(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("istZahl 只能用于字符串");
    if (argc != 0) kr_error("istZahl 不需要参数");
    if (obj.str_len == 0) return make_int64(0LL);
    size_t i = 0;
    if (obj.str_val[0] == '-' || obj.str_val[0] == '+') i = 1;
    if (i >= obj.str_len) return make_int64(0LL);
    for (; i < obj.str_len; ++i)
        if (!isdigit((unsigned char)obj.str_val[i])) return make_int64(0LL);
    return make_int64(1LL);
}

Value c_method_entferne(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("entferne 只能用于字符串");
    if (argc != 1) kr_error("entferne 需要 1 个参数（子串）");
    if (args[0].type != VAL_STRING) kr_error("参数必须是字符串");
    std::string s(obj.str_val, obj.str_len);
    std::string p(args[0].str_val, args[0].str_len);
    if (p.empty()) return make_string_len(s.data(), s.size());
    std::string result;
    size_t pos = 0, prev = 0;
    while ((pos = s.find(p, prev)) != std::string::npos) {
        result.append(s, prev, pos - prev);
        prev = pos + p.size();
    }
    result.append(s, prev, std::string::npos);
    return make_string_len(result.data(), result.size());
}

Value c_method_anfang(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("anfang 只能用于字符串");
    if (argc != 1) kr_error("anfang 需要 1 个参数（长度）");
    long long n = value_to_ll(args[0]);
    if (n < 0) n = 0;
    std::string s(obj.str_val, obj.str_len);
    size_t char_len = utf8_length(s);
    if ((size_t)n > char_len) n = char_len;
    size_t pos = 0;
    for (long long i = 0; i < n; ++i) {
        size_t len;
        utf8_char_width(&s[pos], &len);
        pos += len;
    }
    return make_string_len(s.data(), pos);
}

Value c_method_rechts(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_STRING) kr_error("rechts 只能用于字符串");
    if (argc != 1) kr_error("rechts 需要 1 个参数（长度）");
    long long n = value_to_ll(args[0]);
    if (n < 0) n = 0;
    std::string s(obj.str_val, obj.str_len);
    size_t char_len = utf8_length(s);
    if ((size_t)n > char_len) n = char_len;
    size_t pos = s.size();
    for (long long i = 0; i < n; ++i) {
        do { --pos; } while (pos > 0 && (s[pos] & 0xC0) == 0x80);
    }
    return make_string_len(s.data() + pos, s.size() - pos);
}

Value c_method_mittel(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("mittel 只能用于数组");
    if (argc != 0) kr_error("mittel 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有平均值");
    mpf_t sum; mpf_init_set_d(sum, 0.0);
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& e = obj.arr_val.elements[i];
        if (e.type == VAL_FLOAT) mpf_add(sum, sum, *e.mpf_val);
        else if (e.type == VAL_INT64) { mpf_t t; mpf_init_set_si(t, e.int64_val); mpf_add(sum, sum, t); mpf_clear(t); }
        else if (e.type == VAL_INT)   { mpf_t t; mpf_init(t); mpf_set_z(t, *e.big_int); mpf_add(sum, sum, t); mpf_clear(t); }
        else { mpf_clear(sum); kr_error("mittel 仅支持数值数组"); }
    }
    mpf_t count; mpf_init_set_ui(count, obj.arr_val.length);
    mpf_div(sum, sum, count);
    Value res = make_float(sum);
    mpf_clear(sum); mpf_clear(count);
    return res;
}

Value c_method_produkt(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("produkt 只能用于数组");
    if (argc != 0) kr_error("produkt 不需要参数");
    if (obj.arr_val.length == 0) return make_int(1LL);
    mpf_t prod; mpf_init_set_ui(prod, 1);
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& e = obj.arr_val.elements[i];
        if (e.type == VAL_FLOAT) mpf_mul(prod, prod, *e.mpf_val);
        else if (e.type == VAL_INT64) { mpf_t t; mpf_init_set_si(t, e.int64_val); mpf_mul(prod, prod, t); mpf_clear(t); }
        else if (e.type == VAL_INT)   { mpf_t t; mpf_init(t); mpf_set_z(t, *e.big_int); mpf_mul(prod, prod, t); mpf_clear(t); }
        else { mpf_clear(prod); kr_error("produkt 仅支持数值数组"); }
    }
    Value res = make_float(prod);
    mpf_clear(prod);
    return res;
}

Value c_method_erstes(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("erstes 只能用于数组");
    if (argc != 0) kr_error("erstes 不需要参数");
    if (obj.arr_val.length == 0) kr_error("空数组没有第一个元素");
    return copy_value(obj.arr_val.elements[0]);
}

Value c_method_einfuegen(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("einfuegen 只能用于数组");
    if (argc != 2) kr_error("einfuegen 需要 2 个参数（索引, 元素）");
    long long idx = value_to_ll(args[0]);
    Value elem = copy_value(args[1]);

    Value* arr_ptr = &obj;
    if (idx < 0 || idx > arr_ptr->arr_val.length) {
        free_value(&elem);
        kr_error("索引越界（0 到 %lld）", arr_ptr->arr_val.length);
    }
    arr_ptr->arr_val.elements = (Value*)realloc(arr_ptr->arr_val.elements,
        (arr_ptr->arr_val.length + 1) * sizeof(Value));
    for (long long i = arr_ptr->arr_val.length; i > idx; --i)
        arr_ptr->arr_val.elements[i] = arr_ptr->arr_val.elements[i-1];
    arr_ptr->arr_val.elements[idx] = copy_value(elem);
    arr_ptr->arr_val.length++;
    free_value(&elem);
    return copy_value(obj);
}

Value c_method_vereinige_array(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("vereinige 只能用于数组");
    if (argc != 1) kr_error("vereinige 需要 1 个参数（另一个数组）");
    if (args[0].type != VAL_ARRAY) kr_error("参数必须是数组");
    int total = obj.arr_val.length + args[0].arr_val.length;
    Value* elems = (Value*)malloc(total * sizeof(Value));
    for (int i = 0; i < obj.arr_val.length; ++i)
        elems[i] = copy_value(obj.arr_val.elements[i]);
    for (int i = 0; i < args[0].arr_val.length; ++i)
        elems[obj.arr_val.length + i] = copy_value(args[0].arr_val.elements[i]);
    Value res = make_array(elems, total);
    free(elems);
    return res;
}

Value c_method_schnitt(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("schnitt 只能用于数组");
    if (argc != 1) kr_error("schnitt 需要 1 个参数（另一个数组）");
    if (args[0].type != VAL_ARRAY) kr_error("参数必须是数组");
    std::vector<Value> result;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& a = obj.arr_val.elements[i];
        for (int j = 0; j < args[0].arr_val.length; ++j) {
            if (value_to_stdstring(a) == value_to_stdstring(args[0].arr_val.elements[j])) {
                result.push_back(copy_value(a));
                break;
            }
        }
    }
    Value res = make_array(result.data(), (int)result.size());
    for (auto& v : result) free_value(&v);
    return res;
}

Value c_method_differenz(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("differenz 只能用于数组");
    if (argc != 1) kr_error("differenz 需要 1 个参数（另一个数组）");
    if (args[0].type != VAL_ARRAY) kr_error("参数必须是数组");
    std::vector<Value> result;
    for (int i = 0; i < obj.arr_val.length; ++i) {
        Value& a = obj.arr_val.elements[i];
        bool found = false;
        for (int j = 0; j < args[0].arr_val.length; ++j) {
            if (value_to_stdstring(a) == value_to_stdstring(args[0].arr_val.elements[j])) {
                found = true; break;
            }
        }
        if (!found) result.push_back(copy_value(a));
    }
    Value res = make_array(result.data(), (int)result.size());
    for (auto& v : result) free_value(&v);
    return res;
}

Value c_method_entferne_array(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("entferne 只能用于数组");
    if (argc != 1) kr_error("entferne 需要 1 个参数（要删除的值）");
    Value* arr_ptr = &obj;
    std::string target_str = value_to_stdstring(args[0]);
    int write = 0;
    for (int i = 0; i < arr_ptr->arr_val.length; ++i) {
        if (value_to_stdstring(arr_ptr->arr_val.elements[i]) != target_str) {
            if (write != i) arr_ptr->arr_val.elements[write] = arr_ptr->arr_val.elements[i];
            write++;
        } else {
            free_value(&arr_ptr->arr_val.elements[i]);
        }
    }
    arr_ptr->arr_val.length = write;
    if (write > 0) {
        arr_ptr->arr_val.elements = (Value*)realloc(arr_ptr->arr_val.elements, write * sizeof(Value));
    } else {
        free(arr_ptr->arr_val.elements);
        arr_ptr->arr_val.elements = NULL;
    }
    return copy_value(obj);
}

Value c_method_mische(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_ARRAY) kr_error("mische 只能用于数组");
    if (argc != 0) kr_error("mische 不需要参数");
    Value* arr_ptr = &obj;
    int n = arr_ptr->arr_val.length;
    for (int i = n - 1; i > 0; --i) {
        int j = rand() % (i + 1);
        Value tmp = arr_ptr->arr_val.elements[i];
        arr_ptr->arr_val.elements[i] = arr_ptr->arr_val.elements[j];
        arr_ptr->arr_val.elements[j] = tmp;
    }
    return copy_value(obj);
}

Value c_method_vereinige_obj(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_OBJECT) kr_error("vereinige 只能用于对象");
    if (argc != 1) kr_error("vereinige 需要 1 个参数（另一个对象）");
    if (args[0].type != VAL_OBJECT) kr_error("参数必须是对象");
    std::unordered_map<std::string, Value> map;
    for (int i = 0; i < obj.obj_val.count; ++i)
        map[obj.obj_val.entries[i].key] = copy_value(obj.obj_val.entries[i].value);
    for (int i = 0; i < args[0].obj_val.count; ++i) {
        auto it = map.find(args[0].obj_val.entries[i].key);
        if (it != map.end()) free_value(&it->second);
        map[args[0].obj_val.entries[i].key] = copy_value(args[0].obj_val.entries[i].value);
    }
    ObjectEntry* entries = (ObjectEntry*)malloc(map.size() * sizeof(ObjectEntry));
    int idx = 0;
    for (auto& kv : map) {
        entries[idx].key = strdup(kv.first.c_str());
        entries[idx].value = kv.second;
        idx++;
    }
    Value res = make_object(entries, idx);
    for (int i = 0; i < idx; ++i) {
        free(entries[i].key);
        free_value(&entries[i].value);
    }
    free(entries);
    return res;
}

Value c_method_kopiere(Value& obj, Value* args, int argc) {
    if (obj.type != VAL_OBJECT) kr_error("kopiere 只能用于对象");
    if (argc != 0) kr_error("kopiere 不需要参数");
    return copy_value(obj);
}

Value c_method_lan(Value& obj, Value* args, int argc) {
    // 不接受额外参数
    if (argc != 0) {
        kr_error("län 不需要额外参数");
    }

    Value res = make_null();
    if (obj.type == VAL_ARRAY) {
        res = make_int64(obj.arr_val.length);
    } else if (obj.type == VAL_STRING) {
        long long n = (long long)utf8_length(std::string(obj.str_val, obj.str_len));
        res = make_int64(n);
    } else if (obj.type == VAL_OBJECT) {
        bool found = false;
        for (int i = 0; i < obj.obj_val.count; ++i) {
            if (strcmp(obj.obj_val.entries[i].key, "län") == 0) {
                res = copy_value(obj.obj_val.entries[i].value);
                found = true;
                break;
            }
        }
        if (!found) {
            res = make_int64(obj.obj_val.count);
        }
    } else {
        // 其他类型返回 null 或者报错，看你需求，这里返回null
        kr_error("län 不支持该类型");
        res = make_null();
    }
    return res;
}