#define MAJOR 0
#define MINOR 0
#define PATCH 1924
#define BUILD 1

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
#include <cassert>
#include <string>
#include <vector>
#include <stdarg.h>
#include <regex>
#include <time.h>
#include <atomic>
#include <unordered_map>
#include <sstream>
#include <thread>
#include <chrono>
#include <future>
#include <mutex>
#include <memory>
#include <algorithm>
#include <unordered_map>
#include <functional>
#include <memory>
#include <stdexcept>
#include <cstdarg>
#include <cstdint>
#include <fstream>
#include <list>
#include <shared_mutex>
#include <curl/curl.h>     // -I E:\msys\mingw64\include -L E:\msys\mingw64\lib -lcurl
#include <microhttpd.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <gmp.h>
#include <iostream>
#include <codecvt>
#include <string>
#include <set>
#include <filesystem>
#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>
#include <iomanip>
#include <chrono>
#include <unordered_set>
#include <numeric>
#include <array>
#include <charconv>
#include <queue>
#ifdef _WIN32
    #ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
    #endif
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <iphlpapi.h>   // GetAdaptersAddresses (需要链接 -liphlpapi)
    #include <windows.h>
    #include <conio.h>      // _getch()
    #ifdef IN
    #undef IN
    #endif
    #ifdef OUT
    #undef OUT
    #endif
#else
    #include <ifaddrs.h>    // getifaddrs
    #include <netinet/in.h> // sockaddr_in / sockaddr_in6
    #include <arpa/inet.h>  // inet_ntop
    #include <termios.h>    // tcgetattr, tcsetattr
    #include <sys/mman.h>
#endif
    #include <unistd.h>         // 在所有平台包含（MinGW 提供）

#ifndef VAL_INT64_DEFINED
#define VAL_INT64_DEFINED
#endif

#ifndef VERWIRRT_H
#define VERWIRRT_H

std::string execute_vw(const std::string& code, const std::string& context_json,
    int start_line, int start_col, const char* filename,
    std::function<std::string(const std::string&, const std::string&)> external_call);

#endif

std::string export_global_values();
void import_global_values(const std::string& json);

extern thread_local int g_last_error_line;
extern thread_local int g_last_error_col;
extern thread_local const char* current_filename; // current_filename 并不可靠，大多时候应该使用 node 节点获取的文件名
extern thread_local std::string g_custom_source_context;

thread_local std::string g_current_operating_position = "<UNBEKAN>";
thread_local std::chrono::steady_clock::time_point g_tick_time;
thread_local bool g_tick_set = false;
thread_local const char* g_last_error_filename = nullptr;
struct CallFrame {
    int line;
    int col;
    const char* filename;
};
thread_local std::vector<CallFrame> g_call_stack;
thread_local std::vector<std::string> g_umf_stack;

// 剥离 umf 前缀（给 suggest_correction 遍历用）
static std::string strip_umf_prefix(const std::string& k) {
    size_t p = k.rfind("::");
    return (p == std::string::npos) ? k : k.substr(p + 2);
}

// 生成当前 umf 下的限定名，例如 g_umf_stack = {"A"} 时 type_key("C") = "A::C"
static std::string type_key(const std::string& bare) {
    if (g_umf_stack.empty()) return bare;
    std::string k;
    for (auto& u : g_umf_stack) { k += u; k += "::"; }
    return k + bare;
}

// 所有类型表查找统一走这个：先试限定名，失败回退裸名
template <typename Map>
static auto find_type(Map& m, const std::string& bare) {
    if (!g_umf_stack.empty()) {
        std::string k;
        for (auto& u : g_umf_stack) { k += u; k += "::"; }
        k += bare;
        auto it = m.find(k);
        if (it != m.end()) return it;
    }
    return m.find(bare);
}

static const char* find_filename_by_line_col(int line, int col);
struct CallStackGuard {
    std::vector<CallFrame>& stack;
    bool pushed;
    CallStackGuard(std::vector<CallFrame>& s, int line, int col, const char* file)
        : stack(s), pushed(false) {
        const char* fname = file ? file : (current_filename ? current_filename : "-");
        char* fname_copy = strdup(fname);      // 复制到堆
        stack.push_back({line, col, fname_copy});
        pushed = true;
    }
    ~CallStackGuard() {
        if (pushed) {
            CallFrame& frame = stack.back();
            free(const_cast<char*>(frame.filename)); // 释放内存
            stack.pop_back();
            pushed = false;
        }
    }
};

namespace fs = std::filesystem;
 
/* ========== 词法分析 ========== */
typedef enum {
    TOK_IDENT, TOK_NUMBER, TOK_STRING, TOK_KEYWORD,
    TOK_OP, TOK_SYMBOL, TOK_EOF,
    TOK_REGEX
} TokensType;

typedef struct Token {
    TokensType type;
    char* value;
    int line;   // 行号（从1开始）
    int col;    // 列号（从1开始）
    char* flags;
    char* filename;
} Token;

// 前向声明用于 kr_error 的 thread_local 变量
extern thread_local Token* tokens;
extern thread_local int token_count;
extern thread_local int tok_pos;
extern thread_local int g_last_token_line;
extern thread_local int g_last_token_col;
extern thread_local int g_stmt_start_line;
extern thread_local int g_stmt_start_col;
static int g_context_before = 4;
static int g_context_after = 4;
static std::map<int, std::string> g_line_to_file;
static void print_source_context(int line, int col, const char* filename);
static std::vector<std::string> g_command_args; 
bool g_trace_ast = false;   // 运行时打印 AST 跟踪

static const char* find_filename_by_line_col(int line, int col) {
    // 1. 优先使用 g_line_to_file 映射（按行号精确覆盖）
    auto it = g_line_to_file.find(line);
    if (it != g_line_to_file.end()) {
        return it->second.c_str();
    }
    // 2. 若未找到，再尝试从 token 中查找
    for (int i = 0; i < token_count; ++i) {
        if (tokens[i].line == line && tokens[i].col == col && tokens[i].filename) {
            return tokens[i].filename;
        }
    }
    // 3. 若 col 为 0 或未精确匹配，返回该行第一个 Token 的文件名
    for (int i = 0; i < token_count; ++i) {
        if (tokens[i].line == line && tokens[i].filename) {
            return tokens[i].filename;
        }
    }
    return nullptr;
}

static std::string suggest_correction(const std::string& name);

class KRError : public std::exception {
    std::string msg;
    std::string hint;
    bool already_printed;
public:
    KRError() : msg("Fehler: Programm beendet.") {}
    explicit KRError(const std::string& m, bool printed = false) : msg(m), already_printed(printed) {}
    explicit KRError(const std::string& m, const std::string& h, bool printed = false) : msg(m), hint(h), already_printed(printed) {}
    explicit KRError(const char* m, bool printed = false) : msg(m ? m : "Fehler: Programm beendet."), already_printed(printed) {}
    explicit KRError(const char* m, const char* h, bool printed = false) : msg(m ? m : "Fehler: Programm beendet."), hint(h ? h : ""), already_printed(printed) {}
    bool isAlreadyPrinted() const noexcept { return already_printed; }
    const char* what() const noexcept override {
        static thread_local std::string full;
        full = msg;
        if (!hint.empty()) {
            full += "\n\033[30m[Hinw]\033[0m ";
            full += hint;
        }
        return full.c_str();
    }
};

[[noreturn]] void kr_error(const char* format, ...) {
    va_list args;
    va_start(args, format);
    char buffer[1024];
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    int line = g_last_error_line;
    int col = g_last_error_col;
    const char* filename = nullptr;

    if (line != 0 && col != 0) {
        filename = find_filename_by_line_col(line, col);
        if (!filename) {
            if (g_last_error_filename && g_last_error_filename[0] != '\0')
                filename = g_last_error_filename;
            else
                filename = current_filename;
        }
    } else {
        if (!g_call_stack.empty()) {
            const CallFrame& frame = g_call_stack.back();
            line = frame.line;
            col = frame.col;
            filename = frame.filename;
            if (filename && strcmp(filename, "-") == 0) {
                filename = current_filename;
            }
        } else if (line == 0) {
            if (tok_pos < token_count) {
                line = tokens[tok_pos].line;
                col = tokens[tok_pos].col;
            } else {
                line = g_last_token_line;
                col = g_last_token_col;
            }
            if (line == 0) {
                line = g_stmt_start_line;
                col = g_stmt_start_col;
            }
        }
        if (line == 0) { line = 1; col = 1; }

        if (!g_custom_source_context.empty()) {
            filename = current_filename;
        } else {
            if (line > 0 && col > 0) {
                filename = find_filename_by_line_col(line, col);
            }
            if (!filename && line > 0) {
                auto it = g_line_to_file.find(line);
                if (it != g_line_to_file.end()) filename = it->second.c_str();
                else {
                    auto it2 = g_line_to_file.upper_bound(line);
                    if (it2 != g_line_to_file.begin()) { --it2; filename = it2->second.c_str(); }
                }
            }
            if (!filename) filename = current_filename;
        }
        if (!filename) filename = "-";
    }

    // ---- 优先使用调用栈中的文件名（如果有效），但不改变行列 ----
    if (g_last_error_filename && g_last_error_filename[0] != '\0' && strcmp(g_last_error_filename, "-") != 0) {
        filename = g_last_error_filename;
    } else if (!g_call_stack.empty()) {
        const CallFrame& frame = g_call_stack.back();
        if (frame.filename && strcmp(frame.filename, "-") != 0) {
            filename = frame.filename;
        }
    }

    // ---- 更新全局缓存（如果之前没有） ----
    g_last_error_line = line;
    g_last_error_col = col;
    g_last_error_filename = filename;

    // ---- 构造完整错误消息并抛出 ----
    char full_msg[2048];
    snprintf(full_msg, sizeof(full_msg), "\033[31m[Fehl]\033[0m \033[34m%s\033[0m \033[96m%s:%d:%d:\033[0m %s",
             g_current_operating_position.c_str(),
             filename ? filename : "-",
             line, col, buffer);
    throw KRError(std::string(full_msg));
}

[[noreturn]] void kr_error_hint(const char* hint, const char* format, ...) {
    const char* filename = nullptr;
    va_list args;
    va_start(args, format);
    char buffer[1024];
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    int line = g_last_error_line;
    int col = g_last_error_col;

    if (line != 0 && col != 0) {
        filename = find_filename_by_line_col(line, col);
        if (!filename) {
            if (g_last_error_filename && g_last_error_filename[0] != '\0')
                filename = g_last_error_filename;
            else
                filename = current_filename;
        }
    } else {
        if (!g_call_stack.empty()) {
            const CallFrame& frame = g_call_stack.back();
            line = frame.line;
            col = frame.col;
            filename = frame.filename;
            if (filename && strcmp(filename, "-") == 0) {
                filename = current_filename;
            }
        } else if (line == 0) {
            if (tok_pos < token_count) {
                line = tokens[tok_pos].line;
                col = tokens[tok_pos].col;
            } else {
                line = g_last_token_line;
                col = g_last_token_col;
            }
            if (line == 0) {
                line = g_stmt_start_line;
                col = g_stmt_start_col;
            }
        }
        if (line == 0) { line = 1; col = 1; }

        if (!g_custom_source_context.empty()) {
            filename = current_filename;
        } else {
            if (line > 0 && col > 0) {
                filename = find_filename_by_line_col(line, col);
            }
            if (!filename && line > 0) {
                auto it = g_line_to_file.find(line);
                if (it != g_line_to_file.end()) filename = it->second.c_str();
                else {
                    auto it2 = g_line_to_file.upper_bound(line);
                    if (it2 != g_line_to_file.begin()) { --it2; filename = it2->second.c_str(); }
                }
            }
            if (!filename) filename = current_filename;
        }
        if (!filename) filename = "-";
    }

    // ---- 优先使用调用栈中的文件名（如果有效），但不改变行列 ----
    if (g_last_error_filename && g_last_error_filename[0] != '\0' && strcmp(g_last_error_filename, "-") != 0) {
        filename = g_last_error_filename;
    } else if (!g_call_stack.empty()) {
        const CallFrame& frame = g_call_stack.back();
        if (frame.filename && strcmp(frame.filename, "-") != 0) {
            filename = frame.filename;
        }
    }

    g_last_error_line = line;
    g_last_error_col = col;
    g_last_error_filename = filename;
    
    char full_msg[2048];
    snprintf(full_msg, sizeof(full_msg), "\033[31m[Fehl]\033[0m \033[34m%s\033[0m \033[96m%s:%d:%d:\033[0m %s",
             g_current_operating_position.c_str(),
             filename ? filename : "-",
             line, col, buffer);
    throw KRError(std::string(full_msg), hint ? std::string(hint) : "");
}

void kr_warn(const char* format, ...);
static bool g_warnings_enabled = false;
// 警告函数：打印警告信息，不退出
void kr_warn(const char* format, ...) {
    const char* filename = nullptr;
    if (!g_warnings_enabled) return;   // 未开启则直接返回
    va_list args;
    va_start(args, format);
    char buffer[1024];
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    // 自动获取出错位置（与 kr_error 逻辑一致）
    int line = g_last_error_line;
    int col = g_last_error_col;
    
    if (line != 0 && col != 0) {
        filename = find_filename_by_line_col(line, col);
        if (!filename) {
            if (g_last_error_filename && g_last_error_filename[0] != '\0')
                filename = g_last_error_filename;
            else
                filename = current_filename;
        }
    } else {
        if (!g_call_stack.empty()) {
            const CallFrame& frame = g_call_stack.back();
            line = frame.line;
            col = frame.col;
            filename = frame.filename;
            if (filename && strcmp(filename, "-") == 0) {
                filename = current_filename;
            }
        } else if (line == 0) {
            if (tok_pos < token_count) {
                line = tokens[tok_pos].line;
                col = tokens[tok_pos].col;
            } else {
                line = g_last_token_line;
                col = g_last_token_col;
            }
            if (line == 0) {
                line = g_stmt_start_line;
                col = g_stmt_start_col;
            }
        }
        if (line == 0) { line = 1; col = 1; }

        if (!g_custom_source_context.empty()) {
            filename = current_filename;
        } else {
            if (line > 0 && col > 0) {
                filename = find_filename_by_line_col(line, col);
            }
            if (!filename && line > 0) {
                auto it = g_line_to_file.find(line);
                if (it != g_line_to_file.end()) filename = it->second.c_str();
                else {
                    auto it2 = g_line_to_file.upper_bound(line);
                    if (it2 != g_line_to_file.begin()) { --it2; filename = it2->second.c_str(); }
                }
            }
            if (!filename) filename = current_filename;
        }
        if (!filename) filename = "-";
    }

    // ---- 优先使用调用栈中的文件名（如果有效），但不改变行列 ----
    if (g_last_error_filename && g_last_error_filename[0] != '\0' && strcmp(g_last_error_filename, "-") != 0) {
        filename = g_last_error_filename;
    } else if (!g_call_stack.empty()) {
        const CallFrame& frame = g_call_stack.back();
        if (frame.filename && strcmp(frame.filename, "-") != 0) {
            filename = frame.filename;
        }
    }
    
    g_last_error_line = line;
    g_last_error_col = col;
    g_last_error_filename = filename;

    fprintf(stderr, "\033[33m[Warn]\033[0m \033[34m%s\033[0m \033[96m%s:%d:%d:\033[0m %s\n",
        g_current_operating_position.c_str(), filename, line, col, buffer);
}
 #define KR_THROW(msg) kr_error("%s", msg)

 #define FLAG_NUM        (1 << 0)   // 数值模式
 #define FLAG_NO_STORE   (1 << 1)   // 不存储模式
 #define FLAG_FLOAT     (1 << 2)

 #define _USE_MATH_DEFINES

 template <typename Key, typename Value>
 class LRUCache {
     size_t capacity_;
     mutable std::mutex mtx_;
     std::list<Key> lru_list_;
     std::unordered_map<Key, std::pair<Value, typename std::list<Key>::iterator>> cache_;
 public:
     LRUCache(size_t cap = 1024) : capacity_(cap) {}
     Value get(const Key& key, std::function<Value()> loader) {
         std::unique_lock<std::mutex> lock(mtx_);
         auto it = cache_.find(key);
         if (it != cache_.end()) {
             lru_list_.splice(lru_list_.begin(), lru_list_, it->second.second);
             return it->second.first;
         }
         lock.unlock();                        // 释放锁，避免在 loader 中死锁
         Value val = loader();
         lock.lock();                          // 重新加锁
         if (cache_.size() >= capacity_) {
             auto last = lru_list_.back();
             cache_.erase(last);
             lru_list_.pop_back();
         }
         lru_list_.push_front(key);
         cache_[key] = {val, lru_list_.begin()};
         return val;
     }
     void clear() {
         std::unique_lock<std::mutex> lock(mtx_);
         cache_.clear();
         lru_list_.clear();
     }
 };

 thread_local int g_last_error_line = 0;
 thread_local int g_last_error_col = 0;
 thread_local int g_last_token_line = 0;
 thread_local int g_last_token_col = 0;
 thread_local int g_stmt_start_line = 0;
 thread_local int g_stmt_start_col = 0;
 thread_local int g_in_expr_depth = 0;
 thread_local std::string g_custom_source_context;
 
 /* ========== 前向声明 ========== */
 struct ASTNode;
 ASTNode* parse_expression();
 ASTNode* parse_term();
 ASTNode* parse_condition();
 ASTNode* parse_backtick_interp(const char* raw);
 ASTNode* parse_statement(int allow_semicolon);
 ASTNode* parse_block();
 ASTNode* parse_body_block(int base_indent);
 ASTNode* parse_program();
 ASTNode* parse_logical_or();
 ASTNode* parse_logical_and();
 ASTNode* parse_unary();
 ASTNode* parse_comparison();
 ASTNode* parse_add_sub();
 ASTNode* parse_mul_div();
 ASTNode* parse_ternary();
 ASTNode* parse_foreach();
 ASTNode* parse_postfix(ASTNode* left);
 ASTNode* copy_ast(ASTNode* node);
 ASTNode* expand_macros_in_ast(ASTNode* node);
 ASTNode* expand_macro(const std::string& name, std::vector<ASTNode*>& args, int line, int col);
 ASTNode* parse_range();
 ASTNode* parse_bitwise_xor();
 ASTNode* parse_bitwise_or();
 ASTNode* parse_bitwise_and();
 ASTNode* parse_shift();
 ASTNode* parse_pipe();
 ASTNode* parse_null_coalesce();
 ASTNode* parse_list_comprehension();
 ASTNode* parse_object_literal();
 ASTNode* parse_object_comprehension();
 ASTNode* parse_pattern();
 ASTNode* parse_pattern_list();
 ASTNode* parse_enum_definition();
 void free_key_binds();
 void free_ast(ASTNode* node);
 void tokenize_impl(const char* source);
 bool exec_statement(ASTNode* node);
 ASTNode* parse_class_definition(int access_modifier = 0, bool is_static_class = false);
 ASTNode* parse_primary();
 ASTNode* parse_match_expression(int als_col, int als_line);
 ASTNode* prog = nullptr;
 static ASTNode* parse_interp_postfix(const char* s, int* pos, ASTNode* left);
 static ASTNode* parse_interp_expression(const char* src);
 static std::string process_interp_expr(const char* expr_src);

 thread_local ASTNode* g_current_eval_node = nullptr;
 thread_local std::vector<ASTNode*> g_eval_node_stack;
 
 struct EvalNodeGuard {
     EvalNodeGuard(ASTNode* node) {
         g_eval_node_stack.push_back(node);
         g_current_eval_node = node;
     }
     ~EvalNodeGuard() {
         if (!g_eval_node_stack.empty()) {
             g_eval_node_stack.pop_back();
             g_current_eval_node = g_eval_node_stack.empty() ? nullptr : g_eval_node_stack.back();
         }
     }
 };

 struct Scope;
 struct TypeNode;
 struct Variable;
 Variable* resolve_alias(Variable* var);

 TypeNode* copy_type_node(TypeNode* src);
 void free_type_node(TypeNode* type);
 
 ASTNode* make_default_value_for_type(TypeNode* type);

struct MacroDef {
    std::vector<std::string> params;   // 参数名列表
    ASTNode* body;                     // 宏体 AST（未展开）
    int line;                          // 宏定义所在行
    int col;                           // 宏定义所在列
};
static std::unordered_map<std::string, MacroDef> macros;

struct PreprocessMacroDef {
    std::vector<std::string> params;
    std::string replacement;
    int line;
    int col;
};

struct PropertyDef {
    std::string name;
    TypeNode* type;            // 可为 nullptr
    ASTNode* default_expr;     // 默认值表达式，可为 nullptr
    bool is_const;
    bool is_static;
    bool is_lazy = false;
    int access;                // 0=public, 1=private, 2=protected
};

struct MethodDef {
    std::vector<std::string> params;
    std::vector<TypeNode*> param_types;
    ASTNode* body = nullptr;
    bool is_static = false;
    int access = 0;
    TypeNode* return_type = nullptr;
    std::string vararg_name;
    TypeNode* vararg_type = nullptr;
    bool is_stmt_func = false;
};

struct ClassDef {
    std::string name;
    std::string parent;                 // 空表示无父类
    std::vector<std::string> ctor_params; // 构造函数参数名
    std::vector<TypeNode*> ctor_param_types;
    ASTNode* ctor_body;                // 构造函数体（可包含 ober 调用）
    std::unordered_map<std::string, MethodDef> methods;
    std::vector<PropertyDef> properties;
    int access_modifier;
    std::string defining_file;
    bool is_static_class = false;
    std::vector<ASTNode*> ctor_defaults;
};

struct RecordMeta {
    uint64_t id;
    uint64_t vater;
    uint32_t type;
    std::vector<std::string> tags;
    uint64_t text_offset;
    uint64_t data_offset;
    uint32_t text_len;
    uint32_t data_len;
};

struct Record {
    uint64_t id;
    uint64_t vater;
    uint32_t type;
    std::vector<std::string> tags;
    std::string text;
    std::vector<uint8_t> data;
};

template <typename V>
struct ScopedTypeMap : std::unordered_map<std::string, V> {
    using Base = std::unordered_map<std::string, V>;
    using Base::Base;

    // 裸名 → 当前 umf 下的限定名
    std::string qualify(const std::string& bare) const {
        if (g_umf_stack.empty()) return bare;
        std::string k;
        for (auto& u : g_umf_stack) { k += u; k += "::"; }
        return k + bare;
    }

    // ---- 读路径：先限定名，回退裸名 ----
    typename Base::iterator find(const std::string& bare) {
        auto it = Base::find(qualify(bare));
        return (it != this->end()) ? it : Base::find(bare);
    }
    typename Base::const_iterator find(const std::string& bare) const {
        auto it = Base::find(qualify(bare));
        return (it != this->end()) ? it : Base::find(bare);
    }
    size_t count(const std::string& bare) const {
        return find(bare) != this->end() ? 1 : 0;
    }
    V& at(const std::string& bare) {
        auto it = find(bare);
        if (it == this->end())
            throw std::out_of_range("ScopedTypeMap::at: " + bare);
        return it->second;
    }
    const V& at(const std::string& bare) const {
        auto it = find(bare);
        if (it == this->end())
            throw std::out_of_range("ScopedTypeMap::at: " + bare);
        return it->second;
    }
};

static ScopedTypeMap<ClassDef> class_table;
static ScopedTypeMap<TypeNode*> type_aliases;
static std::atomic<int> next_scope_id{1};
static thread_local std::unordered_map<int, std::unordered_map<int, std::string>> print_lines;
static std::mutex global_interpreter_mutex;
static std::mutex print_mutex;
static std::thread::id main_thread_id;
static bool derive_key(const std::string& password, unsigned char* key);
static fs::path exe_dir;
static std::unordered_map<std::string, Scope*> module_cache;
static std::set<std::string> loading_modules;
static std::mutex module_cache_mutex;
static std::vector<ASTNode*> g_loaded_module_asts;
static int utf8_char_width(const char* str, size_t* char_len);
static std::recursive_mutex g_global_mutex;
static std::unordered_map<std::string, std::pair<int,int>> g_var_decl_pos;
static std::unordered_map<std::string, std::pair<int,int>> g_func_decl_pos;
static std::unordered_set<std::string> g_stmt_func_names;
static bool g_optimize_for_loops = false;

thread_local bool g_in_async_context = false;
thread_local std::string g_current_class_name_str;
thread_local const char* g_current_class_name = nullptr;

struct EnumInfo {
    std::vector<std::string> variants;
    std::vector<int> param_counts;
};
static ScopedTypeMap<EnumInfo> enum_table;

std::unordered_map<std::string, std::atomic<bool>> g_key_pressed;
std::unordered_map<std::string, std::thread> g_key_listeners;
std::mutex g_key_listener_mutex;
bool g_listener_running = false;
char* unescape_string(const char* s, size_t* out_len = (size_t*)nullptr);
std::string normalize_key_string(const std::string& s);
std::string ansi_to_key_name(const std::string& seq);
std::string map_extended_key(int ch2);
std::unordered_map<std::string, Scope*> named_scopes;

std::string ansi_to_key_name(const std::string& seq) {
    static const std::unordered_map<std::string, std::string> map = {
        {"\x1b[A", "Up"},
        {"\x1b[B", "Down"},
        {"\x1b[C", "Right"},
        {"\x1b[D", "Left"},
        {"\x1b[H", "Home"},
        {"\x1b[F", "End"},
        {"\x1b[5~", "PageUp"},
        {"\x1b[6~", "PageDown"},
        {"\x1b[2~", "Insert"},
        {"\x1b[3~", "Delete"},
        {"\x1b[11~", "F1"},
        {"\x1b[12~", "F2"},
        {"\x1b[13~", "F3"},
        {"\x1b[14~", "F4"},
        {"\x1b[15~", "F5"},
        {"\x1b[17~", "F6"},
        {"\x1b[18~", "F7"},
        {"\x1b[19~", "F8"},
        {"\x1b[20~", "F9"},
        {"\x1b[21~", "F10"},
        {"\x1b[23~", "F11"},
        {"\x1b[24~", "F12"},
        // 可继续添加 F13-F24 等
    };
    auto it = map.find(seq);
    if (it != map.end()) return it->second;
    // 如果不是标准序列，可能是一个普通字符（单字符）或未知，返回原始序列
    return seq;
}

int key_to_vk(const std::string& key) {
    if (key == "Esc")   return VK_ESCAPE;
    if (key == "Up")    return VK_UP;
    if (key == "Down")  return VK_DOWN;
    if (key == "Left")  return VK_LEFT;
    if (key == "Right") return VK_RIGHT;
    if (key == "Home")  return VK_HOME;
    if (key == "End")   return VK_END;
    if (key == "PageUp") return VK_PRIOR;
    if (key == "PageDown") return VK_NEXT;
    if (key == "Insert") return VK_INSERT;
    if (key == "Delete") return VK_DELETE;
    for (int i = 1; i <= 24; ++i) {
        if (key == "F" + std::to_string(i))
            return VK_F1 + (i - 1);
    }
    if (key.length() == 1) {
        // 字母或数字，返回对应的虚拟键码（字母需大写）
        char ch = key[0];
        if (ch >= 'a' && ch <= 'z') ch = toupper(ch);
        return ch; // VK_A 到 VK_Z 与 ASCII 一致
    }
    return 0;
}

bool is_key_pressed(const std::string& key) {
#if defined(_WIN32) || defined(_WIN64)
    int vk = key_to_vk(key);
    if (vk == 0) return false;
    return (GetAsyncKeyState(vk) & 0x8000) != 0;
#else
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    int ch = getchar();
    if (ch == EOF) {
        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
        return false;
    }
    std::string seq;
    seq += (char)ch;
    if (ch == 0x1B) {
        int ch2 = getchar();
        if (ch2 != EOF) {
            seq += (char)ch2;
            if (ch2 == '[') {
                while (true) {
                    int c = getchar();
                    if (c == EOF) break;
                    seq += (char)c;
                    if (isalpha(c) || c == '~') break;
                }
            } else if (ch2 == 'O') {
                int c = getchar();
                if (c != EOF) seq += (char)c;
            }
        }
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    // 将 ANSI 序列转为规范名
    std::string norm = ansi_to_key_name(seq);
    if (norm.empty()) norm = seq;
    return norm == key;
#endif
}

class ScopedLockRelease {
    std::recursive_mutex& mtx_;
    bool released_;
public:
    explicit ScopedLockRelease(std::recursive_mutex& mtx) 
        : mtx_(mtx), released_(false) {}
    
    ~ScopedLockRelease() {
        if (released_) {
            mtx_.lock();   // 确保析构时重新加锁
        }
    }
    
    void release() {
        if (!released_) {
            mtx_.unlock();
            released_ = true;
        }
    }
    
    void relock() {
        if (released_) {
            mtx_.lock();
            released_ = false;
        }
    }
};

// ----- KDDataSet 类 -----
class KDDataSet : public std::enable_shared_from_this<KDDataSet> {
    public:
        KDDataSet() = default;
        ~KDDataSet() { close(); }
    
        bool load(const std::string& fname);
        bool insert_record(const Record& rec);
        bool update_record(uint64_t id, const Record& rec);
        bool delete_record(uint64_t id);
        Record get_record(uint64_t id);
        std::vector<uint64_t> find_by_tag(const std::string& tag);
        std::vector<uint64_t> find_by_type(uint32_t type);
        std::vector<uint64_t> find_children(uint64_t vater_id);
        std::vector<uint64_t> find_by_text(const std::string& regex_str);
        std::vector<uint64_t> filter_records(std::function<bool(const Record&)> pred);
        std::vector<uint64_t> all_ids() const;
        uint64_t naechste_id() const;
        bool compact(const std::string& backup_suffix = ".bak");
        bool encrypt(const std::string& password);
        bool decrypt(const std::string& password);
    
    private:
        struct Meta {
            uint64_t id;
            uint64_t vater;
            uint32_t type;
            std::vector<std::string> tags;
            uint64_t text_offset;
            uint32_t text_len;
            uint64_t data_offset;
            uint32_t data_len;
        };
    
        std::string filename_;
        mutable std::fstream file_;               // 文件流（可读可写）
        std::unordered_map<uint64_t, Meta> meta_map_;
        std::unordered_map<std::string, std::vector<uint64_t>> tag_index_;
        std::unordered_map<uint32_t, std::vector<uint64_t>> type_index_;
        std::unordered_map<uint64_t, std::vector<uint64_t>> vater_index_;
        LRUCache<uint64_t, Record> cache_{1024};
        mutable std::shared_mutex rw_mtx_;        // 读写锁
        std::mutex io_mtx_;                       // 保护文件流操作
        bool encrypted_ = false;
    
        // 内部辅助
        bool read_meta(Meta& meta);
        bool write_meta(const Meta& meta);
        bool read_record_data(const Meta& meta, Record& rec);
        bool write_record_data(const Meta& meta, const Record& rec);
        void rebuild_indices();
        bool update_header(uint64_t count);
        void close();
    };

// ---------- 实现 ----------
bool KDDataSet::load(const std::string& fname) {
    std::lock_guard<std::shared_mutex> lock(rw_mtx_);
    close();
    filename_ = fname;

    // 尝试以读写模式打开
    file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
    if (!file_) {
        // 文件不存在，创建新文件
        file_.clear();
        file_.open(filename_, std::ios::out | std::ios::binary);
        if (!file_) return false;
        // 写入空头
        file_.write("KDB", 3);
        uint32_t version = 1;
        uint64_t count = 0;
        file_.write(reinterpret_cast<const char*>(&version), 4);
        file_.write(reinterpret_cast<const char*>(&count), 8);
        file_.flush();
        file_.close();
        // 重新以读写模式打开
        file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
        if (!file_) return false;
        return true;
    }

    // 读取魔数
    char magic[4] = {0};
    file_.read(magic, 3);
    if (!file_.good() || (magic[0] != 'K' || magic[1] != 'D' || magic[2] != 'B')) {
        if (magic[0] == 'K' && magic[1] == 'D' && magic[2] == 'E') {
            encrypted_ = true;          // 标记为加密
            file_.close();              // 关闭文件（解密时重新打开）
            return true;                // 返回成功，但不加载元数据
        }
        file_.close();
        return false;
    }

    uint32_t version;
    uint64_t count;
    file_.read(reinterpret_cast<char*>(&version), 4);
    file_.read(reinterpret_cast<char*>(&count), 8);
    if (!file_.good() || count > 1000000000) { // 防止恶意大数
        file_.close();
        return false;
    }

    meta_map_.clear();
    tag_index_.clear();
    type_index_.clear();
    vater_index_.clear();
    cache_.clear();

    for (uint64_t i = 0; i < count; ++i) {
        Meta meta;
        if (!read_meta(meta)) {
            file_.close();
            return false;
        }
        meta_map_[meta.id] = std::move(meta);
    }

    rebuild_indices();
    return true;
}

bool KDDataSet::read_meta(Meta& meta) {
    // 假设文件流已位于记录起始
    file_.read(reinterpret_cast<char*>(&meta.id), 8);
    file_.read(reinterpret_cast<char*>(&meta.vater), 8);
    file_.read(reinterpret_cast<char*>(&meta.type), 4);
    uint32_t tag_count;
    file_.read(reinterpret_cast<char*>(&tag_count), 4);
    if (!file_.good() || tag_count > 10000) return false;
    meta.tags.clear();
    meta.tags.reserve(tag_count);
    for (uint32_t j = 0; j < tag_count; ++j) {
        uint32_t len;
        file_.read(reinterpret_cast<char*>(&len), 4);
        if (!file_.good() || len > 65536) return false;
        std::string tag(len, '\0');
        file_.read(&tag[0], len);
        if (!file_.good()) return false;
        meta.tags.push_back(std::move(tag));
    }
    file_.read(reinterpret_cast<char*>(&meta.text_len), 4);
    if (!file_.good() || meta.text_len > 100000000) return false;
    meta.text_offset = file_.tellg();
    file_.seekg(meta.text_len, std::ios::cur);
    if (!file_.good()) return false;
    file_.read(reinterpret_cast<char*>(&meta.data_len), 4);
    if (!file_.good() || meta.data_len > 100000000) return false;
    meta.data_offset = file_.tellg();
    file_.seekg(meta.data_len, std::ios::cur);
    return file_.good();
}

bool KDDataSet::write_meta(const Meta& meta) {
    // 写入固定字段
    file_.write(reinterpret_cast<const char*>(&meta.id), 8);
    file_.write(reinterpret_cast<const char*>(&meta.vater), 8);
    file_.write(reinterpret_cast<const char*>(&meta.type), 4);
    uint32_t tag_count = static_cast<uint32_t>(meta.tags.size());
    file_.write(reinterpret_cast<const char*>(&tag_count), 4);
    for (const auto& tag : meta.tags) {
        uint32_t len = static_cast<uint32_t>(tag.size());
        file_.write(reinterpret_cast<const char*>(&len), 4);
        file_.write(tag.data(), len);
    }
    file_.write(reinterpret_cast<const char*>(&meta.text_len), 4);
    // text 和 data 由 write_record_data 处理
    return file_.good();
}

bool KDDataSet::write_record_data(const Meta& meta, const Record& rec) {
    // 写入 text
    if (meta.text_len > 0)
        file_.write(rec.text.data(), meta.text_len);
    // 写入 data_len
    file_.write(reinterpret_cast<const char*>(&meta.data_len), 4);
    // 写入 data
    if (meta.data_len > 0)
        file_.write(reinterpret_cast<const char*>(rec.data.data()), meta.data_len);
    return file_.good();
}

bool KDDataSet::read_record_data(const Meta& meta, Record& rec) {
    rec.id = meta.id;
    rec.vater = meta.vater;
    rec.type = meta.type;
    rec.tags = meta.tags;
    if (meta.text_len > 0) {
        rec.text.resize(meta.text_len);
        file_.seekg(meta.text_offset);
        file_.read(&rec.text[0], meta.text_len);
        if (!file_.good()) return false;
    } else {
        rec.text.clear();
    }
    if (meta.data_len > 0) {
        rec.data.resize(meta.data_len);
        file_.seekg(meta.data_offset);
        file_.read(reinterpret_cast<char*>(rec.data.data()), meta.data_len);
        if (!file_.good()) return false;
    } else {
        rec.data.clear();
    }
    return true;
}

void KDDataSet::rebuild_indices() {
    tag_index_.clear();
    type_index_.clear();
    vater_index_.clear();
    for (const auto& pair : meta_map_) {
        const Meta& meta = pair.second;
        for (const auto& tag : meta.tags)
            tag_index_[tag].push_back(meta.id);
        type_index_[meta.type].push_back(meta.id);
        vater_index_[meta.vater].push_back(meta.id);
    }
}

bool KDDataSet::update_header(uint64_t count) {
    file_.seekp(3 + 4); // 跳过魔数和版本
    file_.write(reinterpret_cast<const char*>(&count), 8);
    file_.flush();
    return file_.good();
}

bool KDDataSet::insert_record(const Record& rec) {
    std::lock_guard<std::shared_mutex> lock(rw_mtx_);
    if (!file_.is_open()) return false;
    if (meta_map_.find(rec.id) != meta_map_.end()) return false;

    // 构造 Meta
    Meta meta;
    meta.id = rec.id;
    meta.vater = rec.vater;
    meta.type = rec.type;
    meta.tags = rec.tags;
    meta.text_len = static_cast<uint32_t>(rec.text.size());
    meta.data_len = static_cast<uint32_t>(rec.data.size());

    // 计算偏移（先计算头部大小）
    uint32_t tags_size = 0;
    for (const auto& tag : meta.tags)
        tags_size += 4 + static_cast<uint32_t>(tag.size());

    file_.seekp(0, std::ios::end);
    uint64_t start = file_.tellp();

    uint64_t header_size = 8 + 8 + 4 + 4 + tags_size + 4; // id + vater + type + tag_count + tags + text_len
    uint64_t text_offset = start + header_size;
    uint64_t data_offset = text_offset + meta.text_len + 4; // +4 for data_len

    meta.text_offset = text_offset;
    meta.data_offset = data_offset;

    // 写入头部
    if (!write_meta(meta)) {
        file_.flush();
        return false;
    }
    // 写入 text + data_len + data
    if (!write_record_data(meta, rec)) {
        file_.flush();
        return false;
    }

    file_.flush();
    if (!file_.good()) return false;

    // 更新内存
    meta_map_[meta.id] = meta;
    for (const auto& tag : meta.tags)
        tag_index_[tag].push_back(meta.id);
    type_index_[meta.type].push_back(meta.id);
    vater_index_[meta.vater].push_back(meta.id);

    // 更新文件头记录数
    update_header(meta_map_.size());

    cache_.clear();
    return true;
}

bool KDDataSet::update_record(uint64_t id, const Record& rec) {
    if (!delete_record(id)) return false;
    Record new_rec = rec;
    new_rec.id = id;
    return insert_record(new_rec);
}

bool KDDataSet::delete_record(uint64_t id) {
    std::lock_guard<std::shared_mutex> lock(rw_mtx_);
    auto it = meta_map_.find(id);
    if (it == meta_map_.end()) return false;

    const Meta& meta = it->second;

    // 从索引移除
    for (const auto& tag : meta.tags) {
        auto& vec = tag_index_[tag];
        vec.erase(std::remove(vec.begin(), vec.end(), id), vec.end());
        if (vec.empty()) tag_index_.erase(tag);
    }
    auto& typ_vec = type_index_[meta.type];
    typ_vec.erase(std::remove(typ_vec.begin(), typ_vec.end(), id), typ_vec.end());
    if (typ_vec.empty()) type_index_.erase(meta.type);
    auto& par_vec = vater_index_[meta.vater];
    par_vec.erase(std::remove(par_vec.begin(), par_vec.end(), id), par_vec.end());
    if (par_vec.empty()) vater_index_.erase(meta.vater);

    meta_map_.erase(it);
    cache_.clear();

    update_header(meta_map_.size());
    return true;
}

Record KDDataSet::get_record(uint64_t id) {
    return cache_.get(id, [this, id]() -> Record {
        std::shared_lock<std::shared_mutex> lock(rw_mtx_);
        auto it = meta_map_.find(id);
        if (it == meta_map_.end())
            throw KRError("KD: Datensatz-ID nicht gefunden");
        const Meta& meta = it->second;
        Record rec;
        std::lock_guard<std::mutex> io_lock(io_mtx_);
        if (!read_record_data(meta, rec))
            throw KRError("KD: konnte Datensatz nicht lesen");
        return rec;
    });
}

std::vector<uint64_t> KDDataSet::find_by_tag(const std::string& tag) {
    std::shared_lock<std::shared_mutex> lock(rw_mtx_);
    auto it = tag_index_.find(tag);
    return (it == tag_index_.end()) ? std::vector<uint64_t>{} : it->second;
}

std::vector<uint64_t> KDDataSet::find_by_type(uint32_t type) {
    std::shared_lock<std::shared_mutex> lock(rw_mtx_);
    auto it = type_index_.find(type);
    return (it == type_index_.end()) ? std::vector<uint64_t>{} : it->second;
}

std::vector<uint64_t> KDDataSet::find_children(uint64_t vater_id) {
    std::shared_lock<std::shared_mutex> lock(rw_mtx_);
    auto it = vater_index_.find(vater_id);
    return (it == vater_index_.end()) ? std::vector<uint64_t>{} : it->second;
}

std::vector<uint64_t> KDDataSet::find_by_text(const std::string& regex_str) {
    std::shared_lock<std::shared_mutex> lock(rw_mtx_);
    std::vector<uint64_t> result;
    std::regex re;
    try {
        re = std::regex(regex_str);
    } catch (...) {
        return result;
    }
    for (const auto& pair : meta_map_) {
        Record rec = get_record(pair.first);
        if (std::regex_search(rec.text, re))
            result.push_back(pair.first);
    }
    return result;
}

std::vector<uint64_t> KDDataSet::filter_records(std::function<bool(const Record&)> pred) {
    std::shared_lock<std::shared_mutex> lock(rw_mtx_);
    std::vector<uint64_t> result;
    for (const auto& pair : meta_map_) {
        Record rec = get_record(pair.first);
        if (pred(rec))
            result.push_back(pair.first);
    }
    return result;
}

std::vector<uint64_t> KDDataSet::all_ids() const {
    std::shared_lock<std::shared_mutex> lock(rw_mtx_);
    std::vector<uint64_t> ids;
    ids.reserve(meta_map_.size());
    for (const auto& pair : meta_map_)
        ids.push_back(pair.first);
    return ids;
}

uint64_t KDDataSet::naechste_id() const {
    std::shared_lock<std::shared_mutex> lock(rw_mtx_);
    uint64_t max_id = 0;
    for (const auto& pair : meta_map_)
        if (pair.first > max_id) max_id = pair.first;
    return max_id + 1;
}

bool KDDataSet::compact(const std::string& backup_suffix) {
    std::lock_guard<std::shared_mutex> lock(rw_mtx_);
    if (!file_.is_open()) return false;

    cache_.clear();
    std::string temp = filename_ + ".tmp";
    std::string backup = filename_ + backup_suffix;

    // 关闭当前文件，备份原文件
    file_.close();
    if (rename(filename_.c_str(), backup.c_str()) != 0) {
        file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
        return false;
    }

    // 创建临时文件
    std::ofstream ofs(temp, std::ios::binary);
    if (!ofs) {
        rename(backup.c_str(), filename_.c_str());
        file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
        return false;
    }

    // 写入头部
    ofs.write("KDB", 3);
    uint32_t version = 1;
    uint64_t count = meta_map_.size();
    ofs.write(reinterpret_cast<const char*>(&version), 4);
    ofs.write(reinterpret_cast<const char*>(&count), 8);

    // 遍历所有记录，逐个写入
    for (const auto& pair : meta_map_) {
        const Meta& meta = pair.second;
        Record rec;
        // 从原备份文件读取数据（注意原文件已关闭，需重新打开只读）
        std::ifstream ifs(backup, std::ios::binary);
        if (!ifs) {
            ofs.close();
            remove(temp.c_str());
            rename(backup.c_str(), filename_.c_str());
            file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
            return false;
        }
        ifs.seekg(meta.text_offset);
        rec.text.resize(meta.text_len);
        ifs.read(&rec.text[0], meta.text_len);
        if (!ifs) { ifs.close(); ofs.close(); remove(temp.c_str()); rename(backup.c_str(), filename_.c_str()); file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary); return false; }
        ifs.seekg(meta.data_offset);
        rec.data.resize(meta.data_len);
        ifs.read(reinterpret_cast<char*>(rec.data.data()), meta.data_len);
        if (!ifs) { ifs.close(); ofs.close(); remove(temp.c_str()); rename(backup.c_str(), filename_.c_str()); file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary); return false; }
        ifs.close();

        rec.id = meta.id;
        rec.vater = meta.vater;
        rec.type = meta.type;
        rec.tags = meta.tags;

        // 写入临时文件
        Meta new_meta;
        new_meta.id = rec.id;
        new_meta.vater = rec.vater;
        new_meta.type = rec.type;
        new_meta.tags = rec.tags;
        new_meta.text_len = meta.text_len;
        new_meta.data_len = meta.data_len;
        // 计算偏移（在 ofs 中）
        uint64_t start = ofs.tellp();
        uint32_t tags_size = 0;
        for (const auto& tag : new_meta.tags)
            tags_size += 4 + tag.size();
        uint64_t header_size = 8 + 8 + 4 + 4 + tags_size + 4;
        new_meta.text_offset = start + header_size;
        new_meta.data_offset = new_meta.text_offset + new_meta.text_len + 4;

        // 写入头部
        ofs.write(reinterpret_cast<const char*>(&new_meta.id), 8);
        ofs.write(reinterpret_cast<const char*>(&new_meta.vater), 8);
        ofs.write(reinterpret_cast<const char*>(&new_meta.type), 4);
        uint32_t tag_count = static_cast<uint32_t>(new_meta.tags.size());
        ofs.write(reinterpret_cast<const char*>(&tag_count), 4);
        for (const auto& tag : new_meta.tags) {
            uint32_t len = static_cast<uint32_t>(tag.size());
            ofs.write(reinterpret_cast<const char*>(&len), 4);
            ofs.write(tag.data(), len);
        }
        ofs.write(reinterpret_cast<const char*>(&new_meta.text_len), 4);
        if (new_meta.text_len > 0)
            ofs.write(rec.text.data(), new_meta.text_len);
        ofs.write(reinterpret_cast<const char*>(&new_meta.data_len), 4);
        if (new_meta.data_len > 0)
            ofs.write(reinterpret_cast<const char*>(rec.data.data()), new_meta.data_len);
    }

    ofs.flush();
    ofs.close();

    // 替换文件
    if (rename(temp.c_str(), filename_.c_str()) != 0) {
        rename(backup.c_str(), filename_.c_str());
        file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
        return false;
    }

    // 重新打开并重建索引
    file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
    if (!file_) {
        rename(backup.c_str(), filename_.c_str());
        file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
        return false;
    }

    // 重新加载元数据
    meta_map_.clear();
    tag_index_.clear();
    type_index_.clear();
    vater_index_.clear();
    cache_.clear();

    file_.seekg(0);
    char magic[4] = {0};
    file_.read(magic, 3);
    uint32_t ver;
    uint64_t cnt;
    file_.read(reinterpret_cast<char*>(&ver), 4);
    file_.read(reinterpret_cast<char*>(&cnt), 8);
    for (uint64_t i = 0; i < cnt; ++i) {
        Meta meta;
        if (!read_meta(meta)) {
            file_.close();
            return false;
        }
        meta_map_[meta.id] = std::move(meta);
    }
    rebuild_indices();
    remove(backup.c_str()); // 可选删除备份
    return true;
}

// 加密 / 解密（沿用原算法，但文件操作使用 fstream）
bool KDDataSet::encrypt(const std::string& password) {
    std::lock_guard<std::shared_mutex> lock(rw_mtx_);
    if (!file_.is_open()) return false;
    // 读取整个文件
    file_.seekg(0, std::ios::end);
    long filesize = file_.tellg();
    if (filesize <= 0) return false;
    file_.seekg(0);
    std::vector<unsigned char> plaintext(filesize);
    file_.read(reinterpret_cast<char*>(plaintext.data()), filesize);
    if (!file_.good()) return false;

    unsigned char key[32];
    if (!derive_key(password, key)) return false;

    unsigned char iv[16];
    if (RAND_bytes(iv, 16) != 1) return false;

    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return false;
    if (EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), nullptr, key, iv) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    std::vector<unsigned char> ciphertext(plaintext.size() + EVP_CIPHER_CTX_block_size(ctx));
    int out_len, total_len = 0;
    if (EVP_EncryptUpdate(ctx, ciphertext.data(), &out_len, plaintext.data(), plaintext.size()) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    total_len = out_len;
    if (EVP_EncryptFinal_ex(ctx, ciphertext.data() + total_len, &out_len) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    total_len += out_len;
    EVP_CIPHER_CTX_free(ctx);

    // 关闭并重写文件
    file_.close();
    file_.open(filename_, std::ios::out | std::ios::binary);
    if (!file_) return false;
    file_.write("KDE", 3);
    file_.write(reinterpret_cast<const char*>(iv), 16);
    file_.write(reinterpret_cast<const char*>(ciphertext.data()), total_len);
    file_.flush();
    file_.close();
    // 重新打开读写
    file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
    if (!file_) return false;
    // 清空内存索引
    meta_map_.clear();
    tag_index_.clear();
    type_index_.clear();
    vater_index_.clear();
    cache_.clear();
    return true;
}

bool KDDataSet::decrypt(const std::string& password) {
    std::lock_guard<std::shared_mutex> lock(rw_mtx_);
    if (file_.is_open()) file_.close();

    std::ifstream ifs(filename_, std::ios::binary);
    if (!ifs) return false;
    ifs.seekg(0, std::ios::end);
    std::streamsize filesize = ifs.tellg();
    if (filesize <= 19) return false;
    ifs.seekg(0);
    std::vector<unsigned char> content((size_t)filesize);
    ifs.read(reinterpret_cast<char*>(content.data()), filesize);
    if (!ifs) return false;
    ifs.close();

    if (content.size() < 19 || memcmp(content.data(), "KDE", 3) != 0)
        return false;

    unsigned char iv[16];
    memcpy(iv, content.data() + 3, 16);
    std::vector<unsigned char> ciphertext(content.begin() + 19, content.end());

    unsigned char key[32];
    if (!derive_key(password, key)) return false;

    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return false;
    if (EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), nullptr, key, iv) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    std::vector<unsigned char> plaintext(ciphertext.size());
    int out_len, total_len = 0;
    if (EVP_DecryptUpdate(ctx, plaintext.data(), &out_len, ciphertext.data(), ciphertext.size()) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    total_len = out_len;
    if (EVP_DecryptFinal_ex(ctx, plaintext.data() + total_len, &out_len) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    total_len += out_len;
    EVP_CIPHER_CTX_free(ctx);

    if (total_len < 15 || memcmp(plaintext.data(), "KDB", 3) != 0)
        return false;

    plaintext[0] = 'K';
    plaintext[1] = 'D';
    plaintext[2] = 'B';

    std::ofstream ofs(filename_, std::ios::binary);
    if (!ofs) return false;
    ofs.write(reinterpret_cast<const char*>(plaintext.data()), total_len);
    ofs.flush();
    ofs.close();

    encrypted_ = false;

    file_.open(filename_, std::ios::in | std::ios::out | std::ios::binary);
    if (!file_) return false;

    meta_map_.clear();
    tag_index_.clear();
    type_index_.clear();
    vater_index_.clear();
    cache_.clear();

    file_.seekg(0);
    char magic[4] = {0};
    file_.read(magic, 3);
    if (magic[0] != 'K' || magic[1] != 'D' || magic[2] != 'B') {
        file_.close();
        return false;
    }
    uint32_t version;
    uint64_t count;
    file_.read(reinterpret_cast<char*>(&version), 4);
    file_.read(reinterpret_cast<char*>(&count), 8);
    if (!file_.good() || count > 1000000000) {
        file_.close();
        return false;
    }
    for (uint64_t i = 0; i < count; ++i) {
        Meta meta;
        if (!read_meta(meta)) {
            file_.close();
            return false;
        }
        meta_map_[meta.id] = std::move(meta);
    }
    rebuild_indices();
    return true;
}

void KDDataSet::close() {
    if (file_.is_open()) file_.close();
    meta_map_.clear();
    tag_index_.clear();
    type_index_.clear();
    vater_index_.clear();
    cache_.clear();
}

static size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t total = size * nmemb;
    ((std::string*)userp)->append((char*)contents, total);
    return total;
}

// ============= 流式响应基础设施 =============
struct StreamState {
    std::mutex mtx;
    std::condition_variable cv;
    std::deque<std::string> chunks;
    bool closed = false;
    bool sse    = true;      // 是否 SSE 模式（自动加 data: 前缀）

    void push(std::string data) {
        {
            std::lock_guard<std::mutex> lk(mtx);
            if (closed) return;
            chunks.push_back(std::move(data));
        }
        cv.notify_one();
    }

    void close() {
        {
            std::lock_guard<std::mutex> lk(mtx);
            closed = true;
        }
        cv.notify_all();
    }
};

// 每个 handle 独立持有 shared_ptr<StreamState>，可被用户侧与 MHD 侧各持一份
struct StreamHandle {
    std::shared_ptr<StreamState> state;
};

// MHD 拉取数据回调（阻塞式）
static ssize_t stream_reader_cb(void* cls, uint64_t /*pos*/, char* buf, size_t max) {
    auto* h = static_cast<StreamHandle*>(cls);
    StreamState* st = h->state.get();
    std::unique_lock<std::mutex> lk(st->mtx);
    st->cv.wait(lk, [&]{ return !st->chunks.empty() || st->closed; });
    if (st->chunks.empty()) return MHD_CONTENT_READER_END_OF_STREAM;

    std::string& front = st->chunks.front();
    ssize_t n = std::min<ssize_t>((ssize_t)front.size(), (ssize_t)max);
    memcpy(buf, front.data(), (size_t)n);
    if (n == (ssize_t)front.size()) st->chunks.pop_front();
    else front.erase(0, (size_t)n);
    return n;
}

// MHD 释放 response 时调用
static void stream_free_cb(void* cls) {
    auto* h = static_cast<StreamHandle*>(cls);
    if (h->state) h->state->close();
    delete h;
}
 
/* ---------- 值类型 ---------- */
enum ValType {
    VAL_INT,
    VAL_INT64, 
    VAL_FLOAT,
    VAL_STRING,
    VAL_ARRAY,
    VAL_OBJECT,
    VAL_NULL,
    VAL_FUNCTION,
    VAL_FUTURE,
    VAL_POINTER,
};
 
struct Value {
    ValType type;
    size_t str_len;
    union {
        char* str_val;
        struct {
            struct Value* elements;
            long long length;
        } arr_val;
        struct {
            struct ObjectEntry* entries; // 键值对数组
            int count;
        } obj_val;
        struct {
            char* name;           // 函数名（可有可无）
            char** params;
            int param_count;
            int compiled_idx;
            ASTNode* body;
            Scope* closure_scope;
            bool is_memoized;
            bool is_async;
            bool global_scope;
            bool is_rule;
            TypeNode* return_type;
            char* vararg_name;
            TypeNode* vararg_type;
            bool* param_is_const;
            ASTNode** param_defaults;
            TypeNode** param_types;
            bool is_stmt_func;
            char* filename;
        } func_val;
        struct {
            int future_id;   // 用于在 future_map 中查找
        } future_state;
        struct {
            Value* raw_target;                      // 裸指针：指向堆上的 Value 副本
            std::shared_ptr<Value>* smart_target;   // 智能指针：指向堆上的 shared_ptr<Value>
            TypeNode* elem_type;                    // 元素类型（可选，用于类型注解）
            bool freed;
        } ptr_val;
        mpz_t* big_int;
        int64_t int64_val;
        mpf_t* mpf_val;
        ASTNode* ast_ptr;
    };
};

// 前向声明（用于解决循环引用）
static Scope* copy_scope_chain(Scope* scope, std::unordered_map<Scope*, Scope*>& visited);
static Value copy_value_with_visited(Value src, std::unordered_map<Scope*, Scope*>& visited);
Value make_function(const char* name, char** params, int param_count, ASTNode* body,
    Scope* closure, bool is_memoized, bool is_async, bool global_scope,
    bool is_rule, TypeNode* ret_type, char* vararg_name,
    bool* param_is_const, ASTNode** param_defaults,
    TypeNode** param_types = nullptr, TypeNode* vararg_type = nullptr, bool is_stmt_func = false);
thread_local char* current_func_name = nullptr;
thread_local const Value* current_func_value = nullptr;
thread_local Value* current_constructed_obj = nullptr;
thread_local Value* g_current_return_slot = nullptr;
static Value method_alsText(Value obj, ASTNode** args, int arg_count);
static ScopedTypeMap<std::pair<std::string, int>> variant_table;
static std::string resolve_module_path(const std::string& module_name,
    bool has_quote,
    const std::string& base_dir);
static std::string expand_imports(const std::string& source,
                                  const std::string& base_dir,
                                  std::set<fs::path>& visited,
                                  std::unordered_map<std::string, std::vector<std::string>>& alias_map,
                                  const std::string& current_file = "",
                                  const std::string& top_level_file = "");

static std::unordered_map<std::string, Value> static_props;
static std::mutex static_props_mutex;
static std::unordered_map<std::string, ASTNode*> static_lazy_init;
static bool try_get_static_property(const std::string& key, Value& out);
static MethodDef* find_static_method(const std::string& class_name,
    const std::string& method_name,
    std::string* found_class = nullptr);

 // 键值对结构
 struct ObjectEntry {
    char* key;
    Value value;
 };

 struct MatchBranch {
    ASTNode* pattern;
    ASTNode* guard;
    ASTNode* body;
 };

 // 结构体字段
struct StructField {
    char* name;
    TypeNode* type;
};

// 联合变体（可匿名参数或具名参数）
struct UnionVariant {
    char* name;
    TypeNode** param_types;   // 匿名参数类型列表（长度 param_count）
    int param_count;
    StructField* named_fields; // 具名参数字段列表（长度 field_count）
    int field_count;
    // 若 param_count > 0，则 field_count 必须为 0；反之亦然
};
 
 // 辅助：深拷贝 Value
 Value copy_value(Value src);
 Value call_function_value(const Value& func, Value* args, int arg_count,
    ASTNode* call_node = nullptr, bool move_args = false);
 Value eval_expr(ASTNode* node);
 Value make_int(long long v);
 Value make_string(const char* s);
 Value make_array(Value* elems, int len);
 Value make_null(void);
 Value make_pointer_raw(Value v);
 Value make_pointer_smart(Value v);
 Value make_object(ObjectEntry* entries, int count);
 Value make_float(double v);
 char* value_to_string(Value v);
 void free_value(Value* v);
 int value_to_bool(Value v);
 TypeNode* parse_type_expr();
 bool type_matches(const TypeNode* a, const TypeNode* b);
 bool check_type(TypeNode* type, Value val);
 long long value_to_ll(const Value& v);
 static std::string value_to_stdstring(const Value& v);

 Value make_object(ObjectEntry* entries, int count) {
    Value val;
    val.type = VAL_OBJECT;
    val.obj_val.count = count;
    val.obj_val.entries = (ObjectEntry*)malloc(count * sizeof(ObjectEntry));
    for (int i = 0; i < count; i++) {
        val.obj_val.entries[i].key = strdup(entries[i].key);
        val.obj_val.entries[i].value = copy_value(entries[i].value);
    }
    return val;
 }

Value make_null() {
    Value v;
    v.type = VAL_NULL;
    return v;
}

Value make_pointer_raw(Value v) {
    Value p;
    p.type = VAL_POINTER;
    Value* target = new Value();
    target->type = VAL_NULL;
    Value tmp = copy_value(v);
    *target = tmp;                          // 字节复制（Value 是 POD）
    p.ptr_val.raw_target = target;
    p.ptr_val.smart_target = nullptr;
    p.ptr_val.elem_type = nullptr;
    p.ptr_val.freed = false;
    return p;
}

Value make_pointer_smart(Value v) {
    Value p;
    p.type = VAL_POINTER;
    Value* heap_v = new Value();
    heap_v->type = VAL_NULL;
    Value tmp = copy_value(v);
    *heap_v = tmp;
    p.ptr_val.smart_target = new std::shared_ptr<Value>(
        heap_v,
        [](Value* ptr) {
            if (ptr) { free_value(ptr); delete ptr; }
        });
    p.ptr_val.raw_target = nullptr;
    p.ptr_val.elem_type = nullptr;
    p.ptr_val.freed = false;
    return p;
}

Value make_string(const char* s) {
    Value v;
    v.type = VAL_STRING;
    if (s) {
        v.str_len = strlen(s);
        v.str_val = (char*)malloc(v.str_len + 1);
        memcpy(v.str_val, s, v.str_len + 1);
    } else {
        v.str_len = 0;
        v.str_val = strdup("");
    }
    return v;
}

Value make_string_len(const char* s, size_t len) {
    Value v;
    v.type = VAL_STRING;
    v.str_len = len;
    v.str_val = (char*)malloc(len + 1);
    if (s && len > 0) memcpy(v.str_val, s, len);
    v.str_val[len] = '\0';
    return v;
}

static char* dup_object_key(const Value& v) {
    if (v.type == VAL_STRING) {
        if (memchr(v.str_val, '\0', v.str_len) != nullptr) {
            kr_error("对象键不能包含内嵌的空字节");
        }
        char* k = (char*)malloc(v.str_len + 1);
        memcpy(k, v.str_val, v.str_len);
        k[v.str_len] = '\0';
        return k;
    }
    char* s = value_to_string(v);
    char* result = strdup(s);
    free(s);
    return result;
}

Value make_array(Value* elems, int len) {
    Value v;
    v.type = VAL_ARRAY;
    v.arr_val.length = len;
    v.arr_val.elements = (Value*)malloc(len * sizeof(Value));
    for (int i = 0; i < len; i++) {
        v.arr_val.elements[i] = copy_value(elems[i]);
    }
    return v;
}

// 检查是否可以用 int64 表示
static inline bool fits_int64(const mpz_t z) {
    // thread_local 缓存 INT64_MIN / INT64_MAX，避免每次重新解析字符串并分配
    static thread_local mpz_t tls_min, tls_max;
    static thread_local bool tls_inited = false;
    if (!tls_inited) {
        mpz_init_set_str(tls_min, "-9223372036854775808", 10);
        mpz_init_set_str(tls_max, "9223372036854775807", 10);
        tls_inited = true;
    }
    return mpz_cmp(z, tls_min) >= 0 && mpz_cmp(z, tls_max) <= 0;
}

int64_t mpz_get_int64(const mpz_t z) {
    if (mpz_sgn(z) == 0) return 0;
    // 快速路径：64 位 long 平台上（Linux/macOS），fits_slong 覆盖整个 int64 范围
    if (mpz_fits_slong_p(z)) return (int64_t)mpz_get_si(z);
    // 慢速路径（32 位 long 平台，如 32 位 Windows）
    if (mpz_sgn(z) > 0) {
        uint64_t u = 0;
        size_t c = 1;
        mpz_export(&u, &c, -1, 8, 0, 0, z);
        return (int64_t)u;
    } else {
        mpz_t abs;
        mpz_init(abs);
        mpz_abs(abs, z);
        uint64_t u = 0;
        size_t c = 1;
        mpz_export(&u, &c, -1, 8, 0, 0, abs);
        mpz_clear(abs);
        return -(int64_t)u;
    }
}

// 创建原生整数 Value
Value make_int64(int64_t v) {
    Value val;
    val.type = VAL_INT64;
    val.int64_val = v;
    return val;
}

// 创建 GMP 整数（保留原函数）
Value make_int(const mpz_t z) {
    Value val;
    val.type = VAL_INT;
    val.big_int = (mpz_t*)malloc(sizeof(mpz_t));
    mpz_init_set(*val.big_int, z);
    return val;
}

// 自动选择表示方式的 make_int（重载或新函数）
Value make_int_auto(const mpz_t z) {
    if (fits_int64(z)) {
        return make_int64(mpz_get_int64(z));
    } else {
        return make_int(z);
    }
}

// 从 long long 创建
Value make_int_auto_ll(long long v) {
    // 检查是否在 int64 范围内（通常 long long 就是 int64）
    // 但为了安全，可以用 __int128 判断溢出
    if (v >= INT64_MIN && v <= INT64_MAX) {
        return make_int64((int64_t)v);
    } else {
        mpz_t tmp;
        mpz_init_set_si(tmp, v);
        Value res = make_int(tmp);
        mpz_clear(tmp);
        return res;
    }
}

// 检查是否派生类
static bool is_subclass(const std::string& derived, const std::string& base) {
    std::string cur = derived;
    while (!cur.empty()) {
        if (cur == base) return true;
        auto it = class_table.find(cur);
        if (it == class_table.end()) break;
        cur = it->second.parent;
    }
    return false;
}
 /* ========== 递归深度 & 循环迭代限制 ========== */
 static const int MAX_RECURSION_DEPTH = 15000;
 thread_local int eval_depth = 0;
 thread_local int exec_depth = 0;
 thread_local bool return_caught = false;
 thread_local Value return_value   = {VAL_NULL, 0, {0}};
 thread_local bool break_caught = false;
 thread_local bool continue_caught = false;
 thread_local int  break_levels = 1;
 thread_local int  continue_levels = 1;
 thread_local bool exception_raised = false;
 thread_local Value exception_value = {VAL_NULL, 0, {0}};
 thread_local int in_loop = 0;
 thread_local int in_catch_depth = 0;
 
 static const int MAX_LOOP_ITERATIONS = 100000000; // 100 M

 thread_local int g_type_check_depth = 0;
 const int MAX_TYPE_DEPTH = 10000000;
 
 struct TypeCheckDepthGuard {
     TypeCheckDepthGuard() {
         if (++g_type_check_depth > MAX_TYPE_DEPTH) {
             kr_error("类型检查递归深度超过限制（可能存在循环类型别名）");
         }
     }
     ~TypeCheckDepthGuard() {
         --g_type_check_depth;
     }
 };

// ---- 控制标志栈（用于嵌套调用隔离） ----
struct ControlFlags {
    bool return_caught;
    bool break_caught;
    bool continue_caught;
    bool exception_raised;
    Value return_value;
    Value exception_value;
};

thread_local std::vector<ControlFlags> flag_stack;

static void save_flags() {
    ControlFlags f;
    f.return_caught = return_caught;
    f.break_caught = break_caught;
    f.continue_caught = continue_caught;
    f.exception_raised = exception_raised;
    f.return_value = copy_value(return_value);
    f.exception_value = copy_value(exception_value);
    flag_stack.push_back(f);
}

static void restore_flags() {
    if (flag_stack.empty()) return;
    ControlFlags f = flag_stack.back();
    flag_stack.pop_back();
    // 恢复标志
    return_caught = f.return_caught;
    break_caught = f.break_caught;
    continue_caught = f.continue_caught;
    exception_raised = f.exception_raised;
    // 释放当前全局值
    free_value(&return_value);
    free_value(&exception_value);
    // 复制保存的值
    return_value = copy_value(f.return_value);
    exception_value = copy_value(f.exception_value);
    // 释放栈中副本
    free_value(&f.return_value);
    free_value(&f.exception_value);
}

 thread_local Token* tokens = NULL;
 thread_local int token_count = 0;
 thread_local int tok_pos = 0;
 thread_local char* source_code = NULL;
 thread_local const char* current_filename = NULL;
 
 // parser 阶段的 umf 名字栈（用于 art / aufz / klass 等在解析期注册类型时生成限定名）
 thread_local std::vector<std::string> g_umf_parse_stack;
 
 // 与运行时 type_key() 使用同一套拼接规则
 static std::string type_key_parse(const std::string& bare) {
     if (g_umf_parse_stack.empty()) return bare;
     std::string k;
     for (auto& u : g_umf_parse_stack) { k += u; k += "::"; }
     return k + bare;
 }

 std::mutex functions_mutex;
 std::mutex class_table_mutex;
 std::mutex type_aliases_mutex;
 std::mutex key_bind_map_mutex;
 // ---- 已标记“called=true”的函数名缓存，避免每次调用都扫描 functions[] ----
 static std::unordered_set<std::string> g_marked_funcs_called;
 
 [[noreturn]] void error_at(int line, int col, const char* format, ...) {
    g_last_error_line = line;
    g_last_error_col = col;
    va_list args;
    va_start(args, format);
    char buffer[1024];
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    if (line <= 0 || col <= 0) {
        kr_error("%s", buffer);  // 让 kr_error 自动获取位置（已支持映射）
    } else {
        const char* filename = nullptr;
        if (line != 0 && col != 0) {
            filename = find_filename_by_line_col(line, col);
            if (!filename) {
                if (g_last_error_filename && g_last_error_filename[0] != '\0')
                    filename = g_last_error_filename;
                else
                    filename = current_filename;
            }
        } else {
            if (!g_call_stack.empty()) {
                const CallFrame& frame = g_call_stack.back();
                line = frame.line;
                col = frame.col;
                filename = frame.filename;
                if (filename && strcmp(filename, "-") == 0) {
                    filename = current_filename;
                }
            } else if (line == 0) {
                if (tok_pos < token_count) {
                    line = tokens[tok_pos].line;
                    col = tokens[tok_pos].col;
                } else {
                    line = g_last_token_line;
                    col = g_last_token_col;
                }
                if (line == 0) {
                    line = g_stmt_start_line;
                    col = g_stmt_start_col;
                }
            }
            if (line == 0) { line = 1; col = 1; }
    
            if (!g_custom_source_context.empty()) {
                filename = current_filename;
            } else {
                if (line > 0 && col > 0) {
                    filename = find_filename_by_line_col(line, col);
                }
                if (!filename && line > 0) {
                    auto it = g_line_to_file.find(line);
                    if (it != g_line_to_file.end()) filename = it->second.c_str();
                    else {
                        auto it2 = g_line_to_file.upper_bound(line);
                        if (it2 != g_line_to_file.begin()) { --it2; filename = it2->second.c_str(); }
                    }
                }
                if (!filename) filename = current_filename;
            }
            if (!filename) filename = "-";
        }
    
        // ---- 优先使用调用栈中的文件名（如果有效），但不改变行列 ----
        if (g_last_error_filename && g_last_error_filename[0] != '\0' && strcmp(g_last_error_filename, "-") != 0) {
            filename = g_last_error_filename;
        } else if (!g_call_stack.empty()) {
            const CallFrame& frame = g_call_stack.back();
            if (frame.filename && strcmp(frame.filename, "-") != 0) {
                filename = frame.filename;
            }
        }
        
        g_last_error_line = line;
        g_last_error_col = col;
        static thread_local std::string filename_storage;
        filename_storage = filename;
        g_last_error_filename = filename_storage.c_str();
        
        char full_msg[2048];
        snprintf(full_msg, sizeof(full_msg), "\033[31m[Fehl]\033[0m \033[34m%s\033[0m \033[96m%s:%d:%d:\033[0m %s",
                g_current_operating_position.c_str(),
                filename ? filename : "-",
                line, col, buffer);
        throw KRError(std::string(full_msg));
    }
 }
 
 void free_tokens() {
    for (int i = 0; i < token_count; i++) {
        free(tokens[i].value);
        if (tokens[i].flags) free(tokens[i].flags);
        if (tokens[i].filename) free(tokens[i].filename);
    }
    free(tokens);
    tokens = NULL;
    token_count = 0;
    tok_pos = 0;
 }

 void key_listener_thread_func(const std::string& key) {
    while (true) {
        // 检查是否已按下
        if (g_key_pressed[key].load()) {
            // 已被按下，但线程可能还未停止，为避免重复触发，可等待外部停止
            // 这里简单退出线程
            break;
        }
        if (is_key_pressed(key)) {
            g_key_pressed[key] = true;
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
 }

 // 类型表示
 typedef enum {
    TYPE_INT,      // 整数
    TYPE_NUM,      // Zahl – 整数或浮点数
    TYPE_FLOAT,    // Kommazahl
    TYPE_STRING,   // Text
    TYPE_BOOL,     // bool
    TYPE_CHAR,     // einz – 单字符
    TYPE_ARRAY,    // [T]
    TYPE_OBJECT,   // { key: T, ... }
    TYPE_ALIAS,    // 用户定义别名
    TYPE_FUNCTION, // (params) -> T
    TYPE_ANY,      // 任意类型
    TYPE_OPTIONAL, // 可选类型：T?
    TYPE_STRING_UNION,
    TYPE_STRUCT,    // 结构体
    TYPE_UNION,     // 联合
    TYPE_POINTER,
} TypeKind;

enum RoundingMode {
    ROUND_HALF_UP,  // 四舍五入（默认）
    ROUND_CEIL,     // 向上取整
    ROUND_FLOOR     // 向下取整
};

struct TypeNode {
    TypeKind kind;
    union {
        struct { TypeNode* elem_type; } array_type;
        struct { char** keys; TypeNode** types; int count; } object_type;
        struct { char* name; } alias_type;
        struct { TypeNode** param_types; int param_count; TypeNode* ret_type; } func_type;
        struct { TypeNode* inner_type; } optional_type;
        struct { std::unordered_set<std::string>* string_union; } union_type;
        struct { StructField* fields; int field_count; } struct_type;
        struct { UnionVariant* variants; int variant_count; } variant_type;
        struct {
            TypeNode* elem_type;
            bool      smart;
        } ptr_type;
    };
};

// 将 TypeNode 转换为可读字符串
std::string type_to_string(const TypeNode* type) {
    if (!type) return "unbekan";
    switch (type->kind) {
        case TYPE_INT:      return "Ganzzahl(gzl)";
        case TYPE_FLOAT:    return "Kommazahl(kzl)";
        case TYPE_STRING:   return "Zeichenkette(zkt)";
        case TYPE_BOOL:     return "Boolescher(bool)";
        case TYPE_CHAR:     return "Zeichen(einz)";
        case TYPE_NUM:      return "Zahl(zahl)";
        case TYPE_ANY:      return "Beliebig(any)";
        case TYPE_ARRAY: {
            std::string elem = type_to_string(type->array_type.elem_type);
            return "[" + elem + "]";
        }
        case TYPE_OBJECT: {
            std::string s = "{";
            for (int i = 0; i < type->object_type.count; ++i) {
                if (i) s += ", ";
                s += type->object_type.keys[i];
                s += ": ";
                s += type_to_string(type->object_type.types[i]);
            }
            s += "}";
            return s;
        }
        case TYPE_ALIAS:
            return "Typalias '" + std::string(type->alias_type.name) + "'";
        case TYPE_FUNCTION: {
            std::string s = "fkt(";
            for (int i = 0; i < type->func_type.param_count; ++i) {
                if (i) s += ", ";
                s += type_to_string(type->func_type.param_types[i]);
            }
            s += ")";
            if (type->func_type.ret_type) {
                s += ": " + type_to_string(type->func_type.ret_type);
            }
            return s;
        }
        case TYPE_OPTIONAL: {
            std::string inner = type_to_string(type->optional_type.inner_type);
            return inner + "?";
        }
        case TYPE_STRING_UNION: {
            std::string s;
            for (const auto& str : *type->union_type.string_union) {
                if (!s.empty()) s += " | ";
                s += "\"" + str + "\"";
            }
            return s;
        }
        case TYPE_POINTER: {
            std::string elem = type_to_string(type->ptr_type.elem_type);
            return (type->ptr_type.smart ? "Schlauer Zeiger<" : "Zeiger<") + elem + ">";
        }
        default: return "unbekan Typ";
    }
}

// 把 TypeNode* 转成与 value_type_to_string 一致风格的短类型名
// 例如：gzl、kzl、zkt、[gzl]、{x: gzl}、fkt(gzl) -> gzl
static std::string type_node_to_short(const TypeNode* t) {
    if (!t) return "leer";
    switch (t->kind) {
        case TYPE_INT:    return "gzl";
        case TYPE_FLOAT:  return "kzl";
        case TYPE_STRING: return "zkt";
        case TYPE_BOOL:   return "bool";
        case TYPE_CHAR:   return "einz";
        case TYPE_NUM:    return "zahl";
        case TYPE_ANY:    return "leer";
        case TYPE_ARRAY:
            return "[" + type_node_to_short(t->array_type.elem_type) + "]";
        case TYPE_OBJECT: {
            std::string s = "{";
            for (int i = 0; i < t->object_type.count; ++i) {
                if (i) s += ", ";
                s += t->object_type.keys[i];
                s += ": ";
                s += type_node_to_short(t->object_type.types[i]);
            }
            s += "}";
            return s;
        }
        case TYPE_OPTIONAL:
            return type_node_to_short(t->optional_type.inner_type) + "?";
        case TYPE_ALIAS:
            return t->alias_type.name;   // 别名本身就是短名
        case TYPE_POINTER: {
            std::string elem = type_node_to_short(t->ptr_type.elem_type);
            return (t->ptr_type.smart ? "schlau<" : "zgr<") + elem + ">";
        }
        case TYPE_FUNCTION: {
            std::string s = "fkt(";
            for (int i = 0; i < t->func_type.param_count; ++i) {
                if (i) s += ", ";
                s += type_node_to_short(t->func_type.param_types[i]);
            }
            s += ")";
            if (t->func_type.ret_type)
                s += ": " + type_node_to_short(t->func_type.ret_type);
            return s;
        }
        case TYPE_STRING_UNION: {
            std::string s;
            for (const auto& str : *t->union_type.string_union) {
                if (!s.empty()) s += " | ";
                s += "\"" + str + "\"";
            }
            return s;
        }
        default:
            // 结构体 / 联合体等没有短名，回退到长名
            return type_to_string(t);
    }
}

// 从 Value 获取类型名称（仅类型，不包含值）
std::string value_type_to_string(const Value& v) {
    // 递归深度保护（正常程序不会触发，防止手工构造的循环引用爆栈）
    static thread_local int depth = 0;
    if (depth > 10000) return "...";
    ++depth;

    std::string result;
    switch (v.type) {
        case VAL_INT64:
        case VAL_INT:      result = "gzl"; break;
        case VAL_FLOAT:    result = "kzl"; break;
        case VAL_STRING:   result = "zkt"; break;

        // ---------------- 数组：[T] ----------------
        case VAL_ARRAY: {
            if (v.arr_val.length <= 0) {
                result = "[]";
                break;
            }
            std::string first = value_type_to_string(v.arr_val.elements[0]);
            bool uniform = true;
            for (int i = 1; i < v.arr_val.length; ++i) {
                if (value_type_to_string(v.arr_val.elements[i]) != first) {
                    uniform = false;
                    break;
                }
            }
            result = uniform ? ("[" + first + "]") : "[leer]";
            break;
        }

        // ---------------- 对象：{key: T, ...} ----------------
        case VAL_OBJECT: {
            // 1) 类实例：优先识别 __klass
            bool handled = false;
            for (int i = 0; i < v.obj_val.count; ++i) {
                if (strcmp(v.obj_val.entries[i].key, "__klass") == 0 &&
                    v.obj_val.entries[i].value.type == VAL_STRING) {
                    const char* s = v.obj_val.entries[i].value.str_val;
                    result = "objekt -> " + std::string(s ? s : "");
                    handled = true;
                    break;
                }
            }
            if (handled) break;

            // 2) 枚举变体：识别 __tag
            for (int i = 0; i < v.obj_val.count; ++i) {
                if (strcmp(v.obj_val.entries[i].key, "__tag") == 0 &&
                    v.obj_val.entries[i].value.type == VAL_STRING) {
                    result = "aufz -> " + std::string(v.obj_val.entries[i].value.str_val);
                    handled = true;
                    break;
                }
            }
            if (handled) break;

            // 3) 普通对象：{key: type, ...}（跳过 __ 开头的内部键）
            std::string s = "{";
            bool first = true;
            for (int i = 0; i < v.obj_val.count; ++i) {
                const char* k = v.obj_val.entries[i].key;
                if (!k) continue;
                if (k[0] == '_' && k[1] == '_') continue;   // 跳过内部键
                if (!first) s += ", ";
                first = false;
                s += k;
                s += ": ";
                s += value_type_to_string(v.obj_val.entries[i].value);
            }
            s += "}";
            result = s;
            break;
        }

        case VAL_FUNCTION: {
            std::string s = "fkt(";
            for (int i = 0; i < v.func_val.param_count; ++i) {
                if (i) s += ", ";
                if (v.func_val.param_types && v.func_val.param_types[i]) {
                    s += type_node_to_short(v.func_val.param_types[i]);
                } else {
                    s += "leer";
                }
            }
            if (v.func_val.vararg_name) {
                if (v.func_val.param_count > 0) s += ", ";
                s += "...";
                if (v.func_val.vararg_type) {
                    s += ":" + type_node_to_short(v.func_val.vararg_type);
                }
            }
            s += ")";
            if (v.func_val.return_type) {
                s += ": " + type_node_to_short(v.func_val.return_type);
            }
            result = s;
            break;
        }
        case VAL_NULL:     result = "null"; break;
        case VAL_FUTURE:   result = "zukunft"; break;
        case VAL_POINTER:  result = v.ptr_val.smart_target ? "schlau" : "zgr"; break;
        default:           result = "unbekan"; break;
    }

    --depth;
    return result;
}

// 基本类型字符串：只返回顶层类型名，不展开参数 / 字段 / 元素类型
static std::string basic_value_type_to_string(const Value& v) {
    switch (v.type) {
        case VAL_INT:
        case VAL_INT64:    return "gzl";
        case VAL_FLOAT:    return "kzl";
        case VAL_STRING:   return "zkt";
        case VAL_ARRAY:    return "array";
        case VAL_OBJECT:   return "objekt";
        case VAL_FUNCTION: return "funktion";
        case VAL_NULL:     return "null";
        case VAL_FUTURE:   return "zukunft";
        case VAL_POINTER:  return v.ptr_val.smart_target ? "schlau" : "zgr";
        default:           return "unbekan";
    }
}

static size_t utf8_length(const std::string& s) {
    size_t count = 0;
    for (size_t i = 0; i < s.size(); ) {
        unsigned char c = s[i];
        if (c < 0x80) i += 1;
        else if ((c & 0xE0) == 0xC0) i += 2;
        else if ((c & 0xF0) == 0xE0) i += 3;
        else if ((c & 0xF8) == 0xF0) i += 4;
        else i += 1; // 无效字节，跳过
        count++;
    }
    return count;
}

static std::string utf8_char_at(const std::string& s, size_t pos) {
    size_t count = 0;
    size_t start = 0, end = 0;
    for (size_t i = 0; i < s.size(); ) {
        unsigned char c = s[i];
        size_t len;
        if (c < 0x80) len = 1;
        else if ((c & 0xE0) == 0xC0) len = 2;
        else if ((c & 0xF0) == 0xE0) len = 3;
        else if ((c & 0xF8) == 0xF0) len = 4;
        else len = 1;
        if (count == pos) {
            start = i;
            end = i + len;
            break;
        }
        i += len;
        count++;
    }
    if (end > s.size()) end = s.size();
    return s.substr(start, end - start);
}

// 自定义字符判断，支持非ASCII（如 ä, ö, ü 等）
static bool is_ident_char(char c) {
    return (isalnum((unsigned char)c) || c == '_' || (unsigned char)c > 127);
}
static bool is_ident_start(char c) {
    return (isalpha((unsigned char)c) || c == '_' || (unsigned char)c > 127);
}

// 自定义四舍五入函数（兼容旧版 GMP，若系统未提供 mpf_round）
static inline void mpf_round(mpf_t rop, const mpf_t op) {
    mpf_t tmp, half;
    mpf_init(tmp);
    mpf_init_set_d(half, 0.5);
    if (mpf_sgn(op) >= 0) {
        mpf_add(tmp, op, half);
        mpf_floor(rop, tmp);
    } else {
        mpf_sub(tmp, op, half);
        mpf_ceil(rop, tmp);
    }
    mpf_clear(tmp);
    mpf_clear(half);
}

// 宏定义表（仅记录是否定义，不存储替换文本）
static std::unordered_map<std::string, bool> g_macros;

// 条件编译栈，记录每层当前是否应跳过行（true = 跳过）
static std::vector<bool> g_cond_stack;

static std::unordered_map<std::string, PreprocessMacroDef> g_macro_defs;
 
bool is_keyword(const char* s) {
    return (strcmp(s, "der") == 0 || strcmp(s, "das") == 0 || strcmp(s, "nutz") == 0 ||
            strcmp(s, "ist") == 0 || strcmp(s, "zeig") == 0 || strcmp(s, "schr") == 0 ||
            strcmp(s, "fa") == 0 || strcmp(s, "snfa") == 0 ||
            strcmp(s, "sonst") == 0 || strcmp(s, "indes") == 0 || strcmp(s, "tu") == 0 ||
            strcmp(s, "fkt") == 0 || strcmp(s, "makro") == 0 || strcmp(s, "lies") == 0 ||
            strcmp(s, "gib") == 0 || strcmp(s, "art") == 0 ||
            strcmp(s, "null") == 0 || strcmp(s, "wahr") == 0 || strcmp(s, "fals") == 0 ||
            strcmp(s, "für") == 0 || strcmp(s, "bruch") == 0 ||
            strcmp(s, "ver") == 0 || strcmp(s, "den") == 0 ||
            strcmp(s, "die") == 0 || strcmp(s, "dem") == 0 ||
            strcmp(s, "jedes") == 0 || strcmp(s, "in") == 0 ||
            strcmp(s, "faul") == 0 || strcmp(s, "dies") == 0 ||
            strcmp(s, "imp") == 0 || strcmp(s, "as") == 0 ||
            strcmp(s, "weiter") == 0 ||
            strcmp(s, "aufz") == 0 || strcmp(s, "als") == 0 ||
            strcmp(s, "warte") == 0 || strcmp(s, "kernregel") == 0 ||
            strcmp(s, "global") == 0 || strcmp(s, "des") == 0 ||
            strcmp(s, "bind") == 0 || strcmp(s, "klass") == 0 || strcmp(s, "erbt") == 0 || strcmp(s, "öffent") == 0 || strcmp(s, "privat") == 0 || strcmp(s, "schutz") == 0 ||
            strcmp(s, "konstr") == 0 || strcmp(s, "methode") == 0 ||
            strcmp(s, "neu") == 0 || strcmp(s, "ober") == 0|| strcmp(s, "bei") == 0 || strcmp(s, "sch") == 0 ||
            strcmp(s, "stati") == 0 || strcmp(s, "sicher") == 0 || strcmp(s, "NICH") == 0 || strcmp(s, "nich") == 0 ||
            strcmp(s, "dann") == 0);
 }

 static std::string expand_macros(const std::string& text,
    const std::unordered_map<size_t, int>& offset_to_line) {
    const auto& macro_defs = g_macro_defs;
    const int MAX_DEPTH = 16;
    std::string result = text;
    const char* fname = current_filename ? current_filename : "<cmdline>";

    for (int depth = 0; depth < MAX_DEPTH; ++depth) {
        std::string new_result;
        new_result.reserve(result.size() + 64);
        size_t pos = 0;
        bool replaced = false;

        // ---- 状态机：字符串 / 字符 / 反引号 / 注释 ----
        bool in_string   = false;
        bool in_char     = false;
        bool in_backtick = false;
        bool escape      = false;
        bool in_line_comment  = false;
        bool in_block_comment = false;

        while (pos < result.size()) {
            char c = result[pos];

            // ---------- 行注释 ----------
            if (in_line_comment) {
                new_result += c;
                pos++;
                if (c == '\n') in_line_comment = false;
                continue;
            }

            // ---------- 块注释 /| ... |/ ----------
            if (in_block_comment) {
                if (c == '|' && pos + 1 < result.size() && result[pos + 1] == '/') {
                    new_result += "|/";
                    pos += 2;
                    in_block_comment = false;
                } else {
                    new_result += c;
                    pos++;
                }
                continue;
            }

            // ---------- 字符串 / 字符 / 反引号内部 ----------
            if (in_string || in_char || in_backtick) {
                new_result += c;
                pos++;
                if (escape) {
                    escape = false;
                } else if (c == '\\') {
                    escape = true;
                } else if (in_string && c == '"') {
                    in_string = false;
                } else if (in_char && c == '\'') {
                    in_char = false;
                } else if (in_backtick && c == '`') {
                    in_backtick = false;
                }
                continue;
            }

            // ---------- 检测注释开始（仅在字符串外） ----------
            if (c == '/' && pos + 1 < result.size()) {
                if (result[pos + 1] == '/') {
                    new_result += "//";
                    pos += 2;
                    in_line_comment = true;
                    continue;
                }
                if (result[pos + 1] == '|') {
                    new_result += "/|";
                    pos += 2;
                    in_block_comment = true;
                    continue;
                }
            }

            // ---------- 检测字符串开始 ----------
            if (c == '"') { new_result += c; pos++; in_string = true; continue; }
            if (c == '\'') { new_result += c; pos++; in_char = true; continue; }
            if (c == '`') { new_result += c; pos++; in_backtick = true; continue; }

            // ---------- 标识符（允许 UTF-8 起始字节） ----------
            if (is_ident_start(c)) {
                size_t start = pos;
                size_t end = pos + 1;
                while (end < result.size() && is_ident_char(result[end])) end++;

                std::string macro_name = result.substr(start, end - start);
                auto it = g_macro_defs.find(macro_name);

                // ================= 带参数的宏 =================
                if (it != macro_defs.end() && end < result.size() && result[end] == '(') {
                    int paren_depth = 0;
                    size_t args_start = end + 1;
                    size_t args_end = args_start;
                    while (args_end < result.size()) {
                        if (result[args_end] == '(') paren_depth++;
                        else if (result[args_end] == ')') {
                            if (paren_depth == 0) break;
                            paren_depth--;
                        }
                        args_end++;
                    }

                    if (args_end < result.size() && result[args_end] == ')') {
                        std::vector<std::string> args;
                        size_t arg_start = args_start;
                        int depth2 = 0;
                        for (size_t i = args_start; i < args_end; ++i) {
                            char ch = result[i];
                            if (ch == '(') depth2++;
                            else if (ch == ')') depth2--;
                            else if (ch == ',' && depth2 == 0) {
                                std::string arg = result.substr(arg_start, i - arg_start);
                                size_t s = arg.find_first_not_of(" \t");
                                size_t e = arg.find_last_not_of(" \t");
                                if (s != std::string::npos && e != std::string::npos)
                                    args.push_back(arg.substr(s, e - s + 1));
                                else
                                    args.push_back("");
                                arg_start = i + 1;
                            }
                        }
                        std::string last_arg = result.substr(arg_start, args_end - arg_start);
                        size_t s = last_arg.find_first_not_of(" \t");
                        size_t e = last_arg.find_last_not_of(" \t");
                        if (s != std::string::npos && e != std::string::npos)
                            args.push_back(last_arg.substr(s, e - s + 1));
                        else
                            args.push_back("");

                        const PreprocessMacroDef& def = it->second;
                        if (args.size() == def.params.size()) {
                            // 参数替换映射
                            std::unordered_map<std::string, std::string> replace_map;
                            for (size_t i = 0; i < def.params.size(); ++i)
                                replace_map[def.params[i]] = args[i];

                            std::string expanded = def.replacement;
                            for (const auto& pair : replace_map) {
                                size_t find_pos = 0;
                                while ((find_pos = expanded.find(pair.first, find_pos)) != std::string::npos) {
                                    bool left_ok  = (find_pos == 0) ||
                                                    (!is_ident_char(expanded[find_pos - 1]));
                                    bool right_ok = (find_pos + pair.first.size() == expanded.size()) ||
                                                    (!is_ident_char(expanded[find_pos + pair.first.size()]));
                                    if (left_ok && right_ok) {
                                        expanded.replace(find_pos, pair.first.size(), pair.second);
                                        find_pos += pair.second.size();
                                    } else {
                                        find_pos += pair.first.size();
                                    }
                                }
                            }

                            // 计算调用宏的原始行号
                            int call_line = 1;
                            auto off_it = offset_to_line.find(start);
                            if (off_it != offset_to_line.end()) {
                                call_line = off_it->second;
                            } else {
                                for (auto it2 = offset_to_line.begin(); it2 != offset_to_line.end(); ++it2) {
                                    if (it2->first <= start) call_line = it2->second;
                                    else break;
                                }
                            }

                            std::string replacement =
                                "#zeile " + std::to_string(call_line) + " \"" + fname + "\";\n";
                            replacement += expanded;
                            replacement += "\n#zeile " + std::to_string(call_line + 1) + " \"" + fname + "\";\n";

                            new_result += replacement;
                            pos = args_end + 1;
                            replaced = true;
                            continue;
                        } else {
                            // 参数个数不匹配：原样输出
                            new_result += result.substr(pos, args_end + 1 - pos);
                            pos = args_end + 1;
                            continue;
                        }
                    }
                    // 若无匹配右括号，则当作普通标识符处理（下面会追加）
                }

                // ================= 无参数宏 =================
                if (it != macro_defs.end() && it->second.params.empty()) {
                    bool left_ok  = (start == 0) || !is_ident_char(result[start - 1]);
                    bool right_ok = (end >= result.size()) || !is_ident_char(result[end]);
                    if (left_ok && right_ok) {
                        new_result += it->second.replacement;
                        pos = end;
                        replaced = true;
                        continue;
                    }
                }

                // 普通标识符（非宏）：原样输出
                new_result += macro_name;
                pos = end;
                continue;
            }

            // ---------- 普通字符 ----------
            new_result += c;
            pos++;
        }

        if (!replaced) break;
        result = std::move(new_result);
    }
    return result;
}

static std::unordered_map<size_t, int> build_offset_to_line(const std::string& text) {
    std::unordered_map<size_t, int> offset_to_line;
    int line = 1;
    // 记录每行起始偏移量（包含行首）
    offset_to_line[0] = 1;
    for (size_t i = 0; i < text.size(); ++i) {
        if (text[i] == '\n') {
            line++;
            offset_to_line[i + 1] = line;   // 下一行起始偏移量
        }
    }
    return offset_to_line;
}

static std::string extract_and_strip_lexikal(const std::string& source,
    std::unordered_map<std::string, std::vector<std::string>>& alias_map);

// 保存当前 Lexikal 别名映射，供错误提示查询
static std::unordered_map<std::string, std::vector<std::string>> g_lexikal_alias_map;

// 反向查找：给定关键字，找到它是由哪个别名替换而来的
static std::string find_alias_for_keyword(const std::string& keyword) {
    for (const auto& kv : g_lexikal_alias_map) {
        for (const auto& part : kv.second) {
            // 按空格分割值，支持多词短语
            std::istringstream iss(part);
            std::string word;
            while (iss >> word) {
                if (word == keyword) {
                    return kv.first;
                }
            }
        }
    }
    return "";
}

// 生成统一的别名提示
static std::string make_keyword_alias_hint(const char* used, const char* correct) {
    std::string used_str = used;
    std::string correct_str = correct;
    std::string used_alias = find_alias_for_keyword(used_str);
    std::string correct_alias = find_alias_for_keyword(correct_str);
    std::string hint;
    if (!used_alias.empty()) {
        hint += "您可能使用了别名 '" + used_alias + "'，它被替换为 '" + used_str + "'。";
    }
    if (!correct_alias.empty()) {
        hint += "在当前位置应使用 '" + correct_alias + "'（即 '" + correct_str + "'）。";
    } else {
        hint += "关键字 '" + correct_str + "' 无别名。";
    }
    return hint;
}

void def_stream(const char* name, const char* val) {
    if (g_macro_defs.find(name) == g_macro_defs.end()) {
        PreprocessMacroDef def;
        def.params = {};
        def.replacement = val;
        def.line = 0;
        def.col = 0;
        g_macro_defs[name] = def;
    }
}

// ---------- 系统检测：自动注册平台/架构/编译器相关的预处理宏 ----------
// 所有系统宏始终被定义，通过值 1 (真) / 0 (假) 来区分是否匹配当前平台。
// #fa / #snfa / #fan 直接比较宏的布尔值：值为 "0" 或未定义视为假。
static void register_system_macros() {
    auto def_macro = [](const char* name, bool value) {
        if (g_macro_defs.find(name) == g_macro_defs.end()) {
            PreprocessMacroDef def;
            def.params = {};
            def.replacement = value ? "1" : "0";
            def.line = 0;
            def.col = 0;
            g_macro_defs[name] = def;
        }
    };

    // ---------- 操作系统 ----------
    bool os_win = false, os_win64 = false;
    bool os_linux = false, os_unix = false, os_android = false;
    bool os_macos = false, os_freebsd = false, os_openbsd = false, os_netbsd = false;

#if defined(_WIN32) || defined(_WIN64)
    os_win = true;
    #ifdef _WIN64
        os_win64 = true;
    #endif
#elif defined(__ANDROID__)
    os_android = true;
    os_linux = true;
    os_unix = true;
#elif defined(__linux__)
    os_linux = true;
    os_unix = true;
#elif defined(__APPLE__)
    os_macos = true;
    os_unix = true;
#elif defined(__FreeBSD__)
    os_freebsd = true;
    os_unix = true;
#elif defined(__OpenBSD__)
    os_openbsd = true;
    os_unix = true;
#elif defined(__NetBSD__)
    os_netbsd = true;
    os_unix = true;
#elif defined(__unix__) || defined(__unix)
    os_unix = true;
#endif

    def_macro("WIN_32",   os_win);
    def_macro("WINDOWS",  os_win);
    def_macro("WIN_64",   os_win64);
    def_macro("LINUX",    os_linux);
    def_macro("UNIX",     os_unix);
    def_macro("ANDROID",  os_android);
    def_macro("MACOS",    os_macos);
    def_macro("FREEBSD",  os_freebsd);
    def_macro("OPENBSD",  os_openbsd);
    def_macro("NETBSD",   os_netbsd);

    // ---------- 体系结构 ----------
    bool arch_x86_64 = false, arch_x86 = false;
    bool arch_arm64 = false, arch_arm = false;
    bool arch_riscv = false, arch_ppc64 = false;
    bool arch_64 = false;

#if defined(__x86_64__) || defined(_M_X64)
    arch_x86_64 = true; arch_64 = true;
#elif defined(__i386__) || defined(_M_IX86)
    arch_x86 = true;
#elif defined(__aarch64__) || defined(_M_ARM64)
    arch_arm64 = true; arch_64 = true;
#elif defined(__arm__) || defined(_M_ARM)
    arch_arm = true;
#elif defined(__riscv)
    arch_riscv = true;
#elif defined(__powerpc64__) || defined(__ppc64__)
    arch_ppc64 = true; arch_64 = true;
#endif

    // Windows 64 位也算作 64 位架构
    if (os_win64) arch_64 = true;

    def_macro("ARCH_X86_64", arch_x86_64);
    def_macro("ARCH_X86",    arch_x86);
    def_macro("ARCH_ARM64",  arch_arm64);
    def_macro("ARCH_ARM",    arch_arm);
    def_macro("ARCH_RISCV",  arch_riscv);
    def_macro("ARCH_PPC64",  arch_ppc64);
    def_macro("ARCH_64",     arch_64);
    def_macro("ARCH_32",     !arch_64);

    // ---------- 位宽 ----------
    def_macro("BITS_64", arch_64);
    def_macro("BITS_32", !arch_64);

    // ---------- 编译器 ----------
    bool comp_clang = false, comp_gcc = false, comp_msvc = false;
#if defined(__clang__)
    comp_clang = true;
#elif defined(__GNUC__)
    comp_gcc = true;
#elif defined(_MSC_VER)
    comp_msvc = true;
#endif

    def_macro("COMPILER_CLANG", comp_clang);
    def_macro("COMPILER_GCC",   comp_gcc);
    def_macro("COMPILER_MSVC",  comp_msvc);

    // ---------- Kernregel 自身标识 ----------
#ifdef __cplusplus
    def_macro("CPLUSPLUS", true);
#else
    def_macro("CPLUSPLUS", false);
#endif
    def_macro("KR", true);

    auto def_version_macro = [](const char* name, int value) {
        if (g_macro_defs.find(name) == g_macro_defs.end()) {
            PreprocessMacroDef def;
            def.params = {};
            def.replacement = std::to_string(value);
            def.line = 0;
            def.col  = 0;
            g_macro_defs[name] = def;
        }
    };
    def_version_macro("KR_MAJOR", MAJOR);
    def_version_macro("KR_MINOR", MINOR);
    def_version_macro("KR_PATCH", PATCH);

    def_stream("stderg",  "0");
    def_stream("stdfehl", "1");
}

struct MacroLexMark {
    std::string name;         // 宏名；branch 标记时为空
    int line = 0;             // 1-based
    int col  = 0;             // 1-based
    bool truth = false;       // definition / condition 使用
    std::string kind;         // "definition" / "condition" / "removed" / "branch"
    int  end_line = 0;        // 仅 branch：结束行
    int  end_col  = 0;        // 仅 branch：结束列
    bool taken    = false;    // 仅 branch：该分支是否被进入
};

static thread_local std::vector<MacroLexMark> g_macro_lex_marks;

// ---------- #fa / #fan 逻辑条件解析器 ----------
// 支持： !expr, expr && expr, expr || expr, ( expr ), 标识符
// 优先级（从低到高）：||  <  &&  <  !  <  ( )
struct MacroCondParser {
    const std::string& src;
    size_t pos;
    const std::unordered_map<std::string, bool>& macros;
    const std::unordered_map<std::string, PreprocessMacroDef>& macro_defs;
    bool ok = true;
    std::string err;

    int base_line;
    int base_col;
    std::vector<MacroLexMark>* marks;

    struct Val {
        bool is_num = false;
        double num = 0;
        std::string str;
        bool truthy() const {
            if (is_num) return num != 0;
            return !str.empty();
        }
    };

    MacroCondParser(const std::string& s,
                    const std::unordered_map<std::string, bool>& m,
                    const std::unordered_map<std::string, PreprocessMacroDef>& d,
                    int line = 0, int col = 1,
                    std::vector<MacroLexMark>* marks_ptr = nullptr)
        : src(s), pos(0), macros(m), macro_defs(d),
          base_line(line), base_col(col), marks(marks_ptr) {}

    void skip_ws() {
        while (pos < src.size() && (unsigned char)src[pos] <= ' ') pos++;
    }

    // 查找宏；返回是否被找到（"发现过这个名字"）
    bool lookup_macro(const std::string& name, bool& is_defined, std::string& rep) const {
        auto it = macro_defs.find(name);
        if (it != macro_defs.end()) {
            rep = it->second.replacement;
            is_defined = (rep != "0");
            return true;
        }
        auto it2 = macros.find(name);
        if (it2 != macros.end()) {
            is_defined = it2->second;
            rep = is_defined ? "1" : "0";
            return true;
        }
        is_defined = false;
        rep = "0";
        return false;
    }

    // 入口：解析完整表达式并检查尾部
    bool parse() {
        skip_ws();
        if (pos >= src.size()) {
            ok = false;
            err = "空条件表达式";
            return false;
        }
        Val r = parse_or();
        skip_ws();
        if (pos < src.size()) {
            ok = false;
            err = std::string("意外的字符 '") + src[pos] + "'";
        }
        return r.truthy();
    }

    // or_expr := and_expr ( '||' and_expr )*
    Val parse_or() {
        Val left = parse_and();
        while (true) {
            skip_ws();
            if (pos + 1 < src.size() &&
                src[pos] == '|' && src[pos + 1] == '|') {
                pos += 2;
                Val right = parse_and();
                Val res;
                res.is_num = true;
                res.num = (left.truthy() || right.truthy()) ? 1 : 0;
                left = res;
            } else break;
        }
        return left;
    }

    // and_expr := cmp_expr ( '&&' cmp_expr )*
    Val parse_and() {
        Val left = parse_cmp();
        while (true) {
            skip_ws();
            if (pos + 1 < src.size() &&
                src[pos] == '&' && src[pos + 1] == '&') {
                pos += 2;
                Val right = parse_cmp();
                Val res;
                res.is_num = true;
                res.num = (left.truthy() && right.truthy()) ? 1 : 0;
                left = res;
            } else break;
        }
        return left;
    }

    // cmp_expr := unary ( cmp_op unary )?
    // cmp_op   := "==" | "!=" | "<=" | ">=" | "<" | ">"
    Val parse_cmp() {
        Val left = parse_unary();
        skip_ws();
        if (pos >= src.size()) return left;

        std::string op;
        char c  = src[pos];
        char c2 = (pos + 1 < src.size()) ? src[pos + 1] : '\0';

        if      (c == '=' && c2 == '=') { op = "=="; pos += 2; }
        else if (c == '!' && c2 == '=') { op = "!="; pos += 2; }
        else if (c == '<' && c2 == '=') { op = "<="; pos += 2; }
        else if (c == '>' && c2 == '=') { op = ">="; pos += 2; }
        else if (c == '<')              { op = "<";  pos += 1; }
        else if (c == '>')              { op = ">";  pos += 1; }
        else return left;

        Val right = parse_unary();
        Val res;
        res.is_num = true;
        res.num = 0;

        if (left.is_num && right.is_num) {
            double a = left.num, b = right.num;
            if      (op == "==") res.num = (a == b) ? 1 : 0;
            else if (op == "!=") res.num = (a != b) ? 1 : 0;
            else if (op == "<")  res.num = (a <  b) ? 1 : 0;
            else if (op == ">")  res.num = (a >  b) ? 1 : 0;
            else if (op == "<=") res.num = (a <= b) ? 1 : 0;
            else if (op == ">=") res.num = (a >= b) ? 1 : 0;
        } else {
            // 至少一方是字符串 → 按字符串比较
            std::string a = left.is_num  ? std::to_string(left.num)  : left.str;
            std::string b = right.is_num ? std::to_string(right.num) : right.str;
            int cmp = a.compare(b);
            if      (op == "==") res.num = (cmp == 0) ? 1 : 0;
            else if (op == "!=") res.num = (cmp != 0) ? 1 : 0;
            else if (op == "<")  res.num = (cmp <  0) ? 1 : 0;
            else if (op == ">")  res.num = (cmp >  0) ? 1 : 0;
            else if (op == "<=") res.num = (cmp <= 0) ? 1 : 0;
            else if (op == ">=") res.num = (cmp >= 0) ? 1 : 0;
        }
        return res;
    }

    // unary := '!' unary | primary
    Val parse_unary() {
        skip_ws();
        // 注意：跳过 '!=' 的情况
        if (pos < src.size() && src[pos] == '!' &&
            (pos + 1 >= src.size() || src[pos + 1] != '=')) {
            pos++;
            Val v = parse_unary();
            Val res;
            res.is_num = true;
            res.num = v.truthy() ? 0 : 1;
            return res;
        }
        return parse_primary();
    }

    // primary := NUMBER | STRING | IDENT | '(' expr ')'
    Val parse_primary() {
        skip_ws();
        if (pos >= src.size()) {
            ok = false;
            err = "表达式意外结束";
            return {};
        }

        // 括号
        if (src[pos] == '(') {
            pos++;
            Val r = parse_or();
            skip_ws();
            if (pos >= src.size() || src[pos] != ')') {
                ok = false;
                err = "缺少 ')'";
                return r;
            }
            pos++;
            return r;
        }

        // 数字字面量
        if (isdigit((unsigned char)src[pos]) ||
            (src[pos] == '-' && pos + 1 < src.size() &&
             isdigit((unsigned char)src[pos + 1]))) {
            size_t start = pos;
            if (src[pos] == '-') pos++;
            while (pos < src.size() && isdigit((unsigned char)src[pos])) pos++;
            if (pos < src.size() && src[pos] == '.') {
                pos++;
                while (pos < src.size() && isdigit((unsigned char)src[pos])) pos++;
            }
            std::string num_str = src.substr(start, pos - start);
            Val v;
            v.is_num = true;
            v.num = strtod(num_str.c_str(), nullptr);
            return v;
        }

        // 字符串字面量（单/双引号）
        if (src[pos] == '"' || src[pos] == '\'') {
            char q = src[pos++];
            std::string s;
            while (pos < src.size() && src[pos] != q) {
                if (src[pos] == '\\' && pos + 1 < src.size()) {
                    pos++;
                    switch (src[pos]) {
                        case 'n':  s += '\n'; break;
                        case 't':  s += '\t'; break;
                        case 'r':  s += '\r'; break;
                        case '\\': s += '\\'; break;
                        case '"':  s += '"';  break;
                        case '\'': s += '\''; break;
                        default:   s += src[pos];
                    }
                    pos++;
                } else {
                    s += src[pos++];
                }
            }
            if (pos >= src.size()) {
                ok = false;
                err = "字符串未终止";
                return {};
            }
            pos++; // 跳过结束引号
            Val v;
            v.is_num = false;
            v.str = s;
            return v;
        }

        // 标识符（宏名）
        if (!is_ident_start(src[pos])) {
            ok = false;
            err = std::string("意外的字符 '") + src[pos] + "'";
            return {};
        }
        size_t start = pos;
        while (pos < src.size() && is_ident_char(src[pos])) pos++;
        std::string name = src.substr(start, pos - start);

        bool defined = false;
        std::string rep;
        lookup_macro(name, defined, rep);

        if (marks) {
            MacroLexMark mark;
            mark.name  = name;
            mark.line  = base_line;
            mark.col   = base_col + (int)start;
            mark.truth = defined;
            mark.kind  = "condition";
            marks->push_back(mark);
        }

        // 尝试把宏的替换文本解析为数字；否则当作字符串
        Val v;
        if (!rep.empty()) {
            char* end = nullptr;
            errno = 0;
            double d = strtod(rep.c_str(), &end);
            if (end != rep.c_str() && *end == '\0') {
                v.is_num = true;
                v.num = d;
                return v;
            }
        }
        v.is_num = false;
        v.str = rep;
        return v;
    }
};

// ---------- 预处理阶段统一错误入口 ----------
// 词法分析之前使用，此时还没有 token 和行映射表，
// 必须由调用方显式提供行号（1-based）；col 可传 0 表示未知，缺省为 1。
[[noreturn]] static void preprocess_error_at(int line, int col, const char* format, ...) {
    va_list args;
    va_start(args, format);
    char buffer[1024];
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    g_last_error_line = (line > 0) ? line : 1;
    g_last_error_col  = (col  > 0) ? col  : 1;

    // 词法分析尚未运行，tokens 为空，find_filename_by_line_col 会返回 nullptr，
    // 因此这里显式给 g_last_error_filename 赋值。
    static thread_local std::string filename_storage;
    filename_storage = (current_filename && current_filename[0] != '\0')
                       ? current_filename
                       : "<preprocess>";
    g_last_error_filename = filename_storage.c_str();
    g_custom_source_context.clear();

    kr_error("%s", buffer);
}

// 计算某字节偏移在字符串中的 (line, col)，均为 1-based。
static void offset_to_line_col(const std::string& s, size_t offset, int& line, int& col) {
    line = 1;
    col  = 1;
    size_t limit = (offset < s.size()) ? offset : s.size();
    for (size_t i = 0; i < limit; ++i) {
        if (s[i] == '\n') { ++line; col = 1; }
        else ++col;
    }
}

// ---------- <--va--> 专用：剔除 NASM 风格的 ; 行注释 ----------
// 注意：不处理字符串内的 ';'，按需求字符串上下文暂不考虑。
// 行注释结束后保留换行符，以维持块内的行计数。
static std::string strip_va_line_comments(const std::string& s) {
    std::string result;
    result.reserve(s.size());
    size_t i = 0;
    while (i < s.size()) {
        if (s[i] == ';') {
            // 跳到行尾（不越过 '\n'，让下一轮循环把换行原样加入）
            while (i < s.size() && s[i] != '\n') ++i;
        } else {
            result += s[i++];
        }
    }
    return result;
}

// ---------- <--vw--> 专用：剔除 // 行注释和 /| ... |/ 块注释 ----------
// 注意：不处理字符串内的注释符，按需求字符串上下文暂不考虑。
// 块注释内的换行被保留，以维持块内的行计数。
static std::string strip_vw_comments(const std::string& s) {
    std::string result;
    result.reserve(s.size());
    size_t i = 0;
    while (i < s.size()) {
        if (s[i] == '/' && i + 1 < s.size()) {
            if (s[i + 1] == '/') {
                // 行注释：跳过 // 及之后到行尾（换行由下一轮循环原样加入）
                i += 2;
                while (i < s.size() && s[i] != '\n') ++i;
                continue;
            }
            if (s[i + 1] == '|') {
                // 块注释：/| ... |/
                i += 2;
                while (i < s.size()) {
                    if (s[i] == '|' && i + 1 < s.size() && s[i + 1] == '/') {
                        i += 2;
                        break;
                    }
                    if (s[i] == '\n') result += '\n';   // 保留换行以维持行计数
                    ++i;
                }
                continue;
            }
        }
        result += s[i++];
    }
    return result;
}

static std::string preprocess_source(const char* source, bool keep_line_numbers,
    std::unordered_map<std::string, std::vector<std::string>>& alias_map) {
    g_macro_lex_marks.clear();
    g_lexikal_alias_map = alias_map;
    std::string code(source);
    std::string final_result;
    std::vector<std::string> removed_aliases;
    
    size_t pos = 0;
    while ((pos = code.find("\r\n", pos)) != std::string::npos) {
        code.replace(pos, 2, "\n");
        pos += 1;
    }
    
    // ---------- 1. 移除所有注释（//, /| |/），但不移除 # ----------
    std::string no_comments;
    bool in_string = false, in_char = false, escape = false;
    bool in_backtick = false;   // 反引号状态
    bool in_line_comment = false, in_block_comment = false;
    size_t i = 0;
    while (i < code.length()) {
        char c = code[i];
        if (!in_line_comment && !in_block_comment) {
            if (!in_string && !in_char && !in_backtick) {
                if (c == '/' && i + 1 < code.length()) {
                    if (code[i + 1] == '/') {
                        in_line_comment = true;
                        i += 2;
                        continue;
                    } else if (code[i + 1] == '|') {
                        in_block_comment = true;
                        i += 2;
                        continue;
                    }
                }
                if (c == '"') {
                    in_string = true;
                    no_comments += c;
                    i++;
                    continue;
                }
                if (c == '\'') {
                    in_char = true;
                    no_comments += c;
                    i++;
                    continue;
                }
                if (c == '`') {
                    in_backtick = true;
                    no_comments += c;
                    i++;
                    continue;
                }
                no_comments += c;
                i++;
            } else if (in_string) {
                if (c == '\\' && !escape) {
                    escape = true;
                    no_comments += c;
                    i++;
                    continue;
                }
                if (c == '"' && !escape) {
                    in_string = false;
                }
                escape = false;
                no_comments += c;
                i++;
            } else if (in_char) {
                if (c == '\\' && !escape) {
                    escape = true;
                    no_comments += c;
                    i++;
                    continue;
                }
                if (c == '\'' && !escape) {
                    in_char = false;
                }
                escape = false;
                no_comments += c;
                i++;
            } else if (in_backtick) {
                if (c == '\\' && !escape) {
                    escape = true;
                    no_comments += c;
                    i++;
                    continue;
                }
                if (c == '`' && !escape) {
                    in_backtick = false;
                }
                escape = false;
                no_comments += c;
                i++;
            }
        } else {
            if (in_line_comment) {
                if (c == '\n') {
                    in_line_comment = false;
                    no_comments += '\n';
                }
                i++;
            } else if (in_block_comment) {
                if (c == '|' && i + 1 < code.length() && code[i + 1] == '/') {
                    in_block_comment = false;
                    i += 2;
                    continue;
                }
                if (c == '\n') {
                    no_comments += '\n';
                }
                i++;
            }
        }
    }
    code = no_comments;
    
    std::unordered_map<size_t, int> offset_to_line = build_offset_to_line(code);
    {
        std::string modified;
        size_t pos = 0;
        while (pos < code.length()) {
            size_t start = code.find("<--vw-->", pos);
            if (start == std::string::npos) {
                modified += code.substr(pos);
                break;
            }
            modified += code.substr(pos, start - pos);
            size_t end = code.find("<---->", start + 8);
            if (end == std::string::npos) {
                int vw_line = 1, vw_col = 1;
                offset_to_line_col(code, start, vw_line, vw_col);
                preprocess_error_at(vw_line, vw_col,
                    "未终止的 <--vw--> 块（缺少 <---->）");
            }
            std::string vw_code = code.substr(start + 8, end - (start + 8));
            vw_code = strip_vw_comments(vw_code);
            
            // 统计原块中的换行符个数（包括标记自身所在的换行）
            size_t newline_count = 0;
            for (size_t i = start; i < end + 6; ++i) {
                if (code[i] == '\n') ++newline_count;
            }
    
            // 转义字符串
            std::string escaped;
            for (char c : vw_code) {
                if (c == '"' || c == '\\') escaped += '\\';
                escaped += c;
            }
            // 替换为函数调用，并补足换行
            int line = offset_to_line[start];
            size_t line_start = code.rfind('\n', start - 1);
            if (line_start == std::string::npos) line_start = 0;
            else line_start += 1;
            int col = start - line_start + 1;
            const char* fname = current_filename ? current_filename : "-";
            modified += "vw(`" + vw_code + "`, " + std::to_string(line) + ", " + std::to_string(col) + ", `" + fname + "`);";

            modified.append(newline_count, '\n');  // 补足原块中的换行数
    
            pos = end + 6; // 跳过 <---->
        }
        code = modified;  // 替换原 code
    }
    // ---------- 处理 <--va--> 块 ----------
    {
        std::string modified;
        size_t pos = 0;
        while (pos < code.length()) {
            size_t start = code.find("<--va-->", pos);
            if (start == std::string::npos) {
                modified += code.substr(pos);
                break;
            }
            modified += code.substr(pos, start - pos);
            size_t end = code.find("<---->", start + 8);
            if (end == std::string::npos) {
                int va_line = 1, va_col = 1;
                offset_to_line_col(code, start, va_line, va_col);
                preprocess_error_at(va_line, va_col,
                    "未终止的 <--va--> 块（缺少 <---->）");
            }
            std::string va_code = code.substr(start + 8, end - (start + 8));
            va_code = strip_va_line_comments(va_code);
            
            // 统计原块中的换行符个数（包括标记自身所在的换行）
            size_t newline_count = 0;
            for (size_t i = start; i < end + 6; ++i) {
                if (code[i] == '\n') ++newline_count;
            }
    
            // 使用反引号原始字符串，保留所有字符（包括换行），无需转义
            modified += "va(`" + va_code + "`);";
            modified.append(newline_count, '\n');  // 补足原块中的换行数
    
            pos = end + 6; // 跳过 <---->
        }
        code = modified;  // 替换原 code
    }

    if (code.find_first_not_of(" \t\n\r{}[]()") == std::string::npos) {
        return code;
    }
    if (alias_map.empty()) {
        final_result = code;
    }

    // ------ 预处理指令处理（宏定义和条件编译） ------
    std::unordered_map<std::string, bool> macros;
    std::vector<bool> cond_stack;            // 当前分支是否跳过
    std::vector<bool> branch_taken_stack;    // 当前条件组是否已有分支被选中(用于 #snfa / #sonst)
    std::vector<int>  cond_line_stack;
    
    struct CondFrame {
        int  branch_line;    // 当前分支开始的行（1-based）
        int  branch_col;     // 当前分支开始的列（1-based）
        bool branch_taken;   // 该分支是否被进入
    };
    std::vector<CondFrame> cond_frames;      // 与 cond_stack / cond_line_stack 平行

    std::string processed_code;
    std::istringstream stream(code);
    std::string line;
    int line_num = 1;
    // ---- 跨行字符串状态：避免字符串内部的 '#' 被误判为预处理指令 ----
    bool in_string_state   = false;   // 双引号字符串内
    bool in_char_state     = false;   // 单引号字符/字符串内
    bool in_backtick_state = false;   // 反引号原始字符串内
    bool escape_state      = false;   // 转义状态
    // 扫描一行，更新字符串状态（不修改行本身）
    auto scan_line_string_state = [&](const std::string& ln) {
        for (size_t i = 0; i < ln.size(); ++i) {
            char c = ln[i];
            if (in_string_state || in_char_state || in_backtick_state) {
                if (escape_state) { escape_state = false; continue; }
                if (c == '\\') { escape_state = true; continue; }
                if (in_string_state   && c == '"')  in_string_state = false;
                else if (in_char_state     && c == '\'') in_char_state = false;
                else if (in_backtick_state && c == '`')  in_backtick_state = false;
            } else {
                if (c == '"')       in_string_state = true;
                else if (c == '\'') in_char_state = true;
                else if (c == '`')  in_backtick_state = true;
            }
        }
        // 处于字符串外时重置 escape —— 行尾的 \ 不属于字符串，不应影响下一行
        if (!in_string_state && !in_char_state && !in_backtick_state) {
            escape_state = false;
        }
    };

    while (std::getline(stream, line)) {
        // 去除行首空白，判断是否为指令
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        size_t pos = line.find_first_not_of(" \t");
        bool line_starts_in_string = in_string_state || in_char_state || in_backtick_state;
        if (!line_starts_in_string && pos != std::string::npos && line[pos] == '#') {
            std::string directive = line.substr(pos + 1);
            size_t start = directive.find_first_not_of(" \t");
            if (start != std::string::npos) {
                directive = directive.substr(start);
                std::istringstream ds(directive);
                std::string cmd;
                ds >> cmd;
                if (cmd == "makro") {
                    std::string rest;
                    std::getline(ds, rest);
                    // 去除前导空格
                    size_t first = rest.find_first_not_of(" \t");
                    if (first != std::string::npos)
                        rest = rest.substr(first);
                    else
                        rest.clear();
                    if (rest.empty()) continue;
                
                    // 提取宏名称：直到遇到 '(' 或空格
                    size_t name_end = rest.find_first_of("( \t");
                    std::string name;
                    std::string params_part;
                    if (name_end == std::string::npos) {
                        // 无参数宏
                        name = rest;
                        rest.clear();
                    } else {
                        name = rest.substr(0, name_end);
                        // 跳过名称后的空白
                        size_t pos = name_end;
                        while (pos < rest.size() && isspace(rest[pos])) pos++;
                        if (pos < rest.size() && rest[pos] == '(') {
                            // 有参数列表，保留从 '(' 开始的剩余部分
                            params_part = rest.substr(pos);
                        } else {
                            // 无参数但有空格，将剩余部分作为替换文本
                            params_part = rest.substr(pos);
                        }
                    }
                
                    if (name.empty()) continue;
                
                    std::vector<std::string> params;
                    std::string replacement;
                
                    // 如果 params_part 以 '(' 开头，解析参数列表
                    if (!params_part.empty() && params_part[0] == '(') {
                        size_t pos = 1; // 跳过 '('
                        // 解析参数名，直到遇到 ')'
                        while (pos < params_part.size() && params_part[pos] != ')') {
                            while (pos < params_part.size() && isspace(params_part[pos])) pos++;
                            if (pos >= params_part.size() || params_part[pos] == ')') break;
                            size_t start = pos;
                            while (pos < params_part.size() && params_part[pos] != ',' && params_part[pos] != ')') pos++;
                            std::string param = params_part.substr(start, pos - start);
                            size_t s = param.find_first_not_of(" \t");
                            size_t e = param.find_last_not_of(" \t");
                            if (s != std::string::npos && e != std::string::npos)
                                param = param.substr(s, e - s + 1);
                            else
                                param.clear();
                            if (!param.empty()) params.push_back(param);
                            if (pos < params_part.size() && params_part[pos] == ',') pos++;
                        }
                        // 跳过 ')' 及其后的空白
                        if (pos < params_part.size() && params_part[pos] == ')') {
                            pos++;
                            while (pos < params_part.size() && isspace(params_part[pos])) pos++;
                            replacement = params_part.substr(pos);
                        } else {
                            // 格式错误，忽略该宏定义
                            continue;
                        }
                    } else {
                        // 无参数宏，剩余部分作为替换文本
                        replacement = params_part;
                    }
                    
                    while (!replacement.empty() && replacement.back() == '\\') {
                        replacement.pop_back(); // 去掉末尾 '\'
                        std::string next_line;
                        if (!std::getline(stream, next_line)) break;
                        if (!next_line.empty() && next_line.back() == '\r')
                            next_line.pop_back();
                        replacement += next_line;
                        line_num++;
                    }
                
                    // 去除替换文本首尾空格
                    size_t s = replacement.find_first_not_of(" \t");
                    size_t e = replacement.find_last_not_of(" \t");
                    if (s != std::string::npos && e != std::string::npos)
                        replacement = replacement.substr(s, e - s + 1);
                    else
                        replacement.clear();
                
                    // 存储宏定义
                    PreprocessMacroDef def;
                    def.params = params;
                    def.replacement = replacement;
                    def.line = line_num;
                    def.col = 1;
                    g_macro_defs[name] = def;
                    macros[name] = true;
                    {
                        size_t name_pos_in_line = line.find(name, pos);
                        int name_col = (name_pos_in_line != std::string::npos)
                                       ? (int)name_pos_in_line + 1
                                       : 1;
                        g_macro_lex_marks.push_back({name, line_num, name_col, true, "definition"});
                    }
                    processed_code += '\n';           // 保持行号
                    line_num++;
                    continue;
                }
                else if (cmd == "fa" || cmd == "fan") {
                    std::string rest;
                    std::getline(ds, rest);
                    size_t first = rest.find_first_not_of(" \t\r");
                    size_t last  = rest.find_last_not_of(" \t\r");
                    if (first == std::string::npos) {
                        preprocess_error_at(line_num, 1,
                            "#%s 需要条件表达式", cmd.c_str());
                    }
                    rest = rest.substr(first, last - first + 1);
                
                    size_t rest_pos_in_line = line.find(rest, pos);
                    int cond_base_col = (rest_pos_in_line != std::string::npos)
                                        ? (int)rest_pos_in_line + 1
                                        : 1;
                
                    bool outer_skip = !cond_stack.empty() && cond_stack.back();
                
                    // 无论外层是否跳过，都解析条件以标记其中的宏引用。
                    // 仅在外层未跳过时才把解析错误视为真正的错误。
                    MacroCondParser parser(rest, macros, g_macro_defs,
                                           line_num, cond_base_col,
                                           &g_macro_lex_marks);
                    bool cond_true = parser.parse();
                    if (!parser.ok && !outer_skip) {
                        preprocess_error_at(line_num, 1,
                            "在 #%s 条件 '%s' 中: %s",
                            cmd.c_str(), rest.c_str(), parser.err.c_str());
                    }
                    if (!parser.ok) cond_true = false;
                
                    if (cmd == "fan") cond_true = !cond_true;
                
                    bool should_skip = outer_skip || !cond_true;
                    cond_stack.push_back(should_skip);
                    branch_taken_stack.push_back(!outer_skip && cond_true);
                    cond_line_stack.push_back(line_num);
                    cond_frames.push_back({ line_num, (int)pos + 1, !outer_skip && cond_true });
                
                    processed_code += '\n';
                    line_num++;
                    continue;
                }
                else if (cmd == "snfa") {
                    if (cond_stack.empty()) {
                        preprocess_error_at(line_num, 1,
                            "#snfa 缺少前面的 #fa / #fan");
                    }
                    std::string rest;
                    std::getline(ds, rest);
                    size_t first = rest.find_first_not_of(" \t\r");
                    size_t last  = rest.find_last_not_of(" \t\r");
                    if (first == std::string::npos) {
                        preprocess_error_at(line_num, 1,
                            "#snfa 需要条件表达式");
                    }
                    rest = rest.substr(first, last - first + 1);
                
                    size_t rest_pos_in_line = line.find(rest, pos);
                    int cond_base_col = (rest_pos_in_line != std::string::npos)
                                        ? (int)rest_pos_in_line + 1
                                        : 1;
                
                    bool outer_skip    = (cond_stack.size() >= 2) && cond_stack[cond_stack.size() - 2];
                    bool already_taken = branch_taken_stack.back();
                
                    // 总是解析以标记宏引用
                    MacroCondParser parser(rest, macros, g_macro_defs,
                                           line_num, cond_base_col,
                                           &g_macro_lex_marks);
                    bool cond_true = parser.parse();
                    if (!parser.ok && !outer_skip) {
                        preprocess_error_at(line_num, 1,
                            "在 #snfa 条件 '%s' 中: %s",
                            rest.c_str(), parser.err.c_str());
                    }
                    if (!parser.ok) cond_true = false;
                
                    // ---- 关闭前一个分支，发出 branch 标记 ----
                    {
                        auto& f = cond_frames.back();
                        MacroLexMark m;
                        m.kind     = "branch";
                        m.line     = f.branch_line;
                        m.col      = f.branch_col;
                        m.end_line = line_num;
                        m.end_col  = (int)pos + 1;
                        m.taken    = f.branch_taken;
                        g_macro_lex_marks.push_back(m);
                    }
                
                    bool should_skip = outer_skip || already_taken || !cond_true;
                    cond_stack.back() = should_skip;
                    if (!outer_skip && !already_taken && cond_true) {
                        branch_taken_stack.back() = true;
                    }
                
                    // ---- 开始新分支 ----
                    auto& f = cond_frames.back();
                    f.branch_line  = line_num;
                    f.branch_col   = (int)pos + 1;
                    f.branch_taken = (!outer_skip && !already_taken && cond_true);
                
                    processed_code += '\n';
                    line_num++;
                    continue;
                }
                else if (cmd == "sonst") {
                    if (cond_stack.empty()) {
                        preprocess_error_at(line_num, 1,
                            "#sonst 缺少前面的 #fa / #fan");
                    }
                    bool outer_skip    = (cond_stack.size() >= 2) && cond_stack[cond_stack.size() - 2];
                    bool already_taken = branch_taken_stack.back();
                    bool should_skip   = outer_skip || already_taken;
                
                    // ---- 关闭前一个分支，发出 branch 标记 ----
                    {
                        auto& f = cond_frames.back();
                        MacroLexMark m;
                        m.kind     = "branch";
                        m.line     = f.branch_line;
                        m.col      = f.branch_col;
                        m.end_line = line_num;
                        m.end_col  = (int)pos + 1;
                        m.taken    = f.branch_taken;
                        g_macro_lex_marks.push_back(m);
                    }
                
                    cond_stack.back() = should_skip;
                    if (!should_skip) branch_taken_stack.back() = true;
                
                    // ---- 开始新分支 ----
                    auto& f = cond_frames.back();
                    f.branch_line  = line_num;
                    f.branch_col   = (int)pos + 1;
                    f.branch_taken = (!should_skip);
                
                    processed_code += '\n';
                    line_num++;
                    continue;
                }
                else if (cmd == "endfa") {
                    if (cond_stack.empty()) {
                        preprocess_error_at(line_num, 1,
                            "#endfa 缺少前面的 #fa / #fan");
                    }
                
                    // ---- 关闭最后一个分支，发出 branch 标记 ----
                    if (!cond_frames.empty()) {
                        auto& f = cond_frames.back();
                        MacroLexMark m;
                        m.kind     = "branch";
                        m.line     = f.branch_line;
                        m.col      = f.branch_col;
                        m.end_line = line_num;
                        m.end_col  = (int)pos + 1;
                        m.taken    = f.branch_taken;
                        g_macro_lex_marks.push_back(m);
                        cond_frames.pop_back();
                    }
                
                    cond_stack.pop_back();
                    branch_taken_stack.pop_back();
                    cond_line_stack.pop_back();
                
                    processed_code += '\n';
                    line_num++;
                    continue;
                }
                // ---------- #r：取消 lexikal 别名或预处理宏定义 ----------
                else if (cmd == "r") {
                    std::string rest;
                    std::getline(ds, rest);
                    // 去除首尾空白
                    size_t first = rest.find_first_not_of(" \t");
                    if (first == std::string::npos) {
                        preprocess_error_at(line_num, 1,
                            "#r 需要一个参数 (\"alias\" 或 makroName)");
                    }
                    size_t last = rest.find_last_not_of(" \t");
                    rest = rest.substr(first, last - first + 1);

                    // 带引号 → 取消 lexikal 别名
                    if (rest.size() >= 2 &&
                        (rest.front() == '"' || rest.front() == '\'') &&
                        rest.back() == rest.front()) {
                        std::string key = rest.substr(1, rest.size() - 2);
                        alias_map.erase(key);
                        removed_aliases.push_back(key);
                    }
                    // 无引号 → 取消预处理宏（同时尝试移除同名别名，保证一致性）
                    else {
                        bool was_macro = (macros.find(rest) != macros.end() ||
                                          g_macro_defs.find(rest) != g_macro_defs.end());
                        if (was_macro) {
                            size_t p = line.find(rest, pos);
                            int c = (p != std::string::npos) ? (int)p + 1 : 1;
                            g_macro_lex_marks.push_back({rest, line_num, c, false, "removed"});
                        }
                        macros.erase(rest);
                        g_macro_defs.erase(rest);
                        alias_map.erase(rest);
                    }
                    processed_code += '\n';
                    line_num++;
                    continue;
                }

                else if (cmd == "zeile") {
                    int final_new_line = -1;
                
                    // (1) 解析行首的 "zeile N"
                    //     directive 已去掉前导 '#'，所以这里以 'z' 开头而不是 '#'
                    {
                        size_t p = 0;
                        while (p < directive.size() && isspace((unsigned char)directive[p])) p++;
                        if (p + 5 <= directive.size() &&
                            strncmp(directive.c_str() + p, "zeile", 5) == 0) {
                            p += 5;
                            while (p < directive.size() && isspace((unsigned char)directive[p])) p++;
                            int nl = 0;
                            bool has_digit = false;
                            while (p < directive.size() && isdigit((unsigned char)directive[p])) {
                                nl = nl * 10 + (directive[p] - '0');
                                p++;
                                has_digit = true;
                            }
                            if (has_digit && nl > 0) final_new_line = nl;
                        }
                    }
                
                    // (2) 仍扫描行内其他 "#zeile N"（兼容被拼成一行的情况）
                    size_t scan_pos = 0;
                    while (scan_pos < directive.size()) {
                        size_t hash_pos = directive.find('#', scan_pos);
                        if (hash_pos == std::string::npos) break;
                        size_t p = hash_pos + 1;
                        while (p < directive.size() && isspace((unsigned char)directive[p])) p++;
                        if (p + 5 <= directive.size() &&
                            strncmp(directive.c_str() + p, "zeile", 5) == 0) {
                            p += 5;
                            while (p < directive.size() && isspace((unsigned char)directive[p])) p++;
                            int nl = 0;
                            while (p < directive.size() && isdigit((unsigned char)directive[p])) {
                                nl = nl * 10 + (directive[p] - '0');
                                p++;
                            }
                            if (nl > 0) final_new_line = nl;
                            scan_pos = p;
                        } else {
                            scan_pos = hash_pos + 1;
                        }
                    }
                
                    if (final_new_line > 0) {
                        line_num = final_new_line;   // 跳到目标行号，不递增
                    } else {
                        line_num++;                  // 解析失败时保持原行为
                    }
                    processed_code += line + '\n';
                    continue;
                }
            }
        }

        // 非指令行：根据当前跳过状态决定是否输出
        scan_line_string_state(line);

        // 非指令行：根据当前跳过状态决定是否输出
        bool skip = false;
        if (!cond_stack.empty()) skip = cond_stack.back();
        if (!skip) {
            processed_code += line;
        }
        processed_code += '\n';
        line_num++;
    }
    if (!cond_stack.empty()) {
        // 报第一个未闭合的 #fa / #fan（栈底），因为它才是后续代码被吞掉的起点
        int first_open = cond_line_stack.front();
        int unclosed   = (int)cond_stack.size();
        preprocess_error_at(first_open, 1,
            "条件编译块未闭合：从第 %d 行开始的 #fa / #fan 缺少对应的 #endfa"
            "（共 %d 层未闭合）",
            first_open, unclosed);
    }
    code = processed_code;

    code = extract_and_strip_lexikal(code, alias_map);
    g_lexikal_alias_map = alias_map;  // 更新全局别名映射，用于错误提示
    for (const auto& key : removed_aliases) {
        alias_map.erase(key);
        g_lexikal_alias_map.erase(key);
    }

    // ---------- 2. 获取基准目录 ----------
    std::string base_dir = ".";
    if (current_filename && current_filename[0] != '\0') {
        fs::path file_path = fs::u8path(current_filename);
        base_dir = file_path.parent_path().string();
    }

    // ---------- 3. 预处理 lexikal 导入：只收集别名，不展开源码 ----------
    std::set<std::string> visited;

    // ---------- 4. 替换别名（支持多词短语，迭代直到稳定） ----------
    if (alias_map.empty()) {
        final_result = code;
        std::unordered_map<size_t, int> offset_map = build_offset_to_line(final_result);
        final_result = expand_macros(final_result, offset_map);
        return final_result;
    }

    // ---- 预分类别名键 ----
    std::vector<std::string> pure_ident_keys;
    std::vector<std::string> mixed_keys;
    for (const auto& kv : alias_map) {
        bool is_pure = true;
        for (char c : kv.first) {
            if (!is_ident_char(c)) { is_pure = false; break; }
        }
        if (is_pure) pure_ident_keys.push_back(kv.first);
        else         mixed_keys.push_back(kv.first);
    }
    // 按长度降序（优先匹配较长键，避免前缀误匹配）
    std::sort(pure_ident_keys.begin(), pure_ident_keys.end(),
        [](const std::string& a, const std::string& b) { return a.length() > b.length(); });
    std::sort(mixed_keys.begin(), mixed_keys.end(),
        [](const std::string& a, const std::string& b) { return a.length() > b.length(); });

    // ---- 迭代替换直到稳定 ----
    std::string work = code;
    const int MAX_ALIAS_PASSES = 64;
    for (int pass = 0; pass < MAX_ALIAS_PASSES; ++pass) {
        std::string temp_code = work;
        std::string next_result;
        next_result.reserve(temp_code.size() + 64);

        bool in_string_   = false;
        bool in_char_     = false;
        bool in_backtick_ = false;
        bool escape_protect_next = false;   // 下一个字符受反斜杠转义保护，不参与混合键匹配

        size_t i = 0;
        while (i < temp_code.length()) {
            char c = temp_code[i];

            // ============================================================
            // 第一步：尝试匹配混合键（符号宏）
            //   - 在任意位置匹配（包括字符串 / 字符 / 反引号内部）
            //   - 如果处于转义保护状态，跳过
            //   - 反斜杠本身若是一个混合键，会在此处被匹配
            // ============================================================
            bool matched = false;
            if (!escape_protect_next) {
                for (const std::string& key : mixed_keys) {
                    if (temp_code.compare(i, key.length(), key) == 0) {
                        const auto& parts = alias_map[key];
                        std::string replacement;
                        for (const auto& part : parts) {
                            if (!replacement.empty()) replacement += " ";
                            replacement += part;
                        }
                        next_result += replacement;
                        i += key.length();
                        matched = true;
                        break;
                    }
                }
            }
            if (matched) {
                escape_protect_next = false;
                continue;
            }

            // ============================================================
            // 第二步：处理转义保护状态
            //   被保护的字符直接输出，不参与混合键匹配，也不参与字符串状态切换
            //   （例如 \" 中的 " 在字符串外不应进入字符串状态）
            // ============================================================
            if (escape_protect_next) {
                escape_protect_next = false;
                next_result += c;
                i++;
                continue;
            }

            // ============================================================
            // 第三步：处理反斜杠（不是任何混合键的一部分）
            //   作为转义符，保护下一个字符不被混合键匹配。
            // ============================================================
            if (c == '\\') {
                next_result += c;
                escape_protect_next = true;
                i++;
                continue;
            }

            // ============================================================
            // 第四步：维护字符串 / 字符 / 反引号状态
            //   （纯标识符键的匹配需要此状态）
            // ============================================================
            if (!in_string_ && !in_char_ && !in_backtick_) {
                if (c == '"')  { in_string_   = true; next_result += c; i++; continue; }
                if (c == '\'') { in_char_     = true; next_result += c; i++; continue; }
                if (c == '`')  { in_backtick_ = true; next_result += c; i++; continue; }
            } else {
                if (in_string_   && c == '"')  { in_string_   = false; next_result += c; i++; continue; }
                if (in_char_     && c == '\'') { in_char_     = false; next_result += c; i++; continue; }
                if (in_backtick_ && c == '`')  { in_backtick_ = false; next_result += c; i++; continue; }
            }

            // ============================================================
            // 第五步：尝试匹配纯标识符键（仅在字符串外，且需满足标识符边界）
            // ============================================================
            if (!in_string_ && !in_char_ && !in_backtick_ && is_ident_start(c)) {
                for (const std::string& key : pure_ident_keys) {
                    if (temp_code.compare(i, key.length(), key) == 0) {
                        size_t end = i + key.length();
                        bool left_ok  = (i == 0 || !is_ident_char(temp_code[i-1]));
                        bool right_ok = (end == temp_code.length() || !is_ident_char(temp_code[end]));
                        if (left_ok && right_ok) {
                            if (is_keyword(key.c_str())) {
                                next_result += key;   // 关键字别名保持原样
                            } else {
                                const auto& parts = alias_map[key];
                                std::string replacement;
                                for (const auto& part : parts) {
                                    if (!replacement.empty()) replacement += " ";
                                    replacement += part;
                                }
                                next_result += replacement;
                            }
                            i += key.length();
                            matched = true;
                            break;
                        }
                    }
                }
            }
            if (matched) continue;

            // ============================================================
            // 第六步：普通字符
            // ============================================================
            next_result += c;
            i++;
        }

        // ---- 判断是否稳定（本轮没有再产生变化） ----
        if (next_result == work) {
            work = std::move(next_result);
            break;
        }
        work = std::move(next_result);
    }

    final_result = std::move(work);
    std::unordered_map<size_t, int> offset_map = build_offset_to_line(final_result);
    final_result = expand_macros(final_result, offset_map);
    return final_result;
}

static std::string macro_marks_to_json() {
    std::string json = "[";
    bool first = true;
    for (const auto& m : g_macro_lex_marks) {
        if (!first) json += ",";
        first = false;
        json += "{\"name\":\"";
        for (char c : m.name) {
            if (c == '"' || c == '\\') json += '\\';
            json += c;
        }
        json += "\",\"zeile\":" + std::to_string(m.line);
        json += ",\"spal\":"  + std::to_string(m.col);
        json += ",\"wahr\":"  + std::string(m.truth ? "1" : "0");
        json += ",\"art\":\"" + m.kind + "\"";
        if (m.kind == "branch") {
            json += ",\"endZeile\":" + std::to_string(m.end_line);
            json += ",\"endSpal\":"  + std::to_string(m.end_col);
            json += ",\"genommen\":" + std::string(m.taken ? "1" : "0");
        }
        json += "}";
    }
    json += "]";
    return json;
}

static std::string lex_version_string() {
    return std::to_string(MAJOR) + "." +
           std::to_string(MINOR) + "." +
           std::to_string(PATCH);
}

static std::string resolve_module_path(const std::string& module_name,
                                       bool has_quote,
                                       const std::string& base_dir) {
    fs::path path;
    // ---- 按 base_dir 和 lag 目录直接拼接 ----
    if (has_quote) {
        fs::path rel = fs::path(base_dir) / module_name;
        if (fs::exists(rel)) {
            path = rel;
        } else {
            fs::path lag = exe_dir / "lag" / module_name;
            if (fs::exists(lag)) {
                path = lag;
            } else {
                if (module_name.find(".kr") == std::string::npos) {
                    fs::path lag_kr = exe_dir / "lag" / (module_name + ".kr");
                    if (fs::exists(lag_kr)) {
                        path = lag_kr;
                    } else {
                        fs::path rel_kr = fs::path(base_dir) / (module_name + ".kr");
                        if (fs::exists(rel_kr)) {
                            path = rel_kr;
                        }
                    }
                }
            }
        }
    } else {
        fs::path lag = exe_dir / "lag" / (module_name + ".kr");
        if (fs::exists(lag)) {
            path = lag;
        }
    }

    // ---- 如果仍未找到，且模块名不含路径分隔符，则递归搜索 lag 目录 ----
    if (path.empty() && 
        module_name.find('/') == std::string::npos &&
        module_name.find('\\') == std::string::npos) {
        fs::path lag_root = exe_dir / "lag";
        if (fs::exists(lag_root) && fs::is_directory(lag_root)) {
            std::string target_filename = module_name;
            if (!has_quote && target_filename.find(".kr") == std::string::npos) {
                target_filename += ".kr";
            }
            // 递归遍历 lag 下所有子目录
            for (auto& entry : fs::recursive_directory_iterator(lag_root)) {
                if (entry.is_regular_file() && entry.path().filename() == target_filename) {
                    path = entry.path();
                    break;
                }
            }
        }
    }

    return path.empty() ? "" : path.string();
}

// 提取 lexikal 块别名并删除块
static std::string extract_and_strip_lexikal(const std::string& source,
                                             std::unordered_map<std::string, std::vector<std::string>>& alias_map) {
    std::string result;
    size_t i = 0;
    bool in_string = false, in_char = false, in_backtick = false, escape = false;

    while (i < source.length()) {
        char c = source[i];

        if (escape) {
            escape = false;
            result += c;
            i++;
            continue;
        }
        if (c == '\\') {
            escape = true;
            result += c;
            i++;
            continue;
        }

        // 处理字符串/字符/反引号边界
        if (!in_string && !in_char && !in_backtick) {
            if (c == '"') { in_string = true; result += c; i++; continue; }
            if (c == '\'') { in_char = true; result += c; i++; continue; }
            if (c == '`') { in_backtick = true; result += c; i++; continue; }
        } else {
            if (in_string && c == '"') { in_string = false; result += c; i++; continue; }
            if (in_char && c == '\'') { in_char = false; result += c; i++; continue; }
            if (in_backtick && c == '`') { in_backtick = false; result += c; i++; continue; }
        }

        // 检测 lexikal 关键字（只在非引号内）
        if (!in_string && !in_char && !in_backtick) {
            if (source.compare(i, 7, "lexikal") == 0 &&
                (i == 0 || !is_ident_char(source[i-1])) &&
                (i + 7 >= source.length() || !is_ident_char(source[i+7]))) {
                // 向前看：越过 "lexikal" 后的空白，找到 '{' 的位置
                // 注意：不修改 i，只有确认是块后才推进
                size_t lookahead = i + 7;
                while (lookahead < source.length() &&
                       isspace((unsigned char)source[lookahead]))
                    lookahead++;
                if (lookahead < source.length() && source[lookahead] == '{') {
                    // 保留 "lexikal" 与 '{' 之间的换行符，以维持行号
                    for (size_t k = i + 7; k < lookahead; k++) {
                        if (source[k] == '\n') result += '\n';
                    }
                    i = lookahead + 1; // 跳过 '{'
                    // 提取块内容并解析别名
                    size_t block_start = i;
                    int depth = 1;
                    while (i < source.length() && depth > 0) {
                        char ch = source[i];
                        if (ch == '\n') result += '\n';
                        if (ch == '\\') {
                            if (i + 1 < source.length() && source[i + 1] == '\n') {
                                result += '\n';       // 续行反斜杠后的换行同样要保留
                            }
                            i += 2;
                            continue;
                        }
                        if (ch == '"' || ch == '\'') {
                            char quote = ch;
                            i++;
                            while (i < source.length() &&
                                   !(source[i] == quote && source[i-1] != '\\')) {
                                if (source[i] == '\n') result += '\n';
                                i++;
                            }
                            if (i < source.length()) i++;
                            continue;
                        }
                        if (ch == '{') depth++;
                        else if (ch == '}') depth--;
                        i++;
                    }
                    if (depth == 0) {
                        // block_start 到 i-1 是块内容（不含末尾的 '}'）
                        size_t block_end = i - 1;
                        std::string block_content = source.substr(block_start, block_end - block_start);
                        // ---------- 基于字符扫描的解析器：支持跨行带引号的值 ----------
                        {
                            size_t bi = 0;
                            size_t blen = block_content.size();

                            // 跳过空白与行注释（仅在非引号状态下使用）
                            auto skip_ws_and_comments = [&]() {
                                while (bi < blen) {
                                    char c = block_content[bi];
                                    if (c == ' ' || c == '\t' || c == '\r' || c == '\n') { bi++; continue; }
                                    if (c == '#') {
                                        while (bi < blen && block_content[bi] != '\n') bi++;
                                        continue;
                                    }
                                    break;
                                }
                            };

                            while (bi < blen) {
                                skip_ws_and_comments();
                                if (bi >= blen) break;

                                // ---------- 1. 解析键 ----------
                                std::string key;
                                if (block_content[bi] == '"' || block_content[bi] == '\'') {
                                    char q = block_content[bi];
                                    bi++;  // 跳过开引号
                                    std::string raw;
                                    while (bi < blen) {
                                        char c = block_content[bi];
                                        if (c == '\\' && bi + 1 < blen) {
                                            raw += c;
                                            raw += block_content[bi + 1];
                                            bi += 2;
                                            continue;
                                        }
                                        if (c == q) { bi++; break; }
                                        raw += c;
                                        bi++;
                                    }
                                    char* unescaped = unescape_string(raw.c_str());
                                    key = unescaped;
                                    free(unescaped);
                                } else {
                                    // 未加引号的键：读到 '=' 或空白
                                    size_t start = bi;
                                    while (bi < blen && block_content[bi] != '=' &&
                                        !(block_content[bi] == ' ' || block_content[bi] == '\t' ||
                                            block_content[bi] == '\r' || block_content[bi] == '\n')) {
                                        bi++;
                                    }
                                    key = block_content.substr(start, bi - start);
                                }

                                skip_ws_and_comments();
                                if (bi >= blen || block_content[bi] != '=') {
                                    // 缺少 '='，跳过本行
                                    while (bi < blen && block_content[bi] != '\n') bi++;
                                    if (bi < blen) bi++;
                                    continue;
                                }
                                bi++; // 跳过 '='

                                skip_ws_and_comments();
                                if (bi >= blen) break;

                                // ---------- 2. 解析值（支持跨行） ----------
                                std::string val;
                                if (block_content[bi] == '"' || block_content[bi] == '\'') {
                                    char q = block_content[bi];
                                    bi++;  // 跳过开引号
                                    std::string raw;
                                    while (bi < blen) {
                                        char c = block_content[bi];
                                        if (c == '\\' && bi + 1 < blen) {
                                            // 保留转义序列原样，交给 unescape_string 处理
                                            raw += c;
                                            raw += block_content[bi + 1];
                                            bi += 2;
                                            continue;
                                        }
                                        if (c == q) { bi++; break; }
                                        raw += c;
                                        bi++;
                                    }
                                    char* unescaped = unescape_string(raw.c_str());
                                    val = unescaped;
                                    free(unescaped);
                                } else {
                                    // 未加引号的值：读到行尾或 '#' 注释
                                    size_t start = bi;
                                    while (bi < blen && block_content[bi] != '\n' && block_content[bi] != '#') {
                                        bi++;
                                    }
                                    val = block_content.substr(start, bi - start);
                                    // 去除首尾空白
                                    size_t s = val.find_first_not_of(" \t\r\n");
                                    size_t e = val.find_last_not_of(" \t\r\n");
                                    if (s != std::string::npos && e != std::string::npos)
                                        val = val.substr(s, e - s + 1);
                                    else
                                        val.clear();
                                }

                                if (!key.empty() && !val.empty())
                                    alias_map[key].push_back(val);
                            }
                        }
                        // 块已被处理，不向 result 添加任何内容（即删除整个块）
                        continue;
                    } else {
                        // 未正确闭合，保留原样（报错或简单忽略）
                        result += "lexikal";
                        i += 7;
                        continue;
                    }
                } else {
                    // 不是完整的 lexikal 块，保留 "lexikal"
                    result += "lexikal";
                    i += 7;
                    continue;
                }
            }
        }
        result += c;
        i++;
    }
    return result;
}

// ============ 静态未定义检查所需的内置名字 ============
static const std::unordered_set<std::string>& builtin_names() {
    static const std::unordered_set<std::string> s = {
        // 关键字
        "der","das","nutz","ist","zeig","schr","fa","snfa","sonst","indes","tu",
        "fkt","makro","lies","gib","art","null","wahr","fals","für","bruch","fortset",
        "ver","den","die","dem","jedes","in","faul","dies","imp","as","break","weiter",
        "aufz","als","warte","kernregel","global","des","bind","klass","erbt",
        "öffent","privat","schutz","konstr","methode","neu","ober","bei","sch",
        "stati","sicher","NICH","nich","dann","ac","von","bis","mit",
        // 内置函数（与 suggest_correction 的 builtins 列表保持一致即可）
        "sqrt","wurz","cbrt","kub","abs","btr","sin","cos","tan","tg","cot","ctg","sec","csc",
        "asin","acos","atan","atan2","sinh","cosh","tanh","asinh","acosh","atanh",
        "rand","zuf","srand","setze","exp","ln","log","lg","ld",
        "abl","inte","ab2","simp","grad","nullst","euler","pabl","ab3","ab4","rk",
        "newton","gradab","kquad","gauss",
        "leseDatei","lese","leseBin","schrd",
        "trim","ersetze","ers","teil","entfal","enthält","hat","fängtAnMit","beg",
        "abschnitt","ab","stelleVon","wo","letzteStelleVon","letzt",
        "alsZahl","alz","alsText","alt","alsArray","ala","format","län","groß",
        "sleep","zeit","zeit_us","zeit_ms","zeit_ns","tick","tock","tock_ms","tock_s",
        "datum","loesch","aktu","zeigAlle",
        "drücke","taste","ac_taste","taste_gedrueckt",
        "ausf","ausführen","BC","ac_ausf","lauf","ac_lauf","aufgT","aufgTöten","aufgAnf","taste_g",
        "ANFR","ac_ANFR","starteServer","ac_starteServer", "text","json","html","umleiten","abfrage","formular","esc",
        "holeIP",
        "kodierURL","dekodierURL",
        "ladeKD","schrKD","erneuKD","loesKD","suchKD","siebeKD","alleKD","zaehleKD",
        "verschlKD","entschlKD","jsonzu","zujson",
        "KRFehl","KRWarn","KRKom","typist","gtyp", "tokens","worte","zeile","line",
        "ende","exit","bytes","umbytes","kodierBase64","umf",
        "cpp","asm","va","vw","ast","regGen",
        "zgr","schlau","zgrw","zgrs","frei","zgrNull", "zeigIn","schrIn",
        "istZiffer", "istBuchstabe",
        "istAlnum", "istRaum",
        "istGroß", "istKlein",
        "istZahl", "entferne", "anfang", "rechts",
        "mittel", "produkt", "erstes", "einfuegen",
        "vereinige", "schnitt", "differenz", "mische",
        "kopiere",
        // 特殊变量
        "arga","argw","_",
    };
    return s;
}
 
 void tokenize_impl(const char* source) {
    const char* p = source;
    token_count = 0;
    tokens = NULL;
    tok_pos = 0;
    TokensType prevType = TOK_EOF;
    (void)prevType;
    g_current_operating_position = "<LEXIKAL>";
    
    if (current_filename && current_filename[0] != '\0') {
        g_line_to_file.emplace(1, current_filename);
        g_line_to_file[1] = current_filename;
    
    }

    int line = 1, col = 1;

    while (*p) {
        // ---------- 最高优先级：注释 ----------
        if (*p == '/') {
            if (*(p + 1) == '/') {               // 行注释
                while (*p && *p != '\n') { p++; col++; }
                continue;
            }
            if (*(p + 1) == '|') {               // 块注释
                p += 2;
                col += 2;
                while (*p && !(*p == '|' && *(p + 1) == '/')) {
                    if (*p == '\n') { line++; col = 1; }
                    else { col++; }
                    p++;
                }
                if (*p) { p += 2; col += 2; }
                continue;
            }
        }

        // ---------- 跳过空白 ----------
        if (isspace(*p)) {
            if (*p == '\n') {
                line++;
                col = 1;
            }
            else { col++; }
            p++;
            continue;
        }

        if (*p == '#') {
            const char* q = p + 1;
            while (*q && isspace(*q)) q++;
            if (strncmp(q, "zeile", 5) == 0) {
                q += 5;
                while (*q && isspace(*q)) q++;
                // 解析行号
                int new_line = 0;
                while (*q && isdigit(*q)) {
                    new_line = new_line * 10 + (*q - '0');
                    q++;
                }
                while (*q && isspace(*q)) q++;
                if (*q == '"') {
                    q++;
                    const char* file_start = q;
                    while (*q && *q != '"') q++;
                    if (*q == '"') {
                        std::string filename(file_start, q - file_start);
                        static thread_local std::string filename_storage;
                        filename_storage = filename;
                        current_filename = filename_storage.c_str();
                        line = new_line;
                        col = 1;
                        g_line_to_file[new_line] = filename;
                        q++;                                    // 跳过结束引号
                        while (*q && isspace((unsigned char)*q)
                               && *q != '\n' && *q != '\r') q++;   // 跳过同一行的空白
                        if (*q == ';') q++;                     // 跳过分号
                        p = q;

                        if (*p == '\r' && *(p + 1) == '\n') {
                            p += 2;
                        } else if (*p == '\n') {
                            p++;
                        }
                        col = 1;
                        continue;
                    }
                }
            }
        }

        // ---------- 正则字面量识别（仅当注释已排除） ----------
        if (*p == '/') {
            bool mayBeRegex = false;
            if (token_count == 0) {
                mayBeRegex = true;
            } else {
                Token* prev = &tokens[token_count - 1];
                if ((prev->type == TOK_OP || prev->type == TOK_SYMBOL) &&
                    strcmp(prev->value, ")") != 0 &&
                    strcmp(prev->value, "]") != 0 &&
                    strcmp(prev->value, "}") != 0 &&
                    strcmp(prev->value, ";") != 0) {
                    mayBeRegex = true;
                }
            }

            if (mayBeRegex) {
                int start_line = line, start_col = col;
                const char* regex_start = p + 1;
                p = regex_start;
                col++;
                while (1) {
                    if (*p == '\0') {
                        error_at(start_line, start_col, "未终止的正则表达式（未正确闭合）");
                    }
                    if (*p == '/' && (p == regex_start || *(p - 1) != '\\')) {
                        break;
                    }
                    if (*p == '\n') { line++; col = 1; }
                    else { col++; }
                    p++;
                }
                int len = p - regex_start;
                char* s = (char*)malloc(len + 1);
                memcpy(s, regex_start, len);
                s[len] = '\0';

                p++; // 跳过结束的 '/'
                col++;

                // 读取 flags（例如 i, g, m 等）
                char flags[16] = {0};
                int flag_idx = 0;
                while (isalpha(*p) || *p == '_') {
                    if (flag_idx < 15) flags[flag_idx++] = *p;
                    p++; col++;
                }
                flags[flag_idx] = '\0';

                // 生成 Token
                tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
                tokens[token_count].type = TOK_REGEX;
                tokens[token_count].value = s;
                tokens[token_count].line = start_line;
                tokens[token_count].col = start_col;
                // 若 flags 为空，则设为 "regex" 标记，以区别于双引号字符串
                tokens[token_count].flags = (flags[0] == '\0') ? strdup("regex") : strdup(flags);
                tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
                token_count++;

                prevType = TOK_STRING;
                continue;
            }
        }

        bool is_raw_string = false;
        bool is_bytes_string = false;
        bool is_escape_string = false;

        if ((*p == 'u' || *p == 'b' || *p == 'e') && *(p+1)) {
            char prefix = *p;
            char quote_char = *(p+1);
            if (quote_char == '"' || quote_char == '`') { // 支持 u" u` b" b`
                if (prefix == 'u') {
                    is_raw_string = true;
                } else if (prefix == 'b') {
                    is_bytes_string = true;
                } else {
                    is_escape_string = true;
                }
                p++;
                col++;
                // p现在指向引号字符 " 或者 `
            }
        }
 
        // ---- 双引号字符串 ----
        if (*p == '"') {
            int start_line = line, start_col = col;
            p++;                     // 跳过开头的双引号
            col++;
            const char* start = p;   // 字符串内容起始
            int brace_depth = 0;
            bool escaped = false;    // 标记当前是否处于转义状态

            while (*p) {
                // 处理转义状态
                if (escaped) {
                    escaped = false;   // 当前字符已被转义，跳过
                    // 直接跳到更新行列和p++，不检查任何特殊字符
                } else {
                    // 检查是否为反斜杠（进入转义状态）
                    if (!is_raw_string && *p == '\\') {
                        escaped = true;
                        // 跳过反斜杠本身，下一个字符将被忽略
                        if (*p == '\n') { line++; col = 1; } else { col++; }
                        p++;
                        continue;
                    }

                    // 仅在深度为0且非转义时检查结束双引号
                    if (brace_depth == 0 && *p == '"') {
                        break;   // 字符串结束
                    }

                    // 处理未转义的花括号（插值边界）
                    if (!is_raw_string && !is_bytes_string) {
                        if (*p == '{') {
                            brace_depth++;
                        }
                        else if (*p == '}') {
                            if (brace_depth > 0)
                                brace_depth--;
                        }
                    }
                }

                // 更新行列并前进
                if (*p == '\n') { line++; col = 1; } else { col++; }
                p++;
            }

            // 检查字符串是否正常结束
            int len = (int)(p - start);
            if (*p == '"') {
                p++;                     // 跳过结束双引号
                col++;
            } else {
                error_at(start_line, start_col, "未终止的字符串（未正确闭合）");
            }

            // 复制内容（转义序列原样保留，后续由 unescape_string 处理）
            char* s = (char*)malloc(len + 1);
            memcpy(s, start, len);
            s[len] = '\0';

            // 生成 token
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_REGEX;   // 复用 TOK_REGEX 表示字符串
            tokens[token_count].value = s;
            tokens[token_count].line = start_line;
            tokens[token_count].col = start_col;
            if (is_raw_string)
                tokens[token_count].flags = strdup("uraw");
            else if (is_bytes_string)
                tokens[token_count].flags = strdup("bytes");
            else if (is_escape_string)
                tokens[token_count].flags = strdup("escape");
            else
                tokens[token_count].flags = NULL;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;

            prevType = TOK_STRING;
            continue;
        }

        // ---- 单引号字符/字符串字面量 ----
        if (*p == '\'') {
            int start_line = line, start_col = col;
            p++; col++;  // 跳过开头的单引号
            const char* start = p;
            while (*p) {
                if (*p == '\\' && *(p+1)) {
                    p += 2;
                    col += 2;
                    continue;
                }
                if (*p == '\'') break;
                p++;
                col++;
            }
            if (*p != '\'') {
                error_at(start_line, start_col, "未终止的字符/字符串字面量（未正确闭合）");
            }
            int len = p - start;
            char* content = (char*)malloc(len + 1);
            memcpy(content, start, len);
            content[len] = '\0';
            p++; col++; // 跳过结束单引号

            size_t unescaped_len = 0;
            char* unescaped = unescape_string(content, &unescaped_len);
            free(content);

            if (unescaped_len == 1) {
                tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
                tokens[token_count].type = TOK_REGEX;   // 复用正则/字符串类型
                tokens[token_count].value = unescaped;  // 直接持有（unescaped 已分配）
                tokens[token_count].line = start_line;
                tokens[token_count].col = start_col;
                tokens[token_count].flags = strdup("single");
                tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
                token_count++;
                prevType = TOK_REGEX;
            } else if (unescaped_len == 0) {
                // 空单引号 → 整数 0
                tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
                tokens[token_count].type = TOK_NUMBER;
                tokens[token_count].value = strdup("0");
                tokens[token_count].line = start_line;
                tokens[token_count].col = start_col;
                tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
                token_count++;
                prevType = TOK_NUMBER;
                free(unescaped);
            } else {
                // 空或多字符 → 字符串 Token
                tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
                tokens[token_count].type = TOK_REGEX;
                tokens[token_count].value = unescaped;  // 直接持有转义后的字符串
                tokens[token_count].line = start_line;
                tokens[token_count].col = start_col;
                if (is_raw_string)
                    tokens[token_count].flags = strdup("uraw");
                else if (is_bytes_string)
                    tokens[token_count].flags = strdup("bytes");
                else if (is_escape_string)
                    tokens[token_count].flags = strdup("escape");
                else
                    tokens[token_count].flags = strdup("single");
                tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
                token_count++;
                prevType = TOK_REGEX;
            }
            continue;
        }

        // 反引号原始字符串
        if (*p == '`') {
            int start_line = line, start_col = col;
            p++;                     // 跳过开头的反引号
            col++;
            std::string content;
            while (*p) {
                // 检测转义的反引号
                if (*p == '\\' && *(p + 1) == '`') {
                    content.push_back('`');   // 字面反引号
                    p += 2;                    // 跳过反斜杠和反引号
                    col += 2;                  // 这两个字符占用两列
                    continue;
                }
                else if (*p == '\\' && *(p + 1) == '\\') {
                    content.push_back('\\');
                    p += 2;
                    col += 2;
                    continue;
                }
                else if (*p == '\\' && *(p + 1) == '&') {
                    content.push_back('&');
                    p += 2; col += 2;
                    continue;
                }
                // 遇到未转义的反引号 → 结束
                if (*p == '`') {
                    break;
                }
                // 普通字符
                content.push_back(*p);
                if (*p == '\n') { line++; col = 1; }
                else { col++; }
                p++;
            }
            if (*p != '`') {
                error_at(start_line, start_col, "未终止的反引号字符串（未正确闭合）");
            }
            p++;                     // 跳过结束的反引号
            col++;
            char* s = strdup(content.c_str());
            // 生成 Token，flags 仍为 "raw" 表示原始字符串
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_REGEX;
            tokens[token_count].value = s;
            tokens[token_count].line = start_line;
            tokens[token_count].col = start_col;
            if (is_raw_string)
                tokens[token_count].flags = strdup("uraw");
            else if (is_bytes_string)
                tokens[token_count].flags = strdup("bytes");
            else if (is_escape_string)
                tokens[token_count].flags = strdup("escape");
            else
                tokens[token_count].flags = strdup("raw");
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            prevType = TOK_STRING;
            continue;
        }
 
         // ---- 多字符运算符（包括 ++, --, 复合赋值） ----
         if ((*p == '+' && *(p+1) == '+') || (*p == '-' && *(p+1) == '-')) {
             char s[3] = {*p, *(p+1), '\0'};
             tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
             tokens[token_count].type = TOK_OP;
             tokens[token_count].value = strdup(s);
             tokens[token_count].line = line;
             tokens[token_count].col = col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = TOK_OP;
             p += 2; col += 2;
             continue;
         }
         if (*p == '<' && *(p+1) == '-' && *(p+2) == '>') {
            char s[4] = {'<', '-', '>', '\0'};   // 或直接赋值 "<->"
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].flags = NULL;     // 无额外标志
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            prevType = TOK_OP;
            p += 3;
            col += 3;
            continue;
        }

        if (*p == '#' && *(p+1) == '#') {
            char s[3] = {'#', '#', '\0'};
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            p += 2; col += 2;
            continue;
        }
        if (*p == '\xC2' && *(p+1) == '\xB0') {
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup("°");   // 使用字符串字面量
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            p += 2;   // 跳过两个字节
            col += 2;
            continue;
        }
        if (*p == '<' && *(p+1) == '<') {
            char s[3] = {'<', '<', '\0'};
            tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            p += 2; col += 2;
            continue;
        }
        if (*p == '>' && *(p+1) == '>') {
            char s[3] = {'>', '>', '\0'};
            tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            p += 2; col += 2;
            continue;
        }

        if ((*p == '+' && *(p+1) == '=') || (*p == '-' && *(p+1) == '=') ||
            (*p == '*' && *(p+1) == '=') || (*p == '/' && *(p+1) == '=') ||
            (*p == '%' && *(p+1) == '=') || (*p == '^' && *(p+1) == '=') ||
            (*p == '|' && *(p+1) == '=') || (*p == '&' && *(p+1) == '=') ||
            (*p == '~' && *(p+1) == '=')) {
             char s[3] = {*p, *(p+1), '\0'};
             tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
             tokens[token_count].type = TOK_OP;
             tokens[token_count].value = strdup(s);
             tokens[token_count].line = line;
             tokens[token_count].col = col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = TOK_OP;
             p += 2; col += 2;
             continue;
         }
         if (*p == '<' && *(p+1) == '=' && *(p+2) == '>') {
            char s[4] = {'<', '=', '>', '\0'};
            tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            prevType = TOK_OP;
            p += 3;
            col += 3;
            continue;
         }
         if ((*p == '<' && *(p+1) == '=') || (*p == '>' && *(p+1) == '=') ||
             (*p == '=' && *(p+1) == '=') || (*p == '!' && *(p+1) == '=')) {
             char s[3] = {*p, *(p+1), '\0'};
             tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
             tokens[token_count].type = TOK_OP;
             tokens[token_count].value = strdup(s);
             tokens[token_count].line = line;
             tokens[token_count].col = col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = TOK_OP;
             p += 2; col += 2;
             continue;
         }
         if (*p == '&' && *(p+1) == '&') {
             tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
             tokens[token_count].type = TOK_OP;
             tokens[token_count].value = strdup("&&");
             tokens[token_count].line = line;
             tokens[token_count].col = col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = TOK_OP;
             p += 2; col += 2;
             continue;
         }
         if (*p == '|' && *(p+1) == '|') {
             tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
             tokens[token_count].type = TOK_OP;
             tokens[token_count].value = strdup("||");
             tokens[token_count].line = line;
             tokens[token_count].col = col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = TOK_OP;
             p += 2; col += 2;
             continue;
         }
         if (*p == '.' && *(p+1) == '.' && *(p+2) == '.') {
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup("...");
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            p += 3;
            col += 3;
            prevType = TOK_OP;
            continue;
         }
         if (*p == '.' && *(p+1) == '.') {
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup("..");
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].flags = NULL;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
             p += 2; col += 2;
             continue;
         }
         if (*p == '?' && *(p+1) == '.') {
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup("?.");
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].flags = NULL;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
             p += 2; col += 2; continue;
         }
         if (*p == '?' && *(p+1) == '?') {
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup("??");
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].flags = NULL;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
             p += 2; col += 2; continue;
         }
         if (*p == '|' && *(p+1) == '>') {
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup("|>");
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].flags = NULL;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
             p += 2; col += 2; continue;
         }
         if (*p == '=' && *(p+1) == '>') {
            char s[3] = {'=', '>', '\0'};
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            prevType = TOK_OP;
            p += 2;
            col += 2;
            continue;
         }

         if (*p == '*' && *(p+1) == '*') {
             char s[3] = {'*', '*', '\0'};
             tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
             tokens[token_count].type = TOK_OP;
             tokens[token_count].value = strdup(s);
             tokens[token_count].line = line;
             tokens[token_count].col = col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = TOK_OP;
             p += 2;
             col += 2;
             continue;
         }
         
         if (*p == '!' && *(p+1) == '!') {
            char s[3] = {'!', '!', '\0'};
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            prevType = TOK_OP;
            p += 2;
            col += 2;
            continue;
         }
         if (*p == ':' && *(p+1) == ':') {
            char s[3] = {':', ':', '\0'};
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            p += 2; col += 2;
            continue;
         }
         if (*p == '~' && *(p+1) == '~') {
            char s[3] = {'~', '~', '\0'};
            tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
            tokens[token_count].type = TOK_OP;
            tokens[token_count].value = strdup(s);
            tokens[token_count].line = line;
            tokens[token_count].col = col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            prevType = TOK_OP;
            p += 2; col += 2;
            continue;
         }
 
         // ---- 单字符运算符和符号 ----
         if (strchr("+-*/%(){}<>=,.[];?:#^!&|~", *p)) {
             char s[2] = {*p, '\0'};
             TokensType typ = (*p == '(' || *p == ')' || *p == '{' || *p == '}' || *p == ',' ||
                              *p == '[' || *p == ']' || *p == '.' || *p == ';' ||
                              *p == '?' || *p == ':') ? TOK_SYMBOL : TOK_OP;
             tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
             tokens[token_count].type = typ;
             tokens[token_count].value = strdup(s);
             tokens[token_count].line = line;
             tokens[token_count].col = col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = typ;
             p++; col++;
             continue;
         }
 
        // ---- 数字 ----
        if (isdigit(*p)) {
            int start_line = line, start_col = col;
            const char* start = p;
        
            // 检测十六进制前缀 0x / 0X
            if (*p == '0' && (*(p + 1) == 'x' || *(p + 1) == 'X')) {
                p += 2;
                col += 2;
                if (!isxdigit(*p)) {
                    error_at(start_line, start_col, "无效的十六进制数字");
                }
                // 解析十六进制整数部分（允许下划线）
                while (isxdigit(*p) || *p == '_') { p++; col++; }
                // 可选的小数点（十六进制浮点数）
                if (*p == '.' && isxdigit(*(p + 1))) {
                    p++; col++;
                    while (isxdigit(*p) || *p == '_') { p++; col++; }
                }
                // 可选的指数部分（'p' 或 'P'，后跟有符号十进制整数）
                if ((*p == 'p' || *p == 'P') &&
                    (isdigit(*(p + 1)) || ((*(p + 1) == '+' || *(p + 1) == '-') && isdigit(*(p + 2))))) {
                    p++; col++;                      // 跳过 p/P
                    if (*p == '+' || *p == '-') { p++; col++; }
                    while (isdigit(*p)) { p++; col++; }  // 指数不含下划线
                }
            } else if (*p == '0' && (*(p + 1) == 'b' || *(p + 1) == 'B')) {
                // 二进制
                p += 2; col += 2;
                if (!(*p == '0' || *p == '1')) {
                    error_at(start_line, start_col, "无效的二进制数字");
                }
                while (*p == '0' || *p == '1' || *p == '_') { p++; col++; }
                // 不允许浮点部分
                if (*p == '.' || *p == 'e' || *p == 'E') {
                    error_at(start_line, start_col, "二进制不支持浮点数");
                }
                // 记录原始字符串（含前缀）
                int len = p - start;
                char* raw = (char*)malloc(len + 1);
                memcpy(raw, start, len);
                raw[len] = '\0';
                // 去除下划线
                char* clean = (char*)malloc(len + 1);
                int j = 0;
                for (int i = 0; i < len; i++) {
                    if (raw[i] != '_') clean[j++] = raw[i];
                }
                clean[j] = '\0';
                free(raw);
                // 生成 TOK_NUMBER
                tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
                tokens[token_count].type = TOK_NUMBER;
                tokens[token_count].value = clean;  // 如 "0b1010"
                tokens[token_count].line = start_line;
                tokens[token_count].col = start_col;
                tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
                token_count++;
                prevType = TOK_NUMBER;
                continue;
            } else if (*p == '0' && (*(p + 1) == 'o' || *(p + 1) == 'O')) {
                // 八进制
                p += 2; col += 2;
                if (!(*p >= '0' && *p <= '7')) {
                    error_at(start_line, start_col, "无效的八进制数字");
                }
                while ((*p >= '0' && *p <= '7') || *p == '_') { p++; col++; }
                if (*p == '.' || *p == 'e' || *p == 'E') {
                    error_at(start_line, start_col, "八进制不支持浮点数");
                }
                int len = p - start;
                char* raw = (char*)malloc(len + 1);
                memcpy(raw, start, len);
                raw[len] = '\0';
                char* clean = (char*)malloc(len + 1);
                int j = 0;
                for (int i = 0; i < len; i++) {
                    if (raw[i] != '_') clean[j++] = raw[i];
                }
                clean[j] = '\0';
                free(raw);
                tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
                tokens[token_count].type = TOK_NUMBER;
                tokens[token_count].value = clean;
                tokens[token_count].line = start_line;
                tokens[token_count].col = start_col;
                tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
                token_count++;
                prevType = TOK_NUMBER;
                continue;
            } else {
                // 十进制数字解析（支持科学计数法 e/E，允许下划线）
                while (isdigit(*p) || *p == '_') { p++; col++; }
                if (*p == '.' && isdigit(*(p + 1))) {
                    p++; col++;
                    while (isdigit(*p) || *p == '_') { p++; col++; }
                }
                if ((*p == 'e' || *p == 'E') &&
                    (isdigit(*(p + 1)) || ((*(p + 1) == '+' || *(p + 1) == '-') && isdigit(*(p + 2))))) {
                    p++; col++;
                    if (*p == '+' || *p == '-') { p++; col++; }
                    while (isdigit(*p) || *p == '_') { p++; col++; }
                }
            }
        
            int len = p - start;
            char* raw = (char*)malloc(len + 1);
            memcpy(raw, start, len);
            raw[len] = '\0';
        
            // 如果 token 是十六进制浮点数（含 'p' 或 'P'）且指数缺少符号，则强制插入 '+'
            if (strchr(raw, 'p') || strchr(raw, 'P')) {
                char* ppos = strpbrk(raw, "pP");
                if (ppos && ppos[1] && ppos[1] != '+' && ppos[1] != '-') {
                    std::string modified(raw);
                    size_t idx = ppos - raw;
                    modified.insert(idx + 1, "+");
                    free(raw);
                    raw = strdup(modified.c_str());
                    len = strlen(raw);   // 更新长度，以便后续分配 clean
                }
            }
        
            // 去除所有下划线
            char* clean = (char*)malloc(len + 1);
            int j = 0;
            for (int i = 0; i < len; i++) {
                if (raw[i] != '_') clean[j++] = raw[i];
            }
            clean[j] = '\0';
            free(raw);
        
            tokens = (Token*)realloc(tokens, (token_count + 1) * sizeof(Token));
            tokens[token_count].type = TOK_NUMBER;
            tokens[token_count].value = clean;
            tokens[token_count].line = start_line;
            tokens[token_count].col = start_col;
            tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
            token_count++;
            prevType = TOK_NUMBER;
            continue;
        }    
 
         // ---- 标识符 / 关键字 ----
         if (isalpha((unsigned char)*p) || *p == '_' || (unsigned char)*p > 127) {
             int start_line = line;
             int start_col = col;
             const char* start = p;
             while (isalnum((unsigned char)*p) || *p == '_' || (unsigned char)*p > 127) {
                p++; col++;
             }
             int len = p - start;
             char* s = (char*)malloc(len + 1);
             strncpy(s, start, len);
             s[len] = '\0';
             TokensType type = TOK_IDENT;
             char* value = s;
             // 逻辑运算符
             if (strcmp(s, "OD") == 0 || strcmp(s, "od") == 0) {
                 free(s);
                 value = strdup("||");
                 type = TOK_OP;
             } else if (strcmp(s, "UND") == 0 || strcmp(s, "und") == 0) {
                 free(s);
                 value = strdup("&&");
                 type = TOK_OP;
             } else {
                 if (is_keyword(s)) type = TOK_KEYWORD;
             }
             tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
             tokens[token_count].type = type;
             tokens[token_count].value = value;
             tokens[token_count].line = start_line;
             tokens[token_count].col = start_col;
             tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
             token_count++;
             prevType = type;
             continue;
         }
 
         // ---- 其他字符 ----
         p++; col++;
     }
 
     // EOF token
     tokens = (Token*)realloc(tokens, (token_count+1)*sizeof(Token));
     tokens[token_count].type = TOK_EOF;
     tokens[token_count].value = strdup("");
     tokens[token_count].line = line;
     tokens[token_count].col = col;
     tokens[token_count].filename = current_filename ? strdup(current_filename) : NULL;
     token_count++;
 }

 void tokenize(const char* source) {
    tokenize_impl(source);
 }
 
 Token* peek() { return &tokens[tok_pos]; }
 Token* consume() {
    Token* t = &tokens[tok_pos++];
    g_last_token_line = t->line;
    g_last_token_col = t->col;
    return t;
 }
 
void expect(const char* s) {
    Token* t = peek();
    // 单字符符号必须为 TOK_SYMBOL
    if (strlen(s) == 1 && strchr("(){}[];,:", s[0])) {
        if (t->type != TOK_SYMBOL || strcmp(t->value, s) != 0) {
            error_at(t->line, t->col, "语法错误: 期望符号 '%s', 得到 '%s'", s, t->value);
        }
    } else {
        // 其他（如 "=>"）只比较值
        if (strcmp(t->value, s) != 0) {
            error_at(t->line, t->col, "语法错误: 期望 '%s', 得到 '%s'", s, t->value);
        }
    }
    tok_pos++;
}
 
/* ========== 作用域与符号表 ========== */
struct Variable {
    char* name;
    Value value;           // 普通变量值（惰性变量未求值时忽略）
    bool is_const;
    bool is_lazy;          // 是否为惰性变量
    bool evaluated;        // 是否已求值（仅惰性变量有效）
    ASTNode* init_expr;    // 惰性初始化表达式（仅惰性变量有效）
    Value cached_value;    // 求值后的缓存值（仅惰性变量有效）
    bool is_alias;         // 是否为别名
    char* alias_target;    // 目标变量名（若 is_alias 为 true）
    bool is_read;
    TypeNode* type_annotation;

    size_t lazy_code_off = SIZE_MAX;
    size_t lazy_code_end = SIZE_MAX;
    Scope*   lazy_scope    = nullptr;
};

struct Scope {
    Variable* vars;
    int var_count;
    struct Scope* parent;
    int id;
    
    int refcount = 1;
    void retain()  { refcount++; }
    void release() {
        if (--refcount == 0) {
            delete this;
        }
    }
};
 
thread_local Scope* current_scope = NULL;
Scope* original_global_scope = nullptr;
 
// ---- 作用域池：避免每次函数调用都 calloc/free ----
// LIFO 复用；作用域内部保留的 vars 数组容量也会一并保留，
// 从而让 declare_var 的首次 realloc 走原地缩小路径，避免再次分配。
static const size_t MAX_SCOPE_POOL = 32;
thread_local std::vector<Scope*> g_scope_pool;

using CompileConstTable = std::unordered_map<std::string, ASTNode*>;
static std::vector<CompileConstTable> g_compile_const_stack;

void push_scope() {
    Scope* s;
    if (!g_scope_pool.empty()) {
        // 复用池中作用域
        s = g_scope_pool.back();
        g_scope_pool.pop_back();
        s->parent = current_scope;
        s->id = next_scope_id++;
        // var_count 已在 pop_scope 归零；vars 数组容量保留
    } else {
        s = (Scope*)calloc(1, sizeof(Scope));
        s->parent = current_scope;
        s->id = next_scope_id++;
    }
    current_scope = s;
    // 注意：不再无条件执行 print_lines[s->id]。
    // print_lines 的条目改为按需创建（首次 write/aktu 时由 operator[] 触发）
    g_compile_const_stack.emplace_back();
}

void pop_scope() {
    if (!current_scope) return;

    if(!g_compile_const_stack.empty()){
        g_compile_const_stack.pop_back();
    }

    // 移除 print_lines 里可能存在的条目（如果从没写过，这次 erase 只做一次
    // 哈希查找，不会分配也不会创建条目）
    print_lines.erase(current_scope->id);

    // 释放变量内容，但保留 vars 数组本身以复用
    for (int i = 0; i < current_scope->var_count; i++) {
        Variable* var = &current_scope->vars[i];
        free(var->name);
        var->name = nullptr;
        if (var->is_lazy) {
            if (var->evaluated) {
                free_value(&var->cached_value);
            }
        } else {
            free_value(&var->value);
        }
    }

    Scope* parent = current_scope->parent;
    Scope* s = current_scope;
    current_scope = parent;

    if (g_scope_pool.size() < MAX_SCOPE_POOL) {
        s->var_count = 0;
        s->parent = nullptr;
        g_scope_pool.push_back(s);
    } else {
        free(s->vars);
        free(s);
    }
}

 static void free_scope_chain(Scope* scope) {
    if (!scope) return;
    if (scope == original_global_scope) return;
    free_scope_chain(scope->parent);
    for (int i = 0; i < scope->var_count; i++) {
        Variable* var = &scope->vars[i];
        free(var->name);
        free_type_node(var->type_annotation);
        if (var->is_lazy) {
            if (var->evaluated) {
                free_value(&var->cached_value);   // 释放缓存值
            }
            // init_expr 属于程序 AST，不由作用域释放
        } else {
            free_value(&var->value);
        }
    }
    free(scope->vars);
    free(scope);
 }
 
 int get_var_index_in_scope(Scope* scope, const char* name) {
     for (int i = 0; i < scope->var_count; i++) {
         if (strcmp(scope->vars[i].name, name) == 0)
             return i;
     }
     return -1;
 }
 
Variable* get_var(const char* name, bool for_read = true) {
    // ---- 快速路径：只在 current_scope 这一层查找（thread_local，无需加锁） ----
    if (current_scope) {
        Scope* s = current_scope;
        const char c0 = name[0];
        for (int i = 0; i < s->var_count; ++i) {
            if (s->vars[i].name[0] == c0 &&
                strcmp(s->vars[i].name, name) == 0) {
                if (for_read) s->vars[i].is_read = true;
                return &s->vars[i];
            }
        }
    }
    // ---- 常规路径（加锁 + 遍历父链，处理全局/静态属性回退） ----
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    Scope* s = current_scope;
    while (s) {
        int idx = get_var_index_in_scope(s, name);
        if (idx >= 0) {
            if (for_read) s->vars[idx].is_read = true;
            return &s->vars[idx];
        }
        s = s->parent;
    }
    if (original_global_scope && current_scope != original_global_scope) {
        int idx = get_var_index_in_scope(original_global_scope, name);
        if (idx >= 0) {
            if (for_read) original_global_scope->vars[idx].is_read = true;
            return &original_global_scope->vars[idx];
        }
    }
    return NULL;
}

 // 递归解析别名，返回最终指向的真实变量
Variable* resolve_alias(Variable* var) {
    if (!var || !var->is_alias) return var;
    // 防止无限递归
    static int depth = 0;
    if (++depth > MAX_RECURSION_DEPTH) {
        kr_error("别名链过深(%d)或存在循环别名\n", MAX_RECURSION_DEPTH);
        
    }
    Variable* target = get_var(var->alias_target);
    if (!target) {
        kr_error("别名目标 '%s' 未定义\n", var->alias_target);
        
    }
    Variable* result = resolve_alias(target);
    depth--;
    return result;
}

void declare_var_in_scope(Scope* scope, const char* name, bool is_const, 
    Value value, TypeNode* type_anno = nullptr) {
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    if (!scope) return;
    int idx = get_var_index_in_scope(scope, name);
    if (idx >= 0) {
        Variable* var = &scope->vars[idx];
        if (var->is_const) {
            kr_error("Fehler: 常量 '%s' 不能重新声明\n", name);
            
        }
        if (var->is_alias) {
            free(var->alias_target);
            var->is_alias = false;
            var->alias_target = NULL;
        }
        free_type_node(var->type_annotation);
        var->type_annotation = type_anno ? copy_type_node(type_anno) : nullptr;
        if (type_anno) {
            free_type_node(var->type_annotation);
            var->type_annotation = copy_type_node(type_anno);
        }
        free_value(&var->value);
        var->value = value;
        var->is_lazy = false;
        var->evaluated = false;
        var->init_expr = NULL;
        free_value(&var->cached_value);
        var->cached_value = make_null();
        return;
    }
    scope->vars = (Variable*)realloc(scope->vars, (scope->var_count + 1) * sizeof(Variable));
    Variable* var = &scope->vars[scope->var_count++];
    var->name = strdup(name);
    var->value = value;
    var->is_const = is_const;
    var->is_lazy = false;
    var->evaluated = false;
    var->init_expr = NULL;
    var->is_alias = false;
    var->alias_target = NULL;
    var->cached_value = make_null();
    var->is_read = false;
    var->type_annotation = type_anno ? copy_type_node(type_anno) : nullptr;
 }

 void set_var_in_scope(Scope* scope, const char* name, Value value) {
    if (!scope) return;
    Variable* var = NULL;
    Scope* s = scope;
    while (s) {
        int idx = get_var_index_in_scope(s, name);
        if (idx >= 0) { var = &s->vars[idx]; break; }
        s = s->parent;
    }
    if (var) {
        if (var->is_const) {
            kr_error("Fehler: 常量 '%s' 不能重新赋值\n", name);
            
        }
        if (var->is_lazy) {
            kr_error("Fehler: 惰性变量 '%s' 不能赋值\n", name);
            
        }
        free_value(&var->value);
        var->value = value;
    } else {
        // 在指定作用域创建新变量（默认非 const）
        declare_var_in_scope(scope, name, false, value);
    }
 }
 
 void declare_var(const char* name, bool is_const, Value value, TypeNode* type_anno = nullptr) {
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    if (!current_scope) push_scope();
    int idx = get_var_index_in_scope(current_scope, name);
    if (idx >= 0) {
        Variable* var = &current_scope->vars[idx];
        if (var->is_const) {
            kr_error("Fehler: 常量 '%s' 不能重新声明\n", name);
        }
        free_value(&var->value);
        var->value = value;
        // 如果提供了新类型注解，则更新
        if (type_anno) {
            free_type_node(var->type_annotation);
            var->type_annotation = copy_type_node(type_anno);
        }
        var->is_lazy = false;
        var->evaluated = false;
        var->init_expr = NULL;
        free_value(&var->cached_value);
        var->cached_value = make_null();
        var->is_read = false;
        return;
    }
    current_scope->vars = (Variable*)realloc(current_scope->vars,
                                 (current_scope->var_count + 1) * sizeof(Variable));
    Variable* var = &current_scope->vars[current_scope->var_count++];
    var->name = strdup(name);
    var->value = value;
    var->is_const = is_const;
    var->is_lazy = false;
    var->evaluated = false;
    var->init_expr = NULL;
    var->is_alias = false;
    var->alias_target = NULL;
    var->cached_value = make_null();
    var->type_annotation = type_anno ? copy_type_node(type_anno) : nullptr;
}
 
void set_var(const char* name, Value value) {
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    Variable* var = get_var(name, false);
    if (!var) {
        // 在当前作用域中声明（若当前作用域为空则创建）
        if (!current_scope) push_scope();
        declare_var_in_scope(current_scope, name, false, value);
        return;
    }
    if (var->is_const) {
        kr_error("Fehler: 常量 '%s' 不能重新赋值\n", name);
        
    }
    if (var->is_lazy) {           // 禁止对惰性变量赋值
        kr_error("Fehler: 惰性变量 '%s' 不能赋值\n", name);
        
    } 
    else {
        var = resolve_alias(var);
    }
    free_value(&var->value);
    var->value = value;
}

static Value clone_kd_handle(const Value& src) {
    if (src.type != VAL_OBJECT) {
        // 如果不符，回退到普通复制（但通常不会发生）
        std::unordered_map<Scope*, Scope*> dummy;
        return copy_value_with_visited(src, dummy);
    }

    std::shared_ptr<KDDataSet>* orig_ptr = nullptr;
    for (int i = 0; i < src.obj_val.count; i++) {
        if (strcmp(src.obj_val.entries[i].key, "__zgr") == 0 &&
            (src.obj_val.entries[i].value.type == VAL_INT || 
             src.obj_val.entries[i].value.type == VAL_INT64)) {
            int64_t ptr_val = value_to_ll(src.obj_val.entries[i].value);
            orig_ptr = (std::shared_ptr<KDDataSet>*)ptr_val;
            break;
        }
    }

    if (!orig_ptr) {
        // 无法提取指针，回退到普通复制
        std::unordered_map<Scope*, Scope*> dummy;
        return copy_value_with_visited(src, dummy);
    }

    // 创建新的 shared_ptr 副本（共享底层 KDDataSet，但拥有独立的 shared_ptr 控制块）
    std::shared_ptr<KDDataSet>* new_ptr = new std::shared_ptr<KDDataSet>(*orig_ptr);

    // 构建新的嵌套对象
    ObjectEntry entries[1];
    entries[0].key = strdup("__zgr");
    entries[0].value = make_int64((int64_t)new_ptr);

    Value inner = make_object(entries, 1);
    
    // 释放临时条目（make_object 已复制内容）
    free(entries[0].key);
    free_value(&entries[0].value);
    
    return inner;
}

// 带 visited 的深拷贝，用于复制作用域时打破循环
static Value copy_value_with_visited(Value src, std::unordered_map<Scope*, Scope*>& visited) {
    Value dst;
    dst.type = src.type;
    switch (src.type) {
        case VAL_INT64:
            dst.int64_val = src.int64_val;
            break;
        case VAL_INT: {
            dst.big_int = (mpz_t*)malloc(sizeof(mpz_t));
            mpz_init_set(*dst.big_int, *src.big_int);
            break;
        }
        case VAL_FLOAT: {
            dst.mpf_val = (mpf_t*)malloc(sizeof(mpf_t));
            mpf_init(*dst.mpf_val);
            mpf_set(*dst.mpf_val, *src.mpf_val);
            break;
        }
        case VAL_STRING: {
            dst.str_len = src.str_len;
            dst.str_val = (char*)malloc(dst.str_len + 1);
            memcpy(dst.str_val, src.str_val, dst.str_len);
            dst.str_val[dst.str_len] = '\0';
            break;
        }
        case VAL_ARRAY:
            dst.arr_val.length = src.arr_val.length;
            dst.arr_val.elements = (Value*)malloc(dst.arr_val.length * sizeof(Value));
            for (int i = 0; i < dst.arr_val.length; i++)
                dst.arr_val.elements[i] = copy_value_with_visited(src.arr_val.elements[i], visited);
            break;
        case VAL_OBJECT:
            dst.obj_val.count = src.obj_val.count;
            dst.obj_val.entries = (ObjectEntry*)malloc(dst.obj_val.count * sizeof(ObjectEntry));
            for (int i = 0; i < dst.obj_val.count; i++) {
                dst.obj_val.entries[i].key = strdup(src.obj_val.entries[i].key);
                if (strcmp(src.obj_val.entries[i].key, "__kd_daten") == 0) {
                    // 特殊处理 KD 数据集句柄，避免共享指针
                    dst.obj_val.entries[i].value = clone_kd_handle(src.obj_val.entries[i].value);
                } else {
                    dst.obj_val.entries[i].value = copy_value_with_visited(src.obj_val.entries[i].value, visited);
                }
            }
            break;
        case VAL_FUNCTION:
            dst.func_val.name = src.func_val.name ? strdup(src.func_val.name) : NULL;
            dst.func_val.param_count = src.func_val.param_count;
            dst.func_val.return_type = copy_type_node(src.func_val.return_type);
        
            if (src.func_val.params != NULL && src.func_val.param_count > 0) {
                dst.func_val.params = (char**)malloc(
                    (size_t)dst.func_val.param_count * sizeof(char*));
                for (int i = 0; i < dst.func_val.param_count; i++)
                    dst.func_val.params[i] =
                        src.func_val.params[i] ? strdup(src.func_val.params[i]) : NULL;
            } else {
                dst.func_val.params = NULL;
            }
        
            // body / closure 都可能为 NULL（编译期函数值没有 AST）
            dst.func_val.body = src.func_val.body ? copy_ast(src.func_val.body) : NULL;
            dst.func_val.closure_scope = src.func_val.closure_scope
                ? copy_scope_chain(src.func_val.closure_scope, visited)
                : NULL;
        
            dst.func_val.is_memoized = src.func_val.is_memoized;
            dst.func_val.is_async    = src.func_val.is_async;
            dst.func_val.global_scope= src.func_val.global_scope;
            dst.func_val.is_rule     = src.func_val.is_rule;
            dst.func_val.vararg_name = src.func_val.vararg_name
                                        ? strdup(src.func_val.vararg_name) : NULL;
        
            // ---- param_is_const：判空 ----
            if (src.func_val.param_is_const && src.func_val.param_count > 0) {
                dst.func_val.param_is_const = (bool*)malloc(
                    (size_t)src.func_val.param_count * sizeof(bool));
                for (int i = 0; i < src.func_val.param_count; ++i)
                    dst.func_val.param_is_const[i] = src.func_val.param_is_const[i];
            } else {
                dst.func_val.param_is_const = NULL;
            }
        
            // ---- param_defaults：判空 ----
            if (src.func_val.param_defaults && src.func_val.param_count > 0) {
                dst.func_val.param_defaults = (ASTNode**)malloc(
                    (size_t)src.func_val.param_count * sizeof(ASTNode*));
                for (int i = 0; i < src.func_val.param_count; ++i)
                    dst.func_val.param_defaults[i] =
                        src.func_val.param_defaults[i]
                            ? copy_ast(src.func_val.param_defaults[i])
                            : nullptr;
            } else {
                dst.func_val.param_defaults = nullptr;
            }
        
            // ---- param_types：判空 ----
            if (src.func_val.param_types && src.func_val.param_count > 0) {
                dst.func_val.param_types = (TypeNode**)malloc(
                    (size_t)src.func_val.param_count * sizeof(TypeNode*));
                for (int i = 0; i < src.func_val.param_count; i++)
                    dst.func_val.param_types[i] =
                        copy_type_node(src.func_val.param_types[i]);
            } else {
                dst.func_val.param_types = nullptr;
            }
        
            dst.func_val.vararg_type  = copy_type_node(src.func_val.vararg_type);
            dst.func_val.is_stmt_func = src.func_val.is_stmt_func;
            dst.func_val.filename     = src.func_val.filename
                                        ? strdup(src.func_val.filename) : NULL;
        
            dst.func_val.compiled_idx = src.func_val.compiled_idx;
            break;
        case VAL_NULL: break;
        case VAL_FUTURE:
            dst.future_state.future_id = src.future_state.future_id;
            break;
        case VAL_POINTER:
            if (src.ptr_val.smart_target) {
                // 智能指针：复制 shared_ptr，增加引用计数
                dst.ptr_val.smart_target =
                    new std::shared_ptr<Value>(*src.ptr_val.smart_target);
                dst.ptr_val.raw_target = nullptr;
            } else {
                // 裸指针：浅拷贝（共享地址）
                dst.ptr_val.raw_target  = src.ptr_val.raw_target;
                dst.ptr_val.smart_target = nullptr;
            }
            dst.ptr_val.elem_type = copy_type_node(src.ptr_val.elem_type);
            dst.ptr_val.freed = src.ptr_val.freed;
            break;
        
    }
    return dst;
}

// 无参版本
static Scope* copy_scope_chain(Scope* scope) {
    std::unordered_map<Scope*, Scope*> visited;
    return copy_scope_chain(scope, visited);
}

// 带 visited 的复制作用域
static Scope* copy_scope_chain(Scope* scope, std::unordered_map<Scope*, Scope*>& visited) {
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    if (!scope) return NULL;
    if (scope == original_global_scope) return scope;
    auto it = visited.find(scope);
    if (it != visited.end()) return it->second;

    Scope* copy = (Scope*)calloc(1, sizeof(Scope));
    copy->id = 0;
    copy->var_count = scope->var_count;
    copy->vars = (Variable*)malloc(copy->var_count * sizeof(Variable));

    visited[scope] = copy;

    // 复制父作用域
    copy->parent = copy_scope_chain(scope->parent, visited);

    for (int i = 0; i < copy->var_count; i++) {
        Variable* src = &scope->vars[i];
        Variable* dst = &copy->vars[i];
        dst->name = strdup(src->name);
        dst->is_const = src->is_const;
        dst->is_lazy = src->is_lazy;
        dst->evaluated = src->evaluated;
        dst->init_expr = src->init_expr ? copy_ast(src->init_expr) : nullptr;
        dst->is_alias = src->is_alias;
        dst->alias_target = src->is_alias ? strdup(src->alias_target) : NULL;
        dst->type_annotation = src->type_annotation ? copy_type_node(src->type_annotation) : nullptr;

        if (src->is_lazy) {
            if (src->evaluated)
                dst->cached_value = copy_value_with_visited(src->cached_value, visited);
            else
                dst->cached_value = make_null();
            dst->value = make_null();
        } else {
            dst->value = copy_value_with_visited(src->value, visited);
            dst->cached_value = make_null();
            dst->evaluated = false;
            dst->init_expr = NULL;
        }
    }

    return copy;
}

static bool try_get_static_property(const std::string& key, Value& out) {
    // 1) 已求值的缓存
    {
        std::lock_guard<std::mutex> lock(static_props_mutex);
        auto it = static_props.find(key);
        if (it != static_props.end()) {
            out = copy_value(it->second);
            return true;
        }
    }
    // 2) 惰性待求值
    ASTNode* lazy_expr = nullptr;
    {
        std::lock_guard<std::mutex> lock(static_props_mutex);
        auto it = static_lazy_init.find(key);
        if (it == static_lazy_init.end()) return false;
        lazy_expr = it->second;
        static_lazy_init.erase(it);    // 先擦除，避免递归自引用死循环
    }
    // 3) 在锁外求值（eval_expr 可能重入 static_props_mutex）
    Value v = lazy_expr ? eval_expr(lazy_expr) : make_null();
    // 4) 缓存（竞态时以先写入者为准）
    {
        std::lock_guard<std::mutex> lock(static_props_mutex);
        auto it = static_props.find(key);
        if (it == static_props.end()) {
            static_props[key] = copy_value(v);
            out = copy_value(v);
        } else {
            out = copy_value(it->second);
        }
    }
    free_value(&v);
    return true;
}
 
Value copy_value(Value src) {
    std::unordered_map<Scope*, Scope*> visited;
    return copy_value_with_visited(src, visited);
}
 
Value get_var_value(const char* name) {
    Variable* var = get_var(name, false);
    if (!var) {
        // 如果变量未定义，但当前正在执行同名函数（递归），则返回该函数值
        if (current_func_name && strcmp(current_func_name, name) == 0) {
            return copy_value(*current_func_value);
        }
        kr_error("Fehler: 变量 '%s' 未在当前作用域声明\n", name);
        
    }
    var = resolve_alias(var);
    // 处理惰性变量
    if (var->is_lazy) {
        if (!var->evaluated) {
            Value v = eval_expr(var->init_expr);
            var->cached_value = copy_value(v);
            var->evaluated = true;
            free_value(&v);
        }
        return copy_value(var->cached_value);
    }
    // 如果变量值为 null，且当前函数名匹配，则返回当前函数值（用于递归）
    if (var->value.type == VAL_NULL && current_func_name && strcmp(current_func_name, name) == 0) {
        return copy_value(*current_func_value);
    }
    return copy_value(var->value);
}
 
/* ========== 函数定义存储 ========== */
struct Function {
    char* name;
    char** params;
    int param_count;
    ASTNode* body;
    Scope* closure_scope;
    bool is_memoized;
    void* cache;  // 指向哈希表
    bool is_async;
    bool global_scope;
    char* vararg_name;
    TypeNode* return_type;
    bool* param_is_const;
    ASTNode** param_defaults;
    TypeNode** param_types;
    TypeNode* vararg_type;
    bool called;
    bool is_stmt_func;
    char* filename;
};
 
Function* functions = NULL;
int func_count = 0;
 
Function* get_function(const char* name) {
    std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
    for (int i = 0; i < func_count; i++) {
        if (strcmp(functions[i].name, name) == 0)
            return &functions[i];
    }
    return NULL;
}
 
/* ========== AST 节点定义 ========== */
enum NodeType {
    NODE_PROGRAM, NODE_BLOCK, NODE_VAR_DECL, NODE_ASSIGN,
    NODE_PRINT, NODE_PRINT_NO_NEWLINE, NODE_INPUT, NODE_IF, NODE_WHILE,
    NODE_FUNC_DEF, NODE_FUNC_CALL, NODE_BINARY,
    NODE_NUMBER, NODE_FLOAT, NODE_VARIABLE, NODE_STRING,
    NODE_RETURN,
    NODE_ARRAY_LITERAL,
    NODE_ARRAY_ACCESS,
    NODE_ARRAY_LEN,
    NODE_STRING_ACCESS,
    NODE_STRING_LEN,
    NODE_NOT,
    NODE_LOGICAL_AND,
    NODE_LOGICAL_OR,
    NODE_ARRAY_ASSIGN,
    NODE_METHOD_CALL,
    NODE_EXPR_STMT,
    NODE_NULL,
    NODE_PRE_INC,
    NODE_PRE_DEC,
    NODE_POST_INC,
    NODE_POST_DEC,
    NODE_TERNARY,
    NODE_FOR,
    NODE_BREAK,
    NODE_CONTINUE,
    NODE_ARRAY_COMPOUND_ASSIGN,
    NODE_TRY,
    NODE_THROW,
    NODE_OBJECT_LITERAL,
    NODE_OBJECT_ACCESS,
    NODE_OBJECT_ASSIGN,
    NODE_OBJECT_COMPOUND_ASSIGN,
    NODE_FOREACH,
    NODE_NULL_COALESCE,      // ??
    NODE_PIPE,               // |>
    NODE_RANGE,              // start..end
    NODE_LIST_COMPREHENSION, // [ expr for var in collection if cond ]
    NODE_LAZY_VAR_DECL,
    NODE_SICHER,
    NODE_MEMOIZED_FUNC_DEF,
    NODE_SWAP_ASSIGN,
    NODE_IMPORT,
    NODE_STRING_INTERP,
    NODE_ENUM_DEF,       // aufz 枚举定义
    NODE_MATCH,          // 模式匹配
    NODE_ENUM_VARIANT,   // 枚举变体值（构造时使用）
    NODE_PATTERN_BIND,   // 变量绑定模式
    NODE_PATTERN_OBJECT, // 对象解构模式
    NODE_PATTERN_VARIANT, // 枚举变体匹配模式
    NODE_PATTERN_CONSTANT,
    NODE_ASYNC_FUNC_DEF,   // ac fkt
    NODE_AWAIT,            // warte expr
    NODE_KEY_BIND, 
    NODE_SCOPE_BLOCK,
    NODE_ALIAS_DECL,
    NODE_GLOBAL_BLOCK,
    NODE_DESTRUCTURE,
    NODE_RULE_DEF,
    NODE_CLASS_DEF,      // klass 定义
    NODE_NEW,            // neu 实例化
    NODE_METHOD_DEF,     // methode 定义（内部使用，可合并到 NODE_CLASS_DEF）
    NODE_SUPER_CALL,     // ober(...) 构造函数调用
    NODE_THIS,            // dies 表达式
    NODE_PRINT_WITH_LINE,
    NODE_DEGREE,          // 度数转换（后缀一元）
    NODE_FACTORIAL,       // 阶乘（后缀一元）
    NODE_DOUBLE_FACTORIAL,
    NODE_CMP_THREE_WAY,   // <=> 三向比较
    NODE_CONCAT,          // ## 字符串拼接
    NODE_PRINT_MULTI,               // zeig 多参数，末尾换行
    NODE_PRINT_NO_NEWLINE_MULTI,    // schr 多参数，末尾不换行
    NODE_UMF_DEF,
    NODE_DESTRUCTURE_ASSIGN,  // 解构赋值语句
    NODE_DO_WHILE,
    NODE_REGEX_LITERAL,
    NODE_MULTI_ASSIGN,
    NODE_SPREAD_ARRAY,
    NODE_SPREAD_OBJECT,
    NODE_SPREAD_ARG,
    NODE_PATTERN_OR,
    NODE_MARK_USED,
    NODE_MARK_ALL_USED,
    NODE_BITWISE_NOT,
    NODE_TYPE_DEF,
    NODE_STRUCT_DEF,
    NODE_UNION_DEF,
    NODE_BITWISE_OR,
    NODE_BITWISE_AND,
    NODE_SHIFT_LEFT,
    NODE_SHIFT_RIGHT,
    NODE_OBJECT_COMPREHENSION,
    NODE_UMF_IMPORT,
};

struct ASTNode {
    NodeType type;
    int line;
    int col;
    size_t string_len;
    union {
        struct { ASTNode** stmts; int count; } block;
        struct { char* name; ASTNode* expr; int is_const; TypeNode* type_annotation; bool global; bool is_alias; int access_modifier; bool is_static_prop; } var_decl;
        struct { char* name; ASTNode* expr; bool global; } assign;
        struct { ASTNode* expr; } print;
        struct { char* name; ASTNode** args; int arg_count; ASTNode* multiline_expr; int flags; } input;
        struct { ASTNode* cond; ASTNode* then_block; ASTNode** else_ifs; int else_if_count; ASTNode* else_block; } if_stmt;
        struct { ASTNode* cond; ASTNode* body; } while_stmt;
        struct { char* name; char** params; int param_count; ASTNode* body; bool is_memoized; bool global_scope;
                 TypeNode* return_type; bool is_static; char* vararg_name; bool* param_is_const; ASTNode** param_defaults;
                 TypeNode** param_types; TypeNode* vararg_type; bool is_stmt_func; } func_def;
        struct { char* name; ASTNode* func_expr; ASTNode** args; int arg_count; } func_call;
        struct { ASTNode* left; ASTNode* right; char op; } binary;
        char* number_str;   // 整数常量字符串
        char* float_str;    // 浮点数常量字符串
        char* string;
        char* var_name;
        struct { ASTNode* expr; } ret;
        struct { ASTNode** elems; int count; } array_lit;
        struct { ASTNode* array; ASTNode* index; } array_access;
        struct { ASTNode* array; } array_len;
        struct { ASTNode* str; ASTNode* index; } string_access;
        struct { ASTNode* str; } string_len;
        struct { ASTNode* expr; } not_expr;
        struct { ASTNode* left; ASTNode* right; } logical_and;
        struct { ASTNode* left; ASTNode* right; } logical_or;
        struct { ASTNode* left; ASTNode* index; ASTNode* expr; } array_assign;
        struct { ASTNode* left; ASTNode* index; char op; ASTNode* rhs; } array_compound_assign;
        struct { ASTNode* obj; char* method; ASTNode** args; int arg_count; bool is_optional; } method_call;
        struct { ASTNode* expr; } expr_stmt;
        struct { ASTNode* operand; } inc_dec;
        struct { ASTNode* cond; ASTNode* true_expr; ASTNode* false_expr; } ternary;
        struct { ASTNode* init; ASTNode* cond; ASTNode* update; ASTNode* body; } for_stmt;
        struct {
            ASTNode** key_exprs;   // 键表达式节点（变量或字符串）
            ASTNode** vals;
            ASTNode** spreads;
            int count;
            int spread_count;
        } object_lit;
        struct { ASTNode* obj; char* key; ASTNode* value; } object_assign;
        struct { ASTNode* obj; char* key; char op; ASTNode* rhs; } object_compound_assign;
        struct { char* name; ASTNode* expr; bool global; } lazy_var_decl;
        struct { ASTNode* expr; ASTNode* line; } print_with_line;
        struct { ASTNode* body; ASTNode* cond; } do_while;
        struct {
            ASTNode* expr;
            ASTNode* msg_expr;   // 自定义错误消息表达式，若为 NULL 则使用默认
        } sicher;
        struct {
            ASTNode* expr;
            ASTNode* timeout;   // 超时表达式（毫秒），NULL 表示无超时
            ASTNode* fallback;  // 超时/失败时的备用表达式，NULL 表示无备用
        } await;
         struct {
            ASTNode* obj;
            char* key;
            bool is_optional;
        } object_access;
        struct { ASTNode* obj; char* key; ASTNode* expr; };
        struct {
            ASTNode* try_body;
            char* catch_var;
            ASTNode* catch_body;
            ASTNode* finally_body;
        }  try_stmt;
        struct {
            ASTNode* expr;
        } throw_expr;
        struct {
            char* key_var;      // 第一个变量（总是存在）
            char* value_var;    // 第二个变量（可为 NULL）
            ASTNode* collection;
            ASTNode* body;
        } foreach;
        struct {
            ASTNode* left;
            ASTNode* right;
        } null_coalesce;
        struct {
            ASTNode* left;
            ASTNode* right;
        } pipe;
        struct {
            ASTNode* start;
            ASTNode* end;
            ASTNode* step;
        } range;
        struct {
            ASTNode* expr;
            char* var_name;
            ASTNode* collection;
            ASTNode* cond;
        } list_comp;
        struct {
            char* name;
            char** params;
            int param_count;
            ASTNode* body;
            // 缓存结构将在执行时动态维护
        } memoized_func_def;
        struct {
            ASTNode* left;
            ASTNode* right;
            bool global;
        } swap;
        struct {
            char* filename;
            char* alias;        // 可为 NULL
            bool has_quote; 
            ASTNode* module_ast;
        } import;
        struct {
            ASTNode** fragments;   // 每个片段可以是 NODE_STRING 或任何表达式
            int count;
        } string_interp;
        struct {
            char* name;
            char** variants;              // 变体名称数组
            int* variant_param_counts;    // 每个变体的参数个数
            int variant_count;
        } enum_def;
        struct {
            ASTNode* expr;               // 待匹配的表达式
            MatchBranch* branches;
            int branch_count;
        } match;
        
        struct {
            char* name;                  // 绑定的变量名
        } pattern_bind;
        
        struct {
            char** keys;                 // 需要解构的键名
            int count;
        } pattern_object;
        
        struct {
            char* tag;                   // 变体标签
            char** params;               // 绑定的参数变量名
            int param_count;
        } pattern_variant;
        struct {
            Value constant;        // 存储常量值（复制）
        } pattern_constant;
        struct {
            char* key;       // 按键字符串
            ASTNode* body;   // 代码块
        } key_bind;
        struct {
            char* name;      // 别名名称
            char* target;    // 目标变量名
            bool global;     // 是否为全局别名
        } alias_decl;
        struct {
            char** names;      // 变量名列表
            int count;         // 变量个数
            ASTNode* expr;     // 右侧表达式
            bool is_const;     // 是否为常量声明（das）
            char* rest_name;
        } destructure;
        struct {
            char* name;
            char* parent;
            int access_modifier; 
            char** ctor_params;
            int ctor_param_count;
            TypeNode** ctor_param_types;
            int ctor_param_type_count;
            ASTNode* ctor_body;
            bool is_static_class;
            ASTNode** ctor_defaults;   // 默认值表达式数组
            int ctor_default_count;    // 默认值个数（=参数个数）
            struct {
                char** names;
                char*** param_lists;
                TypeNode*** param_types;
                int* param_counts;
                ASTNode** bodies;
                bool* is_static;
                int* access;
                TypeNode** return_types;
                int count;
                char** vararg_names;
                TypeNode** vararg_types;
                bool* is_stmt_func;
            } methods;
            struct {
                char** names;
                TypeNode** types;
                ASTNode** default_exprs;
                bool* is_const;
                bool* is_static;
                bool* is_lazy;
                int* access;
                int count;
            } properties;
        } class_def;
        
        struct {
            char* class_name;
            ASTNode** args;
            int arg_count;
        } new_expr;
        
        struct {
            ASTNode** args;
            int arg_count;
        } super_call;

        struct {
            TypeNode* inner_type;
        } optional_type;

        struct {
            ASTNode** exprs;
            int count;
        } print_multi;

        struct {
            char* name;
            char* parent_name;
            ASTNode* body;
        } umf_def;

        struct {
            char* pattern;
            char* flags;
        } regex_lit;

        struct {
            char** left_names;      // 左侧变量名列表
            int left_count;
            ASTNode** right_exprs;  // 右侧表达式列表
            int right_count;
        } multi_assign;

        struct {
            ASTNode* obj;    // 被切片的对象（字符串或数组）
            ASTNode* start;  // 起始索引表达式（可为 NULL 表示省略）
            ASTNode* end;    // 结束索引表达式（可为 NULL 表示省略）
        } slice;

        struct {
            ASTNode* expr;      // 要展开的表达式
        } spread;

        struct {
            ASTNode** patterns;
            int count;
        } pattern_or;

        struct {
            char** names;
            int count;
        } mark_used;

        struct {
            char* name;
            ASTNode** members;
            int member_count;
        } type_def;
        struct {
            char* name;
            StructField* fields;
            int field_count;
        } struct_def;
        struct {
            char* name;
            StructField* common_fields;  // 公共字段（可为空）
            int common_count;
            UnionVariant* variants;
            int variant_count;
        } union_def;
        struct {
            ASTNode* key_expr;      // 键表达式
            ASTNode* value_expr;    // 值表达式
            char* var_name;         // 第一个循环变量
            char* value_var;        // 第二个循环变量
            ASTNode* collection;    // 集合表达式
            ASTNode* cond;          // 过滤条件
        } object_comp;
        struct {
            char* name;      // 命名空间名
        } umf_import;
        struct {
            int levels;   // 跳出/继续的层数，默认 1
        } break_stmt;
    } data;
};

struct RuleState {
    std::thread thread;
    std::mutex mtx;
    Value cached_value;
    std::string usage;
    std::atomic<bool> running;
    int iteration;
    Value* args;
    int arg_count;
    ASTNode* body;
    char** param_names;
    int param_count;
    Scope* closure_scope;

    ~RuleState() {
        if (thread.joinable()) thread.join();
        free_ast(body);
        for (int i = 0; i < param_count; i++) free(param_names[i]);
        free(param_names);
        for (int i = 0; i < arg_count; i++) free_value(&args[i]);
        free(args);
        free_scope_chain(closure_scope);
        free_value(&cached_value);
    }
};
 
ASTNode* new_node(NodeType type, int line, int col) {
    ASTNode* n = (ASTNode*)calloc(1, sizeof(ASTNode));
    n->type = type;
    n->line = line;
    n->col = col;
    return n;
}

ASTNode* new_node(NodeType type) {
    int line, col;
    if (g_in_expr_depth > 0) {
        // 表达式内部：使用最近消费的 token 位置
        line = g_last_token_line;
        col  = g_last_token_col;
    } else {
        // 语句层面：使用语句起始位置
        line = g_stmt_start_line;
        col  = g_stmt_start_col;
    }
    // 若上述位置仍为 0（例如未设置），则回退到 g_last_token
    if (line == 0) line = g_last_token_line;
    if (col == 0)  col  = g_last_token_col;
    return new_node(type, line, col);
}
 
 void free_ast(ASTNode* node) {
     if (!node) return;
     switch (node->type) {
         case NODE_PROGRAM: case NODE_BLOCK:
             for (int i = 0; i < node->data.block.count; i++) free_ast(node->data.block.stmts[i]);
             free(node->data.block.stmts); break;
         case NODE_VAR_DECL:
             free(node->data.var_decl.name);
             free_ast(node->data.var_decl.expr);
             free_type_node(node->data.var_decl.type_annotation);
             break;
         case NODE_ASSIGN: free(node->data.assign.name); free_ast(node->data.assign.expr); break;
         case NODE_PRINT: free_ast(node->data.print.expr); break;
         case NODE_INPUT:
            free(node->data.input.name);
            for (int i = 0; i < node->data.input.arg_count; i++)
                free_ast(node->data.input.args[i]);
            free(node->data.input.args);
            break;
         case NODE_IF:
             free_ast(node->data.if_stmt.cond); free_ast(node->data.if_stmt.then_block);
             for (int i = 0; i < node->data.if_stmt.else_if_count; i++) free_ast(node->data.if_stmt.else_ifs[i]);
             free(node->data.if_stmt.else_ifs); free_ast(node->data.if_stmt.else_block); break;
         case NODE_WHILE: free_ast(node->data.while_stmt.cond); free_ast(node->data.while_stmt.body); break;
         case NODE_RULE_DEF:
         case NODE_FUNC_DEF:
             free(node->data.func_def.name);
             for (int i = 0; i < node->data.func_def.param_count; i++)
                 free(node->data.func_def.params[i]);
             free(node->data.func_def.params);
             free_ast(node->data.func_def.body);
             free_type_node(node->data.func_def.return_type);
             free(node->data.func_def.vararg_name);
             free(node->data.func_def.param_is_const);
             for (int i = 0; i < node->data.func_def.param_count; i++)
                 free_ast(node->data.func_def.param_defaults[i]);
             free(node->data.func_def.param_defaults);
             if (node->data.func_def.param_types) {
                 for (int i = 0; i < node->data.func_def.param_count; ++i)
                     free_type_node(node->data.func_def.param_types[i]);
                 free(node->data.func_def.param_types);
             }
             free_type_node(node->data.func_def.vararg_type);
             break;
         case NODE_FUNC_CALL:
             if (node->data.func_call.name) free(node->data.func_call.name);
             if (node->data.func_call.func_expr) free_ast(node->data.func_call.func_expr);
             for (int i = 0; i < node->data.func_call.arg_count; i++)
                 free_ast(node->data.func_call.args[i]);
             free(node->data.func_call.args);
             break;
         case NODE_BINARY:
         case NODE_CMP_THREE_WAY:
         case NODE_CONCAT: 
             free_ast(node->data.binary.left); free_ast(node->data.binary.right); break;
         case NODE_NUMBER: free(node->data.number_str); break;
         case NODE_VARIABLE: free(node->data.var_name); break;
         case NODE_STRING: free(node->data.string); break;
         case NODE_RETURN: free_ast(node->data.ret.expr); break;
         case NODE_ARRAY_LITERAL:
             for (int i = 0; i < node->data.array_lit.count; i++) free_ast(node->data.array_lit.elems[i]);
             free(node->data.array_lit.elems); break;
         case NODE_ARRAY_ACCESS: free_ast(node->data.array_access.array); free_ast(node->data.array_access.index); break;
         case NODE_ARRAY_LEN: free_ast(node->data.array_len.array); break;
         case NODE_STRING_ACCESS: free_ast(node->data.string_access.str); free_ast(node->data.string_access.index); break;
         case NODE_STRING_LEN: free_ast(node->data.string_len.str); break;
         case NODE_NOT: free_ast(node->data.not_expr.expr); break;
         case NODE_LOGICAL_AND: free_ast(node->data.logical_and.left); free_ast(node->data.logical_and.right); break;
         case NODE_LOGICAL_OR: free_ast(node->data.logical_or.left); free_ast(node->data.logical_or.right); break;
         case NODE_ARRAY_ASSIGN:
            free_ast(node->data.array_assign.left);
            free_ast(node->data.array_assign.index);
            free_ast(node->data.array_assign.expr);
            break;
         case NODE_METHOD_CALL:
             free_ast(node->data.method_call.obj);
             free(node->data.method_call.method);
             for (int i = 0; i < node->data.method_call.arg_count; i++) free_ast(node->data.method_call.args[i]);
             free(node->data.method_call.args);
             break;
         case NODE_EXPR_STMT:
             free_ast(node->data.expr_stmt.expr);
             break;
         case NODE_NULL:
             break;
         case NODE_PRE_INC: case NODE_PRE_DEC: case NODE_POST_INC: case NODE_POST_DEC: case NODE_DEGREE: case NODE_FACTORIAL: case NODE_BITWISE_NOT:
             free_ast(node->data.inc_dec.operand);
             break;
         case NODE_TERNARY:
             free_ast(node->data.ternary.cond);
             free_ast(node->data.ternary.true_expr);
             free_ast(node->data.ternary.false_expr);
             break;
         case NODE_FOR:
             free_ast(node->data.for_stmt.init);
             free_ast(node->data.for_stmt.cond);
             free_ast(node->data.for_stmt.update);
             free_ast(node->data.for_stmt.body);
             break;
         case NODE_BREAK: case NODE_CONTINUE:
             break;
         case NODE_ARRAY_COMPOUND_ASSIGN:
             free_ast(node->data.array_compound_assign.left);
             free_ast(node->data.array_compound_assign.index);
             free_ast(node->data.array_compound_assign.rhs);
             break;
         case NODE_TRY:
             free_ast(node->data.try_stmt.try_body);
             free(node->data.try_stmt.catch_var);
             free_ast(node->data.try_stmt.catch_body);
             free_ast(node->data.try_stmt.finally_body);
             break;
         case NODE_THROW:
             free_ast(node->data.throw_expr.expr);
             break;
         case NODE_OBJECT_LITERAL:
             for (int i = 0; i < node->data.object_lit.count; i++) {
                 free_ast(node->data.object_lit.key_exprs[i]);
                 free_ast(node->data.object_lit.vals[i]);
             }
             free(node->data.object_lit.key_exprs);
             free(node->data.object_lit.vals);
             for (int i = 0; i < node->data.object_lit.spread_count; i++)
                 free_ast(node->data.object_lit.spreads[i]);
             free(node->data.object_lit.spreads);
             break;
         case NODE_OBJECT_ACCESS:
             free_ast(node->data.object_access.obj);
             free(node->data.object_access.key);
             break;
         case NODE_OBJECT_ASSIGN:
             free_ast(node->data.object_assign.obj);
             free(node->data.object_assign.key);
             free_ast(node->data.object_assign.value);
             break;
        case NODE_OBJECT_COMPOUND_ASSIGN:
            free_ast(node->data.object_compound_assign.obj);
            free(node->data.object_compound_assign.key);
            free_ast(node->data.object_compound_assign.rhs);
            break;
         case NODE_FOREACH:
             free(node->data.foreach.key_var);
             if (node->data.foreach.value_var) free(node->data.foreach.value_var);
             free_ast(node->data.foreach.collection);
             free_ast(node->data.foreach.body);
             break;
         case NODE_NULL_COALESCE:
             free_ast(node->data.null_coalesce.left);
             free_ast(node->data.null_coalesce.right);
             break;
         case NODE_RANGE:
             free_ast(node->data.range.start);
             free_ast(node->data.range.end);
             if (node->data.range.step) free_ast(node->data.range.step);
             break;
         case NODE_LIST_COMPREHENSION:
             free_ast(node->data.list_comp.expr);
             free(node->data.list_comp.var_name);
             free_ast(node->data.list_comp.collection);
             free_ast(node->data.list_comp.cond);
             break;
        case NODE_PIPE:
            free_ast(node->data.pipe.left);
            free_ast(node->data.pipe.right);
            break;
        case NODE_FLOAT: free(node->data.float_str); break;
        case NODE_LAZY_VAR_DECL:
            free(node->data.lazy_var_decl.name);
            free_ast(node->data.lazy_var_decl.expr);
            break;
        case NODE_SICHER:
            free_ast(node->data.sicher.expr);
            if (node->data.sicher.msg_expr) free_ast(node->data.sicher.msg_expr);
            break;
        case NODE_SWAP_ASSIGN:
            free_ast(node->data.swap.left);
            free_ast(node->data.swap.right);
            break;
        case NODE_MEMOIZED_FUNC_DEF:
            break;
        case NODE_IMPORT:
            free(node->data.import.filename);
            if (node->data.import.alias) free(node->data.import.alias);
            break;
        case NODE_STRING_INTERP:
            // 如果保留该节点，则释放 fragments；若不使用可忽略
            for (int i = 0; i < node->data.string_interp.count; i++)
                free_ast(node->data.string_interp.fragments[i]);
            free(node->data.string_interp.fragments);
            break;
        case NODE_MATCH:
            free_ast(node->data.match.expr);
            for (int i = 0; i < node->data.match.branch_count; i++) {
                free_ast(node->data.match.branches[i].pattern);
                free_ast(node->data.match.branches[i].guard);
                free_ast(node->data.match.branches[i].body);
            }
            free(node->data.match.branches);
            break;
        case NODE_PATTERN_BIND:
            free(node->data.pattern_bind.name);
            break;
        case NODE_PATTERN_OBJECT:
            for (int i = 0; i < node->data.pattern_object.count; i++)
                free(node->data.pattern_object.keys[i]);
            free(node->data.pattern_object.keys);
            break;
        case NODE_PATTERN_VARIANT:
            free(node->data.pattern_variant.tag);
            for (int i = 0; i < node->data.pattern_variant.param_count; i++)
                free(node->data.pattern_variant.params[i]);
            free(node->data.pattern_variant.params);
            break;
        case NODE_ENUM_DEF:
            free(node->data.enum_def.name);
            for (int i = 0; i < node->data.enum_def.variant_count; i++) {
                free(node->data.enum_def.variants[i]);
            }
            free(node->data.enum_def.variants);
            free(node->data.enum_def.variant_param_counts);
            break;
        case NODE_ENUM_VARIANT:
            // 该节点未使用，暂时空处理
            break;
        case NODE_PATTERN_CONSTANT:
            free_value(&node->data.pattern_constant.constant);
            break;
        case NODE_ASYNC_FUNC_DEF:
            free(node->data.func_def.name);
            for (int i = 0; i < node->data.func_def.param_count; i++) free(node->data.func_def.params[i]);
            free(node->data.func_def.params);
            free_ast(node->data.func_def.body);
            free_type_node(node->data.func_def.return_type);
            free(node->data.func_def.vararg_name);
            free(node->data.func_def.param_is_const);
            for (int i = 0; i < node->data.func_def.param_count; i++)
                free_ast(node->data.func_def.param_defaults[i]);
            free(node->data.func_def.param_defaults);
            if (node->data.func_def.param_types) {
                for (int i = 0; i < node->data.func_def.param_count; ++i)
                    free_type_node(node->data.func_def.param_types[i]);
                free(node->data.func_def.param_types);
            }
            free_type_node(node->data.func_def.vararg_type);
            break;
        case NODE_AWAIT:
            free_ast(node->data.await.expr);
            free_ast(node->data.await.timeout);
            free_ast(node->data.await.fallback);
            break;
        case NODE_KEY_BIND:
            free(node->data.key_bind.key);
            free_ast(node->data.key_bind.body);
            break;
        case NODE_SCOPE_BLOCK:
            for (int i = 0; i < node->data.block.count; i++) free_ast(node->data.block.stmts[i]);
            free(node->data.block.stmts);
            break;
        case NODE_ALIAS_DECL:
            free(node->data.alias_decl.name);
            free(node->data.alias_decl.target);
            break;
        case NODE_GLOBAL_BLOCK:
            for (int i = 0; i < node->data.block.count; i++) free_ast(node->data.block.stmts[i]);
            free(node->data.block.stmts);
            break;
        case NODE_DESTRUCTURE:
            for (int i = 0; i < node->data.destructure.count; i++)
                free(node->data.destructure.names[i]);
            free(node->data.destructure.names);
            free_ast(node->data.destructure.expr);
            break;
        case NODE_CLASS_DEF:
            free(node->data.class_def.name);
            free(node->data.class_def.parent);
            for (int i = 0; i < node->data.class_def.ctor_param_count; i++)
                free(node->data.class_def.ctor_params[i]);
            free(node->data.class_def.ctor_params);
            free_ast(node->data.class_def.ctor_body);
        
            // ---- 释放方法 ----
            for (int i = 0; i < node->data.class_def.methods.count; i++) {
                free(node->data.class_def.methods.names[i]);
                for (int j = 0; j < node->data.class_def.methods.param_counts[i]; j++)
                    free(node->data.class_def.methods.param_lists[i][j]);
                free(node->data.class_def.methods.param_lists[i]);
                free_ast(node->data.class_def.methods.bodies[i]);
                // 释放参数类型
                if (node->data.class_def.methods.param_types && node->data.class_def.methods.param_types[i]) {
                    for (int j = 0; j < node->data.class_def.methods.param_counts[i]; j++)
                        free_type_node(node->data.class_def.methods.param_types[i][j]);
                    free(node->data.class_def.methods.param_types[i]);
                }
                // 释放返回类型
                if (node->data.class_def.methods.return_types && node->data.class_def.methods.return_types[i])
                    free_type_node(node->data.class_def.methods.return_types[i]);
            }
            free(node->data.class_def.methods.names);
            free(node->data.class_def.methods.param_lists);
            free(node->data.class_def.methods.param_counts);
            free(node->data.class_def.methods.bodies);
            free(node->data.class_def.methods.is_static);
            free(node->data.class_def.properties.is_lazy);
            free(node->data.class_def.methods.access);
            free(node->data.class_def.methods.return_types);
            free(node->data.class_def.methods.param_types);

            if (node->data.class_def.methods.vararg_names) {
                for (int i = 0; i < node->data.class_def.methods.count; i++)
                    free(node->data.class_def.methods.vararg_names[i]);
                free(node->data.class_def.methods.vararg_names);
            }
            if (node->data.class_def.methods.vararg_types) {
                for (int i = 0; i < node->data.class_def.methods.count; i++)
                    free_type_node(node->data.class_def.methods.vararg_types[i]);
                free(node->data.class_def.methods.vararg_types);
            }
        
            // ---- 释放属性 ----
            for (int i = 0; i < node->data.class_def.properties.count; i++) {
                free(node->data.class_def.properties.names[i]);
                free_type_node(node->data.class_def.properties.types[i]);
                free_ast(node->data.class_def.properties.default_exprs[i]);
            }
            free(node->data.class_def.properties.names);
            free(node->data.class_def.properties.types);
            free(node->data.class_def.properties.default_exprs);
            free(node->data.class_def.properties.is_const);
            free(node->data.class_def.properties.is_static);
            free(node->data.class_def.properties.access);

            for (int i = 0; i < node->data.class_def.ctor_param_type_count; i++) {
                free_type_node(node->data.class_def.ctor_param_types[i]);
            }
            free(node->data.class_def.ctor_param_types);
            if (node->data.class_def.methods.is_stmt_func) {
                free(node->data.class_def.methods.is_stmt_func);
            }
            for (int i = 0; i < node->data.class_def.ctor_default_count; ++i)
                free_ast(node->data.class_def.ctor_defaults[i]);
            free(node->data.class_def.ctor_defaults);
            break;
        case NODE_NEW:
            free(node->data.new_expr.class_name);
            for (int i = 0; i < node->data.new_expr.arg_count; i++)
                free_ast(node->data.new_expr.args[i]);
            free(node->data.new_expr.args);
            break;
        case NODE_SUPER_CALL:
            for (int i = 0; i < node->data.super_call.arg_count; i++)
                free_ast(node->data.super_call.args[i]);
            free(node->data.super_call.args);
            break;
        case NODE_THIS:
            break; // 无动态内存
        case NODE_METHOD_DEF:
            break;
        case NODE_PRINT_WITH_LINE:
            free_ast(node->data.print_with_line.expr);
            free_ast(node->data.print_with_line.line);
            break;
        case NODE_PRINT_NO_NEWLINE:
            free_ast(node->data.print.expr);
            break;
        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI:
            for (int i = 0; i < node->data.print_multi.count; i++)
                free_ast(node->data.print_multi.exprs[i]);
            free(node->data.print_multi.exprs);
            break;
        case NODE_DOUBLE_FACTORIAL:
            free_ast(node->data.inc_dec.operand);
            break;
        case NODE_UMF_DEF:
            free(node->data.umf_def.name);
            if (node->data.umf_def.parent_name) free(node->data.umf_def.parent_name);
            free_ast(node->data.umf_def.body);
            break;
        case NODE_DESTRUCTURE_ASSIGN:
            for (int i = 0; i < node->data.destructure.count; i++)
                free(node->data.destructure.names[i]);
            free(node->data.destructure.names);
            free_ast(node->data.destructure.expr);
            free(node->data.destructure.rest_name);
            break;
        case NODE_DO_WHILE:
            free_ast(node->data.do_while.body);
            free_ast(node->data.do_while.cond);
            break;
        case NODE_REGEX_LITERAL:
            free(node->data.regex_lit.pattern);
            free(node->data.regex_lit.flags);
            break;
        case NODE_MULTI_ASSIGN:
            for (int i = 0; i < node->data.multi_assign.left_count; i++)
                free(node->data.multi_assign.left_names[i]);
            free(node->data.multi_assign.left_names);
            for (int i = 0; i < node->data.multi_assign.right_count; i++)
                free_ast(node->data.multi_assign.right_exprs[i]);
            free(node->data.multi_assign.right_exprs);
            break;
        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            free_ast(node->data.spread.expr);
            break;
        case NODE_PATTERN_OR:
            for (int i = 0; i < node->data.pattern_or.count; ++i)
                free_ast(node->data.pattern_or.patterns[i]);
            free(node->data.pattern_or.patterns);
            break;
        case NODE_MARK_USED:
            for (int i = 0; i < node->data.mark_used.count; ++i)
                free(node->data.mark_used.names[i]);
            free(node->data.mark_used.names);
            break;
        case NODE_MARK_ALL_USED:
            break;
        case NODE_TYPE_DEF:
            free(node->data.type_def.name);
            for (int i = 0; i < node->data.type_def.member_count; ++i)
                free_ast(node->data.type_def.members[i]);
            free(node->data.type_def.members);
            break;
            case NODE_STRUCT_DEF:
            free(node->data.struct_def.name);
            for (int i = 0; i < node->data.struct_def.field_count; i++) {
                free(node->data.struct_def.fields[i].name);
                free_type_node(node->data.struct_def.fields[i].type);
            }
            free(node->data.struct_def.fields);
            break;
        case NODE_UNION_DEF:
            free(node->data.union_def.name);
            for (int i = 0; i < node->data.union_def.common_count; i++) {
                free(node->data.union_def.common_fields[i].name);
                free_type_node(node->data.union_def.common_fields[i].type);
            }
            free(node->data.union_def.common_fields);
            for (int i = 0; i < node->data.union_def.variant_count; i++) {
                UnionVariant* v = &node->data.union_def.variants[i];
                free(v->name);
                if (v->param_count > 0) {
                    for (int j = 0; j < v->param_count; j++)
                        free_type_node(v->param_types[j]);
                    free(v->param_types);
                } else {
                    for (int j = 0; j < v->field_count; j++) {
                        free(v->named_fields[j].name);
                        free_type_node(v->named_fields[j].type);
                    }
                    free(v->named_fields);
                }
            }
            free(node->data.union_def.variants);
            break;
        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT:
            free_ast(node->data.binary.left);
            free_ast(node->data.binary.right);
            break;
        case NODE_OBJECT_COMPREHENSION:
            free_ast(node->data.object_comp.key_expr);
            free_ast(node->data.object_comp.value_expr);
            free(node->data.object_comp.var_name);
            if (node->data.object_comp.value_var) free(node->data.object_comp.value_var);
            free_ast(node->data.object_comp.collection);
            if (node->data.object_comp.cond) free_ast(node->data.object_comp.cond);
            break;
        case NODE_UMF_IMPORT:
            free(node->data.umf_import.name);
            break;
     }
     free(node);
 }

 ASTNode* copy_ast(ASTNode* node) {
    if (!node) return NULL;
    ASTNode* copy = new_node(node->type, node->line, node->col);
    // 根据类型复制各个字段（只复制必要的数据，指针指向新分配的内存）
    switch (node->type) {
        case NODE_PROGRAM:
        case NODE_BLOCK: {
            copy->data.block.count = node->data.block.count;
            copy->data.block.stmts = (ASTNode**)malloc(copy->data.block.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.block.count; i++)
                copy->data.block.stmts[i] = copy_ast(node->data.block.stmts[i]);
            break;
        }
        case NODE_VAR_DECL: {
            copy->data.var_decl.name = strdup(node->data.var_decl.name);
            copy->data.var_decl.expr = copy_ast(node->data.var_decl.expr);
            copy->data.var_decl.is_const = node->data.var_decl.is_const;
            copy->data.var_decl.global = node->data.var_decl.global;
            copy->data.var_decl.type_annotation = copy_type_node(node->data.var_decl.type_annotation);
            break;
        }
        case NODE_ASSIGN: {
            copy->data.assign.name = strdup(node->data.assign.name);
            copy->data.assign.expr = copy_ast(node->data.assign.expr);
            copy->data.assign.global = node->data.assign.global;
            break;
        }
        case NODE_PRINT: {
            copy->data.print.expr = copy_ast(node->data.print.expr);
            break;
        }
        case NODE_PRINT_WITH_LINE: {
            copy->data.print_with_line.expr = copy_ast(node->data.print_with_line.expr);
            copy->data.print_with_line.line = copy_ast(node->data.print_with_line.line);
            break;
        }
        case NODE_INPUT: {
            copy->data.input.name = strdup(node->data.input.name);
            copy->data.input.arg_count = node->data.input.arg_count;
            copy->data.input.flags = node->data.input.flags;
            copy->data.input.multiline_expr = copy_ast(node->data.input.multiline_expr);
            copy->data.input.args = (ASTNode**)malloc(copy->data.input.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.input.arg_count; i++)
                copy->data.input.args[i] = copy_ast(node->data.input.args[i]);
            break;
        }
        case NODE_IF: {
            copy->data.if_stmt.cond = copy_ast(node->data.if_stmt.cond);
            copy->data.if_stmt.then_block = copy_ast(node->data.if_stmt.then_block);
            copy->data.if_stmt.else_if_count = node->data.if_stmt.else_if_count;
            copy->data.if_stmt.else_ifs = (ASTNode**)malloc(copy->data.if_stmt.else_if_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.if_stmt.else_if_count; i++)
                copy->data.if_stmt.else_ifs[i] = copy_ast(node->data.if_stmt.else_ifs[i]);
            copy->data.if_stmt.else_block = copy_ast(node->data.if_stmt.else_block);
            break;
        }
        case NODE_WHILE: {
            copy->data.while_stmt.cond = copy_ast(node->data.while_stmt.cond);
            copy->data.while_stmt.body = copy_ast(node->data.while_stmt.body);
            break;
        }
        case NODE_RULE_DEF:
        case NODE_FUNC_DEF: {
            copy->data.func_def.name = node->data.func_def.name ? strdup(node->data.func_def.name) : NULL;
            copy->data.func_def.param_count = node->data.func_def.param_count;
            copy->data.func_def.params = (char**)malloc(copy->data.func_def.param_count * sizeof(char*));
            for (int i = 0; i < copy->data.func_def.param_count; i++)
                copy->data.func_def.params[i] = strdup(node->data.func_def.params[i]);
            copy->data.func_def.body = copy_ast(node->data.func_def.body);
            copy->data.func_def.is_memoized = node->data.func_def.is_memoized;
            copy->data.func_def.global_scope = node->data.func_def.global_scope;
            copy->data.func_def.return_type = copy_type_node(node->data.func_def.return_type);
            copy->data.func_def.vararg_name = node->data.func_def.vararg_name ? strdup(node->data.func_def.vararg_name) : NULL;
            copy->data.func_def.param_is_const = (bool*)malloc(node->data.func_def.param_count * sizeof(bool));
            copy->data.func_def.param_defaults = (ASTNode**)malloc(node->data.func_def.param_count * sizeof(ASTNode*));
            if (node->data.func_def.param_types) {
                copy->data.func_def.param_types = (TypeNode**)malloc(node->data.func_def.param_count * sizeof(TypeNode*));
                for (int i = 0; i < node->data.func_def.param_count; i++)
                    copy->data.func_def.param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
            } else {
                copy->data.func_def.param_types = nullptr;
            }
            for (int i = 0; i < node->data.func_def.param_count; i++) {
                copy->data.func_def.param_is_const[i] = node->data.func_def.param_is_const[i];
                copy->data.func_def.param_defaults[i] = copy_ast(node->data.func_def.param_defaults[i]);
            }
            copy->data.func_def.vararg_type = copy_type_node(node->data.func_def.vararg_type);
            break;
        }
        case NODE_FUNC_CALL: {
            copy->data.func_call.name = node->data.func_call.name ? strdup(node->data.func_call.name) : NULL;
            copy->data.func_call.func_expr = node->data.func_call.func_expr ? copy_ast(node->data.func_call.func_expr) : NULL;
            copy->data.func_call.arg_count = node->data.func_call.arg_count;
            copy->data.func_call.args = (ASTNode**)malloc(copy->data.func_call.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.func_call.arg_count; i++)
                copy->data.func_call.args[i] = copy_ast(node->data.func_call.args[i]);
            break;
        }
        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT: {
            copy->data.binary.left = copy_ast(node->data.binary.left);
            copy->data.binary.right = copy_ast(node->data.binary.right);
            copy->data.binary.op = node->data.binary.op;
            break;
        }
        case NODE_NUMBER: copy->data.number_str = strdup(node->data.number_str); break;
        case NODE_VARIABLE: copy->data.var_name = strdup(node->data.var_name); break;
        case NODE_STRING:
            copy->data.string = strdup(node->data.string); 
            copy->string_len  = node->string_len;
            break;
        case NODE_RETURN: copy->data.ret.expr = copy_ast(node->data.ret.expr); break;
        case NODE_ARRAY_LITERAL: {
            copy->data.array_lit.count = node->data.array_lit.count;
            copy->data.array_lit.elems = (ASTNode**)malloc(copy->data.array_lit.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.array_lit.count; i++)
                copy->data.array_lit.elems[i] = copy_ast(node->data.array_lit.elems[i]);
            break;
        }
        case NODE_ARRAY_ACCESS: {
            copy->data.array_access.array = copy_ast(node->data.array_access.array);
            copy->data.array_access.index = copy_ast(node->data.array_access.index);
            break;
        }
        case NODE_ARRAY_LEN: copy->data.array_len.array = copy_ast(node->data.array_len.array); break;
        case NODE_STRING_ACCESS: {
            copy->data.string_access.str = copy_ast(node->data.string_access.str);
            copy->data.string_access.index = copy_ast(node->data.string_access.index);
            break;
        }
        case NODE_STRING_LEN: copy->data.string_len.str = copy_ast(node->data.string_len.str); break;
        case NODE_NOT: copy->data.not_expr.expr = copy_ast(node->data.not_expr.expr); break;
        case NODE_LOGICAL_AND: {
            copy->data.logical_and.left = copy_ast(node->data.logical_and.left);
            copy->data.logical_and.right = copy_ast(node->data.logical_and.right);
            break;
        }
        case NODE_LOGICAL_OR: {
            copy->data.logical_or.left = copy_ast(node->data.logical_or.left);
            copy->data.logical_or.right = copy_ast(node->data.logical_or.right);
            break;
        }
        case NODE_ARRAY_ASSIGN: {
            copy->data.array_assign.left = copy_ast(node->data.array_assign.left);
            copy->data.array_assign.index = copy_ast(node->data.array_assign.index);
            copy->data.array_assign.expr = copy_ast(node->data.array_assign.expr);
            break;
        }
        case NODE_METHOD_CALL: {
            copy->data.method_call.obj = copy_ast(node->data.method_call.obj);
            copy->data.method_call.method = strdup(node->data.method_call.method);
            copy->data.method_call.arg_count = node->data.method_call.arg_count;
            copy->data.method_call.args = (ASTNode**)malloc(copy->data.method_call.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.method_call.arg_count; i++)
                copy->data.method_call.args[i] = copy_ast(node->data.method_call.args[i]);
            copy->data.method_call.is_optional = node->data.method_call.is_optional;
            break;
        }
        case NODE_EXPR_STMT: copy->data.expr_stmt.expr = copy_ast(node->data.expr_stmt.expr); break;
        case NODE_NULL: break;
        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
            copy->data.inc_dec.operand = copy_ast(node->data.inc_dec.operand);
            break;
        case NODE_TERNARY: {
            copy->data.ternary.cond = copy_ast(node->data.ternary.cond);
            copy->data.ternary.true_expr = copy_ast(node->data.ternary.true_expr);
            copy->data.ternary.false_expr = copy_ast(node->data.ternary.false_expr);
            break;
        }
        case NODE_FOR: {
            copy->data.for_stmt.init = copy_ast(node->data.for_stmt.init);
            copy->data.for_stmt.cond = copy_ast(node->data.for_stmt.cond);
            copy->data.for_stmt.update = copy_ast(node->data.for_stmt.update);
            copy->data.for_stmt.body = copy_ast(node->data.for_stmt.body);
            break;
        }
        case NODE_BREAK:
        case NODE_CONTINUE:
            copy->data.break_stmt.levels = node->data.break_stmt.levels;
            break;
        case NODE_ARRAY_COMPOUND_ASSIGN: {
            copy->data.array_compound_assign.left = copy_ast(node->data.array_compound_assign.left);
            copy->data.array_compound_assign.index = copy_ast(node->data.array_compound_assign.index);
            copy->data.array_compound_assign.op = node->data.array_compound_assign.op;
            copy->data.array_compound_assign.rhs = copy_ast(node->data.array_compound_assign.rhs);
            break;
        }
        case NODE_TRY: {
            copy->data.try_stmt.try_body = copy_ast(node->data.try_stmt.try_body);
            copy->data.try_stmt.catch_var = node->data.try_stmt.catch_var ? strdup(node->data.try_stmt.catch_var) : NULL;
            copy->data.try_stmt.catch_body = copy_ast(node->data.try_stmt.catch_body);
            copy->data.try_stmt.finally_body = copy_ast(node->data.try_stmt.finally_body);
            break;
        }
        case NODE_THROW: copy->data.throw_expr.expr = copy_ast(node->data.throw_expr.expr); break;
        case NODE_OBJECT_LITERAL: {
            copy->data.object_lit.count = node->data.object_lit.count;
            copy->data.object_lit.key_exprs = (ASTNode**)malloc(copy->data.object_lit.count * sizeof(ASTNode*));
            copy->data.object_lit.vals = (ASTNode**)malloc(copy->data.object_lit.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.object_lit.count; i++) {
                copy->data.object_lit.key_exprs[i] = copy_ast(node->data.object_lit.key_exprs[i]);
                copy->data.object_lit.vals[i] = copy_ast(node->data.object_lit.vals[i]);
            }
            copy->data.object_lit.spread_count = node->data.object_lit.spread_count;
            copy->data.object_lit.spreads = (ASTNode**)malloc(copy->data.object_lit.spread_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.object_lit.spread_count; i++)
                copy->data.object_lit.spreads[i] = copy_ast(node->data.object_lit.spreads[i]);
            break;
        }
        case NODE_OBJECT_ACCESS: {
            copy->data.object_access.obj = copy_ast(node->data.object_access.obj);
            copy->data.object_access.key = strdup(node->data.object_access.key);
            copy->data.object_access.is_optional = node->data.object_access.is_optional;
            break;
        }
        case NODE_OBJECT_ASSIGN: {
            copy->data.object_assign.obj = copy_ast(node->data.object_assign.obj);
            copy->data.object_assign.key = strdup(node->data.object_assign.key);
            copy->data.object_assign.value = copy_ast(node->data.object_assign.value);
            break;
        }
        case NODE_OBJECT_COMPOUND_ASSIGN: {
            copy->data.object_compound_assign.obj = copy_ast(node->data.object_compound_assign.obj);
            copy->data.object_compound_assign.key = strdup(node->data.object_compound_assign.key);
            copy->data.object_compound_assign.op  = node->data.object_compound_assign.op;
            copy->data.object_compound_assign.rhs = copy_ast(node->data.object_compound_assign.rhs);
            break;
        }
        case NODE_FOREACH: {
            copy->data.foreach.key_var = strdup(node->data.foreach.key_var);
            copy->data.foreach.value_var = node->data.foreach.value_var ? strdup(node->data.foreach.value_var) : NULL;
            copy->data.foreach.collection = copy_ast(node->data.foreach.collection);
            copy->data.foreach.body = copy_ast(node->data.foreach.body);
            break;
        }
        case NODE_NULL_COALESCE: {
            copy->data.null_coalesce.left = copy_ast(node->data.null_coalesce.left);
            copy->data.null_coalesce.right = copy_ast(node->data.null_coalesce.right);
            break;
        }
        case NODE_RANGE: {
            copy->data.range.start = copy_ast(node->data.range.start);
            copy->data.range.end = copy_ast(node->data.range.end);
            copy->data.range.step = copy_ast(node->data.range.step);
            break;
        }
        case NODE_LIST_COMPREHENSION: {
            copy->data.list_comp.expr = copy_ast(node->data.list_comp.expr);
            copy->data.list_comp.var_name = strdup(node->data.list_comp.var_name);
            copy->data.list_comp.collection = copy_ast(node->data.list_comp.collection);
            copy->data.list_comp.cond = copy_ast(node->data.list_comp.cond);
            break;
        }
        case NODE_PIPE:
            copy->data.pipe.left = copy_ast(node->data.pipe.left);
            copy->data.pipe.right = copy_ast(node->data.pipe.right);
            break;
        case NODE_FLOAT:
            copy->data.float_str = strdup(node->data.float_str); break;
            break;
        case NODE_LAZY_VAR_DECL:
            copy->data.lazy_var_decl.name = strdup(node->data.lazy_var_decl.name);
            copy->data.lazy_var_decl.expr = copy_ast(node->data.lazy_var_decl.expr);
            break;
        case NODE_SICHER:
            copy->data.sicher.expr = copy_ast(node->data.sicher.expr);
            copy->data.sicher.msg_expr = copy_ast(node->data.sicher.msg_expr);
            break;
        case NODE_SWAP_ASSIGN:
            copy->data.swap.left = copy_ast(node->data.swap.left);
            copy->data.swap.right = copy_ast(node->data.swap.right);
            copy->data.swap.global = node->data.swap.global;
            break;
        case NODE_MATCH:
            copy->data.match.expr = copy_ast(node->data.match.expr);
            copy->data.match.branch_count = node->data.match.branch_count;
            copy->data.match.branches = (MatchBranch*)malloc(copy->data.match.branch_count * sizeof(MatchBranch));
            for (int i = 0; i < copy->data.match.branch_count; i++) {
                copy->data.match.branches[i].pattern = copy_ast(node->data.match.branches[i].pattern);
                copy->data.match.branches[i].guard   = copy_ast(node->data.match.branches[i].guard);
                copy->data.match.branches[i].body = copy_ast(node->data.match.branches[i].body);
            }
            break;
        case NODE_PATTERN_BIND:
            copy->data.pattern_bind.name = strdup(node->data.pattern_bind.name);
            break;
        case NODE_PATTERN_OBJECT:
            copy->data.pattern_object.count = node->data.pattern_object.count;
            copy->data.pattern_object.keys = (char**)malloc(copy->data.pattern_object.count * sizeof(char*));
            for (int i = 0; i < copy->data.pattern_object.count; i++)
                copy->data.pattern_object.keys[i] = strdup(node->data.pattern_object.keys[i]);
            break;
        case NODE_PATTERN_VARIANT:
            copy->data.pattern_variant.tag = strdup(node->data.pattern_variant.tag);
            copy->data.pattern_variant.param_count = node->data.pattern_variant.param_count;
            copy->data.pattern_variant.params = (char**)malloc(copy->data.pattern_variant.param_count * sizeof(char*));
            for (int i = 0; i < copy->data.pattern_variant.param_count; i++)
                copy->data.pattern_variant.params[i] = strdup(node->data.pattern_variant.params[i]);
            break;   
        case NODE_ENUM_DEF:
            copy->data.enum_def.name = strdup(node->data.enum_def.name);
            copy->data.enum_def.variant_count = node->data.enum_def.variant_count;
            copy->data.enum_def.variants = (char**)malloc(copy->data.enum_def.variant_count * sizeof(char*));
            copy->data.enum_def.variant_param_counts = (int*)malloc(copy->data.enum_def.variant_count * sizeof(int));
            for (int i = 0; i < copy->data.enum_def.variant_count; i++) {
                copy->data.enum_def.variants[i] = strdup(node->data.enum_def.variants[i]);
                copy->data.enum_def.variant_param_counts[i] = node->data.enum_def.variant_param_counts[i];
            }
            break;
        case NODE_ENUM_VARIANT:
            break;
        case NODE_PATTERN_CONSTANT:
            copy->data.pattern_constant.constant = copy_value(node->data.pattern_constant.constant);
            break;
        case NODE_ASYNC_FUNC_DEF:
            copy->data.func_def.name = node->data.func_def.name ? strdup(node->data.func_def.name) : NULL;
            copy->data.func_def.param_count = node->data.func_def.param_count;
            copy->data.func_def.params = (char**)malloc(copy->data.func_def.param_count * sizeof(char*));
            for (int i = 0; i < copy->data.func_def.param_count; i++)
                copy->data.func_def.params[i] = strdup(node->data.func_def.params[i]);
            copy->data.func_def.body = copy_ast(node->data.func_def.body);
            copy->data.func_def.is_memoized = node->data.func_def.is_memoized;
            copy->data.func_def.global_scope = node->data.func_def.global_scope;
            copy->data.func_def.return_type = copy_type_node(node->data.func_def.return_type);
            copy->data.func_def.vararg_name = node->data.func_def.vararg_name ? strdup(node->data.func_def.vararg_name) : NULL;
            copy->data.func_def.param_is_const = (bool*)malloc(node->data.func_def.param_count * sizeof(bool));
            copy->data.func_def.param_defaults = (ASTNode**)malloc(node->data.func_def.param_count * sizeof(ASTNode*));
            if (node->data.func_def.param_types) {
                copy->data.func_def.param_types = (TypeNode**)malloc(node->data.func_def.param_count * sizeof(TypeNode*));
                for (int i = 0; i < node->data.func_def.param_count; i++)
                    copy->data.func_def.param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
            } else {
                copy->data.func_def.param_types = nullptr;
            }
            for (int i = 0; i < node->data.func_def.param_count; i++) {
                copy->data.func_def.param_is_const[i] = node->data.func_def.param_is_const[i];
                copy->data.func_def.param_defaults[i] = copy_ast(node->data.func_def.param_defaults[i]);
            }
            copy->data.func_def.vararg_type = copy_type_node(node->data.func_def.vararg_type);
            break;
        case NODE_AWAIT:
            copy->data.await.expr = copy_ast(node->data.await.expr);
            copy->data.await.timeout = copy_ast(node->data.await.timeout);
            copy->data.await.fallback = copy_ast(node->data.await.fallback);
            break;
        case NODE_STRING_INTERP: {
            copy->data.string_interp.count = node->data.string_interp.count;
            copy->data.string_interp.fragments = (ASTNode**)malloc(
                copy->data.string_interp.count * sizeof(ASTNode*)
            );
            for (int i = 0; i < copy->data.string_interp.count; i++)
                copy->data.string_interp.fragments[i] = copy_ast(node->data.string_interp.fragments[i]);
            break;
        }
        case NODE_KEY_BIND:
            copy->data.key_bind.key = strdup(node->data.key_bind.key);
            copy->data.key_bind.body = copy_ast(node->data.key_bind.body);
            break;
        case NODE_SCOPE_BLOCK: {
            copy->data.block.count = node->data.block.count;
            copy->data.block.stmts = (ASTNode**)malloc(copy->data.block.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.block.count; i++)
                copy->data.block.stmts[i] = copy_ast(node->data.block.stmts[i]);
            break;
        }
        case NODE_ALIAS_DECL:
            copy->data.alias_decl.name = strdup(node->data.alias_decl.name);
            copy->data.alias_decl.target = strdup(node->data.alias_decl.target);
            copy->data.alias_decl.global = node->data.alias_decl.global;
            break;
        case NODE_GLOBAL_BLOCK: {
            copy->data.block.count = node->data.block.count;
            copy->data.block.stmts = (ASTNode**)malloc(copy->data.block.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.block.count; i++)
                copy->data.block.stmts[i] = copy_ast(node->data.block.stmts[i]);
            break;
        }
        case NODE_DESTRUCTURE: {
            copy->data.destructure.count = node->data.destructure.count;
            copy->data.destructure.names = (char**)malloc(copy->data.destructure.count * sizeof(char*));
            for (int i = 0; i < copy->data.destructure.count; i++)
                copy->data.destructure.names[i] = strdup(node->data.destructure.names[i]);
            copy->data.destructure.expr = copy_ast(node->data.destructure.expr);
            copy->data.destructure.is_const = node->data.destructure.is_const;
            break;
        }
        case NODE_CLASS_DEF: {
            copy->data.class_def.name = strdup(node->data.class_def.name);
            copy->data.class_def.parent = node->data.class_def.parent ? strdup(node->data.class_def.parent) : NULL;
            copy->data.class_def.access_modifier = node->data.class_def.access_modifier;
            copy->data.class_def.ctor_param_count = node->data.class_def.ctor_param_count;
            copy->data.class_def.ctor_params = (char**)malloc(copy->data.class_def.ctor_param_count * sizeof(char*));
            for (int i = 0; i < copy->data.class_def.ctor_param_count; i++)
                copy->data.class_def.ctor_params[i] = strdup(node->data.class_def.ctor_params[i]);
            copy->data.class_def.ctor_body = copy_ast(node->data.class_def.ctor_body);
        
            // ---- 复制方法 ----
            copy->data.class_def.methods.count = node->data.class_def.methods.count;
            copy->data.class_def.methods.names = (char**)malloc(copy->data.class_def.methods.count * sizeof(char*));
            copy->data.class_def.methods.param_counts = (int*)malloc(copy->data.class_def.methods.count * sizeof(int));
            copy->data.class_def.methods.param_lists = (char***)malloc(copy->data.class_def.methods.count * sizeof(char**));
            copy->data.class_def.methods.bodies = (ASTNode**)malloc(copy->data.class_def.methods.count * sizeof(ASTNode*));
            copy->data.class_def.methods.is_static = (bool*)malloc(copy->data.class_def.methods.count * sizeof(bool));
            copy->data.class_def.methods.access = (int*)malloc(copy->data.class_def.methods.count * sizeof(int));
            copy->data.class_def.methods.return_types = (TypeNode**)malloc(copy->data.class_def.methods.count * sizeof(TypeNode*));
            copy->data.class_def.methods.param_types = (TypeNode***)malloc(copy->data.class_def.methods.count * sizeof(TypeNode**));

            copy->data.class_def.methods.vararg_names = (char**)malloc(copy->data.class_def.methods.count * sizeof(char*));
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.vararg_names[i] = node->data.class_def.methods.vararg_names[i] 
                                                                ? strdup(node->data.class_def.methods.vararg_names[i]) 
                                                                : NULL;
            }
            copy->data.class_def.methods.vararg_types = (TypeNode**)malloc(copy->data.class_def.methods.count * sizeof(TypeNode*));
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.vararg_types[i] = node->data.class_def.methods.vararg_types[i] 
                                                                ? copy_type_node(node->data.class_def.methods.vararg_types[i]) 
                                                                : NULL;
            }
        
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.names[i] = strdup(node->data.class_def.methods.names[i]);
                copy->data.class_def.methods.param_counts[i] = node->data.class_def.methods.param_counts[i];
                char** src_params = node->data.class_def.methods.param_lists[i];
                char** dst_params = (char**)malloc(copy->data.class_def.methods.param_counts[i] * sizeof(char*));
                for (int j = 0; j < copy->data.class_def.methods.param_counts[i]; j++)
                    dst_params[j] = strdup(src_params[j]);
                copy->data.class_def.methods.param_lists[i] = dst_params;
                copy->data.class_def.methods.bodies[i] = copy_ast(node->data.class_def.methods.bodies[i]);
                copy->data.class_def.methods.is_static[i] = node->data.class_def.methods.is_static[i];
                copy->data.class_def.methods.access[i] = node->data.class_def.methods.access[i];
                copy->data.class_def.methods.return_types[i] = node->data.class_def.methods.return_types[i]
                                                              ? copy_type_node(node->data.class_def.methods.return_types[i])
                                                              : nullptr;
        
                // 复制参数类型
                if (node->data.class_def.methods.param_types && node->data.class_def.methods.param_types[i]) {
                    copy->data.class_def.methods.param_types[i] = (TypeNode**)malloc(copy->data.class_def.methods.param_counts[i] * sizeof(TypeNode*));
                    for (int j = 0; j < copy->data.class_def.methods.param_counts[i]; j++)
                        copy->data.class_def.methods.param_types[i][j] = copy_type_node(node->data.class_def.methods.param_types[i][j]);
                } else {
                    copy->data.class_def.methods.param_types[i] = nullptr;
                }
            }
        
            // ---- 复制属性 ----
            copy->data.class_def.properties.count = node->data.class_def.properties.count;
            copy->data.class_def.properties.names = (char**)malloc(copy->data.class_def.properties.count * sizeof(char*));
            copy->data.class_def.properties.types = (TypeNode**)malloc(copy->data.class_def.properties.count * sizeof(TypeNode*));
            copy->data.class_def.properties.default_exprs = (ASTNode**)malloc(copy->data.class_def.properties.count * sizeof(ASTNode*));
            copy->data.class_def.properties.is_const = (bool*)malloc(copy->data.class_def.properties.count * sizeof(bool));
            copy->data.class_def.properties.is_static = (bool*)malloc(copy->data.class_def.properties.count * sizeof(bool));
            copy->data.class_def.properties.access = (int*)malloc(copy->data.class_def.properties.count * sizeof(int));
            for (int i = 0; i < copy->data.class_def.properties.count; i++) {
                copy->data.class_def.properties.names[i] = strdup(node->data.class_def.properties.names[i]);
                copy->data.class_def.properties.types[i] = node->data.class_def.properties.types[i]
                                                          ? copy_type_node(node->data.class_def.properties.types[i])
                                                          : nullptr;
                copy->data.class_def.properties.default_exprs[i] = copy_ast(node->data.class_def.properties.default_exprs[i]);
                copy->data.class_def.properties.is_const[i] = node->data.class_def.properties.is_const[i];
                copy->data.class_def.properties.is_static[i] = node->data.class_def.properties.is_static[i];
                copy->data.class_def.properties.access[i] = node->data.class_def.properties.access[i];
            }

            copy->data.class_def.ctor_param_type_count = node->data.class_def.ctor_param_type_count;
            copy->data.class_def.ctor_param_types = (TypeNode**)malloc(copy->data.class_def.ctor_param_type_count * sizeof(TypeNode*));
            for (int i = 0; i < copy->data.class_def.ctor_param_type_count; i++) {
                copy->data.class_def.ctor_param_types[i] = copy_type_node(node->data.class_def.ctor_param_types[i]);
            }
            copy->data.class_def.methods.is_stmt_func = (bool*)malloc(
                copy->data.class_def.methods.count * sizeof(bool));
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.is_stmt_func[i] = 
                    node->data.class_def.methods.is_stmt_func[i];
            }
            copy->data.class_def.is_static_class = node->data.class_def.is_static_class;
            
            copy->data.class_def.ctor_default_count = node->data.class_def.ctor_default_count;
            copy->data.class_def.ctor_defaults = (ASTNode**)malloc(
                copy->data.class_def.ctor_default_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.class_def.ctor_default_count; ++i)
                copy->data.class_def.ctor_defaults[i] = copy_ast(node->data.class_def.ctor_defaults[i]);
            copy->data.class_def.properties.is_lazy =
                (bool*)malloc(copy->data.class_def.properties.count * sizeof(bool));
            for (int i = 0; i < copy->data.class_def.properties.count; i++) {
                copy->data.class_def.properties.is_lazy[i] =
                    node->data.class_def.properties.is_lazy[i];
            }
            break;
        }
        case NODE_NEW: {
            copy->data.new_expr.class_name = strdup(node->data.new_expr.class_name);
            copy->data.new_expr.arg_count = node->data.new_expr.arg_count;
            copy->data.new_expr.args = (ASTNode**)malloc(copy->data.new_expr.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.new_expr.arg_count; i++)
                copy->data.new_expr.args[i] = copy_ast(node->data.new_expr.args[i]);
            break;
        }
        case NODE_SUPER_CALL: {
            copy->data.super_call.arg_count = node->data.super_call.arg_count;
            copy->data.super_call.args = (ASTNode**)malloc(copy->data.super_call.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.super_call.arg_count; i++)
                copy->data.super_call.args[i] = copy_ast(node->data.super_call.args[i]);
            break;
        }
        case NODE_THIS:
            break; // 无数据
        case NODE_PRINT_NO_NEWLINE:
            copy->data.print.expr = copy_ast(node->data.print.expr);
            break;
        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI: {
            copy->data.print_multi.count = node->data.print_multi.count;
            copy->data.print_multi.exprs = (ASTNode**)malloc(copy->data.print_multi.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.print_multi.count; i++)
                copy->data.print_multi.exprs[i] = copy_ast(node->data.print_multi.exprs[i]);
            break;
        }
        case NODE_DOUBLE_FACTORIAL:
            copy->data.inc_dec.operand = copy_ast(node->data.inc_dec.operand);
            break;
        case NODE_UMF_DEF: {
            copy->data.umf_def.name = strdup(node->data.umf_def.name);
            copy->data.umf_def.parent_name = node->data.umf_def.parent_name ? strdup(node->data.umf_def.parent_name) : NULL;
            copy->data.umf_def.body = copy_ast(node->data.umf_def.body);
            break;
        }
        case NODE_DESTRUCTURE_ASSIGN: {
            copy->data.destructure.count = node->data.destructure.count;
            copy->data.destructure.names = (char**)malloc(copy->data.destructure.count * sizeof(char*));
            for (int i = 0; i < copy->data.destructure.count; i++)
                copy->data.destructure.names[i] = strdup(node->data.destructure.names[i]);
            copy->data.destructure.expr = copy_ast(node->data.destructure.expr);
            copy->data.destructure.rest_name = node->data.destructure.rest_name ? strdup(node->data.destructure.rest_name) : nullptr;
            break;
        }
        case NODE_IMPORT:
            copy->data.import.filename = strdup(node->data.import.filename);
            copy->data.import.alias = node->data.import.alias ? strdup(node->data.import.alias) : nullptr;
            copy->data.import.has_quote = node->data.import.has_quote;
            copy->data.import.module_ast = nullptr;   // 运行时才加载
            break;
        case NODE_DO_WHILE: {
            copy->data.do_while.body = copy_ast(node->data.do_while.body);
            copy->data.do_while.cond = copy_ast(node->data.do_while.cond);
            break;
        }
        case NODE_REGEX_LITERAL:
            copy->data.regex_lit.pattern = strdup(node->data.regex_lit.pattern);
            copy->data.regex_lit.flags = strdup(node->data.regex_lit.flags);
            break;
        case NODE_MULTI_ASSIGN: {
            copy->data.multi_assign.left_count = node->data.multi_assign.left_count;
            copy->data.multi_assign.left_names = (char**)malloc(copy->data.multi_assign.left_count * sizeof(char*));
            for (int i = 0; i < copy->data.multi_assign.left_count; i++)
                copy->data.multi_assign.left_names[i] = strdup(node->data.multi_assign.left_names[i]);
            copy->data.multi_assign.right_count = node->data.multi_assign.right_count;
            copy->data.multi_assign.right_exprs = (ASTNode**)malloc(copy->data.multi_assign.right_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.multi_assign.right_count; i++)
                copy->data.multi_assign.right_exprs[i] = copy_ast(node->data.multi_assign.right_exprs[i]);
            break;
        }
        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            copy->data.spread.expr = copy_ast(node->data.spread.expr);
            break;
        case NODE_PATTERN_OR:
            copy->data.pattern_or.count = node->data.pattern_or.count;
            copy->data.pattern_or.patterns = (ASTNode**)malloc(copy->data.pattern_or.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.pattern_or.count; ++i)
                copy->data.pattern_or.patterns[i] = copy_ast(node->data.pattern_or.patterns[i]);
            break;
        case NODE_MARK_USED:
            copy->data.mark_used.count = node->data.mark_used.count;
            copy->data.mark_used.names = (char**)malloc(copy->data.mark_used.count * sizeof(char*));
            for (int i = 0; i < copy->data.mark_used.count; ++i)
                copy->data.mark_used.names[i] = strdup(node->data.mark_used.names[i]);
            break;
        case NODE_MARK_ALL_USED:
            break;
        case NODE_TYPE_DEF: {
            copy->data.type_def.name = strdup(node->data.type_def.name);
            copy->data.type_def.member_count = node->data.type_def.member_count;
            copy->data.type_def.members = (ASTNode**)malloc(
                copy->data.type_def.member_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.type_def.member_count; ++i)
                copy->data.type_def.members[i] = copy_ast(node->data.type_def.members[i]);
            break;
        }
        case NODE_STRUCT_DEF: {
            copy->data.struct_def.name = strdup(node->data.struct_def.name);
            copy->data.struct_def.field_count = node->data.struct_def.field_count;
            copy->data.struct_def.fields = (StructField*)malloc(copy->data.struct_def.field_count * sizeof(StructField));
            for (int i = 0; i < copy->data.struct_def.field_count; i++) {
                copy->data.struct_def.fields[i].name = strdup(node->data.struct_def.fields[i].name);
                copy->data.struct_def.fields[i].type = copy_type_node(node->data.struct_def.fields[i].type);
            }
            break;
        }
        case NODE_UNION_DEF: {
            copy->data.union_def.name = strdup(node->data.union_def.name);
            copy->data.union_def.common_count = node->data.union_def.common_count;
            copy->data.union_def.common_fields = (StructField*)malloc(copy->data.union_def.common_count * sizeof(StructField));
            for (int i = 0; i < copy->data.union_def.common_count; i++) {
                copy->data.union_def.common_fields[i].name = strdup(node->data.union_def.common_fields[i].name);
                copy->data.union_def.common_fields[i].type = copy_type_node(node->data.union_def.common_fields[i].type);
            }
            copy->data.union_def.variant_count = node->data.union_def.variant_count;
            copy->data.union_def.variants = (UnionVariant*)malloc(copy->data.union_def.variant_count * sizeof(UnionVariant));
            for (int i = 0; i < copy->data.union_def.variant_count; i++) {
                UnionVariant* sv = &node->data.union_def.variants[i];
                UnionVariant* dv = &copy->data.union_def.variants[i];
                dv->name = strdup(sv->name);
                dv->param_count = sv->param_count;
                if (dv->param_count > 0) {
                    dv->param_types = (TypeNode**)malloc(dv->param_count * sizeof(TypeNode*));
                    for (int j = 0; j < dv->param_count; j++)
                        dv->param_types[j] = copy_type_node(sv->param_types[j]);
                    dv->named_fields = NULL;
                    dv->field_count = 0;
                } else {
                    dv->param_types = NULL;
                    dv->field_count = sv->field_count;
                    if (dv->field_count > 0) {
                        dv->named_fields = (StructField*)malloc(dv->field_count * sizeof(StructField));
                        for (int j = 0; j < dv->field_count; j++) {
                            dv->named_fields[j].name = strdup(sv->named_fields[j].name);
                            dv->named_fields[j].type = copy_type_node(sv->named_fields[j].type);
                        }
                    } else {
                        dv->named_fields = NULL;
                    }
                }
            }
            break;
        }
        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT:
            copy->data.binary.left = copy_ast(node->data.binary.left);
            copy->data.binary.right = copy_ast(node->data.binary.right);
            break;
        case NODE_OBJECT_COMPREHENSION:
            copy->data.object_comp.key_expr = copy_ast(node->data.object_comp.key_expr);
            copy->data.object_comp.value_expr = copy_ast(node->data.object_comp.value_expr);
            copy->data.object_comp.var_name = strdup(node->data.object_comp.var_name);
            copy->data.object_comp.value_var = node->data.object_comp.value_var ? strdup(node->data.object_comp.value_var) : NULL;
            copy->data.object_comp.collection = copy_ast(node->data.object_comp.collection);
            copy->data.object_comp.cond = node->data.object_comp.cond ? copy_ast(node->data.object_comp.cond) : NULL;
            break;
        case NODE_BITWISE_NOT:
            copy->data.inc_dec.operand = copy_ast(node->data.inc_dec.operand);
            break;
        case NODE_UMF_IMPORT:
            copy->data.umf_import.name = strdup(node->data.umf_import.name);
            break;
        default:
            kr_error("copy_ast: 未知节点类型 %d\n", node->type);
            
    }
    return copy;
 }

 ASTNode* copy_ast_with_replacement(ASTNode* node, const std::unordered_map<std::string, ASTNode*>& replacements) {
    if (!node) return nullptr;
    if (node->type == NODE_VARIABLE) {
        auto it = replacements.find(node->data.var_name);
        if (it != replacements.end()) {
            return copy_ast_with_replacement(it->second, replacements);
        }
    }
    ASTNode* copy = new_node(node->type, node->line, node->col);
    switch (node->type) {
        case NODE_PROGRAM:
        case NODE_BLOCK: {
            copy->data.block.count = node->data.block.count;
            copy->data.block.stmts = (ASTNode**)malloc(copy->data.block.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.block.count; i++)
                copy->data.block.stmts[i] = copy_ast_with_replacement(node->data.block.stmts[i], replacements);
            break;
        }
        case NODE_VAR_DECL: {
            copy->data.var_decl.name = strdup(node->data.var_decl.name);
            copy->data.var_decl.expr = copy_ast_with_replacement(node->data.var_decl.expr, replacements);
            copy->data.var_decl.is_const = node->data.var_decl.is_const;
            copy->data.var_decl.global = node->data.var_decl.global;
            copy->data.var_decl.type_annotation = copy_type_node(node->data.var_decl.type_annotation);
            break;
        }
        case NODE_ASSIGN: {
            copy->data.assign.name = strdup(node->data.assign.name);
            copy->data.assign.expr = copy_ast_with_replacement(node->data.assign.expr, replacements);
            copy->data.assign.global = node->data.assign.global;
            break;
        }
        case NODE_PRINT: {
            copy->data.print.expr = copy_ast_with_replacement(node->data.print.expr, replacements);
            break;
        }
        case NODE_PRINT_WITH_LINE: {
            copy->data.print_with_line.expr = copy_ast_with_replacement(node->data.print_with_line.expr, replacements);
            copy->data.print_with_line.line = copy_ast_with_replacement(node->data.print_with_line.line, replacements);
            break;
        }
        case NODE_INPUT: {
            copy->data.input.name = strdup(node->data.input.name);
            copy->data.input.arg_count = node->data.input.arg_count;
            copy->data.input.flags = node->data.input.flags;
            copy->data.input.multiline_expr = copy_ast_with_replacement(node->data.input.multiline_expr, replacements);
            copy->data.input.args = (ASTNode**)malloc(copy->data.input.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.input.arg_count; i++)
                copy->data.input.args[i] = copy_ast_with_replacement(node->data.input.args[i], replacements);
            break;
        }
        case NODE_IF: {
            copy->data.if_stmt.cond = copy_ast_with_replacement(node->data.if_stmt.cond, replacements);
            copy->data.if_stmt.then_block = copy_ast_with_replacement(node->data.if_stmt.then_block, replacements);
            copy->data.if_stmt.else_if_count = node->data.if_stmt.else_if_count;
            copy->data.if_stmt.else_ifs = (ASTNode**)malloc(copy->data.if_stmt.else_if_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.if_stmt.else_if_count; i++)
                copy->data.if_stmt.else_ifs[i] = copy_ast_with_replacement(node->data.if_stmt.else_ifs[i], replacements);
            copy->data.if_stmt.else_block = copy_ast_with_replacement(node->data.if_stmt.else_block, replacements);
            break;
        }
        case NODE_WHILE: {
            copy->data.while_stmt.cond = copy_ast_with_replacement(node->data.while_stmt.cond, replacements);
            copy->data.while_stmt.body = copy_ast_with_replacement(node->data.while_stmt.body, replacements);
            break;
        }
        case NODE_RULE_DEF:
        case NODE_FUNC_DEF: {
            copy->data.func_def.name = node->data.func_def.name ? strdup(node->data.func_def.name) : NULL;
            copy->data.func_def.param_count = node->data.func_def.param_count;
            copy->data.func_def.params = (char**)malloc(copy->data.func_def.param_count * sizeof(char*));
            for (int i = 0; i < copy->data.func_def.param_count; i++)
                copy->data.func_def.params[i] = strdup(node->data.func_def.params[i]);
            copy->data.func_def.body = copy_ast_with_replacement(node->data.func_def.body, replacements);
            copy->data.func_def.is_memoized = node->data.func_def.is_memoized;
            copy->data.func_def.global_scope = node->data.func_def.global_scope;
            copy->data.func_def.return_type = copy_type_node(node->data.func_def.return_type);
            copy->data.func_def.vararg_name = node->data.func_def.vararg_name ? strdup(node->data.func_def.vararg_name) : NULL;
            copy->data.func_def.param_is_const = (bool*)malloc(node->data.func_def.param_count * sizeof(bool));
            copy->data.func_def.param_defaults = (ASTNode**)malloc(node->data.func_def.param_count * sizeof(ASTNode*));
            if (node->data.func_def.param_types) {
                copy->data.func_def.param_types = (TypeNode**)malloc(node->data.func_def.param_count * sizeof(TypeNode*));
                for (int i = 0; i < node->data.func_def.param_count; i++)
                    copy->data.func_def.param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
            } else {
                copy->data.func_def.param_types = nullptr;
            }
            for (int i = 0; i < node->data.func_def.param_count; i++) {
                copy->data.func_def.param_is_const[i] = node->data.func_def.param_is_const[i];
                copy->data.func_def.param_defaults[i] = copy_ast_with_replacement(node->data.func_def.param_defaults[i], replacements);
            }
            copy->data.func_def.vararg_type = copy_type_node(node->data.func_def.vararg_type);
            break;
        }
        case NODE_FUNC_CALL: {
            copy->data.func_call.name = node->data.func_call.name ? strdup(node->data.func_call.name) : NULL;
            copy->data.func_call.func_expr = node->data.func_call.func_expr ? copy_ast_with_replacement(node->data.func_call.func_expr, replacements) : NULL;
            copy->data.func_call.arg_count = node->data.func_call.arg_count;
            copy->data.func_call.args = (ASTNode**)malloc(copy->data.func_call.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.func_call.arg_count; i++)
                copy->data.func_call.args[i] = copy_ast_with_replacement(node->data.func_call.args[i], replacements);
            break;
        }
        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT: {
            copy->data.binary.left = copy_ast_with_replacement(node->data.binary.left, replacements);
            copy->data.binary.right = copy_ast_with_replacement(node->data.binary.right, replacements);
            copy->data.binary.op = node->data.binary.op;
            break;
        }
        case NODE_NUMBER: copy->data.number_str = strdup(node->data.number_str); break;
        case NODE_VARIABLE: copy->data.var_name = strdup(node->data.var_name); break;
        case NODE_STRING:
            copy->data.string = strdup(node->data.string); 
            copy->string_len  = node->string_len;
            break;
        case NODE_RETURN: copy->data.ret.expr = copy_ast_with_replacement(node->data.ret.expr, replacements); break;
        case NODE_ARRAY_LITERAL: {
            copy->data.array_lit.count = node->data.array_lit.count;
            copy->data.array_lit.elems = (ASTNode**)malloc(copy->data.array_lit.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.array_lit.count; i++)
                copy->data.array_lit.elems[i] = copy_ast_with_replacement(node->data.array_lit.elems[i], replacements);
            break;
        }
        case NODE_ARRAY_ACCESS: {
            copy->data.array_access.array = copy_ast_with_replacement(node->data.array_access.array, replacements);
            copy->data.array_access.index = copy_ast_with_replacement(node->data.array_access.index, replacements);
            break;
        }
        case NODE_ARRAY_LEN: copy->data.array_len.array = copy_ast_with_replacement(node->data.array_len.array, replacements); break;
        case NODE_STRING_ACCESS: {
            copy->data.string_access.str = copy_ast_with_replacement(node->data.string_access.str, replacements);
            copy->data.string_access.index = copy_ast_with_replacement(node->data.string_access.index, replacements);
            break;
        }
        case NODE_STRING_LEN: copy->data.string_len.str = copy_ast_with_replacement(node->data.string_len.str, replacements); break;
        case NODE_NOT: copy->data.not_expr.expr = copy_ast_with_replacement(node->data.not_expr.expr, replacements); break;
        case NODE_LOGICAL_AND: {
            copy->data.logical_and.left = copy_ast_with_replacement(node->data.logical_and.left, replacements);
            copy->data.logical_and.right = copy_ast_with_replacement(node->data.logical_and.right, replacements);
            break;
        }
        case NODE_LOGICAL_OR: {
            copy->data.logical_or.left = copy_ast_with_replacement(node->data.logical_or.left, replacements);
            copy->data.logical_or.right = copy_ast_with_replacement(node->data.logical_or.right, replacements);
            break;
        }
        case NODE_ARRAY_ASSIGN: {
            copy->data.array_assign.left = copy_ast_with_replacement(node->data.array_assign.left, replacements);
            copy->data.array_assign.index = copy_ast_with_replacement(node->data.array_assign.index, replacements);
            copy->data.array_assign.expr = copy_ast_with_replacement(node->data.array_assign.expr, replacements);
            break;
        }
        case NODE_METHOD_CALL: {
            copy->data.method_call.obj = copy_ast_with_replacement(node->data.method_call.obj, replacements);
            copy->data.method_call.method = strdup(node->data.method_call.method);
            copy->data.method_call.arg_count = node->data.method_call.arg_count;
            copy->data.method_call.args = (ASTNode**)malloc(copy->data.method_call.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.method_call.arg_count; i++)
                copy->data.method_call.args[i] = copy_ast_with_replacement(node->data.method_call.args[i], replacements);
            copy->data.method_call.is_optional = node->data.method_call.is_optional;
            break;
        }
        case NODE_EXPR_STMT: copy->data.expr_stmt.expr = copy_ast_with_replacement(node->data.expr_stmt.expr, replacements); break;
        case NODE_NULL: break;
        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
            copy->data.inc_dec.operand = copy_ast_with_replacement(node->data.inc_dec.operand, replacements);
            break;
        case NODE_TERNARY: {
            copy->data.ternary.cond = copy_ast_with_replacement(node->data.ternary.cond, replacements);
            copy->data.ternary.true_expr = copy_ast_with_replacement(node->data.ternary.true_expr, replacements);
            copy->data.ternary.false_expr = copy_ast_with_replacement(node->data.ternary.false_expr, replacements);
            break;
        }
        case NODE_FOR: {
            copy->data.for_stmt.init = copy_ast_with_replacement(node->data.for_stmt.init, replacements);
            copy->data.for_stmt.cond = copy_ast_with_replacement(node->data.for_stmt.cond, replacements);
            copy->data.for_stmt.update = copy_ast_with_replacement(node->data.for_stmt.update, replacements);
            copy->data.for_stmt.body = copy_ast_with_replacement(node->data.for_stmt.body, replacements);
            break;
        }
        case NODE_BREAK: case NODE_CONTINUE: break;
        case NODE_ARRAY_COMPOUND_ASSIGN: {
            copy->data.array_compound_assign.left = copy_ast_with_replacement(node->data.array_compound_assign.left, replacements);
            copy->data.array_compound_assign.index = copy_ast_with_replacement(node->data.array_compound_assign.index, replacements);
            copy->data.array_compound_assign.op = node->data.array_compound_assign.op;
            copy->data.array_compound_assign.rhs = copy_ast_with_replacement(node->data.array_compound_assign.rhs, replacements);
            break;
        }
        case NODE_TRY: {
            copy->data.try_stmt.try_body = copy_ast_with_replacement(node->data.try_stmt.try_body, replacements);
            copy->data.try_stmt.catch_var = node->data.try_stmt.catch_var ? strdup(node->data.try_stmt.catch_var) : NULL;
            copy->data.try_stmt.catch_body = copy_ast_with_replacement(node->data.try_stmt.catch_body, replacements);
            copy->data.try_stmt.finally_body = copy_ast_with_replacement(node->data.try_stmt.finally_body, replacements);
            break;
        }
        case NODE_THROW: copy->data.throw_expr.expr = copy_ast_with_replacement(node->data.throw_expr.expr, replacements); break;
        case NODE_OBJECT_LITERAL: {
            copy->data.object_lit.count = node->data.object_lit.count;
            copy->data.object_lit.key_exprs = (ASTNode**)malloc(copy->data.object_lit.count * sizeof(ASTNode*));
            copy->data.object_lit.vals = (ASTNode**)malloc(copy->data.object_lit.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.object_lit.count; i++) {
                copy->data.object_lit.key_exprs[i] = copy_ast_with_replacement(node->data.object_lit.key_exprs[i], replacements);
                copy->data.object_lit.vals[i] = copy_ast_with_replacement(node->data.object_lit.vals[i], replacements);
            }
            copy->data.object_lit.spread_count = node->data.object_lit.spread_count;
            copy->data.object_lit.spreads = (ASTNode**)malloc(copy->data.object_lit.spread_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.object_lit.spread_count; i++)
                copy->data.object_lit.spreads[i] = copy_ast_with_replacement(node->data.object_lit.spreads[i], replacements);
            break;
        }
        case NODE_OBJECT_ACCESS: {
            copy->data.object_access.obj = copy_ast_with_replacement(node->data.object_access.obj, replacements);
            copy->data.object_access.key = strdup(node->data.object_access.key);
            copy->data.object_access.is_optional = node->data.object_access.is_optional;
            break;
        }
        case NODE_OBJECT_ASSIGN: {
            copy->data.object_assign.obj = copy_ast_with_replacement(node->data.object_assign.obj, replacements);
            copy->data.object_assign.key = strdup(node->data.object_assign.key);
            copy->data.object_assign.value = copy_ast_with_replacement(node->data.object_assign.value, replacements);
            break;
        }
        case NODE_OBJECT_COMPOUND_ASSIGN: {
            copy->data.object_compound_assign.obj = copy_ast_with_replacement(node->data.object_compound_assign.obj, replacements);
            copy->data.object_compound_assign.key = strdup(node->data.object_compound_assign.key);
            copy->data.object_compound_assign.op  = node->data.object_compound_assign.op;
            copy->data.object_compound_assign.rhs = copy_ast_with_replacement(node->data.object_compound_assign.rhs, replacements);
            break;
        }
        case NODE_FOREACH: {
            copy->data.foreach.key_var = strdup(node->data.foreach.key_var);
            copy->data.foreach.value_var = node->data.foreach.value_var ? strdup(node->data.foreach.value_var) : NULL;
            copy->data.foreach.collection = copy_ast_with_replacement(node->data.foreach.collection, replacements);
            copy->data.foreach.body = copy_ast_with_replacement(node->data.foreach.body, replacements);
            break;
        }
        case NODE_NULL_COALESCE: {
            copy->data.null_coalesce.left = copy_ast_with_replacement(node->data.null_coalesce.left, replacements);
            copy->data.null_coalesce.right = copy_ast_with_replacement(node->data.null_coalesce.right, replacements);
            break;
        }
        case NODE_RANGE: {
            copy->data.range.start = copy_ast_with_replacement(node->data.range.start, replacements);
            copy->data.range.end = copy_ast_with_replacement(node->data.range.end, replacements);
            copy->data.range.step = copy_ast_with_replacement(node->data.range.step, replacements);
            break;
        }
        case NODE_LIST_COMPREHENSION: {
            copy->data.list_comp.expr = copy_ast_with_replacement(node->data.list_comp.expr, replacements);
            copy->data.list_comp.var_name = strdup(node->data.list_comp.var_name);
            copy->data.list_comp.collection = copy_ast_with_replacement(node->data.list_comp.collection, replacements);
            copy->data.list_comp.cond = copy_ast_with_replacement(node->data.list_comp.cond, replacements);
            break;
        }
        case NODE_PIPE:
            copy->data.pipe.left = copy_ast_with_replacement(node->data.pipe.left, replacements);
            copy->data.pipe.right = copy_ast_with_replacement(node->data.pipe.right, replacements);
            break;
        case NODE_FLOAT:
            copy->data.float_str = strdup(node->data.float_str); break;
            break;
        case NODE_LAZY_VAR_DECL:
            copy->data.lazy_var_decl.name = strdup(node->data.lazy_var_decl.name);
            copy->data.lazy_var_decl.expr = copy_ast_with_replacement(node->data.lazy_var_decl.expr, replacements);
            break;
        case NODE_SICHER:
            copy->data.sicher.expr = copy_ast_with_replacement(node->data.sicher.expr, replacements);
            copy->data.sicher.msg_expr = copy_ast_with_replacement(node->data.sicher.msg_expr, replacements);
            break;
        case NODE_SWAP_ASSIGN:
            copy->data.swap.left = copy_ast_with_replacement(node->data.swap.left, replacements);
            copy->data.swap.right = copy_ast_with_replacement(node->data.swap.right, replacements);
            copy->data.swap.global = node->data.swap.global;
            break;
        case NODE_MATCH:
            copy->data.match.expr = copy_ast_with_replacement(node->data.match.expr, replacements);
            copy->data.match.branch_count = node->data.match.branch_count;
            copy->data.match.branches = (MatchBranch*)malloc(copy->data.match.branch_count * sizeof(MatchBranch));
            for (int i = 0; i < copy->data.match.branch_count; i++) {
                copy->data.match.branches[i].pattern = copy_ast_with_replacement(node->data.match.branches[i].pattern, replacements);
                copy->data.match.branches[i].guard   = copy_ast_with_replacement(node->data.match.branches[i].guard, replacements);
                copy->data.match.branches[i].body = copy_ast_with_replacement(node->data.match.branches[i].body, replacements);
            }
            break;
        case NODE_PATTERN_BIND:
            copy->data.pattern_bind.name = strdup(node->data.pattern_bind.name);
            break;
        case NODE_PATTERN_OBJECT:
            copy->data.pattern_object.count = node->data.pattern_object.count;
            copy->data.pattern_object.keys = (char**)malloc(copy->data.pattern_object.count * sizeof(char*));
            for (int i = 0; i < copy->data.pattern_object.count; i++)
                copy->data.pattern_object.keys[i] = strdup(node->data.pattern_object.keys[i]);
            break;
        case NODE_PATTERN_VARIANT:
            copy->data.pattern_variant.tag = strdup(node->data.pattern_variant.tag);
            copy->data.pattern_variant.param_count = node->data.pattern_variant.param_count;
            copy->data.pattern_variant.params = (char**)malloc(copy->data.pattern_variant.param_count * sizeof(char*));
            for (int i = 0; i < copy->data.pattern_variant.param_count; i++)
                copy->data.pattern_variant.params[i] = strdup(node->data.pattern_variant.params[i]);
            break;   
        case NODE_ENUM_DEF:
            copy->data.enum_def.name = strdup(node->data.enum_def.name);
            copy->data.enum_def.variant_count = node->data.enum_def.variant_count;
            copy->data.enum_def.variants = (char**)malloc(copy->data.enum_def.variant_count * sizeof(char*));
            copy->data.enum_def.variant_param_counts = (int*)malloc(copy->data.enum_def.variant_count * sizeof(int));
            for (int i = 0; i < copy->data.enum_def.variant_count; i++) {
                copy->data.enum_def.variants[i] = strdup(node->data.enum_def.variants[i]);
                copy->data.enum_def.variant_param_counts[i] = node->data.enum_def.variant_param_counts[i];
            }
            break;
        case NODE_ENUM_VARIANT:
            break;
        case NODE_PATTERN_CONSTANT:
            copy->data.pattern_constant.constant = copy_value(node->data.pattern_constant.constant);
            break;
        case NODE_ASYNC_FUNC_DEF:
            copy->data.func_def.name = node->data.func_def.name ? strdup(node->data.func_def.name) : NULL;
            copy->data.func_def.param_count = node->data.func_def.param_count;
            copy->data.func_def.params = (char**)malloc(copy->data.func_def.param_count * sizeof(char*));
            for (int i = 0; i < copy->data.func_def.param_count; i++)
                copy->data.func_def.params[i] = strdup(node->data.func_def.params[i]);
            copy->data.func_def.body = copy_ast_with_replacement(node->data.func_def.body, replacements);
            copy->data.func_def.is_memoized = node->data.func_def.is_memoized;
            copy->data.func_def.global_scope = node->data.func_def.global_scope;
            copy->data.func_def.return_type = copy_type_node(node->data.func_def.return_type);
            copy->data.func_def.vararg_name = node->data.func_def.vararg_name ? strdup(node->data.func_def.vararg_name) : NULL;
            copy->data.func_def.param_is_const = (bool*)malloc(node->data.func_def.param_count * sizeof(bool));
            copy->data.func_def.param_defaults = (ASTNode**)malloc(node->data.func_def.param_count * sizeof(ASTNode*));
            if (node->data.func_def.param_types) {
                copy->data.func_def.param_types = (TypeNode**)malloc(node->data.func_def.param_count * sizeof(TypeNode*));
                for (int i = 0; i < node->data.func_def.param_count; i++)
                    copy->data.func_def.param_types[i] = copy_type_node(node->data.func_def.param_types[i]);
            } else {
                copy->data.func_def.param_types = nullptr;
            }
            for (int i = 0; i < node->data.func_def.param_count; i++) {
                copy->data.func_def.param_is_const[i] = node->data.func_def.param_is_const[i];
                copy->data.func_def.param_defaults[i] = copy_ast_with_replacement(node->data.func_def.param_defaults[i], replacements);
            }
            copy->data.func_def.vararg_type = copy_type_node(node->data.func_def.vararg_type);
            break;
        case NODE_AWAIT:
            copy->data.await.expr = copy_ast_with_replacement(node->data.await.expr, replacements);
            copy->data.await.timeout = copy_ast_with_replacement(node->data.await.timeout, replacements);
            copy->data.await.fallback = copy_ast_with_replacement(node->data.await.fallback, replacements);
            break;
        case NODE_STRING_INTERP: {
            copy->data.string_interp.count = node->data.string_interp.count;
            copy->data.string_interp.fragments = (ASTNode**)malloc(
                copy->data.string_interp.count * sizeof(ASTNode*)
            );
            for (int i = 0; i < copy->data.string_interp.count; i++)
                copy->data.string_interp.fragments[i] = copy_ast_with_replacement(node->data.string_interp.fragments[i], replacements);
            break;
        }
        case NODE_KEY_BIND:
            copy->data.key_bind.key = strdup(node->data.key_bind.key);
            copy->data.key_bind.body = copy_ast_with_replacement(node->data.key_bind.body, replacements);
            break;
        case NODE_SCOPE_BLOCK: {
            copy->data.block.count = node->data.block.count;
            copy->data.block.stmts = (ASTNode**)malloc(copy->data.block.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.block.count; i++)
                copy->data.block.stmts[i] = copy_ast_with_replacement(node->data.block.stmts[i], replacements);
            break;
        }
        case NODE_ALIAS_DECL:
            copy->data.alias_decl.name = strdup(node->data.alias_decl.name);
            copy->data.alias_decl.target = strdup(node->data.alias_decl.target);
            copy->data.alias_decl.global = node->data.alias_decl.global;
            break;
        case NODE_GLOBAL_BLOCK: {
            copy->data.block.count = node->data.block.count;
            copy->data.block.stmts = (ASTNode**)malloc(copy->data.block.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.block.count; i++)
                copy->data.block.stmts[i] = copy_ast_with_replacement(node->data.block.stmts[i], replacements);
            break;
        }
        case NODE_DESTRUCTURE: {
            copy->data.destructure.count = node->data.destructure.count;
            copy->data.destructure.names = (char**)malloc(copy->data.destructure.count * sizeof(char*));
            for (int i = 0; i < copy->data.destructure.count; i++)
                copy->data.destructure.names[i] = strdup(node->data.destructure.names[i]);
            copy->data.destructure.expr = copy_ast_with_replacement(node->data.destructure.expr, replacements);
            copy->data.destructure.is_const = node->data.destructure.is_const;
            break;
        }
        case NODE_CLASS_DEF: {
            copy->data.class_def.name = strdup(node->data.class_def.name);
            copy->data.class_def.parent = node->data.class_def.parent ? strdup(node->data.class_def.parent) : NULL;
            copy->data.class_def.access_modifier = node->data.class_def.access_modifier;
            copy->data.class_def.ctor_param_count = node->data.class_def.ctor_param_count;
            copy->data.class_def.ctor_params = (char**)malloc(copy->data.class_def.ctor_param_count * sizeof(char*));
            for (int i = 0; i < copy->data.class_def.ctor_param_count; i++)
                copy->data.class_def.ctor_params[i] = strdup(node->data.class_def.ctor_params[i]);
            copy->data.class_def.ctor_body = copy_ast_with_replacement(node->data.class_def.ctor_body, replacements);
        
            // ---- 复制方法 ----
            copy->data.class_def.methods.count = node->data.class_def.methods.count;
            copy->data.class_def.methods.names = (char**)malloc(copy->data.class_def.methods.count * sizeof(char*));
            copy->data.class_def.methods.param_counts = (int*)malloc(copy->data.class_def.methods.count * sizeof(int));
            copy->data.class_def.methods.param_lists = (char***)malloc(copy->data.class_def.methods.count * sizeof(char**));
            copy->data.class_def.methods.bodies = (ASTNode**)malloc(copy->data.class_def.methods.count * sizeof(ASTNode*));
            copy->data.class_def.methods.is_static = (bool*)malloc(copy->data.class_def.methods.count * sizeof(bool));
            copy->data.class_def.methods.access = (int*)malloc(copy->data.class_def.methods.count * sizeof(int));
            copy->data.class_def.methods.return_types = (TypeNode**)malloc(copy->data.class_def.methods.count * sizeof(TypeNode*));
            copy->data.class_def.methods.param_types = (TypeNode***)malloc(copy->data.class_def.methods.count * sizeof(TypeNode**));

            copy->data.class_def.methods.vararg_names = (char**)malloc(copy->data.class_def.methods.count * sizeof(char*));
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.vararg_names[i] = node->data.class_def.methods.vararg_names[i] 
                                                                ? strdup(node->data.class_def.methods.vararg_names[i]) 
                                                                : NULL;
            }
            copy->data.class_def.methods.vararg_types = (TypeNode**)malloc(copy->data.class_def.methods.count * sizeof(TypeNode*));
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.vararg_types[i] = node->data.class_def.methods.vararg_types[i] 
                                                                ? copy_type_node(node->data.class_def.methods.vararg_types[i]) 
                                                                : NULL;
            }
        
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.names[i] = strdup(node->data.class_def.methods.names[i]);
                copy->data.class_def.methods.param_counts[i] = node->data.class_def.methods.param_counts[i];
                char** src_params = node->data.class_def.methods.param_lists[i];
                char** dst_params = (char**)malloc(copy->data.class_def.methods.param_counts[i] * sizeof(char*));
                for (int j = 0; j < copy->data.class_def.methods.param_counts[i]; j++)
                    dst_params[j] = strdup(src_params[j]);
                copy->data.class_def.methods.param_lists[i] = dst_params;
                copy->data.class_def.methods.bodies[i] = copy_ast_with_replacement(node->data.class_def.methods.bodies[i], replacements);
                copy->data.class_def.methods.is_static[i] = node->data.class_def.methods.is_static[i];
                copy->data.class_def.methods.access[i] = node->data.class_def.methods.access[i];
                copy->data.class_def.methods.return_types[i] = node->data.class_def.methods.return_types[i]
                                                              ? copy_type_node(node->data.class_def.methods.return_types[i])
                                                              : nullptr;
        
                // 复制参数类型
                if (node->data.class_def.methods.param_types && node->data.class_def.methods.param_types[i]) {
                    copy->data.class_def.methods.param_types[i] = (TypeNode**)malloc(copy->data.class_def.methods.param_counts[i] * sizeof(TypeNode*));
                    for (int j = 0; j < copy->data.class_def.methods.param_counts[i]; j++)
                        copy->data.class_def.methods.param_types[i][j] = copy_type_node(node->data.class_def.methods.param_types[i][j]);
                } else {
                    copy->data.class_def.methods.param_types[i] = nullptr;
                }
            }
        
            // ---- 复制属性 ----
            copy->data.class_def.properties.count = node->data.class_def.properties.count;
            copy->data.class_def.properties.names = (char**)malloc(copy->data.class_def.properties.count * sizeof(char*));
            copy->data.class_def.properties.types = (TypeNode**)malloc(copy->data.class_def.properties.count * sizeof(TypeNode*));
            copy->data.class_def.properties.default_exprs = (ASTNode**)malloc(copy->data.class_def.properties.count * sizeof(ASTNode*));
            copy->data.class_def.properties.is_const = (bool*)malloc(copy->data.class_def.properties.count * sizeof(bool));
            copy->data.class_def.properties.is_static = (bool*)malloc(copy->data.class_def.properties.count * sizeof(bool));
            copy->data.class_def.properties.access = (int*)malloc(copy->data.class_def.properties.count * sizeof(int));
            for (int i = 0; i < copy->data.class_def.properties.count; i++) {
                copy->data.class_def.properties.names[i] = strdup(node->data.class_def.properties.names[i]);
                copy->data.class_def.properties.types[i] = node->data.class_def.properties.types[i]
                                                          ? copy_type_node(node->data.class_def.properties.types[i])
                                                          : nullptr;
                copy->data.class_def.properties.default_exprs[i] = copy_ast_with_replacement(node->data.class_def.properties.default_exprs[i], replacements);
                copy->data.class_def.properties.is_const[i] = node->data.class_def.properties.is_const[i];
                copy->data.class_def.properties.is_static[i] = node->data.class_def.properties.is_static[i];
                copy->data.class_def.properties.access[i] = node->data.class_def.properties.access[i];
            }

            copy->data.class_def.ctor_param_type_count = node->data.class_def.ctor_param_type_count;
            copy->data.class_def.ctor_param_types = (TypeNode**)malloc(copy->data.class_def.ctor_param_type_count * sizeof(TypeNode*));
            for (int i = 0; i < copy->data.class_def.ctor_param_type_count; i++) {
                copy->data.class_def.ctor_param_types[i] = copy_type_node(node->data.class_def.ctor_param_types[i]);
            }
            copy->data.class_def.methods.is_stmt_func = (bool*)malloc(
                copy->data.class_def.methods.count * sizeof(bool));
            for (int i = 0; i < copy->data.class_def.methods.count; i++) {
                copy->data.class_def.methods.is_stmt_func[i] = 
                    node->data.class_def.methods.is_stmt_func[i];
            }
            copy->data.class_def.is_static_class = node->data.class_def.is_static_class;
            
            copy->data.class_def.ctor_default_count = node->data.class_def.ctor_default_count;
            copy->data.class_def.ctor_defaults = (ASTNode**)malloc(
                copy->data.class_def.ctor_default_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.class_def.ctor_default_count; ++i)
                copy->data.class_def.ctor_defaults[i] = copy_ast_with_replacement(node->data.class_def.ctor_defaults[i], replacements);
            break;
        }
        case NODE_NEW: {
            copy->data.new_expr.class_name = strdup(node->data.new_expr.class_name);
            copy->data.new_expr.arg_count = node->data.new_expr.arg_count;
            copy->data.new_expr.args = (ASTNode**)malloc(copy->data.new_expr.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.new_expr.arg_count; i++)
                copy->data.new_expr.args[i] = copy_ast_with_replacement(node->data.new_expr.args[i], replacements);
            break;
        }
        case NODE_SUPER_CALL: {
            copy->data.super_call.arg_count = node->data.super_call.arg_count;
            copy->data.super_call.args = (ASTNode**)malloc(copy->data.super_call.arg_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.super_call.arg_count; i++)
                copy->data.super_call.args[i] = copy_ast_with_replacement(node->data.super_call.args[i], replacements);
            break;
        }
        case NODE_THIS:
            break; // 无数据
        case NODE_PRINT_NO_NEWLINE:
            copy->data.print.expr = copy_ast_with_replacement(node->data.print.expr, replacements);
            break;
        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI: {
            copy->data.print_multi.count = node->data.print_multi.count;
            copy->data.print_multi.exprs = (ASTNode**)malloc(copy->data.print_multi.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.print_multi.count; i++)
                copy->data.print_multi.exprs[i] = copy_ast_with_replacement(node->data.print_multi.exprs[i], replacements);
            break;
        }
        case NODE_DOUBLE_FACTORIAL:
            copy->data.inc_dec.operand = copy_ast_with_replacement(node->data.inc_dec.operand, replacements);
            break;
        case NODE_UMF_DEF: {
            copy->data.umf_def.name = strdup(node->data.umf_def.name);
            copy->data.umf_def.parent_name = node->data.umf_def.parent_name ? strdup(node->data.umf_def.parent_name) : NULL;
            copy->data.umf_def.body = copy_ast_with_replacement(node->data.umf_def.body, replacements);
            break;
        }
        case NODE_DESTRUCTURE_ASSIGN: {
            copy->data.destructure.count = node->data.destructure.count;
            copy->data.destructure.names = (char**)malloc(copy->data.destructure.count * sizeof(char*));
            for (int i = 0; i < copy->data.destructure.count; i++)
                copy->data.destructure.names[i] = strdup(node->data.destructure.names[i]);
            copy->data.destructure.expr = copy_ast_with_replacement(node->data.destructure.expr, replacements);
            copy->data.destructure.rest_name = node->data.destructure.rest_name ? strdup(node->data.destructure.rest_name) : nullptr;
            break;
        }
        case NODE_IMPORT:
            copy->data.import.filename = strdup(node->data.import.filename);
            copy->data.import.alias = node->data.import.alias ? strdup(node->data.import.alias) : nullptr;
            copy->data.import.has_quote = node->data.import.has_quote;
            copy->data.import.module_ast = nullptr;   // 运行时才加载
            break;
        case NODE_DO_WHILE: {
            copy->data.do_while.body = copy_ast_with_replacement(node->data.do_while.body, replacements);
            copy->data.do_while.cond = copy_ast_with_replacement(node->data.do_while.cond, replacements);
            break;
        }
        case NODE_REGEX_LITERAL:
            copy->data.regex_lit.pattern = strdup(node->data.regex_lit.pattern);
            copy->data.regex_lit.flags = strdup(node->data.regex_lit.flags);
            break;
        case NODE_MULTI_ASSIGN: {
            copy->data.multi_assign.left_count = node->data.multi_assign.left_count;
            copy->data.multi_assign.left_names = (char**)malloc(copy->data.multi_assign.left_count * sizeof(char*));
            for (int i = 0; i < copy->data.multi_assign.left_count; i++)
                copy->data.multi_assign.left_names[i] = strdup(node->data.multi_assign.left_names[i]);
            copy->data.multi_assign.right_count = node->data.multi_assign.right_count;
            copy->data.multi_assign.right_exprs = (ASTNode**)malloc(copy->data.multi_assign.right_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.multi_assign.right_count; i++)
                copy->data.multi_assign.right_exprs[i] = copy_ast_with_replacement(node->data.multi_assign.right_exprs[i], replacements);
            break;
        }
        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            copy->data.spread.expr = copy_ast_with_replacement(node->data.spread.expr, replacements);
            break;
        case NODE_PATTERN_OR:
            copy->data.pattern_or.count = node->data.pattern_or.count;
            copy->data.pattern_or.patterns = (ASTNode**)malloc(copy->data.pattern_or.count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.pattern_or.count; ++i)
                copy->data.pattern_or.patterns[i] = copy_ast_with_replacement(node->data.pattern_or.patterns[i], replacements);
            break;
        case NODE_MARK_USED:
            copy->data.mark_used.count = node->data.mark_used.count;
            copy->data.mark_used.names = (char**)malloc(copy->data.mark_used.count * sizeof(char*));
            for (int i = 0; i < copy->data.mark_used.count; ++i)
                copy->data.mark_used.names[i] = strdup(node->data.mark_used.names[i]);
            break;
        case NODE_MARK_ALL_USED:
            break;
        case NODE_TYPE_DEF: {
            copy->data.type_def.name = strdup(node->data.type_def.name);
            copy->data.type_def.member_count = node->data.type_def.member_count;
            copy->data.type_def.members = (ASTNode**)malloc(
                copy->data.type_def.member_count * sizeof(ASTNode*));
            for (int i = 0; i < copy->data.type_def.member_count; ++i)
                copy->data.type_def.members[i] = copy_ast_with_replacement(
                    node->data.type_def.members[i], replacements);
            break;
        }
        case NODE_BITWISE_OR:
        case NODE_BITWISE_AND:
        case NODE_SHIFT_LEFT:
        case NODE_SHIFT_RIGHT:
            copy->data.binary.left = copy_ast_with_replacement(node->data.binary.left, replacements);
            copy->data.binary.right = copy_ast_with_replacement(node->data.binary.right, replacements);
            break;
        case NODE_OBJECT_COMPREHENSION:
            copy->data.object_comp.key_expr = copy_ast_with_replacement(node->data.object_comp.key_expr, replacements);
            copy->data.object_comp.value_expr = copy_ast_with_replacement(node->data.object_comp.value_expr, replacements);
            copy->data.object_comp.var_name = strdup(node->data.object_comp.var_name);
            copy->data.object_comp.value_var = node->data.object_comp.value_var ? strdup(node->data.object_comp.value_var) : NULL;
            copy->data.object_comp.collection = copy_ast_with_replacement(node->data.object_comp.collection, replacements);
            copy->data.object_comp.cond = node->data.object_comp.cond ? copy_ast_with_replacement(node->data.object_comp.cond, replacements) : nullptr;
            break;
        case NODE_BITWISE_NOT:
            copy->data.inc_dec.operand = copy_ast_with_replacement(
                node->data.inc_dec.operand, replacements);
            break;
        case NODE_UMF_IMPORT:
            copy->data.umf_import.name = strdup(node->data.umf_import.name);
            break;
        default:
            kr_error("copy_ast: 未知节点类型 %d\n", node->type);
            
    }
    return copy;
 }

 void set_ast_position(ASTNode* node, int line, int col) {
    if (!node) return;
    node->line = line;
    node->col = col;
    switch (node->type) {
        // 遍历所有包含子节点的类型，递归调用自身
        case NODE_PROGRAM:
        case NODE_BLOCK:
        case NODE_SCOPE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            for (int i = 0; i < node->data.block.count; ++i)
                set_ast_position(node->data.block.stmts[i], line, col);
            break;
        case NODE_VAR_DECL:
            set_ast_position(node->data.var_decl.expr, line, col);
            break;
        case NODE_ASSIGN:
            set_ast_position(node->data.assign.expr, line, col);
            break;
        case NODE_PRINT:
        case NODE_PRINT_NO_NEWLINE:
            set_ast_position(node->data.print.expr, line, col);
            break;
        case NODE_INPUT:
            for (int i = 0; i < node->data.input.arg_count; ++i)
                set_ast_position(node->data.input.args[i], line, col);
            set_ast_position(node->data.input.multiline_expr, line, col);
            break;
        case NODE_IF:
            set_ast_position(node->data.if_stmt.cond, line, col);
            set_ast_position(node->data.if_stmt.then_block, line, col);
            for (int i = 0; i < node->data.if_stmt.else_if_count; ++i)
                set_ast_position(node->data.if_stmt.else_ifs[i], line, col);
            set_ast_position(node->data.if_stmt.else_block, line, col);
            break;
        case NODE_WHILE:
            set_ast_position(node->data.while_stmt.cond, line, col);
            set_ast_position(node->data.while_stmt.body, line, col);
            break;
        case NODE_DO_WHILE:
            set_ast_position(node->data.do_while.body, line, col);
            set_ast_position(node->data.do_while.cond, line, col);
            break;
        case NODE_FOR:
            set_ast_position(node->data.for_stmt.init, line, col);
            set_ast_position(node->data.for_stmt.cond, line, col);
            set_ast_position(node->data.for_stmt.update, line, col);
            set_ast_position(node->data.for_stmt.body, line, col);
            break;
        case NODE_FOREACH:
            set_ast_position(node->data.foreach.collection, line, col);
            set_ast_position(node->data.foreach.body, line, col);
            break;
        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF:
            set_ast_position(node->data.func_def.body, line, col);
            for (int i = 0; i < node->data.func_def.param_count; ++i)
                set_ast_position(node->data.func_def.param_defaults[i], line, col);
            break;
        case NODE_FUNC_CALL:
            set_ast_position(node->data.func_call.func_expr, line, col);
            for (int i = 0; i < node->data.func_call.arg_count; ++i)
                set_ast_position(node->data.func_call.args[i], line, col);
            break;
        case NODE_BINARY:
        case NODE_CMP_THREE_WAY:
        case NODE_CONCAT:
            set_ast_position(node->data.binary.left, line, col);
            set_ast_position(node->data.binary.right, line, col);
            break;
        case NODE_RETURN:
            set_ast_position(node->data.ret.expr, line, col);
            break;
        case NODE_ARRAY_LITERAL:
            for (int i = 0; i < node->data.array_lit.count; ++i)
                set_ast_position(node->data.array_lit.elems[i], line, col);
            break;
        case NODE_ARRAY_ACCESS:
            set_ast_position(node->data.array_access.array, line, col);
            set_ast_position(node->data.array_access.index, line, col);
            break;
        case NODE_ARRAY_LEN:
            set_ast_position(node->data.array_len.array, line, col);
            break;
        case NODE_STRING_ACCESS:
            set_ast_position(node->data.string_access.str, line, col);
            set_ast_position(node->data.string_access.index, line, col);
            break;
        case NODE_STRING_LEN:
            set_ast_position(node->data.string_len.str, line, col);
            break;
        case NODE_NOT:
            set_ast_position(node->data.not_expr.expr, line, col);
            break;
        case NODE_LOGICAL_AND:
        case NODE_LOGICAL_OR:
            set_ast_position(node->data.logical_and.left, line, col);
            set_ast_position(node->data.logical_and.right, line, col);
            break;
        case NODE_ARRAY_ASSIGN:
            set_ast_position(node->data.array_assign.index, line, col);
            set_ast_position(node->data.array_assign.expr, line, col);
            break;
        case NODE_METHOD_CALL:
            set_ast_position(node->data.method_call.obj, line, col);
            for (int i = 0; i < node->data.method_call.arg_count; ++i)
                set_ast_position(node->data.method_call.args[i], line, col);
            break;
        case NODE_EXPR_STMT:
            set_ast_position(node->data.expr_stmt.expr, line, col);
            break;
        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
        case NODE_DOUBLE_FACTORIAL:
        case NODE_BITWISE_NOT:
            set_ast_position(node->data.inc_dec.operand, line, col);
            break;
        case NODE_TERNARY:
            set_ast_position(node->data.ternary.cond, line, col);
            set_ast_position(node->data.ternary.true_expr, line, col);
            set_ast_position(node->data.ternary.false_expr, line, col);
            break;
        case NODE_ARRAY_COMPOUND_ASSIGN:
            set_ast_position(node->data.array_compound_assign.index, line, col);
            set_ast_position(node->data.array_compound_assign.rhs, line, col);
            break;
        case NODE_TRY:
            set_ast_position(node->data.try_stmt.try_body, line, col);
            set_ast_position(node->data.try_stmt.catch_body, line, col);
            set_ast_position(node->data.try_stmt.finally_body, line, col);
            break;
        case NODE_THROW:
            set_ast_position(node->data.throw_expr.expr, line, col);
            break;
        case NODE_OBJECT_LITERAL:
            for (int i = 0; i < node->data.object_lit.count; ++i) {
                set_ast_position(node->data.object_lit.key_exprs[i], line, col);
                set_ast_position(node->data.object_lit.vals[i], line, col);
            }
            for (int i = 0; i < node->data.object_lit.spread_count; ++i)
                set_ast_position(node->data.object_lit.spreads[i], line, col);
            break;
        case NODE_OBJECT_ACCESS:
            set_ast_position(node->data.object_access.obj, line, col);
            break;
        case NODE_OBJECT_ASSIGN:
            set_ast_position(node->data.object_assign.obj, line, col);
            set_ast_position(node->data.object_assign.value, line, col);
            break;
        case NODE_OBJECT_COMPOUND_ASSIGN:
            set_ast_position(node->data.object_compound_assign.obj, line, col);
            set_ast_position(node->data.object_compound_assign.rhs, line, col);
            break;
        case NODE_NULL_COALESCE:
            set_ast_position(node->data.null_coalesce.left, line, col);
            set_ast_position(node->data.null_coalesce.right, line, col);
            break;
        case NODE_PIPE:
            set_ast_position(node->data.pipe.left, line, col);
            set_ast_position(node->data.pipe.right, line, col);
            break;
        case NODE_RANGE:
            set_ast_position(node->data.range.start, line, col);
            set_ast_position(node->data.range.end, line, col);
            set_ast_position(node->data.range.step, line, col);
            break;
        case NODE_LIST_COMPREHENSION:
            set_ast_position(node->data.list_comp.expr, line, col);
            set_ast_position(node->data.list_comp.collection, line, col);
            set_ast_position(node->data.list_comp.cond, line, col);
            break;
        case NODE_LAZY_VAR_DECL:
            set_ast_position(node->data.lazy_var_decl.expr, line, col);
            break;
        case NODE_SICHER:
            set_ast_position(node->data.sicher.expr, line, col);
            set_ast_position(node->data.sicher.msg_expr, line, col);
            break;
        case NODE_SWAP_ASSIGN:
            set_ast_position(node->data.swap.left, line, col);
            set_ast_position(node->data.swap.right, line, col);
            break;
        case NODE_MATCH:
            set_ast_position(node->data.match.expr, line, col);
            for (int i = 0; i < node->data.match.branch_count; ++i) {
                set_ast_position(node->data.match.branches[i].pattern, line, col);
                set_ast_position(node->data.match.branches[i].guard, line, col);
                set_ast_position(node->data.match.branches[i].body, line, col);
            }
            break;
        case NODE_PATTERN_OR:
            for (int i = 0; i < node->data.pattern_or.count; ++i)
                set_ast_position(node->data.pattern_or.patterns[i], line, col);
            break;
        case NODE_AWAIT:
            set_ast_position(node->data.await.expr, line, col);
            set_ast_position(node->data.await.timeout, line, col);
            set_ast_position(node->data.await.fallback, line, col);
            break;
        case NODE_KEY_BIND:
            set_ast_position(node->data.key_bind.body, line, col);
            break;
        case NODE_DESTRUCTURE:
        case NODE_DESTRUCTURE_ASSIGN:
            set_ast_position(node->data.destructure.expr, line, col);
            break;
        case NODE_CLASS_DEF:
            set_ast_position(node->data.class_def.ctor_body, line, col);
            for (int i = 0; i < node->data.class_def.methods.count; ++i)
                set_ast_position(node->data.class_def.methods.bodies[i], line, col);
            for (int i = 0; i < node->data.class_def.properties.count; ++i)
                set_ast_position(node->data.class_def.properties.default_exprs[i], line, col);
            break;
        case NODE_NEW:
            for (int i = 0; i < node->data.new_expr.arg_count; ++i)
                set_ast_position(node->data.new_expr.args[i], line, col);
            break;
        case NODE_SUPER_CALL:
            for (int i = 0; i < node->data.super_call.arg_count; ++i)
                set_ast_position(node->data.super_call.args[i], line, col);
            break;
        case NODE_PRINT_WITH_LINE:
            set_ast_position(node->data.print_with_line.expr, line, col);
            set_ast_position(node->data.print_with_line.line, line, col);
            break;
        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI:
            for (int i = 0; i < node->data.print_multi.count; ++i)
                set_ast_position(node->data.print_multi.exprs[i], line, col);
            break;
        case NODE_UMF_DEF:
            set_ast_position(node->data.umf_def.body, line, col);
            break;
        case NODE_MULTI_ASSIGN:
            for (int i = 0; i < node->data.multi_assign.right_count; ++i)
                set_ast_position(node->data.multi_assign.right_exprs[i], line, col);
            break;
        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            set_ast_position(node->data.spread.expr, line, col);
            break;
        case NODE_STRING_INTERP:
            for (int i = 0; i < node->data.string_interp.count; ++i)
                set_ast_position(node->data.string_interp.fragments[i], line, col);
            break;
        default:
            break;
    }
}

ASTNode* expand_macro(const std::string& name, std::vector<ASTNode*>& args, int line, int col) {
    auto it = macros.find(name);
    if (it == macros.end()) return nullptr;
    MacroDef& macro = it->second;
    if (args.size() != macro.params.size()) {
        g_last_error_line = macro.line;
        g_last_error_col = macro.col;
        kr_error("宏 '%s' 参数数量不匹配：期望 %zu，实际 %zu",
                 name.c_str(), macro.params.size(), args.size());
    }
    std::unordered_map<std::string, ASTNode*> replacements;
    for (size_t i = 0; i < macro.params.size(); ++i)
        replacements[macro.params[i]] = args[i];
    ASTNode* expanded = copy_ast_with_replacement(macro.body, replacements);
    set_ast_position(expanded, line, col);          // 设置所有节点位置
    expanded = expand_macros_in_ast(expanded);
    return expanded;
}

ASTNode* expand_macros_in_ast(ASTNode* node) {
    if (!node) return nullptr;

    // 先处理当前节点是否为宏调用（如果它是函数调用且名字为宏）
    if (node->type == NODE_FUNC_CALL && node->data.func_call.name) {
        std::string name = node->data.func_call.name;
        auto it = macros.find(name);
        if (it != macros.end()) {
            // 先展开参数
            for (int i = 0; i < node->data.func_call.arg_count; ++i)
                node->data.func_call.args[i] = expand_macros_in_ast(node->data.func_call.args[i]);
            std::vector<ASTNode*> args;
            for (int i = 0; i < node->data.func_call.arg_count; ++i)
                args.push_back(node->data.func_call.args[i]);
            ASTNode* expanded = expand_macro(name, args, node->line, node->col);
            free_ast(node);
            return expanded;
        }
    }

    // 如果不是宏调用，则递归处理子节点（原地修改）
    switch (node->type) {
        case NODE_PROGRAM:
        case NODE_BLOCK:
        case NODE_SCOPE_BLOCK:
        case NODE_GLOBAL_BLOCK:
            for (int i = 0; i < node->data.block.count; ++i) {
                node->data.block.stmts[i] = expand_macros_in_ast(node->data.block.stmts[i]);
            }
            break;

        case NODE_VAR_DECL:
            if (node->data.var_decl.expr)
                node->data.var_decl.expr = expand_macros_in_ast(node->data.var_decl.expr);
            break;

        case NODE_ASSIGN:
            node->data.assign.expr = expand_macros_in_ast(node->data.assign.expr);
            break;

        case NODE_PRINT:
        case NODE_PRINT_NO_NEWLINE:
            node->data.print.expr = expand_macros_in_ast(node->data.print.expr);
            break;

        case NODE_INPUT:
            for (int i = 0; i < node->data.input.arg_count; ++i)
                node->data.input.args[i] = expand_macros_in_ast(node->data.input.args[i]);
            if (node->data.input.multiline_expr)
                node->data.input.multiline_expr = expand_macros_in_ast(node->data.input.multiline_expr);
            break;

        case NODE_IF:
            node->data.if_stmt.cond = expand_macros_in_ast(node->data.if_stmt.cond);
            node->data.if_stmt.then_block = expand_macros_in_ast(node->data.if_stmt.then_block);
            for (int i = 0; i < node->data.if_stmt.else_if_count; ++i)
                node->data.if_stmt.else_ifs[i] = expand_macros_in_ast(node->data.if_stmt.else_ifs[i]);
            if (node->data.if_stmt.else_block)
                node->data.if_stmt.else_block = expand_macros_in_ast(node->data.if_stmt.else_block);
            break;

        case NODE_WHILE:
            node->data.while_stmt.cond = expand_macros_in_ast(node->data.while_stmt.cond);
            node->data.while_stmt.body = expand_macros_in_ast(node->data.while_stmt.body);
            break;

        case NODE_DO_WHILE:
            node->data.do_while.body = expand_macros_in_ast(node->data.do_while.body);
            node->data.do_while.cond = expand_macros_in_ast(node->data.do_while.cond);
            break;

        case NODE_FOR:
            if (node->data.for_stmt.init)
                node->data.for_stmt.init = expand_macros_in_ast(node->data.for_stmt.init);
            if (node->data.for_stmt.cond)
                node->data.for_stmt.cond = expand_macros_in_ast(node->data.for_stmt.cond);
            if (node->data.for_stmt.update)
                node->data.for_stmt.update = expand_macros_in_ast(node->data.for_stmt.update);
            node->data.for_stmt.body = expand_macros_in_ast(node->data.for_stmt.body);
            break;

        case NODE_FOREACH:
            node->data.foreach.collection = expand_macros_in_ast(node->data.foreach.collection);
            node->data.foreach.body = expand_macros_in_ast(node->data.foreach.body);
            break;

        case NODE_FUNC_DEF:
        case NODE_ASYNC_FUNC_DEF:
        case NODE_RULE_DEF:
            // 函数体需要展开，但参数名不需要
            if (node->data.func_def.body)
                node->data.func_def.body = expand_macros_in_ast(node->data.func_def.body);
            // 默认参数表达式也要展开
            for (int i = 0; i < node->data.func_def.param_count; ++i) {
                if (node->data.func_def.param_defaults[i])
                    node->data.func_def.param_defaults[i] = expand_macros_in_ast(node->data.func_def.param_defaults[i]);
            }
            break;

        case NODE_FUNC_CALL:
            // 展开函数参数
            for (int i = 0; i < node->data.func_call.arg_count; ++i) {
                node->data.func_call.args[i] = expand_macros_in_ast(node->data.func_call.args[i]);
            }
            if (node->data.func_call.func_expr)
                node->data.func_call.func_expr = expand_macros_in_ast(node->data.func_call.func_expr);
            break;

        case NODE_BINARY:
        case NODE_CONCAT:
        case NODE_CMP_THREE_WAY:
            node->data.binary.left = expand_macros_in_ast(node->data.binary.left);
            node->data.binary.right = expand_macros_in_ast(node->data.binary.right);
            break;

        case NODE_ARRAY_LITERAL:
            for (int i = 0; i < node->data.array_lit.count; ++i)
                node->data.array_lit.elems[i] = expand_macros_in_ast(node->data.array_lit.elems[i]);
            break;

        case NODE_ARRAY_ACCESS:
            node->data.array_access.array = expand_macros_in_ast(node->data.array_access.array);
            node->data.array_access.index = expand_macros_in_ast(node->data.array_access.index);
            break;

        case NODE_ARRAY_LEN:
            node->data.array_len.array = expand_macros_in_ast(node->data.array_len.array);
            break;

        case NODE_STRING_ACCESS:
            node->data.string_access.str = expand_macros_in_ast(node->data.string_access.str);
            node->data.string_access.index = expand_macros_in_ast(node->data.string_access.index);
            break;

        case NODE_STRING_LEN:
            node->data.string_len.str = expand_macros_in_ast(node->data.string_len.str);
            break;

        case NODE_NOT:
            node->data.not_expr.expr = expand_macros_in_ast(node->data.not_expr.expr);
            break;

        case NODE_LOGICAL_AND:
        case NODE_LOGICAL_OR:
            node->data.logical_and.left = expand_macros_in_ast(node->data.logical_and.left);
            node->data.logical_and.right = expand_macros_in_ast(node->data.logical_and.right);
            break;

        case NODE_ARRAY_ASSIGN:
            node->data.array_assign.index = expand_macros_in_ast(node->data.array_assign.index);
            node->data.array_assign.expr = expand_macros_in_ast(node->data.array_assign.expr);
            break;

        case NODE_METHOD_CALL:
            node->data.method_call.obj = expand_macros_in_ast(node->data.method_call.obj);
            for (int i = 0; i < node->data.method_call.arg_count; ++i)
                node->data.method_call.args[i] = expand_macros_in_ast(node->data.method_call.args[i]);
            break;

        case NODE_EXPR_STMT:
            node->data.expr_stmt.expr = expand_macros_in_ast(node->data.expr_stmt.expr);
            break;

        case NODE_TERNARY:
            node->data.ternary.cond = expand_macros_in_ast(node->data.ternary.cond);
            node->data.ternary.true_expr = expand_macros_in_ast(node->data.ternary.true_expr);
            node->data.ternary.false_expr = expand_macros_in_ast(node->data.ternary.false_expr);
            break;

        case NODE_PRE_INC:
        case NODE_PRE_DEC:
        case NODE_POST_INC:
        case NODE_POST_DEC:
        case NODE_DEGREE:
        case NODE_FACTORIAL:
        case NODE_DOUBLE_FACTORIAL:
            node->data.inc_dec.operand = expand_macros_in_ast(node->data.inc_dec.operand);
            break;

        case NODE_ARRAY_COMPOUND_ASSIGN:
            node->data.array_compound_assign.index = expand_macros_in_ast(node->data.array_compound_assign.index);
            node->data.array_compound_assign.rhs = expand_macros_in_ast(node->data.array_compound_assign.rhs);
            break;

        case NODE_TRY:
            node->data.try_stmt.try_body = expand_macros_in_ast(node->data.try_stmt.try_body);
            if (node->data.try_stmt.catch_body)
                node->data.try_stmt.catch_body = expand_macros_in_ast(node->data.try_stmt.catch_body);
            if (node->data.try_stmt.finally_body)
                node->data.try_stmt.finally_body = expand_macros_in_ast(node->data.try_stmt.finally_body);
            break;

        case NODE_THROW:
            node->data.throw_expr.expr = expand_macros_in_ast(node->data.throw_expr.expr);
            break;

        case NODE_OBJECT_LITERAL:
            for (int i = 0; i < node->data.object_lit.count; ++i) {
                node->data.object_lit.key_exprs[i] = expand_macros_in_ast(node->data.object_lit.key_exprs[i]);
                node->data.object_lit.vals[i] = expand_macros_in_ast(node->data.object_lit.vals[i]);
            }
            for (int i = 0; i < node->data.object_lit.spread_count; ++i)
                node->data.object_lit.spreads[i] = expand_macros_in_ast(node->data.object_lit.spreads[i]);
            break;

        case NODE_OBJECT_ACCESS:
            node->data.object_access.obj = expand_macros_in_ast(node->data.object_access.obj);
            break;

        case NODE_OBJECT_ASSIGN:
            node->data.object_assign.obj = expand_macros_in_ast(node->data.object_assign.obj);
            node->data.object_assign.value = expand_macros_in_ast(node->data.object_assign.value);
            break;

        case NODE_OBJECT_COMPOUND_ASSIGN:
            node->data.object_compound_assign.obj = expand_macros_in_ast(node->data.object_compound_assign.obj);
            node->data.object_compound_assign.rhs = expand_macros_in_ast(node->data.object_compound_assign.rhs);
            break;

        case NODE_NULL_COALESCE:
            node->data.null_coalesce.left = expand_macros_in_ast(node->data.null_coalesce.left);
            node->data.null_coalesce.right = expand_macros_in_ast(node->data.null_coalesce.right);
            break;

        case NODE_PIPE:
            node->data.pipe.left = expand_macros_in_ast(node->data.pipe.left);
            node->data.pipe.right = expand_macros_in_ast(node->data.pipe.right);
            break;

        case NODE_RANGE:
            node->data.range.start = expand_macros_in_ast(node->data.range.start);
            node->data.range.end = expand_macros_in_ast(node->data.range.end);
            if (node->data.range.step)
                node->data.range.step = expand_macros_in_ast(node->data.range.step);
            break;

        case NODE_LIST_COMPREHENSION:
            node->data.list_comp.expr = expand_macros_in_ast(node->data.list_comp.expr);
            node->data.list_comp.collection = expand_macros_in_ast(node->data.list_comp.collection);
            if (node->data.list_comp.cond)
                node->data.list_comp.cond = expand_macros_in_ast(node->data.list_comp.cond);
            break;

        case NODE_LAZY_VAR_DECL:
            node->data.lazy_var_decl.expr = expand_macros_in_ast(node->data.lazy_var_decl.expr);
            break;

        case NODE_SICHER:
            node->data.sicher.expr = expand_macros_in_ast(node->data.sicher.expr);
            if (node->data.sicher.msg_expr)
                node->data.sicher.msg_expr = expand_macros_in_ast(node->data.sicher.msg_expr);
            break;

        case NODE_SWAP_ASSIGN:
            node->data.swap.left = expand_macros_in_ast(node->data.swap.left);
            node->data.swap.right = expand_macros_in_ast(node->data.swap.right);
            break;

        case NODE_IMPORT:
            // 导入节点没有子节点需要展开
            break;

        case NODE_STRING_INTERP:
            for (int i = 0; i < node->data.string_interp.count; ++i)
                node->data.string_interp.fragments[i] = expand_macros_in_ast(node->data.string_interp.fragments[i]);
            break;

        case NODE_MATCH:
            node->data.match.expr = expand_macros_in_ast(node->data.match.expr);
            for (int i = 0; i < node->data.match.branch_count; ++i) {
                node->data.match.branches[i].pattern = expand_macros_in_ast(node->data.match.branches[i].pattern);
                if (node->data.match.branches[i].guard)
                    node->data.match.branches[i].guard = expand_macros_in_ast(node->data.match.branches[i].guard);
                node->data.match.branches[i].body = expand_macros_in_ast(node->data.match.branches[i].body);
            }
            break;

        case NODE_PATTERN_BIND:
        case NODE_PATTERN_OBJECT:
        case NODE_PATTERN_VARIANT:
        case NODE_PATTERN_CONSTANT:
        case NODE_PATTERN_OR:
            // 模式节点可能包含子节点（如常量），但常量无子节点；PATTERN_OR 有子模式
            if (node->type == NODE_PATTERN_OR) {
                for (int i = 0; i < node->data.pattern_or.count; ++i)
                    node->data.pattern_or.patterns[i] = expand_macros_in_ast(node->data.pattern_or.patterns[i]);
            }
            // 其他模式无子节点
            break;

        case NODE_ENUM_DEF:
            // 枚举定义无子节点
            break;

        case NODE_CLASS_DEF:
            // 类定义包含子节点（构造函数体、方法体、属性默认值等）
            if (node->data.class_def.ctor_body)
                node->data.class_def.ctor_body = expand_macros_in_ast(node->data.class_def.ctor_body);
            for (int i = 0; i < node->data.class_def.methods.count; ++i) {
                node->data.class_def.methods.bodies[i] = expand_macros_in_ast(node->data.class_def.methods.bodies[i]);
            }
            for (int i = 0; i < node->data.class_def.properties.count; ++i) {
                if (node->data.class_def.properties.default_exprs[i])
                    node->data.class_def.properties.default_exprs[i] = expand_macros_in_ast(node->data.class_def.properties.default_exprs[i]);
            }
            break;

        case NODE_NEW:
            for (int i = 0; i < node->data.new_expr.arg_count; ++i)
                node->data.new_expr.args[i] = expand_macros_in_ast(node->data.new_expr.args[i]);
            break;

        case NODE_SUPER_CALL:
            for (int i = 0; i < node->data.super_call.arg_count; ++i)
                node->data.super_call.args[i] = expand_macros_in_ast(node->data.super_call.args[i]);
            break;

        case NODE_PRINT_WITH_LINE:
            node->data.print_with_line.expr = expand_macros_in_ast(node->data.print_with_line.expr);
            node->data.print_with_line.line = expand_macros_in_ast(node->data.print_with_line.line);
            break;

        case NODE_PRINT_MULTI:
        case NODE_PRINT_NO_NEWLINE_MULTI:
            for (int i = 0; i < node->data.print_multi.count; ++i)
                node->data.print_multi.exprs[i] = expand_macros_in_ast(node->data.print_multi.exprs[i]);
            break;

        case NODE_UMF_DEF:
            node->data.umf_def.body = expand_macros_in_ast(node->data.umf_def.body);
            break;

        case NODE_DESTRUCTURE:
        case NODE_DESTRUCTURE_ASSIGN:
            node->data.destructure.expr = expand_macros_in_ast(node->data.destructure.expr);
            break;

        case NODE_MULTI_ASSIGN:
            for (int i = 0; i < node->data.multi_assign.right_count; ++i)
                node->data.multi_assign.right_exprs[i] = expand_macros_in_ast(node->data.multi_assign.right_exprs[i]);
            break;

        case NODE_SPREAD_ARRAY:
        case NODE_SPREAD_OBJECT:
        case NODE_SPREAD_ARG:
            node->data.spread.expr = expand_macros_in_ast(node->data.spread.expr);
            break;

        case NODE_KEY_BIND:
            node->data.key_bind.body = expand_macros_in_ast(node->data.key_bind.body);
            break;

        case NODE_ALIAS_DECL:
            // 无子节点
            break;

        case NODE_THIS:
        case NODE_NULL:
        case NODE_NUMBER:
        case NODE_FLOAT:
        case NODE_STRING:
        case NODE_VARIABLE:
        case NODE_RETURN:
        case NODE_BREAK:
        case NODE_CONTINUE:
        case NODE_REGEX_LITERAL:
        case NODE_ENUM_VARIANT:
        case NODE_AWAIT:
            // 这些节点没有子节点需要展开
            break;

        default:
            kr_error("expand_macros_in_ast: 未知节点类型 %d\n", node->type);
            break;
    }

    return node;
}

 static std::string make_key(Value* args, int count) {
    std::string key;
    for (int i = 0; i < count; ++i) {
        if (i > 0) key += '|';
        Value& v = args[i];
        switch (v.type) {
            case VAL_INT64: {
                key += "g(64):" + std::to_string(v.int64_val);
                break;
            }
            case VAL_INT: {
                char* s = mpz_get_str(NULL, 10, *v.big_int);
                key += "g:" + std::string(s);
                free(s);
                break;
            }
            case VAL_FLOAT: {
                char* s = mpf_get_str(NULL, NULL, 10, 0, *v.mpf_val);
                key += "k:" + std::string(s);
                free(s);
                break;
            }
            case VAL_STRING: key += "t:" + std::string(v.str_val, v.str_len); break;
            case VAL_NULL:   key += "n:null"; break;
            default: kr_error("记忆化不支持参数类型 %d", v.type);
        }
    }
    return key;
 }
 std::string normalize_key_string(const std::string& s) {
    std::string lower = s;
    std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
    if (lower == "esc" || lower == "escape")   return "Esc";
    if (lower == "space")                      return " ";
    if (lower == "tab")                        return "Tab";
    if (lower == "enter" || lower == "return") return "Enter";
    if (lower == "backspace")                  return "Backspace";
    // 方向键
    if (lower == "up")    return "Up";
    if (lower == "down")  return "Down";
    if (lower == "right") return "Right";
    if (lower == "left")  return "Left";
    // 编辑键
    if (lower == "home")  return "Home";
    if (lower == "end")   return "End";
    if (lower == "pageup") return "PageUp";
    if (lower == "pagedown") return "PageDown";
    if (lower == "insert") return "Insert";
    if (lower == "delete") return "Delete";
    // F1–F24
    for (int i = 1; i <= 24; ++i) {
        if (lower == "f" + std::to_string(i))
            return "F" + std::to_string(i);
    }
    return s;
 }
 std::string map_extended_key(int ch2) {
    switch (ch2) {
        // 功能键 F1–F12（0x3B–0x44, 0x85–0x86）
        case 0x3B: return "\x1b[11~"; // F1
        case 0x3C: return "\x1b[12~"; // F2
        case 0x3D: return "\x1b[13~"; // F3
        case 0x3E: return "\x1b[14~"; // F4
        case 0x3F: return "\x1b[15~"; // F5
        case 0x40: return "\x1b[17~"; // F6
        case 0x41: return "\x1b[18~"; // F7
        case 0x42: return "\x1b[19~"; // F8
        case 0x43: return "\x1b[20~"; // F9
        case 0x44: return "\x1b[21~"; // F10
        case 0x85: return "\x1b[23~"; // F11
        case 0x86: return "\x1b[24~"; // F12
        // 方向键
        case 0x48: return "\x1b[A";  // Up
        case 0x50: return "\x1b[B";  // Down
        case 0x4B: return "\x1b[D";  // Left
        case 0x4D: return "\x1b[C";  // Right
        // 编辑键
        case 0x47: return "\x1b[H";  // Home
        case 0x4F: return "\x1b[F";  // End
        case 0x49: return "\x1b[5~"; // PageUp
        case 0x51: return "\x1b[6~"; // PageDown
        case 0x52: return "\x1b[2~"; // Insert
        case 0x53: return "\x1b[3~"; // Delete
        // 数字键盘（NumLock 开启时）
        case 0x4A: return "-";       // Numpad -
        case 0x4E: return "+";       // Numpad +
        // 其他（可根据需要添加）
        default:
            return ""; // 未知
    }
 }
 std::unordered_map<std::string, std::unordered_map<std::string, Value>> memo_cache;
 std::mutex memo_cache_mutex;
 std::unordered_map<int, std::shared_future<std::shared_ptr<Value>>> future_map;
 std::mutex future_map_mutex;
 std::atomic<int> next_future_id{0};
 std::unordered_map<std::string, std::pair<ASTNode*, Scope*>> key_bind_map;
 std::unordered_map<int, std::shared_ptr<RuleState>> rule_states;
 std::atomic<int> next_rule_id{0};

 void free_key_binds() {
    for (auto& pair : key_bind_map) {
        free_ast(pair.second.first);
        free_scope_chain(pair.second.second);
    }
    key_bind_map.clear();
 }

 ASTNode* get_last_expr_from_block(ASTNode* block) {
    if (!block || block->type != NODE_BLOCK || block->data.block.count == 0)
        return NULL;
    ASTNode* last = block->data.block.stmts[block->data.block.count - 1];
    if (last->type == NODE_EXPR_STMT)
        return last->data.expr_stmt.expr;
    return NULL;
 }

 Scope* get_global_scope() {
    return original_global_scope;   // 总是返回真正的全局作用域
 }

 Value make_function(const char* name, char** params, int param_count, ASTNode* body,
    Scope* closure, bool is_memoized, bool is_async, bool global_scope,
    bool is_rule, TypeNode* ret_type, char* vararg_name,
    bool* param_is_const, ASTNode** param_defaults,
    TypeNode** param_types, TypeNode* vararg_type, bool is_stmt_func) {
    if (!closure) closure = get_global_scope();
    Value val;
    val.type = VAL_FUNCTION;
    val.func_val.name = name ? strdup(name) : NULL;
    val.func_val.param_count = param_count;
    val.func_val.params = (char**)malloc(param_count * sizeof(char*));
    for (int i = 0; i < param_count; i++)
        val.func_val.params[i] = strdup(params[i]);
    val.func_val.body = body;
    val.func_val.closure_scope = closure;
    val.func_val.is_memoized = is_memoized;
    val.func_val.is_async = is_async;
    val.func_val.global_scope = global_scope;
    val.func_val.is_rule = is_rule;
    val.func_val.return_type = copy_type_node(ret_type);
    val.func_val.vararg_name = vararg_name ? strdup(vararg_name) : NULL;
    val.func_val.param_is_const = (bool*)malloc(param_count * sizeof(bool));
    val.func_val.param_defaults = (ASTNode**)malloc(param_count * sizeof(ASTNode*));
    for (int i = 0; i < param_count; i++) {
        val.func_val.param_is_const[i] = param_is_const[i];
        val.func_val.param_defaults[i] = param_defaults[i] ? copy_ast(param_defaults[i]) : NULL;
    }
    if (param_types) {
        val.func_val.param_types = (TypeNode**)malloc(param_count * sizeof(TypeNode*));
        for (int i = 0; i < param_count; i++)
            val.func_val.param_types[i] = copy_type_node(param_types[i]);
    } else {
        val.func_val.param_types = nullptr;
    }
    val.func_val.vararg_type = copy_type_node(vararg_type);
    val.func_val.is_stmt_func = is_stmt_func;
    val.func_val.filename = current_filename ? strdup(current_filename) : strdup("-");
    return val;
 }

 ASTNode* parse_foreach() {
    consume();  // 消费 'jedes'（调用前已消费 'für'）
    expect("(");
    
    // 解析第一个变量（必需）
    Token* key_tok = consume();
    if (key_tok->type != TOK_IDENT)
        error_at(key_tok->line, key_tok->col, "期望标识符作为循环变量");
    char* key_var = strdup(key_tok->value);
    
    // 可选第二个变量（用于对象遍历键值对）
    char* value_var = NULL;
    if (strcmp(peek()->value, ",") == 0) {
        consume();
        Token* val_tok = consume();
        if (val_tok->type != TOK_IDENT)
            error_at(val_tok->line, val_tok->col, "期望标识符作为循环变量");
        value_var = strdup(val_tok->value);
    }
    
    // 期望 'in'
    expect("in");
    
    // 解析集合表达式
    ASTNode* collection = parse_expression();
    
    // 期望 ')'
    expect(")");
    
    // 循环体
    int base_indent = g_stmt_start_col - 1;
    ASTNode* body = parse_body_block(base_indent);
    
    ASTNode* node = new_node(NODE_FOREACH);
    node->data.foreach.key_var = key_var;
    node->data.foreach.value_var = value_var;
    node->data.foreach.collection = collection;
    node->data.foreach.body = body;
    return node;
}
 
/* ========== 值辅助函数 ========== */
static inline void mpz_set_int64(mpz_t rop, int64_t val) {
    if (val >= LONG_MIN && val <= LONG_MAX) {
        mpz_set_si(rop, (long)val);
    } else {
        char buf[32];
        snprintf(buf, sizeof(buf), "%lld", val);
        mpz_set_str(rop, buf, 10);
    }
}

static inline void mpf_set_int64(mpf_t rop, int64_t val) {
    if (val >= LONG_MIN && val <= LONG_MAX) {
        mpf_set_si(rop, (long)val);
    } else {
        char buf[32];
        snprintf(buf, sizeof(buf), "%lld", val);
        mpf_set_str(rop, buf, 10);
    }
}

Value make_int(mpz_t z) {
    Value v;
    v.type = VAL_INT;
    v.big_int = (mpz_t*)malloc(sizeof(mpz_t));
    mpz_init_set(*v.big_int, z);
    return v;
}
Value make_int_str(const char* s) {
    mpz_t tmp;
    mpz_init(tmp);
    if (mpz_set_str(tmp, s, 10) != 0) {
        mpz_clear(tmp);
        kr_error("无效的整数: %s", s);
    }
    Value v = make_int(tmp);
    mpz_clear(tmp);
    return v;
}
Value make_float(mpf_t z) {
    Value v;
    v.type = VAL_FLOAT;
    v.mpf_val = (mpf_t*)malloc(sizeof(mpf_t));
    mpf_init2(*v.mpf_val, mpf_get_default_prec()); // 使用全局默认精度
    mpf_set(*v.mpf_val, z);
    return v;
}
Value make_float_str(const char* s) {
    mpf_t tmp;
    mpf_init(tmp);
    if (mpf_set_str(tmp, s, 10) != 0) {
        mpf_clear(tmp);
        kr_error("无效的浮点数: %s", s);
    }
    Value v = make_float(tmp);
    mpf_clear(tmp);
    return v;
}

Value make_int(long long x) {
    // long long == int64_t，永远能放得下 → 直接返回原生 int64，
    // 免掉两次 mpz 分配和一次字符串 round-trip。
    return make_int64((int64_t)x);
}
Value make_float(double x) {
    mpf_t tmp;
    mpf_init_set_d(tmp, x);
    Value v = make_float(tmp);
    mpf_clear(tmp);
    return v;
}

// 辅助：根据类型生成默认值表达式节点
ASTNode* make_default_value_for_type(TypeNode* type) {
    if (!type) return new_node(NODE_NULL);

    // 处理 TYPE_OPTIONAL：直接返回 null
    if (type->kind == TYPE_OPTIONAL) {
        return new_node(NODE_NULL);
    }

    // 处理 TYPE_ALIAS：解析为具体类型
    if (type->kind == TYPE_ALIAS) {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        
        // 1) 检查是否为类型别名 (typ)
        auto it = type_aliases.find(type->alias_type.name);
        if (it != type_aliases.end()) {
            return make_default_value_for_type(it->second);
        }

        // 2) 检查是否为类
        auto cls_it = class_table.find(type->alias_type.name);
        if (cls_it != class_table.end()) {
            ClassDef& cls = cls_it->second;
            // 尝试生成 new 表达式
            if (cls.ctor_params.empty()) {
                // 无参构造函数
                ASTNode* node = new_node(NODE_NEW);
                node->data.new_expr.class_name = strdup(type->alias_type.name);
                return node;
            }
            // 检查是否所有参数都有默认值
            bool all_default = true;
            for (auto def : cls.ctor_defaults) {
                if (!def) { all_default = false; break; }
            }
            if (all_default && cls.ctor_params.size() == cls.ctor_defaults.size()) {
                ASTNode* node = new_node(NODE_NEW);
                node->data.new_expr.class_name = strdup(type->alias_type.name);
                node->data.new_expr.arg_count = (int)cls.ctor_params.size();
                node->data.new_expr.args = (ASTNode**)malloc(node->data.new_expr.arg_count * sizeof(ASTNode*));
                for (size_t i = 0; i < cls.ctor_params.size(); ++i) {
                    node->data.new_expr.args[i] = copy_ast(cls.ctor_defaults[i]);
                }
                return node;
            }
            // 不可默认构造，报错
            kr_error("类型 '%s' 没有可用的默认构造函数（缺少无参构造或参数缺少默认值）", type->alias_type.name);
        }

        // 3) 检查是否为枚举 (aufz)
        auto enum_it = enum_table.find(type->alias_type.name);
        if (enum_it != enum_table.end()) {
            // 取第一个变体作为默认值
            const auto& info = enum_it->second;
            if (info.variants.empty()) return new_node(NODE_NULL);
            // 构造枚举对象：{ "__tag": "变体名", "__felder": [] }
            ASTNode* tag_node = new_node(NODE_STRING);
            tag_node->data.string = strdup(info.variants[0].c_str());
            ASTNode* fields_node = new_node(NODE_ARRAY_LITERAL);
            int param_count = info.param_counts[0];
            fields_node->data.array_lit.count = param_count;
            fields_node->data.array_lit.elems = (ASTNode**)malloc(param_count * sizeof(ASTNode*));
            for (int i = 0; i < param_count; ++i) {
                // 参数类型未知，用 null 占位（但运行时会被类型检查拦截，故需更完善）
                // 实际上枚举参数类型未存储，这里只能生成 null，但类型检查会失败，所以枚举默认初始化应依赖用户自定义。
                // 作为改进，我们可以在此生成 null 但类型检查时对枚举变体的参数类型未定义，建议用户显式初始化。
                // 这里暂定为 null，但类型检查会报错，实际上无参枚举才可默认初始化。
                fields_node->data.array_lit.elems[i] = new_node(NODE_NULL);
            }
            // 组装对象字面量
            ASTNode* obj = new_node(NODE_OBJECT_LITERAL);
            obj->data.object_lit.count = 2;
            obj->data.object_lit.key_exprs = (ASTNode**)malloc(2 * sizeof(ASTNode*));
            obj->data.object_lit.vals = (ASTNode**)malloc(2 * sizeof(ASTNode*));
            // 键 "__tag"
            ASTNode* key1 = new_node(NODE_STRING);
            key1->data.string = strdup("__tag");
            obj->data.object_lit.key_exprs[0] = key1;
            obj->data.object_lit.vals[0] = tag_node;
            // 键 "__felder"
            ASTNode* key2 = new_node(NODE_STRING);
            key2->data.string = strdup("__felder");
            obj->data.object_lit.key_exprs[1] = key2;
            obj->data.object_lit.vals[1] = fields_node;
            return obj;
        }

        
        {
            ASTNode* node = new_node(NODE_NEW);
            node->data.new_expr.class_name = strdup(type->alias_type.name);
            node->data.new_expr.arg_count = 0;
            node->data.new_expr.args = nullptr;
            return node;
        }
    }

    // 处理基础类型
    switch (type->kind) {
        case TYPE_INT:
        case TYPE_NUM:
        case TYPE_BOOL: {
            ASTNode* n = new_node(NODE_NUMBER);
            n->data.number_str = strdup("0");
            return n;
        }
        case TYPE_FLOAT: {
            ASTNode* n = new_node(NODE_FLOAT);
            n->data.float_str = strdup("0.0");
            return n;
        }
        case TYPE_STRING:
        case TYPE_CHAR: {
            ASTNode* n = new_node(NODE_STRING);
            n->data.string = strdup("");
            return n;
        }
        case TYPE_ARRAY: {
            ASTNode* n = new_node(NODE_ARRAY_LITERAL);
            n->data.array_lit.elems = NULL;
            n->data.array_lit.count = 0;
            return n;
        }
        case TYPE_OBJECT: {
            // 对象字面量：根据类型生成默认键值对
            ASTNode* obj = new_node(NODE_OBJECT_LITERAL);
            int count = type->object_type.count;
            obj->data.object_lit.count = count;
            obj->data.object_lit.key_exprs = (ASTNode**)malloc(count * sizeof(ASTNode*));
            obj->data.object_lit.vals = (ASTNode**)malloc(count * sizeof(ASTNode*));
            for (int i = 0; i < count; ++i) {
                ASTNode* key_node = new_node(NODE_STRING);
                key_node->data.string = strdup(type->object_type.keys[i]);
                obj->data.object_lit.key_exprs[i] = key_node;
                obj->data.object_lit.vals[i] = make_default_value_for_type(type->object_type.types[i]);
            }
            obj->data.object_lit.spreads = NULL;
            obj->data.object_lit.spread_count = 0;
            return obj;
        }
        case TYPE_STRUCT: {
            ASTNode* obj = new_node(NODE_OBJECT_LITERAL);
            int count = type->struct_type.field_count;
            obj->data.object_lit.count = count;
            obj->data.object_lit.key_exprs = (ASTNode**)malloc(count * sizeof(ASTNode*));
            obj->data.object_lit.vals = (ASTNode**)malloc(count * sizeof(ASTNode*));
            for (int i = 0; i < count; ++i) {
                StructField& field = type->struct_type.fields[i];
                ASTNode* key_node = new_node(NODE_STRING);
                key_node->data.string = strdup(field.name);
                obj->data.object_lit.key_exprs[i] = key_node;
                obj->data.object_lit.vals[i] = make_default_value_for_type(field.type);
            }
            obj->data.object_lit.spreads = NULL;
            obj->data.object_lit.spread_count = 0;
            return obj;
        }
        case TYPE_UNION: {
            if (type->variant_type.variant_count == 0)
                return new_node(NODE_NULL);
            UnionVariant* first = &type->variant_type.variants[0];
            
            // 构造 __tag 字符串节点
            ASTNode* tag_node = new_node(NODE_STRING);
            tag_node->data.string = strdup(first->name);
            
            // 构造 __felder 数组节点
            ASTNode* fields_node = new_node(NODE_ARRAY_LITERAL);
            int param_cnt = 0;
            if (first->param_count > 0) {
                param_cnt = first->param_count;
                fields_node->data.array_lit.count = param_cnt;
                fields_node->data.array_lit.elems = (ASTNode**)malloc(param_cnt * sizeof(ASTNode*));
                for (int i = 0; i < param_cnt; ++i) {
                    fields_node->data.array_lit.elems[i] = make_default_value_for_type(first->param_types[i]);
                }
            } else {
                param_cnt = first->field_count;
                fields_node->data.array_lit.count = param_cnt;
                fields_node->data.array_lit.elems = (ASTNode**)malloc(param_cnt * sizeof(ASTNode*));
                for (int i = 0; i < param_cnt; ++i) {
                    fields_node->data.array_lit.elems[i] = make_default_value_for_type(first->named_fields[i].type);
                }
            }
            
            // 组装对象
            ASTNode* obj = new_node(NODE_OBJECT_LITERAL);
            obj->data.object_lit.count = 2;
            obj->data.object_lit.key_exprs = (ASTNode**)malloc(2 * sizeof(ASTNode*));
            obj->data.object_lit.vals = (ASTNode**)malloc(2 * sizeof(ASTNode*));
            // 键 "__tag"
            ASTNode* key1 = new_node(NODE_STRING);
            key1->data.string = strdup("__tag");
            obj->data.object_lit.key_exprs[0] = key1;
            obj->data.object_lit.vals[0] = tag_node;
            // 键 "__felder"
            ASTNode* key2 = new_node(NODE_STRING);
            key2->data.string = strdup("__felder");
            obj->data.object_lit.key_exprs[1] = key2;
            obj->data.object_lit.vals[1] = fields_node;
            return obj;
        }
        case TYPE_FUNCTION: {
            // 函数类型不能默认构造，返回 null（但类型检查会失败，故极少用到）
            return new_node(NODE_NULL);
        }
        case TYPE_POINTER:
            // 空指针用 null 表示
            return new_node(NODE_NULL);
        case TYPE_ANY: {
            // any 类型默认 null
            return new_node(NODE_NULL);
        }
        default:
            return new_node(NODE_NULL);
    }
}

static bool is_lvalue_node(ASTNode* node) {
    return node && (node->type == NODE_VARIABLE ||
                    node->type == NODE_ARRAY_ACCESS ||
                    node->type == NODE_OBJECT_ACCESS ||
                    node->type == NODE_THIS);
}

 static void assign_or_declare(const char* name, Value value) {
    Variable* var = get_var(name, false);
    if (var) {
        // 变量已存在，检查常量并赋值
        if (var->is_const) {
            kr_error("Fehler: 常量 '%s' 不能修改\n", name);
            
        }
        if (var->is_lazy) {
            kr_error("Fehler: 惰性变量 '%s' 不能赋值\n", name);
            
        }
        free_value(&var->value);
        var->value = value;
    } else {
        // 在当前作用域声明新变量（非 const）
        declare_var(name, false, value);
    }
 }

 void declare_lazy_var(const char* name, ASTNode* expr) {
    if (!current_scope) push_scope();
    // 检查重复声明（与普通变量逻辑类似）
    int idx = get_var_index_in_scope(current_scope, name);
    if (idx >= 0) {
        kr_error("Fehler: 变量 '%s' 已声明\n", name);
        
    }
    current_scope->vars = (Variable*)realloc(current_scope->vars,
                                 (current_scope->var_count + 1) * sizeof(Variable));
    Variable* var = &current_scope->vars[current_scope->var_count++];
    var->name = strdup(name);
    var->value = make_null();           // 未求值，值未定义
    var->is_const = false;              // 惰性变量可视为常量（只读），这里设为false也可，但赋值时会禁止
    var->is_lazy = true;
    var->evaluated = false;
    var->init_expr = expr;
    var->is_alias = false;
    var->alias_target = NULL;
    var->cached_value = make_null();
 }

 // 转义处理函数
 char* unescape_string(const char* s, size_t* out_len) {
    size_t len = strlen(s);
    char* result = (char*)malloc(len + 1);
    int j = 0;
    for (size_t i = 0; i < len; i++) {
        if (s[i] == '\\') {
            i++;
            if (i >= len) break;
            switch (s[i]) {
                case 'n': result[j++] = '\n'; break;
                case 't': result[j++] = '\t'; break;
                case 'r': result[j++] = '\r'; break;
                case 'b': result[j++] = '\b'; break;
                case '\\': result[j++] = '\\'; break;
                case '"': result[j++] = '"'; break;
                case '{': result[j++] = '{'; break;
                case '}': result[j++] = '}'; break;
                case 'u':   // 上移一行（\033[A）
                    result[j++] = '\033';
                    result[j++] = '[';
                    result[j++] = 'A';
                    break;
                case 'U':   // 上移到行首（\033[F）
                    result[j++] = '\033';
                    result[j++] = '[';
                    result[j++] = 'F';
                    break;

                case 'x': {
                    if (i + 2 < len && isxdigit(s[i+1]) && isxdigit(s[i+2])) {
                        char hex[3] = {s[i+1], s[i+2], '\0'};
                        result[j++] = (char)strtol(hex, NULL, 16);
                        i += 2;
                    } else {
                        result[j++] = 'x';
                    }
                    break;
                }
                case '#':
                    result[j++] = '\\';
                    result[j++] = '#';
                    break;
                default: {
                    // 八进制 \0 到 \377
                    if (s[i] >= '0' && s[i] <= '7') {
                        char octal[4] = {s[i], '\0'};
                        int k = 1;
                        while (k < 3 && i + k < len && s[i + k] >= '0' && s[i + k] <= '7') {
                            octal[k] = s[i + k];
                            k++;
                        }
                        octal[k] = '\0';
                        result[j++] = (char)strtol(octal, NULL, 8);
                        i += k - 1;
                    } else {
                        result[j++] = s[i];   // 未知转义保留原字符
                    }
                    break;
                }
            }
        } else {
            result[j++] = s[i];
        }
    }
    result[j] = '\0';
    if (out_len) *out_len = (size_t)j;
    return result;
 }
 
 void free_value(Value* v) {
    if (!v) return;
    switch (v->type) {
        case VAL_STRING:
            free(v->str_val);
            v->str_len = 0;
            break;
        case VAL_ARRAY:
            for (int i = 0; i < v->arr_val.length; i++)
                free_value(&v->arr_val.elements[i]);
            free(v->arr_val.elements);
            break;
        case VAL_OBJECT: {
            // 释放 __kd_daten 的内部指针（若存在）
            for (int i = 0; i < v->obj_val.count; i++) {
                if (strcmp(v->obj_val.entries[i].key, "__kd_daten") == 0) {
                    Value& inner = v->obj_val.entries[i].value;
                    if (inner.type == VAL_OBJECT && inner.obj_val.count >= 1) {
                        // 找到 __zgr 并删除 shared_ptr
                        for (int j = 0; j < inner.obj_val.count; j++) {
                            if (strcmp(inner.obj_val.entries[j].key, "__zgr") == 0 &&
                                (inner.obj_val.entries[j].value.type == VAL_INT || inner.obj_val.entries[j].value.type == VAL_INT64)) {
                                int64_t ptr_val = value_to_ll(inner.obj_val.entries[j].value);
                                std::shared_ptr<KDDataSet>* ptr = (std::shared_ptr<KDDataSet>*)ptr_val;
                                delete ptr;
                                // 清空该条目，防止二次释放
                                free_value(&inner.obj_val.entries[j].value);
                                inner.obj_val.entries[j].value = make_null();
                                break;
                            }
                        }
                        // 释放 inner 的所有条目（包括已清空的 __zgr）
                        for (int j = 0; j < inner.obj_val.count; j++) {
                            free(inner.obj_val.entries[j].key);
                            free_value(&inner.obj_val.entries[j].value);
                        }
                        free(inner.obj_val.entries);
                        inner.obj_val.entries = NULL;
                        inner.obj_val.count = 0;
                        inner.type = VAL_NULL;   // 标记为 null，防止后续通用循环再次释放
                    }
                    break; // 只需处理一个 __kd_daten
                }
            }

            // ---- 释放 stream handle ----
            for (int i = 0; i < v->obj_val.count; i++) {
                if (strcmp(v->obj_val.entries[i].key, "__stream_handle") == 0 &&
                    v->obj_val.entries[i].value.type == VAL_INT64) {
                    StreamHandle* h = (StreamHandle*)v->obj_val.entries[i].value.int64_val;
                    delete h;
                    v->obj_val.entries[i].value.int64_val = 0;   // 防二次释放
                    break;
                }
            }
        
            // 规则句柄检测
            int rule_id = -1;
            for (int i = 0; i < v->obj_val.count; i++) {
                if (strcmp(v->obj_val.entries[i].key, "__reg_id") == 0 &&
                    (v->obj_val.entries[i].value.type == VAL_INT || v->obj_val.entries[i].value.type == VAL_INT64)) {
                    rule_id = (int)mpz_get_si(*v->obj_val.entries[i].value.big_int);
                    break;
                }
            }
            if (rule_id != -1) {
                auto it = rule_states.find(rule_id);
                if (it != rule_states.end()) {
                    it->second->running = false;
                }
            }
        
            // 通用释放所有条目（此时 __kd_daten 条目已变为 VAL_NULL，安全）
            for (int i = 0; i < v->obj_val.count; i++) {
                free(v->obj_val.entries[i].key);
                free_value(&v->obj_val.entries[i].value);
            }
            free(v->obj_val.entries);
            break;
        }
        case VAL_FUNCTION:
            free(v->func_val.name);
            if (v->func_val.params) {
                for (int i = 0; i < v->func_val.param_count; i++)
                    free(v->func_val.params[i]);
                free(v->func_val.params);
            }
            free_ast(v->func_val.body);
            if (v->func_val.closure_scope)
                free_scope_chain(v->func_val.closure_scope);
            free_type_node(v->func_val.return_type);
            free(v->func_val.vararg_name);
            free(v->func_val.param_is_const);
            if (v->func_val.param_defaults) {
                for (int i = 0; i < v->func_val.param_count; i++)
                    if (v->func_val.param_defaults[i])
                        free_ast(v->func_val.param_defaults[i]);
                free(v->func_val.param_defaults);
            }
            if (v->func_val.param_types) {
                for (int i = 0; i < v->func_val.param_count; i++)
                    free_type_node(v->func_val.param_types[i]);
                free(v->func_val.param_types);
            }
            free_type_node(v->func_val.vararg_type);
            free(v->func_val.filename);
            break;
        case VAL_INT64:
            break;
        case VAL_INT:
            if (v->big_int) { mpz_clear(*v->big_int); free(v->big_int); }
            break;
        case VAL_FLOAT:
            if (v->mpf_val) { mpf_clear(*v->mpf_val); free(v->mpf_val); }
            break;
        case VAL_NULL:
            break;  // 无动态内存
        case VAL_FUTURE:
            // ID 对应的 future 在 warte 后被删除，或由全局 map 管理，无需额外释放
            break;
        case VAL_POINTER:
            if (v->ptr_val.smart_target) {
                // shared_ptr 自动管理生命周期
                delete v->ptr_val.smart_target;
                v->ptr_val.smart_target = nullptr;
            }
            // 裸指针不自动释放，由用户负责（zeigerFrei）
            if (v->ptr_val.elem_type) {
                free_type_node(v->ptr_val.elem_type);
                v->ptr_val.elem_type = nullptr;
            }
            break;
    }
    v->type = VAL_NULL;  // 重置类型，防止二次释放
 }
 
 long long value_to_int(Value v) {
    if (v.type == VAL_INT64) {
        // 检查是否溢出（实际 int64 一定在 long long 范围内）
        return v.int64_val;
    }
    if (v.type == VAL_INT) {
        if (mpz_fits_slong_p(*v.big_int))
            return mpz_get_si(*v.big_int);
        kr_error("整数太大无法转换为 long long");
    }
    if (v.type == VAL_FLOAT) {
        if (mpf_integer_p(*v.mpf_val))
            return mpf_get_si(*v.mpf_val);
        kr_error("浮点数不是整数");
    }
    if (v.type == VAL_STRING) return atoll(v.str_val);
    if (v.type == VAL_NULL) return 0;
    kr_error("无法转换为整数");
    return 0;
 }

 void value_to_mpz(const Value& v, mpz_t& out) {
    if (v.type == VAL_INT64) {
        mpz_set_int64(out, v.int64_val);
    } else if (v.type == VAL_INT) {
        mpz_set(out, *v.big_int);
    } else {
        kr_error("按位运算要求整数操作数");
    }
}

// 提取 long long（用于索引、循环等）
inline long long value_to_ll(const Value& v) {
    if (v.type == VAL_INT64) return v.int64_val;
    if (v.type == VAL_INT) {
        // 检查是否在 long long 范围内
        mpz_t min, max;
        mpz_init_set_str(min, "-9223372036854775808", 10);
        mpz_init_set_str(max, "9223372036854775807", 10);
        if (mpz_cmp(*v.big_int, min) >= 0 && mpz_cmp(*v.big_int, max) <= 0) {
            // 提取为 long long
            uint64_t u = 0;
            size_t c = 1;
            mpz_export(&u, &c, -1, 8, 0, 0, *v.big_int);
            mpz_clear(min);
            mpz_clear(max);
            return (long long)u;
        }
        mpz_clear(min);
        mpz_clear(max);
        kr_error("整数太大无法转换为 long long");
    }
    if (v.type == VAL_FLOAT) {
        if (mpf_integer_p(*v.mpf_val))
            return mpf_get_si(*v.mpf_val);
        kr_error("浮点数不是整数");
    }
    kr_error("无法转换为 long long");
    return 0;
}

// 提取 double（用于数学函数、打印等）
inline double value_to_double(const Value& v) {
    if (v.type == VAL_INT64) return (double)v.int64_val;
    if (v.type == VAL_INT) return mpz_get_d(*v.big_int);
    if (v.type == VAL_FLOAT) return mpf_get_d(*v.mpf_val);
    kr_error("无法转换为 double");
    return 0.0;
}

// 检查是否为惰性 Range 对象 { __range: 1, start, end, step }
static bool is_lazy_range(const Value& v) {
    if (v.type != VAL_OBJECT) return false;
    for (int i = 0; i < v.obj_val.count; i++) {
        if (strcmp(v.obj_val.entries[i].key, "__range") == 0) {
            const Value& mark = v.obj_val.entries[i].value;
            if (mark.type == VAL_INT64) return mark.int64_val != 0;
            if (mark.type == VAL_INT)   return mpz_sgn(*mark.big_int) != 0;
            return false;
        }
    }
    return false;
}

// 从惰性 Range 对象提取参数
static bool extract_range_params(const Value& v, int64_t& start, int64_t& end, int64_t& step) {
    if (!is_lazy_range(v)) return false;
    start = end = step = 0;
    bool has_start = false, has_end = false, has_step = false;
    for (int i = 0; i < v.obj_val.count; i++) {
        const char* key = v.obj_val.entries[i].key;
        const Value& val = v.obj_val.entries[i].value;
        if (strcmp(key, "start") == 0) { start = value_to_ll(val); has_start = true; }
        else if (strcmp(key, "end") == 0) { end = value_to_ll(val); has_end = true; }
        else if (strcmp(key, "step") == 0) { step = value_to_ll(val); has_step = true; }
    }
    return has_start && has_end && has_step;
}

// 计算惰性 Range 的元素个数
static int64_t lazy_range_count(int64_t start, int64_t end, int64_t step) {
    if (step == 0) return 0;
    if (step > 0) {
        if (start > end) return 0;
        return (end - start) / step + 1;
    } else {
        if (start < end) return 0;
        return (start - end) / (-step) + 1;
    }
}

// 将惰性 Range 展开为数组（仅当真正需要数组时调用）
static Value expand_lazy_range(const Value& v) {
    int64_t rs, re, rstep;
    if (!extract_range_params(v, rs, re, rstep)) return make_null();
    if (rstep == 0) kr_error("Range 步长不能为 0");
    int64_t count = lazy_range_count(rs, re, rstep);
    long long MAX = 1000000000LL;
    if (count > MAX) {
        kr_error("Range 元素数量 (%lld) 超过 %lld，无法展开", (long long)count, MAX);
    }
    if (count == 0) return make_array(nullptr, 0);
    Value* elems = (Value*)malloc(count * sizeof(Value));
    for (int64_t i = 0; i < count; i++) {
        elems[i] = make_int64(rs + i * rstep);
    }
    Value arr = make_array(elems, (int)count);
    free(elems);
    return arr;
}
 
 char* value_to_string(Value v) {
    if (v.type == VAL_STRING) {
        return strdup(v.str_val);
    }
    if (v.type == VAL_FLOAT) {
        char buffer[512];
        mp_exp_t exp;
        mpf_get_str(buffer, &exp, 10, 0, *v.mpf_val);
        if (!buffer[0]) return strdup("0.0");
    
        // 提取符号
        bool negative = (buffer[0] == '-');
        const char* mant_ptr = (negative) ? buffer + 1 : buffer;
        std::string mantissa(mant_ptr);
    
        std::string result;
        if (exp >= (int)mantissa.size()) {
            result = mantissa + std::string(exp - mantissa.size(), '0');
        } else if (exp > 0) {
            result = mantissa.substr(0, exp) + "." + mantissa.substr(exp);
        } else if (exp == 0) {
            result = "0." + mantissa;
        } else { // exp < 0
            result = "0." + std::string(-exp - 1, '0') + mantissa;
        }
    
        // 智能舍入（保留原逻辑）
        size_t dot = result.find('.');
        if (dot != std::string::npos) {
            std::string int_part = result.substr(0, dot);
            std::string frac = result.substr(dot + 1);
            if (frac.length() > 15) {
                std::string keep = frac.substr(0, 15);
                char next = frac[15];
                if (next >= '5') {
                    mpz_t keep_int;
                    mpz_init(keep_int);
                    mpz_set_str(keep_int, keep.c_str(), 10);
                    mpz_add_ui(keep_int, keep_int, 1);
                    char* new_keep = mpz_get_str(NULL, 10, keep_int);
                    keep = new_keep;
                    free(new_keep);
                    mpz_clear(keep_int);
                    if (keep.length() > 15) {
                        mpz_t int_mpz;
                        mpz_init(int_mpz);
                        mpz_set_str(int_mpz, int_part.c_str(), 10);
                        mpz_add_ui(int_mpz, int_mpz, 1);
                        char* new_int = mpz_get_str(NULL, 10, int_mpz);
                        int_part = new_int;
                        free(new_int);
                        mpz_clear(int_mpz);
                        keep = std::string(15, '0');
                    } else {
                        while (keep.length() < 15) keep = "0" + keep;
                    }
                }
                frac = keep;
            }
            // 检查全9进位
            if (frac.length() >= 3) {
                bool all_nine = true;
                for (char c : frac) if (c != '9') { all_nine = false; break; }
                if (all_nine) {
                    mpz_t int_mpz;
                    mpz_init(int_mpz);
                    mpz_set_str(int_mpz, int_part.c_str(), 10);
                    mpz_add_ui(int_mpz, int_mpz, 1);
                    char* new_int = mpz_get_str(NULL, 10, int_mpz);
                    int_part = new_int;
                    free(new_int);
                    mpz_clear(int_mpz);
                    frac = "0";
                }
            }
            result = int_part + "." + frac;
        }
    
        // 去除末尾多余零（保留至少一位小数）
        dot = result.find('.');
        if (dot != std::string::npos) {
            while (result.size() > dot + 1 && result.back() == '0')
                result.pop_back();
            if (result.back() == '.')
                result.push_back('0');
        }
    
        // 最后加上负号（如果有）
        if (negative) {
            // 注意：如果结果是 "0.0" 或 "0"，不添加负号（避免 "-0"）
            if (result != "0" && result != "0.0") {
                result = "-" + result;
            }
        }
    
        return strdup(result.c_str());
    }
    if (v.type == VAL_INT64) {
        char buf[32];
        snprintf(buf, sizeof(buf), "%lld", v.int64_val);
        return strdup(buf);
    }
    if (v.type == VAL_INT) {
        char* s = mpz_get_str(NULL, 10, *v.big_int);
        if (!s) return strdup("0");
        return s;
    }
    if (v.type == VAL_ARRAY) {
        std::string res = "[";
        for (int i = 0; i < v.arr_val.length; i++) {
            res += value_to_stdstring(v.arr_val.elements[i]);
            if (i < v.arr_val.length - 1) res += ", ";
        }
        res += "]";
        return strdup(res.c_str());
    }
    if (v.type == VAL_OBJECT) {
        if (is_lazy_range(v)) {
            int64_t rs, re, rstep;
            extract_range_params(v, rs, re, rstep);
            int64_t count = lazy_range_count(rs, re, rstep);
            if (count > 1000) {
                char buf[128];
                snprintf(buf, sizeof(buf), "<Bereich %lld..%lld, Schritt %lld>",
                         (long long)rs, (long long)re, (long long)rstep);
                return strdup(buf);
            }
            Value expanded = expand_lazy_range(v);
            char* s = value_to_string(expanded);
            free_value(&expanded);
            return s;
        }
        // 检查是否为规则句柄（__rule_id）
        int rule_id = -1;
        for (int i = 0; i < v.obj_val.count; i++) {
            if (strcmp(v.obj_val.entries[i].key, "__reg_id") == 0 &&
                (v.obj_val.entries[i].value.type == VAL_INT || v.obj_val.entries[i].value.type == VAL_INT64)) {
                rule_id = (int)value_to_ll(v.obj_val.entries[i].value);
                break;
            }
        }
        if (rule_id != -1) {
            auto it = rule_states.find(rule_id);
            if (it != rule_states.end()) {
                std::lock_guard<std::mutex> lock(it->second->mtx);
                // 递归调用 value_to_string 来转换缓存值
                char* result = value_to_string(it->second->cached_value);
                return result;
            } else {
                return strdup("null");
            }
        }
        // 普通对象
        std::string res = "{";
        for (int i = 0; i < v.obj_val.count; i++) {
            res += v.obj_val.entries[i].key;
            res += ": ";
            res += value_to_stdstring(v.obj_val.entries[i].value);
            if (i < v.obj_val.count - 1) res += ", ";
        }
        res += "}";
        return strdup(res.c_str());
    }
    if (v.type == VAL_FUNCTION) {
        char buf[256];
        snprintf(buf, sizeof(buf), "<funktion %s>", v.func_val.name ? v.func_val.name : "anonym");
        return strdup(buf);
    }
    if (v.type == VAL_NULL) {
        return strdup("null");
    }
    if (v.type == VAL_FUTURE) {
        return strdup("<future>");
    }
    if (v.type == VAL_POINTER) {
        char buf[128];
        void* addr = v.ptr_val.smart_target
                     ? (void*)v.ptr_val.smart_target->get()
                     : (void*)v.ptr_val.raw_target;
        if (v.ptr_val.smart_target) {
            snprintf(buf, sizeof(buf), "<schlauer Zeiger %p>", addr);
        } else {
            snprintf(buf, sizeof(buf), "<Zeiger %p>", addr);
        }
        return strdup(buf);
    }
    // 未知类型
    char buffer[256];
    snprintf(buffer, sizeof(buffer), "Value '%d': UNBEKAN", v.type);
    return strdup(buffer);
 }

static std::string value_to_stdstring(const Value& v) {
    if (v.type == VAL_STRING) {
        if (!v.str_val) return std::string();
        return std::string(v.str_val, v.str_len);
    }
    char* s = value_to_string(v);   // 其他类型仍然走旧路径
    std::string out(s ? s : "");
    free(s);
    return out;
}

[[maybe_unused]] static char* value_to_string_len(Value v, size_t* out_len) {
    if (v.type == VAL_STRING) {
        char* result = (char*)malloc(v.str_len + 1);
        memcpy(result, v.str_val, v.str_len);
        result[v.str_len] = '\0';
        if (out_len) *out_len = v.str_len;
        return result;
    }
    char* s = value_to_string(v);
    if (out_len) *out_len = strlen(s);
    return s;
}

// ==================== IP 地址获取辅助 ====================

// 获取本机所有 IP 地址，返回 (IP 字符串, 是否为 IPv6) 的列表
static std::vector<std::pair<std::string, bool>> get_all_local_ips() {
    std::vector<std::pair<std::string, bool>> result;
    char buf[INET6_ADDRSTRLEN];
    
#ifdef _WIN32
    ULONG family = AF_UNSPEC;
    ULONG flags = GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST | GAA_FLAG_SKIP_DNS_SERVER;
    ULONG buflen = 15000;
    PIP_ADAPTER_ADDRESSES addrs = (PIP_ADAPTER_ADDRESSES)malloc(buflen);
    if (!addrs) return result;
    
    ULONG ret = GetAdaptersAddresses(family, flags, NULL, addrs, &buflen);
    if (ret == ERROR_BUFFER_OVERFLOW) {
        free(addrs);
        addrs = (PIP_ADAPTER_ADDRESSES)malloc(buflen);
        if (!addrs) return result;
        ret = GetAdaptersAddresses(family, flags, NULL, addrs, &buflen);
    }
    
    if (ret == NO_ERROR) {
        for (PIP_ADAPTER_ADDRESSES p = addrs; p; p = p->Next) {
            if (p->OperStatus != IfOperStatusUp) continue;
            for (PIP_ADAPTER_UNICAST_ADDRESS ua = p->FirstUnicastAddress; ua; ua = ua->Next) {
                struct sockaddr* sa = ua->Address.lpSockaddr;
                if (!sa) continue;
                if (sa->sa_family == AF_INET) {
                    struct sockaddr_in* sin = (struct sockaddr_in*)sa;
                    if (inet_ntop(AF_INET, &sin->sin_addr, buf, sizeof(buf))) {
                        result.push_back({std::string(buf), false});
                    }
                } else if (sa->sa_family == AF_INET6) {
                    struct sockaddr_in6* sin6 = (struct sockaddr_in6*)sa;
                    if (inet_ntop(AF_INET6, &sin6->sin6_addr, buf, sizeof(buf))) {
                        result.push_back({std::string(buf), true});
                    }
                }
            }
        }
    }
    free(addrs);
#else
    struct ifaddrs* ifaddr = nullptr;
    if (getifaddrs(&ifaddr) == -1) return result;
    
    for (struct ifaddrs* ifa = ifaddr; ifa; ifa = ifa->ifa_next) {
        if (!ifa->ifa_addr) continue;
        int family = ifa->ifa_addr->sa_family;
        if (family == AF_INET) {
            struct sockaddr_in* sin = (struct sockaddr_in*)ifa->ifa_addr;
            if (inet_ntop(AF_INET, &sin->sin_addr, buf, sizeof(buf))) {
                result.push_back({std::string(buf), false});
            }
        } else if (family == AF_INET6) {
            struct sockaddr_in6* sin6 = (struct sockaddr_in6*)ifa->ifa_addr;
            if (inet_ntop(AF_INET6, &sin6->sin6_addr, buf, sizeof(buf))) {
                result.push_back({std::string(buf), true});
            }
        }
    }
    freeifaddrs(ifaddr);
#endif
    return result;
}

// 判断是否为环回地址
static bool is_loopback_ip(const std::string& ip) {
    if (ip == "127.0.0.1" || ip == "::1") return true;
    if (ip.rfind("127.", 0) == 0) return true;
    if (ip.rfind("::ffff:127.", 0) == 0) return true;
    return false;
}

// 将 sockaddr 格式化为 IP 字符串
static std::string format_sockaddr(const struct sockaddr* addr) {
    if (!addr) return "";
    char buf[INET6_ADDRSTRLEN];
    if (addr->sa_family == AF_INET) {
        struct sockaddr_in* sin = (struct sockaddr_in*)addr;
        if (inet_ntop(AF_INET, &sin->sin_addr, buf, sizeof(buf)))
            return std::string(buf);
    } else if (addr->sa_family == AF_INET6) {
        struct sockaddr_in6* sin6 = (struct sockaddr_in6*)addr;
        // IPv4-mapped IPv6 -> 纯 IPv4（例如 ::ffff:192.168.1.5 → 192.168.1.5）
        if (IN6_IS_ADDR_V4MAPPED(&sin6->sin6_addr)) {
            struct in_addr v4;
            memcpy(&v4, &sin6->sin6_addr.s6_addr[12], 4);
            if (inet_ntop(AF_INET, &v4, buf, sizeof(buf)))
                return std::string(buf);
        }
        if (inet_ntop(AF_INET6, &sin6->sin6_addr, buf, sizeof(buf)))
            return std::string(buf);
    }
    return "";
}

// 构造主机 IP 信息对象 { host, lokal, ipv4, ipv6 }
static Value make_host_ip_object() {
    auto ips = get_all_local_ips();
    std::vector<Value> v4_vals, v6_vals;
    std::string primary_host;
    
    for (auto& pr : ips) {
        const std::string& ip = pr.first;
        bool is_v6 = pr.second;
        if (is_loopback_ip(ip)) continue;
        if (is_v6) {
            // 跳过 link-local 与临时 IPv6
            if (ip.rfind("fe80:", 0) == 0) continue;
            if (ip.rfind("fd", 0) == 0 || ip.rfind("fc", 0) == 0) {
                // ULA 地址保留
            }
            v6_vals.push_back(make_string(ip.c_str()));
        } else {
            v4_vals.push_back(make_string(ip.c_str()));
            if (primary_host.empty()) primary_host = ip;   // 第一个 IPv4 作为主 host
        }
    }
    // 无 IPv4 时回退到 IPv6
    if (primary_host.empty() && !v6_vals.empty()) {
        primary_host.assign(v6_vals[0].str_val, v6_vals[0].str_len);
    }
    if (primary_host.empty()) primary_host = "127.0.0.1";
    
    Value ipv4_arr = make_array(v4_vals.data(), (int)v4_vals.size());
    Value ipv6_arr = make_array(v6_vals.data(), (int)v6_vals.size());
    for (auto& v : v4_vals) free_value(&v);
    for (auto& v : v6_vals) free_value(&v);
    
    ObjectEntry entries[4];
    entries[0].key = strdup("host");
    entries[0].value = make_string(primary_host.c_str());
    entries[1].key = strdup("lokal");
    entries[1].value = make_string("127.0.0.1");
    entries[2].key = strdup("ipv4");
    entries[2].value = ipv4_arr;
    entries[3].key = strdup("ipv6");
    entries[3].value = ipv6_arr;
    
    Value result = make_object(entries, 4);
    for (int i = 0; i < 4; ++i) {
        free(entries[i].key);
        free_value(&entries[i].value);
    }
    return result;
}

 class HttpServer {
    public:
        using Handler = std::function<Value(Value)>;  // 按值传递
    
        HttpServer(uint16_t port, Handler handler)
            : port_(port), handler_(handler), daemon_(nullptr), running_(true) {}
    
        ~HttpServer() { stop(); }
    
        bool start() {
            daemon_ = MHD_start_daemon(
                MHD_USE_INTERNAL_POLLING_THREAD | MHD_USE_ERROR_LOG,  // 使用内部轮询线程，并输出错误日志
                port_, nullptr, nullptr,
                &HttpServer::request_handler_cb, this,
                MHD_OPTION_THREAD_POOL_SIZE, 32,
                MHD_OPTION_END);
            return daemon_ != nullptr;
        }
    
        void stop() {
            if (daemon_) {
                MHD_stop_daemon(daemon_);
                daemon_ = nullptr;
            }
            running_ = false;   // 让 wait 退出
        }
    
        void wait() {
            while (running_) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
        }
    
        void set_running(bool run) { running_ = run; }
    
    private:
        struct SessionData {
            std::string body;
        };
    
        static MHD_Result request_handler_cb(void* cls,
                                             struct MHD_Connection* connection,
                                             const char* url,
                                             const char* method,
                                             const char* /* version */,
                                             const char* upload_data,
                                             size_t* upload_data_size,
                                             void** con_cls) {
            auto* server = static_cast<HttpServer*>(cls);
            if (*con_cls == nullptr) {
                *con_cls = new SessionData();
                return MHD_YES;
            }
            auto* session = static_cast<SessionData*>(*con_cls);
    
            // 收集请求体
            if (*upload_data_size != 0) {
                session->body.append(upload_data, *upload_data_size);
                *upload_data_size = 0;
                return MHD_YES;
            }
    
            // 构建请求对象
            ObjectEntry entries[5];
            int idx = 0;
            entries[idx].key = strdup("methode");
            entries[idx].value = make_string(method);
            idx++;
            entries[idx].key = strdup("pfad");
            entries[idx].value = make_string(url);
            idx++;

            // ---- 客户端 IP（访问方） ----
            std::string client_ip;
            const union MHD_ConnectionInfo* cinfo =
                MHD_get_connection_info(connection, MHD_CONNECTION_INFO_CLIENT_ADDRESS);
            if (cinfo && cinfo->client_addr) {
                client_ip = format_sockaddr(cinfo->client_addr);
            }
            entries[idx].key = strdup("ip");
            entries[idx].value = make_string(client_ip.c_str());
            idx++;
    
            // 收集请求头
            std::vector<ObjectEntry> header_vec;
            MHD_get_connection_values(connection, MHD_HEADER_KIND,
                [](void* cls, enum MHD_ValueKind /* kind */, const char* key, const char* value) -> MHD_Result {
                    auto* vec = static_cast<std::vector<ObjectEntry>*>(cls);
                    vec->push_back({strdup(key), make_string(value)});
                    return MHD_YES;
                }, &header_vec);

            // 将 header_vec 转换为对象
            entries[idx].key = strdup("kopf");
            entries[idx].value = make_object(header_vec.data(), (int)header_vec.size());
            idx++;

            entries[idx].key = strdup("inhalt");
            entries[idx].value = make_string_len(session->body.data(), session->body.size());
            idx++;
    
            Value req_obj = make_object(entries, idx);
    
            // 释放 entries（make_object 已复制）
            for (int i = 0; i < idx; i++) {
                free(entries[i].key);
                free_value(&entries[i].value);
            }
            // 释放 header_vec 中的内存
            for (auto& h : header_vec) {
                free(h.key);
                free_value(&h.value);
            }
    
            // 调用用户处理器（req 按值传递）
            Value resp = server->handler_(req_obj);
            free_value(&req_obj);
    
            // ---------- 检测是否为流式响应 ----------
            StreamHandle* user_stream = nullptr;
            for (int i = 0; i < resp.obj_val.count; i++) {
                if (strcmp(resp.obj_val.entries[i].key, "__stream_handle") == 0 &&
                    resp.obj_val.entries[i].value.type == VAL_INT64) {
                    user_stream = (StreamHandle*)resp.obj_val.entries[i].value.int64_val;
                    break;
                }
            }

            int status = 200;
            std::vector<std::pair<std::string, std::string>> hdrs;

            for (int i = 0; i < resp.obj_val.count; i++) {
                const char* k = resp.obj_val.entries[i].key;
                Value& v = resp.obj_val.entries[i].value;
                if (strcmp(k, "zustand") == 0) {
                    status = (int)value_to_int(v);
                } else if (strcmp(k, "kopf") == 0 && v.type == VAL_OBJECT) {
                    for (int j = 0; j < v.obj_val.count; j++) {
                        if (v.obj_val.entries[j].value.type == VAL_STRING) {
                            hdrs.emplace_back(
                                v.obj_val.entries[j].key,
                                std::string(v.obj_val.entries[j].value.str_val,
                                            v.obj_val.entries[j].value.str_len));
                        }
                    }
                }
            }

            // ---------- 流式分支 ----------
            if (user_stream) {
                bool has_cc = false;
                for (auto& h : hdrs) if (h.first == "Cache-Control") { has_cc = true; break; }
                if (!has_cc) hdrs.emplace_back("Cache-Control", "no-cache");
                hdrs.emplace_back("X-Accel-Buffering", "no");   // 反代关闭缓冲

                // MHD 侧使用独立的 handle，通过 shared_ptr 共享状态
                StreamHandle* mhd_handle = new StreamHandle{ user_stream->state };

                struct MHD_Response* response = MHD_create_response_from_callback(
                    MHD_SIZE_UNKNOWN,       // 未知长度 → chunked
                    4096,
                    &stream_reader_cb,
                    (void*)mhd_handle,
                    &stream_free_cb);

                if (!response) {
                    stream_free_cb(mhd_handle);   // 内部会 delete
                    free_value(&resp);
                    delete session;
                    *con_cls = nullptr;
                    return MHD_NO;
                }

                for (auto& h : hdrs) {
                    MHD_add_response_header(response, h.first.c_str(), h.second.c_str());
                }

                int ret = MHD_queue_response(connection, status, response);
                MHD_destroy_response(response);

                free_value(&resp);
                delete session;
                *con_cls = nullptr;
                return (ret == MHD_YES) ? MHD_YES : MHD_NO;
            }

            // ---------- 普通 buffer 分支 ----------
            {
                std::string body;
                for (int i = 0; i < resp.obj_val.count; i++) {
                    if (strcmp(resp.obj_val.entries[i].key, "inhalt") == 0) {
                        char* s = value_to_string(resp.obj_val.entries[i].value);
                        body = s;
                        free(s);
                    }
                }
                free_value(&resp);
            
                struct MHD_Response* response = MHD_create_response_from_buffer(
                    body.size(), (void*)body.c_str(), MHD_RESPMEM_MUST_COPY);
                if (!response) {
                    delete session;
                    *con_cls = nullptr;
                    return MHD_NO;
                }
                for (auto& h : hdrs) {
                    MHD_add_response_header(response, h.first.c_str(), h.second.c_str());
                }
                int ret = MHD_queue_response(connection, status, response);
                MHD_destroy_response(response);
            
                delete session;
                *con_cls = nullptr;
                return (ret == MHD_YES) ? MHD_YES : MHD_NO;
            }
        }
    
        uint16_t port_;
        Handler handler_;
        struct MHD_Daemon* daemon_;
        std::atomic<bool> running_;
    };

struct HttpOptions {
    std::string daten;              // 请求体
    long zeitgrenze = 30;           // 超时秒数
    bool umleitung = true;          // 跟随重定向
    bool pruefeSSL = true;          // 验证SSL
    std::vector<std::string> kopfzeilen;  // 请求头列表
};

static HttpOptions parse_http_options(Value optionen) {
    HttpOptions opts;
    if (optionen.type != VAL_OBJECT) return opts;

    for (int i = 0; i < optionen.obj_val.count; i++) {
        const char* schlüssel = optionen.obj_val.entries[i].key;
        Value wert = optionen.obj_val.entries[i].value;

        if (strcmp(schlüssel, "daten") == 0) {
            if (wert.type == VAL_STRING) opts.daten = wert.str_val;
            else {
                char* s = value_to_string(wert);
                opts.daten = s;
                free(s);
            }
        }
        else if (strcmp(schlüssel, "zeitgre") == 0) {
            if (wert.type == VAL_INT || wert.type == VAL_INT64) opts.zeitgrenze = value_to_ll(wert);
            else if (wert.type == VAL_FLOAT) opts.zeitgrenze = (long)value_to_double(wert);
        }
        else if (strcmp(schlüssel, "umleit") == 0) {
            opts.umleitung = value_to_bool(wert) != 0;
        }
        else if (strcmp(schlüssel, "pruefeSSL") == 0) {
            opts.pruefeSSL = value_to_bool(wert) != 0;
        }
        else if (strcmp(schlüssel, "kopf") == 0) {
            if (wert.type == VAL_OBJECT) {
                for (int j = 0; j < wert.obj_val.count; j++) {
                    char* hschl = wert.obj_val.entries[j].key;
                    Value hwert = wert.obj_val.entries[j].value;
                    if (hwert.type == VAL_STRING) {
                        std::string zeile = std::string(hschl) + ": " + hwert.str_val;
                        opts.kopfzeilen.push_back(zeile);
                    }
                }
            }
        }
    }
    return opts;
}

static Value http_anfrage(const std::string& methode, const std::string& url, Value optionen) {
    CURL* curl = curl_easy_init();
    if (!curl) kr_error("curl konnte nicht initialisiert werden");

    HttpOptions opts = parse_http_options(optionen);

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, opts.zeitgrenze);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, opts.umleitung ? 1L : 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, opts.pruefeSSL ? 1L : 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, opts.pruefeSSL ? 2L : 0L);

    if (methode == "GET") {
        curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);
    } else if (methode == "HEAD") {
        curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
        // HEAD 请求无响应体，但会接收响应头
    } else if (methode == "POST") {
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        if (!opts.daten.empty())
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, opts.daten.c_str());
    } else if (methode == "PUT" || methode == "DELETE" || methode == "PATCH") {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, methode.c_str());
        if (!opts.daten.empty())
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, opts.daten.c_str());
    } else {
        kr_error("Unbekan HTTP-Methode: %s", methode.c_str());
    }

    // Kopfzeilen setzen
    struct curl_slist* kopf_liste = NULL;
    for (const auto& h : opts.kopfzeilen)
        kopf_liste = curl_slist_append(kopf_liste, h.c_str());
    if (kopf_liste)
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, kopf_liste);

    // Antwortkörper sammeln
    std::string antwort_text;
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &antwort_text);

    // Antwortkopf sammeln
    std::string kopf_text;
    curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_HEADERDATA, &kopf_text);

    CURLcode res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        if (kopf_liste) curl_slist_free_all(kopf_liste);
        curl_easy_cleanup(curl);
        kr_error("HTTP-Anfrage fehlgeschlagen: %s", curl_easy_strerror(res));
    }

    long statuscode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &statuscode);

    // Kopfzeilen parsen (einfach)
    ObjectEntry* kopf_eintraege = NULL;
    int kopf_anzahl = 0;
    std::istringstream kopf_stream(kopf_text);
    std::string zeile;
    while (std::getline(kopf_stream, zeile)) {
        if (!zeile.empty() && zeile.back() == '\r') zeile.pop_back();
        if (zeile.empty()) continue;
        size_t doppelpunkt = zeile.find(':');
        if (doppelpunkt != std::string::npos) {
            std::string schl = zeile.substr(0, doppelpunkt);
            std::string wert = zeile.substr(doppelpunkt + 1);
            size_t start = wert.find_first_not_of(" \t");
            if (start != std::string::npos) wert = wert.substr(start);
            kopf_eintraege = (ObjectEntry*)realloc(kopf_eintraege, (kopf_anzahl + 1) * sizeof(ObjectEntry));
            kopf_eintraege[kopf_anzahl].key = strdup(schl.c_str());
            kopf_eintraege[kopf_anzahl].value = make_string(wert.c_str());
            kopf_anzahl++;
        }
    }

    // Rückgabe-Objekt aufbauen
    ObjectEntry* ergebnis_eintraege = (ObjectEntry*)malloc(3 * sizeof(ObjectEntry));
    ergebnis_eintraege[0].key = strdup("zustand");
    ergebnis_eintraege[0].value = make_int(statuscode);
    ergebnis_eintraege[1].key = strdup("kopf");
    ergebnis_eintraege[1].value = make_object(kopf_eintraege, kopf_anzahl);
    ergebnis_eintraege[2].key = strdup("inhalt");
    ergebnis_eintraege[2].value = make_string_len(antwort_text.data(), antwort_text.size());

    // Aufräumen
    for (int i = 0; i < kopf_anzahl; i++) {
        free(kopf_eintraege[i].key);
        free_value(&kopf_eintraege[i].value);
    }
    free(kopf_eintraege);
    if (kopf_liste) curl_slist_free_all(kopf_liste);
    curl_easy_cleanup(curl);

    Value rueckgabe = make_object(ergebnis_eintraege, 3);
    // make_object kopiert die Einträge, daher können wir unser Array freigeben
    for (int i = 0; i < 3; i++) {
        free(ergebnis_eintraege[i].key);
        free_value(&ergebnis_eintraege[i].value);
    }
    free(ergebnis_eintraege);
    return rueckgabe;
}

static Value ac_http_anfrage(const std::string& methode, const std::string& url, Value optionen) {
    std::string* methode_kopie = new std::string(methode);
    std::string* url_kopie = new std::string(url);
    Value optionen_kopie = copy_value(optionen);

    int id = ++next_future_id;
    auto future = std::async(std::launch::async, [methode_kopie, url_kopie, optionen_kopie]() mutable {
        Value ergebnis = http_anfrage(*methode_kopie, *url_kopie, optionen_kopie);
        Value* heap_wert = new Value(copy_value(ergebnis));
        free_value(&ergebnis);
        delete methode_kopie;
        delete url_kopie;
        free_value(&optionen_kopie);
        return std::shared_ptr<Value>(heap_wert, [](Value* p) {
            if (p) { free_value(p); delete p; }
        });
    });

    {
        std::lock_guard<std::mutex> lock(future_map_mutex);
        future_map[id] = future.share();
    }

    Value zukunft;
    zukunft.type = VAL_FUTURE;
    zukunft.future_state.future_id = id;
    return zukunft;
}

// 预处理：递归展开 imp 语句
static std::string expand_imports(const std::string& source,
    const std::string& base_dir,
    std::set<fs::path>& visited,
    std::unordered_map<std::string, std::vector<std::string>>& alias_map,
    const std::string& current_file,
    const std::string& top_level_file) {
    std::string result;
    std::istringstream stream(source);
    std::string line;
    std::regex imp_regex(R"(^\s*imp\s+([^\s;]+)(?:\s+as\s+(\w+))?\s*;?)");
    fs::path base_path = fs::u8path(base_dir);

    bool in_block_comment = false;   // 跨行块注释状态
    int line_num = 1;                // 当前处理行号（从1开始）

    while (std::getline(stream, line)) {
        std::string clean_line;
        size_t i = 0;
        bool in_string = false;
        char string_char = '\0';
        bool escape = false;

        // 逐字符扫描，提取非注释、非字符串的“有效”字符
        while (i < line.size()) {
            char c = line[i];

            if (in_block_comment) {
                // 寻找块注释结束符 |/
                if (c == '|' && i + 1 < line.size() && line[i + 1] == '/') {
                    in_block_comment = false;
                    i += 2;
                    continue;
                }
                i++;
                continue;
            }

            // 不在块注释中
            if (in_string) {
                clean_line.push_back(c);
                if (escape) {
                    escape = false;
                } else if (c == '\\') {
                    escape = true;
                } else if (c == string_char) {
                    in_string = false;
                }
                i++;
                continue;
            }
            // 处理字符串字面量（进入字符串）
            if (c == '"' || c == '\'') {
                in_string = true;
                string_char = c;
                clean_line.push_back(c);
                i++;
                continue;
            }

            // 处理行注释 //
            if (c == '/' && i + 1 < line.size() && line[i + 1] == '/') {
                break;  // 忽略行余下部分
            }

            // 处理块注释 /| ... |/
            if (c == '/' && i + 1 < line.size() && line[i + 1] == '|') {
                in_block_comment = true;
                i += 2;
                continue;
            }

            // 普通字符，加入 clean_line
            clean_line.push_back(c);
            i++;
        }

        // 在 clean_line 上尝试匹配 imp 语句
        std::smatch match;
        if (!clean_line.empty() && std::regex_search(clean_line, match, imp_regex) && match.size() >= 2) {
            // 记录 imp 所在的行号（用于恢复）
            int imp_line = line_num;

            // ---- 处理导入（与原逻辑完全一致） ----
            std::string raw_token = match[1].str();
            bool has_quote = false;
            std::string filename_or_module;
            if (raw_token.front() == '"' || raw_token.front() == '\'') {
                has_quote = true;
                filename_or_module = raw_token.substr(1, raw_token.size() - 2);
            } else {
                filename_or_module = raw_token;
            }

            std::string alias = match.size() > 2 ? match[2].str() : "";

            fs::path full_path;

            if (!has_quote) {
                std::string abs_path = resolve_module_path(filename_or_module, has_quote, base_dir);
                if (abs_path.empty()) {
                    preprocess_error_at(imp_line, 1,
                        "找不到模块文件 '%s'", filename_or_module.c_str());
                }
                full_path = fs::u8path(abs_path);
            } else {
                fs::path try_path = fs::u8path(filename_or_module);

                if (fs::exists(try_path)) {
                    full_path = try_path;
                } else {
                    fs::path rel_path = base_path / try_path;
                    if (fs::exists(rel_path)) {
                        full_path = rel_path;
                    } else {
                        fs::path lag_path = exe_dir / "lag" / try_path;
                        if (fs::exists(lag_path)) {
                            full_path = lag_path;
                        } else if (filename_or_module.find(".kr") == std::string::npos) {
                            fs::path lag_kr = exe_dir / "lag" / (filename_or_module + ".kr");
                            if (fs::exists(lag_kr)) {
                                full_path = lag_kr;
                            }
                        }
                    }
                }

                if (full_path.empty()) {
                    preprocess_error_at(imp_line, 1,
                        "找不到导入文件 '%s'", filename_or_module.c_str());
                }
            }

            if (visited.find(full_path) != visited.end()) {
                preprocess_error_at(imp_line, 1,
                    "循环导入 '%s'", full_path.string().c_str());
            }
            visited.insert(full_path);

            std::ifstream ifs(full_path, std::ios::binary);
            if (!ifs) {
                preprocess_error_at(imp_line, 1,
                    "无法打开导入文件 '%s'", full_path.string().c_str());
            }
            std::string content((std::istreambuf_iterator<char>(ifs)),
                                std::istreambuf_iterator<char>());
            ifs.close();

            std::string parent_dir = full_path.parent_path().string();
            // 递归展开
            std::string expanded = expand_imports(content, parent_dir, visited, alias_map,
                full_path.string(),
                top_level_file.empty() ? current_file : top_level_file);

            // 计算 expanded 的行数
            int expanded_line_count = 1;
            (void)expanded_line_count;
            if (!expanded.empty()) {
            expanded_line_count = std::count(expanded.begin(), expanded.end(), '\n') + 1;
            }

            // 插入模块开始指令
            result += "#zeile 1 \"" + full_path.generic_string() + "\";\n";

            // 插入展开内容
            if (!alias.empty()) {
                result += "umf \"" + alias + "\" {\n";
                result += expanded;
                result += "}\n";
                result += "der " + alias + " = umf(\"" + alias + "\");\n";
            } else {
                result += expanded;
            }

            // 恢复主文件行号
            std::string restore_file = top_level_file.empty()
                ? (current_file.empty() ? "<main>" : current_file)
                : top_level_file;
            result += "#zeile " + std::to_string(imp_line + 1)
                    + " \"" + restore_file + "\";\n";

            visited.erase(full_path);
        } else {
            // 非 imp 行，原样保留（包括注释、空白等）
            result += line + "\n";
        }

        line_num++;   // 每处理一行，行号加 1
    }

    return result;
}

// ---------- JSON 解析器 ----------
class JSONParser {
    const std::string& input;
    size_t pos;

    void skip_whitespace() {
        while (pos < input.size() && isspace((unsigned char)input[pos])) ++pos;
    }

    char peek() const { return pos < input.size() ? input[pos] : '\0'; }
    char consume() { return pos < input.size() ? input[pos++] : '\0'; }

    // 解析字符串（处理转义）
    std::string parse_string() {
        if (consume() != '"') kr_error("JSON: 期望 '\"'");
        std::string result;
        while (true) {
            char c = consume();
            if (c == '"') break;
            if (c == '\\') {
                c = consume();
                switch (c) {
                    case '"':  result += '"'; break;
                    case '\\': result += '\\'; break;
                    case '/':  result += '/'; break;
                    case 'b':  result += '\b'; break;
                    case 'f':  result += '\f'; break;
                    case 'n':  result += '\n'; break;
                    case 'r':  result += '\r'; break;
                    case 't':  result += '\t'; break;
                    case 'u': {
                        // 简单处理 Unicode 转义（仅支持 BMP，转成 UTF-8）
                        char hex[5] = {0};
                        for (int i = 0; i < 4; ++i) hex[i] = consume();
                        unsigned int code = strtoul(hex, nullptr, 16);
                        if (code < 0x80) {
                            result += (char)code;
                        } else if (code < 0x800) {
                            result += (char)(0xC0 | (code >> 6));
                            result += (char)(0x80 | (code & 0x3F));
                        } else {
                            result += (char)(0xE0 | (code >> 12));
                            result += (char)(0x80 | ((code >> 6) & 0x3F));
                            result += (char)(0x80 | (code & 0x3F));
                        }
                        break;
                    }
                    default:
                        kr_error("JSON: 无效转义 '\\%c'", c);
                }
            } else {
                result += c;
            }
        }
        return result;
    }

    // 解析数字（支持整数和浮点，使用 GMP）
    Value parse_number() {
        const char* start = input.c_str() + pos;
        char* end = nullptr;
        strtod(start, &end);   // 仅用于确定结束位置
        if (end == start) {
            kr_error("JSON: 无效数字");
        }
        std::string num_str(start, end - start);
        pos += (end - start);
    
        bool is_int = (num_str.find('.') == std::string::npos &&
                       num_str.find('e') == std::string::npos &&
                       num_str.find('E') == std::string::npos);
        if (is_int) {
            mpz_t tmp; mpz_init(tmp);
            if (mpz_set_str(tmp, num_str.c_str(), 10) != 0) {
                mpz_clear(tmp);
                kr_error("JSON: 无效整数");
            }
            Value v = make_int(tmp);
            mpz_clear(tmp);
            return v;
        } else {
            mpf_t f; mpf_init(f);
            if (mpf_set_str(f, num_str.c_str(), 10) != 0) {
                mpf_clear(f);
                kr_error("JSON: 无效浮点数");
            }
            Value v = make_float(f);
            mpf_clear(f);
            return v;
        }
    }

    Value parse_value() {
        skip_whitespace();
        char c = peek();
        if (c == '"') return make_string(parse_string().c_str());
        if (c == '{') return parse_object();
        if (c == '[') return parse_array();
        if (c == 't') {
            if (input.compare(pos, 4, "true") == 0) { pos += 4; return make_int(1LL); }
            kr_error("JSON: 期望 true");
        }
        if (c == 'f') {
            if (input.compare(pos, 5, "false") == 0) { pos += 5; return make_int(0LL); }
            kr_error("JSON: 期望 false");
        }
        if (c == 'n') {
            if (input.compare(pos, 4, "null") == 0) { pos += 4; return make_null(); }
            kr_error("JSON: 期望 null");
        }
        if (isdigit(c) || c == '-') return parse_number();
        kr_error("JSON: 意外的字符 '%c'", c);
        return make_null();
    }

    Value parse_object() {
        if (consume() != '{') kr_error("JSON: 期望 '{'");
        ObjectEntry* entries = nullptr;
        int count = 0;
        skip_whitespace();
        if (peek() == '}') {
            consume();
            Value v; v.type = VAL_OBJECT; v.obj_val.count = 0; v.obj_val.entries = nullptr;
            return v;
        }
        while (true) {
            skip_whitespace();
            if (peek() != '"') kr_error("JSON: 对象键必须是字符串");
            std::string key = parse_string();
            skip_whitespace();
            if (consume() != ':') kr_error("JSON: 期望 ':'");
            Value val = parse_value();
            entries = (ObjectEntry*)realloc(entries, (count + 1) * sizeof(ObjectEntry));
            entries[count].key = strdup(key.c_str());
            entries[count].value = val;
            count++;
            skip_whitespace();
            char c = peek();
            if (c == ',') { consume(); continue; }
            if (c == '}') { consume(); break; }
            kr_error("JSON: 期望 ',' 或 '}'");
        }
        Value obj = make_object(entries, count);
        // 释放临时 entries（make_object 复制了内容）
        for (int i = 0; i < count; ++i) {
            free(entries[i].key);
            free_value(&entries[i].value);
        }
        free(entries);
        return obj;
    }

    Value parse_array() {
        if (consume() != '[') kr_error("JSON: 期望 '['");
        std::vector<Value> elems;
        skip_whitespace();
        if (peek() == ']') {
            consume();
            return make_array(nullptr, 0);
        }
        while (true) {
            Value v = parse_value();
            elems.push_back(v);
            skip_whitespace();
            char c = peek();
            if (c == ',') { consume(); continue; }
            if (c == ']') { consume(); break; }
            kr_error("JSON: 期望 ',' 或 ']'");
        }
        Value arr = make_array(elems.data(), (int)elems.size());
        // 释放临时值（make_array 复制了内容）
        for (auto& v : elems) free_value(&v);
        return arr;
    }

public:
    JSONParser(const std::string& s) : input(s), pos(0) {}
    Value parse() {
        Value v = parse_value();
        skip_whitespace();
        if (pos != input.size())
            kr_error("JSON: 多余字符在末尾");
        return v;
    }
};

static Value json_parse(Value arg) {
    if (arg.type != VAL_STRING)
        kr_error("jsonzu 需要字符串参数");
    JSONParser parser(std::string(arg.str_val));
    return parser.parse();
}

// ---------- JSON 序列化 ----------
static std::string json_stringify_value(const Value& v, bool pretty = false, int indent = 0);

static std::string json_escape_string(const std::string& s) {
    std::string out;
    for (char c : s) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) {
                    char buf[7];
                    snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                    out += buf;
                } else {
                    out += c;
                }
        }
    }
    return out;
}

static std::string json_stringify_value(const Value& v, bool pretty, int indent) {
    std::string result;
    std::string indent_str(indent, ' ');
    std::string next_indent = indent_str + (pretty ? "  " : "");

    switch (v.type) {
        case VAL_NULL:
            return "null";
        case VAL_INT64: {
            return std::to_string(v.int64_val);
        }
        case VAL_INT: {
            char* s = mpz_get_str(nullptr, 10, *v.big_int);
            std::string out(s);
            free(s);
            return out;
        }
        case VAL_FLOAT: {
            char* s = mpf_get_str(nullptr, nullptr, 10, 0, *v.mpf_val);
            std::string out(s);
            free(s);
            return out;
        }
        case VAL_STRING:
            return "\"" + json_escape_string(std::string(v.str_val, v.str_len)) + "\"";
        case VAL_ARRAY: {
            result += "[";
            for (int i = 0; i < v.arr_val.length; ++i) {
                if (i > 0) result += ",";
                if (pretty) result += "\n" + next_indent;
                else result += " ";
                result += json_stringify_value(v.arr_val.elements[i], pretty, indent + 2);
            }
            if (pretty && v.arr_val.length > 0) result += "\n" + indent_str;
            result += "]";
            break;
        }
        case VAL_OBJECT: {
            // 排除内部标记（以 __ 开头的键）
            std::vector<std::pair<std::string, Value>> pairs;
            for (int i = 0; i < v.obj_val.count; ++i) {
                std::string key = v.obj_val.entries[i].key;
                if (key.size() >= 2 && key[0] == '_' && key[1] == '_') continue; // 跳过内部字段
                pairs.emplace_back(key, v.obj_val.entries[i].value);
            }
            result += "{";
            for (size_t i = 0; i < pairs.size(); ++i) {
                if (i > 0) result += ",";
                if (pretty) result += "\n" + next_indent;
                else result += " ";
                result += "\"" + json_escape_string(pairs[i].first) + "\":";
                if (pretty) result += " ";
                result += json_stringify_value(pairs[i].second, pretty, indent + 2);
            }
            if (pretty && !pairs.empty()) result += "\n" + indent_str;
            result += "}";
            break;
        }
        case VAL_FUNCTION:
        case VAL_FUTURE:
            // 不能序列化，转为 null 或抛出错误
            kr_warn("zujson: 函数或 Future 无法序列化，转为 null");
            return "null";
        default:
            kr_error("zujson: 不支持的类型");
    }
    return result;
}

static Value json_to_string(Value arg) {
    std::string json = json_stringify_value(arg, false, 0);
    return make_string(json.c_str());
}
 
int value_to_bool(Value v) {
    switch (v.type) {
        case VAL_INT64:
            return v.int64_val != 0;
        case VAL_NULL: return 0;
        case VAL_INT: return mpz_sgn(*v.big_int) != 0;
        case VAL_FLOAT: return mpf_sgn(*v.mpf_val) != 0;
        case VAL_STRING: return v.str_len > 0;
        case VAL_ARRAY: return v.arr_val.length > 0;
        case VAL_OBJECT: return v.obj_val.count > 0;
        case VAL_FUNCTION: return 1;
        case VAL_FUTURE: return 0;
        case VAL_POINTER:
            return (v.ptr_val.smart_target != nullptr) ||
                (v.ptr_val.raw_target  != nullptr);
    }
    return 0;
}
 
 /* ========== 解析器 ========== */
 ASTNode* parse_program() {
     ASTNode* prog = new_node(NODE_PROGRAM);
     prog->data.block.stmts = NULL; prog->data.block.count = 0;
     while (peek()->type != TOK_EOF) {
         ASTNode* stmt = parse_statement(1);
         prog->data.block.stmts = (ASTNode**)realloc(prog->data.block.stmts,
                                           (prog->data.block.count+1)*sizeof(ASTNode*));
         prog->data.block.stmts[prog->data.block.count++] = stmt;
     }
     return prog;
 }
 
// 辅助：判断是否为复合赋值运算符（不包括 "ist"）
bool is_compound_assign(const char* op) {
    return (strcmp(op, "+=") == 0 || strcmp(op, "-=") == 0 ||
            strcmp(op, "*=") == 0 || strcmp(op, "/=") == 0 ||
            strcmp(op, "%=") == 0 || strcmp(op, "^=") == 0 ||
            strcmp(op, "|=") == 0 || strcmp(op, "&=") == 0 ||
            strcmp(op, "~=") == 0);
}
 
// 辅助：将复合赋值运算符转为对应的二元操作符
char compound_op_to_binary(const char* op) {
    if (strcmp(op, "+=") == 0) return '+';
    if (strcmp(op, "-=") == 0) return '-';
    if (strcmp(op, "*=") == 0) return '*';
    if (strcmp(op, "/=") == 0) return '/';
    if (strcmp(op, "%=") == 0) return '%';
    if (strcmp(op, "^=") == 0) return '^';   // 仍表示指数
    if (strcmp(op, "|=") == 0) return '|';   // 按位或
    if (strcmp(op, "&=") == 0) return '&';   // 按位与
    if (strcmp(op, "~=") == 0) return 'X';   // 按位异或
    return 0;
}
 
 #define CONSUME_OPTIONAL_SEMICOLON() \
    do { if (allow_semicolon && strcmp(peek()->value, ";") == 0) consume(); } while (0)

// ---------- 辅助：使用密码派生密钥（SHA-256） ----------
static bool derive_key(const std::string& password, unsigned char* key) {
    // 计算密码的SHA-256作为密钥
    EVP_MD_CTX* mdctx = EVP_MD_CTX_new();
    if (!mdctx) return false;
    if (EVP_DigestInit_ex(mdctx, EVP_sha256(), NULL) != 1) {
        EVP_MD_CTX_free(mdctx);
        return false;
    }
    if (EVP_DigestUpdate(mdctx, password.data(), password.size()) != 1) {
        EVP_MD_CTX_free(mdctx);
        return false;
    }
    unsigned int len = 0;
    if (EVP_DigestFinal_ex(mdctx, key, &len) != 1 || len != 32) {
        EVP_MD_CTX_free(mdctx);
        return false;
    }
    EVP_MD_CTX_free(mdctx);
    return true;
}

// KDB 辅助函数
static std::shared_ptr<KDDataSet> _hole_dataset(Value menge) {
    if (menge.type != VAL_OBJECT) return nullptr;
    for (int i = 0; i < menge.obj_val.count; ++i) {
        if (strcmp(menge.obj_val.entries[i].key, "__kd_daten") == 0) {
            Value& inner = menge.obj_val.entries[i].value;
            if (inner.type == VAL_OBJECT && inner.obj_val.count >= 1 &&
                strcmp(inner.obj_val.entries[0].key, "__zgr") == 0 &&
                (inner.obj_val.entries[0].value.type == VAL_INT || inner.obj_val.entries[0].value.type == VAL_INT64)) {
                return *(std::shared_ptr<KDDataSet>*)value_to_ll(inner.obj_val.entries[0].value);
            }
        }
    }
    return nullptr;
}

static Record _wert_zu_eintrag(Value wert) {
    if (wert.type != VAL_OBJECT) kr_error("Eintrag muss ein Objekt sein");
    Record eintrag;
    eintrag.id = 0; eintrag.vater = 0; eintrag.type = 0;
    for (int i = 0; i < wert.obj_val.count; ++i) {
        const char* key = wert.obj_val.entries[i].key;
        Value val = wert.obj_val.entries[i].value;
        if (strcmp(key, "id") == 0) {
            if (val.type != VAL_INT && val.type != VAL_INT64) kr_error("id muss eine Zahl sein");
            eintrag.id = (uint64_t)mpz_get_si(*val.big_int);
        } else if (strcmp(key, "vater") == 0) {
            if (val.type != VAL_INT && val.type != VAL_INT64) kr_error("vater muss eine Zahl sein");
            eintrag.vater = value_to_ll(val);
        } else if (strcmp(key, "art") == 0) {
            if (val.type != VAL_INT && val.type != VAL_INT64) kr_error("typ muss eine Zahl sein");
            eintrag.type = (uint32_t)value_to_ll(val);
        } else if (strcmp(key, "worte") == 0) {
            if (val.type != VAL_ARRAY) kr_error("worte müssen ein Array sein");
            for (int j = 0; j < val.arr_val.length; ++j) {
                if (val.arr_val.elements[j].type != VAL_STRING)
                    kr_error("Schlagwort muss Text sein");
                eintrag.tags.push_back(val.arr_val.elements[j].str_val);
            }
        } else if (strcmp(key, "zkt") == 0) {
            if (val.type != VAL_STRING) kr_error("text muss Text sein");
            eintrag.text.assign(val.str_val, val.str_len);
        } else if (strcmp(key, "daten") == 0) {
            if (val.type != VAL_ARRAY) kr_error("daten müssen ein Byte-Array sein");
            for (int j = 0; j < val.arr_val.length; ++j) {
                if (val.arr_val.elements[j].type != VAL_INT && val.arr_val.elements[j].type != VAL_INT64) {
                    kr_error("Byte muss Zahl sein");
                }
                int byte = (int)mpz_get_si(*val.arr_val.elements[j].big_int);
                if (byte < 0 || byte > 255) kr_error("Byte-Wert außerhalb 0-255");
                eintrag.data.push_back((uint8_t)byte);
            }
        }
    }
    return eintrag;
}

static Value _eintrag_zu_wert(const Record& eintrag) {
    ObjectEntry entries[6];
    int cnt = 0;
    entries[cnt].key = strdup("id");
    entries[cnt].value = make_int(eintrag.id);
    cnt++;
    entries[cnt].key = strdup("vater");
    entries[cnt].value = make_int(eintrag.vater);
    cnt++;
    entries[cnt].key = strdup("art");
    entries[cnt].value = make_int(eintrag.type);
    cnt++;
    Value* tag_vals = (Value*)malloc(eintrag.tags.size() * sizeof(Value));
    for (size_t i = 0; i < eintrag.tags.size(); ++i)
        tag_vals[i] = make_string(eintrag.tags[i].c_str());
    entries[cnt].key = strdup("worte");
    entries[cnt].value = make_array(tag_vals, (int)eintrag.tags.size());
    cnt++;
    free(tag_vals);
    entries[cnt].key = strdup("zkt");
    entries[cnt].value = make_string_len(eintrag.text.data(), eintrag.text.size());
    cnt++;
    Value* data_vals = (Value*)malloc(eintrag.data.size() * sizeof(Value));
    for (size_t i = 0; i < eintrag.data.size(); ++i)
        data_vals[i] = make_int(eintrag.data[i]);
    entries[cnt].key = strdup("daten");
    entries[cnt].value = make_array(data_vals, (int)eintrag.data.size());
    cnt++;
    free(data_vals);
    Value obj = make_object(entries, cnt);
    for (int i = 0; i < cnt; ++i) {
        free(entries[i].key);
        free_value(&entries[i].value);
    }
    return obj;
}


bool type_matches(const TypeNode* a, const TypeNode* b) {
    TypeCheckDepthGuard guard;
    if (!a && !b) return true;
    if (!a || !b) return false;
    if (a->kind != b->kind) return false;
    if (a->kind == TYPE_STRING_UNION && b->kind == TYPE_STRING_UNION) {
        return *a->union_type.string_union == *b->union_type.string_union;
    }

    switch (a->kind) {
        case TYPE_INT:
        case TYPE_FLOAT:
        case TYPE_STRING:
        case TYPE_BOOL:
        case TYPE_CHAR:
        case TYPE_NUM:
        case TYPE_ANY:
            return true;   // 基础类型仅需 kind 相同

        case TYPE_ARRAY:
            return type_matches(a->array_type.elem_type, b->array_type.elem_type);

        case TYPE_OBJECT: {
            if (a->object_type.count != b->object_type.count) return false;
            for (int i = 0; i < a->object_type.count; ++i) {
                if (strcmp(a->object_type.keys[i], b->object_type.keys[i]) != 0)
                    return false;
                if (!type_matches(a->object_type.types[i], b->object_type.types[i]))
                    return false;
            }
            return true;
        }

        case TYPE_ALIAS: {
            std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
            auto it = type_aliases.find(a->alias_type.name);
            if (it != type_aliases.end())
                return type_matches(it->second, b);
            // 若找不到别名，则直接比较名字（对于类/枚举名称）
            return strcmp(a->alias_type.name, b->alias_type.name) == 0;
        }

        case TYPE_FUNCTION: {
            if (a->func_type.param_count != b->func_type.param_count) return false;
            for (int i = 0; i < a->func_type.param_count; ++i) {
                if (!type_matches(a->func_type.param_types[i], b->func_type.param_types[i]))
                    return false;
            }
            return type_matches(a->func_type.ret_type, b->func_type.ret_type);
        }

        case TYPE_OPTIONAL: {
            return type_matches(a->optional_type.inner_type, b->optional_type.inner_type);
        }

        case TYPE_STRUCT: {
            if (a->struct_type.field_count != b->struct_type.field_count) return false;
            for (int i = 0; i < a->struct_type.field_count; i++) {
                if (strcmp(a->struct_type.fields[i].name, b->struct_type.fields[i].name) != 0)
                    return false;
                if (!type_matches(a->struct_type.fields[i].type, b->struct_type.fields[i].type))
                    return false;
            }
            return true;
        }
        case TYPE_UNION: {
            if (a->variant_type.variant_count != b->variant_type.variant_count) return false;
            for (int i = 0; i < a->variant_type.variant_count; i++) {
                UnionVariant* va = &a->variant_type.variants[i];
                UnionVariant* vb = &b->variant_type.variants[i];
                if (strcmp(va->name, vb->name) != 0) return false;
                if (va->param_count != vb->param_count) return false;
                for (int j = 0; j < va->param_count; j++) {
                    if (!type_matches(va->param_types[j], vb->param_types[j])) return false;
                }
                // 具名参数同理（省略）
            }
            return true;
        }

        case TYPE_POINTER:
            if (a->ptr_type.smart != b->ptr_type.smart) return false;
            return type_matches(a->ptr_type.elem_type, b->ptr_type.elem_type);

        default:
            return false;
    }
}

bool check_type(TypeNode* type, Value val) {
    TypeCheckDepthGuard guard;
    if (!type) return true;

    if (type->kind < TYPE_INT || type->kind > TYPE_POINTER) {
        kr_warn("check_type: 无效类型 kind=%d，跳过检查", type->kind);
        return true;
    }

    // 1. 处理可选类型 (T?)
    if (type->kind == TYPE_OPTIONAL) {
        if (val.type == VAL_NULL) return true;
        return check_type(type->optional_type.inner_type, val);
    }

    // 2. 展开类型别名 (typ)
    if (type->kind == TYPE_ALIAS) {
        std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
        auto it = type_aliases.find(type->alias_type.name);
        if (it != type_aliases.end()) {
            return check_type(it->second, val);
        }
        // 检查是否为类名
        auto class_it = class_table.find(type->alias_type.name);
        if (class_it != class_table.end()) {
            if (val.type != VAL_OBJECT) return false;
            for (int i = 0; i < val.obj_val.count; ++i) {
                if (strcmp(val.obj_val.entries[i].key, "__klass") == 0 &&
                    val.obj_val.entries[i].value.type == VAL_STRING) {
                    return strcmp(val.obj_val.entries[i].value.str_val, type->alias_type.name) == 0;
                }
            }
            return false;
        }
        // 检查是否为枚举
        auto enum_it = enum_table.find(type->alias_type.name);
        if (enum_it != enum_table.end()) {
            if (val.type != VAL_OBJECT) return false;
            // 提取 __tag 和 __felder
            std::string tag;
            Value* fields = nullptr;
            for (int i = 0; i < val.obj_val.count; ++i) {
                if (strcmp(val.obj_val.entries[i].key, "__tag") == 0 &&
                    val.obj_val.entries[i].value.type == VAL_STRING) {
                    tag = val.obj_val.entries[i].value.str_val;
                }
                if (strcmp(val.obj_val.entries[i].key, "__felder") == 0) {
                    fields = &val.obj_val.entries[i].value;
                }
            }
            if (tag.empty() || !fields || fields->type != VAL_ARRAY) return false;
            // 查找变体
            const auto& info = enum_it->second;
            for (size_t i = 0; i < info.variants.size(); ++i) {
                if (info.variants[i] == tag) {
                    int expected = info.param_counts[i];
                    return fields->arr_val.length == expected;
                }
            }
            return false;
        }
        std::string hint = suggest_correction(type->alias_type.name);
        kr_error_hint(hint.empty() ? nullptr : hint.c_str(), "未定义类型别名、类或枚举 '%s'", type->alias_type.name);
    }

    // 3. 核心类型检查
    switch (type->kind) {
        case TYPE_INT:      // gzl
            return (val.type == VAL_INT || val.type == VAL_INT64);

        case TYPE_FLOAT:    // kzl
            return val.type == VAL_FLOAT;

        case TYPE_NUM:      // zahl
            return (val.type == VAL_INT || val.type == VAL_FLOAT || val.type == VAL_INT64);

        case TYPE_STRING:   // text
            return val.type == VAL_STRING;

        case TYPE_BOOL: {   // bool
            if (val.type == VAL_INT) {
                return mpz_cmp_ui(*val.big_int, 0) == 0 || mpz_cmp_ui(*val.big_int, 1) == 0;
            }
            if (val.type == VAL_INT64) {
                return val.int64_val == 0 || val.int64_val == 1;
            }
            if (val.type == VAL_FLOAT) {
                return mpf_cmp_ui(*val.mpf_val, 0) == 0 || mpf_cmp_ui(*val.mpf_val, 1) == 0;
            }
            return false;
        }

        case TYPE_CHAR: {   // einz
            if (val.type == VAL_STRING && strlen(val.str_val) == 1) return true;
            if (val.type == VAL_INT || val.type == VAL_INT64) {
                long long n = value_to_ll(val);
                return (n >= 0 && n <= 255);
            }
            return false;
        }

        case TYPE_ARRAY: {  // [T]
            if (val.type != VAL_ARRAY) return false;
            for (int i = 0; i < val.arr_val.length; i++) {
                if (!check_type(type->array_type.elem_type, val.arr_val.elements[i]))
                    return false;
            }
            return true;
        }

        case TYPE_OBJECT: { // { key: T, ... }
            if (val.type != VAL_OBJECT) return false;
            for (int i = 0; i < type->object_type.count; i++) {
                char* key = type->object_type.keys[i];
                bool found = false;
                for (int j = 0; j < val.obj_val.count; j++) {
                    if (strcmp(val.obj_val.entries[j].key, key) == 0) {
                        if (!check_type(type->object_type.types[i], val.obj_val.entries[j].value))
                            return false;
                        found = true;
                        break;
                    }
                }
                if (!found) return false;
            }
            return true;
        }

        case TYPE_FUNCTION: {
            if (val.type != VAL_FUNCTION) return false;
            if (val.func_val.param_count != type->func_type.param_count) return false;
            // 检查参数类型是否匹配（必须完全一致）
            for (int i = 0; i < type->func_type.param_count; ++i) {
                if (!type_matches(type->func_type.param_types[i], val.func_val.param_types[i]))
                    return false;
            }
            // 检查返回类型是否匹配
            if (!type_matches(type->func_type.ret_type, val.func_val.return_type))
                return false;
            return true;
        }

        case TYPE_STRING_UNION: {
            if (val.type != VAL_STRING) return false;
            return type->union_type.string_union->find(val.str_val) != type->union_type.string_union->end();
        }

        case TYPE_STRUCT: {
            if (val.type != VAL_OBJECT) return false;
            for (int i = 0; i < type->struct_type.field_count; i++) {
                const char* fname = type->struct_type.fields[i].name;
                bool found = false;
                for (int j = 0; j < val.obj_val.count; j++) {
                    if (strcmp(val.obj_val.entries[j].key, fname) == 0) {
                        if (!check_type(type->struct_type.fields[i].type, val.obj_val.entries[j].value))
                            return false;
                        found = true;
                        break;
                    }
                }
                if (!found) return false;
            }
            return true;
        }
        case TYPE_UNION: {
            if (val.type != VAL_OBJECT) return false;
            const char* tag = NULL;
            Value* fields = NULL;
            for (int i = 0; i < val.obj_val.count; i++) {
                if (strcmp(val.obj_val.entries[i].key, "__tag") == 0 && val.obj_val.entries[i].value.type == VAL_STRING)
                    tag = val.obj_val.entries[i].value.str_val;
                if (strcmp(val.obj_val.entries[i].key, "__felder") == 0)
                    fields = &val.obj_val.entries[i].value;
            }
            if (!tag) return false;
            for (int i = 0; i < type->variant_type.variant_count; i++) {
                UnionVariant* v = &type->variant_type.variants[i];
                if (strcmp(v->name, tag) == 0) {
                    if (v->param_count > 0) {
                        // 匿名参数变体
                        if (!fields || fields->type != VAL_ARRAY) return false;
                        if (fields->arr_val.length != v->param_count) return false;
                        for (int j = 0; j < v->param_count; j++) {
                            if (!check_type(v->param_types[j], fields->arr_val.elements[j]))
                                return false;
                        }
                    } else {
                        // 具名参数变体（或空变体）
                        if (v->field_count == 0) return true;  // 无参变体
                        if (!fields || fields->type != VAL_ARRAY) return false;
                        if (fields->arr_val.length != v->field_count) return false;
                        for (int j = 0; j < v->field_count; j++) {
                            if (!check_type(v->named_fields[j].type, fields->arr_val.elements[j]))
                                return false;
                        }
                    }
                    return true;
                }
            }
            return false;
        }

        case TYPE_POINTER:
            return val.type == VAL_POINTER;

        case TYPE_ANY:      // leer
            return true;

        // 注意：TYPE_OPTIONAL 和 TYPE_ALIAS 已在函数开头处理，这里不再重复
        default:
            // 防御性编程：如果出现未知类型，返回 false 而不是 true，避免隐藏错误
            kr_error("check_type: 未知类型 kind=%d", type->kind);
            return false;
    }
}



// 把 rhs 移动给 node 描述的目标变量（node 必须是 NODE_ASSIGN）。
// 目标不存在则隐式声明；常量 / 惰性 / 类型不匹配 → 抛错。
// 调用后 rhs 的所有权已转移，调用者不得再使用 rhs。
static void assign_to_target(ASTNode* node, Value rhs) {
    Variable* var = nullptr;

    if (node->data.assign.global) {
        Scope* gs = get_global_scope();
        if (!gs) {
            free_value(&rhs);
            kr_error("全局作用域不存在，无法赋值 '%s'", node->data.assign.name);
        }
        int idx = get_var_index_in_scope(gs, node->data.assign.name);
        if (idx >= 0) {
            var = &gs->vars[idx];
        } else {
            declare_var_in_scope(gs, node->data.assign.name, false, rhs); // 移动
            idx = get_var_index_in_scope(gs, node->data.assign.name);
            if (idx < 0) kr_error("无法声明全局变量 '%s'", node->data.assign.name);
            var = &gs->vars[idx];
            g_var_decl_pos[node->data.assign.name] = {node->line, node->col};
            var->is_read = false;
            return;
        }
    } else {
        var = get_var(node->data.assign.name, false);

        if (!var) {
            // ---- 静态属性回退 ----
            if (g_current_class_name) {
                const char* cur_cls = g_current_class_name;
                std::string key = std::string(cur_cls) + "::" + node->data.assign.name;

                //  1) 先在类定义里查：属性是否存在？是否为惰性？是否为常量？类型？
                //    这一步只读 class_table，因此按 g_global_mutex -> 释放的顺序进行，
                //    和 NODE_OBJECT_ACCESS 保持一致，避免锁序反转。
                bool prop_exists  = false;
                bool prop_is_lazy = false;
                bool prop_is_const = false;
                TypeNode* prop_type = nullptr;
                std::string prop_defining_file;
                {
                    std::lock_guard<std::recursive_mutex> lock_cls(g_global_mutex);
                    // 沿继承链向上找（可选：若你的静态属性不继承，可只查本类）
                    std::string c = cur_cls;
                    while (!c.empty()) {
                        auto cls_it = class_table.find(c);
                        if (cls_it == class_table.end()) break;
                        for (const auto& prop : cls_it->second.properties) {
                            if (prop.name == node->data.assign.name && prop.is_static) {
                                prop_exists = true;
                                prop_is_lazy = prop.is_lazy;
                                prop_is_const = prop.is_const;
                                prop_type = prop.type;
                                prop_defining_file = cls_it->second.defining_file;
                                break;
                            }
                        }
                        if (prop_exists) break;
                        if (cls_it->second.parent.empty()) break;
                        c = cls_it->second.parent;
                    }
                }

                if (prop_exists) {
                    if (prop_is_lazy) {
                        free_value(&rhs);
                        kr_error("惰性静态属性 '%s' 不能赋值", node->data.assign.name);
                    }
                    if (prop_is_const) {
                        free_value(&rhs);
                        kr_error("静态常量 '%s' 不能重新赋值", node->data.assign.name);
                    }
                    if (prop_type && !check_type(prop_type, rhs)) {
                        char* got = value_to_string(rhs);
                        free_value(&rhs);
                        kr_error("静态属性赋值类型错误: 期望 '%s', 实际 '%s'",
                                 type_to_string(prop_type).c_str(), got);
                    }

                    //  2) 再进入 static_props_mutex 写入缓存（此时不再嵌套 g_global_mutex）
                    {
                        std::lock_guard<std::mutex> lock(static_props_mutex);
                        auto it = static_props.find(key);
                        if (it != static_props.end()) {
                            free_value(&it->second);
                            it->second = rhs;   // 移动
                        } else {
                            static_props[key] = rhs;  // 移动
                        }
                    }
                    return;
                }
                //  3) 属性不存在：这是用户写错名字，明确报错，不要隐式声明
                free_value(&rhs);
                kr_error("类 '%s' 没有静态属性 '%s'",
                         cur_cls, node->data.assign.name);
            }

            // ---- 隐式声明（只有确实不在任何类里才走这里） ----
            if (!current_scope) push_scope();
            declare_var_in_scope(current_scope, node->data.assign.name, false, rhs);
            int idx = get_var_index_in_scope(current_scope, node->data.assign.name);
            if (idx < 0) kr_error("无法声明变量 '%s'", node->data.assign.name);
            var = &current_scope->vars[idx];
            if (current_scope == original_global_scope)
                g_var_decl_pos[node->data.assign.name] = {node->line, node->col};
            var->is_read = false;
            return;
        }
    }

    if (var->is_const) { free_value(&rhs); kr_error("常量 '%s' 不能重新赋值", node->data.assign.name); }
    if (var->is_lazy)  { free_value(&rhs); kr_error("惰性变量 '%s' 不能赋值", node->data.assign.name); }
    if (var->type_annotation && !check_type(var->type_annotation, rhs)) {
        char* got = value_to_string(rhs);
        free_value(&rhs);
        kr_error("赋值类型错误: 变量 '%s' 期望 '%s', 实际 '%s'",
                 node->data.assign.name, type_to_string(var->type_annotation).c_str(), got);
    }
    free_value(&var->value);
    var->value = rhs;   // 移动
}
 
/* 辅助：递增递减操作（仅支持整数） */
static void inc_value(Value* v) {
    if (v->type == VAL_INT64) {
        if (v->int64_val == INT64_MAX) {
            // 溢出，转为 GMP
            mpz_t tmp;
            mpz_init_set_si(tmp, v->int64_val);
            mpz_add_ui(tmp, tmp, 1);
            Value newv = make_int(tmp);
            mpz_clear(tmp);
            free_value(v);
            *v = newv;
        } else {
            v->int64_val++;
        }
    } else if (v->type == VAL_INT || v->type == VAL_INT64) {
        mpz_add_ui(*v->big_int, *v->big_int, 1);
    } else if (v->type == VAL_FLOAT) {
        mpf_add_ui(*v->mpf_val, *v->mpf_val, 1);
    } else kr_error("递增只支持整数或浮点数");
}
static void dec_value(Value* v) {
    if (v->type == VAL_INT64) {
        if (v->int64_val == INT64_MIN) {
            // 溢出，转为 GMP
            mpz_t tmp;
            mpz_init_set_si(tmp, v->int64_val);
            mpz_sub_ui(tmp, tmp, 1);
            Value newv = make_int(tmp);
            mpz_clear(tmp);
            free_value(v);
            *v = newv;
        } else {
            v->int64_val--;
        }
    } else if (v->type == VAL_INT) {
        mpz_sub_ui(*v->big_int, *v->big_int, 1);
    } else if (v->type == VAL_FLOAT) {
        mpf_sub_ui(*v->mpf_val, *v->mpf_val, 1);
    } else kr_error("递减只支持整数或浮点数");
}

 
 /* 辅助：获取可修改的左值指针（用于递增递减） */
 static Value* get_mutable_ptr(ASTNode* node) {
    if (node->type == NODE_VARIABLE) {
        Variable* var = get_var(node->data.var_name);
        if (!var) {
            // ---- 尝试从静态属性中查找（写路径） ----
            // 优先当前类，回退到所有已注册的类
            Value* found_ptr = nullptr;
            std::string owner_class_name;
            {
                std::lock_guard<std::mutex> lock(static_props_mutex);
                // 1) 优先匹配当前类
                if (g_current_class_name) {
                    std::string key = std::string(g_current_class_name) + "::" + node->data.var_name;
                    auto it = static_props.find(key);
                    if (it != static_props.end()) {
                        found_ptr = &it->second;
                        owner_class_name = g_current_class_name;
                    }
                }
                // 2) 回退：在所有已注册类中查找
                if (!found_ptr) {
                    std::string suffix = "::" + std::string(node->data.var_name);
                    for (auto& pair : static_props) {
                        if (pair.first.size() > suffix.size() &&
                            pair.first.compare(pair.first.size() - suffix.size(),
                                               suffix.size(), suffix) == 0) {
                            found_ptr = &pair.second;
                            owner_class_name = pair.first.substr(0, pair.first.size() - suffix.size());
                            break;
                        }
                    }
                }
            }
            if (found_ptr) {
                // 检查该静态属性是否为常量
                {
                    std::lock_guard<std::recursive_mutex> lock_cls(g_global_mutex);
                    auto cls_it = class_table.find(owner_class_name);
                    if (cls_it != class_table.end()) {
                        for (const auto& prop : cls_it->second.properties) {
                            if (prop.name == node->data.var_name && prop.is_static) {
                                if (prop.is_const) {
                                    kr_error("Fehler: 静态常量 '%s' 不能修改\n",
                                             node->data.var_name);
                                }
                                break;
                            }
                        }
                    }
                }
                return found_ptr;
            }
            if (g_current_class_name) {
                std::string key = std::string(g_current_class_name) + "::" + node->data.var_name;
                std::lock_guard<std::mutex> lock(static_props_mutex);
                if (static_lazy_init.count(key)) {
                    kr_error("Fehler: 静态惰性属性 '%s' 不能修改\n", node->data.var_name);
                }
            }
            kr_error("Fehler: 变量 '%s' 未在当前作用域声明\n", node->data.var_name);
        }
        var = resolve_alias(var);
        if (var->is_const) {
            kr_error("Fehler: 常量不能修改\n");
        }
        if (var->is_lazy) {
            kr_error("Fehler: 惰性变量不能修改\n");
        }
        return &var->value;
    }
    else if (node->type == NODE_ARRAY_ACCESS) {
        Value* arr_ptr = get_mutable_ptr(node->data.array_access.array);
        Value idx_val = eval_expr(node->data.array_access.index);
        char* key_str = value_to_string(idx_val);
        free_value(&idx_val);
    
        if (arr_ptr->type == VAL_ARRAY) {
            long long idx = atoll(key_str);
            if (idx < 0 || idx >= arr_ptr->arr_val.length) {
                free(key_str);
                kr_error("数组索引越界 (长度 %lld, 索引 %lld)", arr_ptr->arr_val.length, idx);
            }
            free(key_str);
            return &arr_ptr->arr_val.elements[idx];
        }
        else if (arr_ptr->type == VAL_STRING) {
            long long idx = atoll(key_str);
            int len = utf8_length(arr_ptr->str_val);
            if (idx < 0 || idx >= len) {
                free(key_str);
                kr_error("字符串索引越界");
            }
            free(key_str);
            kr_error("字符串不可修改");
            return nullptr;
        }
        else if (arr_ptr->type == VAL_OBJECT) {
            // 对象键访问（方括号语法）
            for (int i = 0; i < arr_ptr->obj_val.count; i++) {
                if (strcmp(arr_ptr->obj_val.entries[i].key, key_str) == 0) {
                    free(key_str);
                    return &arr_ptr->obj_val.entries[i].value;
                }
            }
            // 键不存在，动态创建
            arr_ptr->obj_val.count++;
            arr_ptr->obj_val.entries = (ObjectEntry*)realloc(arr_ptr->obj_val.entries,
                                        arr_ptr->obj_val.count * sizeof(ObjectEntry));
            arr_ptr->obj_val.entries[arr_ptr->obj_val.count - 1].key = strdup(key_str);
            arr_ptr->obj_val.entries[arr_ptr->obj_val.count - 1].value = make_null();
            free(key_str);
            return &arr_ptr->obj_val.entries[arr_ptr->obj_val.count - 1].value;
        }
        else {
            free(key_str);
            kr_error("索引操作的对象不是数组、字符串或对象");
            return nullptr;
        }
    }
    else if (node->type == NODE_OBJECT_ACCESS) {
        if (node->data.object_access.obj->type == NODE_VARIABLE) {
            std::string var_name = node->data.object_access.obj->data.var_name;
            Variable* maybe_var = get_var(var_name.c_str());
            if (!maybe_var) {
                std::lock_guard<std::recursive_mutex> lock(g_global_mutex);
                auto class_it = class_table.find(var_name);
                if (class_it != class_table.end()) {
                    std::string key = node->data.object_access.key;
                    // 沿继承链查找静态属性
                    std::string cur = var_name;
                    while (!cur.empty()) {
                        auto it = class_table.find(cur);
                        if (it == class_table.end()) break;
                        for (auto& prop : it->second.properties) {
                            if (prop.name == key && prop.is_static) {
                                if (prop.is_const) {
                                    kr_error("Fehler: 静态常量 '%s' 不能修改\n", key.c_str());
                                }
                                std::string prop_key = cur + "::" + key;
                                std::lock_guard<std::mutex> lock_sp(static_props_mutex);
                                auto sp_it = static_props.find(prop_key);
                                if (sp_it == static_props.end()) {
                                    // 惰性初始化（防止类定义阶段未注册）
                                    Value init_val;
                                    if (prop.default_expr) {
                                        init_val = eval_expr(prop.default_expr);
                                    } else if (prop.type) {
                                        init_val = eval_expr(make_default_value_for_type(prop.type));
                                    } else {
                                        init_val = make_null();
                                    }
                                    static_props[prop_key] = copy_value(init_val);
                                    free_value(&init_val);
                                    sp_it = static_props.find(prop_key);
                                }
                                if (sp_it != static_props.end()) {
                                    return &sp_it->second;
                                }
                                kr_error("Fehler: 静态属性 '%s::%s' 初始化失败",
                                         cur.c_str(), key.c_str());
                            }
                        }
                        if (it->second.parent.empty()) break;
                        cur = it->second.parent;
                    }
                    kr_error("Fehler: 类 '%s' 中没有静态属性 '%s'",
                             var_name.c_str(), key.c_str());
                }
            }
        }
    
        Value* parent_ptr = get_mutable_ptr(node->data.object_access.obj);
        if (parent_ptr->type != VAL_OBJECT) {
            kr_error("Fehler: 尝试访问非对象的属性\n");
        }
        char* key = node->data.object_access.key;
        for (int i = 0; i < parent_ptr->obj_val.count; i++) {
            if (strcmp(parent_ptr->obj_val.entries[i].key, key) == 0) {
                return &parent_ptr->obj_val.entries[i].value;
            }
        }
        // 动态创建属性
        parent_ptr->obj_val.count++;
        parent_ptr->obj_val.entries = (ObjectEntry*)realloc(parent_ptr->obj_val.entries,
                                    parent_ptr->obj_val.count * sizeof(ObjectEntry));
        parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].key = strdup(key);
        parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].value = make_null();
        return &parent_ptr->obj_val.entries[parent_ptr->obj_val.count - 1].value;
    }
    else if (node->type == NODE_THIS) {
        if (current_constructed_obj) {
            return current_constructed_obj;
        } else {
            Variable* dies = get_var("dies");
            if (!dies) {
                std::string hint = make_keyword_alias_hint("dies", "dies");
                kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                              "dies 只能在构造函数或实例方法内使用");
            }
            return &dies->value;
        }
    }
    else {
        kr_error("Fehler: 不能对非左值表达式进行修改\n");
        return NULL;
    }
}

static Value* get_container_ptr(ASTNode* node) {
    if (node->type == NODE_VARIABLE) {
        Variable* var = get_var(node->data.var_name);
        if (!var) {
            kr_error("变量 '%s' 未在当前作用域声明\n", node->data.var_name);
        }
        var = resolve_alias(var);
        if (var->is_const) {
            kr_error("常量不能修改元素/属性\n");
        }
        if (var->is_lazy) {
            kr_error("惰性变量不能修改\n");
        }
        return &var->value;
    }
    else if (node->type == NODE_OBJECT_ACCESS) {
        Value* parent = get_container_ptr(node->data.object_access.obj);
        if (parent->type != VAL_OBJECT) {
            kr_error("尝试访问非对象的属性\n");
        }
        char* key = node->data.object_access.key;
        for (int i = 0; i < parent->obj_val.count; i++) {
            if (strcmp(parent->obj_val.entries[i].key, key) == 0)
                return &parent->obj_val.entries[i].value;
        }
        parent->obj_val.count++;
        parent->obj_val.entries = (ObjectEntry*)realloc(
            parent->obj_val.entries,
            parent->obj_val.count * sizeof(ObjectEntry)
        );
        parent->obj_val.entries[parent->obj_val.count - 1].key = strdup(key);
        parent->obj_val.entries[parent->obj_val.count - 1].value = make_null();
        return &parent->obj_val.entries[parent->obj_val.count - 1].value;
    }
    else if (node->type == NODE_THIS) {
        if (current_constructed_obj)
            return current_constructed_obj;
        Variable* dies = get_var("dies");
        if (!dies) {
            std::string hint = make_keyword_alias_hint("dies", "dies");
            kr_error_hint(hint.empty() ? nullptr : hint.c_str(),
                          "dies 只能在构造函数或实例方法内使用");
        }
        return &dies->value;
    }
    else if (node->type == NODE_ARRAY_ACCESS) {
        Value* container = get_container_ptr(node->data.array_access.array);
        if (!container) return nullptr;

        Value idx_val = eval_expr(node->data.array_access.index);
        if (container->type == VAL_ARRAY) {
            long long idx = value_to_ll(idx_val);
            free_value(&idx_val);
            if (idx < 0 || idx >= container->arr_val.length) {
                kr_error("数组索引越界 (长度 %lld, 索引 %lld)", container->arr_val.length, idx);
            }
            return &container->arr_val.elements[idx];
        }
        else if (container->type == VAL_OBJECT) {
            char* key_str = value_to_string(idx_val);
            free_value(&idx_val);
            for (int i = 0; i < container->obj_val.count; i++) {
                if (strcmp(container->obj_val.entries[i].key, key_str) == 0) {
                    free(key_str);
                    return &container->obj_val.entries[i].value;
                }
            }
            // 键不存在，动态创建
            container->obj_val.count++;
            container->obj_val.entries = (ObjectEntry*)realloc(
                container->obj_val.entries,
                container->obj_val.count * sizeof(ObjectEntry)
            );
            container->obj_val.entries[container->obj_val.count - 1].key = strdup(key_str);
            container->obj_val.entries[container->obj_val.count - 1].value = make_null();
            free(key_str);
            return &container->obj_val.entries[container->obj_val.count - 1].value;
        }
        else {
            free_value(&idx_val);
            kr_error("索引操作的对象不是数组或对象");
            return nullptr;
        }
    }
    else {
        kr_error("不能获取该表达式的容器指针\n");
        return NULL;
    }
}

static Value to_integer_value(Value v) {
    if (v.type == VAL_INT64) {
        return copy_value(v);
    }
    if (v.type == VAL_INT) {
        return copy_value(v);
    }
    if (v.type == VAL_FLOAT) {
        // 四舍五入取整
        mpf_t rounded;
        mpf_init(rounded);
        mpf_round(rounded, *v.mpf_val);
        mpz_t tmp;
        mpz_init(tmp);
        mpz_set_f(tmp, rounded);
        mpf_clear(rounded);
        Value result = make_int(tmp);
        mpz_clear(tmp);
        return result;
    }
    if (v.type == VAL_STRING) {
        // 尝试解析为十进制整数
        mpz_t tmp;
        mpz_init(tmp);
        if (mpz_set_str(tmp, v.str_val, 10) == 0) {
            Value result = make_int(tmp);
            mpz_clear(tmp);
            return result;
        }
        mpz_clear(tmp);
        // 尝试解析为浮点数后取整
        mpf_t f;
        mpf_init(f);
        if (mpf_set_str(f, v.str_val, 10) == 0) {
            Value float_val = make_float(f);
            mpf_clear(f);
            Value int_val = to_integer_value(float_val);
            free_value(&float_val);
            return int_val;
        }
        mpf_clear(f);
        kr_error("步长字符串无法转换为整数: %s", v.str_val);
    }
    if (v.type == VAL_ARRAY) {
        if (v.arr_val.length == 0) {
            kr_warn("步长数组为空，使用默认步长 1");
            return make_int(1LL);
        }
        if (v.arr_val.length > 1) {
            kr_warn("步长数组长度大于1，仅使用第一个元素作为步长");
        }
        Value first = copy_value(v.arr_val.elements[0]);
        Value result = to_integer_value(first);
        free_value(&first);
        return result;
    }
    // 其他类型（对象、函数、null）无法转换
    kr_error("步长必须是整数、浮点数、数字字符串或单元素数组，当前类型: %d", v.type);
    return make_null(); // never reached
}

bool try_match_pattern(ASTNode* pattern, Value val) {
    switch (pattern->type) {
        case NODE_PATTERN_CONSTANT: {
            Value const_val = pattern->data.pattern_constant.constant;
            if ((const_val.type == VAL_INT || const_val.type == VAL_INT64) &&
                (val.type == VAL_INT || val.type == VAL_INT64)) {
                if (const_val.type == VAL_INT64 && val.type == VAL_INT64) {
                    return const_val.int64_val == val.int64_val;
                }
                mpz_t a, b;
                mpz_init(a);
                mpz_init(b);
                if (const_val.type == VAL_INT64)
                    mpz_set_int64(a, const_val.int64_val);
                else
                    mpz_set(a, *const_val.big_int);
                if (val.type == VAL_INT64)
                    mpz_set_int64(b, val.int64_val);
                else
                    mpz_set(b, *val.big_int);
                int cmp = mpz_cmp(a, b);
                mpz_clear(a);
                mpz_clear(b);
                return cmp == 0;
            }
            if (const_val.type == VAL_FLOAT && val.type == VAL_FLOAT) {
                return mpf_cmp(*const_val.mpf_val, *val.mpf_val) == 0;
            }
            if (const_val.type == VAL_STRING && val.type == VAL_STRING) {
                return strcmp(const_val.str_val, val.str_val) == 0;
            }
            return false;
        }
        case NODE_PATTERN_BIND: {
            if (strcmp(pattern->data.pattern_bind.name, "_") == 0) {
                return true;
            }
            declare_var(pattern->data.pattern_bind.name, false, copy_value(val));
            return true;
        }
        case NODE_PATTERN_OBJECT: {
            if (val.type != VAL_OBJECT) { kr_warn("不是对象"); return false; }
            for (int i = 0; i < pattern->data.pattern_object.count; i++) {
                char* key = pattern->data.pattern_object.keys[i];
                bool found = false;
                for (int j = 0; j < val.obj_val.count; j++) {
                    if (strcmp(val.obj_val.entries[j].key, key) == 0) {
                        declare_var(key, false, copy_value(val.obj_val.entries[j].value));
                        found = true;
                        break;
                    }
                }
                if (!found) { kr_warn("对象缺少键: %s", key); return false; }
            }
            return true;
        }
        case NODE_PATTERN_VARIANT: {
            if (val.type != VAL_OBJECT) { kr_warn("值不是对象"); return false; }
            Value* tag_val = NULL;
            Value* fields_val = NULL;
            for (int i = 0; i < val.obj_val.count; i++) {
                if (strcmp(val.obj_val.entries[i].key, "__tag") == 0)
                    tag_val = &val.obj_val.entries[i].value;
                if (strcmp(val.obj_val.entries[i].key, "__felder") == 0)
                    fields_val = &val.obj_val.entries[i].value;
            }
            if (!tag_val || tag_val->type != VAL_STRING) {
                kr_warn("缺少 __tag 或类型错误");
                return false;
            }
        
            // ---- Normalisieren Sie den String, indem Sie führende und nachfolgende Leerzeichen sowie \r\n entfernen. ----
            auto normalize = [](const char* s) -> std::string {
                std::string str(s);
                size_t start = str.find_first_not_of(" \t\n\r\f\v");
                if (start == std::string::npos) return "";
                size_t end = str.find_last_not_of(" \t\n\r\f\v");
                return str.substr(start, end - start + 1);
            };
            std::string tag_norm = normalize(tag_val->str_val);
            std::string pattern_tag_norm = normalize(pattern->data.pattern_variant.tag);
        
            if (tag_norm != pattern_tag_norm) {
                kr_warn("标签不匹配: '%s' vs '%s'", tag_norm.c_str(), pattern_tag_norm.c_str());
                return false;
            }
        
            int expected = pattern->data.pattern_variant.param_count;
            if (expected == 0) {
                return true;
            }
            if (!fields_val) {
                kr_warn("缺少 __felder");
                return false;
            }
            if (fields_val->type != VAL_ARRAY) {
                kr_warn("__felder 不是数组");
                return false;
            }
            if (fields_val->arr_val.length != expected) {
                kr_warn("__felder 长度 %lld 不等于期望 %d", fields_val->arr_val.length, expected);
                return false;
            }
            for (int i = 0; i < expected; i++) {
                declare_var(pattern->data.pattern_variant.params[i], false,
                            copy_value(fields_val->arr_val.elements[i]));
            }
            return true;
        }
        case NODE_PATTERN_OR: {
            for (int i = 0; i < pattern->data.pattern_or.count; ++i) {
                int attempt_count = current_scope->var_count;
                if (try_match_pattern(pattern->data.pattern_or.patterns[i], val)) {
                    return true;
                }
                // Übereinstimmung fehlgeschlagen, Variablen dieser Teilmusterdeklaration zurücksetzen
                while (current_scope->var_count > attempt_count) {
                    Variable* var = &current_scope->vars[--current_scope->var_count];
                    free(var->name);
                    free_value(&var->value);
                    // Wenn es sich um eine faule Variable handelt, muss man auch den Cache usw. bearbeiten
                }
            }
            // Alle Untermuster sind fehlgeschlagen, zurück zum Anfang des Branches
            return false;
        }
        default:
            kr_warn("未知模式类型");
            return false;
    }
}

Value run_command_and_capture(const std::string& cmd) {
    std::string stdout_data, stderr_data;
    int exit_code = -1;
    bool abnormal = false;

#ifdef _WIN32
    // 通过 cmd.exe /c 执行，支持内部命令和批处理
    std::string full_cmd = "cmd.exe /c " + cmd;
    char* cmdline = _strdup(full_cmd.c_str());

    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
    HANDLE hStdoutRead, hStdoutWrite, hStderrRead, hStderrWrite;
    if (!CreatePipe(&hStdoutRead, &hStdoutWrite, &sa, 0) ||
        !CreatePipe(&hStderrRead, &hStderrWrite, &sa, 0)) {
        free(cmdline);
        kr_error("创建管道失败");
    }
    // 确保读句柄不可继承（仅写端可继承）
    SetHandleInformation(hStdoutRead, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(hStderrRead, HANDLE_FLAG_INHERIT, 0);

    // 使用 ANSI 版本的 STARTUPINFOA
    STARTUPINFOA si = { sizeof(STARTUPINFOA) };
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = hStdoutWrite;
    si.hStdError = hStderrWrite;
    si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);

    PROCESS_INFORMATION pi = {0};
    // 显式调用 CreateProcessA（第二个参数接受 char*）
    BOOL success = CreateProcessA(
        NULL,               // 使用命令行
        cmdline,
        NULL, NULL,
        TRUE,               // 继承句柄（让子进程继承管道写端）
        CREATE_NO_WINDOW,
        NULL, NULL,
        &si, &pi
    );

    // 父进程关闭写端，否则无法读到 EOF
    CloseHandle(hStdoutWrite);
    CloseHandle(hStderrWrite);

    if (!success) {
        DWORD err = GetLastError();
        free(cmdline);
        CloseHandle(hStdoutRead);
        CloseHandle(hStderrRead);
        kr_error("CreateProcess 失败，错误码 %lu (命令: %s)", err, full_cmd.c_str());
    }
    free(cmdline);

    // 读取子进程输出（顺序读取，简单场景够用）
    char buffer[4096];
    DWORD bytesRead;
    while (ReadFile(hStdoutRead, buffer, sizeof(buffer)-1, &bytesRead, NULL) && bytesRead > 0) {
        buffer[bytesRead] = '\0';
        stdout_data += buffer;
    }
    while (ReadFile(hStderrRead, buffer, sizeof(buffer)-1, &bytesRead, NULL) && bytesRead > 0) {
        buffer[bytesRead] = '\0';
        stderr_data += buffer;
    }

    WaitForSingleObject(pi.hProcess, INFINITE);
    DWORD dwExit;
    GetExitCodeProcess(pi.hProcess, &dwExit);
    exit_code = (int)dwExit;
    // NTSTATUS 异常码（访问冲突、除零、栈溢出等）高位为 1，
    // 即 (DWORD)exit_code >= 0xC0000000UL；用户主动 exit(N) 的 N 不会进入这个区间。
    if ((DWORD)dwExit >= 0xC0000000UL) {
        abnormal = true;
    }

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    CloseHandle(hStdoutRead);
    CloseHandle(hStderrRead);

#else
    // Unix 部分（使用 fork + pipe + exec）
    int stdout_pipe[2], stderr_pipe[2];
    if (pipe(stdout_pipe) == -1 || pipe(stderr_pipe) == -1) {
        kr_error("pipe 失败");
    }

    pid_t pid = fork();
    if (pid == -1) {
        kr_error("fork 失败");
    } else if (pid == 0) {
        dup2(stdout_pipe[1], STDOUT_FILENO);
        dup2(stderr_pipe[1], STDERR_FILENO);
        close(stdout_pipe[0]); close(stdout_pipe[1]);
        close(stderr_pipe[0]); close(stderr_pipe[1]);
        execl("/bin/sh", "sh", "-c", cmd.c_str(), (char*)NULL);
        _exit(127);
    } else {
        close(stdout_pipe[1]);
        close(stderr_pipe[1]);

        char buffer[4096];
        ssize_t bytes;
        while ((bytes = read(stdout_pipe[0], buffer, sizeof(buffer)-1)) > 0) {
            buffer[bytes] = '\0';
            stdout_data += buffer;
        }
        while ((bytes = read(stderr_pipe[0], buffer, sizeof(buffer)-1)) > 0) {
            buffer[bytes] = '\0';
            stderr_data += buffer;
        }
        close(stdout_pipe[0]);
        close(stderr_pipe[0]);

        int status;
        waitpid(pid, &status, 0);
        if (WIFEXITED(status)) {
            exit_code = WEXITSTATUS(status);
        } else if (WIFSIGNALED(status)) {
            // 被信号终止（如 SIGSEGV、SIGABRT、SIGFPE 等）视为异常
            exit_code = -1;
            abnormal = true;
        } else {
            exit_code = -1;
            abnormal = true;
        }
    }
#endif

    // 构造返回值对象：{ code, erg, fehl, abnorm }
    ObjectEntry entries[4];
    entries[0].key = strdup("code");
    entries[0].value = make_int(exit_code);
    entries[1].key = strdup("erg");
    entries[1].value = make_string_len(stdout_data.data(), stdout_data.size());
    entries[2].key = strdup("fehl");
    entries[2].value = make_string_len(stderr_data.data(), stderr_data.size());
    entries[3].key = strdup("abnorm");
    entries[3].value = make_int(abnormal ? 1 : 0);

    Value result = make_object(entries, 4);
    for (int i = 0; i < 4; ++i) {
        free(entries[i].key);
        free_value(&entries[i].value);
    }
    return result;
}

struct ProcHandle {
#ifdef _WIN32
    HANDLE hProcess = nullptr;
    HANDLE hThread = nullptr;
    HANDLE hOutRead = nullptr;
    HANDLE hErrRead = nullptr;
#else
    pid_t pid = -1;
    int fd_out = -1;
    int fd_err = -1;
#endif
};

struct ProcTask {
    int id;
    std::shared_future<std::shared_ptr<Value>> future;
    std::atomic<bool> running{false};
#ifdef _WIN32
    HANDLE hProcess = nullptr;
#else
    pid_t pid = -1;
#endif
    std::mutex proc_mtx;
};

std::unordered_map<int, std::shared_ptr<ProcTask>> proc_task_map;
std::mutex proc_task_mtx;

ProcHandle proc_start(const std::string& exe, const std::vector<std::string>& args)
{
    ProcHandle ph{};
#ifdef _WIN32
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
    HANDLE hStdoutRead, hStdoutWrite, hStderrRead, hStderrWrite;
    if (!CreatePipe(&hStdoutRead, &hStdoutWrite, &sa, 0) ||
        !CreatePipe(&hStderrRead, &hStderrWrite, &sa, 0)) {
        kr_error("CreatePipe failed");
    }
    SetHandleInformation(hStdoutRead, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(hStderrRead, HANDLE_FLAG_INHERIT, 0);

    std::string cmdline;
    cmdline += "\"";
    cmdline += exe;
    cmdline += "\"";
    for (const auto& a : args) {
        cmdline += " \"";
        cmdline += a;
        cmdline += "\"";
    }
    char* cmd = _strdup(cmdline.c_str());

    STARTUPINFOA si = { sizeof(STARTUPINFOA) };
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = hStdoutWrite;
    si.hStdError = hStderrWrite;
    si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);

    PROCESS_INFORMATION pi = {0};
    BOOL success = CreateProcessA(
        NULL,
        cmd,
        NULL, NULL,
        TRUE,
        CREATE_NO_WINDOW,
        NULL, NULL,
        &si, &pi
    );

    CloseHandle(hStdoutWrite);
    CloseHandle(hStderrWrite);
    free(cmd);

    if (!success) {
        DWORD err = GetLastError();
        CloseHandle(hStdoutRead);
        CloseHandle(hStderrRead);
        kr_error("CreateProcessA failed %lu, exe=%s", err, exe.c_str());
    }

    ph.hProcess = pi.hProcess;
    ph.hThread = pi.hThread;
    ph.hOutRead = hStdoutRead;
    ph.hErrRead = hStderrRead;
#else
    int stdout_pipe[2], stderr_pipe[2];
    if (pipe(stdout_pipe) == -1 || pipe(stderr_pipe) == -1) {
        kr_error("pipe failed");
    }
    pid_t pid = fork();
    if (pid == -1) {
        kr_error("fork failed");
    } else if (pid == 0) {
        dup2(stdout_pipe[1], STDOUT_FILENO);
        dup2(stderr_pipe[1], STDERR_FILENO);
        close(stdout_pipe[0]); close(stdout_pipe[1]);
        close(stderr_pipe[0]); close(stderr_pipe[1]);

        std::vector<char*> argv;
        argv.push_back((char*)exe.c_str());
        for (auto& s : args) argv.push_back((char*)s.c_str());
        argv.push_back(nullptr);
        execvp(exe.c_str(), argv.data());
        _exit(127);
    }
    close(stdout_pipe[1]);
    close(stderr_pipe[1]);
    ph.pid = pid;
    ph.fd_out = stdout_pipe[0];
    ph.fd_err = stderr_pipe[0];
#endif
    return ph;
}

Value proc_read_wait_close(ProcHandle ph) {
    std::string stdout_data, stderr_data;
    int exit_code = -1;
    bool abnormal = false;

    // 并行读取两个管道
    std::thread read_out([&]() {
        char buffer[4096];
#ifdef _WIN32
        DWORD bytesRead;
        while (ReadFile(ph.hOutRead, buffer, sizeof(buffer)-1, &bytesRead, NULL) && bytesRead > 0) {
            buffer[bytesRead] = '\0';
            stdout_data += buffer;
        }
#else
        ssize_t bytes;
        while ((bytes = read(ph.fd_out, buffer, sizeof(buffer)-1)) > 0) {
            buffer[bytes] = '\0';
            stdout_data += buffer;
        }
#endif
    });

    std::thread read_err([&]() {
        char buffer[4096];
#ifdef _WIN32
        DWORD bytesRead;
        while (ReadFile(ph.hErrRead, buffer, sizeof(buffer)-1, &bytesRead, NULL) && bytesRead > 0) {
            buffer[bytesRead] = '\0';
            stderr_data += buffer;
        }
#else
        ssize_t bytes;
        while ((bytes = read(ph.fd_err, buffer, sizeof(buffer)-1)) > 0) {
            buffer[bytes] = '\0';
            stderr_data += buffer;
        }
#endif
    });

    read_out.join();
    read_err.join();

#ifdef _WIN32
    WaitForSingleObject(ph.hProcess, INFINITE);
    DWORD dwExit;
    GetExitCodeProcess(ph.hProcess, &dwExit);
    exit_code = static_cast<int>(dwExit);
    if ((DWORD)dwExit >= 0xC0000000UL) {
        abnormal = true;
    }
    CloseHandle(ph.hProcess);
    CloseHandle(ph.hThread);
    CloseHandle(ph.hOutRead);
    CloseHandle(ph.hErrRead); // 这里只有win才有 hErrRead
#else
    int status;
    waitpid(ph.pid, &status, 0);
    if (WIFEXITED(status)) {
        exit_code = WEXITSTATUS(status);
    } else if (WIFSIGNALED(status)) {
        exit_code = -1;
        abnormal = true;
    } else {
        exit_code = -1;
        abnormal = true;
    }
    close(ph.fd_out);
    close(ph.fd_err);
#endif

    ObjectEntry entries[4];
    entries[0].key = strdup("code");
    entries[0].value = make_int(exit_code);
    entries[1].key = strdup("erg");
    entries[1].value = make_string_len(stdout_data.data(), stdout_data.size());
    entries[2].key = strdup("fehl");
    entries[2].value = make_string_len(stderr_data.data(), stderr_data.size());
    entries[3].key = strdup("abnorm");
    entries[3].value = make_int(abnormal ? 1 : 0);
    Value result = make_object(entries, 4);
    for (int i = 0; i <4; ++i) {
        free(entries[i].key);
        free_value(&entries[i].value);
    }
    return result;
}

Value run_exec_no_shell(const std::string& exe, const std::vector<std::string>& args) {
    ProcHandle ph = proc_start(exe, args);
    return proc_read_wait_close(ph);
}
