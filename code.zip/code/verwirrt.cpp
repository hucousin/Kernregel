#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <memory>
#include <cctype>
#include <stdexcept>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <functional>
#include <cstdint>
#include <cmath>   // for pow, fmod
#include <optional>
#include <unordered_set>

#ifdef _WIN32
#include <windows.h>
#undef PRINT
#undef AND
#undef OR
#undef NOT
#endif

thread_local std::function<std::string(const std::string&, const std::string&)> g_external_call = nullptr;

// =========================== 词法分析 ===========================
enum class TokenTypes {
    IDENTIFIER, NUMBER, STRING,
    PLUS, MINUS, STAR, SLASH,
    LPAREN, RPAREN,
    LBRACKET, RBRACKET,
    LBRACE, RBRACE,
    COMMA,
    SEMICOLON,
    ASSIGN, QUESTION, COLON,
    OR, AND, NOT,
    LT, GT, EQ,
    IF, ELSEIF, ELSE, THEN,
    PRINT_EXPR,  // 原 PRINT 改为 PRINT_EXPR，用于 \...\ 打印表达式
    WHILE,
    FOR, CONTINUE, BREAK,
    RANGE,
    DOT,
    NEWLINE, INDENT, DEDENT,
    END,
    MOD, EXP, LE, GE, NE,
    ASSIGN_ADD, ASSIGN_SUB, ASSIGN_MUL, ASSIGN_DIV, ASSIGN_MOD, ASSIGN_EXP,
    RETURN,
    AT
};

struct Token {
    TokenTypes type;
    std::string lexeme;
    int line;
    int indent_level;
};

class Lexer {
public:
    Lexer(const std::string& src, bool handle_indent = true)
        : src(src), pos(0), current_line(1), indent_stack({0}), handle_indent(handle_indent) {}

    std::vector<Token> tokenize() {
        std::vector<Token> tokens;
        bool at_line_start = true;
        while (pos < src.size()) {
            char c = src[pos];
            // ---------- 换行 ----------
            if (c == '\n') {
                ++current_line;
                ++pos;
                if (handle_indent) {
                    if (!tokens.empty() && tokens.back().type != TokenTypes::NEWLINE &&
                        tokens.back().type != TokenTypes::INDENT && tokens.back().type != TokenTypes::DEDENT) {
                        tokens.push_back({TokenTypes::NEWLINE, "\n", current_line - 1, 0});
                    }
                    at_line_start = true;
                }
                continue;
            }

            // ---------- 行首缩进（仅在 handle_indent 时处理） ----------
            if (handle_indent && at_line_start) {
                at_line_start = false;
                int indent = 0;
                while (pos < src.size() && (src[pos] == ' ' || src[pos] == '\t')) {
                    if (src[pos] == ' ') ++indent;
                    else if (src[pos] == '\t') indent += 4;
                    ++pos;
                }
                if (pos < src.size() && src[pos] == '\n') {
                    at_line_start = true;
                    continue;
                }
                if (pos < src.size() && src[pos] == '/') {
                    if (pos + 1 < src.size()) {
                        if (src[pos + 1] == '/') {
                            while (pos < src.size() && src[pos] != '\n') ++pos;
                            at_line_start = true;
                            continue;
                        } else if (src[pos + 1] == '|') {
                            pos += 2;
                            while (pos + 1 < src.size() && !(src[pos] == '|' && src[pos + 1] == '/')) {
                                if (src[pos] == '\n') ++current_line;
                                ++pos;
                            }
                            if (pos + 1 < src.size()) pos += 2;
                            at_line_start = true;
                            continue;
                        }
                    }
                }
                while (indent_stack.back() < indent) {
                    indent_stack.push_back(indent);
                    tokens.push_back({TokenTypes::INDENT, "", current_line, indent});
                }
                while (indent_stack.back() > indent) {
                    indent_stack.pop_back();
                    tokens.push_back({TokenTypes::DEDENT, "", current_line, indent_stack.back()});
                }
                continue;
            }

            // ---------- 跳过行内空白 ----------
            if (isspace(c) && c != '\n') {
                ++pos;
                continue;
            }

            // ---------- 注释 ----------
            if (src[pos] == '/') {
                if (pos + 1 < src.size()) {
                    if (src[pos + 1] == '/') {
                        while (pos < src.size() && src[pos] != '\n') ++pos;
                        continue;
                    }
                    if (src[pos + 1] == '|') {
                        pos += 2;
                        while (pos + 1 < src.size() && !(src[pos] == '|' && src[pos + 1] == '/')) {
                            if (src[pos] == '\n') ++current_line;
                            ++pos;
                        }
                        if (pos + 1 < src.size()) pos += 2;
                        continue;
                    }
                }
            }

            // ---------- 字符串 ----------
            if (src[pos] == '"') {
                int line = current_line;
                ++pos;
                std::string str;
                while (pos < src.size() && src[pos] != '"') {
                    if (src[pos] == '\\' && pos + 1 < src.size()) {
                        char esc = src[pos + 1];
                        if (esc == 'n') str += '\n';
                        else if (esc == 't') str += '\t';
                        else if (esc == '\\') str += '\\';
                        else if (esc == '"') str += '"';
                        else str += esc;
                        pos += 2;
                    } else {
                        str += src[pos++];
                    }
                }
                if (pos < src.size() && src[pos] == '"') ++pos;
                tokens.push_back({TokenTypes::STRING, str, line, 0});
                continue;
            }

            // ---------- 标识符 ----------
            if (isalpha(src[pos]) || src[pos] == '_' || (unsigned char)src[pos] >= 128) {
                int line = current_line;
                std::string ident;
                while (pos < src.size() && (isalnum(src[pos]) || src[pos] == '_' || (unsigned char)src[pos] >= 128)) {
                    ident += src[pos++];
                }
                tokens.push_back({TokenTypes::IDENTIFIER, ident, line, 0});
                continue;
            }

            // ---------- 数字 ----------
            if (isdigit(src[pos]) || (src[pos] == '.' && pos + 1 < src.size() && isdigit(src[pos + 1]))) {
                int line = current_line;
                std::string num;
                bool hasDot = false;
                while (pos < src.size() && (isdigit(src[pos]) || src[pos] == '.')) {
                    if (src[pos] == '.') {
                        if (hasDot || (pos + 1 < src.size() && src[pos + 1] == '.')) {
                            break;
                        }
                        hasDot = true;
                    }
                    num += src[pos++];
                }
                tokens.push_back({TokenTypes::NUMBER, num, line, 0});
                continue;
            }

            // ---------- 多字符运算符 ----------
            if (src[pos] == '+' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::ASSIGN_ADD, "+=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '-' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::ASSIGN_SUB, "-=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '*' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::ASSIGN_MUL, "*=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '/' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::ASSIGN_DIV, "/=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '%' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::ASSIGN_MOD, "%=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '^' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::ASSIGN_EXP, "^=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '<' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::LE, "<=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '>' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::GE, ">=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '!' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::NE, "!=", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '=' && pos + 1 < src.size() && src[pos + 1] == '=') {
                tokens.push_back({TokenTypes::EQ, "==", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '?' && pos + 1 < src.size() && src[pos + 1] == '>') {
                tokens.push_back({TokenTypes::IF, "?>", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '|' && pos + 1 < src.size() && src[pos + 1] == '>') {
                tokens.push_back({TokenTypes::ELSEIF, "|>", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '!' && pos + 1 < src.size() && src[pos + 1] == '>') {
                tokens.push_back({TokenTypes::ELSE, "!>", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '>' && pos + 1 < src.size() && src[pos + 1] == '>') {
                tokens.push_back({TokenTypes::THEN, ">>", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '#' && pos + 1 < src.size() && src[pos + 1] == '#') {
                tokens.push_back({TokenTypes::FOR, "##", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '^' && pos + 1 < src.size() && src[pos + 1] == '^') {
                tokens.push_back({TokenTypes::CONTINUE, "^^", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '~' && pos + 1 < src.size() && src[pos + 1] == '~') {
                tokens.push_back({TokenTypes::BREAK, "~~", current_line, 0});
                pos += 2;
                continue;
            }
            if (src[pos] == '.' && pos + 1 < src.size() && src[pos + 1] == '.') {
                tokens.push_back({TokenTypes::RANGE, "..", current_line, 0});
                pos += 2;
                continue;
            }
            // ---------- 打印指令 \...\ ，支持任意表达式 ----------
            if (src[pos] == '\\') {
                int line = current_line;
                ++pos;  // 跳过开头的反斜杠
                size_t start = pos;
                // 查找闭合的反斜杠
                while (pos < src.size() && src[pos] != '\\') {
                    ++pos;
                }
                if (pos >= src.size()) {
                    throw std::runtime_error("Zeile " + std::to_string(line) + ": Fehlender schließender '\\' in Print-Direktive");
                }
                std::string raw = src.substr(start, pos - start);
                ++pos;  // 跳过闭合的反斜杠
                // 将 raw 作为 PRINT_EXPR 的 lexeme 存储，后续由解析器解析为表达式
                tokens.push_back({TokenTypes::PRINT_EXPR, raw, line, 0});
                continue;
            }
            if (src[pos] == '@' && pos + 1 < src.size() && src[pos + 1] == '^') {
                tokens.push_back({TokenTypes::RETURN, "@^", current_line, 0});
                pos += 2;
                continue;
            }
            // ---------- 单字符 ----------
            int line = current_line;
            switch (src[pos]) {
                case '+': tokens.push_back({TokenTypes::PLUS, "+", line, 0}); break;
                case '-': tokens.push_back({TokenTypes::MINUS, "-", line, 0}); break;
                case '*': tokens.push_back({TokenTypes::STAR, "*", line, 0}); break;
                case '/': tokens.push_back({TokenTypes::SLASH, "/", line, 0}); break;
                case '%': tokens.push_back({TokenTypes::MOD, "%", line, 0}); break;
                case '^': tokens.push_back({TokenTypes::EXP, "^", line, 0}); break;
                case '(': tokens.push_back({TokenTypes::LPAREN, "(", line, 0}); break;
                case ')': tokens.push_back({TokenTypes::RPAREN, ")", line, 0}); break;
                case '[': tokens.push_back({TokenTypes::LBRACKET, "[", line, 0}); break;
                case ']': tokens.push_back({TokenTypes::RBRACKET, "]", line, 0}); break;
                case '{': tokens.push_back({TokenTypes::LBRACE, "{", line, 0}); break;
                case '}': tokens.push_back({TokenTypes::RBRACE, "}", line, 0}); break;
                case ',': tokens.push_back({TokenTypes::COMMA, ",", line, 0}); break;
                case '=': tokens.push_back({TokenTypes::ASSIGN, "=", line, 0}); break;
                case '?': tokens.push_back({TokenTypes::QUESTION, "?", line, 0}); break;
                case ':': tokens.push_back({TokenTypes::COLON, ":", line, 0}); break;
                case '|': tokens.push_back({TokenTypes::OR, "|", line, 0}); break;
                case '&': tokens.push_back({TokenTypes::AND, "&", line, 0}); break;
                case '!': tokens.push_back({TokenTypes::NOT, "!", line, 0}); break;
                case '<': tokens.push_back({TokenTypes::LT, "<", line, 0}); break;
                case '>': tokens.push_back({TokenTypes::GT, ">", line, 0}); break;
                case '#': tokens.push_back({TokenTypes::WHILE, "#", line, 0}); break;
                case '.': tokens.push_back({TokenTypes::DOT, ".", line, 0}); break;
                case ';': tokens.push_back({TokenTypes::SEMICOLON, ";", line, 0}); break;
                case '@': tokens.push_back({TokenTypes::AT, "@", line, 0}); break;
                default: throw std::runtime_error("Zeile " + std::to_string(line) + ": Unerwartetes Zeichen: " + src[pos]);
            }
            ++pos;
        }
        if (handle_indent) {
            while (indent_stack.size() > 1) {
                indent_stack.pop_back();
                tokens.push_back({TokenTypes::DEDENT, "", current_line, indent_stack.back()});
            }
        }
        tokens.push_back({TokenTypes::END, "", current_line, 0});
        return tokens;
    }
private:
    std::string src;
    size_t pos;
    int current_line;
    std::vector<int> indent_stack;
    bool handle_indent;
};

// =========================== AST ===========================
struct Expr { virtual ~Expr() = default; };
struct NumberExpr : Expr { double value; NumberExpr(double v) : value(v) {} };
struct VariableExpr : Expr { std::string name; VariableExpr(const std::string& n) : name(n) {} };
struct BinaryExpr : Expr {
    enum Op { ADD, SUB, MUL, DIV, LT, GT, EQ, AND, OR, MOD, EXP, LE, GE, NE };
    Op op; std::unique_ptr<Expr> left, right;
    BinaryExpr(Op o, std::unique_ptr<Expr> l, std::unique_ptr<Expr> r) : op(o), left(std::move(l)), right(std::move(r)) {}
};
struct UnaryExpr : Expr {
    enum Op { NOT };
    Op op; std::unique_ptr<Expr> operand;
    UnaryExpr(Op o, std::unique_ptr<Expr> opnd) : op(o), operand(std::move(opnd)) {}
};
struct ConditionalExpr : Expr {
    std::unique_ptr<Expr> cond, thenExpr, elseExpr;
    ConditionalExpr(std::unique_ptr<Expr> c, std::unique_ptr<Expr> t, std::unique_ptr<Expr> e)
        : cond(std::move(c)), thenExpr(std::move(t)), elseExpr(std::move(e)) {}
};
struct ArrayLiteralExpr : Expr {
    std::vector<std::unique_ptr<Expr>> elements;
    ArrayLiteralExpr(std::vector<std::unique_ptr<Expr>> elems) : elements(std::move(elems)) {}
};
struct IndexExpr : Expr {
    std::unique_ptr<Expr> array;
    std::unique_ptr<Expr> index;
    IndexExpr(std::unique_ptr<Expr> a, std::unique_ptr<Expr> i) : array(std::move(a)), index(std::move(i)) {}
};
struct RangeExpr : Expr {
    std::unique_ptr<Expr> left, right;
    RangeExpr(std::unique_ptr<Expr> l, std::unique_ptr<Expr> r) : left(std::move(l)), right(std::move(r)) {}
};
struct ObjectLiteralExpr : Expr {
    std::vector<std::pair<std::string, std::unique_ptr<Expr>>> fields;
    ObjectLiteralExpr(std::vector<std::pair<std::string, std::unique_ptr<Expr>>> f) : fields(std::move(f)) {}
};
struct PropertyAccessExpr : Expr {
    std::unique_ptr<Expr> object;
    std::string key;
    PropertyAccessExpr(std::unique_ptr<Expr> o, const std::string& k) : object(std::move(o)), key(k) {}
};
struct FunctionCallExpr : Expr {
    std::string funcName;
    std::vector<std::unique_ptr<Expr>> args;
    FunctionCallExpr(const std::string& name, std::vector<std::unique_ptr<Expr>> a)
        : funcName(name), args(std::move(a)) {}
};
struct StringLiteralExpr : Expr {
    std::string raw;
    std::vector<std::string> parts;
    StringLiteralExpr(const std::string& r, const std::vector<std::string>& p)
        : raw(r), parts(p) {}
};

struct Stmt { virtual ~Stmt() = default; };
struct AssignmentStmt : Stmt {
    std::string var; std::unique_ptr<Expr> expr;
    AssignmentStmt(const std::string& v, std::unique_ptr<Expr> e) : var(v), expr(std::move(e)) {}
};
struct IndexAssignmentStmt : Stmt {
    std::unique_ptr<Expr> array;
    std::unique_ptr<Expr> index;
    std::unique_ptr<Expr> expr;
    IndexAssignmentStmt(std::unique_ptr<Expr> a, std::unique_ptr<Expr> i, std::unique_ptr<Expr> e)
        : array(std::move(a)), index(std::move(i)), expr(std::move(e)) {}
};
struct PropertyAssignmentStmt : Stmt {
    std::unique_ptr<Expr> object;
    std::string key;
    std::unique_ptr<Expr> expr;
    PropertyAssignmentStmt(std::unique_ptr<Expr> o, const std::string& k, std::unique_ptr<Expr> e)
        : object(std::move(o)), key(k), expr(std::move(e)) {}
};
struct CompoundAssignStmt : Stmt {
    std::unique_ptr<Expr> left;
    TokenTypes op;
    std::unique_ptr<Expr> right;
    CompoundAssignStmt(std::unique_ptr<Expr> l, TokenTypes o, std::unique_ptr<Expr> r)
        : left(std::move(l)), op(o), right(std::move(r)) {}
};
struct PrintStmt : Stmt {
    std::unique_ptr<Expr> expr;  // 改为表达式
    PrintStmt(std::unique_ptr<Expr> e) : expr(std::move(e)) {}
};
struct IfStmt : Stmt {
    struct ElseIf { std::unique_ptr<Expr> cond; std::unique_ptr<Stmt> body; };
    std::unique_ptr<Expr> cond;
    std::unique_ptr<Stmt> thenBody;
    std::vector<ElseIf> elseIfs;
    std::unique_ptr<Stmt> elseBody;
};
struct WhileStmt : Stmt {
    std::unique_ptr<Expr> cond;
    std::unique_ptr<Stmt> body;
    WhileStmt(std::unique_ptr<Expr> c, std::unique_ptr<Stmt> b) : cond(std::move(c)), body(std::move(b)) {}
};
struct ForStmt : Stmt {
    std::string var;
    std::unique_ptr<Expr> start;
    std::unique_ptr<Expr> end;
    std::unique_ptr<Stmt> body;
    bool isRange;
    ForStmt(const std::string& v, std::unique_ptr<Expr> s, std::unique_ptr<Expr> e,
            std::unique_ptr<Stmt> b, bool range)
        : var(v), start(std::move(s)), end(std::move(e)), body(std::move(b)), isRange(range) {}
};
struct BlockStmt : Stmt {
    std::vector<std::unique_ptr<Stmt>> statements;
};
struct ContinueStmt : Stmt {};
struct BreakStmt : Stmt {};
struct ExpressionStmt : Stmt {
    std::unique_ptr<Expr> expr;
    ExpressionStmt(std::unique_ptr<Expr> e) : expr(std::move(e)) {}
};
struct FunctionDefStmt : Stmt {
    std::string name;
    std::vector<std::string> params;
    std::unique_ptr<BlockStmt> body;
    FunctionDefStmt(const std::string& n, const std::vector<std::string>& p, std::unique_ptr<BlockStmt> b)
        : name(n), params(p), body(std::move(b)) {}
};

struct Program {
    std::vector<std::unique_ptr<Stmt>> statements;
    std::vector<std::unique_ptr<FunctionDefStmt>> functions;
};

struct ReturnStmt : Stmt {
    std::unique_ptr<Expr> expr;  // nullptr 表示空返回
    ReturnStmt(std::unique_ptr<Expr> e = nullptr) : expr(std::move(e)) {}
};

// =========================== 语法分析 ===========================
class Parser {
public:
    Parser(const std::vector<Token>& tokens) : tokens(tokens), pos(0) {}

    std::unique_ptr<Program> parse() {
        auto prog = std::make_unique<Program>();
        while (!peek(TokenTypes::END)) {
            while (peek(TokenTypes::NEWLINE)) consume();
            if (peek(TokenTypes::END)) break;
            auto stmt = parseStatement();
            if (dynamic_cast<FunctionDefStmt*>(stmt.get())) {
                prog->functions.push_back(std::unique_ptr<FunctionDefStmt>(static_cast<FunctionDefStmt*>(stmt.release())));
            } else {
                prog->statements.push_back(std::move(stmt));
            }
        }
        return prog;
    }

    // 公共方法：从 tokens 解析一个表达式
    std::unique_ptr<Expr> parseExpressionFromTokens(const std::vector<Token>& toks) {
        Parser p(toks);
        p.pos = 0;
        return p.parseExpression();
    }

private:
    const std::vector<Token>& tokens;
    size_t pos;

    Token peek() const { return tokens[pos]; }
    Token consume() { return tokens[pos++]; }
    bool match(TokenTypes t) {
        if (peek().type == t) {
            ++pos;
            return true;
        }
        return false;
    }
    bool peek(TokenTypes t) const { return tokens[pos].type == t; }
    void expect(TokenTypes t, const std::string& msg = "Token erwartet") {
        if (!match(t)) {
            Token cur = peek();
            throw std::runtime_error("Zeile " + std::to_string(cur.line) + ": " + msg + " (erhalten: " + cur.lexeme + ")");
        }
    }

    std::vector<std::string> parseStringInterpolation(const std::string& raw) {
        std::vector<std::string> parts;
        size_t start = 0, cur = 0;
        while (cur < raw.size()) {
            if (raw[cur] == '{') {
                if (cur > start) parts.push_back(raw.substr(start, cur - start));
                size_t end = raw.find('}', cur + 1);
                if (end == std::string::npos)
                    throw std::runtime_error("Ungeschlossene Interpolation in: " + raw);
                std::string var = raw.substr(cur + 1, end - cur - 1);
                if (var.empty() || !(isalpha(var[0]) || var[0] == '_'))
                    throw std::runtime_error("Ungültiger Variablenname in Interpolation: " + var);
                parts.push_back(var);
                start = end + 1;
                cur = end + 1;
            } else {
                ++cur;
            }
        }
        if (start < raw.size()) parts.push_back(raw.substr(start));
        if (parts.empty()) parts.push_back(raw);
        return parts;
    }

    std::unique_ptr<Expr> parseRange() {
        auto expr = parseTernary();
        if (match(TokenTypes::RANGE)) {
            auto right = parseTernary();
            return std::make_unique<RangeExpr>(std::move(expr), std::move(right));
        }
        return expr;
    }

    std::unique_ptr<BlockStmt> parseBlock() {
        while (peek(TokenTypes::NEWLINE)) consume();
        if (!match(TokenTypes::INDENT)) {
            Token cur = peek();
            throw std::runtime_error("Zeile " + std::to_string(cur.line) + ": Einrückung erwartet");
        }
        auto block = std::make_unique<BlockStmt>();
        while (!peek(TokenTypes::DEDENT) && !peek(TokenTypes::END)) {
            while (peek(TokenTypes::NEWLINE)) consume();
            if (peek(TokenTypes::DEDENT) || peek(TokenTypes::END)) break;
            auto stmt = parseStatement();
            block->statements.push_back(std::move(stmt));
        }
        if (!match(TokenTypes::DEDENT)) {
            Token cur = peek();
            throw std::runtime_error("Zeile " + std::to_string(cur.line) + ": Fehlende DEDENT");
        }
        return block;
    }

    std::unique_ptr<Stmt> parseFunctionDef() {
        consume();  // '@'
        if (!peek(TokenTypes::IDENTIFIER))
            throw std::runtime_error("Funktionsname erwartet");
        Token name = consume();
        expect(TokenTypes::LPAREN, "'(' erwartet");
        std::vector<std::string> params;
        if (!peek(TokenTypes::RPAREN)) {
            do {
                if (!peek(TokenTypes::IDENTIFIER))
                    throw std::runtime_error("Parametername erwartet");
                params.push_back(consume().lexeme);
            } while (match(TokenTypes::COMMA));
        }
        expect(TokenTypes::RPAREN, "')' erwartet");
    
        if (peek(TokenTypes::COLON)) {
            consume();
        } else {
            expect(TokenTypes::THEN, "'>>' oder ':' erwartet");
        }
    
        if (peek(TokenTypes::NEWLINE)) {
            consume();
            auto body = parseBlock();
            return std::make_unique<FunctionDefStmt>(name.lexeme, params, std::move(body));
        } else {
            auto stmt = parseStatement();
            auto block = std::make_unique<BlockStmt>();
            block->statements.push_back(std::move(stmt));
            return std::make_unique<FunctionDefStmt>(name.lexeme, params, std::move(block));
        }
    }

    std::unique_ptr<Stmt> parseStatement() {
        if (peek(TokenTypes::AT)) {
            return parseFunctionDef();
        }
        if (peek(TokenTypes::CONTINUE)) {
            consume();
            expect(TokenTypes::NEWLINE, "nach continue fehlt Zeilenumbruch");
            return std::make_unique<ContinueStmt>();
        }
        if (peek(TokenTypes::BREAK)) {
            consume();
            expect(TokenTypes::NEWLINE, "nach break fehlt Zeilenumbruch");
            return std::make_unique<BreakStmt>();
        }
        if (peek(TokenTypes::WHILE)) return parseWhile();
        if (peek(TokenTypes::FOR)) return parseFor();
        if (peek(TokenTypes::IF)) return parseIf();
        // 处理打印表达式
        if (peek(TokenTypes::PRINT_EXPR)) {
            Token t = consume();
            std::string raw = t.lexeme;
            // 对 raw 进行词法分析（不处理缩进）
            Lexer innerLexer(raw, false);
            auto innerTokens = innerLexer.tokenize();
            // 过滤掉 NEWLINE（虽然 raw 内通常没有，但以防万一）
            std::vector<Token> filtered;
            for (auto& tok : innerTokens) {
                if (tok.type != TokenTypes::NEWLINE)
                    filtered.push_back(tok);
            }
            auto expr = parseExpressionFromTokens(filtered);
            expect(TokenTypes::NEWLINE, "nach Print-Direktive fehlt Zeilenumbruch");
            return std::make_unique<PrintStmt>(std::move(expr));
        }
        if (peek(TokenTypes::IDENTIFIER)) {
            auto left = parseExpression();
            if (peek(TokenTypes::ASSIGN_ADD) || peek(TokenTypes::ASSIGN_SUB) ||
                peek(TokenTypes::ASSIGN_MUL) || peek(TokenTypes::ASSIGN_DIV) ||
                peek(TokenTypes::ASSIGN_MOD) || peek(TokenTypes::ASSIGN_EXP)) {
                Token opToken = consume();
                auto right = parseExpression();
                expect(TokenTypes::NEWLINE, "nach Ausdruck fehlt Zeilenumbruch");
                return std::make_unique<CompoundAssignStmt>(std::move(left), opToken.type, std::move(right));
            }
            if (peek(TokenTypes::ASSIGN)) {
                consume();
                auto right = parseExpression();
                expect(TokenTypes::NEWLINE, "nach Ausdruck fehlt Zeilenumbruch");
                if (auto* v = dynamic_cast<VariableExpr*>(left.get())) {
                    return std::make_unique<AssignmentStmt>(v->name, std::move(right));
                } else if (auto* idx = dynamic_cast<IndexExpr*>(left.get())) {
                    auto array = std::move(idx->array);
                    auto index = std::move(idx->index);
                    return std::make_unique<IndexAssignmentStmt>(std::move(array), std::move(index), std::move(right));
                } else if (auto* pa = dynamic_cast<PropertyAccessExpr*>(left.get())) {
                    auto obj = std::move(pa->object);
                    std::string key = pa->key;
                    return std::make_unique<PropertyAssignmentStmt>(std::move(obj), key, std::move(right));
                } else {
                    throw std::runtime_error("Linke Seite der Zuweisung ist kein lvalue");
                }
            } else {
                expect(TokenTypes::NEWLINE, "nach Ausdruck fehlt Zeilenumbruch");
                return std::make_unique<ExpressionStmt>(std::move(left));
            }
        }
        if (peek(TokenTypes::NUMBER) || peek(TokenTypes::LPAREN) || peek(TokenTypes::NOT) ||
            peek(TokenTypes::LBRACKET) || peek(TokenTypes::LBRACE) || peek(TokenTypes::STRING)) {
            auto expr = parseExpression();
            expect(TokenTypes::NEWLINE, "nach Ausdruck fehlt Zeilenumbruch");
            return std::make_unique<ExpressionStmt>(std::move(expr));
        }
        if (peek(TokenTypes::RETURN)) {
            consume();  // 消耗 RETURN
            std::unique_ptr<Expr> retExpr = nullptr;
            if (peek(TokenTypes::SEMICOLON)) {
                consume();  // 消耗 ';'，表示空返回
            } else {
                // 解析表达式（可能为普通表达式，但注意不能出现 ';' 或 NEWLINE 前的错误）
                retExpr = parseExpression();
                // 可选：允许后面跟分号或换行，但这里统一期望 NEWLINE
            }
            expect(TokenTypes::NEWLINE, "nach Rückgabe-Anweisung fehlt Zeilenumbruch");
            return std::make_unique<ReturnStmt>(std::move(retExpr));
        }
        Token cur = peek();
        throw std::runtime_error("Zeile " + std::to_string(cur.line) + ": Unerwartete Anweisung (Token: " + cur.lexeme + ")");
    }

    std::unique_ptr<Stmt> parseWhile() {
        consume();
        auto cond = parseExpression();
        expect(TokenTypes::THEN, "nach Bedingung fehlt '>>'");
        if (peek(TokenTypes::NEWLINE)) {
            auto body = parseBlock();
            return std::make_unique<WhileStmt>(std::move(cond), std::move(body));
        } else {
            auto stmt = parseStatement();
            auto block = std::make_unique<BlockStmt>();
            block->statements.push_back(std::move(stmt));
            return std::make_unique<WhileStmt>(std::move(cond), std::move(block));
        }
    }

    std::unique_ptr<Stmt> parseFor() {
        consume();
        if (!peek(TokenTypes::IDENTIFIER)) {
            Token cur = peek();
            throw std::runtime_error("Zeile " + std::to_string(cur.line) + ": Bezeichner für Schleifenvariable erwartet");
        }
        Token var = consume();
        expect(TokenTypes::WHILE, "nach Variable fehlt '#'");

        auto expr = parseExpressionWithoutRange();

        if (match(TokenTypes::RANGE)) {
            auto end = parseExpressionWithoutRange();
            expect(TokenTypes::THEN, "nach Bereich fehlt '>>'");
            if (peek(TokenTypes::NEWLINE)) {
                auto body = parseBlock();
                return std::make_unique<ForStmt>(var.lexeme, std::move(expr), std::move(end), std::move(body), true);
            } else {
                auto stmt = parseStatement();
                auto block = std::make_unique<BlockStmt>();
                block->statements.push_back(std::move(stmt));
                return std::make_unique<ForStmt>(var.lexeme, std::move(expr), std::move(end), std::move(block), true);
            }
        } else {
            expect(TokenTypes::THEN, "nach Array fehlt '>>'");
            if (peek(TokenTypes::NEWLINE)) {
                auto body = parseBlock();
                return std::make_unique<ForStmt>(var.lexeme, std::move(expr), nullptr, std::move(body), false);
            } else {
                auto stmt = parseStatement();
                auto block = std::make_unique<BlockStmt>();
                block->statements.push_back(std::move(stmt));
                return std::make_unique<ForStmt>(var.lexeme, std::move(expr), nullptr, std::move(block), false);
            }
        }
    }

    std::unique_ptr<Stmt> parseIf() {
        consume();
        auto cond = parseExpression();
        expect(TokenTypes::THEN, "nach Bedingung fehlt '>>'");
        auto ifStmt = std::make_unique<IfStmt>();
        ifStmt->cond = std::move(cond);

        bool isSingleLine = !peek(TokenTypes::NEWLINE);
        if (isSingleLine) {
            ifStmt->thenBody = parseStatement();
            while (peek(TokenTypes::ELSEIF)) {
                consume();
                auto econd = parseExpression();
                expect(TokenTypes::THEN, "nach Bedingung in Sonst falls fehlt '>>'");
                auto ebody = parseStatement();
                IfStmt::ElseIf ei;
                ei.cond = std::move(econd);
                ei.body = std::move(ebody);
                ifStmt->elseIfs.push_back(std::move(ei));
            }
            if (peek(TokenTypes::ELSE)) {
                consume();
                ifStmt->elseBody = parseStatement();
            }
        } else {
            consume();
            while (peek(TokenTypes::NEWLINE)) consume();
            ifStmt->thenBody = parseBlock();
            while (peek(TokenTypes::ELSEIF)) {
                consume();
                auto econd = parseExpression();
                expect(TokenTypes::THEN, "nach Bedingung in Sonst falls fehlt '>>'");
                while (peek(TokenTypes::NEWLINE)) consume();
                auto ebody = parseBlock();
                IfStmt::ElseIf ei;
                ei.cond = std::move(econd);
                ei.body = std::move(ebody);
                ifStmt->elseIfs.push_back(std::move(ei));
            }
            if (peek(TokenTypes::ELSE)) {
                consume();
                while (peek(TokenTypes::NEWLINE)) consume();
                ifStmt->elseBody = parseBlock();
            }
        }
        return ifStmt;
    }

    std::unique_ptr<Expr> parseExpression() { return parseRange(); }

    std::unique_ptr<Expr> parseTernary() {
        auto expr = parseOr();
        if (match(TokenTypes::QUESTION)) {
            auto thenExpr = parseExpression();
            expect(TokenTypes::COLON, "in ternärem Ausdruck fehlt ':'");
            auto elseExpr = parseExpression();
            return std::make_unique<ConditionalExpr>(std::move(expr), std::move(thenExpr), std::move(elseExpr));
        }
        return expr;
    }

    std::unique_ptr<Expr> parseExpressionWithoutRange() {
        return parseOr();
    }

    std::unique_ptr<Expr> parseOr() {
        auto expr = parseAnd();
        while (match(TokenTypes::OR)) {
            auto right = parseAnd();
            expr = std::make_unique<BinaryExpr>(BinaryExpr::OR, std::move(expr), std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseAnd() {
        auto expr = parseComparison();
        while (match(TokenTypes::AND)) {
            auto right = parseComparison();
            expr = std::make_unique<BinaryExpr>(BinaryExpr::AND, std::move(expr), std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseComparison() {
        auto expr = parseAddSub();
        if (match(TokenTypes::LT) || match(TokenTypes::GT) || match(TokenTypes::EQ) ||
            match(TokenTypes::LE) || match(TokenTypes::GE) || match(TokenTypes::NE)) {
            TokenTypes opType = tokens[pos - 1].type;
            auto right = parseAddSub();
            BinaryExpr::Op op;
            switch (opType) {
                case TokenTypes::LT: op = BinaryExpr::LT; break;
                case TokenTypes::GT: op = BinaryExpr::GT; break;
                case TokenTypes::EQ: op = BinaryExpr::EQ; break;
                case TokenTypes::LE: op = BinaryExpr::LE; break;
                case TokenTypes::GE: op = BinaryExpr::GE; break;
                case TokenTypes::NE: op = BinaryExpr::NE; break;
                default: throw std::runtime_error("Ungültiger Vergleichsoperator");
            }
            return std::make_unique<BinaryExpr>(op, std::move(expr), std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseAddSub() {
        auto expr = parseMulDiv();
        while (true) {
            if (match(TokenTypes::PLUS)) {
                auto right = parseMulDiv();
                expr = std::make_unique<BinaryExpr>(BinaryExpr::ADD, std::move(expr), std::move(right));
            } else if (match(TokenTypes::MINUS)) {
                auto right = parseMulDiv();
                expr = std::make_unique<BinaryExpr>(BinaryExpr::SUB, std::move(expr), std::move(right));
            } else break;
        }
        return expr;
    }
    std::unique_ptr<Expr> parseMulDiv() {
        auto expr = parseExponent();
        while (true) {
            if (match(TokenTypes::STAR)) {
                auto right = parseExponent();
                expr = std::make_unique<BinaryExpr>(BinaryExpr::MUL, std::move(expr), std::move(right));
            } else if (match(TokenTypes::SLASH)) {
                auto right = parseExponent();
                expr = std::make_unique<BinaryExpr>(BinaryExpr::DIV, std::move(expr), std::move(right));
            } else if (match(TokenTypes::MOD)) {
                auto right = parseExponent();
                expr = std::make_unique<BinaryExpr>(BinaryExpr::MOD, std::move(expr), std::move(right));
            } else break;
        }
        return expr;
    }
    std::unique_ptr<Expr> parseExponent() {
        auto expr = parseUnary();
        if (match(TokenTypes::EXP)) {
            auto right = parseExponent();
            return std::make_unique<BinaryExpr>(BinaryExpr::EXP, std::move(expr), std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseUnary() {
        if (match(TokenTypes::NOT)) {
            auto operand = parseUnary();
            return std::make_unique<UnaryExpr>(UnaryExpr::NOT, std::move(operand));
        }
        return parsePrimary();
    }
    std::unique_ptr<Expr> parsePrimary() {
        if (match(TokenTypes::NUMBER)) {
            double val = std::stod(tokens[pos - 1].lexeme);
            return std::make_unique<NumberExpr>(val);
        }
        if (match(TokenTypes::STRING)) {
            std::string raw = tokens[pos - 1].lexeme;
            auto parts = parseStringInterpolation(raw);
            return std::make_unique<StringLiteralExpr>(raw, parts);
        }
        if (match(TokenTypes::IDENTIFIER)) {
            std::string name = tokens[pos - 1].lexeme;
            if (peek(TokenTypes::LPAREN)) {
                consume();
                std::vector<std::unique_ptr<Expr>> args;
                if (!peek(TokenTypes::RPAREN)) {
                    do {
                        args.push_back(parseExpression());
                    } while (match(TokenTypes::COMMA));
                }
                expect(TokenTypes::RPAREN, "')' erwartet");
                return std::make_unique<FunctionCallExpr>(name, std::move(args));
            }
            std::unique_ptr<Expr> expr = std::make_unique<VariableExpr>(name);
            while (true) {
                if (peek(TokenTypes::DOT)) {
                    consume();
                    if (!peek(TokenTypes::IDENTIFIER)) {
                        throw std::runtime_error("nach '.' wird ein Bezeichner erwartet");
                    }
                    std::string key = consume().lexeme;
                    expr = std::make_unique<PropertyAccessExpr>(std::move(expr), key);
                } else if (peek(TokenTypes::LBRACKET)) {
                    consume();
                    auto index = parseExpression();
                    expect(TokenTypes::RBRACKET, "nach Index fehlt ']'");
                    expr = std::make_unique<IndexExpr>(std::move(expr), std::move(index));
                } else {
                    break;
                }
            }
            return expr;
        }
        if (match(TokenTypes::LPAREN)) {
            auto expr = parseExpression();
            expect(TokenTypes::RPAREN, "nach '(' fehlt ')'");
            return expr;
        }
        if (match(TokenTypes::LBRACKET)) {
            std::vector<std::unique_ptr<Expr>> elements;
            if (!peek(TokenTypes::RBRACKET)) {
                do {
                    elements.push_back(parseExpression());
                } while (match(TokenTypes::COMMA));
            }
            expect(TokenTypes::RBRACKET, "nach Array-Literal fehlt ']'");
            return std::make_unique<ArrayLiteralExpr>(std::move(elements));
        }
        if (match(TokenTypes::LBRACE)) {
            std::vector<std::pair<std::string, std::unique_ptr<Expr>>> fields;
            if (!peek(TokenTypes::RBRACE)) {
                do {
                    std::string key;
                    if (peek(TokenTypes::IDENTIFIER)) {
                        key = consume().lexeme;
                    } else if (peek(TokenTypes::STRING)) {
                        key = consume().lexeme;
                    } else {
                        throw std::runtime_error("Objektschlüssel erwartet");
                    }
                    expect(TokenTypes::COLON, "nach Schlüssel fehlt ':'");
                    auto val = parseExpression();
                    fields.push_back({key, std::move(val)});
                } while (match(TokenTypes::COMMA));
            }
            expect(TokenTypes::RBRACE, "nach Objektliteral fehlt '}'");
            return std::make_unique<ObjectLiteralExpr>(std::move(fields));
        }
        Token cur = peek();
        throw std::runtime_error("Zeile " + std::to_string(cur.line) + ": Primärer Ausdruck erwartet (Token: " + cur.lexeme + ")");
    }
};

// =========================== 编译器 ===========================
namespace vw {

enum OpCode {
    OP_PUSH, OP_LOAD, OP_STORE,
    OP_ADD, OP_SUB, OP_MUL, OP_DIV,
    OP_LT, OP_GT, OP_EQ, OP_AND, OP_OR, OP_NOT,
    OP_JMP, OP_JZ, OP_JNZ,
    OP_PRINT,
    OP_HALT,
    OP_POP,
    OP_NEW_ARRAY,
    OP_ARRAY_LITERAL,
    OP_LOAD_INDEX,
    OP_STORE_INDEX,
    OP_ARRAY_LEN,
    OP_PUSH_STRING,
    OP_NEW_OBJECT,
    OP_LOAD_PROPERTY,
    OP_STORE_PROPERTY,
    OP_CALL_EXTERNAL,
    OP_MOD, OP_EXP, OP_LE, OP_GE, OP_NE,
    OP_ITOS,
    OP_CONCAT,
    OP_PUSH_FLOAT,
    OP_CALL,
    OP_RET,
    OP_LOAD_LOCAL,
    OP_STORE_LOCAL,
};

struct Instruction { OpCode op; int operand; };

// ---------- 值类型 ----------
struct Value {
    enum Type { T_INT, T_FLOAT, T_STRING, T_ARRAY, T_OBJECT } type;
    union {
        int int_val;
        double float_val;
        int string_handle;
        int array_handle;
        int object_handle;
    };
    Value() : type(T_INT), int_val(0) {}
    Value(int v) : type(T_INT), int_val(v) {}
    Value(double v) : type(T_FLOAT), float_val(v) {}
    Value(int h, Type t) : type(t) {
        if (t == T_STRING) string_handle = h;
        else if (t == T_ARRAY) array_handle = h;
        else if (t == T_OBJECT) object_handle = h;
        else int_val = h;
    }
    bool isInt() const { return type == T_INT; }
    bool isFloat() const { return type == T_FLOAT; }
    bool isNumber() const { return type == T_INT || type == T_FLOAT; }
    bool isString() const { return type == T_STRING; }
    bool isArray() const { return type == T_ARRAY; }
    bool isObject() const { return type == T_OBJECT; }
    double asDouble() const {
        if (type == T_INT) return (double)int_val;
        if (type == T_FLOAT) return float_val;
        throw std::runtime_error("Wert ist keine Zahl");
    }
    int asInt() const {
        if (type == T_INT) return int_val;
        if (type == T_FLOAT) return (int)float_val;
        throw std::runtime_error("Wert ist keine Zahl");
    }
};

// ---------- 编译器 ----------
class Compiler {
public:
    // 对常量表达式求值，返回 0（假）或 1（真），若非常量返回 std::nullopt
    std::optional<int> evalConstExpr(const Expr* expr) {
        if (auto* n = dynamic_cast<const NumberExpr*>(expr)) {
            return (n->value != 0.0) ? 1 : 0;
        }
        if (auto* b = dynamic_cast<const BinaryExpr*>(expr)) {
            auto left = evalConstExpr(b->left.get());
            auto right = evalConstExpr(b->right.get());
            if (!left || !right) return std::nullopt;
            int l = *left, r = *right;
            switch (b->op) {
                case BinaryExpr::AND: return (l && r) ? 1 : 0;
                case BinaryExpr::OR:  return (l || r) ? 1 : 0;
                case BinaryExpr::EQ:  return (l == r) ? 1 : 0;
                case BinaryExpr::NE:  return (l != r) ? 1 : 0;
                case BinaryExpr::LT:  return (l < r) ? 1 : 0;
                case BinaryExpr::GT:  return (l > r) ? 1 : 0;
                case BinaryExpr::LE:  return (l <= r) ? 1 : 0;
                case BinaryExpr::GE:  return (l >= r) ? 1 : 0;
                case BinaryExpr::ADD: return l + r;
                case BinaryExpr::SUB: return l - r;
                case BinaryExpr::MUL: return l * r;
                case BinaryExpr::DIV: if (r == 0) return std::nullopt; return l / r;
                case BinaryExpr::MOD: if (r == 0) return std::nullopt; return l % r;
                case BinaryExpr::EXP: {
                    if (r < 0) return std::nullopt;
                    int result = 1;
                    for (int i = 0; i < r; ++i) result *= l;
                    return result;
                }
                default: return std::nullopt;
            }
        }
        // 可扩展对 UnaryExpr::NOT 的处理
        if (auto* u = dynamic_cast<const UnaryExpr*>(expr)) {
            if (u->op == UnaryExpr::NOT) {
                auto operand = evalConstExpr(u->operand.get());
                if (!operand) return std::nullopt;
                return (*operand == 0) ? 1 : 0;
            }
        }
        return std::nullopt;
    }
    Compiler(const Program& prog, const std::unordered_map<std::string, int>& initialGlobalMap = {})
        : prog(prog), globalVarMap(initialGlobalMap), nextGlobal((int)initialGlobalMap.size()) {}

    std::vector<Instruction> compile() {
        int idx = 0;
        for (auto& fd : prog.functions) {
            funcNameToIndex[fd->name] = idx++;
            funcParams[fd->name] = fd->params;
        }
        functionAddresses.resize(prog.functions.size(), -1);
        functionFrameSizes.resize(prog.functions.size(), 0);
        functionParamCounts.resize(prog.functions.size(), 0);

        inFunction = false;
        scopeStack.clear();
        for (auto& stmt : prog.statements) compileStmt(stmt.get());
        int jmpToHalt = code.size();
        code.push_back({OP_JMP, 0});

        for (auto& fd : prog.functions) {
            int funcIdx = funcNameToIndex[fd->name];
            functionAddresses[funcIdx] = (int)code.size();
            ScopeFrame funcScope;
            funcScope.isDeclarable = true;
            scopeStack.push_back(funcScope);
            inFunction = true;
            for (auto& p : fd->params) lookupVariable(p, true);
            compileStmt(fd->body.get());
            code.push_back({OP_PUSH, 0});
            code.push_back({OP_RET, 0});
            functionFrameSizes[funcIdx] = (int)scopeStack.back().varMap.size();
            functionParamCounts[funcIdx] = (int)fd->params.size();
            scopeStack.pop_back();
            inFunction = false;
        }

        code[jmpToHalt].operand = (int)code.size();
        code.push_back({OP_HALT, 0});
        return code;
    }

    const std::unordered_map<std::string, int>& getGlobalVarMap() const { return globalVarMap; }
    const std::vector<std::string>& getStringPool() const { return stringPool; }
    const std::vector<double>& getFloatPool() const { return floatPool; }
    const std::vector<int>& getFunctionAddresses() const { return functionAddresses; }
    const std::vector<int>& getFunctionFrameSizes() const { return functionFrameSizes; }
    const std::vector<int>& getFunctionParamCounts() const { return functionParamCounts; }

private:
    struct ScopeFrame {
        std::unordered_map<std::string, int> varMap;
        bool isDeclarable;
    };
    struct VarInfo {
        enum Kind { GLOBAL, LOCAL } kind;
        int index;
    };

    const Program& prog;
    std::vector<Instruction> code;
    std::unordered_map<std::string, int> globalVarMap;
    int nextGlobal;
    std::vector<std::string> stringPool;
    std::vector<double> floatPool;

    std::unordered_map<std::string, int> funcNameToIndex;
    std::unordered_map<std::string, std::vector<std::string>> funcParams;
    std::vector<int> functionAddresses;
    std::vector<int> functionFrameSizes;
    std::vector<int> functionParamCounts;

    std::vector<ScopeFrame> scopeStack;
    bool inFunction = false;

    struct LoopInfo {
        int startAddr, endAddr, updateAddr;
        bool isFor;
        std::vector<int> continueJumps;
        std::vector<int> breakJumps;
    };
    std::vector<LoopInfo> loopStack;

    VarInfo lookupVariable(const std::string& name, bool forAssignment = false, bool forceLocal = false) {
        if (forceLocal) {
            for (auto it = scopeStack.rbegin(); it != scopeStack.rend(); ++it) {
                if (it->isDeclarable) {
                    auto found = it->varMap.find(name);
                    if (found != it->varMap.end())
                        return {VarInfo::LOCAL, found->second};
                    int idx = (int)it->varMap.size();
                    it->varMap[name] = idx;
                    return {VarInfo::LOCAL, idx};
                }
            }
            throw std::runtime_error("Kein deklarierbarer Scope für lokale Variable");
        }
        for (auto it = scopeStack.rbegin(); it != scopeStack.rend(); ++it) {
            auto found = it->varMap.find(name);
            if (found != it->varMap.end())
                return {VarInfo::LOCAL, found->second};
        }
        auto it = globalVarMap.find(name);
        if (it != globalVarMap.end())
            return {VarInfo::GLOBAL, it->second};
        if (forAssignment) {
            for (auto it = scopeStack.rbegin(); it != scopeStack.rend(); ++it) {
                if (it->isDeclarable) {
                    int idx = (int)it->varMap.size();
                    it->varMap[name] = idx;
                    return {VarInfo::LOCAL, idx};
                }
            }
            int idx = nextGlobal++;
            globalVarMap[name] = idx;
            return {VarInfo::GLOBAL, idx};
        }
        throw std::runtime_error("Variable '" + name + "' nicht definiert");
    }

    int addString(const std::string& s) {
        for (size_t i = 0; i < stringPool.size(); ++i)
            if (stringPool[i] == s) return (int)i;
        stringPool.push_back(s);
        return (int)stringPool.size() - 1;
    }
    int addFloat(double v) {
        for (size_t i = 0; i < floatPool.size(); ++i)
            if (floatPool[i] == v) return (int)i;
        floatPool.push_back(v);
        return (int)floatPool.size() - 1;
    }

    void compileStmt(Stmt* stmt) {
        if (auto* as = dynamic_cast<AssignmentStmt*>(stmt)) {
            compileExpr(as->expr.get());
            VarInfo info = lookupVariable(as->var, true);
            if (info.kind == VarInfo::GLOBAL)
                code.push_back({OP_STORE, info.index});
            else
                code.push_back({OP_STORE_LOCAL, info.index});
        }
        else if (auto* ias = dynamic_cast<IndexAssignmentStmt*>(stmt)) {
            compileExpr(ias->expr.get());
            compileExpr(ias->index.get());
            compileExpr(ias->array.get());
            code.push_back({OP_STORE_INDEX, 0});
        }
        else if (auto* pas = dynamic_cast<PropertyAssignmentStmt*>(stmt)) {
            compileExpr(pas->expr.get());
            compileExpr(pas->object.get());
            code.push_back({OP_STORE_PROPERTY, addString(pas->key)});
        }
        else if (auto* cas = dynamic_cast<CompoundAssignStmt*>(stmt)) {
            compileCompoundAssign(cas);
        }
        else if (auto* ps = dynamic_cast<PrintStmt*>(stmt)) {
            compileExpr(ps->expr.get());
            code.push_back({OP_PRINT, 0});
        }
        else if (auto* ifs = dynamic_cast<IfStmt*>(stmt)) {
            compileIf(ifs);
        }
        else if (auto* ws = dynamic_cast<WhileStmt*>(stmt)) {
            auto constVal = evalConstExpr(ws->cond.get());
            if (constVal && *constVal == 0) {
                // 条件恒为假：循环体不生成代码（无操作）
                // 但要注意作用域，此处的 body 不编译，所以其内部变量不会分配，无影响。
            } else if (constVal && *constVal != 0) {
                // 条件恒为真：生成无限循环（无条件跳转）
                int start = code.size();
                LoopInfo info{start, 0, 0, false, {}};
                loopStack.push_back(info);
                compileStmt(ws->body.get());
                code.push_back({OP_JMP, start});
                int end = code.size();
                loopStack.back().endAddr = end;
                // 处理 break 跳转（continue 在 while 中直接跳 start，已在 ContinueStmt 处理）
                for (int pos : loopStack.back().breakJumps) code[pos].operand = end;
                loopStack.pop_back();
            } else {
                // 原有非恒等循环
                int start = code.size();
                compileExpr(ws->cond.get());
                int jz = code.size();
                code.push_back({OP_JZ, 0});
                LoopInfo info{start, 0, 0, false, {}};
                loopStack.push_back(info);
                compileStmt(ws->body.get());
                code.push_back({OP_JMP, start});
                int end = code.size();
                code[jz].operand = end;
                loopStack.back().endAddr = end;
                for (int pos : loopStack.back().breakJumps) code[pos].operand = end;
                loopStack.pop_back();
            }
        }
        else if (auto* fs = dynamic_cast<ForStmt*>(stmt)) {
            ScopeFrame loopScope;
            loopScope.isDeclarable = false;
            scopeStack.push_back(loopScope);
            VarInfo varInfo;
            if (inFunction) {
                varInfo = lookupVariable(fs->var, true, true);
                if (varInfo.kind != VarInfo::LOCAL)
                    throw std::runtime_error("Schleifenvariable muss lokal sein");
            } else {
                varInfo = lookupVariable(fs->var, true);
            }

            if (fs->isRange) {
                compileExpr(fs->start.get());
                if (varInfo.kind == VarInfo::GLOBAL)
                    code.push_back({OP_STORE, varInfo.index});
                else
                    code.push_back({OP_STORE_LOCAL, varInfo.index});
                int start = code.size();
                if (varInfo.kind == VarInfo::GLOBAL)
                    code.push_back({OP_LOAD, varInfo.index});
                else
                    code.push_back({OP_LOAD_LOCAL, varInfo.index});
                compileExpr(fs->end.get());
                code.push_back({OP_GT, 0});
                int jz = code.size();
                code.push_back({OP_JNZ, 0});
                LoopInfo info{start, 0, 0, true, {}};
                loopStack.push_back(info);
                compileStmt(fs->body.get());
                int updateAddr = code.size();
                if (varInfo.kind == VarInfo::GLOBAL)
                    code.push_back({OP_LOAD, varInfo.index});
                else
                    code.push_back({OP_LOAD_LOCAL, varInfo.index});
                code.push_back({OP_PUSH, 1});
                code.push_back({OP_ADD, 0});
                if (varInfo.kind == VarInfo::GLOBAL)
                    code.push_back({OP_STORE, varInfo.index});
                else
                    code.push_back({OP_STORE_LOCAL, varInfo.index});
                code.push_back({OP_JMP, start});
                int end = code.size();
                code[jz].operand = end;
                for (int pos : loopStack.back().continueJumps) code[pos].operand = updateAddr;
                loopStack.back().endAddr = end;
                loopStack.back().updateAddr = updateAddr;
                for (int pos : loopStack.back().breakJumps) code[pos].operand = end;
                loopStack.pop_back();
            } else {
                int handleSlot = lookupVariable("__handle", true).index;
                int indexSlot = lookupVariable("__index", true).index;
                compileExpr(fs->start.get());
                code.push_back({OP_STORE_LOCAL, handleSlot});
                code.push_back({OP_PUSH, 0});
                code.push_back({OP_STORE_LOCAL, indexSlot});
                int start = code.size();
                code.push_back({OP_LOAD_LOCAL, handleSlot});
                code.push_back({OP_ARRAY_LEN, 0});
                code.push_back({OP_LOAD_LOCAL, indexSlot});
                code.push_back({OP_LT, 0});
                int jz = code.size();
                code.push_back({OP_JZ, 0});
                code.push_back({OP_LOAD_LOCAL, handleSlot});
                code.push_back({OP_LOAD_LOCAL, indexSlot});
                code.push_back({OP_LOAD_INDEX, 0});
                code.push_back({OP_STORE_LOCAL, varInfo.index});
                LoopInfo info{start, 0, 0, true, {}};
                loopStack.push_back(info);
                compileStmt(fs->body.get());
                int updateAddr = code.size();
                code.push_back({OP_LOAD_LOCAL, indexSlot});
                code.push_back({OP_PUSH, 1});
                code.push_back({OP_ADD, 0});
                code.push_back({OP_STORE_LOCAL, indexSlot});
                code.push_back({OP_JMP, start});
                int end = code.size();
                code[jz].operand = end;
                for (int pos : loopStack.back().continueJumps) code[pos].operand = updateAddr;
                loopStack.back().endAddr = end;
                loopStack.back().updateAddr = updateAddr;
                loopStack.pop_back();
            }
            scopeStack.pop_back();
        }
        else if (auto* es = dynamic_cast<ExpressionStmt*>(stmt)) {
            compileExpr(es->expr.get());
            code.push_back({OP_POP, 0});
        }
        else if (auto* bs = dynamic_cast<BlockStmt*>(stmt)) {
            for (auto& s : bs->statements) compileStmt(s.get());
        }
        else if (dynamic_cast<ContinueStmt*>(stmt)) {
            if (loopStack.empty()) throw std::runtime_error("continue außerhalb");
            if (loopStack.back().isFor) {
                int pos = code.size();
                code.push_back({OP_JMP, 0});
                loopStack.back().continueJumps.push_back(pos);
            } else {
                code.push_back({OP_JMP, loopStack.back().startAddr});
            }
        }
        else if (dynamic_cast<BreakStmt*>(stmt)) {
            if (loopStack.empty()) throw std::runtime_error("break außerhalb");
            int pos = code.size();
            code.push_back({OP_JMP, 0});  // 占位
            loopStack.back().breakJumps.push_back(pos);
        }
        else if (auto* rs = dynamic_cast<ReturnStmt*>(stmt)) {
            if (!inFunction) {
                throw std::runtime_error("return außerhalb einer Funktion");
            }
            if (rs->expr) {
                compileExpr(rs->expr.get());
            } else {
                code.push_back({OP_PUSH, 0});  // 空返回默认值 0
            }
            code.push_back({OP_RET, 0});
        }
        else {
            throw std::runtime_error("Unbekannte Anweisung");
        }
    }

    void compileCompoundAssign(CompoundAssignStmt* cas) {
        auto& left = cas->left;
        auto& right = cas->right;
        if (auto* var = dynamic_cast<VariableExpr*>(left.get())) {
            VarInfo info = lookupVariable(var->name, true);
            if (info.kind == VarInfo::GLOBAL)
                code.push_back({OP_LOAD, info.index});
            else
                code.push_back({OP_LOAD_LOCAL, info.index});
            compileExpr(right.get());
            emitBinaryOpForAssign(cas->op);
            if (info.kind == VarInfo::GLOBAL)
                code.push_back({OP_STORE, info.index});
            else
                code.push_back({OP_STORE_LOCAL, info.index});
        }
        else if (auto* idx = dynamic_cast<IndexExpr*>(left.get())) {
            int hVar = lookupVariable("__h", true).index;
            int iVar = lookupVariable("__i", true).index;
            compileExpr(idx->array.get());
            code.push_back({OP_STORE_LOCAL, hVar});
            compileExpr(idx->index.get());
            code.push_back({OP_STORE_LOCAL, iVar});
            code.push_back({OP_LOAD_LOCAL, hVar});
            code.push_back({OP_LOAD_LOCAL, iVar});
            code.push_back({OP_LOAD_INDEX, 0});
            compileExpr(right.get());
            emitBinaryOpForAssign(cas->op);
            code.push_back({OP_LOAD_LOCAL, hVar});
            code.push_back({OP_LOAD_LOCAL, iVar});
            code.push_back({OP_STORE_INDEX, 0});
        }
        else if (auto* prop = dynamic_cast<PropertyAccessExpr*>(left.get())) {
            int oVar = lookupVariable("__obj", true).index;
            compileExpr(prop->object.get());
            code.push_back({OP_STORE_LOCAL, oVar});
            code.push_back({OP_LOAD_LOCAL, oVar});
            int keyIdx = addString(prop->key);
            code.push_back({OP_LOAD_PROPERTY, keyIdx});
            compileExpr(right.get());
            emitBinaryOpForAssign(cas->op);
            code.push_back({OP_LOAD_LOCAL, oVar});
            code.push_back({OP_STORE_PROPERTY, keyIdx});
        } else {
            throw std::runtime_error("Komplexe linke Seite in Compound-Assign nicht unterstützt");
        }
    }

    void emitBinaryOpForAssign(TokenTypes op) {
        switch (op) {
            case TokenTypes::ASSIGN_ADD: code.push_back({OP_ADD, 0}); break;
            case TokenTypes::ASSIGN_SUB: code.push_back({OP_SUB, 0}); break;
            case TokenTypes::ASSIGN_MUL: code.push_back({OP_MUL, 0}); break;
            case TokenTypes::ASSIGN_DIV: code.push_back({OP_DIV, 0}); break;
            case TokenTypes::ASSIGN_MOD: code.push_back({OP_MOD, 0}); break;
            case TokenTypes::ASSIGN_EXP: code.push_back({OP_EXP, 0}); break;
            default: throw std::runtime_error("Unbekannter Compound-Assign-Operator");
        }
    }

    void compileIf(IfStmt* ifs) {
        compileExpr(ifs->cond.get());
        int elseLabel = code.size();
        code.push_back({OP_JZ, 0});
        compileStmt(ifs->thenBody.get());
        int endLabel = code.size();
        code.push_back({OP_JMP, 0});
        std::vector<int> jumpLabels;
        for (auto& ei : ifs->elseIfs) {
            code[elseLabel].operand = code.size();
            compileExpr(ei.cond.get());
            elseLabel = code.size();
            code.push_back({OP_JZ, 0});
            compileStmt(ei.body.get());
            int jmp = code.size();
            code.push_back({OP_JMP, 0});
            jumpLabels.push_back(jmp);
        }
        if (ifs->elseBody) {
            code[elseLabel].operand = code.size();
            compileStmt(ifs->elseBody.get());
            int endAddr = code.size();
            for (int addr : jumpLabels) code[addr].operand = endAddr;
            code[endLabel].operand = endAddr;
        } else {
            int endAddr = code.size();
            code[elseLabel].operand = endAddr;
            for (int addr : jumpLabels) code[addr].operand = endAddr;
            code[endLabel].operand = endAddr;
        }
    }

    void compileExpr(Expr* expr) {
        if (auto* n = dynamic_cast<NumberExpr*>(expr)) {
            double v = n->value;
            if (v == (int)v) code.push_back({OP_PUSH, (int)v});
            else code.push_back({OP_PUSH_FLOAT, addFloat(v)});
        }
        else if (auto* v = dynamic_cast<VariableExpr*>(expr)) {
            VarInfo info = lookupVariable(v->name, false);
            if (info.kind == VarInfo::GLOBAL)
                code.push_back({OP_LOAD, info.index});
            else
                code.push_back({OP_LOAD_LOCAL, info.index});
        }
        else if (auto* b = dynamic_cast<BinaryExpr*>(expr)) {
            if (b->op == BinaryExpr::AND) {
                compileExpr(b->left.get());
                int falseLabel = code.size();
                code.push_back({OP_JZ, 0});        // 左为假 → falseLabel
                compileExpr(b->right.get());
                int falseLabel2 = code.size();
                code.push_back({OP_JZ, 0});        // 右为假 → falseLabel2
                // 左右都为真
                code.push_back({OP_PUSH, 1});
                int end = code.size();
                code.push_back({OP_JMP, 0});
            
                // 左为假分支
                code[falseLabel].operand = code.size();
                code.push_back({OP_PUSH, 0});
                int end2 = code.size();
                code.push_back({OP_JMP, 0});
            
                // 右为假分支（左已为真，仅右假）
                code[falseLabel2].operand = code.size();
                code.push_back({OP_PUSH, 0});
                int end3 = code.size();
                code.push_back({OP_JMP, 0});
            
                // 统一合并
                int finalEnd = code.size();
                code[end].operand = finalEnd;
                code[end2].operand = finalEnd;
                code[end3].operand = finalEnd;
            } else if (b->op == BinaryExpr::OR) {
                compileExpr(b->left.get());
                int trueLabel = code.size();
                code.push_back({OP_JNZ, 0});       // 左为真 → trueLabel
                compileExpr(b->right.get());
                int trueLabel2 = code.size();
                code.push_back({OP_JNZ, 0});       // 右为真 → trueLabel2
                // 左右都为假
                code.push_back({OP_PUSH, 0});
                int end = code.size();
                code.push_back({OP_JMP, 0});
            
                // 左为真分支
                code[trueLabel].operand = code.size();
                code.push_back({OP_PUSH, 1});
                int end2 = code.size();
                code.push_back({OP_JMP, 0});
            
                // 右为真分支（左已为假，仅右真）
                code[trueLabel2].operand = code.size();
                code.push_back({OP_PUSH, 1});
                int end3 = code.size();
                code.push_back({OP_JMP, 0});
            
                int finalEnd = code.size();
                code[end].operand = finalEnd;
                code[end2].operand = finalEnd;
                code[end3].operand = finalEnd;
            } else {
                // 非逻辑运算符：正常编译左右并执行操作
                compileExpr(b->left.get());
                compileExpr(b->right.get());
                OpCode op;
                switch (b->op) {
                    case BinaryExpr::ADD: op = OP_ADD; break;
                    case BinaryExpr::SUB: op = OP_SUB; break;
                    case BinaryExpr::MUL: op = OP_MUL; break;
                    case BinaryExpr::DIV: op = OP_DIV; break;
                    case BinaryExpr::LT:  op = OP_LT; break;
                    case BinaryExpr::GT:  op = OP_GT; break;
                    case BinaryExpr::EQ:  op = OP_EQ; break;
                    case BinaryExpr::MOD: op = OP_MOD; break;
                    case BinaryExpr::EXP: op = OP_EXP; break;
                    case BinaryExpr::LE:  op = OP_LE; break;
                    case BinaryExpr::GE:  op = OP_GE; break;
                    case BinaryExpr::NE:  op = OP_NE; break;
                    default: throw std::runtime_error("Unbekannter binärer Operator");
                }
                code.push_back({op, 0});
            }
        }
        else if (auto* u = dynamic_cast<UnaryExpr*>(expr)) {
            compileExpr(u->operand.get());
            code.push_back({OP_NOT, 0});
        }
        else if (auto* c = dynamic_cast<ConditionalExpr*>(expr)) {
            compileExpr(c->cond.get());
            int elseL = code.size();
            code.push_back({OP_JZ, 0});
            compileExpr(c->thenExpr.get());
            int endL = code.size();
            code.push_back({OP_JMP, 0});
            code[elseL].operand = code.size();
            compileExpr(c->elseExpr.get());
            code[endL].operand = code.size();
        }
        else if (auto* arr = dynamic_cast<ArrayLiteralExpr*>(expr)) {
            for (auto& e : arr->elements) compileExpr(e.get());
            code.push_back({OP_ARRAY_LITERAL, (int)arr->elements.size()});
        }
        else if (auto* idx = dynamic_cast<IndexExpr*>(expr)) {
            compileExpr(idx->array.get());
            compileExpr(idx->index.get());
            code.push_back({OP_LOAD_INDEX, 0});
        }
        else if (auto* r = dynamic_cast<RangeExpr*>(expr)) {
            compileExpr(r->left.get());
            compileExpr(r->right.get());
            code.push_back({OP_NEW_ARRAY, 0});
        }
        else if (auto* ol = dynamic_cast<ObjectLiteralExpr*>(expr)) {
            for (auto& f : ol->fields) code.push_back({OP_PUSH_STRING, addString(f.first)});
            for (auto& f : ol->fields) compileExpr(f.second.get());
            code.push_back({OP_NEW_OBJECT, (int)ol->fields.size()});
        }
        else if (auto* pa = dynamic_cast<PropertyAccessExpr*>(expr)) {
            compileExpr(pa->object.get());
            code.push_back({OP_LOAD_PROPERTY, addString(pa->key)});
        }
        else if (auto* fc = dynamic_cast<FunctionCallExpr*>(expr)) {
            auto it = funcNameToIndex.find(fc->funcName);
            if (it != funcNameToIndex.end()) {
                auto& params = funcParams[fc->funcName];
                if (params.size() != fc->args.size())
                    throw std::runtime_error("Falsche Anzahl Argumente für " + fc->funcName);
                for (auto& arg : fc->args) compileExpr(arg.get());
                code.push_back({OP_CALL, it->second});
            } else {
                for (auto& arg : fc->args) compileExpr(arg.get());
                code.push_back({OP_PUSH_STRING, addString(fc->funcName)});
                code.push_back({OP_CALL_EXTERNAL, (int)fc->args.size()});
            }
        }
        else if (auto* sle = dynamic_cast<StringLiteralExpr*>(expr)) {
            const auto& parts = sle->parts;
            if (parts.empty()) {
                code.push_back({OP_PUSH_STRING, addString("")});
                return;
            }
            if (parts.size() == 1) {
                code.push_back({OP_PUSH_STRING, addString(parts[0])});
                return;
            }
            for (size_t i = 0; i < parts.size(); ++i) {
                if (i % 2 == 0) {
                    code.push_back({OP_PUSH_STRING, addString(parts[i])});
                } else {
                    VarInfo info = lookupVariable(parts[i], false);
                    if (info.kind == VarInfo::GLOBAL)
                        code.push_back({OP_LOAD, info.index});
                    else
                        code.push_back({OP_LOAD_LOCAL, info.index});
                    code.push_back({OP_ITOS, 0});
                }
                if (i > 0) code.push_back({OP_CONCAT, 0});
            }
        }
        else {
            throw std::runtime_error("Unbekannter Ausdruck");
        }
    }
};

// ---------- 虚拟机 ----------
class VM {
public:
    const std::vector<std::string>& getStringPool() const { return string_heap; }
    const std::vector<std::vector<Value>>& getArrays() const { return arrays; }
    const std::vector<std::unordered_map<std::string, Value>>& getObjects() const { return objects; }

    VM(const std::vector<Instruction>& bytecode, const std::vector<Value>& initialMemory = {})
        : bytecode(bytecode), pc(0), memory(initialMemory) {
        if (memory.empty()) memory.resize(1024, Value(0));
        stack.reserve(1024);
        frames.reserve(64);
    }

    void setStringPool(const std::vector<std::string>& pool) { string_heap = pool; }
    void setFloatPool(const std::vector<double>& pool) { float_pool = pool; }
    void setFunctionAddresses(const std::vector<int>& addresses) {
        functionAddresses.resize(addresses.size());
        for (size_t i = 0; i < addresses.size(); ++i) {
            if (addresses[i] == -1)
                throw std::runtime_error("Funktionsadresse nicht gesetzt");
            functionAddresses[i] = (size_t)addresses[i];
        }
    }
    void setFunctionFrameSizes(const std::vector<int>& sizes) { functionFrameSizes = sizes; }
    void setFunctionParamCounts(const std::vector<int>& counts) { functionParamCounts = counts; }
    void setArrays(const std::vector<std::vector<Value>>& arrs) { arrays = arrs; }
    void setObjects(const std::vector<std::unordered_map<std::string, Value>>& objs) { objects = objs; }

    void run() {
        while (pc < bytecode.size()) {
            Instruction inst = bytecode[pc++];
            switch (inst.op) {
                case OP_PUSH: push(Value(inst.operand)); break;
                case OP_PUSH_FLOAT: {
                    int idx = inst.operand;
                    if (idx < 0 || idx >= (int)float_pool.size())
                        throw std::runtime_error("Ungültiger Float-Index");
                    push(Value(float_pool[idx]));
                    break;
                }
                case OP_LOAD: {
                    int idx = inst.operand;
                    if (idx >= (int)memory.size())
                        throw std::runtime_error("Speicherzugriff außerhalb");
                    push(memory[idx]);
                    break;
                }
                case OP_STORE: {
                    Value val = pop();
                    int idx = inst.operand;
                    if (idx >= (int)memory.size()) memory.resize(idx + 1);
                    memory[idx] = val;
                    break;
                }
                case OP_LOAD_LOCAL: {
                    int idx = inst.operand;
                    if (frames.empty()) throw std::runtime_error("Kein aktiver Frame");
                    if (idx >= (int)frames.back().locals.size())
                        throw std::runtime_error("Lokaler Index außerhalb");
                    push(frames.back().locals[idx]);
                    break;
                }
                case OP_STORE_LOCAL: {
                    Value val = pop();
                    int idx = inst.operand;
                    if (frames.empty()) throw std::runtime_error("Kein aktiver Frame");
                    if (idx >= (int)frames.back().locals.size())
                        frames.back().locals.resize(idx + 1);
                    frames.back().locals[idx] = val;
                    break;
                }
                case OP_ADD: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("ADD erwartet Zahlen");
                    if (a.isFloat() || b.isFloat())
                        push(Value(a.asDouble() + b.asDouble()));
                    else
                        push(Value(a.int_val + b.int_val));
                    break;
                }
                case OP_SUB: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("SUB erwartet Zahlen");
                    if (a.isFloat() || b.isFloat())
                        push(Value(a.asDouble() - b.asDouble()));
                    else
                        push(Value(a.int_val - b.int_val));
                    break;
                }
                case OP_MUL: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("MUL erwartet Zahlen");
                    if (a.isFloat() || b.isFloat())
                        push(Value(a.asDouble() * b.asDouble()));
                    else
                        push(Value(a.int_val * b.int_val));
                    break;
                }
                case OP_DIV: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("DIV erwartet Zahlen");
                    double denom = b.asDouble();
                    if (denom == 0.0) throw std::runtime_error("Division durch Null");
                    if (a.isFloat() || b.isFloat())
                        push(Value(a.asDouble() / denom));
                    else
                        push(Value(a.int_val / b.int_val));
                    break;
                }
                case OP_MOD: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("MOD erwartet Zahlen");
                    double denom = b.asDouble();
                    if (denom == 0.0) throw std::runtime_error("Division durch Null (Modulo)");
                    if (a.isInt() && b.isInt())
                        push(Value(a.int_val % b.int_val));
                    else
                        push(Value(std::fmod(a.asDouble(), denom)));
                    break;
                }
                case OP_EXP: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("EXP erwartet Zahlen");
                    double base = a.asDouble(), exp = b.asDouble();
                    if (a.isInt() && b.isInt() && exp >= 0) {
                        int result = 1;
                        for (int i = 0; i < (int)exp; ++i) result *= (int)base;
                        push(Value(result));
                    } else {
                        push(Value(std::pow(base, exp)));
                    }
                    break;
                }
                case OP_LT: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("LT erwartet Zahlen");
                    push(Value(a.asDouble() < b.asDouble() ? 1 : 0));
                    break;
                }
                case OP_GT: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("GT erwartet Zahlen");
                    push(Value(a.asDouble() > b.asDouble() ? 1 : 0));
                    break;
                }
                case OP_LE: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("LE erwartet Zahlen");
                    push(Value(a.asDouble() <= b.asDouble() ? 1 : 0));
                    break;
                }
                case OP_GE: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("GE erwartet Zahlen");
                    push(Value(a.asDouble() >= b.asDouble() ? 1 : 0));
                    break;
                }
                case OP_EQ: {
                    Value b = pop(), a = pop();
                    if (a.type != b.type) push(Value(0));
                    else if (a.isInt()) push(Value(a.int_val == b.int_val ? 1 : 0));
                    else if (a.isFloat()) push(Value(a.float_val == b.float_val ? 1 : 0));
                    else if (a.isString()) {
                        int ha = a.string_handle, hb = b.string_handle;
                        if (ha < 0 || ha >= (int)string_heap.size() || hb < 0 || hb >= (int)string_heap.size())
                            throw std::runtime_error("Ungültiger String-Handle");
                        push(Value(string_heap[ha] == string_heap[hb] ? 1 : 0));
                    } else push(Value(0));
                    break;
                }
                case OP_NE: {
                    Value b = pop(), a = pop();
                    if (a.type != b.type) push(Value(1));
                    else if (a.isInt()) push(Value(a.int_val != b.int_val ? 1 : 0));
                    else if (a.isFloat()) push(Value(a.float_val != b.float_val ? 1 : 0));
                    else if (a.isString()) {
                        int ha = a.string_handle, hb = b.string_handle;
                        if (ha < 0 || ha >= (int)string_heap.size() || hb < 0 || hb >= (int)string_heap.size())
                            throw std::runtime_error("Ungültiger String-Handle");
                        push(Value(string_heap[ha] != string_heap[hb] ? 1 : 0));
                    } else push(Value(1));
                    break;
                }
                case OP_JMP: pc = inst.operand; break;
                case OP_JZ: {
                    Value v = pop();
                    if (!v.isNumber()) throw std::runtime_error("JZ erwartet eine Zahl");
                    if (v.asDouble() == 0.0) pc = inst.operand;
                    break;
                }
                case OP_JNZ: {
                    Value v = pop();
                    if (!v.isNumber()) throw std::runtime_error("JNZ erwartet eine Zahl");
                    if (v.asDouble() != 0.0) pc = inst.operand;
                    break;
                }
                case OP_AND: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("AND erwartet Zahlen");
                    push(Value((a.asDouble() != 0.0 && b.asDouble() != 0.0) ? 1 : 0));
                    break;
                }
                case OP_OR: {
                    Value b = pop(), a = pop();
                    if (!a.isNumber() || !b.isNumber()) throw std::runtime_error("OR erwartet Zahlen");
                    push(Value((a.asDouble() != 0.0 || b.asDouble() != 0.0) ? 1 : 0));
                    break;
                }
                case OP_NOT: {
                    Value a = pop();
                    if (!a.isNumber()) throw std::runtime_error("NOT erwartet eine Zahl");
                    push(Value(a.asDouble() == 0.0 ? 1 : 0));
                    break;
                }
                case OP_PRINT: {
                    Value v = pop();
                    if (v.isInt()) std::cout << v.int_val << std::endl;
                    else if (v.isFloat()) std::cout << v.float_val << std::endl;
                    else if (v.isString()) {
                        int h = v.string_handle;
                        if (h < 0 || h >= (int)string_heap.size())
                            throw std::runtime_error("Ungültiger String-Handle");
                        std::cout << string_heap[h] << std::endl;
                    } else {
                        std::cout << "(zeigen: nicht darstellbarer Typ)" << std::endl;
                    }
                    break;
                }
                case OP_HALT: return;
                case OP_POP: pop(); break;
                case OP_NEW_ARRAY: {
                    if (inst.operand == 0) {
                        Value end = pop(), start = pop();
                        if (!start.isNumber() || !end.isNumber())
                            throw std::runtime_error("Bereichs-Endpunkte müssen Zahlen sein");
                        int s = (int)start.asDouble(), e = (int)end.asDouble();
                        std::vector<Value> arr;
                        if (s <= e) for (int i = s; i <= e; ++i) arr.push_back(Value(i));
                        else for (int i = s; i >= e; --i) arr.push_back(Value(i));
                        int handle = arrays.size();
                        arrays.push_back(std::move(arr));
                        push(Value(handle, Value::T_ARRAY));
                    } else {
                        std::vector<Value> arr;
                        for (int i = 0; i < inst.operand; ++i) arr.push_back(pop());
                        std::reverse(arr.begin(), arr.end());
                        int handle = arrays.size();
                        arrays.push_back(std::move(arr));
                        push(Value(handle, Value::T_ARRAY));
                    }
                    break;
                }
                case OP_ARRAY_LITERAL: {
                    std::vector<Value> arr;
                    for (int i = 0; i < inst.operand; ++i) arr.push_back(pop());
                    std::reverse(arr.begin(), arr.end());
                    int handle = arrays.size();
                    arrays.push_back(std::move(arr));
                    push(Value(handle, Value::T_ARRAY));
                    break;
                }
                case OP_LOAD_INDEX: {
                    Value index = pop(), handleVal = pop();
                    if (!handleVal.isArray()) throw std::runtime_error("Kein Array-Handle");
                    if (!index.isNumber()) throw std::runtime_error("Index muss eine Zahl sein");
                    int idx = (int)index.asDouble();
                    int h = handleVal.array_handle;
                    if (h < 0 || h >= (int)arrays.size())
                        throw std::runtime_error("Ungültiger Array-Handle");
                    if (idx < 0 || idx >= (int)arrays[h].size())
                        throw std::runtime_error("Index außerhalb");
                    push(arrays[h][idx]);
                    break;
                }
                case OP_STORE_INDEX: {
                    Value val = pop(), index = pop(), handleVal = pop();
                    if (!handleVal.isArray()) throw std::runtime_error("Kein Array-Handle");
                    if (!index.isNumber()) throw std::runtime_error("Index muss eine Zahl sein");
                    int idx = (int)index.asDouble();
                    int h = handleVal.array_handle;
                    if (h < 0 || h >= (int)arrays.size())
                        throw std::runtime_error("Ungültiger Array-Handle");
                    if (idx < 0 || idx >= (int)arrays[h].size())
                        throw std::runtime_error("Index außerhalb");
                    arrays[h][idx] = val;
                    break;
                }
                case OP_ARRAY_LEN: {
                    Value handleVal = pop();
                    if (!handleVal.isArray()) throw std::runtime_error("Kein Array-Handle");
                    int h = handleVal.array_handle;
                    if (h < 0 || h >= (int)arrays.size())
                        throw std::runtime_error("Ungültiger Array-Handle");
                    push(Value((int)arrays[h].size()));
                    break;
                }
                case OP_PUSH_STRING: {
                    int idx = inst.operand;
                    if (idx < 0 || idx >= (int)string_heap.size())
                        throw std::runtime_error("Ungültiger String-Index");
                    push(Value(idx, Value::T_STRING));
                    break;
                }
                case OP_NEW_OBJECT: {
                    int n = inst.operand;
                    std::vector<Value> vals, keys;
                    for (int i = 0; i < n; ++i) vals.push_back(pop());
                    for (int i = 0; i < n; ++i) keys.push_back(pop());
                    std::reverse(vals.begin(), vals.end());
                    std::reverse(keys.begin(), keys.end());
                    std::unordered_map<std::string, Value> obj;
                    for (int i = 0; i < n; ++i) {
                        if (!keys[i].isString())
                            throw std::runtime_error("Objektschlüssel muss String sein");
                        const std::string& key = string_heap[keys[i].string_handle];
                        obj[key] = vals[i];
                    }
                    int handle = objects.size();
                    objects.push_back(std::move(obj));
                    push(Value(handle, Value::T_OBJECT));
                    break;
                }
                case OP_LOAD_PROPERTY: {
                    int keyIdx = inst.operand;
                    Value objVal = pop();
                    if (!objVal.isObject()) throw std::runtime_error("Objekt erwartet");
                    int h = objVal.object_handle;
                    if (h < 0 || h >= (int)objects.size())
                        throw std::runtime_error("Ungültiger Objekt-Handle");
                    const auto& obj = objects[h];
                    const std::string& key = string_heap[keyIdx];
                    auto it = obj.find(key);
                    if (it == obj.end())
                        throw std::runtime_error("Attribut '" + key + "' nicht vorhanden");
                    push(it->second);
                    break;
                }
                case OP_STORE_PROPERTY: {
                    int keyIdx = inst.operand;
                    Value val = pop(), objVal = pop();
                    if (!objVal.isObject()) throw std::runtime_error("Objekt erwartet");
                    int h = objVal.object_handle;
                    if (h < 0 || h >= (int)objects.size())
                        throw std::runtime_error("Ungültiger Objekt-Handle");
                    objects[h][string_heap[keyIdx]] = val;
                    break;
                }
                case OP_CALL_EXTERNAL: {
                    int argCount = inst.operand;
                    int nameIdx = pop().int_val;
                    std::string funcName = string_heap[nameIdx];
                    std::vector<int> args;
                    for (int i = 0; i < argCount; ++i) {
                        Value v = pop();
                        if (!v.isInt()) throw std::runtime_error("Externe Aufrufe unterstützen derzeit nur Integer-Argumente");
                        args.push_back(v.int_val);
                    }
                    std::reverse(args.begin(), args.end());
                    std::string argsJson = "[";
                    for (size_t i = 0; i < args.size(); ++i) {
                        if (i) argsJson += ",";
                        argsJson += std::to_string(args[i]);
                    }
                    argsJson += "]";
                    if (!g_external_call) throw std::runtime_error("Externer Callback nicht gesetzt");
                    std::string resultJson = g_external_call(funcName, argsJson);
                    int resultInt = 0;
                    size_t pos = resultJson.find_first_of("-0123456789");
                    if (pos != std::string::npos) {
                        size_t end = pos + 1;
                        while (end < resultJson.size() && (isdigit(resultJson[end]) || resultJson[end] == '.')) ++end;
                        std::string numStr = resultJson.substr(pos, end - pos);
                        size_t dot = numStr.find('.');
                        if (dot != std::string::npos) numStr = numStr.substr(0, dot);
                        if (!numStr.empty()) resultInt = std::stoi(numStr);
                    }
                    push(Value(resultInt));
                    break;
                }
                case OP_ITOS: {
                    Value v = pop();
                    std::string s;
                    if (v.isInt()) s = std::to_string(v.int_val);
                    else if (v.isFloat()) {
                        s = std::to_string(v.float_val);
                        s.erase(s.find_last_not_of('0') + 1, std::string::npos);
                        if (s.back() == '.') s.pop_back();
                    } else throw std::runtime_error("ITOS erwartet Zahl");
                    int idx = string_heap.size();
                    string_heap.push_back(s);
                    push(Value(idx, Value::T_STRING));
                    break;
                }
                case OP_CONCAT: {
                    Value b = pop(), a = pop();
                    if (!a.isString() || !b.isString())
                        throw std::runtime_error("CONCAT erwartet zwei Strings");
                    int ha = a.string_handle, hb = b.string_handle;
                    if (ha < 0 || ha >= (int)string_heap.size() || hb < 0 || hb >= (int)string_heap.size())
                        throw std::runtime_error("Ungültiger String-Handle");
                    std::string res = string_heap[ha] + string_heap[hb];
                    int idx = string_heap.size();
                    string_heap.push_back(res);
                    push(Value(idx, Value::T_STRING));
                    break;
                }
                case OP_CALL: {
                    int funcIdx = inst.operand;
                    if (funcIdx < 0 || funcIdx >= (int)functionAddresses.size())
                        throw std::runtime_error("Ungültiger Funktionsindex");
                    size_t target = functionAddresses[funcIdx];
                    int paramCount = functionParamCounts[funcIdx];
                    int frameSize = functionFrameSizes[funcIdx];
                    std::vector<Value> args(paramCount);
                    for (int i = paramCount - 1; i >= 0; --i) {
                        if (stack.empty()) throw std::runtime_error("Nicht genug Argumente");
                        args[i] = pop();
                    }
                    Frame newFrame;
                    newFrame.locals.resize(frameSize);
                    for (int i = 0; i < paramCount; ++i) newFrame.locals[i] = args[i];
                    newFrame.returnAddress = pc;
                    frames.push_back(std::move(newFrame));
                    pc = target;
                    break;
                }
                case OP_RET: {
                    if (frames.empty()) {
                        throw std::runtime_error("Return ohne aktiven Frame");
                    }
                    // 弹出返回值（假设栈顶是返回值）
                    Value retVal = pop();
                    // 恢复调用者的返回地址
                    pc = frames.back().returnAddress;
                    frames.pop_back();
                    // 将返回值压回调用者的栈
                    push(retVal);
                    break;
                }
                default:
                    throw std::runtime_error("Unbekannter Opcode");
            }
        }
    }

    const std::vector<Value>& getMemory() const { return memory; }

private:
    struct Frame {
        std::vector<Value> locals;
        size_t returnAddress;
    };

    std::vector<Value> stack;
    inline void push(const Value& v) { stack.push_back(v); }
    inline Value pop() { Value v = stack.back(); stack.pop_back(); return v; }

    const std::vector<Instruction>& bytecode;
    size_t pc;
    std::vector<Value> memory;
    std::vector<std::vector<Value>> arrays;
    std::vector<std::unordered_map<std::string, Value>> objects;
    std::vector<std::string> string_heap;
    std::vector<double> float_pool;

    std::vector<size_t> functionAddresses;
    std::vector<int> functionFrameSizes;
    std::vector<int> functionParamCounts;
    std::vector<Frame> frames;
};

} // namespace vw

// =========================== 导出接口 ===========================
extern thread_local int g_last_error_line;
extern thread_local int g_last_error_col;
[[noreturn]] void kr_error(const char* format, ...);

// 序列化函数（使用 vw::Value）
static std::string serialize_value(const vw::Value& v, const vw::VM& vm) {
    switch (v.type) {
        case vw::Value::T_INT:
            return std::to_string(v.int_val);
        case vw::Value::T_FLOAT: {
            std::string s = std::to_string(v.float_val);
            s.erase(s.find_last_not_of('0') + 1, std::string::npos);
            if (s.back() == '.') s.pop_back();
            return s;
        }
        case vw::Value::T_STRING: {
            int h = v.string_handle;
            const auto& pool = vm.getStringPool();
            std::string s = pool[h];
            std::string escaped;
            for (char c : s) {
                if (c == '"') escaped += "\\\"";
                else if (c == '\\') escaped += "\\\\";
                else if (c == '\n') escaped += "\\n";
                else if (c == '\r') escaped += "\\r";
                else if (c == '\t') escaped += "\\t";
                else escaped += c;
            }
            return "\"" + escaped + "\"";
        }
        case vw::Value::T_ARRAY: {
            int h = v.array_handle;
            const auto& arrays = vm.getArrays();
            if (h < 0 || h >= (int)arrays.size()) return "null";
            const auto& arr = arrays[h];
            std::string json = "[";
            for (size_t i = 0; i < arr.size(); ++i) {
                if (i > 0) json += ",";
                json += serialize_value(arr[i], vm);
            }
            json += "]";
            return json;
        }
        case vw::Value::T_OBJECT: {
            int h = v.object_handle;
            const auto& objects = vm.getObjects();
            if (h < 0 || h >= (int)objects.size()) return "null";
            const auto& obj = objects[h];
            std::string json = "{";
            bool first = true;
            for (const auto& pair : obj) {
                if (!first) json += ",";
                first = false;
                std::string key = pair.first;
                std::string escaped_key;
                for (char c : key) {
                    if (c == '"') escaped_key += "\\\"";
                    else if (c == '\\') escaped_key += "\\\\";
                    else if (c == '\n') escaped_key += "\\n";
                    else if (c == '\r') escaped_key += "\\r";
                    else if (c == '\t') escaped_key += "\\t";
                    else escaped_key += c;
                }
                json += "\"" + escaped_key + "\":" + serialize_value(pair.second, vm);
            }
            json += "}";
            return json;
        }
        default:
            return "null";
    }
}

// 主执行函数
std::string execute_vw(const std::string& code, const std::string& context_json,
                        int start_line, int start_col, const char* filename,
                        std::function<std::string(const std::string&, const std::string&)> external_call) {
    g_external_call = external_call;

    // -------- 内嵌 JSON 解析器（仅支持标准 JSON 格式）--------
    struct JSONValue {
        enum Type { NULL_, BOOL, NUMBER, STRING, ARRAY, OBJECT };
        Type type;
        std::optional<bool> bool_val;
        std::optional<double> number_val;
        std::optional<std::string> string_val;
        std::optional<std::vector<JSONValue>> array_val;
        std::optional<std::unordered_map<std::string, JSONValue>> object_val;
    };

    // 解析函数
    std::function<JSONValue(const std::string&, size_t&)> parse_json;
    parse_json = [&](const std::string& s, size_t& pos) -> JSONValue {
        // 跳过空白
        while (pos < s.size() && isspace(s[pos])) ++pos;
        if (pos >= s.size()) throw std::runtime_error("Unexpected EOF");

        char c = s[pos];
        if (c == 'n') {
            if (s.compare(pos, 4, "null") == 0) { pos += 4; return {JSONValue::NULL_, {}}; }
            throw std::runtime_error("Expected null");
        }
        if (c == 't') {
            if (s.compare(pos, 4, "true") == 0) { pos += 4; return {JSONValue::BOOL, true}; }
            throw std::runtime_error("Expected true");
        }
        if (c == 'f') {
            if (s.compare(pos, 5, "false") == 0) { pos += 5; return {JSONValue::BOOL, false}; }
            throw std::runtime_error("Expected false");
        }
        if (c == '"') {
            ++pos;
            std::string str;
            while (pos < s.size() && s[pos] != '"') {
                if (s[pos] == '\\' && pos + 1 < s.size()) {
                    char esc = s[++pos];
                    switch (esc) {
                        case '"':  str += '"'; break;
                        case '\\': str += '\\'; break;
                        case '/':  str += '/'; break;
                        case 'b':  str += '\b'; break;
                        case 'f':  str += '\f'; break;
                        case 'n':  str += '\n'; break;
                        case 'r':  str += '\r'; break;
                        case 't':  str += '\t'; break;
                        default:   str += esc; break;
                    }
                } else {
                    str += s[pos];
                }
                ++pos;
            }
            if (pos >= s.size() || s[pos] != '"') throw std::runtime_error("Unterminated string");
            ++pos;
            return {JSONValue::STRING, std::nullopt, std::nullopt, str};
        }
        if (c == '-' || isdigit(c)) {
            size_t start = pos;
            if (c == '-') ++pos;
            while (pos < s.size() && isdigit(s[pos])) ++pos;
            if (pos < s.size() && s[pos] == '.') {
                ++pos;
                while (pos < s.size() && isdigit(s[pos])) ++pos;
            }
            if (pos < s.size() && (s[pos] == 'e' || s[pos] == 'E')) {
                ++pos;
                if (pos < s.size() && (s[pos] == '+' || s[pos] == '-')) ++pos;
                while (pos < s.size() && isdigit(s[pos])) ++pos;
            }
            std::string num = s.substr(start, pos - start);
            // 使用 strtod 进行转换，支持科学计数法，且不会抛出异常
            char* endptr;
            errno = 0;
            double val = strtod(num.c_str(), &endptr);
            if (endptr == num.c_str() || errno == ERANGE) {
                // 如果转换失败，返回 0 或抛出异常（这里选择抛出自定义异常）
                throw std::runtime_error("JSON: ungültige Zahl: " + num);
            }
            return {JSONValue::NUMBER, std::nullopt, val};
        }
        if (c == '[') {
            ++pos;
            std::vector<JSONValue> arr;
            while (pos < s.size()) {
                while (isspace(s[pos])) ++pos;
                if (s[pos] == ']') { ++pos; break; }
                arr.push_back(parse_json(s, pos));
                while (pos < s.size() && isspace(s[pos])) ++pos;
                if (s[pos] == ',') { ++pos; continue; }
                if (s[pos] == ']') { ++pos; break; }
                throw std::runtime_error("Expected ',' or ']'");
            }
            return {JSONValue::ARRAY, std::nullopt, std::nullopt, std::nullopt, arr};
        }
        if (c == '{') {
            ++pos;
            std::unordered_map<std::string, JSONValue> obj;
            while (pos < s.size()) {
                while (isspace(s[pos])) ++pos;
                if (s[pos] == '}') { ++pos; break; }
                JSONValue key = parse_json(s, pos);
                if (key.type != JSONValue::STRING) throw std::runtime_error("Object key must be string");
                while (isspace(s[pos])) ++pos;
                if (s[pos] != ':') throw std::runtime_error("Expected ':'");
                ++pos;
                JSONValue val = parse_json(s, pos);
                obj[*key.string_val] = val;
                while (isspace(s[pos])) ++pos;
                if (s[pos] == ',') { ++pos; continue; }
                if (s[pos] == '}') { ++pos; break; }
                throw std::runtime_error("Expected ',' or '}'");
            }
            return {JSONValue::OBJECT, std::nullopt, std::nullopt, std::nullopt, std::nullopt, obj};
        }
        throw std::runtime_error("Unexpected character");
    };

    try {
        // -------- 解析上下文 JSON --------
        std::vector<std::string> str_pool;
        std::vector<std::vector<vw::Value>> arr_pool;
        std::vector<std::unordered_map<std::string, vw::Value>> obj_pool;
        std::unordered_map<std::string, int> globalVarMap;
        std::vector<vw::Value> memory(1024, vw::Value(0));

        // 递归构建 vw::Value
        std::function<vw::Value(const JSONValue&)> build_vw = [&](const JSONValue& jv) -> vw::Value {
            switch (jv.type) {
                case JSONValue::NULL_: return vw::Value(0);
                case JSONValue::BOOL: return vw::Value(jv.bool_val.value() ? 1 : 0);
                case JSONValue::NUMBER: {
                    double d = jv.number_val.value();
                    if (d == (int)d)
                        return vw::Value((int)d);
                    else
                        return vw::Value(d);  // 使用 double 构造函数
                }
                case JSONValue::STRING: {
                    int idx = (int)str_pool.size();
                    str_pool.push_back(jv.string_val.value());
                    return vw::Value(idx, vw::Value::T_STRING);
                }
                case JSONValue::ARRAY: {
                    std::vector<vw::Value> arr;
                    for (const auto& elem : jv.array_val.value()) {
                        arr.push_back(build_vw(elem));
                    }
                    int idx = (int)arr_pool.size();
                    arr_pool.push_back(std::move(arr));
                    return vw::Value(idx, vw::Value::T_ARRAY);
                }
                case JSONValue::OBJECT: {
                    std::unordered_map<std::string, vw::Value> obj;
                    for (const auto& pair : jv.object_val.value()) {
                        obj[pair.first] = build_vw(pair.second);
                    }
                    int idx = (int)obj_pool.size();
                    obj_pool.push_back(std::move(obj));
                    return vw::Value(idx, vw::Value::T_OBJECT);
                }
                default: return vw::Value(0);
            }
        };

        // 解析 context_json（空串或 "{}" 直接跳过）
        if (!context_json.empty() && context_json != "{}") {
            size_t pos = 0;
            JSONValue root = parse_json(context_json, pos);
            if (root.type == JSONValue::OBJECT) {
                for (const auto& pair : root.object_val.value()) {
                    const std::string& key = pair.first;
                    JSONValue val = pair.second;
                    vw::Value vw_val = build_vw(val);
                    int idx = (int)globalVarMap.size();
                    globalVarMap[key] = idx;
                    if ((int)memory.size() <= idx) memory.resize(idx + 1);
                    memory[idx] = vw_val;
                }
            }
        }

        // -------- 词法分析、解析、编译 --------
        Lexer lexer(code);
        auto tokens = lexer.tokenize();
        Parser parser(tokens);
        auto prog = parser.parse();

        vw::Compiler compiler(*prog, globalVarMap);
        auto bytecode = compiler.compile();

        const auto& finalGlobalMap = compiler.getGlobalVarMap();
        
        if (memory.size() < finalGlobalMap.size()) {
            memory.resize(finalGlobalMap.size());
        }

        // 获取编译器生成的字符串池大小作为偏移量
        int stringOffset = (int)compiler.getStringPool().size();

        // 记录已调整的数组和对象句柄，防止重复调整
        std::unordered_set<int> adjusted_arrays, adjusted_objects;

        std::function<void(vw::Value&)> adjust_handles = [&](vw::Value& val) {
            if (val.type == vw::Value::T_STRING) {
                val.string_handle += stringOffset;
            }
            else if (val.type == vw::Value::T_ARRAY) {
                int h = val.array_handle;
                if (adjusted_arrays.find(h) != adjusted_arrays.end()) return;
                adjusted_arrays.insert(h);
                if (h >= 0 && h < (int)arr_pool.size()) {
                    for (auto& elem : arr_pool[h]) {
                        adjust_handles(elem);
                    }
                }
            }
            else if (val.type == vw::Value::T_OBJECT) {
                int h = val.object_handle;
                if (adjusted_objects.find(h) != adjusted_objects.end()) return;
                adjusted_objects.insert(h);
                if (h >= 0 && h < (int)obj_pool.size()) {
                    for (auto& pair : obj_pool[h]) {
                        adjust_handles(pair.second);
                    }
                }
            }
        };

        // 只调整内存中的值，保证每个数组/对象只被处理一次
        for (auto& val : memory) {
            adjust_handles(val);
        }
        
        // 合并字符串池（编译器池在前，导入池在后）
        std::vector<std::string> final_string_pool = compiler.getStringPool();
        final_string_pool.insert(final_string_pool.end(), str_pool.begin(), str_pool.end());

        // 同样，编译器可能生成浮点池，但这里没有使用，暂忽略。
        vw::VM vm(bytecode, memory);
        vm.setStringPool(final_string_pool);
        vm.setFloatPool(compiler.getFloatPool());
        vm.setFunctionAddresses(compiler.getFunctionAddresses());
        vm.setFunctionFrameSizes(compiler.getFunctionFrameSizes());
        vm.setFunctionParamCounts(compiler.getFunctionParamCounts());
        vm.setArrays(arr_pool);
        vm.setObjects(obj_pool);

        vm.run();

        // -------- 导出结果（所有全局变量）--------
        const auto& finalMemory = vm.getMemory();
        std::string result_json = "{";
        bool first = true;
        for (auto& p : finalGlobalMap) {
            if (!first) result_json += ",";
            const vw::Value& v = (p.second < (int)finalMemory.size()) ? finalMemory[p.second] : vw::Value(0);
            result_json += "\"" + p.first + "\":" + serialize_value(v, vm);
            first = false;
        }
        result_json += "}";
        return result_json;

    } catch (const std::exception& e) {
        // 错误处理（保留原有逻辑）
        std::string msg = e.what();
        int error_line = start_line;
        int error_col = start_col;
        size_t pos = msg.find("Zeile ");
        if (pos != std::string::npos) {
            size_t num_start = pos + 6;
            size_t num_end = msg.find(':', num_start);
            if (num_end != std::string::npos) {
                try {
                    int line_num = std::stoi(msg.substr(num_start, num_end - num_start));
                    error_line = start_line + line_num - 1;
                    msg = msg.substr(num_end + 2);
                } catch (...) {}
            }
        }
        g_last_error_line = error_line;
        g_last_error_col = error_col;
        kr_error("\033[32m<VW-Fehler>\033[0m %s", msg.c_str());
    }
    return "{}";
}