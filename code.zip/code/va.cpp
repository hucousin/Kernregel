// va.cpp – VA – Assembler / Compiler / Interpreter (x86-64 Version)
// Aufruf: va quelle.va [-c exe ausgabe.exe]
// Ohne -c wird das Programm interpretiert.
// Alle Schlüsselwörter und Fehlermeldungen sind auf Deutsch.

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <cctype>
#include <stack>
#include <memory>
#include <sstream>
#include <climits>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#ifdef IN
#undef IN
#endif
#ifdef OUT
#undef OUT
#endif
#endif

// ============================================================================
// Fehlerbehandlung
// ============================================================================
struct Location {
    std::string filename;
    int line = 0;
    int col = 0;
};

class ErrorCollector {
    struct Error { std::string msg; Location loc; };
    std::vector<Error> errors_;
    std::string source_;
public:
    void setSource(const std::string& src) { source_ = src; }
    void report(const std::string& msg, const Location& loc = {}) {
        errors_.push_back({msg, loc});
    }
    bool hasErrors() const { return !errors_.empty(); }
    void printAll() const {
        for (const auto& e : errors_) {
            std::cerr << "\033[96m" << e.loc.filename << ":" << e.loc.line << ":" << e.loc.col << ":\033[0m "
                      << e.msg << "\n";
        }
    }
};

// ============================================================================
// VA-Assembler – Definitionen (64-bit erweitert)
// ============================================================================

// 通用寄存器 – 对应 x86-64 的 16 个 GPR
//   r1  = RAX   r2  = RCX   r3  = RDX   r4  = RBX
//   r5  = RSP   r6  = RBP   r7  = RSI   r8  = RDI
//   r9  = R8    r10 = R9    r11 = R10   r12 = R11
//   r13 = R12   r14 = R13   r15 = R14   r16 = R15
enum class Reg {
    R1, R2, R3, R4, R5, R6, R7, R8,
    R9, R10, R11, R12, R13, R14, R15, R16
};

enum class Opcode {
    MOV, ADD, SUB, MUL, DIV, INC, DEC, AND, OR, XOR, NOT,
    CMP, JMP, JZ, JNZ, JG, JL, JGE, JLE,
    CALL, RET, PUSH, POP, INT,
    PRINT, EXIT,
    DB, DW, DD, DQ,
    IRET, IN, OUT
};

struct Operand {
    enum Type { REG, IMM, MEM, LABEL, STRING, NONE } type;
    Reg reg;
    int64_t imm;          // 64-bit für Immediate
    int64_t disp;         // 64-bit für Displacement
    Reg base;
    Reg index;            // NEU: SIB-Index
    bool hasIndex;        // NEU
    bool hasLabelBase;    // NEU: statt base-Register wird label als Basis (RIP-relativ) verwendet
    std::string label;
    std::string str;
    Operand()
        : type(NONE), reg(Reg::R1), imm(0), disp(0), base(Reg::R1),
          index(Reg::R1), hasIndex(false), hasLabelBase(false) {}
    static Operand make_reg(Reg r) { Operand o; o.type = REG; o.reg = r; return o; }
    static Operand make_imm(int64_t v) { Operand o; o.type = IMM; o.imm = v; return o; }
    static Operand make_mem(Reg base, int64_t disp = 0) {
        Operand o; o.type = MEM; o.base = base; o.disp = disp; return o;
    }
    static Operand make_mem_indexed(Reg base, Reg index, int64_t disp = 0) {
        Operand o; o.type = MEM; o.base = base; o.index = index;
        o.hasIndex = true; o.disp = disp; return o;
    }
    static Operand make_mem_label(const std::string& l, int64_t disp = 0) {
        Operand o; o.type = MEM; o.hasLabelBase = true;
        o.label = l; o.disp = disp; return o;
    }
    static Operand make_label(const std::string& l) { Operand o; o.type = LABEL; o.label = l; return o; }
    static Operand make_string(const std::string& s) { Operand o; o.type = STRING; o.str = s; return o; }
};

struct Instruction {
    Opcode op;
    std::vector<Operand> operands;
    Location loc;
    std::string label;
};

// ============================================================================
// Symboltabelle (Offsets jetzt 64-bit)
// ============================================================================
struct Symbol {
    uint64_t offset;
    bool isData;
};

class SymbolTable {
    std::unordered_map<std::string, Symbol> syms;
public:
    void define(const std::string& name, uint64_t offset, bool isData) {
        syms[name] = {offset, isData};
    }
    bool lookup(const std::string& name, Symbol& out) const {
        auto it = syms.find(name);
        if (it == syms.end()) return false;
        out = it->second;
        return true;
    }
};

// ============================================================================
// Programm-Struktur
// ============================================================================
struct Program {
    std::vector<Instruction> code;
    std::vector<uint8_t> data;
    SymbolTable sym;
    uint64_t codeSize = 0;
    uint64_t dataSize = 0;
    std::string entryLabel = "_start";
};

// ============================================================================
// Lexer / Parser
// ============================================================================
class Parser {
    ErrorCollector& err;
    std::string src;
    std::string filename;
    size_t pos = 0;
    int line = 1, col = 1;
    std::vector<std::string> lines;
    Program prog;

    void skipWhitespace() {
        while (pos < src.size() && (src[pos] == ' ' || src[pos] == '\t' || src[pos] == '\r')) {
            if (src[pos] == '\t') col += 4; else col++;
            pos++;
        }
    }
    void skipLine() {
        while (pos < src.size() && src[pos] != '\n') pos++;
        if (pos < src.size() && src[pos] == '\n') { pos++; line++; col = 1; }
    }
    bool peekChar(char c) { return pos < src.size() && src[pos] == c; }
    char getChar() { if (pos >= src.size()) return 0; char c = src[pos++]; if (c == '\n') { line++; col = 1; } else col++; return c; }

    std::string readIdent() {
        size_t start = pos;
        while (pos < src.size()) {
            unsigned char c = static_cast<unsigned char>(src[pos]);
            if (c >= 0x80 || isalnum(c) || c == '_' || c == '.') {
                ++pos;
            } else {
                break;
            }
        }
        std::string id = src.substr(start, pos - start);
        col += id.size();
        return id;
    }

    std::string readString() {
        if (!peekChar('"')) return "";
        getChar();
        size_t start = pos;
        while (pos < src.size() && src[pos] != '"') {
            if (src[pos] == '\\' && pos + 1 < src.size()) pos += 2;
            else pos++;
        }
        if (pos >= src.size()) { err.report("Nicht geschlossener ZKT", {filename, line, col}); return ""; }
        std::string raw = src.substr(start, pos - start);
        getChar();
        std::string res;
        for (size_t i = 0; i < raw.size(); ++i) {
            if (raw[i] == '\\' && i + 1 < raw.size()) {
                char c = raw[++i];
                switch (c) {
                    case 'n': res.push_back('\n'); break;
                    case 'r': res.push_back('\r'); break;
                    case 't': res.push_back('\t'); break;
                    case '\\': res.push_back('\\'); break;
                    case '"': res.push_back('"'); break;
                    default: res.push_back(c); break;
                }
            } else res.push_back(raw[i]);
        }
        return res;
    }

    int64_t readNumber() {
        size_t start = pos;
        bool isHex = false;
        if (pos < src.size() && src[pos] == '0' && pos + 1 < src.size() &&
            (src[pos + 1] == 'x' || src[pos + 1] == 'X')) {
            isHex = true;
            pos += 2;
            start = pos;
            while (pos < src.size() && isxdigit(src[pos])) pos++;
            std::string num = src.substr(start, pos - start);
            if (num.empty()) {
                err.report("Ungültige Hex-Zahl (keine Ziffern)", {filename, line, col});
                return 0;
            }
            unsigned long long val = std::stoull(num, nullptr, 16);
            return static_cast<int64_t>(val);
        } else {
            while (pos < src.size() && isdigit(src[pos])) pos++;
            std::string num = src.substr(start, pos - start);
            if (num.empty()) {
                err.report("Ungültige Zahl", {filename, line, col});
                return 0;
            }
            long long val = std::stoll(num);
            return static_cast<int64_t>(val);
        }
    }

    // 识别 r1 ... r16（大小写不敏感）
    bool isRegister(const std::string& s, Reg& r) {
        std::string lower = s;
        std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
        if (lower.size() < 2 || lower[0] != 'r') return false;
        int n = 0;
        for (size_t i = 1; i < lower.size(); ++i) {
            if (!isdigit((unsigned char)lower[i])) return false;
            n = n * 10 + (lower[i] - '0');
        }
        if (n < 1 || n > 16) return false;
        r = static_cast<Reg>(n - 1);
        return true;
    }

    Opcode parseOpcode(const std::string& s) {
        std::string low = s;
        std::transform(low.begin(), low.end(), low.begin(), ::tolower);
        if (low == "der") return Opcode::MOV;
        if (low == "add") return Opcode::ADD;
        if (low == "sub") return Opcode::SUB;
        if (low == "mul") return Opcode::MUL;
        if (low == "div") return Opcode::DIV;
        if (low == "ink") return Opcode::INC;
        if (low == "dek") return Opcode::DEC;
        if (low == "und") return Opcode::AND;
        if (low == "od") return Opcode::OR;
        if (low == "xod") return Opcode::XOR;
        if (low == "nich") return Opcode::NOT;
        if (low == "vgl") return Opcode::CMP;
        if (low == "spr") return Opcode::JMP;
        if (low == "sn") return Opcode::JZ;
        if (low == "snn") return Opcode::JNZ;
        if (low == "sg") return Opcode::JG;
        if (low == "sk") return Opcode::JL;
        if (low == "sge") return Opcode::JGE;
        if (low == "ske") return Opcode::JLE;
        if (low == "ruf") return Opcode::CALL;
        if (low == "gib") return Opcode::RET;
        if (low == "drk") return Opcode::PUSH;
        if (low == "hol") return Opcode::POP;
        if (low == "unt") return Opcode::INT;
        if (low == "zeig") return Opcode::PRINT;
        if (low == "ende") return Opcode::EXIT;
        if (low == "db") return Opcode::DB;
        if (low == "dw") return Opcode::DW;
        if (low == "dd") return Opcode::DD;
        if (low == "dq") return Opcode::DQ;
        // 新增助记符
        if (low == "ugib")   return Opcode::IRET;
        if (low == "in")     return Opcode::IN;
        if (low == "erg")    return Opcode::OUT;
        return Opcode::MOV;
    }

    static Operand parseOperandFromString(const std::string& str, size_t& pos,
                                        ErrorCollector& err, const Location& loc) {
        auto skipWS = [&]() {
            while (pos < str.size() && (str[pos] == ' ' || str[pos] == '\t' || str[pos] == '\r'))
                ++pos;
        };
        auto peekChar = [&](char c) -> bool {
            return pos < str.size() && str[pos] == c;
        };
        auto getChar = [&]() -> char {
            if (pos >= str.size()) return 0;
            return str[pos++];
        };
        auto readIdent = [&]() -> std::string {
            size_t start = pos;
            while (pos < str.size()) {
                unsigned char c = static_cast<unsigned char>(str[pos]);
                if (c >= 0x80 || isalnum(c) || c == '_' || c == '.') {
                    ++pos;
                } else {
                    break;
                }
            }
            return str.substr(start, pos - start);
        };
        auto readString = [&]() -> std::string {
            if (pos >= str.size() || str[pos] != '"') return "";
            ++pos;
            size_t start = pos;
            while (pos < str.size() && str[pos] != '"') {
                if (str[pos] == '\\' && pos + 1 < str.size())
                    pos += 2;
                else
                    ++pos;
            }
            if (pos >= str.size()) {
                err.report("Nicht geschlossener ZKT", loc);
                return "";
            }
            std::string raw = str.substr(start, pos - start);
            ++pos;
            std::string res;
            for (size_t i = 0; i < raw.size(); ++i) {
                if (raw[i] == '\\' && i + 1 < raw.size()) {
                    char c = raw[++i];
                    switch (c) {
                        case 'n': res.push_back('\n'); break;
                        case 'r': res.push_back('\r'); break;
                        case 't': res.push_back('\t'); break;
                        case '\\': res.push_back('\\'); break;
                        case '"': res.push_back('"'); break;
                        default: res.push_back(c); break;
                    }
                } else res.push_back(raw[i]);
            }
            return res;
        };
        auto readNumber = [&]() -> int64_t {
            size_t start = pos;
            bool isHex = false;
            if (pos < str.size() && str[pos] == '0' && pos + 1 < str.size() &&
                (str[pos+1] == 'x' || str[pos+1] == 'X')) {
                isHex = true;
                pos += 2;
                start = pos;
                while (pos < str.size() && isxdigit(str[pos])) ++pos;
                std::string num = str.substr(start, pos - start);
                if (num.empty()) {
                    err.report("Ungültige Hex-Zahl (keine Ziffern)", loc);
                    return 0;
                }
                unsigned long long val = std::stoull(num, nullptr, 16);
                return static_cast<int64_t>(val);
            } else {
                while (pos < str.size() && isdigit(str[pos])) ++pos;
                std::string num = str.substr(start, pos - start);
                if (num.empty()) {
                    err.report("Ungültige Zahl", loc);
                    return 0;
                }
                long long val = std::stoll(num);
                return static_cast<int64_t>(val);
            }
        };
        // r1 ... r16（大小写不敏感）
        auto isRegister = [&](const std::string& s, Reg& r) -> bool {
            std::string lower = s;
            std::transform(lower.begin(), lower.end(), lower.begin(), ::tolower);
            if (lower.size() < 2 || lower[0] != 'r') return false;
            int n = 0;
            for (size_t i = 1; i < lower.size(); ++i) {
                if (!isdigit((unsigned char)lower[i])) return false;
                n = n * 10 + (lower[i] - '0');
            }
            if (n < 1 || n > 16) return false;
            r = static_cast<Reg>(n - 1);
            return true;
        };

        skipWS();
        if (pos >= str.size()) return Operand();

        char c = str[pos];
        if (c == '[') {
            ++pos;
            skipWS();

            // ---- 先看第一个 token 是寄存器还是标签 ----
            std::string firstTok = readIdent();
            Reg r1;
            bool firstIsReg = !firstTok.empty() && isRegister(firstTok, r1);

            // ============ [label] 或 [label ± disp] ============
            if (!firstIsReg) {
                if (firstTok.empty()) {
                    err.report("Erwartet Register oder Label in Klammer", loc);
                    return Operand();
                }
                int64_t disp = 0;
                skipWS();
                while (peekChar('+') || peekChar('-')) {
                    char sign = getChar();
                    skipWS();
                    if (pos >= str.size() || !isdigit((unsigned char)str[pos])) {
                        err.report("Erwartet Zahl nach +/- in Klammer", loc);
                        return Operand();
                    }
                    int64_t val = readNumber();
                    disp += (sign == '-') ? -val : val;
                    skipWS();
                }
                if (!peekChar(']')) {
                    err.report("Erwartet ']'", loc);
                    return Operand();
                }
                ++pos;
                return Operand::make_mem_label(firstTok, disp);
            }

            // ============ [reg ...] ============
            Reg base = r1;
            Reg index = Reg::R1;
            bool hasIndex = false;
            int64_t disp = 0;

            skipWS();
            while (peekChar('+') || peekChar('-')) {
                char sign = getChar();
                skipWS();
                if (pos >= str.size()) {
                    err.report("Erwartet Operand nach +/- in Klammer", loc);
                    return Operand();
                }
                if (isdigit((unsigned char)str[pos])) {
                    int64_t val = readNumber();
                    disp += (sign == '-') ? -val : val;
                } else {
                    std::string name = readIdent();
                    Reg r2;
                    if (name.empty() || !isRegister(name, r2)) {
                        err.report("Ungültiges Symbol in Klammer: " + name, loc);
                        return Operand();
                    }
                    if (hasIndex) {
                        err.report("Zu viele Register in Adresse (x86 erlaubt nur Basis + Index)", loc);
                        return Operand();
                    }
                    if (sign == '-') {
                        err.report("Indexregister kann nicht subtrahiert werden", loc);
                        return Operand();
                    }
                    index = r2;
                    hasIndex = true;
                }
                skipWS();
            }

            if (!peekChar(']')) {
                err.report("Erwartet ']'", loc);
                return Operand();
            }
            ++pos;

            // r5 = RSP 不能作为 SIB-Index —— 交换 Base/Index
            if (hasIndex && index == Reg::R5) {
                if (base == Reg::R5) {
                    err.report("RSP kann nicht gleichzeitig Basis und Index sein", loc);
                    return Operand();
                }
                std::swap(base, index);
            }

            if (hasIndex)
                return Operand::make_mem_indexed(base, index, disp);
            return Operand::make_mem(base, disp);
        }
        if (c == '"') {
            std::string s = readString();
            return Operand::make_string(s);
        }
        if (isdigit(c) || (c == '-' && pos+1 < str.size() && isdigit(str[pos+1]))) {
            bool neg = false;
            if (c == '-') { neg = true; ++pos; }
            int64_t val = readNumber();
            if (neg) val = -val;
            return Operand::make_imm(val);
        }
        std::string id = readIdent();
        Reg r;
        if (isRegister(id, r)) {
            return Operand::make_reg(r);
        }
        return Operand::make_label(id);
    }

    bool parseLine(const std::string& lineStr, std::string& label, std::string& rest) {
        label.clear(); rest.clear();
        size_t i = 0;
        while (i < lineStr.size() && isspace(lineStr[i])) i++;
        if (i >= lineStr.size()) return false;
        size_t labelEnd = lineStr.find(':', i);
        if (labelEnd != std::string::npos) {
            label = lineStr.substr(i, labelEnd - i);
            // 去除标签尾部空白字符（空格、制表符、回车、换行）
            size_t end = label.find_last_not_of(" \t\r\n");
            if (end != std::string::npos) {
                label = label.substr(0, end + 1);
            } else {
                label.clear();
            }
            size_t restStart = labelEnd + 1;
            while (restStart < lineStr.size() && isspace(lineStr[restStart])) restStart++;
            if (restStart < lineStr.size())
                rest = lineStr.substr(restStart);
            return true;
        } else {
            rest = lineStr.substr(i);
            return true;
        }
    }

public:
    Parser(const std::string& src, const std::string& fname, ErrorCollector& ec)
        : err(ec), src(src), filename(fname) {
        std::istringstream iss(src);
        std::string line;
        while (std::getline(iss, line)) lines.push_back(line);
    }

    bool parse(Program& out) {
        prog = Program();
        pos = 0; line = 1; col = 1;
        std::vector<Instruction> instrs;
        uint64_t codeOffset = 0;
        uint64_t dataOffset = 0;

        // Erster Durchlauf: Labels sammeln und Datengrößen
        pos = 0; line = 1; col = 1;
        while (pos < src.size()) {
            skipWhitespace();
            if (pos >= src.size()) break;
            if (peekChar(';')) { skipLine(); continue; }
            size_t lineStart = pos;
            while (pos < src.size() && src[pos] != '\n') pos++;
            size_t lineEnd = pos;
            if (pos < src.size() && src[pos] == '\n') pos++;
            std::string lineStr = src.substr(lineStart, lineEnd - lineStart);
            std::string label, rest;
            if (!parseLine(lineStr, label, rest)) continue;
            if (!label.empty()) {
                bool isData = false;
                std::string restTrim = rest;
                size_t p = restTrim.find_first_not_of(" \t");
                if (p != std::string::npos) {
                    std::string first = restTrim.substr(p);
                    size_t space = first.find_first_of(" \t");
                    std::string op = (space == std::string::npos) ? first : first.substr(0, space);
                    std::transform(op.begin(), op.end(), op.begin(), ::tolower);
                    if (op == "db" || op == "dw" || op == "dd" || op == "dq")
                        isData = true;
                }
                uint64_t off = isData ? dataOffset : codeOffset;
                prog.sym.define(label, off, isData);
            }
            std::string restTrim = rest;
            size_t p = restTrim.find_first_not_of(" \t");
            if (p != std::string::npos) {
                std::string first = restTrim.substr(p);
                size_t space = first.find_first_of(" \t");
                std::string op = (space == std::string::npos) ? first : first.substr(0, space);
                std::transform(op.begin(), op.end(), op.begin(), ::tolower);
                if (op == "db" || op == "dw" || op == "dd" || op == "dq") {
                    int unit = (op == "db") ? 1 : (op == "dw") ? 2 : (op == "dd") ? 4 : 8;
                    std::string argsPart = restTrim.substr(p + op.size());
                    auto args = splitArgs(argsPart);
                    for (const std::string& a : args) {
                        std::string t = a;
                        // 去首尾空白
                        size_t s = t.find_first_not_of(" \t");
                        if (s == std::string::npos) continue;
                        t = t.substr(s);
                        if (!t.empty() && t[0] == '"') {
                            // 字符串：长度 + 1（末尾'\0'）
                            dataOffset += t.size();
                        } else {
                            dataOffset += unit;
                        }
                    }
                }
            }
        }

        // Zweiter Durchlauf: Anweisungen parsen
        pos = 0; line = 1; col = 1;
        codeOffset = 0;
        dataOffset = 0;
        prog.code.clear();
        prog.data.clear();
        prog.codeSize = 0;
        prog.dataSize = 0;

        while (pos < src.size()) {
            skipWhitespace();
            if (pos >= src.size()) break;
            if (peekChar(';')) { skipLine(); continue; }
            size_t lineStart = pos;
            while (pos < src.size() && src[pos] != '\n') pos++;
            size_t lineEnd = pos;
            if (pos < src.size() && src[pos] == '\n') pos++;
            std::string lineStr = src.substr(lineStart, lineEnd - lineStart);

            static std::string pendingLabel;

            std::string label, rest;
            if (!parseLine(lineStr, label, rest)) continue;
            while (!rest.empty() && (rest.back() == '\r' || rest.back() == '\n'))
                rest.pop_back();

            std::string restTrim = rest;
            size_t p = restTrim.find_first_not_of(" \t");

            if (p == std::string::npos) {
                if (!label.empty()) pendingLabel = label;
                continue;
            }

            if (!pendingLabel.empty() && label.empty()) {
                label = pendingLabel;
                pendingLabel.clear();
            }
            restTrim = restTrim.substr(p);

            size_t space = restTrim.find_first_of(" \t");
            std::string opStr = (space == std::string::npos) ? restTrim : restTrim.substr(0, space);
            std::transform(opStr.begin(), opStr.end(), opStr.begin(), ::tolower);
            Opcode op = parseOpcode(opStr);
            Location loc{filename, line, col};

            std::vector<Operand> ops;
            if (space != std::string::npos) {
                std::string args = restTrim.substr(space + 1);
                size_t commentPos = args.find(';');
                if (commentPos != std::string::npos)
                    args = args.substr(0, commentPos);

                std::vector<std::string> argList = splitArgs(args);
                for (const std::string& arg : argList) {
                    if (arg.empty()) continue;
                    size_t argPos = 0;
                    Operand opd = parseOperandFromString(arg, argPos, err, loc);
                    if (opd.type != Operand::NONE)
                        ops.push_back(opd);
                }
            }

            Instruction instr;
            instr.op = op;
            instr.operands = ops;
            instr.loc = loc;
            if (!label.empty())
                instr.label = label;
            prog.code.push_back(instr);
        }

        // Daten-Direktiven extrahieren
        std::vector<Instruction> newCode;
        for (auto& instr : prog.code) {
            if (instr.op == Opcode::DB || instr.op == Opcode::DW || instr.op == Opcode::DD || instr.op == Opcode::DQ) {
                for (auto& opd : instr.operands) {
                    if (opd.type == Operand::STRING) {
                        std::string s = opd.str;
                        for (char c : s) prog.data.push_back(static_cast<uint8_t>(c));
                        prog.data.push_back(0);
                    } else if (opd.type == Operand::IMM) {
                        int64_t val = opd.imm;
                        if (instr.op == Opcode::DB) {
                            prog.data.push_back(static_cast<uint8_t>(val & 0xFF));
                        } else if (instr.op == Opcode::DW) {
                            uint16_t w = static_cast<uint16_t>(val & 0xFFFF);
                            prog.data.push_back(static_cast<uint8_t>(w & 0xFF));
                            prog.data.push_back(static_cast<uint8_t>((w >> 8) & 0xFF));
                        } else if (instr.op == Opcode::DD) {
                            uint32_t d = static_cast<uint32_t>(val);
                            for (int i = 0; i < 4; ++i) prog.data.push_back(static_cast<uint8_t>((d >> (i*8)) & 0xFF));
                        } else if (instr.op == Opcode::DQ) {
                            uint64_t q = static_cast<uint64_t>(val);
                            for (int i = 0; i < 8; ++i) prog.data.push_back(static_cast<uint8_t>((q >> (i*8)) & 0xFF));
                        }
                    } else {
                        err.report("Ungültiger Operand für Daten-Direktive", instr.loc);
                    }
                }
            } else {
                newCode.push_back(instr);
            }
        }
        prog.code.swap(newCode);
        out = std::move(prog);
        return !err.hasErrors();
    }

    std::vector<std::string> splitArgs(const std::string& args) {
        std::vector<std::string> result;
        std::string current;
        bool inString = false;
        bool escape = false;

        for (size_t i = 0; i < args.size(); ++i) {
            char c = args[i];

            if (escape) {
                current.push_back(c);
                escape = false;
                continue;
            }
            if (c == '\\') {
                escape = true;
                current.push_back(c);
                continue;
            }
            if (c == '"') {
                inString = !inString;
                current.push_back(c);
                continue;
            }
            if (c == ',' && !inString) {
                size_t start = current.find_first_not_of(" \t");
                if (start != std::string::npos) {
                    size_t end = current.find_last_not_of(" \t");
                    result.push_back(current.substr(start, end - start + 1));
                } else {
                    result.push_back("");
                }
                current.clear();
                continue;
            }
            current.push_back(c);
        }

        if (!current.empty() || !result.empty()) {
            size_t start = current.find_first_not_of(" \t");
            if (start != std::string::npos) {
                size_t end = current.find_last_not_of(" \t");
                result.push_back(current.substr(start, end - start + 1));
            } else {
                result.push_back("");
            }
        }

        return result;
    }
};

// ============================================================================
// PE-Strukturen für 64-bit
// ============================================================================
#pragma pack(push, 1)
struct DOS_HEADER {
    uint16_t e_magic;
    uint16_t e_cblp;
    uint16_t e_cp;
    uint16_t e_crlc;
    uint16_t e_cparhdr;
    uint16_t e_minalloc;
    uint16_t e_maxalloc;
    uint16_t e_ss;
    uint16_t e_sp;
    uint16_t e_csum;
    uint16_t e_ip;
    uint16_t e_cs;
    uint16_t e_lfarlc;
    uint16_t e_ovno;
    uint16_t e_res[4];
    uint16_t e_oemid;
    uint16_t e_oeminfo;
    uint16_t e_res2[10];
    uint32_t e_lfanew;
};
struct FILE_HEADER {
    uint16_t Machine;
    uint16_t NumberOfSections;
    uint32_t TimeDateStamp;
    uint32_t PointerToSymbolTable;
    uint32_t NumberOfSymbols;
    uint16_t SizeOfOptionalHeader;
    uint16_t Characteristics;
};
struct OPTIONAL_HEADER64 {
    uint16_t Magic;
    uint8_t  MajorLinkerVersion;
    uint8_t  MinorLinkerVersion;
    uint32_t SizeOfCode;
    uint32_t SizeOfInitializedData;
    uint32_t SizeOfUninitializedData;
    uint32_t AddressOfEntryPoint;
    uint32_t BaseOfCode;
    uint64_t ImageBase;
    uint32_t SectionAlignment;
    uint32_t FileAlignment;
    uint16_t MajorOperatingSystemVersion;
    uint16_t MinorOperatingSystemVersion;
    uint16_t MajorImageVersion;
    uint16_t MinorImageVersion;
    uint16_t MajorSubsystemVersion;
    uint16_t MinorSubsystemVersion;
    uint32_t Win32VersionValue;
    uint32_t SizeOfImage;
    uint32_t SizeOfHeaders;
    uint32_t CheckSum;
    uint16_t Subsystem;
    uint16_t DllCharacteristics;
    uint64_t SizeOfStackReserve;
    uint64_t SizeOfStackCommit;
    uint64_t SizeOfHeapReserve;
    uint64_t SizeOfHeapCommit;
    uint32_t LoaderFlags;
    uint32_t NumberOfRvaAndSizes;
    uint32_t DataDirectory[16][2];
};
struct SECTION_HEADER {
    uint8_t Name[8];
    uint32_t VirtualSize;
    uint32_t VirtualAddress;
    uint32_t SizeOfRawData;
    uint32_t PointerToRawData;
    uint32_t PointerToRelocations;
    uint32_t PointerToLineNumbers;
    uint16_t NumberOfRelocations;
    uint16_t NumberOfLineNumbers;
    uint32_t Characteristics;
};
struct IMPORT_DESCRIPTOR {
    uint32_t OriginalFirstThunk;
    uint32_t TimeDateStamp;
    uint32_t ForwarderChain;
    uint32_t Name;
    uint32_t FirstThunk;
};
#pragma pack(pop)

// ============================================================================
// Compiler – 完整定义（x86-64，无硬编码偏移）
// ============================================================================
class Compiler {
    ErrorCollector& err;
    const Program& prog;
    std::vector<uint8_t> code;
    std::vector<uint8_t> data_;
    std::vector<uint8_t> peImage;
    bool built = false;

    std::unordered_map<std::string, uint64_t> labelOffsets;

    uint32_t iatGetStdHandle = 0;
    uint32_t iatWriteFile    = 0;
    uint32_t iatExitProcess  = 0;
    uint32_t iatLstrlen      = 0;
    uint32_t importTableOffset = 0;

    uint32_t textRva_ = 0;
    uint32_t dataRva_ = 0;
    uint32_t textRawOff_ = 0;
    uint32_t dataRawOff_ = 0;
    uint32_t codeSizeEstimate_ = 0;
    uint32_t dataTotalSize_ = 0;

    static constexpr uint64_t IMAGE_BASE = 0x140000000ULL;
    static constexpr uint32_t SECTION_ALIGN = 0x1000;
    static constexpr uint32_t FILE_ALIGN = 0x200;

    bool computeLayout() {
        codeSizeEstimate_ = 0;
        for (const auto& instr : prog.code) {
            codeSizeEstimate_ += estimateInstructionSize(instr);
        }
        codeSizeEstimate_ += 512;

        std::vector<std::string> funcs = {"GetStdHandle", "WriteFile", "ExitProcess", "lstrlenA"};
        uint32_t importTableSize = 0;

        for (auto& f : funcs) {
            importTableSize += 2 + f.size() + 1;
            if (importTableSize % 2) ++importTableSize;
        }
        while (importTableSize % 8) ++importTableSize;

        importTableSize += funcs.size() * 8 + 8;
        importTableSize += funcs.size() * 8 + 8;
        importTableSize += sizeof(IMPORT_DESCRIPTOR) + std::string("kernel32.dll").size() + 1;
        importTableSize += sizeof(IMPORT_DESCRIPTOR);
        importTableSize = (importTableSize + 7) & ~7;

        dataTotalSize_ = static_cast<uint32_t>(prog.data.size()) + importTableSize;

        textRva_ = 0x1000;
        textRva_ = (textRva_ + SECTION_ALIGN - 1) & ~(SECTION_ALIGN - 1);
        dataRva_ = (textRva_ + codeSizeEstimate_ + SECTION_ALIGN - 1) & ~(SECTION_ALIGN - 1);

        uint32_t headersSize = sizeof(DOS_HEADER) + 4 + sizeof(FILE_HEADER) +
                               sizeof(OPTIONAL_HEADER64) + 2 * sizeof(SECTION_HEADER);
        textRawOff_ = (headersSize + FILE_ALIGN - 1) & ~(FILE_ALIGN - 1);
        dataRawOff_ = (textRawOff_ + codeSizeEstimate_ + FILE_ALIGN - 1) & ~(FILE_ALIGN - 1);

        return true;
    }

    void emitCallIat(uint32_t iatRva) {
        uint64_t targetVA = IMAGE_BASE + dataRva_ + iatRva;
        uint64_t nextIP = IMAGE_BASE + textRva_ + code.size() + 6;
        uint32_t disp = static_cast<uint32_t>(targetVA - nextIP);
        emitByte(0xFF);
        emitByte(0x15);
        emitDword(disp);
    }

    void emitByte(uint8_t b) { code.push_back(b); }
    void emitDword(uint32_t v) {
        code.push_back(v & 0xFF);
        code.push_back((v >> 8) & 0xFF);
        code.push_back((v >> 16) & 0xFF);
        code.push_back((v >> 24) & 0xFF);
    }
    void emitQword(uint64_t v) {
        for (int i = 0; i < 8; ++i) code.push_back((v >> (i * 8)) & 0xFF);
    }
    // 直接返回寄存器编码 (0 .. 15) – REX 位负责扩展
    uint8_t regCode64(Reg r) {
        return static_cast<uint8_t>(r);
    }
    // 把任意 64 位立即数加载到寄存器（mov r64, imm64）
    void emitMovImm64ToReg(Reg r, int64_t v) {
        uint8_t rc = regCode64(r);
        emitRex(true, false, false, (rc >> 3) & 1);
        emitByte(0xB8 + (rc & 7));
        emitQword(static_cast<uint64_t>(v));
    }
    // 压入任意 64 位立即数：能塞进 imm32 用 push imm32；否则 mov 到 r11 再 push
    void emitPushImm(int64_t v) {
        if (v >= INT32_MIN && v <= INT32_MAX) {
            emitByte(0x68);
            emitDword(static_cast<uint32_t>(static_cast<int32_t>(v)));
        } else {
            emitMovImm64ToReg(Reg::R12, v);   // x86 R11 (caller-saved)
            emitByte(0x41); emitByte(0x53);    // push r11
        }
    }
    // 支持 r1..r16（r9..r16 需要 REX.B）
    void emitPushReg(int reg) {
        if (reg >= 8) emitByte(0x41);           // REX.B
        emitByte(0x50 + (reg & 7));
    }
    void emitPopReg(int reg) {
        if (reg >= 8) emitByte(0x41);
        emitByte(0x58 + (reg & 7));
    }
    // 64 位 add rsp, n
    void emitAddEsp(uint32_t n) {
        if (n == 0) return;
        if (n <= 127) {
            emitByte(0x48); emitByte(0x83); emitByte(0xC4); emitByte(static_cast<uint8_t>(n));
        } else {
            emitByte(0x48); emitByte(0x81); emitByte(0xC4); emitDword(n);
        }
    }
    void emitRex(bool w, bool r, bool x, bool b) {
        if (w || r || x || b) {
            uint8_t rex = 0x40;
            if (w) rex |= 0x08;
            if (r) rex |= 0x04;
            if (x) rex |= 0x02;
            if (b) rex |= 0x01;
            code.push_back(rex);
        }
    }

    // ========================================================================
    // NEU: Hilfsfunktionen für erweiterte Speicher-Adressierung
    // ========================================================================

    // 获取内存操作数的绝对虚拟地址（仅适用于 hasLabelBase）
    uint64_t resolveLabelVA(const std::string& name, const Location* loc = nullptr) {
        Symbol sym;
        if (prog.sym.lookup(name, sym)) {
            return IMAGE_BASE + (sym.isData ? dataRva_ : textRva_) + sym.offset;
        }
        auto it = labelOffsets.find(name);
        if (it != labelOffsets.end()) {
            return IMAGE_BASE + textRva_ + it->second;
        }
        if (loc) err.report("Unbekanntes Label in Speicherzugriff: " + name, *loc);
        return IMAGE_BASE;
    }

    // 为内存操作数输出 REX 前缀。
    // rexR 由调用方根据 ModRM.reg 字段决定。
    void emitMemRex(const Operand& mem, bool rexR) {
        if (mem.hasLabelBase) {
            // RIP-相对：只可能带 REX.W / REX.R
            emitRex(true, rexR, false, false);
            return;
        }
        bool rexB = (regCode64(mem.base) >> 3) & 1;
        bool rexX = false;
        if (mem.hasIndex) {
            uint8_t ic = regCode64(mem.index);
            rexX = (ic >> 3) & 1;
        }
        emitRex(true, rexR, rexX, rexB);
    }

    // 输出 ModRM (+ SIB + disp)。调用方必须先输出操作码。
    // regField 是 ModRM.reg 的 3 位值（不含 REX.R）。
    void emitMemModRM(const Operand& mem, uint8_t regField) {
        if (mem.hasLabelBase) {
            // RIP-相对：[label] / [label ± disp]
            // ModRM: mod=00, reg=regField, rm=101 → RIP + disp32
            code.push_back(static_cast<uint8_t>((0 << 6) | ((regField & 7) << 3) | 5));
            uint64_t targetVA = resolveLabelVA(mem.label) + mem.disp;
            uint64_t nextIP = IMAGE_BASE + textRva_ + code.size() + 4;
            uint32_t disp = static_cast<uint32_t>(targetVA - nextIP);
            emitDword(disp);
            return;
        }

        uint8_t baseCode = regCode64(mem.base);
        uint8_t base3 = baseCode & 7;

        if (!mem.hasIndex) {
            uint8_t mod;
            if (mem.disp == 0 && base3 != 5) mod = 0;
            else if (mem.disp >= -128 && mem.disp <= 127) mod = 1;
            else mod = 2;

            code.push_back(static_cast<uint8_t>((mod << 6) | ((regField & 7) << 3) | base3));
            if (mod == 1) code.push_back(static_cast<uint8_t>(mem.disp));
            else if (mod == 2) emitDword(static_cast<uint32_t>(mem.disp));
            return;
        }

        // SIB 路径：[base + index] / [base + index ± disp]
        uint8_t idxCode = regCode64(mem.index);
        uint8_t idx3 = idxCode & 7;

        uint8_t mod;
        if (mem.disp == 0 && base3 != 5) mod = 0;
        else if (mem.disp >= -128 && mem.disp <= 127) mod = 1;
        else mod = 2;

        // ModRM: rm = 100 → SIB 跟随
        code.push_back(static_cast<uint8_t>((mod << 6) | ((regField & 7) << 3) | 4));
        // SIB: scale=00 (×1) | index | base
        code.push_back(static_cast<uint8_t>((0 << 6) | ((idx3 & 7) << 3) | base3));

        if (mod == 1) code.push_back(static_cast<uint8_t>(mem.disp));
        else if (mod == 2) emitDword(static_cast<uint32_t>(mem.disp));
    }

    size_t estimateInstructionSize(const Instruction& instr) {
        switch (instr.op) {
            case Opcode::MOV: {
                if (instr.operands.size() < 2) return 0;
                const Operand& dest = instr.operands[0];
                const Operand& src  = instr.operands[1];
                if (dest.type == Operand::REG && (src.type == Operand::IMM || src.type == Operand::LABEL))
                    return 10;
                if (dest.type == Operand::REG && src.type == Operand::REG)
                    return 3;
                // 内存操作数最坏情况：REX(1) + op(1) + ModRM(1) + SIB(1) + disp32(4) = 8
                // 留点余量
                if (dest.type == Operand::MEM && src.type == Operand::REG)
                    return 12;
                if (dest.type == Operand::REG && src.type == Operand::MEM)
                    return 12;
                return 0;
            }
            case Opcode::ADD:
            case Opcode::SUB:
            case Opcode::CMP:
            case Opcode::AND:
            case Opcode::OR:
            case Opcode::XOR:
                if (instr.operands[0].type == Operand::REG && instr.operands[1].type == Operand::IMM)
                    return 14;    // 最坏：mov r64,imm64(10) + REX+op+modrm(3) 余量
                if (instr.operands[0].type == Operand::REG && instr.operands[1].type == Operand::REG)
                    return 3;
                return 0;
            case Opcode::MUL: {
                size_t n = instr.operands.size();
                if (n == 0) return 0;
                if (n == 1) {
                    // 原单操作数版本：F7 /4
                    if (instr.operands[0].type == Operand::REG) return 3;
                    if (instr.operands[0].type == Operand::MEM) return 12;
                    return 0;
                }
                if (n == 2) {
                    // 立即数最坏：mov r64,imm64(10) + REX+0F AF+modrm(3) = 13
                    // reg/mem 最坏 12
                    return 14;
                }
                // n >= 3：装 src1 最坏 10，后续每个 imul 最坏 14
                return 10 + (n - 2) * 14;
            }
            case Opcode::DIV: {
                size_t n = instr.operands.size();
                if (n == 0) return 0;
                if (n == 1) {
                    if (instr.operands[0].type == Operand::REG) return 3;
                    if (instr.operands[0].type == Operand::MEM) return 12;
                    return 0;
                }
                return 50;
            }
            case Opcode::NOT:
                if (instr.operands[0].type == Operand::REG)
                    return 3;
                if (instr.operands[0].type == Operand::MEM)
                    return 12;
                return 0;
            case Opcode::INC:
            case Opcode::DEC:
                if (instr.operands[0].type == Operand::REG)
                    return 3;
                return 0;
            case Opcode::PUSH:
                if (instr.operands[0].type == Operand::REG) {
                    int r = static_cast<int>(instr.operands[0].reg);
                    return (r >= 8) ? 2 : 1;
                }
                if (instr.operands[0].type == Operand::IMM)
                    return 14;    // 最坏：mov r11,imm64(10) + push(2)
                return 0;
            case Opcode::POP:
                if (instr.operands[0].type == Operand::REG) {
                    int r = static_cast<int>(instr.operands[0].reg);
                    return (r >= 8) ? 2 : 1;
                }
                return 0;
            case Opcode::JMP:
            case Opcode::CALL:
                return 5;
            case Opcode::JZ:
            case Opcode::JNZ:
            case Opcode::JG:
            case Opcode::JL:
            case Opcode::JGE:
            case Opcode::JLE:
                return 6;
            case Opcode::RET:
                return 1;
            case Opcode::PRINT:
                return 256;
            case Opcode::EXIT: {
                if (instr.operands.empty())                          return 12;
                if (instr.operands[0].type == Operand::IMM)          return 15;
                if (instr.operands[0].type == Operand::REG) {
                    int r = static_cast<int>(instr.operands[0].reg);
                    return (r >= 8) ? 13 : 12;
                }
                return 12;
            }
            case Opcode::INT:
                return 80;
            case Opcode::IRET:
                return 2;                       // REX.W + 0xCF
            case Opcode::IN: {
                if (instr.operands.size() == 2 &&
                    instr.operands[1].type == Operand::REG)
                    return 1;
                return 2;
            }
            case Opcode::OUT: {
                if (instr.operands.size() == 2 &&
                    instr.operands[0].type == Operand::REG)
                    return 1;
                return 2;
            }
            default:
                return 0;
        }
    }

    void emitInstruction(const Instruction& instr) {
        auto emitModRM = [&](uint8_t mod, uint8_t reg, uint8_t rm, bool rex_r = false, bool rex_b = false) {
            emitRex(true, rex_r, false, rex_b);
            uint8_t b = (mod << 6) | ((reg & 7) << 3) | (rm & 7);
            code.push_back(b);
        };

        switch (instr.op) {
            case Opcode::MOV: {
                if (instr.operands.size() != 2) { err.report("DER benötigt 2 Operanden", instr.loc); return; }
                const Operand& dest = instr.operands[0];
                const Operand& src = instr.operands[1];

                if (dest.type == Operand::REG && src.type == Operand::IMM) {
                    uint8_t r = regCode64(dest.reg);
                    emitRex(true, false, false, (r >> 3) & 1);
                    emitByte(0xB8 + (r & 7));
                    emitQword(static_cast<uint64_t>(src.imm));
                } else if (dest.type == Operand::REG && src.type == Operand::REG) {
                    bool rex_r = (regCode64(src.reg) >> 3) & 1;
                    bool rex_b = (regCode64(dest.reg) >> 3) & 1;
                    emitRex(true, rex_r, false, rex_b);
                    emitByte(0x89);
                    uint8_t modrm = 0xC0 | ((regCode64(src.reg) & 7) << 3) | (regCode64(dest.reg) & 7);
                    code.push_back(modrm);
                } else if (dest.type == Operand::MEM && src.type == Operand::REG) {
                    // MOV [mem], reg
                    uint8_t srcCode = regCode64(src.reg);
                    emitMemRex(dest, (srcCode >> 3) & 1);
                    emitByte(0x89);
                    emitMemModRM(dest, srcCode & 7);
                } else if (dest.type == Operand::REG && src.type == Operand::MEM) {
                    // MOV reg, [mem]
                    uint8_t destCode = regCode64(dest.reg);
                    emitMemRex(src, (destCode >> 3) & 1);
                    emitByte(0x8B);
                    emitMemModRM(src, destCode & 7);
                } else if (dest.type == Operand::REG && src.type == Operand::LABEL) {
                    uint64_t addr = 0;
                    Symbol sym;
                    if (prog.sym.lookup(src.label, sym)) {
                        addr = IMAGE_BASE + (sym.isData ? dataRva_ : textRva_) + sym.offset;
                    } else {
                        addr = labelOffsets[src.label];
                    }
                    uint8_t r = regCode64(dest.reg);
                    emitRex(true, false, false, (r >> 3) & 1);
                    emitByte(0xB8 + (r & 7));
                    emitQword(addr);
                } else {
                    err.report("DER: nicht unterstützte Operandenkombination", instr.loc);
                }
                break;
            }
            case Opcode::ADD: {
                if (instr.operands.size() != 2) { err.report("ADD benötigt 2 Operanden", instr.loc); return; }
                const Operand& dest = instr.operands[0];
                const Operand& src = instr.operands[1];
                if (dest.type == Operand::REG && src.type == Operand::IMM) {
                    uint8_t dc = regCode64(dest.reg);
                    if (src.imm >= INT32_MIN && src.imm <= INT32_MAX) {
                        emitRex(true, false, false, (dc >> 3) & 1);
                        emitByte(0x81);
                        code.push_back(0xC0 | (0 << 3) | (dc & 7));
                        emitDword(static_cast<uint32_t>(static_cast<int32_t>(src.imm)));
                    } else {
                        Reg tmp = (dest.reg == Reg::R12) ? Reg::R11 : Reg::R12;
                        emitMovImm64ToReg(tmp, src.imm);
                        uint8_t tc = regCode64(tmp);
                        emitRex(true, (tc >> 3) & 1, false, (dc >> 3) & 1);
                        emitByte(0x01);
                        code.push_back(0xC0 | ((tc & 7) << 3) | (dc & 7));
                    }
                } else if (dest.type == Operand::REG && src.type == Operand::REG) {
                    bool rex_r = (regCode64(src.reg) >> 3) & 1;
                    bool rex_b = (regCode64(dest.reg) >> 3) & 1;
                    emitRex(true, rex_r, false, rex_b);
                    emitByte(0x01);
                    uint8_t modrm = 0xC0 | ((regCode64(src.reg) & 7) << 3) | (regCode64(dest.reg) & 7);
                    code.push_back(modrm);
                } else if (dest.type == Operand::REG && src.type == Operand::MEM) {
                    // ADD reg, [mem]    → 03 /r
                    uint8_t dc = regCode64(dest.reg);
                    emitMemRex(src, (dc >> 3) & 1);
                    emitByte(0x03);
                    emitMemModRM(src, dc & 7);
                } else if (dest.type == Operand::MEM && src.type == Operand::REG) {
                    // ADD [mem], reg    → 01 /r
                    uint8_t sc = regCode64(src.reg);
                    emitMemRex(dest, (sc >> 3) & 1);
                    emitByte(0x01);
                    emitMemModRM(dest, sc & 7);
                } else {
                    err.report("ADD: nicht unterstützte Operanden", instr.loc);
                }
                break;
            }
            case Opcode::SUB: {
                if (instr.operands.size() != 2) { err.report("SUB benötigt 2 Operanden", instr.loc); return; }
                const Operand& dest = instr.operands[0];
                const Operand& src = instr.operands[1];
                if (dest.type == Operand::REG && src.type == Operand::IMM) {
                    uint8_t dc = regCode64(dest.reg);
                    if (src.imm >= INT32_MIN && src.imm <= INT32_MAX) {
                        emitRex(true, false, false, (dc >> 3) & 1);
                        emitByte(0x81);
                        code.push_back(0xC0 | (5 << 3) | (dc & 7));
                        emitDword(static_cast<uint32_t>(static_cast<int32_t>(src.imm)));
                    } else {
                        Reg tmp = (dest.reg == Reg::R12) ? Reg::R11 : Reg::R12;
                        emitMovImm64ToReg(tmp, src.imm);
                        uint8_t tc = regCode64(tmp);
                        emitRex(true, (tc >> 3) & 1, false, (dc >> 3) & 1);
                        emitByte(0x29);
                        code.push_back(0xC0 | ((tc & 7) << 3) | (dc & 7));
                    }
                } else if (dest.type == Operand::REG && src.type == Operand::REG) {
                    bool rex_r = (regCode64(src.reg) >> 3) & 1;
                    bool rex_b = (regCode64(dest.reg) >> 3) & 1;
                    emitRex(true, rex_r, false, rex_b);
                    emitByte(0x29);
                    uint8_t modrm = 0xC0 | ((regCode64(src.reg) & 7) << 3) | (regCode64(dest.reg) & 7);
                    code.push_back(modrm);
                } else if (dest.type == Operand::REG && src.type == Operand::MEM) {
                    // SUB reg, [mem]   → 2B /r
                    uint8_t dc = regCode64(dest.reg);
                    emitMemRex(src, (dc >> 3) & 1);
                    emitByte(0x2B);
                    emitMemModRM(src, dc & 7);
                } else if (dest.type == Operand::MEM && src.type == Operand::REG) {
                    // SUB [mem], reg   → 29 /r
                    uint8_t sc = regCode64(src.reg);
                    emitMemRex(dest, (sc >> 3) & 1);
                    emitByte(0x29);
                    emitMemModRM(dest, sc & 7);
                } else {
                    err.report("SUB: nicht unterstützte Operanden", instr.loc);
                }
                break;
            }
            case Opcode::INC: {
                if (instr.operands.size() != 1) { err.report("INK benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::REG) {
                    emitRex(true, false, false, (regCode64(op.reg) >> 3) & 1);
                    emitByte(0xFF);
                    uint8_t modrm = 0xC0 | (0 << 3) | (regCode64(op.reg) & 7);
                    code.push_back(modrm);
                } else if (op.type == Operand::MEM) {
                    emitMemRex(op, false);
                    emitByte(0xFF);
                    emitMemModRM(op, 0);
                } else {
                    err.report("INK nur auf Register oder Speicher", instr.loc);
                }
                break;
            }
            case Opcode::DEC: {
                if (instr.operands.size() != 1) { err.report("DEK benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::REG) {
                    emitRex(true, false, false, (regCode64(op.reg) >> 3) & 1);
                    emitByte(0xFF);
                    uint8_t modrm = 0xC0 | (1 << 3) | (regCode64(op.reg) & 7);
                    code.push_back(modrm);
                } else if (op.type == Operand::MEM) {
                    emitMemRex(op, false);
                    emitByte(0xFF);
                    emitMemModRM(op, 1);
                } else {
                    err.report("DEK nur auf Register oder Speicher", instr.loc);
                }
                break;
            }
            case Opcode::PUSH: {
                if (instr.operands.size() != 1) { err.report("DRK benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::REG) {
                    uint8_t r = regCode64(op.reg);
                    emitRex(false, false, false, (r >> 3) & 1);
                    emitByte(0x50 + (r & 7));
                } else if (op.type == Operand::IMM) {
                    if (op.imm >= INT32_MIN && op.imm <= INT32_MAX) {
                        emitByte(0x68);
                        emitDword(static_cast<uint32_t>(static_cast<int32_t>(op.imm)));
                    } else {
                        emitMovImm64ToReg(Reg::R12, op.imm);   // x86 R11
                        emitByte(0x41); emitByte(0x53);        // push r11
                    }
                } else {
                    err.report("DRK nur Register oder Immediate", instr.loc);
                }
                break;
            }
            case Opcode::POP: {
                if (instr.operands.size() != 1) { err.report("HOL benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::REG) {
                    uint8_t r = regCode64(op.reg);
                    emitRex(false, false, false, (r >> 3) & 1);
                    emitByte(0x58 + (r & 7));
                } else {
                    err.report("HOL nur Register", instr.loc);
                }
                break;
            }
            case Opcode::CMP: {
                if (instr.operands.size() != 2) { err.report("VGL benötigt 2 Operanden", instr.loc); return; }
                const Operand& a = instr.operands[0];
                const Operand& b = instr.operands[1];
                if (a.type == Operand::REG && b.type == Operand::IMM) {
                    uint8_t ac = regCode64(a.reg);
                    if (b.imm >= INT32_MIN && b.imm <= INT32_MAX) {
                        emitRex(true, false, false, (ac >> 3) & 1);
                        emitByte(0x81);
                        code.push_back(0xC0 | (7 << 3) | (ac & 7));
                        emitDword(static_cast<uint32_t>(static_cast<int32_t>(b.imm)));
                    } else {
                        Reg tmp = (a.reg == Reg::R12) ? Reg::R11 : Reg::R12;
                        emitMovImm64ToReg(tmp, b.imm);
                        uint8_t tc = regCode64(tmp);
                        emitRex(true, (tc >> 3) & 1, false, (ac >> 3) & 1);
                        emitByte(0x39);                          // cmp r/m64, r64
                        code.push_back(0xC0 | ((tc & 7) << 3) | (ac & 7));
                    }
                } else if (a.type == Operand::REG && b.type == Operand::REG) {
                    bool rex_r = (regCode64(b.reg) >> 3) & 1;
                    bool rex_b = (regCode64(a.reg) >> 3) & 1;
                    emitRex(true, rex_r, false, rex_b);
                    emitByte(0x39);
                    uint8_t modrm = 0xC0 | ((regCode64(b.reg) & 7) << 3) | (regCode64(a.reg) & 7);
                    code.push_back(modrm);
                } else if (a.type == Operand::REG && b.type == Operand::MEM) {
                    // CMP reg, [mem]  → 3B /r
                    uint8_t ac = regCode64(a.reg);
                    emitMemRex(b, (ac >> 3) & 1);
                    emitByte(0x3B);
                    emitMemModRM(b, ac & 7);
                } else if (a.type == Operand::MEM && b.type == Operand::REG) {
                    // CMP [mem], reg  → 39 /r
                    uint8_t bc = regCode64(b.reg);
                    emitMemRex(a, (bc >> 3) & 1);
                    emitByte(0x39);
                    emitMemModRM(a, bc & 7);
                } else {
                    err.report("VGL: nicht unterstützte Operanden", instr.loc);
                }
                break;
            }
            case Opcode::JMP: {
                if (instr.operands.size() != 1) { err.report("SPR benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0xE9);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("SPR nur Label", instr.loc);
                }
                break;
            }
            case Opcode::JZ: {
                if (instr.operands.size() != 1) { err.report("SN benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0x0F);
                    emitByte(0x84);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("SN nur Label", instr.loc);
                }
                break;
            }
            case Opcode::JNZ: {
                if (instr.operands.size() != 1) { err.report("SNN benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0x0F);
                    emitByte(0x85);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("SNN nur Label", instr.loc);
                }
                break;
            }
            case Opcode::JG: {
                if (instr.operands.size() != 1) { err.report("SGR benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0x0F);
                    emitByte(0x8F);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("SGR nur Label", instr.loc);
                }
                break;
            }
            case Opcode::JGE: {
                if (instr.operands.size() != 1) { err.report("SGE benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0x0F);
                    emitByte(0x8D);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("SGE nur Label", instr.loc);
                }
                break;
            }
            case Opcode::JLE: {
                if (instr.operands.size() != 1) { err.report("SKE benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0x0F);
                    emitByte(0x8E);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("SKE nur Label", instr.loc);
                }
                break;
            }
            case Opcode::JL: {
                if (instr.operands.size() != 1) { err.report("SKL benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0x0F);
                    emitByte(0x8C);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("SKL nur Label", instr.loc);
                }
                break;
            }
            case Opcode::CALL: {
                if (instr.operands.size() != 1) { err.report("RUF benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::LABEL) {
                    Symbol sym;
                    if (prog.sym.lookup(op.label, sym) && sym.isData) {
                        err.report("Fehler: Datenlabel '" + op.label + "' kann nicht als Sprungziel verwendet werden.", instr.loc);
                        return;
                    }
                    uint64_t target = labelOffsets[op.label];
                    emitByte(0xE8);
                    uint32_t rel = static_cast<uint32_t>(target - (code.size() + 4));
                    emitDword(rel);
                } else {
                    err.report("RUF nur Label", instr.loc);
                }
                break;
            }
            case Opcode::RET: {
                emitByte(0xC3);
                break;
            }
            case Opcode::PRINT: {
                if (instr.operands.size() != 1) {
                    err.report("ZEIG benötigt 1 Operand", instr.loc);
                    return;
                }
                const Operand& opd = instr.operands[0];

                if (opd.type == Operand::LABEL) {
                    // ---------- 打印字符串 ----------
                    Symbol sym;
                    if (!prog.sym.lookup(opd.label, sym) || !sym.isData) {
                        err.report("Unbekanntes Daten-Label: " + opd.label, instr.loc);
                        return;
                    }
                    uint64_t strAddr = IMAGE_BASE + dataRva_ + sym.offset;

                    emitByte(0x48); emitByte(0x83); emitByte(0xEC); emitByte(0x38);   // sub rsp, 56

                    // GetStdHandle(STD_OUTPUT_HANDLE)
                    emitByte(0xB9); emitDword(0xFFFFFFF5);
                    emitCallIat(iatGetStdHandle);
                    emitByte(0x48); emitByte(0x89); emitByte(0xC3);       // mov rbx, rax

                    // lstrlenA(str)
                    emitByte(0x48); emitByte(0x8D); emitByte(0x0D);
                    uint32_t dispStr = static_cast<uint32_t>(strAddr - (IMAGE_BASE + textRva_ + code.size() + 4));
                    emitDword(dispStr);
                    emitCallIat(iatLstrlen);
                    emitByte(0x49); emitByte(0x89); emitByte(0xC0);       // mov r8, rax

                    // WriteFile
                    emitByte(0x48); emitByte(0x89); emitByte(0xD9);       // mov rcx, rbx
                    emitByte(0x48); emitByte(0x8D); emitByte(0x15);
                    uint32_t dispStr2 = static_cast<uint32_t>(strAddr - (IMAGE_BASE + textRva_ + code.size() + 4));
                    emitDword(dispStr2);

                    emitByte(0x48); emitByte(0x8D); emitByte(0x44); emitByte(0x24); emitByte(0x28); // lea rax, [rsp+40]
                    emitByte(0x49); emitByte(0x89); emitByte(0xC1);       // mov r9, rax

                    emitByte(0x48); emitByte(0xC7); emitByte(0x44); emitByte(0x24); emitByte(0x20);
                    emitDword(0);                                          // mov qword [rsp+32], 0

                    emitByte(0x48); emitByte(0xC7); emitByte(0x44); emitByte(0x24); emitByte(0x28);
                    emitDword(0);                                          // mov qword [rsp+40], 0

                    emitCallIat(iatWriteFile);

                    emitByte(0x48); emitByte(0x83); emitByte(0xC4); emitByte(0x38); // add rsp, 56
                } else if (opd.type == Operand::REG) {
                    // ---------- 打印寄存器 ----------
                    emitByte(0x50);                                      // push rax
                    emitByte(0x51);                                      // push rcx
                    emitByte(0x52);                                      // push rdx
                    emitByte(0x41); emitByte(0x50);                      // push r8
                    emitByte(0x41); emitByte(0x51);                      // push r9
                    emitByte(0x41); emitByte(0x52);                      // push r10
                    emitByte(0x41); emitByte(0x53);                      // push r11
                    emitByte(0x57);                                      // push rdi
                    emitByte(0x48); emitByte(0x83); emitByte(0xEC); emitByte(0x48);  // sub rsp, 0x48

                    // 把待打印的寄存器移入 RAX
                    if (opd.reg != Reg::R1) {
                        uint8_t srcCode = regCode64(opd.reg);
                        emitRex(true, (srcCode >> 3) & 1, false, false);
                        emitByte(0x89);                                  // mov rax, <reg>
                        code.push_back(0xC0 | ((srcCode & 7) << 3) | 0);
                    }

                    // RDI = 缓冲区末尾
                    emitByte(0x48); emitByte(0x8D); emitByte(0x7C); emitByte(0x24); emitByte(0x48); // lea rdi, [rsp+0x48]

                    // RCX = 10
                    emitByte(0xB9); emitDword(10);

                    int convLoop = newLabel();
                    int doneLabel = newLabel();

                    // 特判 0
                    emitByte(0x48); emitByte(0x85); emitByte(0xC0);      // test rax, rax
                    emitJnz(convLoop);
                    emitByte(0x48); emitByte(0xFF); emitByte(0xCF);      // dec rdi
                    emitByte(0xC6); emitByte(0x07); emitByte('0');       // mov byte [rdi], '0'
                    emitJmp(doneLabel);

                    emitLabel(convLoop);
                    emitByte(0x48); emitByte(0x31); emitByte(0xD2);      // xor rdx, rdx
                    emitByte(0x48); emitByte(0xF7); emitByte(0xF1);      // div rcx
                    emitByte(0x80); emitByte(0xC2); emitByte('0');       // add dl, '0'
                    emitByte(0x48); emitByte(0xFF); emitByte(0xCF);      // dec rdi
                    emitByte(0x88); emitByte(0x17);                      // mov [rdi], dl
                    emitByte(0x48); emitByte(0x85); emitByte(0xC0);      // test rax, rax
                    emitJnz(convLoop);
                    emitLabel(doneLabel);

                    // GetStdHandle
                    emitByte(0xB9); emitDword(0xFFFFFFF5);
                    emitCallIat(iatGetStdHandle);

                    // WriteFile
                    emitByte(0x48); emitByte(0x89); emitByte(0xC1);                     // mov rcx, rax
                    emitByte(0x48); emitByte(0x89); emitByte(0xFA);                     // mov rdx, rdi
                    emitByte(0x49); emitByte(0x89); emitByte(0xE0);                     // mov r8, rsp
                    emitByte(0x49); emitByte(0x83); emitByte(0xC0); emitByte(0x48);     // add r8, 0x48
                    emitByte(0x49); emitByte(0x29); emitByte(0xF8);                     // sub r8, rdi
                    emitByte(0x4C); emitByte(0x8D); emitByte(0x4C); emitByte(0x24); emitByte(0x28); // lea r9, [rsp+0x28]
                    emitByte(0x48); emitByte(0xC7); emitByte(0x44); emitByte(0x24); emitByte(0x20); emitDword(0);
                    emitByte(0x48); emitByte(0xC7); emitByte(0x44); emitByte(0x24); emitByte(0x28); emitDword(0);

                    emitCallIat(iatWriteFile);

                    // 恢复
                    emitByte(0x48); emitByte(0x83); emitByte(0xC4); emitByte(0x48);     // add rsp, 0x48
                    emitByte(0x5F);                                                     // pop rdi
                    emitByte(0x41); emitByte(0x5B);                                     // pop r11
                    emitByte(0x41); emitByte(0x5A);                                     // pop r10
                    emitByte(0x41); emitByte(0x59);                                     // pop r9
                    emitByte(0x41); emitByte(0x58);                                     // pop r8
                    emitByte(0x5A);                                                     // pop rdx
                    emitByte(0x59);                                                     // pop rcx
                    emitByte(0x58);                                                     // pop rax
                } else {
                    err.report("ZEIG: Operand muss String-Label oder Register sein", instr.loc);
                }
                break;
            }
            case Opcode::EXIT: {
                emitByte(0x48); emitByte(0x83); emitByte(0xEC); emitByte(0x28); // sub rsp, 40

                if (instr.operands.empty()) {
                    emitByte(0x31); emitByte(0xC9);                              // xor ecx, ecx → 0
                } else if (instr.operands[0].type == Operand::REG) {
                    uint8_t srcCode = regCode64(instr.operands[0].reg);
                    bool rex_b = (srcCode >> 3) & 1;
                    emitRex(false, false, false, rex_b);
                    emitByte(0x8B);                                              // mov ecx, <reg32>
                    code.push_back(0xC0 | (1 << 3) | (srcCode & 7));
                } else if (instr.operands[0].type == Operand::IMM) {
                    emitByte(0xB9);                                              // mov ecx, imm32
                    emitDword(static_cast<uint32_t>(instr.operands[0].imm));
                } else {
                    err.report("ENDE: Operand muss Register oder Immediate sein", instr.loc);
                }

                emitCallIat(iatExitProcess);                                     // 永不返回
                break;
            }
            case Opcode::MUL: {
                if (instr.operands.size() == 1) {
                    // 原有单操作数逻辑
                    const Operand& op = instr.operands[0];
                    if (op.type == Operand::REG) {
                        emitRex(true, false, false, (regCode64(op.reg) >> 3) & 1);
                        emitByte(0xF7);
                        uint8_t modrm = 0xC0 | (4 << 3) | (regCode64(op.reg) & 7);
                        code.push_back(modrm);
                    } else if (op.type == Operand::MEM) {
                        emitMemRex(op, false);
                        emitByte(0xF7);
                        emitMemModRM(op, 4);
                    } else {
                        err.report("MUL unterstützt nur Register oder Speicher", instr.loc);
                    }
                } else {
                    // 多操作数 MUL
                    if (instr.operands[0].type != Operand::REG) {
                        err.report("MUL: Ziel (erster Operand) muss ein Register sein", instr.loc);
                        return;
                    }
                    Reg destReg = instr.operands[0].reg;
                    uint8_t destCode = regCode64(destReg);

                    if (instr.operands.size() == 2) {
                        const Operand& src = instr.operands[1];
                        if (src.type == Operand::IMM) {
                            if (src.imm >= INT32_MIN && src.imm <= INT32_MAX) {
                                // imul dest, dest, imm32
                                emitRex(true, (destCode >> 3) & 1, false, (destCode >> 3) & 1);
                                emitByte(0x69);
                                code.push_back(0xC0 | ((destCode & 7) << 3) | (destCode & 7));
                                emitDword(static_cast<uint32_t>(static_cast<int32_t>(src.imm)));
                            } else {
                                // mov temp, imm64; imul dest, temp
                                Reg tmp = (destReg == Reg::R12) ? Reg::R11 : Reg::R12;
                                emitMovImm64ToReg(tmp, src.imm);
                                uint8_t tc = regCode64(tmp);
                                emitRex(true, (destCode >> 3) & 1, false, (tc >> 3) & 1);
                                emitByte(0x0F); emitByte(0xAF);
                                code.push_back(0xC0 | ((destCode & 7) << 3) | (tc & 7));
                            }
                        } else if (src.type == Operand::REG) {
                            // imul dest, src
                            bool rex_r = (destCode >> 3) & 1;
                            bool rex_b = (regCode64(src.reg) >> 3) & 1;
                            emitRex(true, rex_r, false, rex_b);
                            emitByte(0x0F); emitByte(0xAF);
                            code.push_back(0xC0 | ((destCode & 7) << 3) | (regCode64(src.reg) & 7));
                        } else if (src.type == Operand::MEM) {
                            // imul dest, [mem]  → 0F AF /r
                            emitMemRex(src, (destCode >> 3) & 1);
                            emitByte(0x0F); emitByte(0xAF);
                            emitMemModRM(src, destCode & 7);
                        } else {
                            err.report("MUL: ungültiger zweiter Operand", instr.loc);
                        }
                    } else {
                        // 3 个或更多操作数：dest = src1 * src2 * ...
                        const Operand& src1 = instr.operands[1];
                        // 将 src1 移入 dest
                        if (src1.type == Operand::REG) {
                            if (src1.reg != destReg) {
                                bool rex_r = (regCode64(src1.reg) >> 3) & 1;
                                bool rex_b = (destCode >> 3) & 1;
                                emitRex(true, rex_r, false, rex_b);
                                emitByte(0x89);
                                code.push_back(0xC0 | ((regCode64(src1.reg) & 7) << 3) | (destCode & 7));
                            }
                        } else if (src1.type == Operand::IMM) {
                            emitMovImm64ToReg(destReg, src1.imm);
                        } else if (src1.type == Operand::MEM) {
                            emitMemRex(src1, (destCode >> 3) & 1);
                            emitByte(0x8B);
                            emitMemModRM(src1, destCode & 7);
                        } else {
                            err.report("MUL: ungültiger Operand", instr.loc);
                            return;
                        }
                        // 对后续每个操作数执行 imul
                        for (size_t i = 2; i < instr.operands.size(); ++i) {
                            const Operand& src = instr.operands[i];
                            if (src.type == Operand::IMM) {
                                if (src.imm >= INT32_MIN && src.imm <= INT32_MAX) {
                                    emitRex(true, (destCode >> 3) & 1, false, (destCode >> 3) & 1);
                                    emitByte(0x69);
                                    code.push_back(0xC0 | ((destCode & 7) << 3) | (destCode & 7));
                                    emitDword(static_cast<uint32_t>(static_cast<int32_t>(src.imm)));
                                } else {
                                    Reg tmp = (destReg == Reg::R12) ? Reg::R11 : Reg::R12;
                                    emitMovImm64ToReg(tmp, src.imm);
                                    uint8_t tc = regCode64(tmp);
                                    emitRex(true, (destCode >> 3) & 1, false, (tc >> 3) & 1);
                                    emitByte(0x0F); emitByte(0xAF);
                                    code.push_back(0xC0 | ((destCode & 7) << 3) | (tc & 7));
                                }
                            } else if (src.type == Operand::REG) {
                                bool rex_r = (destCode >> 3) & 1;
                                bool rex_b = (regCode64(src.reg) >> 3) & 1;
                                emitRex(true, rex_r, false, rex_b);
                                emitByte(0x0F); emitByte(0xAF);
                                code.push_back(0xC0 | ((destCode & 7) << 3) | (regCode64(src.reg) & 7));
                            } else if (src.type == Operand::MEM) {
                                emitMemRex(src, (destCode >> 3) & 1);
                                emitByte(0x0F); emitByte(0xAF);
                                emitMemModRM(src, destCode & 7);
                            } else {
                                err.report("MUL: ungültiger Operand", instr.loc);
                                return;
                            }
                        }
                    }
                }
                break;
            }
            case Opcode::DIV: {
                if (instr.operands.size() == 1) {
                    // 原有单操作数逻辑
                    const Operand& op = instr.operands[0];
                    if (op.type == Operand::REG) {
                        emitRex(true, false, false, (regCode64(op.reg) >> 3) & 1);
                        emitByte(0xF7);
                        uint8_t modrm = 0xC0 | (6 << 3) | (regCode64(op.reg) & 7);
                        code.push_back(modrm);
                    } else if (op.type == Operand::MEM) {
                        emitMemRex(op, false);
                        emitByte(0xF7);
                        emitMemModRM(op, 6);
                    } else {
                        err.report("DIV unterstützt nur Register oder Speicher", instr.loc);
                    }
                } else {
                    // 多操作数 DIV
                    if (instr.operands.size() > 4) {
                        err.report("DIV: zu viele Operanden (maximal 4)", instr.loc);
                        return;
                    }
                    if (instr.operands[0].type != Operand::REG) {
                        err.report("DIV: erster Operand muss ein Register sein", instr.loc);
                        return;
                    }
                    Reg quotientReg = instr.operands[0].reg;
                    Reg remainderReg;
                    bool hasRemainder = false;
                    if (instr.operands.size() == 4) {
                        if (instr.operands[1].type != Operand::REG) {
                            err.report("DIV: zweiter Operand muss ein Register sein (für Rest)", instr.loc);
                            return;
                        }
                        remainderReg = instr.operands[1].reg;
                        hasRemainder = true;
                    }
                    const Operand* dividendOp = nullptr;
                    const Operand* divisorOp = nullptr;
                    if (instr.operands.size() == 2) {
                        dividendOp = &instr.operands[0];
                        divisorOp = &instr.operands[1];
                    } else if (instr.operands.size() == 3) {
                        dividendOp = &instr.operands[1];
                        divisorOp = &instr.operands[2];
                    } else {
                        dividendOp = &instr.operands[2];
                        divisorOp = &instr.operands[3];
                    }

                    // 1. 将 divisor 压栈
                    if (divisorOp->type == Operand::REG) {
                        uint8_t r = regCode64(divisorOp->reg);
                        emitRex(false, false, false, (r >> 3) & 1);
                        emitByte(0x50 + (r & 7));
                    } else if (divisorOp->type == Operand::IMM) {
                        if (divisorOp->imm >= INT32_MIN && divisorOp->imm <= INT32_MAX) {
                            emitByte(0x68);
                            emitDword(static_cast<uint32_t>(static_cast<int32_t>(divisorOp->imm)));
                        } else {
                            Reg tmp = (dividendOp->type == Operand::REG &&
                                       dividendOp->reg == Reg::R12)
                                      ? Reg::R11 : Reg::R12;
                            emitMovImm64ToReg(tmp, divisorOp->imm);
                            emitPushReg(static_cast<int>(tmp));
                        }
                    } else if (divisorOp->type == Operand::MEM) {
                        emitMemRex(*divisorOp, false);
                        emitByte(0xFF);
                        emitMemModRM(*divisorOp, 6);
                    } else {
                        err.report("DIV: ungültiger Divisor-Operand", instr.loc);
                        return;
                    }

                    // 2. 将 dividend 移入 RAX
                    auto movToRAX = [&](const Operand& op) {
                        if (op.type == Operand::REG) {
                            if (op.reg != Reg::R1) {
                                uint8_t srcCode = regCode64(op.reg);
                                emitRex(true, (srcCode >> 3) & 1, false, false);
                                emitByte(0x89);
                                code.push_back(0xC0 | ((srcCode & 7) << 3) | 0);
                            }
                        } else if (op.type == Operand::IMM) {
                            emitMovImm64ToReg(Reg::R1, op.imm);
                        } else if (op.type == Operand::MEM) {
                            emitMemRex(op, false);
                            emitByte(0x8B);
                            emitMemModRM(op, 0);
                        } else {
                            err.report("DIV: ungültiger Dividend-Operand", instr.loc);
                        }
                    };
                    movToRAX(*dividendOp);

                    // 3. 清零 RDX
                    emitByte(0x48); emitByte(0x31); emitByte(0xD2);

                    // 4. div qword [rsp]
                    emitByte(0x48); emitByte(0xF7); emitByte(0x34); emitByte(0x24);

                    // 5. 调整栈
                    emitByte(0x48); emitByte(0x83); emitByte(0xC4); emitByte(0x08);

                    // 6. 移动商和余数
                    if (hasRemainder && quotientReg == Reg::R3 && remainderReg == Reg::R1) {
                        // 交换：使用 RCX 作为临时
                        emitByte(0x48); emitByte(0x89); emitByte(0xD1); // mov rcx, rdx
                        emitByte(0x48); emitByte(0x89); emitByte(0xC2); // mov rdx, rax
                        emitByte(0x48); emitByte(0x89); emitByte(0xC8); // mov rax, rcx
                    } else {
                        if (quotientReg != Reg::R1) {
                            uint8_t qCode = regCode64(quotientReg);
                            emitRex(true, false, false, (qCode >> 3) & 1);
                            emitByte(0x89);
                            code.push_back(0xC0 | (0 << 3) | (qCode & 7));
                        }
                        if (hasRemainder && remainderReg != Reg::R3) {
                            uint8_t rCode = regCode64(remainderReg);
                            emitRex(true, false, false, (rCode >> 3) & 1);
                            emitByte(0x89);
                            code.push_back(0xC0 | (2 << 3) | (rCode & 7));
                        }
                    }
                }
                break;
            }
            case Opcode::AND: {
                if (instr.operands.size() != 2) { err.report("UND benötigt 2 Operanden", instr.loc); return; }
                const Operand& dest = instr.operands[0];
                const Operand& src = instr.operands[1];
                if (dest.type == Operand::REG && src.type == Operand::REG) {
                    bool rex_r = (regCode64(src.reg) >> 3) & 1;
                    bool rex_b = (regCode64(dest.reg) >> 3) & 1;
                    emitRex(true, rex_r, false, rex_b);
                    emitByte(0x21);
                    uint8_t modrm = 0xC0 | ((regCode64(src.reg) & 7) << 3) | (regCode64(dest.reg) & 7);
                    code.push_back(modrm);
                } else if (dest.type == Operand::REG && src.type == Operand::IMM) {
                    uint8_t dc = regCode64(dest.reg);
                    if (src.imm >= INT32_MIN && src.imm <= INT32_MAX) {
                        emitRex(true, false, false, (dc >> 3) & 1);
                        emitByte(0x81);
                        code.push_back(0xC0 | (4 << 3) | (dc & 7));
                        emitDword(static_cast<uint32_t>(static_cast<int32_t>(src.imm)));
                    } else {
                        Reg tmp = (dest.reg == Reg::R12) ? Reg::R11 : Reg::R12;
                        emitMovImm64ToReg(tmp, src.imm);
                        uint8_t tc = regCode64(tmp);
                        emitRex(true, (tc >> 3) & 1, false, (dc >> 3) & 1);
                        emitByte(0x21);
                        code.push_back(0xC0 | ((tc & 7) << 3) | (dc & 7));
                    }
                } else if (dest.type == Operand::REG && src.type == Operand::MEM) {
                    // AND reg, [mem]  → 23 /r
                    uint8_t dc = regCode64(dest.reg);
                    emitMemRex(src, (dc >> 3) & 1);
                    emitByte(0x23);
                    emitMemModRM(src, dc & 7);
                } else if (dest.type == Operand::MEM && src.type == Operand::REG) {
                    // AND [mem], reg  → 21 /r
                    uint8_t sc = regCode64(src.reg);
                    emitMemRex(dest, (sc >> 3) & 1);
                    emitByte(0x21);
                    emitMemModRM(dest, sc & 7);
                } else {
                    err.report("UND: nicht unterstützte Operanden", instr.loc);
                }
                break;
            }
            case Opcode::OR: {
                if (instr.operands.size() != 2) { err.report("OD benötigt 2 Operanden", instr.loc); return; }
                const Operand& dest = instr.operands[0];
                const Operand& src = instr.operands[1];
                if (dest.type == Operand::REG && src.type == Operand::REG) {
                    bool rex_r = (regCode64(src.reg) >> 3) & 1;
                    bool rex_b = (regCode64(dest.reg) >> 3) & 1;
                    emitRex(true, rex_r, false, rex_b);
                    emitByte(0x09);
                    uint8_t modrm = 0xC0 | ((regCode64(src.reg) & 7) << 3) | (regCode64(dest.reg) & 7);
                    code.push_back(modrm);
                } else if (dest.type == Operand::REG && src.type == Operand::IMM) {
                    uint8_t dc = regCode64(dest.reg);
                    if (src.imm >= INT32_MIN && src.imm <= INT32_MAX) {
                        emitRex(true, false, false, (dc >> 3) & 1);
                        emitByte(0x81);
                        code.push_back(0xC0 | (1 << 3) | (dc & 7));
                        emitDword(static_cast<uint32_t>(static_cast<int32_t>(src.imm)));
                    } else {
                        Reg tmp = (dest.reg == Reg::R12) ? Reg::R11 : Reg::R12;
                        emitMovImm64ToReg(tmp, src.imm);
                        uint8_t tc = regCode64(tmp);
                        emitRex(true, (tc >> 3) & 1, false, (dc >> 3) & 1);
                        emitByte(0x09);
                        code.push_back(0xC0 | ((tc & 7) << 3) | (dc & 7));
                    }
                } else if (dest.type == Operand::REG && src.type == Operand::MEM) {
                    // OR reg, [mem]   → 0B /r
                    uint8_t dc = regCode64(dest.reg);
                    emitMemRex(src, (dc >> 3) & 1);
                    emitByte(0x0B);
                    emitMemModRM(src, dc & 7);
                } else if (dest.type == Operand::MEM && src.type == Operand::REG) {
                    // OR [mem], reg   → 09 /r
                    uint8_t sc = regCode64(src.reg);
                    emitMemRex(dest, (sc >> 3) & 1);
                    emitByte(0x09);
                    emitMemModRM(dest, sc & 7);
                } else {
                    err.report("OD: nicht unterstützte Operanden", instr.loc);
                }
                break;
            }
            case Opcode::XOR: {
                if (instr.operands.size() != 2) { err.report("XOD benötigt 2 Operanden", instr.loc); return; }
                const Operand& dest = instr.operands[0];
                const Operand& src = instr.operands[1];
                if (dest.type == Operand::REG && src.type == Operand::REG) {
                    bool rex_r = (regCode64(src.reg) >> 3) & 1;
                    bool rex_b = (regCode64(dest.reg) >> 3) & 1;
                    emitRex(true, rex_r, false, rex_b);
                    emitByte(0x31);
                    uint8_t modrm = 0xC0 | ((regCode64(src.reg) & 7) << 3) | (regCode64(dest.reg) & 7);
                    code.push_back(modrm);
                } else if (dest.type == Operand::REG && src.type == Operand::IMM) {
                    uint8_t dc = regCode64(dest.reg);
                    if (src.imm >= INT32_MIN && src.imm <= INT32_MAX) {
                        emitRex(true, false, false, (dc >> 3) & 1);
                        emitByte(0x81);
                        code.push_back(0xC0 | (6 << 3) | (dc & 7));
                        emitDword(static_cast<uint32_t>(static_cast<int32_t>(src.imm)));
                    } else {
                        Reg tmp = (dest.reg == Reg::R12) ? Reg::R11 : Reg::R12;
                        emitMovImm64ToReg(tmp, src.imm);
                        uint8_t tc = regCode64(tmp);
                        emitRex(true, (tc >> 3) & 1, false, (dc >> 3) & 1);
                        emitByte(0x31);
                        code.push_back(0xC0 | ((tc & 7) << 3) | (dc & 7));
                    }
                } else if (dest.type == Operand::REG && src.type == Operand::MEM) {
                    // XOR reg, [mem]  → 33 /r
                    uint8_t dc = regCode64(dest.reg);
                    emitMemRex(src, (dc >> 3) & 1);
                    emitByte(0x33);
                    emitMemModRM(src, dc & 7);
                } else if (dest.type == Operand::MEM && src.type == Operand::REG) {
                    // XOR [mem], reg  → 31 /r
                    uint8_t sc = regCode64(src.reg);
                    emitMemRex(dest, (sc >> 3) & 1);
                    emitByte(0x31);
                    emitMemModRM(dest, sc & 7);
                } else {
                    err.report("XOD: nicht unterstützte Operanden", instr.loc);
                }
                break;
            }
            case Opcode::NOT: {
                if (instr.operands.size() != 1) { err.report("NICH benötigt 1 Operand", instr.loc); return; }
                const Operand& op = instr.operands[0];
                if (op.type == Operand::REG) {
                    emitRex(true, false, false, (regCode64(op.reg) >> 3) & 1);
                    emitByte(0xF7);
                    uint8_t modrm = 0xC0 | (2 << 3) | (regCode64(op.reg) & 7);
                    code.push_back(modrm);
                } else if (op.type == Operand::MEM) {
                    emitMemRex(op, false);
                    emitByte(0xF7);
                    emitMemModRM(op, 2);
                } else {
                    err.report("NICH nur Register oder Speicher", instr.loc);
                }
                break;
            }
            case Opcode::INT: {
                if (instr.operands.size() != 1 || instr.operands[0].type != Operand::IMM) {
                    err.report("UNT benötigt einen unmittelbaren Wert", instr.loc);
                    return;
                }
                if (instr.operands[0].imm == 0x80) {
                    int exitLabel = newLabel();
                    int writeLabel = newLabel();
                    int endLabel = newLabel();

                    emitByte(0x83); emitByte(0xF8); emitByte(0x01);  // cmp eax, 1
                    emitJz(exitLabel);
                    emitByte(0x83); emitByte(0xF8); emitByte(0x04);  // cmp eax, 4
                    emitJz(writeLabel);
                    emitJmp(endLabel);

                    emitLabel(exitLabel);
                    emitByte(0x48); emitByte(0x83); emitByte(0xEC); emitByte(0x28); // sub rsp, 40
                    emitByte(0x31); emitByte(0xC9);
                    emitCallIat(iatExitProcess);

                    emitLabel(writeLabel);
                    emitPushImm(0);
                    emitByte(0x48); emitByte(0x83); emitByte(0xEC); emitByte(0x04); // sub rsp, 4  (64-bit)
                    emitByte(0x48); emitByte(0x89); emitByte(0xE0);                 // mov rax, rsp  (64-bit)
                    emitPushReg(0);
                    emitPushReg(2);
                    emitPushReg(1);
                    emitPushReg(3);
                    emitCallIat(iatWriteFile);
                    emitAddEsp(4);
                    emitLabel(endLabel);
                } else {
                    err.report("Nur UNT 0x80 wird unterstützt", instr.loc);
                }
                break;
            }
            case Opcode::IRET: {
                if (!instr.operands.empty()) {
                    err.report("UGIB benötigt keine Operanden", instr.loc);
                    return;
                }
                emitByte(0x48);   // REX.W
                emitByte(0xCF);   // IRETQ
                break;
            }
            case Opcode::IN: {
                if (instr.operands.size() != 2) {
                    err.report("IN benötigt 2 Operanden", instr.loc);
                    return;
                }
                const Operand& dest = instr.operands[0];
                const Operand& port = instr.operands[1];

                if (dest.type != Operand::REG) {
                    err.report("IN: erster Operand muss ein Register sein", instr.loc);
                    return;
                }
                // x86-64: IN 只支持 AL / AX / EAX（写入即零扩展到 RAX）
                if (port.type == Operand::REG) {
                    if (port.reg != Reg::R3) {                 // 必须 r3 == RDX
                        err.report("IN: zweiter Operand muss r3 (RDX) sein", instr.loc);
                        return;
                    }
                    emitByte(0xED);                             // IN EAX, DX
                } else if (port.type == Operand::IMM) {
                    if (port.imm < 0 || port.imm > 255) {
                        err.report("IN: Port muss zwischen 0 und 255 liegen", instr.loc);
                        return;
                    }
                    emitByte(0xE5);                             // IN EAX, imm8
                    emitByte(static_cast<uint8_t>(port.imm));
                } else {
                    err.report("IN: zweiter Operand muss Immediate oder r3 (RDX) sein",
                               instr.loc);
                }
                break;
            }
            case Opcode::OUT: {
                if (instr.operands.size() != 2) {
                    err.report("ERG benötigt 2 Operanden", instr.loc);
                    return;
                }
                const Operand& port = instr.operands[0];
                const Operand& src  = instr.operands[1];

                if (src.type != Operand::REG) {
                    err.report("ERG: zweiter Operand muss ein Register sein", instr.loc);
                    return;
                }
                if (port.type == Operand::REG) {
                    if (port.reg != Reg::R3) {                 // 必须 r3 == RDX
                        err.report("ERG: erster Operand muss r3 (RDX) sein", instr.loc);
                        return;
                    }
                    emitByte(0xEF);                             // OUT DX, EAX
                } else if (port.type == Operand::IMM) {
                    if (port.imm < 0 || port.imm > 255) {
                        err.report("ERG: Port muss zwischen 0 und 255 liegen", instr.loc);
                        return;
                    }
                    emitByte(0xE7);                             // OUT imm8, EAX
                    emitByte(static_cast<uint8_t>(port.imm));
                } else {
                    err.report("ERG: erster Operand muss Immediate oder r3 (RDX) sein",
                               instr.loc);
                }
                break;
            }
            default:
                err.report("Unbekannter Befehl für Compilierung", instr.loc);
        }
    }

    int labelCounter_ = 0;
    std::unordered_map<int, size_t> labelPositions_;
    struct Fixup { size_t pos; int label; bool isJz; };
    std::vector<Fixup> fixups_;

    int newLabel() { return labelCounter_++; }

    void emitLabel(int label) {
        labelPositions_[label] = code.size();
        for (auto it = fixups_.begin(); it != fixups_.end();) {
            if (it->label == label) {
                uint32_t offset = static_cast<uint32_t>(code.size() - (it->pos + 4));
                uint32_t* p = reinterpret_cast<uint32_t*>(&code[it->pos]);
                *p = offset;
                it = fixups_.erase(it);
            } else {
                ++it;
            }
        }
    }

    void emitJmp(int label) {
        emitByte(0xE9);
        auto it = labelPositions_.find(label);
        if (it != labelPositions_.end()) {                       // 向后跳：立即回填
            uint32_t target = static_cast<uint32_t>(it->second);
            uint32_t disp   = target - static_cast<uint32_t>(code.size() + 4);
            emitDword(disp);
        } else {
            emitDword(0x12345678);
            fixups_.push_back({ code.size() - 4, label, false });
        }
    }

    void emitJz(int label) {
        emitByte(0x0F); emitByte(0x84);
        auto it = labelPositions_.find(label);
        if (it != labelPositions_.end()) {
            uint32_t target = static_cast<uint32_t>(it->second);
            uint32_t disp   = target - static_cast<uint32_t>(code.size() + 4);
            emitDword(disp);
        } else {
            emitDword(0x12345678);
            fixups_.push_back({ code.size() - 4, label, true });
        }
    }

    void emitJnz(int label) {
        emitByte(0x0F); emitByte(0x85);
        auto it = labelPositions_.find(label);
        if (it != labelPositions_.end()) {
            uint32_t target = static_cast<uint32_t>(it->second);
            uint32_t disp   = target - static_cast<uint32_t>(code.size() + 4);
            emitDword(disp);
        } else {
            emitDword(0x12345678);
            fixups_.push_back({ code.size() - 4, label, true });
        }
    }

    void generateCode() {
        // 第一遍：记录每个用户 label 的真实字节偏移
        code.clear();
        labelPositions_.clear();
        fixups_.clear();
        std::unordered_map<std::string, uint64_t> realOffsets;
        for (const auto& instr : prog.code) {
            if (!instr.label.empty()) realOffsets[instr.label] = code.size();
            emitInstruction(instr);
        }

        // 第二遍：用真实偏移重新生成
        code.clear();
        labelPositions_.clear();
        fixups_.clear();
        labelOffsets = realOffsets;
        for (const auto& instr : prog.code) {
            if (!instr.label.empty()) labelOffsets[instr.label] = code.size();
            emitInstruction(instr);
        }
    }

    void buildImportTable() {
        data_.clear();
        data_.insert(data_.end(), prog.data.begin(), prog.data.end());
        while (data_.size() % 8) data_.push_back(0);

        std::vector<std::string> funcs = {"GetStdHandle", "WriteFile", "ExitProcess", "lstrlenA"};
        std::vector<uint32_t> nameOffs;

        for (const auto& f : funcs) {
            uint32_t off = static_cast<uint32_t>(data_.size());
            data_.push_back(0); data_.push_back(0);
            data_.insert(data_.end(), f.begin(), f.end());
            data_.push_back(0);
            while (data_.size() % 2) data_.push_back(0);
            nameOffs.push_back(off);
        }
        while (data_.size() % 8) data_.push_back(0);

        uint32_t intOffset = static_cast<uint32_t>(data_.size());
        for (uint32_t off : nameOffs) {
            uint64_t thunk = static_cast<uint64_t>(dataRva_ + off);
            for (int i = 0; i < 8; ++i)
                data_.push_back(static_cast<uint8_t>((thunk >> (i * 8)) & 0xFF));
        }
        for (int i = 0; i < 8; ++i) data_.push_back(0);

        uint32_t iatOffset = static_cast<uint32_t>(data_.size());
        for (uint32_t off : nameOffs) {
            uint64_t thunk = static_cast<uint64_t>(dataRva_ + off);
            for (int i = 0; i < 8; ++i)
                data_.push_back(static_cast<uint8_t>((thunk >> (i * 8)) & 0xFF));
        }
        for (int i = 0; i < 8; ++i) data_.push_back(0);

        iatGetStdHandle = iatOffset;
        iatWriteFile    = iatOffset + 8;
        iatExitProcess  = iatOffset + 16;
        iatLstrlen      = iatOffset + 24;

        uint32_t descOffset = static_cast<uint32_t>(data_.size());
        IMPORT_DESCRIPTOR desc = {};
        desc.OriginalFirstThunk = dataRva_ + intOffset;
        desc.FirstThunk         = dataRva_ + iatOffset;
        desc.Name               = dataRva_ + descOffset + sizeof(desc);
        data_.insert(data_.end(), (uint8_t*)&desc, (uint8_t*)&desc + sizeof(desc));

        std::string dll = "kernel32.dll";
        data_.insert(data_.end(), dll.begin(), dll.end());
        data_.push_back(0);

        IMPORT_DESCRIPTOR nullDesc = {};
        data_.insert(data_.end(), (uint8_t*)&nullDesc, (uint8_t*)&nullDesc + sizeof(nullDesc));

        importTableOffset = descOffset;
    }

    void buildPE(std::vector<uint8_t>& out, const std::string* outfile = nullptr) {
        uint32_t entryRVA = 0;
        auto it = labelOffsets.find("_start");
        if (it != labelOffsets.end()) entryRVA = static_cast<uint32_t>(it->second);

        uint32_t codeRawSize = (static_cast<uint32_t>(code.size()) + FILE_ALIGN - 1) & ~(FILE_ALIGN - 1);
        uint32_t dataRawSize = (static_cast<uint32_t>(data_.size()) + FILE_ALIGN - 1) & ~(FILE_ALIGN - 1);
        if (dataRawSize == 0) dataRawSize = FILE_ALIGN;
        uint32_t codeVirtualSize = (static_cast<uint32_t>(code.size()) + SECTION_ALIGN - 1) & ~(SECTION_ALIGN - 1);
        uint32_t dataVirtualSize = (static_cast<uint32_t>(data_.size()) + SECTION_ALIGN - 1) & ~(SECTION_ALIGN - 1);
        if (dataVirtualSize == 0) dataVirtualSize = SECTION_ALIGN;

        uint32_t sizeOfImage = dataRva_ + dataVirtualSize;
        if (sizeOfImage < 0x3000) sizeOfImage = 0x3000;

        code.resize(codeRawSize, 0);
        data_.resize(dataRawSize, 0);

        out.clear();

        DOS_HEADER dos = {};
        dos.e_magic = 0x5A4D;
        dos.e_lfanew = 0x40;
        out.insert(out.end(), (uint8_t*)&dos, (uint8_t*)&dos + sizeof(dos));
        out.resize(0x40, 0);

        uint32_t peSig = 0x00004550;
        out.insert(out.end(), (uint8_t*)&peSig, (uint8_t*)&peSig + 4);

        FILE_HEADER file = {};
        file.Machine = 0x8664;
        file.NumberOfSections = 2;
        file.SizeOfOptionalHeader = sizeof(OPTIONAL_HEADER64);
        file.Characteristics = 0x0102;
        out.insert(out.end(), (uint8_t*)&file, (uint8_t*)&file + sizeof(file));

        OPTIONAL_HEADER64 opt = {};
        opt.Magic = 0x20B;
        opt.AddressOfEntryPoint = textRva_ + entryRVA;
        opt.BaseOfCode = textRva_;
        opt.ImageBase = IMAGE_BASE;
        opt.SectionAlignment = SECTION_ALIGN;
        opt.FileAlignment = FILE_ALIGN;
        opt.MajorSubsystemVersion = 6;
        opt.SizeOfImage = sizeOfImage;
        opt.SizeOfHeaders = textRawOff_;
        opt.Subsystem = 3;
        opt.NumberOfRvaAndSizes = 16;
        opt.DataDirectory[1][0] = dataRva_ + importTableOffset;
        opt.DataDirectory[1][1] = 2 * sizeof(IMPORT_DESCRIPTOR);
        out.insert(out.end(), (uint8_t*)&opt, (uint8_t*)&opt + sizeof(opt));

        SECTION_HEADER textSect = {};
        memcpy(textSect.Name, ".text", 5);
        textSect.VirtualSize = static_cast<uint32_t>(code.size());
        textSect.VirtualAddress = textRva_;
        textSect.SizeOfRawData = codeRawSize;
        textSect.PointerToRawData = textRawOff_;
        textSect.Characteristics = 0x60000020;
        out.insert(out.end(), (uint8_t*)&textSect, (uint8_t*)&textSect + sizeof(textSect));

        SECTION_HEADER dataSect = {};
        memcpy(dataSect.Name, ".data", 5);
        dataSect.VirtualSize = static_cast<uint32_t>(data_.size());
        dataSect.VirtualAddress = dataRva_;
        dataSect.SizeOfRawData = dataRawSize;
        dataSect.PointerToRawData = dataRawOff_;
        dataSect.Characteristics = 0xC0000040;
        out.insert(out.end(), (uint8_t*)&dataSect, (uint8_t*)&dataSect + sizeof(dataSect));

        out.resize(textRawOff_, 0);
        out.insert(out.end(), code.begin(), code.end());
        out.resize(dataRawOff_, 0);
        out.insert(out.end(), data_.begin(), data_.end());

        if (outfile) {
            std::ofstream f(*outfile, std::ios::binary);
            if (!f) { err.report("Kann Ausgabedatei nicht öffnen", {}); return; }
            f.write((char*)out.data(), out.size());
            f.close();
        }
        built = true;
        peImage = out;
    }

    int loadAndExecute() {
        if (!built) {
            buildPE(peImage);
            if (err.hasErrors()) return -1;
        }

        uint8_t* image = peImage.data();
        PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)image;
        if (dos->e_magic != 0x5A4D) { err.report("Ungültiges DOS-Signatur", {}); return -1; }
        PIMAGE_NT_HEADERS64 nt = (PIMAGE_NT_HEADERS64)(image + dos->e_lfanew);
        if (nt->Signature != 0x00004550) { err.report("Ungültige PE-Signatur", {}); return -1; }

        DWORD imageSize = nt->OptionalHeader.SizeOfImage;
        uint64_t imageBase = nt->OptionalHeader.ImageBase;
        uint8_t* base = (uint8_t*)VirtualAlloc((void*)imageBase, imageSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
        if (!base) {
            err.report("Konnte Speicher an der benötigten Basisadresse nicht reservieren.", {});
            return -1;
        }

        memcpy(base, image, nt->OptionalHeader.SizeOfHeaders);

        PIMAGE_SECTION_HEADER sect = IMAGE_FIRST_SECTION(nt);
        for (int i = 0; i < nt->FileHeader.NumberOfSections; ++i) {
            if (sect[i].SizeOfRawData) {
                uint8_t* dest = base + sect[i].VirtualAddress;
                uint8_t* src = image + sect[i].PointerToRawData;
                memcpy(dest, src, sect[i].SizeOfRawData);
            }
        }

        DWORD importRVA = nt->OptionalHeader.DataDirectory[1].VirtualAddress;
        if (importRVA) {
            PIMAGE_IMPORT_DESCRIPTOR desc = (PIMAGE_IMPORT_DESCRIPTOR)(base + importRVA);
            while (desc->Name) {
                const char* dllName = (const char*)(base + desc->Name);
                HMODULE hMod = LoadLibraryA(dllName);
                if (!hMod) { err.report("LoadLibrary fehlgeschlagen für " + std::string(dllName), {}); return -1; }

                PIMAGE_THUNK_DATA64 thunk = (PIMAGE_THUNK_DATA64)(base + desc->FirstThunk);
                PIMAGE_THUNK_DATA64 orig = (PIMAGE_THUNK_DATA64)(base + desc->OriginalFirstThunk);
                if (!orig) orig = thunk;
                while (orig->u1.AddressOfData) {
                    FARPROC func = nullptr;
                    if (orig->u1.Ordinal & IMAGE_ORDINAL_FLAG64) {
                        func = GetProcAddress(hMod, (LPCSTR)(orig->u1.Ordinal & 0xFFFF));
                    } else {
                        PIMAGE_IMPORT_BY_NAME name = (PIMAGE_IMPORT_BY_NAME)(base + orig->u1.AddressOfData);
                        func = GetProcAddress(hMod, name->Name);
                    }
                    if (!func) {
                        err.report("GetProcAddress fehlgeschlagen", {});
                        return -1;
                    }
                    thunk->u1.Function = (ULONGLONG)func;
                    ++thunk; ++orig;
                }
                ++desc;
            }
        }

        uint64_t entryRVA = nt->OptionalHeader.AddressOfEntryPoint;
        uint8_t* entry = base + entryRVA;
        using EntryFunc = int (*)();
        EntryFunc f = (EntryFunc)entry;
        int ret = f();
        VirtualFree(base, 0, MEM_RELEASE);
        return ret;
    }

public:
    Compiler(const Program& p, ErrorCollector& ec) : prog(p), err(ec) {}

    bool compile(const std::string& outfile) {
        if (!computeLayout()) return false;
        buildImportTable();
        generateCode();
        if (err.hasErrors()) return false;
        buildPE(peImage, &outfile);
        return !err.hasErrors();
    }

    bool run() {
        if (!computeLayout()) return false;
        buildImportTable();
        generateCode();
        if (err.hasErrors()) return false;
        int exitCode = loadAndExecute();
        if (exitCode < 0) return false;
        if (!err.hasErrors()) {
            exit(exitCode);
        }
        return true;
    }
};


// ============================================================================
// UTF-8 Konsolenausgabe
// ============================================================================
static void initConsole() {
    #ifdef _WIN32
        SetConsoleOutputCP(CP_UTF8);
        SetConsoleCP(CP_UTF8);
    #endif
}

// ============================================================================
// Hauptprogramm
// ============================================================================
int main(int argc, char* argv[]) {
    initConsole();

    if (argc < 2) {
        std::cerr << "Aufruf: " << argv[0] << " quelle.va [-c exe ausgabe.exe]\n";
        std::cerr << "   oder: " << argv[0] << " -e \"code\" [-c exe ausgabe.exe]\n";
        return 1;
    }

    bool compileMode = false;
    std::string outFile;
    std::string sourceCode;
    bool fromFile = true;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "-c") {
            if (i + 2 < argc && std::string(argv[i+1]) == "exe") {
                compileMode = true;
                outFile = argv[i+2];
                i += 2;
            } else {
                std::cerr << "Fehler: -c exe <ausgabe> erwartet\n";
                return 1;
            }
        } else if (arg == "-e") {
            if (i + 1 < argc) {
                sourceCode = argv[++i];
                fromFile = false;
            } else {
                std::cerr << "Fehler: -e benötigt einen String\n";
                return 1;
            }
        } else {
            if (fromFile) {
                if (!sourceCode.empty()) {
                    std::cerr << "Warnung: Mehrere Quelldateien, verwende erste\n";
                } else {
                    sourceCode = arg;
                }
            }
        }
    }

    if (sourceCode.empty() && fromFile) {
        std::cerr << "Fehler: Kein Quellcode angegeben\n";
        return 1;
    }

    std::string src;
    if (fromFile) {
        std::ifstream in(sourceCode, std::ios::binary);
        if (!in) {
            std::cerr << "Fehler: Kann Quelldatei nicht öffnen: " << sourceCode << "\n";
            return 1;
        }
        std::string raw((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        in.close();

        if (raw.size() >= 3 &&
            (unsigned char)raw[0] == 0xEF &&
            (unsigned char)raw[1] == 0xBB &&
            (unsigned char)raw[2] == 0xBF) {
            src = raw.substr(3);
        } else {
            src = raw;
        }
    } else {
        src = sourceCode;
    }

    ErrorCollector err;
    err.setSource(src);
    std::string fname = fromFile ? sourceCode : "<command-line>";
    Parser parser(src, fname, err);
    Program prog;
    if (!parser.parse(prog)) {
        err.printAll();
        return 1;
    }

    bool hasStart = false;
    for (const auto& instr : prog.code) {
        if (instr.label == "_start") {
            hasStart = true;
            break;
        }
    }

    if (!hasStart) {
        if (prog.code.empty()) {
            Instruction exitInstr;
            exitInstr.op = Opcode::EXIT;
            exitInstr.label = "_start";
            prog.code.push_back(exitInstr);
        } else {
            err.report("Kein Einstiegspunkt '_start' gefunden.", {});
            err.printAll();
            return 1;
        }
    }

    if (compileMode) {
        Compiler compiler(prog, err);
        if (!compiler.compile(outFile)) {
            err.printAll();
            return 1;
        }
        std::cout << "Erfolgreich kompiliert: " << outFile << "\n";
    } else {
        Compiler compiler(prog, err);
        if (!compiler.run()) {
            err.printAll();
            return 1;
        }
    }

    return 0;
}