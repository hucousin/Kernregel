#!/usr/bin/env python3
"""
hexdump_utf8.py - 二进制文件转储工具，压缩连续零字节，并尝试翻译 UTF-8 文本。

用法: python hexdump_utf8.py <二进制文件路径>
输出格式:
  偏移量: 十六进制字节序列 (每行最多16字节)
  若某非零块可解码为可读 UTF-8，则在块末尾添加注释行 "# UTF-8: <译文>"
  连续零字节显示为 "00*N"
"""

import sys
import os


def is_readable_utf8(data: bytes) -> str | None:
    """
    尝试将字节数据解码为 UTF-8，并判断是否为可读文本。
    可读条件：解码成功，且所有字符均为可打印字符或常用空白符（空格、换行、回车、制表）。
    若满足则返回解码后的字符串，否则返回 None。
    """
    if not data:
        return None
    try:
        text = data.decode('utf-8')
    except UnicodeDecodeError:
        return None

    # 允许的空白字符：空格、换行、回车、制表、垂直制表、换页
    allowed_whitespace = {' ', '\n', '\r', '\t', '\v', '\f'}
    for ch in text:
        if ch.isprintable() or ch in allowed_whitespace:
            continue
        else:
            return None
    return text


def format_hex_line(offset: int, chunk: bytes) -> str:
    """将一段字节格式化为一行：偏移量 + 十六进制字节（空格分隔）"""
    hex_str = ' '.join(f'{b:02X}' for b in chunk)
    return f'{offset:08x}: {hex_str}'


def process_file(data: bytes) -> list[str]:
    """处理整个文件数据，返回输出行列表"""
    out_lines = []
    i = 0
    length = len(data)

    while i < length:
        # 检测连续零块
        if data[i] == 0:
            start = i
            while i < length and data[i] == 0:
                i += 1
            count = i - start
            out_lines.append(f'{start:08x}: 00*{count}')
            continue

        # 非零块
        block_start = i
        block_bytes = bytearray()
        while i < length and data[i] != 0:
            block_bytes.append(data[i])
            i += 1
        block = bytes(block_bytes)

        # 将非零块按每行最多 16 字节输出
        block_len = len(block)
        for j in range(0, block_len, 16):
            chunk = block[j:j+16]
            offset = block_start + j
            out_lines.append(format_hex_line(offset, chunk))

        # 尝试将整个块解码为 UTF-8，若可读则添加注释
        text = is_readable_utf8(block)
        if text is not None:
            # 若块中有换行等，注释可保留原样，但为了显示整洁，可替换换行为 \n
            # 这里直接显示，允许多行注释，但为了避免破坏格式，我们保持单行，但可压缩空白
            # 简单起见，保留原样，但若包含换行，注释可能跨行，我们可以将其替换为空格
            # 但为了更清晰，保留原样，不过注释行前加 '# UTF-8: '
            # 如果文本包含换行，会影响格式，我们可以只取前几个字符或转义
            # 这里直接使用，用户可自行处理
            out_lines.append(f'# UTF-8: {text}')

    return out_lines


def main():
    if len(sys.argv) != 2:
        print("用法: python hexdump_utf8.py <二进制文件路径>", file=sys.stderr)
        sys.exit(1)

    filepath = sys.argv[1]
    if not os.path.isfile(filepath):
        print(f"错误: 文件 '{filepath}' 不存在", file=sys.stderr)
        sys.exit(1)

    with open(filepath, 'rb') as f:
        data = f.read()

    lines = process_file(data)
    print('\n'.join(lines))


if __name__ == '__main__':
    main()